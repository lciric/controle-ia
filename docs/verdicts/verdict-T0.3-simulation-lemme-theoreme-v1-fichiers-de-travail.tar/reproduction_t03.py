"""Reproduction hors dépôt des résultats bruts du run décisif de T0.3 (lecteur du verdict, R4 ; non décisive).

Exécute le code du commit cité (extrait par `git archive d73ac469…` dans un dossier du bloc-notes) avec la grille
scellée et les graines du manifeste du run, sans les gardes de lancement (elles exigent le dépôt) et sans rien
écrire dans le dépôt. Sérialise chaque résultat comme `manifeste.ecrire_resultat` (même run_id, même empreinte de
manifeste, json trié, indentation 2) et compare l'empreinte à celle du fichier scellé de diag/20261004-080257-t03/.

Usage : python -I reproduction_t03.py <extrait du commit cité> <racine du dépôt> <sortie.json>
"""
import hashlib
import json
import sys
import time
from pathlib import Path

EXTRAIT, RACINE, SORTIE = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
sys.path.insert(0, str(EXTRAIT / "src"))

from controle_ia.simulation_t03 import blocs as B  # noqa: E402

RUN = "20261004-080257-t03"
man_txt = (RACINE / "runs" / RUN / "manifeste.json").read_bytes()
man = json.loads(man_txt)
sha_m = hashlib.sha256(man_txt).hexdigest()
grille_txt = (EXTRAIT / "prereg" / "T0.3-grille-v2.json").read_bytes()
assert hashlib.sha256(grille_txt).hexdigest() == "5609f920c0d606a192e92b2c2172416dad740b158940aac1ee049de8b8affe23"
grille = json.loads(grille_txt)
assert grille == man["config"]["grille"]


def octets(contenu):
    corps = {"run_id": RUN, "manifeste_sha256": sha_m, "resultat": contenu}
    return (json.dumps(corps, indent=2, ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8")


def scelle(nom):
    return hashlib.sha256((RACINE / "diag" / RUN / f"{nom}.json").read_bytes()).hexdigest()


ctx = B.Contexte(grille, man["graines"], suffixe="", facteur_R=1)
t0 = time.monotonic()
sortie = {"comparaisons": {}, "durees_s": {}}
calib = {cfg: B.calibrer(ctx, cfg) for cfg in grille["configs"]}
contenu = {"configs": calib, "rho": {str(k): v for k, v in ctx.rho.items()}}
h = hashlib.sha256(octets(contenu)).hexdigest()
sortie["comparaisons"]["calibrage"] = {"reproduit": h, "scelle": scelle("calibrage"), "egal": h == scelle("calibrage")}
sortie["durees_s"]["calibrage"] = round(time.monotonic() - t0, 1)
print("calibrage", sortie["comparaisons"]["calibrage"]["egal"], sortie["durees_s"]["calibrage"], flush=True)
for b in man["config"]["blocs"]:
    res = B.BLOCS[b](ctx)
    h = hashlib.sha256(octets(res)).hexdigest()
    sortie["comparaisons"][f"bloc-{b}"] = {"reproduit": h, "scelle": scelle(f"bloc-{b}"), "egal": h == scelle(f"bloc-{b}")}
    if not sortie["comparaisons"][f"bloc-{b}"]["egal"]:
        ref = json.loads((RACINE / "diag" / RUN / f"bloc-{b}.json").read_text(encoding="utf-8"))["resultat"]
        sortie["comparaisons"][f"bloc-{b}"]["contenu_egal_apres_relecture_json"] = (json.loads(json.dumps(res)) == ref)
    sortie["durees_s"][b] = round(time.monotonic() - t0, 1)
    print(b, sortie["comparaisons"][f"bloc-{b}"]["egal"], sortie["durees_s"][b], flush=True)
sortie["tous_egaux"] = all(v["egal"] for v in sortie["comparaisons"].values())
SORTIE.write_text(json.dumps(sortie, ensure_ascii=False, indent=1), encoding="utf-8")
print("tous égaux :", sortie["tous_egaux"])
