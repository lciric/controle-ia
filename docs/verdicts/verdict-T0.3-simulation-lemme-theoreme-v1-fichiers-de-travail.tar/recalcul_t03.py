"""Recalcul indépendant de la lecture gelée de T0.3 (lecteur du verdict, R13).

N'importe aucun module du programme (ni lecture.py ni calibrage.py) : formes closes recalculées
avec scipy, critères de la table A du préenregistrement réécrits depuis le texte, puis comparés,
cellule par cellule, à diag/20261004-080257-t03/lecture.json.

Usage : python -I recalcul_t03.py <racine du dépôt> <sortie.json>
"""
import json
import math
import sys
from pathlib import Path

import numpy as np
from scipy import optimize, special, stats

RACINE = Path(sys.argv[1])
SORTIE = Path(sys.argv[2])
D = RACINE / "diag" / "20261004-080257-t03"
ALPHA = 0.05
Z = 4.0                      # préenregistrement, l. 262
SEUIL_P72 = 0.99             # l. 263
BORNES = (0.3, 3.0)          # l. 309


def charge(nom):
    return json.loads((D / f"{nom}.json").read_text(encoding="utf-8"))["resultat"]


cal = charge("calibrage")["configs"]


def p0(cfg, st):
    c = cal[cfg]
    return c["alarmes_p0"][st] / c["R0"], c["R0"]


# --- écarts-types (« Métrique », l. 245-249) ---
def var_prop(p, R):
    return max(p * (1 - p), 1.0 / R) / R


def se_diff(p, R, q, R0):
    return math.sqrt(var_prop(p, R) + var_prop(q, R0))


# --- table A (l. 321-333), réécrite depuis le texte ---
def _A_egal(p, R, q, R0):
    se = se_diff(p, R, q, R0); d = p - q
    return ("conforme" if abs(d) <= Z * se else "contraire"), d / se


def _A_au_dessus(p, R, q, R0):
    se = se_diff(p, R, q, R0); d = p - q
    return ("conforme" if d > Z * se else ("contraire" if d < -Z * se else "non concluant")), d / se


def _A_en_dessous(p, R, q, R0):
    se = se_diff(p, R, q, R0); d = p - q
    return ("conforme" if d < -Z * se else ("contraire" if d > Z * se else "non concluant")), d / se


def _A_au_plus(p, R, q, R0):
    se = se_diff(p, R, q, R0); d = p - q
    return ("conforme" if d <= Z * se else "contraire"), d / se


def _A_forme_close(p, R, pth):
    se = math.sqrt(var_prop(pth, R)); d = p - pth
    return ("conforme" if abs(d) <= Z * se else "contraire"), d / se


def _A_au_plus_alpha(p, R):
    se = math.sqrt(var_prop(ALPHA, R))
    return ("conforme" if p <= ALPHA + Z * se else "contraire"), (p - ALPHA) / se


def _A_depasse_alpha(p, R):
    se = math.sqrt(var_prop(ALPHA, R))
    return ("conforme" if p > ALPHA + Z * se else ("contraire" if p < ALPHA - Z * se else "non concluant")), (p - ALPHA) / se


def _A_au_moins_099(p, R):
    se = math.sqrt(var_prop(SEUIL_P72, R))
    return ("conforme" if p >= SEUIL_P72 - Z * se else "contraire"), (p - SEUIL_P72) / se


def _A_traj(v):
    return ("conforme" if v == 0 else "contraire"), None


CRIT = {"crit": None}       # nom de la ligne de la table A appliquée à la dernière cellule


def _enregistre(nom, f):
    def g(*a):
        CRIT["crit"] = nom
        return f(*a)
    return g


A_egal = _enregistre("égal", _A_egal)
A_au_dessus = _enregistre("au-dessus", _A_au_dessus)
A_en_dessous = _enregistre("en dessous", _A_en_dessous)
A_au_plus = _enregistre("au plus", _A_au_plus)
A_forme_close = _enregistre("forme close", _A_forme_close)
A_au_plus_alpha = _enregistre("au plus α", _A_au_plus_alpha)
A_depasse_alpha = _enregistre("dépasse α", _A_depasse_alpha)
A_au_moins_099 = _enregistre("au moins 0,99", _A_au_moins_099)
A_traj = _enregistre("trajectoriel", _A_traj)


# --- formes closes, recalculées sans le code du programme ---
za = stats.norm.isf(ALPHA)


def fc_somme(n0, B):            # P1.2, P1.3
    return float(stats.norm.sf(za - B / math.sqrt(n0)))


def fc_max(n, B, m):            # P2.1
    c = stats.norm.ppf((1 - ALPHA) ** (1.0 / n))
    return float(1 - stats.norm.cdf(c) ** (n - m) * stats.norm.cdf(c - B / m) ** m), float(c)


def logE_unilat(s, n, rho):     # E⁺ du processus e de mélange demi-normal (sigma = 1)
    a = 1 + rho * rho * n
    return math.log(2) - 0.5 * math.log(a) + rho * rho * s * s / (2 * a) + stats.norm.logcdf(rho * s / math.sqrt(a))


def frontiere(n, rho):
    h = math.log(1 / ALPHA)
    return optimize.brentq(lambda s: logE_unilat(s, n, rho) - h, 0.0, 1e6, xtol=1e-13)


def rho_etoile(n):
    r = optimize.minimize_scalar(lambda lr: frontiere(n, math.exp(lr)), bounds=(math.log(1e-4), math.log(10)),
                                 method="bounded", options={"xatol": 1e-12})
    return math.exp(r.x), frontiere(n, math.exp(r.x))


def v_ar1(phi, n):              # variance de la somme / n, AR(1) stationnaire de variance 1
    h = np.arange(1, n)
    return float(1 + 2 * np.sum((1 - h / n) * phi ** h))


def fc_variance(rapport):       # P6.3, P6.4, P6.5 : Φ̄(z_α / √rapport)
    return float(stats.norm.sf(za / math.sqrt(rapport)))


def fc_dispersion(T, mus, seuil):
    """P4.3 : puissance exacte du rebrassage total, par énumération des tables 3 × 3 de marges (T, T, T)
    (loi multi-hypergéométrique), χ²₃ non central conditionnel. Écrit indépendamment."""
    mus = np.asarray(mus, float)
    lf = lambda k: special.gammaln(np.asarray(k, float) + 1)
    r = np.arange(T + 1)
    k11, k12, k21, k22 = [x.ravel() for x in np.meshgrid(r, r, r, r, indexing="ij")]
    k13, k23 = T - k11 - k12, T - k21 - k22
    k31, k32 = T - k11 - k21, T - k12 - k22
    k33 = T - k13 - k23
    ok = (k13 >= 0) & (k23 >= 0) & (k31 >= 0) & (k32 >= 0) & (k33 >= 0)
    K = np.stack([k11, k12, k13, k21, k22, k23, k31, k32, k33], axis=1)[ok].astype(float)
    lconst = 6 * lf(T) - lf(3 * T)
    lp = lconst - lf(K).sum(axis=1)
    P = np.exp(lp)
    M = K.reshape(-1, 3, 3) @ mus / T            # moyenne attendue de chaque agent, sachant la table
    lam = T * np.sum((M - mus) ** 2, axis=1)
    lam_r = np.round(lam, 10)
    uniq, inv = np.unique(lam_r, return_inverse=True)
    sf = np.where(uniq > 0, stats.ncx2.sf(seuil, 3, np.maximum(uniq, 1e-300)), stats.chi2.sf(seuil, 3))
    return float(np.sum(P * sf[inv])), float(P.sum()), int(K.shape[0])


cellules = {}          # (pred, nom) -> dict
z_fc, z_eg = [], []
z_fc_lab, z_eg_lab = [], []


def cel(pred, nom, etat_z, genre="statistique", fc=None, eg=False, crit=None, **info):
    etat, z = etat_z
    if fc is not None and z is not None and 0.01 <= fc <= 0.99:
        z_fc.append(z)
        z_fc_lab.append(pred)
    if eg and z is not None:
        z_eg.append(z)
        z_eg_lab.append(pred)
    cellules[(pred, nom)] = {"etat": etat, "z": z, "genre": genre, "critere": crit or CRIT["crit"], **info}
    CRIT["crit"] = None


valeurs_fc = {}

# --- P1 ---
for g in charge("bloc-P1a")["groupes"]:
    n0, B, R = g["n0"], g["B"], g["R"]
    tag = f"{g['N']}x{g['T']}/B{B}"
    assert abs(g["tolerance_ecart"] - 1e-9 * n0) < 1e-15
    for c in g["cellules"]:
        v = c["disc_somme"] + c["disc_eterm"] + (1 if c["ecart_max"] > 1e-9 * n0 else 0)
        cel("P1.1", f"{tag}/{c['schema']}/m{c['m']}/{c['genre']}", A_traj(v), "trajectoriel")
    pth = fc_somme(n0, B)
    valeurs_fc[f"P1.2/{tag}"] = pth
    cel("P1.2", tag, A_forme_close(g["alarmes_ref_somme"] / R, R, pth), fc=pth, p=g["alarmes_ref_somme"] / R)
P1b = charge("bloc-P1b")["cellules"]
for c in P1b:
    pth = fc_somme(c["n0"], c["B"])
    valeurs_fc[f"P1.3/{c['N']}x{c['T']}/B{c['B']}"] = pth
    cel("P1.3", f"{c['N']}x{c['T']}/B{c['B']}", A_forme_close(c["alarmes_somme"] / c["R"], c["R"], pth), fc=pth,
        p=c["alarmes_somme"] / c["R"])
par = {(c["N"], c["n0"], c["B"]): c for c in P1b}
for B in (10, 20, 30):
    n0s = [50, 100, 200, 500, 1000]
    for a, b in zip(n0s[:-1], n0s[1:]):
        ca, cb = par[(1, a, B)], par[(1, b, B)]
        cel("P1.3", f"décroissance/B{B}/{a}>{b}", A_au_dessus(ca["alarmes_somme"] / ca["R"], ca["R"],
                                                             cb["alarmes_somme"] / cb["R"], cb["R"]))
    for (N, n0) in ((5, 200), (5, 500), (10, 1000)):
        c, c1 = par[(N, n0, B)], par[(1, n0, B)]
        cel("P1.4", f"{c['N']}x{c['T']}~1x{n0}/B{B}", A_egal(c["alarmes_somme"] / c["R"], c["R"],
                                                            c1["alarmes_somme"] / c1["R"], c1["R"]), eg=True)

# --- P2 ---
P2 = charge("bloc-P2")
q, R0 = p0(P2["cfg"], "max")
cn_run = P2["seuil_max"]
for c in P2["cellules"]:
    pth, cn = fc_max(c["n0"], c["B"], c["m"])
    valeurs_fc[f"P2.1/B{c['B']}/m{c['m']}"] = pth
    cel("P2.1", f"B{c['B']}/m{c['m']}", A_forme_close(c["alarmes_max"] / c["R"], c["R"], pth), fc=pth,
        p=c["alarmes_max"] / c["R"])
for B in (10, 20, 30):
    seq = sorted([c for c in P2["cellules"] if c["B"] == B], key=lambda c: c["m"])
    for ca, cb in zip(seq[:-1], seq[1:]):
        cel("P2.2", f"B{B}/m{cb['m']}≤m{ca['m']}", A_au_plus(cb["alarmes_max"] / cb["R"], cb["R"],
                                                            ca["alarmes_max"] / ca["R"], ca["R"]))
    d = seq[-1]
    cel("P2.3", f"B{B}/m{d['m']}", A_au_dessus(d["alarmes_max"] / d["R"], d["R"], q, R0))

# --- P3 ---
rho200, s200 = rho_etoile(200)
for g in charge("bloc-P3")["groupes"]:
    tag = f"{g['N']}x{g['T']}/B{g['B']}"
    for m, viol in g["violations"].items():
        cel("P3.1", f"{tag}/m{m}", A_traj(sum(viol.values())), "trajectoriel")
    taux = {(c["m"], c["calendrier"]): c["alarmes"] / g["R"] for c in g["cellules"]}
    for m in sorted({c["m"] for c in g["cellules"]}):
        for avant in ("debut", "uniforme"):
            cel("P3.2", f"{tag}/m{m}/{avant}>fin", A_au_dessus(taux[(m, avant)], g["R"], taux[(m, "fin")], g["R"]))
    pth = float(stats.norm.sf((frontiere(g["n0"], g["rho"]) - g["B"]) / math.sqrt(g["n0"])))
    valeurs_fc[f"P3.3/{tag}"] = pth
    cel("P3.3", tag, A_forme_close(g["alarmes_terminal"] / g["R"], g["R"], pth), fc=pth, p=g["alarmes_terminal"] / g["R"])
for c in charge("bloc-P34")["cellules"]:
    R = c["R"]
    ref = c["comptes"]["e_unilat_cal"]["a_temps"] / R
    for a_ in ("page", "detecteur_e"):
        cel("P3.4", f"B{c['B']}/m{c['m']}/{a_}>e_unilat_cal", A_au_dessus(c["comptes"][a_]["a_temps"] / R, R, ref, R))

# --- P4 ---
for c in charge("bloc-P4")["configs"]:
    tag, cfg = f"{c['N']}x{c['T']}", f"gauss_{c['N']}x{c['T']}"
    for arr, t in c["T1"].items():
        v = sum(t["valeurs_differentes"].values()) + sum(t["discordances"].values())
        cel("P4.1", f"{tag}/{arr}", A_traj(v), "trajectoriel")
    vus = {}
    for arr, comptes in c["T2"].items():
        for al, k in comptes.items():
            qq, RR0 = p0(cfg, al)
            sym = al in ("somme", "somme_bilat", "max", "e_terminal_ville")
            doublon = sym and al in vus           # second arrangement : même multi-ensemble
            if sym:
                vus[al] = k
            cel("P4.2", f"{tag}/{arr}/{al}", A_egal(k / c["R"], c["R"], qq, RR0), eg=not doublon)
P43 = charge("bloc-P43")
cfg43 = P43["cfg"]
q, R0 = p0(cfg43, "dispersion_agents")
pt = P43["alarmes_total"] / P43["R"]
loi43 = cal[cfg43]["loi"]
seuil43 = cal[cfg43]["seuils"]["dispersion_agents"]
pth43, masse43, ntab43 = fc_dispersion(int(loi43["T"]), loi43["mus"], seuil43)
valeurs_fc["P4.3/rebrassage_total"] = pth43
valeurs_fc["P4.3/masse_tables"] = masse43
valeurs_fc["P4.3/nombre_tables"] = ntab43
valeurs_fc["P4.3/T30_40_50_seuil_chi2"] = [fc_dispersion(T_, loi43["mus"], float(stats.chi2.isf(ALPHA, 3)))[0]
                                            for T_ in (30, 40, 50)]
cel("P4.3", "rebrassage_total>P0", A_au_dessus(pt, P43["R"], q, R0))
cel("P4.3", "rebrassage_total=forme_close", A_forme_close(pt, P43["R"], pth43), fc=pth43, p=pt)
cel("P4.3", "rebrassage_intra_agent", A_egal(P43["alarmes_intra_agent"] / P43["R"], P43["R"], q, R0), eg=True)

# --- P5 ---
t = charge("bloc-P5_temps")
R, cfg = t["R"], t["cfg"]
for arr, c in t["arrangements"].items():
    cel("P5.1", arr, A_traj(c["viol_page"] + c["viol_glissante"] + c["borne_sans_alarme"]), "trajectoriel")
for arr in ("bloc_r5", "bloc_r10"):
    c = t["arrangements"][arr]
    for al in ("glissante_5", "page"):
        cel("P5.2", f"{arr}/{al}", A_au_dessus(c["alarmes"][al] / R, R, *p0(cfg, al)))
p53_appariement = {}
for arr, cible in (("apparie_autocorr", "autocorr"), ("apparie_suites", "suites")):
    c = t["arrangements"][arr]
    frac = c["ecart_hors_tolerance"] / R
    p53_appariement[arr] = {"ecart_hors_tolerance": c["ecart_hors_tolerance"], "fraction": frac}
    if frac > 0.01:
        cel("P5.3", f"{arr}/{cible}", ("non concluant", None), crit="appariement incomplet")
    else:
        cel("P5.3", f"{arr}/{cible}", A_au_plus(c["alarmes"][cible] / R, R, *p0(cfg, cible)))
    for al in ("glissante_5", "page"):
        cel("P5.3", f"{arr}/{al}", A_au_dessus(c["alarmes"][al] / R, R, *p0(cfg, al)))
a = charge("bloc-P5_agents")
cel("P5.4", "co_elevation_3≥3·v(3)", A_traj(a["viol_co_elevation"]), "trajectoriel")
cel("P5.5", "co_elevation_3", A_au_dessus(a["alarmes"]["co_elevation_3"] / a["R"], a["R"], *p0(a["cfg"], "co_elevation_3")))

# --- P6 ---
phi0_2606 = float(cal["ar05_1x300"]["loi"]["phi"])
for c in charge("bloc-P6")["cellules"]:
    loi, R, cfg, nom = c["loi"], c["R"], c["cfg"], c["nom"]
    p = {k: v / R for k, v in c["alarmes"].items()}
    if c["role"] == "copule_temps":
        phi, gauss = float(loi["phi"]), loi["marginale"] == "gauss"
        if phi > 0:
            if gauss:
                for al in ("somme", "e_unilat_ville"):
                    cel("P6.1", f"{nom}/{al}", A_au_dessus(p[al], R, *p0(cfg, al)))
            cel("P6.1", f"{nom}/max", A_au_plus(p["max"], R, *p0(cfg, "max")))
            cel("P6.1", f"{nom}/autocorr", A_au_dessus(p["autocorr"], R, *p0(cfg, "autocorr")))
        else:
            if gauss:
                for al in ("somme", "e_unilat_ville"):
                    cel("P6.2", f"{nom}/{al}", A_en_dessous(p[al], R, *p0(cfg, al)))
            cel("P6.2", f"{nom}/autocorr_abs", A_au_dessus(p["autocorr_abs"], R, *p0(cfg, "autocorr_abs")))
        if gauss:
            pth = fc_variance(v_ar1(phi, int(loi["T"])))
            valeurs_fc[f"P6.3/{nom}"] = pth
            cel("P6.3", f"{nom}/somme", A_forme_close(p["somme"], R, pth), fc=pth, p=p["somme"])
    elif c["role"] == "equicorrelation":
        cc, N = float(loi["c"]), int(loi["N"])
        pth = fc_variance(1 + (N - 1) * cc)
        valeurs_fc[f"P6.4/{nom}"] = pth
        cel("P6.4", f"{nom}/somme=théorie", A_forme_close(p["somme"], R, pth), fc=pth, p=p["somme"])
        for al in ("somme", "e_unilat_ville", "co_elevation_N", "correlation_agents"):
            cel("P6.4", f"{nom}/{al}", A_au_dessus(p[al], R, *p0(cfg, al)))
        cel("P6.4", f"{nom}/max", A_au_plus(p["max"], R, *p0(cfg, "max")))
    elif c["role"] == "construction_2606":
        T = int(loi["T"])
        pth = fc_variance(v_ar1(float(loi["phi"]), T) / v_ar1(phi0_2606, T))
        valeurs_fc[f"P6.5/{nom}"] = pth
        cel("P6.5", f"{nom}/somme=théorie", A_forme_close(p["somme"], R, pth), fc=pth, p=p["somme"])
        cel("P6.5", f"{nom}/max", A_au_plus(p["max"], R, *p0(cfg, "max")))
        cel("P6.5", f"{nom}/autocorr", A_au_dessus(p["autocorr"], R, *p0(cfg, "autocorr")))

# --- P7 ---
t = charge("bloc-P7")
R, cfg = t["R"], t["cfg"]
for arr, c in t["arrangements"].items():
    cel("P7.1", arr, A_traj(c["viol_inclusion_haute"] + c["viol_inclusion_basse"] + c["viol_sommes_partielles"]),
        "trajectoriel")
    for al in ("page", "glissante_10"):
        cel("P7.3", f"{arr}/{al}", A_au_dessus(c["alarmes"][al] / R, R, *p0(cfg, al)))
c = t["arrangements"]["tri_croissant"]
cel("P7.2", "tri_croissant/e_bilat_ville", A_au_moins_099(c["alarmes"]["e_bilat_ville"] / R, R))

# --- P8 (ensembles relus dans le texte du préenregistrement, l. 204-215) ---
bien = ["1x200_gauss", "1x1000_gauss", "5x40_gauss"]
signe = {"1x200_sigma0.8": "1x200_gauss", "1x200_sigma0.9": "1x200_gauss",
         "1x200_tau0.05": "1x200_gauss", "1x200_tau0.1": "1x200_gauss", "1x200_tau0.2": "1x200_gauss",
         "1x1000_tau0.05": "1x1000_gauss", "1x1000_tau0.1": "1x1000_gauss", "1x1000_tau0.2": "1x1000_gauss",
         "1x200_ar0.2": "1x200_gauss", "5x40_equi0.2": "5x40_gauss", "5x40_equi0.4": "5x40_gauss"}
depasse = ["1x200_tau0.2", "1x1000_tau0.2", "5x40_equi0.4", "1x200_sigma0.8"]
P8 = charge("bloc-P8")["reglages"]
parnom = {s["nom"]: s for s in P8}
taux_conf = {}
taux_ville = {}
se_conf = []
th_conf = 1 - math.ceil((1000 + 1) * (1 - ALPHA)) / (1000 + 1)
for s in P8:
    R, p = s["R"], s["alarmes"]["e_unilat_ville"] / s["R"]
    taux_ville[s["nom"]] = p
    if s["nom"] in bien:
        cel("P8.1", s["nom"], A_au_plus_alpha(p, R))
    if s["nom"] in signe:
        ref = parnom[signe[s["nom"]]]
        cel("P8.2", f"{s['nom']}>{ref['nom']}", A_au_dessus(p, R, ref["alarmes"]["e_unilat_ville"] / ref["R"], ref["R"]))
    if s["nom"] in depasse:
        cel("P8.3", s["nom"], A_depasse_alpha(p, R))
    c = s["conforme"]
    assert c["K"] == 1000 and c["L"] == 50 and c["n_test"] == 400
    for st, liste in c["alarmes_par_tirage"].items():
        assert len(liste) == 50
        x = np.array(liste, float) / c["n_test"]
        se = max(float(x.std(ddof=1)) / math.sqrt(50), math.sqrt(ALPHA * (1 - ALPHA) / (50 * 400)))
        d = float(x.mean()) - th_conf
        taux_conf[f"{s['nom']}/{st}"] = float(x.mean())
        se_conf.append(se)
        cel("P8.4", f"{s['nom']}/{st}", (("conforme" if abs(d) <= Z * se else "contraire"), d / se), eg=True,
            crit="taux conforme")

# --- comparaison à la lecture scellée ---
lec = json.loads((D / "lecture.json").read_text(encoding="utf-8"))["resultat"]["lecture"]
ecarts = []
nb_lec = 0
for pred, x in lec["predictions"].items():
    for c in x["cellules"]:
        nb_lec += 1
        k = (pred, c["nom"])
        if k not in cellules:
            ecarts.append(("absente du recalcul", pred, c["nom"]))
            continue
        mine = cellules[k]
        if mine["etat"] != c["etat"]:
            ecarts.append(("état différent", pred, c["nom"], mine["etat"], c["etat"]))
        if c["z"] is not None and mine["z"] is not None and abs(round(mine["z"], 3) - c["z"]) > 0.0015:
            ecarts.append(("z différent", pred, c["nom"], mine["z"], c["z"]))
        if c["genre"] != mine["genre"]:
            ecarts.append(("genre différent", pred, c["nom"], mine["genre"], c["genre"]))
for k in cellules:
    if not any(k == (p, c["nom"]) for p, x in lec["predictions"].items() for c in x["cellules"]):
        ecarts.append(("absente de la lecture", *k))


def verdict(etats):
    if any(e == "contraire" for e in etats):
        return "réfutée"
    return "confirmée" if etats and all(e == "conforme" for e in etats) else "non concluante"


preds = sorted({p for p, _ in cellules}, key=lambda s: (int(s[1]), int(s.split(".")[1])))
par_pred = {}
for p in preds:
    cs = [v for (pp, _), v in cellules.items() if pp == p]
    zs = [abs(v["z"]) for v in cs if v["z"] is not None]
    signes = [v["z"] for v in cs if v["z"] is not None]
    par_pred[p] = {"n": len(cs), "conformes": sum(v["etat"] == "conforme" for v in cs),
                   "contraires": sum(v["etat"] == "contraire" for v in cs),
                   "non_concluants": sum(v["etat"] == "non concluant" for v in cs),
                   "genre": sorted({v["genre"] for v in cs}),
                   "verdict": verdict([v["etat"] for v in cs]),
                   "verdict_lecture": lec["predictions"][p]["verdict"],
                   "z_min": min(signes) if signes else None, "z_max": max(signes) if signes else None}

marges = {}
for (p_, nom_), v_ in cellules.items():
    k_ = f"{p_} | {v_['critere']}"
    m_ = marges.setdefault(k_, {"n": 0, "z_min": None, "z_max": None, "etats": {}})
    m_["n"] += 1
    m_["etats"][v_["etat"]] = m_["etats"].get(v_["etat"], 0) + 1
    if v_["z"] is not None:
        m_["z_min"] = v_["z"] if m_["z_min"] is None else min(m_["z_min"], v_["z"])
        m_["z_max"] = v_["z"] if m_["z_max"] is None else max(m_["z_max"], v_["z"])
zf, ze = np.array(z_fc), np.array(z_eg)


def sous_ensembles(z, lab):
    out = {}
    for p_ in sorted(set(lab), key=lambda s_: (int(s_[1]), int(s_.split(".")[1]))):
        v_ = np.array([zz for zz, ll in zip(z, lab) if ll == p_])
        out[p_] = {"n": int(v_.size), "variance": float(v_.var(ddof=1)) if v_.size > 1 else None,
                   "moyenne": float(v_.mean()), "max_abs": float(np.abs(v_).max())}
    return out


# valeurs imprimées dans le préenregistrement (l. 88, 91-97, 105-114, 129, 145, 177, 179, 187)
IMPRIMEES = {
    "P1.2/1x200/B10": 0.1742, "P1.2/1x200/B20": 0.4088, "P1.2/1x200/B30": 0.6831,
    "P1.3/1x50/B10": 0.4088, "P1.3/1x50/B20": 0.8817, "P1.3/1x50/B30": 0.9953,
    "P1.3/1x100/B10": 0.2595, "P1.3/1x100/B20": 0.6388, "P1.3/1x100/B30": 0.9123,
    "P1.3/1x200/B10": 0.1742, "P1.3/1x200/B20": 0.4088, "P1.3/1x200/B30": 0.6831,
    "P1.3/1x500/B10": 0.1155, "P1.3/1x500/B20": 0.2265, "P1.3/1x500/B30": 0.3809,
    "P1.3/1x1000/B10": 0.0920, "P1.3/1x1000/B20": 0.1557, "P1.3/1x1000/B30": 0.2432,
    "P3.3/1x200/B15": 0.0441, "P3.3/1x200/B25": 0.1591, "P3.3/1x200/B35": 0.3855,
    "P6.3/ar_gauss_phi-0.50": 0.00226, "P6.3/ar_gauss_phi-0.25": 0.01697,
    "P6.3/ar_gauss_phi+0.25": 0.10101, "P6.3/ar_gauss_phi+0.50": 0.17034,
    "P6.4/equi_c0.2": 0.1101, "P6.4/equi_c0.4": 0.1538,
    "P6.5/construction_2606_phi0.59": 0.07383, "P6.5/construction_2606_phi0.725": 0.12697,
    "P6.5/construction_2606_phi0.9": 0.25376,
}
for m_, t_ in {1: (1.0, 1.0, 1.0), 2: (0.9962, 1.0, 1.0), 5: (0.3391, 0.9977, 1.0), 10: (0.1093, 0.5403, 0.9792),
               20: (0.0728, 0.1649, 0.4149), 50: (0.0629, 0.0873, 0.1306), 100: (0.0608, 0.0757, 0.0959),
               200: (0.0599, 0.0714, 0.0849)}.items():
    for B_, v_ in zip((10, 20, 30), t_):
        IMPRIMEES[f"P2.1/B{B_}/m{m_}"] = v_
comparaison_imprimees = {}
for k_, v_ in IMPRIMEES.items():
    nd = len(repr(v_).split(".")[1])
    nd = 4 if v_ in (1.0,) else nd
    comparaison_imprimees[k_] = {"imprime": v_, "recalcul": valeurs_fc[k_],
                                 "egal_a_la_precision_imprimee": round(valeurs_fc[k_], nd) == round(v_, nd)}
res = {
    "nb_cellules_recalcul": len(cellules), "nb_cellules_lecture": nb_lec,
    "statistiques": sum(v["genre"] == "statistique" for v in cellules.values()),
    "trajectorielles": sum(v["genre"] == "trajectoriel" for v in cellules.values()),
    "contraires": sum(v["etat"] == "contraire" for v in cellules.values()),
    "non_concluants": sum(v["etat"] == "non concluant" for v in cellules.values()),
    "ecarts_avec_lecture": ecarts,
    "audit": {"formes_closes": {"n": int(zf.size), "variance": float(zf.var(ddof=1)), "moyenne": float(zf.mean())},
              "egalites": {"n": int(ze.size), "variance": float(ze.var(ddof=1)), "moyenne": float(ze.mean())},
              "lecture": lec["audit_symetrie"]},
    "rho_200": rho200, "s_200": s200, "c_200": fc_max(200, 10, 1)[1], "c_200_run": cn_run,
    "seuil_dispersion_run": seuil43, "chi2_3_quantile": float(stats.chi2.isf(ALPHA, 3)),
    "taux_conforme_theorique": th_conf,
    "valeurs_fc": valeurs_fc,
    "predictions": par_pred,
    "p53_appariement": p53_appariement,
    "marges_par_prediction_et_critere": marges,
    "taux_ville_P8": taux_ville,
    "taux_conforme_P8": taux_conf,
    "audit_sous_ensembles": {"formes_closes": sous_ensembles(z_fc, z_fc_lab),
                             "egalites": sous_ensembles(z_eg, z_eg_lab)},
    "P84_ecart_type_min_max": [min(se_conf), max(se_conf)],
    "valeurs_imprimees": {"n": len(comparaison_imprimees),
                          "egales": sum(v["egal_a_la_precision_imprimee"] for v in comparaison_imprimees.values()),
                          "detail": comparaison_imprimees},
}
SORTIE.write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
print(json.dumps({k: res[k] for k in ("nb_cellules_recalcul", "nb_cellules_lecture", "statistiques", "trajectorielles",
                                      "contraires", "non_concluants", "audit", "rho_200", "s_200", "c_200", "c_200_run",
                                      "seuil_dispersion_run", "chi2_3_quantile", "taux_conforme_theorique")},
                 ensure_ascii=False, indent=1))
print("valeurs imprimées égales :", res["valeurs_imprimees"]["egales"], "sur", res["valeurs_imprimees"]["n"])
print("écarts avec la lecture :", len(ecarts))
for e in ecarts[:40]:
    print("  ", e)
