"""Vérifications du run décisif de T0.3, indépendantes du code du programme (lecteur du verdict, R13).

1. Graines (R9) : chaque graine du manifeste est reconstruite depuis l'entropie de la grille scellée et la clé
   « 64 premiers bits de sha256(nom) » (préenregistrement, l. 283-284) ; état de contrôle recalculé.
2. Rattachement : chaque fichier de diag/<run>/ porte l'empreinte du manifeste.
3. Garde de calibrage sous P₀ (liste d'arrêt, point 6) recalculée sur calibrage.json.
4. Garde d'équivalence (point 7) relue sur equivalence.json.
5. Égalités au seuil et écart maximal de P1.1.

Usage : python -I verifs_run_t03.py <racine> <sortie.json>
"""
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np

RACINE = Path(sys.argv[1]); SORTIE = Path(sys.argv[2])
RUN = "20261004-080257-t03"
D = RACINE / "diag" / RUN
man_txt = (RACINE / "runs" / RUN / "manifeste.json").read_bytes()
man = json.loads(man_txt)
sha_man = hashlib.sha256(man_txt).hexdigest()
grille = json.loads((RACINE / "prereg" / "T0.3-grille-v2.json").read_text(encoding="utf-8"))
sortie = {"sha_manifeste": sha_man}

# 1. graines
ent = int(grille["entropie"])
mauvaises, entropies = [], set()
for nom, g in man["graines"].items():
    cle = int.from_bytes(hashlib.sha256(nom.encode("utf-8")).digest()[:8], "big")
    entropies.add(g["entropie"])
    ss = np.random.SeedSequence(ent, spawn_key=(cle,))
    if g["spawn_key"] != [str(cle)] or [int(x) for x in ss.generate_state(2)] != g["etat_controle"]:
        mauvaises.append(nom)
sortie["graines"] = {"n": len(man["graines"]), "principales": sum(not k.endswith("/replication") for k in man["graines"]),
                     "replication": sum(k.endswith("/replication") for k in man["graines"]),
                     "mauvaises": mauvaises, "entropies": sorted(entropies), "entropie_grille": str(ent)}

# 2. rattachement des résultats au manifeste
ratt = {}
for f in sorted(D.glob("*.json")):
    corps = json.loads(f.read_text(encoding="utf-8"))
    ratt[f.name] = (corps.get("manifeste_sha256") == sha_man, corps.get("run_id") == RUN)
sortie["rattachement"] = {k: v for k, v in ratt.items()}
sortie["rattachement_tous_ok"] = all(a and b for a, b in ratt.values())

# 3. garde de calibrage sous P₀
alpha = float(grille["alpha"])
cal = json.loads((D / "calibrage.json").read_text(encoding="utf-8"))["resultat"]["configs"]
garde = []
for cfg, c in cal.items():
    if not c["garde"]:
        continue
    R0, Rc = c["R0"], c["R_cal"]
    for st, k in c["alarmes_p0"].items():
        if st in c.get("garde_exclus", []):
            continue
        p = k / R0
        genre = c["genres"][st]
        seuil = c["seuils"][st]
        if not math.isfinite(seuil):
            garde.append((cfg, st, "seuil non fini")); continue
        if genre == "exact":
            ok = abs(p - alpha) <= 4 * math.sqrt(alpha * (1 - alpha) / R0)
            ec = (p - alpha) / math.sqrt(alpha * (1 - alpha) / R0)
        elif genre == "ville":
            ok = p <= alpha + 4 * math.sqrt(alpha * (1 - alpha) / R0)
            ec = (p - alpha) / math.sqrt(alpha * (1 - alpha) / R0)
        elif genre == "mc_discret":   # liste d'arrêt, point 6 : unilatéral
            s = math.sqrt(alpha * (1 - alpha) * (1 / R0 + 1 / Rc))
            ok = p <= alpha + 4 * s
            ec = (p - alpha) / s
        elif genre == "mc":           # Monte-Carlo continu : bilatéral
            s = math.sqrt(alpha * (1 - alpha) * (1 / R0 + 1 / Rc))
            ok = abs(p - alpha) <= 4 * s
            ec = (p - alpha) / s
        else:
            garde.append((cfg, st, "genre inconnu " + genre)); continue
        garde.append((cfg, st, genre, round(p, 5), round(ec, 2), ok))
sortie["garde_calibrage"] = garde
sortie["garde_calibrage_echecs"] = [g for g in garde if g[-1] is not True]
sortie["garde_calibrage_ecart_reduit_max_abs"] = max(abs(g[4]) for g in garde if len(g) == 6)

# 4. garde d'équivalence
eq = json.loads((D / "equivalence.json").read_text(encoding="utf-8"))["resultat"]
sortie["equivalence_max"] = max(e for x in eq.values() for e in x["ecart_relatif_max"].values())
sortie["equivalence_n_episodes"] = sorted({x["n_episodes"] for x in eq.values()})

# 5. P1.1 : égalités au seuil, écart max
p1 = json.loads((D / "bloc-P1a.json").read_text(encoding="utf-8"))["resultat"]["groupes"]
sortie["P1a_egalites"] = [(g["N"], g["T"], g["B"], g["egalites_somme"], g["egalites_eterm"]) for g in p1]
sortie["P1a_ecart_max"] = max(c["ecart_max"] for g in p1 for c in g["cellules"])
sortie["P1a_discordances"] = sum(c["disc_somme"] + c["disc_eterm"] for g in p1 for c in g["cellules"])

# 6. journal (durées), configuration
lec = json.loads((D / "lecture.json").read_text(encoding="utf-8"))["resultat"]
sortie["journal_s"] = lec["journal_s"]
sortie["manifeste"] = {k: man[k] for k in ("commande", "commit", "cree_le", "decisif", "depot_propre", "preenregistrement",
                                           "reserves", "versions")}
sortie["manifeste"]["commit_cite"] = man["config"]["commit_cite"]
sortie["manifeste"]["grille_sha256"] = man["config"]["grille_sha256"]
sortie["manifeste"]["blocs"] = man["config"]["blocs"]
sortie["manifeste"]["replication_de"] = man["config"]["replication_de"]
sortie["grille_identique_a_celle_du_manifeste"] = (man["config"]["grille"] == grille)
SORTIE.write_text(json.dumps(sortie, ensure_ascii=False, indent=1), encoding="utf-8")
s = dict(sortie); s.pop("garde_calibrage"); s.pop("rattachement")
print(json.dumps(s, ensure_ascii=False, indent=1))
