"""Recalcul indépendant, sur processeur, de la lecture du run A 20261005-102042-validation-reelle (T0.4).

Juge neuf (R13). Lecture seule du clone `depot/` ; code du commit cité extrait dans `arbre-3a7b5e0/`.
Aucune dépendance au code de lecture du run pour les agrégats : tout est recompté depuis les profils par action
et les trajectoires scellées.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import sys
from pathlib import Path

ICI = Path(__file__).resolve().parent
DEPOT = ICI / "depot"
RUN = "20261005-102042-validation-reelle"
DIAG = DEPOT / "diag" / RUN
MANIF = DEPOT / "runs" / RUN / "manifeste.json"

sortie: dict = {}


def charger(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


# ------------------------------------------------------------------ 1. intégrité et conformité
sys.path.insert(0, str(ICI / "arbre-3a7b5e0" / "src"))
from controle_ia.manifeste import config_canonique, graines, verifier_resultat, lire_manifeste  # noqa: E402
from controle_ia.harnais.validation_reelle import CONFIG_REELLE, taches, lire, tests_conformes  # noqa: E402
import controle_ia  # noqa: E402

assert str(ICI / "arbre-3a7b5e0" / "src") in controle_ia.__file__, controle_ia.__file__

m, sha_m = lire_manifeste(MANIF)
integrite = {"manifeste_sha256": sha_m}
chaine = {}
for f in sorted(DIAG.glob("*.json")):
    corps = verifier_resultat(DEPOT, f)
    chaine[f.name] = {"sha256": sha(f), "rattache_au_manifeste": corps["manifeste_sha256"] == sha_m}
integrite["chaine_resultats"] = chaine

prereg = DEPOT / "prereg" / "T0.4-validation-modele-reel-v1.md"
texte_prereg = prereg.read_text(encoding="utf-8")
revision_citee = re.search(r"Révision du modèle : `([0-9a-f]{40})`", texte_prereg).group(1)
entropie_citee = int(re.search(r"Entropie : `([0-9]+)`", texte_prereg).group(1))
commit_cite = re.search(r"Commit du code d'analyse : `([0-9a-f]{40})`", texte_prereg).group(1)

config_attendue = dict(CONFIG_REELLE, revision=revision_citee)
integrite.update({
    "commit_manifeste": m["commit"],
    "commit_cite_prereg": commit_cite,
    "revision_manifeste": m["config"].get("revision"),
    "revision_citee": revision_citee,
    "revision_conforme": m["config"].get("revision") == revision_citee == "0e9e39f249a16976918f6564b8830bc894c89659",
    "prereg_manifeste": m["preenregistrement"],
    "prereg_sha256_disque": sha(prereg),
    "config_egale_CONFIG_REELLE_plus_revision": m["config"] == config_attendue,
    "config_sha256_recalculee": hashlib.sha256(config_canonique(config_attendue)).hexdigest(),
    "config_sha256_manifeste": m["config_sha256"],
    "decisif": m["decisif"], "depot_propre": m["depot_propre"], "reserves": m["reserves"],
    "versions": m["versions"],
})
# graines : toutes à l'entropie citée, et recalculées à l'identique pour la liste des tâches de la configuration
entropies = {g["entropie"] for g in m["graines"].values()}
g_recalc = graines(taches(config_attendue), entropie_citee)
integrite["graines"] = {"entropies_distinctes": sorted(entropies), "entropie_citee": str(entropie_citee),
                        "nombre_taches": len(m["graines"]), "identiques_au_recalcul": g_recalc == m["graines"]}
sortie["integrite"] = integrite

# ------------------------------------------------------------------ 2. arret.json : résumé partiel
arret = charger(DIAG / "arret.json")["resultat"]
partiel = arret["partiel"]
L = partiel["logique"]
eq_code = L["equivalence"]
TOL = config_attendue["logique"]["tolerance"]
CN = config_attendue["controle_negatif"]
ECH = config_attendue["logique"]["episodes_equivalence"]


def nan_inf(x):
    return float("inf") if (x is None or x != x) else x


actions = []      # une entrée par action comparée
for e in L["episodes"]:
    r = e["equivalence"]
    for cle in r["ecarts"]:
        prof = r["profils"][cle]
        par_couche = {}
        for c, p in prof.items():
            par_couche[c] = {
                "ctx_max": p["contexte"].get("max"), "ctx_jetons": p["contexte"]["jetons"],
                "ctx_q50": p["contexte"].get("q50"), "ctx_q99": p["contexte"].get("q99"),
                "ctx_nuls": p["contexte"].get("nuls", 0),
                "gen_max": p["generee"].get("max"), "gen_jetons": p["generee"]["jetons"],
                "gen_q50": p["generee"].get("q50"), "gen_q99": p["generee"].get("q99"),
                "gen_nuls": p["generee"].get("nuls", 0),
                "tout_max": p.get("max"), "ecart_garde": r["ecarts"][cle][c],
                "neg": r["controle_negatif_zone_generee"][cle][c] if r["controle_negatif_zone_generee"][cle] else None,
            }
        actions.append({"episode": e["episode"], "cle": cle, "lc": r["longueurs_contexte"][cle],
                        "capturees": r["positions_capturees"][cle], "ligne": r["lignes"][cle],
                        "sonde": r["sondes"][cle], "couches": par_couche})

# cohérence interne : écart de la garde = max(profil complet) = max(contexte, zone générée)
incoherences = []
for a in actions:
    for c, v in a["couches"].items():
        mx = max(nan_inf(v["ctx_max"]) if v["ctx_jetons"] else -1, nan_inf(v["gen_max"]) if v["gen_jetons"] else -1)
        if not (v["ecart_garde"] == v["tout_max"] == mx):
            incoherences.append((a["episode"], a["cle"], c, v["ecart_garde"], v["tout_max"], mx))
        if v["ctx_jetons"] != a["lc"] or v["ctx_jetons"] + v["gen_jetons"] != a["capturees"]:
            incoherences.append((a["episode"], a["cle"], c, "jetons", v["ctx_jetons"], v["gen_jetons"], a["capturees"]))

ecarts = [v["ecart_garde"] for a in actions for v in a["couches"].values()]
max_ctx = max(nan_inf(v["ctx_max"]) for a in actions for v in a["couches"].values() if v["ctx_jetons"])
max_gen = max(nan_inf(v["gen_max"]) for a in actions for v in a["couches"].values() if v["gen_jetons"])
ecart_max = max(nan_inf(x) for x in ecarts)
p2 = {
    "episodes_compares": sorted({a["episode"] for a in actions}), "actions_comparees": len(actions),
    "ecart_max": ecart_max, "max_contexte": max_ctx, "max_zone_generee": max_gen,
    "rapport_des_maxima": max(max_ctx, max_gen) / min(max_ctx, max_gen),
    "regle_diffus": {"ecart<=1e-2": ecart_max <= 1e-2, "max_ctx>=1e-5": max_ctx >= 1e-5,
                     "max_gen>=1e-5": max_gen >= 1e-5,
                     "rapport<=3": max(max_ctx, max_gen) <= 3 * min(max_ctx, max_gen)},
    "egal_au_bilan_du_code": {"ecart_max": ecart_max == eq_code["ecart_max"],
                              "max_contexte": max_ctx == eq_code["max_contexte"],
                              "max_zone_generee": max_gen == eq_code["max_zone_generee"]},
    "incoherences_internes": incoherences,
}
# actions au-dessus du seuil, par couche et par zone
au_dessus = []
for a in actions:
    for c, v in a["couches"].items():
        if not v["ecart_garde"] <= TOL:
            zone = "contexte" if nan_inf(v["ctx_max"]) >= nan_inf(v["gen_max"]) else "zone générée"
            au_dessus.append({"episode": a["episode"], "action": a["cle"], "couche": c, "ecart": v["ecart_garde"],
                              "zone_du_max": zone, "ctx_max": v["ctx_max"], "gen_max": v["gen_max"],
                              "remplissage": a["ligne"]["remplissage"], "lc": a["lc"]})
p2["au_dessus_du_seuil"] = au_dessus
# où se trouve le maximum de la zone générée
p2["max_zone_generee_ou"] = [(a["episode"], a["cle"], c) for a in actions for c, v in a["couches"].items()
                             if v["gen_jetons"] and v["gen_max"] == max_gen]
p2["max_contexte_ou"] = [(a["episode"], a["cle"], c) for a in actions for c, v in a["couches"].items()
                         if v["ctx_jetons"] and v["ctx_max"] == max_ctx]
# par couche
par_couche = {}
for c in ("7", "15", "23"):
    par_couche[c] = {
        "max_ctx": max(a["couches"][c]["ctx_max"] for a in actions),
        "max_gen": max(a["couches"][c]["gen_max"] for a in actions),
        "max_q50_ctx": max(a["couches"][c]["ctx_q50"] for a in actions),
        "max_q50_gen": max(a["couches"][c]["gen_q50"] for a in actions),
        "med_des_q50_ctx": sorted(a["couches"][c]["ctx_q50"] for a in actions)[len(actions) // 2],
        "med_des_q50_gen": sorted(a["couches"][c]["gen_q50"] for a in actions)[len(actions) // 2],
        "actions_gen_max_sup_ctx_max": sum(a["couches"][c]["gen_max"] > a["couches"][c]["ctx_max"] for a in actions),
        "actions_au_dessus_1e-4": sum(not a["couches"][c]["ecart_garde"] <= TOL for a in actions),
        "actions_au_dessus_5e-5": sum(a["couches"][c]["ecart_garde"] > 5e-5 for a in actions),
    }
p2["par_couche"] = par_couche

# couverture (sur les seules actions comparées)
couv = {"actions_remplies": sum(a["ligne"]["remplissage"] > 0 for a in actions),
        "actions_finies_avant": sum(bool(a["ligne"]["finie_avant"]) for a in actions),
        "positions_generees_comparees": sum(a["capturees"] - a["lc"] for a in actions),
        "lignes_echantillon": sorted({a["ligne"]["ligne"] for a in actions}),
        "taille_lot": sorted({a["ligne"]["taille_lot"] for a in actions})}
couv["satisfaite"] = (couv["actions_remplies"] > 0 and couv["actions_finies_avant"] > 0
                      and couv["positions_generees_comparees"] > 0 and any(x != 0 for x in couv["lignes_echantillon"]))
couv["egale_au_bilan_du_code"] = {k: couv[k] == eq_code["couverture"][k] for k in eq_code["couverture"]}
p2["couverture"] = couv
p2["domaine"] = {"contexte_max": max(a["lc"] for a in actions),
                 "generes_relus_max": max(a["capturees"] - a["lc"] for a in actions),
                 "taille_lot": max(a["ligne"]["taille_lot"] for a in actions)}
sortie["P2"] = p2

# P3 : contrôle négatif de phase
comparables = passent = courtes = 0
echecs, minimum = [], float("inf")
for a in actions:
    zone = {c: v["neg"] for c, v in a["couches"].items()}
    if any(z is None for z in zone.values()) or min(z["positions"] for z in zone.values()) < CN["positions_min"]:
        courtes += 1
        continue
    comparables += 1
    mm = min(float("-inf") if z["max"] != z["max"] else z["max"] for z in zone.values())
    minimum = min(minimum, mm)
    if mm > TOL:
        passent += 1
    else:
        echecs.append(f"{a['episode']}:{a['cle']}")
p3 = {"comparables": comparables, "passent": passent, "courtes": courtes, "echecs": echecs,
      "fraction": passent / comparables if comparables else None, "min_des_maxima": minimum,
      "positions_decalees_par_action_min": min(min(v["neg"]["positions"] for v in a["couches"].values()) for a in actions),
      "positions_au_dessus_du_seuil_toutes": all(v["neg"]["au_dessus"] == v["neg"]["positions"]
                                                 for a in actions for v in a["couches"].values())}
p3["egal_au_bilan_du_code"] = {k: p3[k] == eq_code["controle_negatif"][k]
                               for k in ("comparables", "passent", "courtes", "echecs", "fraction", "min_des_maxima")}
sortie["P3"] = p3

# P9 : zéros par couche et par zone
zeros = {c: {"contexte": [sum(a["couches"][c]["ctx_nuls"] for a in actions), sum(a["couches"][c]["ctx_jetons"] for a in actions)],
             "generee": [sum(a["couches"][c]["gen_nuls"] for a in actions), sum(a["couches"][c]["gen_jetons"] for a in actions)]}
         for c in ("7", "15", "23")}
sortie["P9"] = {"zeros": zeros, "egal_au_bilan_du_code": zeros == eq_code["zeros"],
                "declenche_logique": all(z["generee"][0] == z["generee"][1] for z in zeros.values()),
                "nuls_ctx_par_action": {f"{a['episode']}:{a['cle']}": [a["couches"][c]["ctx_nuls"] for c in ("7", "15", "23")]
                                        for a in actions if any(a["couches"][c]["ctx_nuls"] for c in ("7", "15", "23"))}}
sortie["sondes_audit"] = {"tableaux_distincts": all(a["sonde"]["tableaux_distincts"] for a in actions),
                          "ulp_vu": all(a["sonde"]["ulp_vu"] for a in actions)}

# ------------------------------------------------------------------ 3. alignement : trajectoires scellées
traj = {}
for k in range(8):
    f = DIAG / f"logique-episode-{k}-trajectoire.json"
    traj[k] = charger(f)["resultat"]
# empreinte de trajectoire = celle du résumé partiel (même calcul que empreinte_episode)
emp_traj = {}
for e in L["episodes"]:
    k = int(e["episode"].split("-")[1])
    h = hashlib.sha256(json.dumps(traj[k], sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()
    emp_traj[e["episode"]] = h == e["empreintes"]["trajectoire"]
alignement = {"empreintes_trajectoires_egales_au_resume": emp_traj}

FINS = set(partiel["format"]["fins"])
MAXN = config_attendue["logique"]["max_nouveaux"]
N, T = config_attendue["logique"]["N"], config_attendue["logique"]["T"]
act = {}   # (k, i, t) -> action
problemes = []
for k, ep in traj.items():
    for tr in ep["transcriptions"]:
        ids = tr["ids"]
        prec_fin = 0
        for a in tr["actions"]:
            act[(k, a["agent"], a["pas"])] = a
            if ids[a["debut"]:a["fin"]] != a["ids"]:
                problemes.append(("empan", k, a["agent"], a["pas"]))
            if a["debut"] < prec_fin:
                problemes.append(("ordre", k, a["agent"], a["pas"]))
            n = len(a["ids"])
            if not (1 <= n <= MAXN) or not (a["ids"][-1] in FINS or n == MAXN):
                problemes.append(("fin", k, a["agent"], a["pas"], n, a["ids"][-1]))
            if any(x in FINS for x in a["ids"][:-1]):
                problemes.append(("fin interne", k, a["agent"], a["pas"]))
            prec_fin = a["fin"]
alignement["problemes_trajectoires"] = problemes
# contexte commun : à t = 0, agent 0, même ouverture pour tous les épisodes
ouv = {tuple(traj[k]["transcriptions"][0]["ids"][:act[(k, 0, 0)]["debut"]]) for k in range(8)}
alignement["ouverture_identique_agent0_pas0"] = len(ouv) == 1

# plan recalculé par pas : remplissage, fin avant les autres, passes, positions capturées
ecarts_plan = []
for a in actions:
    k = int(a["episode"].split("-")[1])
    i, t = (int(x) for x in a["cle"].split(","))
    debuts = {kk: act[(kk, i, t)]["debut"] for kk in range(8)}
    longueurs = {kk: len(act[(kk, i, t)]["ids"]) for kk in range(8)}
    Lp = max(debuts.values())
    n_max = max(longueurs.values())
    passes = min(n_max, MAXN) - 1
    attendu = {"lc": debuts[k], "remplissage": Lp - debuts[k], "finie_avant": longueurs[k] < n_max,
               "capturees": debuts[k] + min(passes, longueurs[k]), "ligne": k, "taille_lot": 8,
               "neg_positions": debuts[k] + min(passes, longueurs[k]) - debuts[k] - 1}
    observe = {"lc": a["lc"], "remplissage": a["ligne"]["remplissage"], "finie_avant": a["ligne"]["finie_avant"],
               "capturees": a["capturees"], "ligne": a["ligne"]["ligne"], "taille_lot": a["ligne"]["taille_lot"],
               "neg_positions": min(v["neg"]["positions"] for v in a["couches"].values())}
    if attendu != observe:
        ecarts_plan.append({"action": f"{a['episode']}:{a['cle']}", "attendu": attendu, "observe": observe})
alignement["plan_recalcule_depuis_trajectoires"] = {"actions_verifiees": len(actions), "ecarts": ecarts_plan}
# la passe unique couvre-t-elle les positions capturées ? (longueur de la transcription finale ≥ capturées)
alignement["capturees_dans_la_transcription"] = all(
    a["capturees"] <= len(traj[int(a["episode"].split("-")[1])]["transcriptions"][int(a["cle"].split(",")[0])]["ids"])
    for a in actions)
sortie["alignement"] = alignement

# ------------------------------------------------------------------ 4. lecture du code, rejouée sur le partiel
sortie["lecture_rejouee_par_lire"] = lire(partiel, config_attendue)
sortie["lecture_partielle_consignee"] = partiel["lecture_partielle"]
sortie["P0"] = {"derniere_ligne": partiel["tests_instance"]["derniere_ligne"],
                "conforme": tests_conformes(partiel["tests_instance"]["derniere_ligne"], 178)}
ti = charger(DIAG / "tests-instance.json")["resultat"]
sortie["P0"]["sortie_scellee_conforme"] = tests_conformes(ti["sortie"], 178)
sortie["P0"]["sortie_scellee_egale_trace"] = ti["sortie"] == (DEPOT / "traces/t04-20261005-102856-G431/tests.txt").read_text(encoding="utf-8")
sortie["P1"] = {"format_verifie": partiel["format"]["verifie"],
                "date_dans_ouverture": "Today Date: 26 Jul 2024" in partiel["format"]["ouverture"],
                "fichiers_modele_tous_conformes": all(v["conforme"] for v in partiel["fichiers_modele"].values()),
                "fichiers_modele": sorted(partiel["fichiers_modele"]),
                "memoire_carte_gio": partiel["reglages"]["memoire_carte_gio"],
                "memoire_vive_effective_go": partiel["memoire_vive_go"]["effective_go"],
                "type_des_poids": partiel["chargement"]["type_des_poids"],
                "attention": partiel["chargement"]["attention"]}
sortie["reglages"] = partiel["reglages"]
sortie["arret"] = {"phase": arret["phase"], "motif": arret["motif"], "duree_s": arret["duree_s"]}

print(json.dumps(sortie, indent=1, ensure_ascii=False, default=str))
