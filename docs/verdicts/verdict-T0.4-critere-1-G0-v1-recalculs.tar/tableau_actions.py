import json
from pathlib import Path
D = Path("depot/diag/20261005-102042-validation-reelle")
arret = json.loads((D / "arret.json").read_text())["resultat"]["partiel"]["logique"]
traj = {k: json.loads((D / f"logique-episode-{k}-trajectoire.json").read_text())["resultat"] for k in range(8)}
long_tr = {(k, tr["agent"]): len(tr["ids"]) for k in traj for tr in traj[k]["transcriptions"]}
print("longueur des transcriptions finales (passe unique) :", {f"ep{k}/ag{i}": v for (k, i), v in sorted(long_tr.items())})
print()
print(f"{'action':>12} {'lc':>5} {'m':>4} {'remp':>5} {'L':>5} {'fin<':>4} {'passe':>5} | " +
      " | ".join(f"c{c}: ctx_max   gen_max   ctxq50   genq50  nuls" for c in ("7","15","23")))
lignes = []
for e in arret["episodes"]:
    r = e["equivalence"]
    k = int(e["episode"].split("-")[1])
    for cle in sorted(r["ecarts"], key=lambda s: (int(s.split(",")[1]), int(s.split(",")[0]))):
        i, t = map(int, cle.split(","))
        lc = r["longueurs_contexte"][cle]; m = r["positions_capturees"][cle] - lc
        li = r["lignes"][cle]
        prof = r["profils"][cle]
        cells = []
        for c in ("7", "15", "23"):
            p = prof[c]
            cells.append(f"{p['contexte']['max']:.2e} {p['generee']['max']:.2e} {p['contexte']['q50']:.1e} {p['generee']['q50']:.1e} {p['contexte']['nuls']:>4}")
        print(f"ep{k} ({i},{t}) {lc:>5} {m:>4} {li['remplissage']:>5} {lc+li['remplissage']:>5} {str(li['finie_avant'])[0]:>4} {long_tr[(k,i)]:>5} | " + " | ".join(cells))
