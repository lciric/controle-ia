"""Descriptif : lignes de matrice du préremplissage (8 x L) et de la passe unique (longueur de la transcription),
contre les contextes exactement nuls. Hypothèse décrite, non prouvée : choix du noyau de produit matriciel selon la forme."""
import json
from pathlib import Path
D = Path("depot/diag/20261005-102042-validation-reelle")
arret = json.loads((D / "arret.json").read_text())["resultat"]["partiel"]["logique"]
traj = {k: json.loads((D / f"logique-episode-{k}-trajectoire.json").read_text())["resultat"] for k in range(8)}
long_tr = {(k, tr["agent"]): len(tr["ids"]) for k in traj for tr in traj[k]["transcriptions"]}
rows = []
for e in arret["episodes"]:
    r = e["equivalence"]; k = int(e["episode"].split("-")[1])
    for cle in r["ecarts"]:
        i, t = map(int, cle.split(","))
        lc = r["longueurs_contexte"][cle]; L = lc + r["lignes"][cle]["remplissage"]
        nuls = r["profils"][cle]["7"]["contexte"]["nuls"]
        rows.append((8 * L, long_tr[(k, i)], nuls == lc, f"ep{k}({i},{t})", r["lignes"][cle]["remplissage"]))
rows.sort()
print("M_prefill  M_passe  contexte_identique  action  remplissage")
for x in rows:
    if x[0] <= 2400:
        print(x)
# maxima de contexte identiques entre actions successives d'un même agent (préfixe commun)
print()
for e in arret["episodes"]:
    r = e["equivalence"]
    for c in ("15", "23"):
        vals = {}
        for cle in r["ecarts"]:
            v = r["profils"][cle][c]["contexte"]["max"]
            vals.setdefault(v, []).append(cle)
        rep = {f"{v:.6e}": cl for v, cl in vals.items() if len(cl) > 1}
        print(e["episode"], "couche", c, "maxima de contexte partagés :", rep)
