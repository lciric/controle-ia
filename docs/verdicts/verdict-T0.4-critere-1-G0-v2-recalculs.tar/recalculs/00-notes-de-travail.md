# Notes de travail du juge R13 — T0.4 v2, critère 1 de G0

(écrites au fil de l'eau ; reprise possible après redémarrage)

- 1. Clone : depot/ au commit 93840abe50487f3c97003abb92697b8b4895bccf (main). Dépôt de référence non modifié.
- 2. Préenregistrement `prereg/T0.4-validation-modele-reel-v2.md` : sha256 886c8c07c6954a46c666b294c391523f0cdd3d03a5b99dae5079507503de3fb9, égal au compagnon et à l'attendu. Lu en entier (398 lignes).
- 3. Empreintes (01-verifier-empreintes.sortie.txt) : toutes OK. 35 fichiers dans diag, 35 compagnons. Traces g2el (5 fichiers) OK, instance 54332340 (3 fichiers) OK. Scripts d'instance au commit cité = empreintes du prereg.
- 4. Historique : diag/runs du run commités par « instance de calcul (T0.4) » en fe2022f (parent 9767398 = commit de scellement), traces en 6853b26 ; aucun changement depuis jusqu'à HEAD.
- 5. Traces : tests.txt dernière ligne « 192 passed in 28.26s » ; run-A.json vide (pas de résumé) ; run-A.err : ARRÊT production 28 fautes de garde. Journal instance : H200 NVL 143771 MiB, pilote 580.95.05, torch 2.14.1+cu130 ; amorce fin code 1 à 14:52:58 ; puis 16 relances de l'amorce par le conteneur, toutes refusées par R12 (aucun second run).
- 6. Identité du run (02-identite-du-run.sortie.txt) : manifeste 92e16632… ; commit 9767398 (scellement), arbre gelé = dc7aa7f (git diff --quiet 0) ; config_sha256 79f85dc1… recalculé = consigné = CONFIG_REELLE+révision ; 598 graines refaites à l'identique depuis l'entropie citée ; tous les résultats rattachés au manifeste ; décisif, dépôt propre, aucune réserve. arret.json : phase production, durée 385 s.
- 7. Code lu : validation_reelle (executer, lire, bilan_phase, bilan_controle_positif, appliquer_gardes), episode, activations, modeles, politique (relire_et_controler lève GardeArret à toute différence, exiger_identite = array_equal + formes).
- 8. Recalculs (03-recalculs-predictions.sortie.txt / .json) — tous égaux aux bilans consignés, lecture du juge = lecture_partielle = lire() relu :
  - P0 conforme (192 passed in 28.26s ; 192 points ; tests.err vide). P1 conforme (format vérifié, date, 10 fichiers conformes = v1, 139.8 Gio, 550.7 Go, float64, 65 normalisations).
  - P2 conforme : max 9.776e-13 (contexte 9.78e-13, zone générée 9.90e-14 ; couches 7/15/23 : 5.2e-14 / 3.7e-13 / 9.8e-13) ; couverture 28 remplies, 32 finies avant, 1850 positions générées, lignes [1,6].
  - P2b conforme : 20/20 comparables vus, min des maxima 5.74e-2 (couche 23), max contexte 3.09e-13 ; séparation 5.87e10 (10.8 ordres).
  - P3 conforme 40/40 min 1.124. P5 conforme 40/40 min 1.061.
  - P4 CONTRAIRE : max 0.5219 (épisode-1 (1,9) couche 23, contexte) ; 28 actions > 0.1, toutes dans le contexte ; couche 15 : 22, couche 23 : 28, couche 7 : 0 ; zone générée max 0.0763.
  - P6 conforme (8 épisodes, 5 empreintes, captures, logits). P8 conforme par l'ordre du code (16 épisodes, stockage, sha des npz ; motif = équivalence). P7 non atteint (aucun run B). P9 non déclenché (0 zéro en zone générée : 1850 et 1402 non nuls par couche).
  - 26/26 trajectoires de diag/ ont l'empreinte consignée.
- 9. Localisation production (04-localisation-production.sortie.txt) : dépassements tous dans le contexte, couches 15/23 ; 28/40 (épisode 1 : 15/20 ; épisode 14 : 13/20) ; contextes 158 à 1014 ; toutes les actions de contexte > 460 dépassent ; les 2 actions sans remplissage (t=0, agent 0, ctx 68) ont un écart de contexte EXACTEMENT nul (0/0/0) ; q50 contexte 0.0145/0.0180/0.0164 ≈ q50 repère 0.0127/0.0143/0.0128 ; max/q99 (c23) 1.6 à 6.6 ; Spearman contexte–écart 0.82 (logique 0.79). Repère : max 0.094/0.512/0.789 ; production max = 0.72/0.57/0.66 du max du repère.
- 10. Contrôle positif recoupé avec ses trajectoires (05) : 20/20 cohérentes ; lignes 1 et 6 jamais les plus longues (épisodes 3 ou 7), zone générée = n ; ouvertures identiques à la logique, actions différentes (graines propres). Aucune action au plafond de 256 jetons sauf 1 en production (06).
- 11. Tests sur processeur dans le clone : 192 passed (08). verifier-arbre : intact. Code cité empreinté (07).
- 12. Remplissage (09) : logique, avec/sans remplissage même niveau (q50 ~1e-14) ; production, sans remplissage (2 actions, ctx 68) contexte = 0 exact, avec remplissage (38) q50 c23 0.014–0.019 indépendamment de la quantité (3 à 441). Remplissage max : logique 373 / production 441 ; longueur remplie max : 1226 / 1447 ; contrôle positif 628.
- 13. Registres : R-045 (run A arrêté en production à 385 s, pas de run B, instance arrêtée par identifiant 14:55, 0.179 h) ; dépenses : 0,74 h sur 6 (reste 5,26).
- 14. Table : seule la ligne « P4 contraire » s'applique ; P7 non atteint, lu par aucune ligne ; première ligne non applicable → critère 1 non prouvé ; lecture gelée : logique validée (P2, P2b, P3 conformes), écart de demi-précision au-dessus du seuil de production ; suite : réserve et nœud au vu du repère.
- 15. Zéros du contexte en production (10) : 68/68 pour les deux actions sans remplissage ; exactement 3 (couche 7) et 2 (couches 15, 23) pour chacune des 38 actions remplies, quel que soit le remplissage (3 à 441) → total 250/212/212. Positions non connues (profils) ; probablement les premières positions du contexte.
- 16. Rédaction du verdict ensuite.
- 17. Verdict écrit : ../verdict-T0.4-critere-1-G0-v2.md (non prouvé ; ligne « P4 contraire » seule ; P7 non atteint, lu par aucune ligne). 05 complété (627 positions générées par couche, 0 nul) et relancé. Dépôt de référence vérifié intact (statut vide, HEAD 93840ab). Scellement : recalculs.sha256 et compagnon du verdict. Fin.
