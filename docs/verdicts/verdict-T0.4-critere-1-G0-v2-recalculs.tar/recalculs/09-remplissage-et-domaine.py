"""Juge R13, T0.4 v2 — audit R4 de P4 : effet du remplissage à gauche selon la phase ; domaine de remplissage.
Descriptif ; lit 03-recalculs-predictions.json et arret.json."""
import json
from pathlib import Path
ICI = Path(__file__).parent
R = json.loads((ICI / "03-recalculs-predictions.json").read_text(encoding="utf-8"))
D = Path("/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/verdict-t04-v2/depot")
P = json.loads((D / "diag/20261005-144628-validation-reelle/arret.json").read_text(encoding="utf-8"))["resultat"]["partiel"]
for nom, acts in (("logique", R["actions_logique"]), ("production", R["actions_production"])):
    sans = [a for a in acts if a["remplissage"] == 0]
    avec = [a for a in acts if a["remplissage"] > 0]
    def resume(g):
        if not g:
            return "aucune"
        mx = [max(a["max_contexte_par_couche"].values()) for a in g]
        q50 = [a["q50_q99_contexte"]["23"][0] for a in g]
        return (f"{len(g)} actions ; contexte {min(a['contexte'] for a in g)}–{max(a['contexte'] for a in g)} ; "
                f"max du contexte (toutes couches) min/max {min(mx):.3g}/{max(mx):.3g} ; q50 du contexte couche 23 min/max {min(q50):.3g}/{max(q50):.3g}")
    print(f"{nom:10s} sans remplissage : {resume(sans)}")
    print(f"{nom:10s} avec remplissage : {resume(avec)}")
    print(f"{nom:10s} remplissage max des actions comparées : {max(a['remplissage'] for a in acts)} ; "
          f"plus long contexte rempli d'un lot (chrono) : {P[nom]['debit']['longueur_remplie_max']} ; "
          f"jetons de remplissage cumulés : {P[nom]['debit']['jetons_remplissage']}")
    gen_sans = [max(v for v in a["max_generee_par_couche"].values()) for a in sans]
    gen_avec = [max(v for v in a["max_generee_par_couche"].values()) for a in avec]
    print(f"{nom:10s} zone générée : max sans remplissage {max(gen_sans) if gen_sans else None:.3g} ; avec {max(gen_avec):.3g}")
# contrôle positif : domaine
C = P["controle_positif"]
print("contrôle positif : plus long contexte rempli", C["debit"]["longueur_remplie_max"], "; jetons de remplissage", C["debit"]["jetons_remplissage"])
