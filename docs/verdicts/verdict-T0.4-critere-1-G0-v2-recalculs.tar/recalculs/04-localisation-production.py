"""Juge R13, T0.4 v2 — étape d : localisation descriptive des écarts de production (aucun seuil proposé).

Lit la sortie 03-recalculs-predictions.json (actions par phase) et arret.json. Décrit, action par action :
pas, agent, longueur du contexte, remplissage, jetons générés relus, maxima et quantiles par couche et par zone ;
puis des regroupements simples (par pas, par remplissage, par longueur de contexte) et la comparaison au
repère de précision. Descriptif seulement.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

ICI = Path(__file__).parent
R = json.loads((ICI / "03-recalculs-predictions.json").read_text(encoding="utf-8"))
D = Path("/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/verdict-t04-v2/depot")
P = json.loads((D / "diag/20261005-144628-validation-reelle/arret.json").read_text(encoding="utf-8"))["resultat"]["partiel"]
TOL = 0.1

prod = R["actions_production"]
log = R["actions_logique"]
log_par = {(a["episode"], a["action"]): a for a in log}


def ligne(a):
    mc, mg = a["max_contexte_par_couche"], a["max_generee_par_couche"]
    qc = a["q50_q99_contexte"]
    return (f"{a['episode']:>10s} ({a['action']}) t={a['pas']} ag={a['agent']} ctx={a['contexte']:4d} rempl={a['remplissage']:4d} "
            f"rel={a['generes_relus']:3d} fin_av={str(a['finie_avant'])[0]} | ctx max 7/15/23 = "
            f"{mc['7']:.4f}/{mc['15']:.4f}/{mc['23']:.4f} | ctx q50 = {qc['7'][0]:.4f}/{qc['15'][0]:.4f}/{qc['23'][0]:.4f} "
            f"| ctx q99 = {qc['7'][1]:.4f}/{qc['15'][1]:.4f}/{qc['23'][1]:.4f} | gen max = "
            f"{mg['7']:.4f}/{mg['15']:.4f}/{mg['23']:.4f} | {'>0,1' if max(a['max_par_couche'].values()) > TOL else ''}")


print("=" * 60, "Production : les 40 actions comparées (épisodes 1 et 14)")
for a in sorted(prod, key=lambda x: (x["episode"], x["pas"], x["agent"])):
    print(ligne(a))

print("\n" + "=" * 60, "Regroupements (production)")
au = [a for a in prod if max(a["max_par_couche"].values()) > TOL]
sous = [a for a in prod if max(a["max_par_couche"].values()) <= TOL]
print("au-dessus de 0,1 :", len(au), "| sous :", len(sous))
print("pas des actions sous 0,1 :", sorted((a["episode"], a["action"]) for a in sous))
for nom, groupe in (("au-dessus", au), ("sous", sous)):
    ctx = [a["contexte"] for a in groupe]
    rem = [a["remplissage"] for a in groupe]
    print(f"{nom:9s} : contexte min/médian/max = {min(ctx)}/{sorted(ctx)[len(ctx)//2]}/{max(ctx)} ; remplissage min/max = {min(rem)}/{max(rem)} ; "
          f"remplissage nul : {sum(r == 0 for r in rem)}")
print("contexte le plus court au-dessus de 0,1 :", min(a["contexte"] for a in au),
      "| contexte le plus long sous 0,1 :", max(a["contexte"] for a in sous))
# monotonie grossière en fonction du contexte
paires = sorted((a["contexte"], max(a["max_par_couche"].values())) for a in prod)
print("(contexte, écart max) triés par contexte :", [(c, round(e, 3)) for c, e in paires])
# rang de corrélation de Spearman, sans scipy
def rangs(v):
    ordre = sorted(range(len(v)), key=lambda i: v[i])
    r = [0.0] * len(v)
    for k, i in enumerate(ordre):
        r[i] = k + 1.0
    return r
x = rangs([a["contexte"] for a in prod]); y = rangs([max(a["max_par_couche"].values()) for a in prod])
mx, my = sum(x) / len(x), sum(y) / len(y)
rho = sum((a - mx) * (b - my) for a, b in zip(x, y)) / math.sqrt(sum((a - mx) ** 2 for a in x) * sum((b - my) ** 2 for b in y))
print(f"corrélation de rang (Spearman) entre longueur du contexte et écart maximal de l'action, production : {rho:.3f}")
x2 = rangs([a["remplissage"] for a in prod])
mx2 = sum(x2) / len(x2)
rho2 = sum((a - mx2) * (b - my) for a, b in zip(x2, y)) / math.sqrt(sum((a - mx2) ** 2 for a in x2) * sum((b - my) ** 2 for b in y))
print(f"corrélation de rang (Spearman) entre remplissage et écart maximal de l'action, production : {rho2:.3f}")
# rapport max / q99 du contexte : concentration sur quelques positions
rap = [a["max_contexte_par_couche"]["23"] / a["q50_q99_contexte"]["23"][1] for a in au]
print("couche 23, actions au-dessus : rapport max / q99 du contexte, min/médian/max =",
      f"{min(rap):.1f}/{sorted(rap)[len(rap)//2]:.1f}/{max(rap):.1f}")
q99s = sorted(a["q50_q99_contexte"]["23"][1] for a in prod)
q50s = sorted(a["q50_q99_contexte"]["23"][0] for a in prod)
print("couche 23, toutes actions : q99 du contexte min/médian/max =", f"{q99s[0]:.4f}/{q99s[len(q99s)//2]:.4f}/{q99s[-1]:.4f}",
      "| q50 du contexte min/médian/max =", f"{q50s[0]:.4f}/{q50s[len(q50s)//2]:.4f}/{q50s[-1]:.4f}")
for c in ("7", "15", "23"):
    gq50 = sorted(a["q50_q99_generee"][c][0] for a in prod)
    gq99 = sorted(a["q50_q99_generee"][c][1] for a in prod)
    cq50 = sorted(a["q50_q99_contexte"][c][0] for a in prod)
    cq99 = sorted(a["q50_q99_contexte"][c][1] for a in prod)
    print(f"couche {c:>2s} : contexte q50 médian {cq50[len(cq50)//2]:.4f}, q99 médian {cq99[len(cq99)//2]:.4f} | "
          f"zone générée q50 médian {gq50[len(gq50)//2]:.4f}, q99 médian {gq99[len(gq99)//2]:.4f}")

print("\n" + "=" * 60, "Repère de précision (passe unique demi contre double, transcriptions des épisodes 1 et 6 de logique)")
for c, v in P["production"]["repere_precision"].items():
    print(f"couche {c:>2s} : jetons {v['jetons']}, q50 {v['q50']:.4f}, q99 {v['q99']:.4f}, max {v['max']:.4f}")
mp = R["P4"]["max_par_couche"]
rp = P["production"]["repere_precision"]
print("rapport maximum de production / maximum du repère, par couche :",
      {c: round(mp[c] / rp[c]["max"], 3) for c in ("7", "15", "23")})
print("rapport maximum de production / q99 du repère, par couche :",
      {c: round(mp[c] / rp[c]["q99"], 2) for c in ("7", "15", "23")})

print("\n" + "=" * 60, "Logique (double précision) : mêmes regroupements, pour comparaison de forme")
for a in sorted(log, key=lambda x: (x["episode"], x["pas"], x["agent"]))[:6]:
    mc = a["max_contexte_par_couche"]; mg = a["max_generee_par_couche"]
    print(f"{a['episode']:>10s} ({a['action']}) ctx={a['contexte']:4d} rempl={a['remplissage']:4d} ctx max 7/15/23 = "
          f"{mc['7']:.2e}/{mc['15']:.2e}/{mc['23']:.2e} | gen max = {mg['7']:.2e}/{mg['15']:.2e}/{mg['23']:.2e}")
paires_l = sorted((a["contexte"], max(a["max_par_couche"].values())) for a in log)
xl = rangs([a["contexte"] for a in log]); yl = rangs([max(a["max_par_couche"].values()) for a in log])
mxl, myl = sum(xl) / len(xl), sum(yl) / len(yl)
rhol = sum((a - mxl) * (b - myl) for a, b in zip(xl, yl)) / math.sqrt(sum((a - mxl) ** 2 for a in xl) * sum((b - myl) ** 2 for b in yl))
print(f"corrélation de rang (Spearman) entre longueur du contexte et écart maximal de l'action, logique : {rhol:.3f}")
print("logique : remplissage nul pour", sum(a["remplissage"] == 0 for a in log), "actions sur", len(log))
print("logique : (contexte, écart max) aux extrêmes :", paires_l[:3], paires_l[-3:])
# actions de remplissage nul en production
print("production : actions à remplissage nul :", [(a["episode"], a["action"], a["contexte"], round(max(a["max_par_couche"].values()), 4)) for a in prod if a["remplissage"] == 0])
print("logique : actions à remplissage nul :", [(a["episode"], a["action"], a["contexte"], f"{max(a['max_par_couche'].values()):.2e}") for a in log if a["remplissage"] == 0])
