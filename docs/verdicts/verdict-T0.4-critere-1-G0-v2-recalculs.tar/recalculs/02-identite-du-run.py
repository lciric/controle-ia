"""Juge R13, T0.4 v2 — étape a : le run est-il celui du préenregistrement ?
Lecture seule. Lancer depuis le clone : PYTHONPATH=src python <ce script>."""
import hashlib, json, re, subprocess, sys
from pathlib import Path

D = Path("/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/verdict-t04-v2/depot")
RUN = "20261005-144628-validation-reelle"
COMMIT_CITE = "dc7aa7fcd6b5b0c676ec7365d2a194a3c1924efc"
sys.path.insert(0, str(D / "src"))
from controle_ia.manifeste import config_canonique, lire_manifeste, verifier_resultat, generateur, graines as fabriquer_graines
from controle_ia.harnais import validation_reelle as V

prereg = (D / "prereg/T0.4-validation-modele-reel-v2.md").read_text(encoding="utf-8")
rev_citee = re.search(r"Révision du modèle : `([0-9a-f]{40})`", prereg).group(1)
ent_citee = int(re.search(r"Entropie : `([0-9]+)`", prereg).group(1))
com_cite = re.search(r"Commit du code d'analyse : `([0-9a-f]{40})`", prereg).group(1)
print("préenregistrement : commit cité", com_cite, "| révision citée", rev_citee, "| entropie citée", ent_citee)
assert com_cite == COMMIT_CITE

m, sha_m = lire_manifeste(D / f"runs/{RUN}/manifeste.json")
print("manifeste sha256 :", sha_m)
print("manifeste : commit", m["commit"], "| décisif", m["decisif"], "| dépôt propre", m["depot_propre"], "| réserves", m["reserves"])
print("manifeste : préenregistrement", m["preenregistrement"])
print("manifeste : versions", m["versions"])

# arbre gelé : commit du manifeste contre commit cité
r = subprocess.run(["git", "-C", str(D), "diff", "--quiet", COMMIT_CITE, m["commit"], "--", *V.CHEMINS_GELES])
print("arbre gelé identique entre le commit cité et celui du manifeste (git diff --quiet, code 0 attendu) :", r.returncode)
# le commit du manifeste descend-il du commit cité ?
r2 = subprocess.run(["git", "-C", str(D), "merge-base", "--is-ancestor", COMMIT_CITE, m["commit"]])
print("commit cité ancêtre du commit du manifeste (0 = oui) :", r2.returncode)
# le commit du manifeste est-il celui qui scelle le préenregistrement (empreinte du prereg à ce commit) ?
blob = subprocess.run(["git", "-C", str(D), "show", f"{m['commit']}:prereg/T0.4-validation-modele-reel-v2.md"],
                      capture_output=True).stdout
print("sha256 du préenregistrement au commit du manifeste :", hashlib.sha256(blob).hexdigest())

# configuration : empreinte recalculée, et égalité avec CONFIG_REELLE du code cité + révision citée
cfg = m["config"]
print("config_sha256 consigné :", m["config_sha256"])
print("config_sha256 recalculé :", hashlib.sha256(config_canonique(cfg)).hexdigest())
attendue = dict(V.CONFIG_REELLE, revision=rev_citee)
print("CONFIG_REELLE (code du clone = arbre gelé) + révision citée, empreinte :", hashlib.sha256(config_canonique(attendue)).hexdigest())
print("configuration du manifeste == CONFIG_REELLE + révision citée :", json.loads(config_canonique(cfg)) == json.loads(config_canonique(attendue)))
print("révision du manifeste == révision citée :", cfg["revision"] == rev_citee)

# graines : toutes à l'entropie citée, tâches = taches(config), chaque graine reconstructible (R9)
g = m["graines"]
ents = {v["entropie"] for v in g.values()}
print("entropies des graines :", ents, "== citée :", ents == {str(ent_citee)})
t_attendues = V.taches(cfg)
print("tâches : consignées", len(g), "| attendues par taches(config)", len(t_attendues), "| mêmes ensembles :", set(g) == set(t_attendues))
ok = all(generateur(v) is not None for v in g.values())
print("chaque graine se reconstruit (generateur, contrôle d'état) :", ok)
refaites = fabriquer_graines(t_attendues, ent_citee)
print("graines refaites depuis l'entropie citée == graines consignées :", refaites == g)
print("tâches contrôle positif :", sum(k.startswith("controle-positif/") for k in g),
      "| logique :", sum(k.startswith("logique/") for k in g), "| production :", sum(k.startswith("production/") for k in g))

# rattachement d'arret.json et des autres résultats au manifeste
for f in sorted((D / f"diag/{RUN}").glob("*.json")):
    corps = verifier_resultat(D, f)
    assert corps["manifeste_sha256"] == sha_m
print("tous les résultats de diag/ rattachés au manifeste par empreinte : oui (verifier_resultat sans arrêt)")

a = json.loads((D / f"diag/{RUN}/arret.json").read_text())["resultat"]
print("arret.json : phase", a["phase"], "| durée", a["duree_s"], "s | commit_cite", a["partiel"]["commit_cite"])
