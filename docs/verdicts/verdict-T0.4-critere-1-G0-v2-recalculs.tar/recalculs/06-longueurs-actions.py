"""Juge R13, T0.4 v2 — longueur des actions par (pas, agent) sur les 8 épisodes de chaque phase (lot de 8) :
qui est la plus longue ligne, combien atteignent le plafond de 256 jetons. Descriptif (audit R4)."""
import json
from pathlib import Path
DIAG = Path("/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/verdict-t04-v2/depot/diag/20261005-144628-validation-reelle")
for prefixe, T, episodes in (("logique", 10, range(8)), ("controle-positif", 5, range(8)), ("production", 10, range(16))):
    trs = {k: json.loads((DIAG / f"{prefixe}-episode-{k}-trajectoire.json").read_text())["resultat"] for k in episodes}
    plafond = 0; total = 0
    print(f"== {prefixe}")
    for lot in ([list(episodes)[i:i + 8] for i in range(0, len(episodes), 8)]):
        for t in range(T):
            for i in range(2):
                n = [len([a for a in trs[k]["transcriptions"][i]["actions"] if a["pas"] == t][0]["ids"]) for k in lot]
                plafond += sum(x == 256 for x in n); total += len(n)
                plus_longue = [lot[j] for j, x in enumerate(n) if x == max(n)]
                print(f"  lot {lot[0]}-{lot[-1]} t={t} ag={i} : longueurs {n} | plus longue(s) : épisodes {plus_longue}")
    print(f"  actions au plafond de 256 jetons : {plafond} sur {total}")
