#!/usr/bin/env bash
# Juge R13, T0.4 v2 : vérification des empreintes des fichiers lus (lecture seule, depuis le clone).
set -u
D=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/verdict-t04-v2/depot
cd "$D" || exit 2
echo "== commit du clone"; git rev-parse HEAD
echo "== préenregistrement (attendu 886c8c07c6954a46c666b294c391523f0cdd3d03a5b99dae5079507503de3fb9)"
(cd prereg && sha256sum -c T0.4-validation-modele-reel-v2.md.sha256)
sha256sum prereg/T0.4-validation-modele-reel-v2.md
echo "== manifeste du run"
(cd runs/20261005-144628-validation-reelle && sha256sum -c manifeste.json.sha256)
echo "== diag du run (chaque compagnon .sha256)"
(cd diag/20261005-144628-validation-reelle && for f in *.sha256; do sha256sum -c "$f"; done) | sort | uniq -c | awk '{print}' 
echo "== nombre de fichiers et de compagnons dans diag"
ls diag/20261005-144628-validation-reelle | grep -v '\.sha256$' | wc -l
ls diag/20261005-144628-validation-reelle | grep '\.sha256$' | wc -l
echo "== fichiers sans compagnon dans diag (attendu : aucun)"
for f in diag/20261005-144628-validation-reelle/*; do case "$f" in *.sha256) ;; *) [ -f "$f.sha256" ] || echo "SANS COMPAGNON: $f";; esac; done
echo "== traces du run (empreintes.sha256)"
(cd traces/t04-20261005-145255-g2el && sha256sum -c empreintes.sha256; ls -la)
echo "== traces de l'instance (empreintes.sha256)"
(cd traces/t04-instance-54332340-20261005-145534 && sha256sum -c empreintes.sha256; ls -la)
echo "== empreintes des fichiers d'empreintes eux-mêmes (pour citation)"
sha256sum traces/t04-20261005-145255-g2el/empreintes.sha256 traces/t04-instance-54332340-20261005-145534/empreintes.sha256
echo "== documents qui font foi (sha256sums-lancement-v2)"
(cd docs && sha256sum -c sha256sums-lancement-v2.txt)
echo "== documents cités en tête du préenregistrement"
sha256sum docs/brief-claude-code-programme-complet-v2.md docs/programme-controle-ia-v2.md livrables/premier-rendu-v1/devis-v1.md docs/notes/memoire-double-precision-T0.4-v1.md docs/verdicts/verdict-T0.4-critere-1-G0-v1.md docs/decisions/proposition-N-010-v1.md 2>&1
echo "== scripts de l'instance au commit cité dc7aa7f (attendus f143a0e9…, 548c14c5…)"
git show dc7aa7fcd6b5b0c676ec7365d2a194a3c1924efc:scripts/validation_t04_instance.sh | sha256sum
git show dc7aa7fcd6b5b0c676ec7365d2a194a3c1924efc:scripts/amorce_instance_t04.sh | sha256sum
echo "== scripts de l'instance au commit du clone"
sha256sum scripts/validation_t04_instance.sh scripts/amorce_instance_t04.sh
