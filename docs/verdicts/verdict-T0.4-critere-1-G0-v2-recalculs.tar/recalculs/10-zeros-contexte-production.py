"""Juge R13, T0.4 v2 — d'où viennent les écarts exactement nuls du contexte en production (descriptif, R4)."""
import json
from pathlib import Path
D = Path("/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/verdict-t04-v2/depot")
P = json.loads((D / "diag/20261005-144628-validation-reelle/arret.json").read_text(encoding="utf-8"))["resultat"]["partiel"]
for e in P["production"]["episodes"]:
    r = e["equivalence"]
    for cle, prof in r["profils"].items():
        n = {c: prof[c]["contexte"]["nuls"] for c in prof}
        if any(n.values()):
            print(e["episode"], cle, "contexte", prof["7"]["contexte"]["jetons"], "remplissage", r["lignes"][cle]["remplissage"], "nuls par couche", n)
tot = {c: sum(e["equivalence"]["profils"][k][c]["contexte"]["nuls"] for e in P["production"]["episodes"] for k in e["equivalence"]["profils"]) for c in ("7", "15", "23")}
print("total des nuls du contexte par couche :", tot)
