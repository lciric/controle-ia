"""Juge R13, T0.4 v2 — étape b : recalcul indépendant de chaque grandeur lue par la table gelée.

Lecture seule des fichiers scellés du run 20261005-144628-validation-reelle (clone du dépôt).
Principe : repartir des données par action (rapports d'équivalence, profils, contrôles négatifs, lignes,
trajectoires) et non des bilans ; puis comparer aux bilans consignés et à `lecture_partielle`.
Lancer depuis le clone : PYTHONPATH=src python <ce script>  (sortie JSON + texte sur la sortie standard).
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import sys
from pathlib import Path

D = Path("/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/verdict-t04-v2/depot")
RUN = "20261005-144628-validation-reelle"
DIAG = D / "diag" / RUN
TOL_LOG, TOL_PROD = 1e-4, 0.1

arret = json.loads((DIAG / "arret.json").read_text(encoding="utf-8"))["resultat"]
P = arret["partiel"]
manifeste = json.loads((D / "runs" / RUN / "manifeste.json").read_text(encoding="utf-8"))
config = manifeste["config"]
sortie: dict = {}


def nanmax(xs):
    """Maximum où NaN compte comme +inf (règle du préenregistrement)."""
    xs = [math.inf if x != x else x for x in xs]
    return max(xs) if xs else None


def titre(t):
    print("\n" + "=" * 100 + "\n" + t + "\n" + "=" * 100)


# ------------------------------------------------------------------ P0
titre("P0 — sortie des tests sur l'instance")
tests_txt = (D / "traces/t04-20261005-145255-g2el/tests.txt").read_text(encoding="utf-8")
tests_err = (D / "traces/t04-20261005-145255-g2el/tests.err").read_text(encoding="utf-8")
derniere = tests_txt.strip().splitlines()[-1]
regle = re.compile(r"^(\d+) passed(, \d+ warnings?)? in [0-9.]+s( \(\d+:\d{2}:\d{2}\))?$")  # règle de P0 (texte du prereg)
m = regle.match(derniere)
points = sum(l.split(" [")[0].count(".") for l in tests_txt.strip().splitlines()[:-1])
autres_marques = sum(sum(l.split(" [")[0].count(c) for c in "FEsxX") for l in tests_txt.strip().splitlines()[:-1])
ti = json.loads((DIAG / "tests-instance.json").read_text(encoding="utf-8"))["resultat"]
p0 = {"derniere_ligne": derniere, "regle_ok": bool(m), "nombre": int(m.group(1)) if m else None,
      "points_de_progression": points, "autres_marques_F_E_s_x_X": autres_marques, "tests_err_octets": len(tests_err),
      "tests_instance_json_identique_aux_traces": ti["sortie"] == tests_txt, "derniere_ligne_json": ti["derniere_ligne"],
      "resume_tests_instance": P["tests_instance"]}
p0["lecture_juge"] = "conforme" if (m and int(m.group(1)) == 192) else "contraire"
print(json.dumps(p0, indent=1, ensure_ascii=False))
sortie["P0"] = p0

# ------------------------------------------------------------------ P1
titre("P1 — format, date, fichiers du modèle, mémoire de la carte, mémoire vive, type des poids, normalisations")
f = P["format"]
fm = P["fichiers_modele"]
p1 = {"format_verifie": f["verifie"], "tours": f["tours"], "jetons_controle": f["jetons"],
      "date_dans_ouverture": "Today Date: 26 Jul 2024" in f["ouverture"],
      "gabarit_sha256": f["gabarit_sha256"], "fins": f["fins"],
      "fichiers_modele": {k: v["conforme"] for k, v in fm.items()},
      "tous_fichiers_conformes": all(v["conforme"] for v in fm.values()), "nombre_fichiers": len(fm),
      "poids_safetensors": sorted(k for k in fm if k.endswith(".safetensors")),
      "memoire_carte_gio": P["reglages"]["memoire_carte_gio"], "memoire_carte_ok": P["reglages"]["memoire_carte_gio"] >= 130,
      "memoire_vive": P["memoire_vive_go"], "memoire_vive_ok": P["memoire_vive_go"]["effective_go"] >= 96,
      "type_des_poids_logique": P["chargement"]["type_des_poids"], "attention": P["chargement"]["attention"],
      "normalisations_en_double": P["chargement"]["normalisations_en_double"],
      "normalisations_attendues": 2 * 32 + 1}
# recoupement : mêmes fichiers du modèle que le run de la v1 (même révision), s'il les consigne
v1 = D / "diag/20261005-102042-validation-reelle/arret.json"
if v1.exists():
    pv1 = json.loads(v1.read_text(encoding="utf-8"))["resultat"]["partiel"]
    fv1 = pv1.get("fichiers_modele")
    p1["fichiers_modele_identiques_a_la_v1"] = (fv1 == fm) if fv1 else "absent de la v1"
    p1["gabarit_identique_a_la_v1"] = pv1.get("format", {}).get("gabarit_sha256") == f["gabarit_sha256"]
p1["lecture_juge"] = "conforme" if (f["verifie"] is True and p1["date_dans_ouverture"] and p1["tous_fichiers_conformes"]
                                    and p1["memoire_carte_ok"] and p1["memoire_vive_ok"]
                                    and p1["type_des_poids_logique"] == "torch.float64") else "contraire"
p1["reserve_normalisations"] = p1["normalisations_en_double"] != 65
print(json.dumps(p1, indent=1, ensure_ascii=False))
sortie["P1"] = p1


# ------------------------------------------------------------------ outils d'équivalence
def actions_de(episodes, cle_rapport="equivalence"):
    """(épisode, clé, rapport) pour chaque action comparée."""
    out = []
    for e in episodes:
        r = e[cle_rapport]
        for cle in r["ecarts"]:
            out.append((e["episode"], cle, r))
    return out


def trajectoire(prefixe, ep):
    return json.loads((DIAG / f"{prefixe}-{ep}-trajectoire.json").read_text(encoding="utf-8"))["resultat"]


def bilan_equivalence(prefixe, episodes, tol):
    acts = actions_de(episodes)
    lignes_action = []
    ecarts = []
    par_couche = {}
    par_zone = {"contexte": [], "generee": []}
    par_couche_zone = {}
    zeros = {}
    cov = {"remplies": 0, "finies_avant": 0, "positions_generees": 0, "lignes": set()}
    dom = {"contexte_max": 0, "generes_relus_max": 0, "taille_lot": 0}
    incoherences = []
    neg = {"comparables": 0, "passent": 0, "courtes": 0, "echecs": [], "min": math.inf}
    sondes_ok = {"distincts": True, "ulp": True}
    trajs = {}
    for ep, cle, r in acts:
        i, t = map(int, cle.split(","))
        e_c = r["ecarts"][cle]
        prof = r["profils"][cle]
        lc, pc = r["longueurs_contexte"][cle], r["positions_capturees"][cle]
        li = r["lignes"][cle]
        # écarts par couche (ecart_equivalence) et cohérence avec les profils (max de toutes positions)
        for c, v in e_c.items():
            ecarts.append(v)
            par_couche.setdefault(c, []).append(v)
            if prof[c]["max"] != v:
                incoherences.append(f"{ep}:{cle}:{c} ecart {v} != profil max {prof[c]['max']}")
            mz = nanmax([prof[c][z]["max"] for z in ("contexte", "generee") if prof[c][z]["jetons"]])
            if mz != v:
                incoherences.append(f"{ep}:{cle}:{c} ecart {v} != max des zones {mz}")
            if prof[c]["contexte"]["jetons"] != lc or prof[c]["generee"]["jetons"] != pc - lc or prof[c]["jetons"] != pc:
                incoherences.append(f"{ep}:{cle}:{c} jetons des zones incohérents")
            for z in ("contexte", "generee"):
                if prof[c][z]["jetons"]:
                    par_zone[z].append(prof[c][z]["max"])
                    par_couche_zone.setdefault((c, z), []).append(prof[c][z]["max"])
                zz = zeros.setdefault(c, {"contexte": [0, 0], "generee": [0, 0]})
                zz[z][0] += prof[c][z].get("nuls", 0)
                zz[z][1] += prof[c][z]["jetons"]
        # couverture et domaine
        cov["remplies"] += li["remplissage"] > 0
        cov["finies_avant"] += bool(li["finie_avant"])
        cov["positions_generees"] += pc - lc
        cov["lignes"].add(li["ligne"])
        dom["contexte_max"] = max(dom["contexte_max"], lc)
        dom["generes_relus_max"] = max(dom["generes_relus_max"], pc - lc)
        dom["taille_lot"] = max(dom["taille_lot"], li["taille_lot"])
        # recoupement avec la trajectoire scellée : début de l'action = longueur du contexte ; jetons relus
        if ep not in trajs:
            trajs[ep] = trajectoire(prefixe, ep)
        tr = trajs[ep]["transcriptions"][i]
        a = [x for x in tr["actions"] if x["pas"] == t][0]
        n = len(a["ids"])
        if a["debut"] != lc:
            incoherences.append(f"{ep}:{cle} début d'action {a['debut']} != longueur de contexte {lc}")
        attendu = n if li["finie_avant"] else n - 1          # la plus longue ligne ne relit pas son dernier jeton
        if pc - lc != attendu:
            incoherences.append(f"{ep}:{cle} relus {pc - lc} != attendu {attendu} (n={n}, finie_avant={li['finie_avant']})")
        # contrôle négatif (zone générée)
        z = r["controle_negatif_zone_generee"][cle]
        if z is None or min(v["positions"] for v in z.values()) < 4:
            neg["courtes"] += 1
        else:
            neg["comparables"] += 1
            mm = min(-math.inf if v["max"] != v["max"] else v["max"] for v in z.values())
            neg["min"] = min(neg["min"], mm)
            if mm > tol:
                neg["passent"] += 1
            else:
                neg["echecs"].append(f"{ep}:{cle}")
            for c, v in z.items():
                if v["positions"] != pc - lc - 1:
                    incoherences.append(f"{ep}:{cle}:{c} comparaisons décalées {v['positions']} != {pc - lc - 1}")
        s = r["sondes"][cle]
        sondes_ok["distincts"] &= s["tableaux_distincts"]
        sondes_ok["ulp"] &= s["ulp_vu"]
        lignes_action.append({"episode": ep, "action": cle, "agent": i, "pas": t, "contexte": lc,
                              "generes_relus": pc - lc, "generes": n, "remplissage": li["remplissage"],
                              "ligne": li["ligne"], "finie_avant": li["finie_avant"],
                              "max_par_couche": e_c,
                              "max_contexte_par_couche": {c: prof[c]["contexte"]["max"] for c in prof},
                              "max_generee_par_couche": {c: prof[c]["generee"].get("max") for c in prof},
                              "q50_q99_contexte": {c: [prof[c]["contexte"]["q50"], prof[c]["contexte"]["q99"]] for c in prof},
                              "q50_q99_generee": {c: [prof[c]["generee"].get("q50"), prof[c]["generee"].get("q99")] for c in prof},
                              "neg_min_couches": None if z is None else min(v["max"] for v in z.values())})
    b = {"actions_comparees": len(acts), "ecart_max": nanmax(ecarts),
         "ecart_non_fini": any(x != x or x == math.inf for x in ecarts),
         "max_contexte": nanmax(par_zone["contexte"]), "max_zone_generee": nanmax(par_zone["generee"]),
         "max_par_couche": {c: nanmax(v) for c, v in sorted(par_couche.items(), key=lambda x: int(x[0]))},
         "max_par_couche_et_zone": {f"{c}/{z}": nanmax(v) for (c, z), v in sorted(par_couche_zone.items(), key=lambda x: (int(x[0][0]), x[0][1]))},
         "couverture": {"actions_remplies": cov["remplies"], "actions_finies_avant": cov["finies_avant"],
                        "positions_generees_comparees": cov["positions_generees"], "lignes_echantillon": sorted(cov["lignes"])},
         "domaine": dom, "zeros": zeros,
         "controle_negatif": {"comparables": neg["comparables"], "passent": neg["passent"], "courtes": neg["courtes"],
                              "echecs": neg["echecs"], "fraction": neg["passent"] / neg["comparables"] if neg["comparables"] else None,
                              "min_des_maxima": neg["min"] if neg["comparables"] else None},
         "sondes_audit": sondes_ok, "incoherences": incoherences}
    return b, lignes_action


def comparer(nom, recalc, consigne, cles):
    diffs = {}
    for k in cles:
        if recalc.get(k) != consigne.get(k):
            diffs[k] = {"recalcul": recalc.get(k), "consigne": consigne.get(k)}
    print(f"{nom} : recalcul == bilan consigné pour {cles} :", "OUI" if not diffs else f"NON {diffs}")
    return diffs


# ------------------------------------------------------------------ P2, P3, P9 (logique)
titre("P2, P3, P9 — phase de logique (double précision)")
L = P["logique"]
eps_log = [e for e in L["episodes"] if e["equivalence"]["ecarts"]]
print("épisodes avec actions comparées :", [e["episode"] for e in eps_log], "(attendu : episode-1 et episode-6)")
b_log, act_log = bilan_equivalence("logique", eps_log, TOL_LOG)
cons = L["equivalence"]
d_log = comparer("logique", {**b_log, "zeros": {c: {z: v for z, v in zz.items()} for c, zz in b_log["zeros"].items()}},
                 cons, ["actions_comparees", "ecart_max", "ecart_non_fini", "max_contexte", "max_zone_generee", "couverture", "domaine", "zeros"])
neg_c = {k: cons["controle_negatif"][k] for k in ("comparables", "passent", "courtes", "echecs", "fraction", "min_des_maxima")}
d_log_neg = comparer("logique, contrôle négatif", b_log["controle_negatif"], neg_c, list(neg_c))
print("incohérences rapports/trajectoires :", b_log["incoherences"] or "aucune")
print(json.dumps({k: v for k, v in b_log.items() if k not in ("incoherences",)}, indent=1, ensure_ascii=False, default=str))
cv = b_log["couverture"]
p2 = {"ecart_max": b_log["ecart_max"], "seuil": TOL_LOG, "sous_le_seuil": b_log["ecart_max"] <= TOL_LOG,
      "couverture_ok": cv["actions_remplies"] > 0 and cv["actions_finies_avant"] > 0 and cv["positions_generees_comparees"] > 0
      and any(x != 0 for x in cv["lignes_echantillon"]), "actions_comparees": b_log["actions_comparees"]}
p2["lecture_juge"] = ("conforme" if p2["sous_le_seuil"] and p2["couverture_ok"] else
                      "non concluant (couverture)" if p2["sous_le_seuil"] else "contraire (voir zones)")
p3 = dict(b_log["controle_negatif"], seuil=TOL_LOG)
p3["lecture_juge"] = ("non concluant" if p3["comparables"] < 10 else "conforme" if p3["fraction"] >= 0.95 else "contraire")
print("P2 :", json.dumps(p2, ensure_ascii=False))
print("P3 :", json.dumps(p3, ensure_ascii=False))
sortie["P2"] = {**p2, "detail": {k: v for k, v in b_log.items() if k != "controle_negatif"}, "ecarts_au_bilan": d_log}
sortie["P3"] = {**p3, "ecarts_au_bilan": d_log_neg}

# ------------------------------------------------------------------ P2b (contrôle positif)
titre("P2b — contrôle positif (défaut D1 injecté)")
C = P["controle_positif"]
print("T :", C["T"], "| décalage :", C["decalage_positions"], "| plan :", C["plan_lots"])
comparables = vus = courtes = 0
manques, minimum, contextes, detail_pc = [], math.inf, [], []
for e in C["episodes"]:
    for cle, prof in e["profils"].items():
        zones = [p["generee"] for p in prof.values()]
        if any(z["jetons"] < 4 for z in zones):
            courtes += 1
            continue
        comparables += 1
        contextes += [p["contexte"]["max"] for p in prof.values() if p["contexte"]["jetons"]]
        mm = min(-math.inf if z["max"] != z["max"] else z["max"] for z in zones)
        minimum = min(minimum, mm)
        if mm > TOL_LOG:
            vus += 1
        else:
            manques.append(f"{e['episode']}:{cle}")
        detail_pc.append({"episode": e["episode"], "action": cle,
                          "contexte": prof["7"]["contexte"]["jetons"], "generee": prof["7"]["generee"]["jetons"],
                          "max_generee_par_couche": {c: p["generee"]["max"] for c, p in prof.items()},
                          "q50_generee_par_couche": {c: p["generee"]["q50"] for c, p in prof.items()},
                          "max_contexte_par_couche": {c: p["contexte"]["max"] for c, p in prof.items()},
                          "nuls_generee": {c: p["generee"]["nuls"] for c, p in prof.items()}})
p2b = {"comparables": comparables, "vus": vus, "courtes": courtes, "manques": manques,
       "fraction": vus / comparables if comparables else None, "min_des_maxima": minimum if comparables else None,
       "max_contexte": nanmax(contextes), "seuil": TOL_LOG, "actions_listees": sum(len(e["profils"]) for e in C["episodes"]),
       "episodes": [e["episode"] for e in C["episodes"]]}
p2b["lecture_juge"] = ("non concluant" if comparables < 10 else "conforme" if p2b["fraction"] >= 0.95 else "contraire")
p2b["ligne_contexte_du_controle_positif_declenchee"] = p2b["max_contexte"] > TOL_LOG
p2b["separation_D1_arrondi"] = p2b["min_des_maxima"] / b_log["ecart_max"]
p2b["separation_D1_arrondi_log10"] = math.log10(p2b["separation_D1_arrondi"])
p2b["separation_D1_zone_generee_logique"] = p2b["min_des_maxima"] / b_log["max_zone_generee"]
d_pc = comparer("contrôle positif", p2b, C["bilan"], ["comparables", "vus", "courtes", "manques", "fraction", "min_des_maxima", "max_contexte"])
print(json.dumps(p2b, indent=1, ensure_ascii=False))
mins_couche = {c: min(x["max_generee_par_couche"][c] for x in detail_pc) for c in ("7", "15", "23")}
q50s = {c: sorted(x["q50_generee_par_couche"][c] for x in detail_pc) for c in ("7", "15", "23")}
print("minimum, par couche, du maximum de la zone générée :", mins_couche)
print("médiane par action (q50 zone générée), min et max par couche :", {c: [v[0], v[-1]] for c, v in q50s.items()})
print("zéros dans la zone générée du contrôle positif :", sum(sum(x["nuls_generee"].values()) for x in detail_pc))
print("contexte des actions : jetons min/max", min(x["contexte"] for x in detail_pc), max(x["contexte"] for x in detail_pc),
      "| zone générée min/max", min(x["generee"] for x in detail_pc), max(x["generee"] for x in detail_pc))
sortie["P2b"] = {**p2b, "min_par_couche_du_max_zone_generee": mins_couche, "detail": detail_pc, "ecarts_au_bilan": d_pc,
                 "domaine": {"contexte_max": max(x["contexte"] for x in detail_pc), "generee_max": max(x["generee"] for x in detail_pc),
                             "longueur_remplie_max": C["debit"].get("longueur_remplie_max")}}

# ------------------------------------------------------------------ P4, P5, P9 (production)
titre("P4, P5, P9 — phase de production (demi-précision)")
PR = P["production"]
eps_prod = [e for e in PR["episodes"] if e["equivalence"]["ecarts"]]
print("épisodes avec actions comparées :", [e["episode"] for e in eps_prod], "(attendu : episode-1 et episode-14)")
b_prod, act_prod = bilan_equivalence("production", eps_prod, TOL_PROD)
cons = PR["equivalence"]
d_prod = comparer("production", b_prod, cons, ["actions_comparees", "ecart_max", "ecart_non_fini", "max_contexte", "max_zone_generee", "couverture", "domaine", "zeros"])
neg_c = {k: cons["controle_negatif"][k] for k in ("comparables", "passent", "courtes", "echecs", "fraction", "min_des_maxima")}
d_prod_neg = comparer("production, contrôle négatif", b_prod["controle_negatif"], neg_c, list(neg_c))
print("incohérences rapports/trajectoires :", b_prod["incoherences"] or "aucune")
print(json.dumps({k: v for k, v in b_prod.items() if k not in ("incoherences",)}, indent=1, ensure_ascii=False, default=str))
au_dessus = [a for a in act_prod if max(a["max_par_couche"].values()) > TOL_PROD]
par_couche_au_dessus = {c: sum(a["max_par_couche"][c] > TOL_PROD for a in act_prod) for c in ("7", "15", "23")}
zone_au_dessus = {"contexte": sum(any(a["max_contexte_par_couche"][c] > TOL_PROD for c in a["max_contexte_par_couche"]) for a in act_prod),
                  "generee": sum(any((a["max_generee_par_couche"][c] or 0) > TOL_PROD for c in a["max_generee_par_couche"]) for a in act_prod)}
p4 = {"ecart_max": b_prod["ecart_max"], "seuil": TOL_PROD, "sous_le_seuil": b_prod["ecart_max"] <= TOL_PROD,
      "actions_au_dessus": len(au_dessus), "actions_au_dessus_par_couche": par_couche_au_dessus,
      "actions_au_dessus_par_zone": zone_au_dessus,
      "max_par_couche": b_prod["max_par_couche"], "max_par_couche_et_zone": b_prod["max_par_couche_et_zone"],
      "liste": [f"{a['episode']}:({a['action']}) " + ", ".join(f"c{c}={v:.4f}" for c, v in a["max_par_couche"].items() if v > TOL_PROD)
                for a in au_dessus]}
p4["lecture_juge"] = "conforme" if p4["sous_le_seuil"] else "contraire"
p5 = dict(b_prod["controle_negatif"], seuil=TOL_PROD)
p5["lecture_juge"] = ("non concluant" if p5["comparables"] < 10 else "conforme" if p5["fraction"] >= 0.95 else "contraire")
print("P4 :", json.dumps(p4, indent=1, ensure_ascii=False))
print("P5 :", json.dumps(p5, ensure_ascii=False))
# recoupement avec le motif de l'arrêt
motif = arret["motif"]
n_motif = int(re.search(r"(\d+) faute\(s\) de garde", motif).group(1))
print("motif : fautes annoncées", n_motif, "| recalcul", len(au_dessus))
sortie["P4"] = {**p4, "fautes_annoncees_par_le_motif": n_motif, "ecarts_au_bilan": d_prod}
sortie["P5"] = {**p5, "ecarts_au_bilan": d_prod_neg}
sortie["actions_production"] = act_prod
sortie["actions_logique"] = act_log

# ------------------------------------------------------------------ P9
titre("P9 — écarts non nuls dans la zone générée, par phase")
p9 = {}
for nom, b in (("logique", b_log), ("production", b_prod)):
    gen = {c: zz["generee"] for c, zz in b["zeros"].items()}
    ctx = {c: zz["contexte"] for c, zz in b["zeros"].items()}
    declenche = sum(t for _, t in gen.values()) > 0 and all(n == t for n, t in gen.values())
    p9[nom] = {"zone_generee_nuls_sur_total": gen, "contexte_nuls_sur_total": ctx,
               "non_nuls_zone_generee": sum(t - n for n, t in gen.values()), "declenche": declenche}
print(json.dumps(p9, indent=1))
sortie["P9"] = p9

# ------------------------------------------------------------------ P6
titre("P6 — rejeu du lot 0 dans le processus (production)")
ep_by = {e["episode"]: e for e in PR["episodes"]}
p6 = []
for r in PR["rejeu_en_processus"]:
    e = ep_by[r["episode"]]
    cles = sorted(set(r["empreintes"]) | set(e["empreintes"]))
    p6.append({"episode": r["episode"], "identique_consigne": r["identique"],
               "cles": cles,
               "empreintes_identiques": r["empreintes"] == e["empreintes"],
               "captures_identiques": r["empreintes_capture"] == e["equivalence"]["empreintes_capture"],
               "logits_par_action_identiques": r["empreintes_logits"] == e["equivalence"]["empreintes_logits"],
               "captures_non_vides": bool(r["empreintes_capture"])})
for x in p6:
    print(x)
p6_ok = (len(p6) == 8 and [x["episode"] for x in p6] == [f"episode-{k}" for k in range(8)]
         and all(x["empreintes_identiques"] and x["captures_identiques"] and x["identique_consigne"] for x in p6)
         and all(set(x["cles"]) == {"activations", "logits", "scores", "trajectoire", "vecteurs"} for x in p6))
print("P6 (8 épisodes, 5 empreintes chacun, captures) :", "conforme" if p6_ok else "contraire")
sortie["P6"] = {"detail": p6, "lecture_juge": "conforme" if p6_ok else "contraire"}

# ------------------------------------------------------------------ P8
titre("P8 — relecture du disque (preuve par l'ordre du code et le contenu d'arret.json)")
eps = PR["episodes"]
p8 = {"episodes_dans_resume": len(eps), "episodes_attendus": config["production"]["episodes"],
      "par_jeton_conserve": [e["episode"] for e in eps if e["par_jeton_conserve"]],
      "tableaux_sha256_presents": all(re.fullmatch(r"[0-9a-f]{64}", e["tableaux_sha256"]) for e in eps),
      "stockage_present": "stockage" in PR, "rejeu_present": "rejeu_en_processus" in PR,
      "repere_present": "repere_precision" in PR, "phase_arret": arret["phase"],
      "motif_commence_par": arret["motif"][:60],
      "fichiers_par_jeton_octets": PR["stockage"]["fichiers_par_jeton_octets"],
      "trajectoires_production_dans_diag": len(list(DIAG.glob("production-episode-*-trajectoire.json")))}
p8["lecture_juge"] = ("conforme (garde de relecture passée pour les 16 épisodes ; vérifiable seulement par l'ordre du code)"
                      if p8["episodes_dans_resume"] == 16 and p8["stockage_present"] and p8["tableaux_sha256_presents"]
                      and "équivalence" not in p8["motif_commence_par"] else "à examiner")
print(json.dumps(p8, indent=1, ensure_ascii=False))
sortie["P8"] = p8

# ------------------------------------------------------------------ P7
titre("P7 — rejeu entre processus (run B)")
runs_validation = sorted(p.name for p in (D / "runs").iterdir() if p.name.endswith("validation-reelle"))
comparaisons = sorted(str(p.relative_to(D)) for p in (D / "diag").glob("*/comparaison-*.json")) + \
               sorted(str(p.relative_to(D)) for p in (D / "diag").glob("*/arret-comparaison-*.json"))
p7 = {"runs_validation_reelle": runs_validation,
      "runs_posterieurs_a_A": [r for r in runs_validation if r > RUN],
      "comparaisons_ou_arrets_de_comparaison_pour_A": [c for c in comparaisons if RUN in c],
      "lecture_juge": "non atteint (run B jamais lancé : le script d'instance s'arrête après l'arrêt consigné de A)"}
print(json.dumps(p7, indent=1, ensure_ascii=False))
sortie["P7"] = p7

# ------------------------------------------------------------------ empreintes des trajectoires
titre("Recoupement : empreinte de chaque trajectoire scellée dans diag/ = empreinte consignée dans arret.json")
verif_traj = {}
for prefixe, liste in (("logique", L["episodes"]), ("controle-positif", C["episodes"]), ("production", PR["episodes"])):
    for e in liste:
        tr = trajectoire(prefixe, e["episode"])
        h = hashlib.sha256(json.dumps(tr, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()
        verif_traj[f"{prefixe}/{e['episode']}"] = h == e["empreintes"]["trajectoire"]
print(f"{sum(verif_traj.values())} sur {len(verif_traj)} identiques ; différentes :", [k for k, v in verif_traj.items() if not v] or "aucune")
sortie["empreintes_trajectoires"] = verif_traj

# ------------------------------------------------------------------ lecture_partielle
titre("lecture_partielle : consignée, relue par le code cité (`lire`), et lecture du juge")
sys.path.insert(0, str(D / "src"))
from controle_ia.harnais.validation_reelle import lire  # noqa: E402

relu = lire(P, config)
juge = {"tests_instance": p0["lecture_juge"], "format": "conforme" if f["verifie"] is True else "contraire",
        "logique_equivalence": p2["lecture_juge"], "logique_controle_negatif": p3["lecture_juge"],
        "controle_positif": p2b["lecture_juge"], "production_equivalence": p4["lecture_juge"],
        "production_controle_negatif": p5["lecture_juge"], "rejeu_en_processus": sortie["P6"]["lecture_juge"],
        "audit_symetrie": "non déclenché" if not (p9["logique"]["declenche"] or p9["production"]["declenche"]) else "déclenché"}
for k in sorted(set(P["lecture_partielle"]) | set(juge)):
    print(f"{k:32s} consignée={P['lecture_partielle'].get(k)!s:15s} relue_par_lire={relu.get(k)!s:15s} juge={juge.get(k)}")
print("lecture relue == consignée :", relu == P["lecture_partielle"])
print("lecture du juge == consignée :", juge == P["lecture_partielle"])
sortie["lecture_partielle"] = {"consignee": P["lecture_partielle"], "relue_par_lire": relu, "juge": juge,
                               "relue_egale": relu == P["lecture_partielle"], "juge_egale": juge == P["lecture_partielle"]}

# ------------------------------------------------------------------ descriptifs
titre("Descriptifs : réglages relus, noyaux, mémoire, domaine, débit, repère de précision")
desc = {"reglages": P["reglages"], "noyaux_logique": L["noyaux_permis"], "noyau_logique": L["noyau_attention"],
        "noyaux_production": PR["noyaux_permis"], "noyau_production": PR["noyau_attention"],
        "memoire_max_go": {"logique": L["memoire_max_go"], "controle_positif": C["memoire_max_go"], "production": PR["memoire_max_go"]},
        "longueur_remplie_max": {"logique": L["debit"].get("longueur_remplie_max"), "controle_positif": C["debit"].get("longueur_remplie_max"),
                                 "production": PR["debit"].get("longueur_remplie_max")},
        "repere_precision": PR["repere_precision"], "empreinte_poids": PR["empreinte_poids"], "debit_phase_atteinte": "debit" in P}
print(json.dumps(desc, indent=1, ensure_ascii=False))
sortie["descriptifs"] = desc

(Path(__file__).with_suffix(".json")).write_text(json.dumps(sortie, indent=1, ensure_ascii=False, default=str) + "\n", encoding="utf-8")
print("\nsortie JSON écrite :", Path(__file__).with_suffix(".json"))
