"""Juge R13, T0.4 v2 — audit R4 du contrôle positif : profils recoupés avec les trajectoires scellées ;
comparaison des trajectoires du contrôle positif et de la logique (graines propres, contextes de départ)."""
import json
from pathlib import Path

D = Path("/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/verdict-t04-v2/depot")
DIAG = D / "diag/20261005-144628-validation-reelle"
P = json.loads((DIAG / "arret.json").read_text(encoding="utf-8"))["resultat"]["partiel"]
C = P["controle_positif"]
incoh = []
lignes = []
for e in C["episodes"]:
    tr = json.loads((DIAG / f"controle-positif-{e['episode']}-trajectoire.json").read_text(encoding="utf-8"))["resultat"]
    assert tr["T"] == 5 and tr["N"] == 2, (tr["T"], tr["N"])
    for cle, prof in e["profils"].items():
        i, t = map(int, cle.split(","))
        a = [x for x in tr["transcriptions"][i]["actions"] if x["pas"] == t][0]
        n = len(a["ids"])
        for c, p in prof.items():
            if p["contexte"]["jetons"] != a["debut"]:
                incoh.append(f"{e['episode']}:{cle}:{c} contexte {p['contexte']['jetons']} != début {a['debut']}")
            if p["generee"]["jetons"] not in (n, n - 1):
                incoh.append(f"{e['episode']}:{cle}:{c} zone générée {p['generee']['jetons']} hors de {{n, n-1}} (n={n})")
            if p["jetons"] != p["contexte"]["jetons"] + p["generee"]["jetons"]:
                incoh.append(f"{e['episode']}:{cle}:{c} total incohérent")
        lignes.append((e["episode"], cle, a["debut"], n, prof["7"]["generee"]["jetons"]))
print("contrôle positif : actions recoupées avec leurs trajectoires :", len(lignes), "| incohérences :", incoh or "aucune")
for l in lignes:
    print("  ", l)
# trajectoires du contrôle positif et de la logique : mêmes ouvertures (pas 0, agent 0), actions différentes (graines propres)
for k in range(8):
    tl = json.loads((DIAG / f"logique-episode-{k}-trajectoire.json").read_text(encoding="utf-8"))["resultat"]
    tc = json.loads((DIAG / f"controle-positif-episode-{k}-trajectoire.json").read_text(encoding="utf-8"))["resultat"]
    a_l = tl["transcriptions"][0]["actions"][0]; a_c = tc["transcriptions"][0]["actions"][0]
    print(f"episode-{k} : ouverture identique {tl['transcriptions'][0]['ids'][:a_l['debut']] == tc['transcriptions'][0]['ids'][:a_c['debut']]} "
          f"(début {a_l['debut']} / {a_c['debut']}) ; première action identique {a_l['ids'] == a_c['ids']} ; "
          f"longueurs des transcriptions logique {[len(x['ids']) for x in tl['transcriptions']]} contrôle positif {[len(x['ids']) for x in tc['transcriptions']]}")
# positions générées par couche et écarts nuls dans la zone générée du contrôle positif (actions comparées)
for c in ("7", "15", "23"):
    print(f"couche {c} : positions générées {sum(e['profils'][k][c]['generee']['jetons'] for e in C['episodes'] for k in e['profils'])}, "
          f"écarts nuls {sum(e['profils'][k][c]['generee']['nuls'] for e in C['episodes'] for k in e['profils'])}")
