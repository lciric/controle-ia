"""Recalcul 03b (juge R13, T0.4 v3) : P7, comme 03, chemins des npz normalisés (identifiant du run retiré).

1. Relit la comparaison scellée de B et vérifie sa chaîne.
2. Refait la comparaison du code (`comparer_runs`), en lecture seule (sans rien écrire).
3. Comparaison profonde et plus stricte : tous les champs des deux résumés, chemin par chemin ; seuls les champs de
   durée, de débit et de pic de mémoire (descriptifs, hors comparaison selon P7) peuvent différer.
4. Trajectoires écrites (tous les fichiers de diag/, hors enveloppe), environnement Python, manifestes.

À lancer depuis la racine du clone, avec PYTHONPATH=src.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

from controle_ia.harnais.validation_reelle import CHEMINS_GELES, PHASES_COMPAREES
from controle_ia.manifeste import lire_manifeste, verifier_resultat

RACINE = Path(".").resolve()
A, B = "20261006-114025-validation-reelle", "20261006-115440-validation-reelle"
ECHECS: list[str] = []
DESCRIPTIFS = {"duree_s", "debit", "memoire_max_go", "projection_heures"}


def controle(nom: str, ok: bool, detail: str = "") -> None:
    print(f"{'OK   ' if ok else 'ÉCHEC'} {nom}{' : ' + detail if detail else ''}")
    if not ok:
        ECHECS.append(nom)


def differences(a, b, chemin=""):
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b), key=str):
            if k not in a or k not in b:
                yield (f"{chemin}/{k}", "clé absente d'un côté")
            else:
                yield from differences(a[k], b[k], f"{chemin}/{k}")
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            yield (chemin, f"longueurs {len(a)} et {len(b)}")
        else:
            for i, (x, y) in enumerate(zip(a, b)):
                yield from differences(x, y, f"{chemin}[{i}]")
    elif type(a) is not type(b) or a != b:
        if not (isinstance(a, float) and isinstance(b, float) and a != a and b != b):
            yield (chemin, f"{str(a)[:60]} ≠ {str(b)[:60]}")


print("== 1. Comparaison scellée de B")
corps = verifier_resultat(RACINE, RACINE / "diag" / B / f"comparaison-{A}.json")
print("     ", json.dumps(corps["resultat"], ensure_ascii=False))
controle("comparaison scellée : identique, sans différence, lecture conforme",
         corps["resultat"] == {"run_a": A, "run_b": B, "identique": True, "differences": [], "lecture": "conforme"})
controle("comparaison rattachée au manifeste de B", corps["run_id"] == B)

print("\n== 2. Comparaison du code refaite en lecture seule")
m_a, _ = lire_manifeste(RACINE / "runs" / A / "manifeste.json")
m_b, _ = lire_manifeste(RACINE / "runs" / B / "manifeste.json")
ra = json.loads(json.dumps(verifier_resultat(RACINE, RACINE / "diag" / A / "resume.json")["resultat"]).replace(f"donnees/{A}/", "donnees/<run>/"))
rb = json.loads(json.dumps(verifier_resultat(RACINE, RACINE / "diag" / B / "resume.json")["resultat"]).replace(f"donnees/{B}/", "donnees/<run>/"))
controle("mêmes configurations", m_a["config_sha256"] == m_b["config_sha256"])
controle("mêmes graines", m_a["graines"] == m_b["graines"])
r = subprocess.run(["git", "--no-optional-locks", "-C", str(RACINE), "diff", "--quiet", m_a["commit"], m_b["commit"],
                    "--", *CHEMINS_GELES], capture_output=True, text=True)
controle("même arbre gelé", r.returncode == 0)
diffs_code = []
for phase in PHASES_COMPAREES:
    ea = {e["episode"]: e for e in ra[phase]["episodes"]}
    eb = {e["episode"]: e for e in rb[phase]["episodes"]}
    if set(ea) != set(eb):
        diffs_code.append((phase, "épisodes"))
        continue
    for ep in sorted(ea):
        for cle in sorted(set(ea[ep]["empreintes"]) | set(eb[ep]["empreintes"])):
            if ea[ep]["empreintes"].get(cle) != eb[ep]["empreintes"].get(cle):
                diffs_code.append((phase, ep, cle))
        for cle in ("empreintes_capture", "profils"):
            if ea[ep]["equivalence"].get(cle) != eb[ep]["equivalence"].get(cle):
                diffs_code.append((phase, ep, cle))
        if ea[ep].get("tableaux_sha256") != eb[ep].get("tableaux_sha256"):
            diffs_code.append((phase, ep, "npz"))
for cle_pc in ("controle_positif", "controle_positif_chemin"):
    sa = {k: v for k, v in ra[cle_pc].items() if k not in ("debit", "memoire_max_go")}
    sb = {k: v for k, v in rb[cle_pc].items() if k not in ("debit", "memoire_max_go")}
    if sa != sb:
        diffs_code.append((cle_pc,))
for cle in ("fichiers_modele", "reglages", "chargement", "format", "lecture"):
    if ra.get(cle) != rb.get(cle):
        diffs_code.append((cle,))
if ra["chemin"]["chargement"] != rb["chemin"]["chargement"]:
    diffs_code.append(("chemin", "chargement"))
for cle in ("empreinte_poids", "repere_precision"):
    if ra["production"][cle] != rb["production"][cle]:
        diffs_code.append(("production", cle))
if m_a["versions"] != m_b["versions"]:
    diffs_code.append(("versions",))
controle("comparaison du code refaite : aucune différence", not diffs_code, str(diffs_code[:5]))
n_npz = sum(1 for e in ra["production"]["episodes"] if e.get("tableaux_sha256"))
print(f"     fichiers npz comparés par empreinte : {n_npz} ; épisodes comparés : "
      f"{ {p: len(ra[p]['episodes']) for p in PHASES_COMPAREES} }")

print("\n== 3. Comparaison profonde des résumés (plus stricte)")
toutes = list(differences(ra, rb))
permises = [d for d in toutes if any(part.split("[")[0] in DESCRIPTIFS for part in d[0].split("/"))]
autres = [d for d in toutes if d not in permises]
print(f"     chemins différents : {len(toutes)} ; dans les champs descriptifs (durée, débit, pic de mémoire, "
      f"projection d'heures) : {len(permises)} ; ailleurs : {len(autres)}")
for d in permises[:60]:
    print("       descriptif :", d)
for d in autres[:30]:
    print("       AUTRE :", d)
controle("aucune différence hors des champs descriptifs", not autres)

print("\n== 4. Fichiers de diag/ (hors enveloppe run_id et manifeste_sha256)")
noms_a = sorted(p.name for p in (RACINE / "diag" / A).iterdir() if not p.name.endswith(".sha256"))
noms_b = sorted(p.name for p in (RACINE / "diag" / B).iterdir() if not p.name.endswith(".sha256"))
controle("mêmes noms de fichiers (B a en plus la comparaison)",
         sorted(set(noms_b) - set(noms_a)) == [f"comparaison-{A}.json"] and set(noms_a) <= set(noms_b))
diff_fichiers = []
for nom in noms_a:
    if nom == "resume.json":
        continue
    x = verifier_resultat(RACINE, RACINE / "diag" / A / nom)["resultat"]
    y = verifier_resultat(RACINE, RACINE / "diag" / B / nom)["resultat"]
    if x != y:
        diff_fichiers.append(nom)
controle(f"{len(noms_a) - 1} fichiers identiques entre A et B (trajectoires, environnement, tests)", not diff_fichiers,
         str(diff_fichiers))

print("\n== 5. Lectures et durées")
controle("lecture de B = lecture de A", ra["lecture"] == rb["lecture"])
print(f"     durée A {ra['duree_s']:.1f} s ; durée B {rb['duree_s']:.1f} s")
print(f"     pics de mémoire A/B : logique {ra['logique']['memoire_max_go']}/{rb['logique']['memoire_max_go']} ; "
      f"contrôle positif {ra['controle_positif']['memoire_max_go']}/{rb['controle_positif']['memoire_max_go']} ; "
      f"chemin {ra['chemin']['memoire_max_go']}/{rb['chemin']['memoire_max_go']} ; contrôle positif du chemin "
      f"{ra['controle_positif_chemin']['memoire_max_go']}/{rb['controle_positif_chemin']['memoire_max_go']} ; "
      f"production {ra['production']['memoire_max_go']}/{rb['production']['memoire_max_go']} ; "
      f"débit {ra['debit']['memoire_max_go']}/{rb['debit']['memoire_max_go']}")

print("\n== Bilan :", "P7 conforme au recalcul" if not ECHECS else f"{len(ECHECS)} échec(s) : {ECHECS}")
sys.exit(1 if ECHECS else 0)
