#!/bin/sh
# Recalcul 10 (juge R13, T0.4 v3) : liste des sha256 recalculés de tous les fichiers des deux runs (manifestes,
# résultats de diag/) et des deux dossiers de traces, chacun comparé à son compagnon (« = compagnon » si égal).
# À lancer depuis la racine du clone.
set -u
for d in runs/20261006-114025-validation-reelle runs/20261006-115440-validation-reelle \
         diag/20261006-114025-validation-reelle diag/20261006-115440-validation-reelle; do
  echo "== $d"
  for f in $(ls "$d" | grep -v '\.sha256$' | sort); do
    h=$(sha256sum "$d/$f" | cut -d' ' -f1)
    c=$(cut -d' ' -f1 "$d/$f.sha256")
    if [ "$h" = "$c" ]; then etat="= compagnon"; else etat="DIFFÉRENT DU COMPAGNON ($c)"; fi
    echo "$h  $d/$f  $etat"
  done
done
for d in traces/t04-20261006-120752-qRPl traces/t04-instance-54476244-20261006-121128; do
  echo "== $d (empreintes.sha256 : $(sha256sum "$d/empreintes.sha256" | cut -d' ' -f1))"
  (cd "$d" && sha256sum -c empreintes.sha256 | sed 's/^/   /')
  (cd "$d" && sha256sum $(ls | grep -v '^empreintes.sha256$') | sed 's/^/   /')
done
