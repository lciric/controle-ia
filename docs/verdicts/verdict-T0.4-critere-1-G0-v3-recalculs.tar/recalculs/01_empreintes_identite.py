"""Recalcul 01 (juge R13, T0.4 v3) : empreintes, chaîne des résultats, identité des runs.

À lancer depuis la racine du clone, avec PYTHONPATH=src :
    python <ce script>
Lecture seule. Imprime chaque contrôle et « ÉCHEC » s'il ne passe pas.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

from controle_ia.harnais.validation_reelle import (CHEMINS_GELES, CONFIG_REELLE, taches, tests_conformes)
from controle_ia.manifeste import config_canonique, graines, lire_manifeste, verifier_resultat
from controle_ia.scellement import empreinte, verifier, verifier_arbre

RACINE = Path(".").resolve()
RUN_A = "20261006-114025-validation-reelle"
RUN_B = "20261006-115440-validation-reelle"
PREREG = "prereg/T0.4-validation-modele-reel-v3.md"
PREREG_SHA = "4f711cd3a58182856c804e6652ec92c1aaab865fe9b595ea1d6be65757b8ed5f"
PROCEDURE = "docs/procedures/validation-T0.4-modele-reel-v4.md"
PROCEDURE_SHA = "4482f7cc66e60f30870390fb82640cec9497eb43f9119bd09d33d58ec21f73d8"
COMMIT_CITE = "b6ab5d15e76972a70e7ffc90cce4dbe280d03061"
REVISION = "0e9e39f249a16976918f6564b8830bc894c89659"
ENTROPIE = 86918527404142130934456531865900787761
ECHECS = []


def controle(nom: str, ok: bool, detail: str = "") -> None:
    print(f"{'OK   ' if ok else 'ÉCHEC'} {nom}{' : ' + detail if detail else ''}")
    if not ok:
        ECHECS.append(nom)


def git(*args) -> subprocess.CompletedProcess:
    return subprocess.run(["git", "--no-optional-locks", "-C", str(RACINE), *args], capture_output=True, text=True)


print("== 1. Préenregistrement et procédure")
controle("préenregistrement : empreinte compagnon", verifier(PREREG) == PREREG_SHA, empreinte(PREREG))
controle("procédure v4 : empreinte compagnon", verifier(PROCEDURE) == PROCEDURE_SHA, empreinte(PROCEDURE))
commit_scellement = git("log", "--diff-filter=A", "-1", "--format=%H", "--", PREREG + ".sha256").stdout.strip()
print(f"     commit de scellement (ajout du compagnon) : {commit_scellement}")
sha_au_scellement = hashlib.sha256(git("show", f"{commit_scellement}:{PREREG}").stdout.encode("utf-8")).hexdigest()
controle("préenregistrement au commit de scellement = texte scellé", sha_au_scellement == PREREG_SHA, sha_au_scellement)
for script, attendu in (("scripts/amorce_instance_t04.sh",
                         "6d34fb18a2e21c83cd5dbb4627f30195838c15edfc2eed581f0d1674b96c6f19"),
                        ("scripts/validation_t04_instance.sh",
                         "ae7050907c8062b015cf868569953906042e8b3fcf50441cd9ae745f79e2aefd")):
    h = hashlib.sha256(subprocess.run(["git", "--no-optional-locks", "-C", str(RACINE), "show",
                                       f"{commit_scellement}:{script}"], capture_output=True).stdout).hexdigest()
    controle(f"{script} au commit de scellement", h == attendu, h)

print("\n== 2. Arbre gelé")
for nom, c in (("commit de scellement", commit_scellement), ("HEAD du clone", "HEAD")):
    r = git("diff", "--quiet", COMMIT_CITE, c, "--", *CHEMINS_GELES)
    controle(f"arbre gelé identique au code cité ({nom})", r.returncode == 0, f"code de retour {r.returncode}")
controle("code cité ancêtre du commit de scellement",
         git("merge-base", "--is-ancestor", COMMIT_CITE, commit_scellement).returncode == 0)

print("\n== 3. Manifestes")
manifestes = {}
for run in (RUN_A, RUN_B):
    chemin = f"runs/{run}/manifeste.json"
    m, sha = lire_manifeste(chemin)
    manifestes[run] = m
    print(f"     {run} : manifeste {sha}")
    controle(f"{run} : décisif", m["decisif"] is True)
    controle(f"{run} : dépôt propre au lancement", m["depot_propre"] is True)
    controle(f"{run} : réserves du manifeste vides", m["reserves"] == [], str(m["reserves"]))
    controle(f"{run} : préenregistrement cité", m["preenregistrement"] == {"chemin": PREREG, "sha256": PREREG_SHA},
             json.dumps(m["preenregistrement"]))
    r = git("diff", "--quiet", COMMIT_CITE, m["commit"], "--", *CHEMINS_GELES)
    controle(f"{run} : commit {m['commit'][:12]}, arbre gelé identique au code cité", r.returncode == 0)
    anc = git("merge-base", "--is-ancestor", commit_scellement, m["commit"]).returncode == 0
    controle(f"{run} : commit de lancement = commit de scellement ou postérieur", anc,
             "égal" if m["commit"] == commit_scellement else f"postérieur : {git('log', '-1', '--format=%s', m['commit']).stdout.strip()[:100]}")
    attendue = dict(CONFIG_REELLE, revision=REVISION)
    controle(f"{run} : configuration = CONFIG_REELLE du code cité + révision", m["config"] == attendue)
    controle(f"{run} : empreinte de configuration", hashlib.sha256(config_canonique(attendue)).hexdigest()
             == m["config_sha256"], m["config_sha256"])
    entropies = {g["entropie"] for g in m["graines"].values()}
    controle(f"{run} : entropie citée, seule", entropies == {str(ENTROPIE)}, str(entropies))
    controle(f"{run} : graines = dérivation des tâches de la configuration à l'entropie citée",
             m["graines"] == graines(taches(attendue), ENTROPIE), f"{len(m['graines'])} tâches")
    print(f"     versions : {json.dumps(m['versions'], ensure_ascii=False)}")
controle("A et B : même empreinte de configuration",
         manifestes[RUN_A]["config_sha256"] == manifestes[RUN_B]["config_sha256"])
controle("A et B : mêmes graines", manifestes[RUN_A]["graines"] == manifestes[RUN_B]["graines"])
controle("A et B : mêmes versions", manifestes[RUN_A]["versions"] == manifestes[RUN_B]["versions"])
print(f"     commit A : {manifestes[RUN_A]['commit']} ; commit B : {manifestes[RUN_B]['commit']}")

print("\n== 4. Résultats : empreintes compagnons et chaîne vers le manifeste (verifier_resultat du code cité)")
for run in (RUN_A, RUN_B):
    dossier = RACINE / "diag" / run
    fichiers = sorted(p for p in dossier.iterdir() if not p.name.endswith(".sha256"))
    compagnons = sorted(p for p in dossier.iterdir() if p.name.endswith(".sha256"))
    controle(f"{run} : un compagnon par fichier", len(fichiers) == len(compagnons)
             and all(Path(str(p) + ".sha256").is_file() for p in fichiers), f"{len(fichiers)} fichiers")
    ok = 0
    for p in fichiers:
        try:
            corps = verifier_resultat(RACINE, p)
            if corps["run_id"] == run:
                ok += 1
            else:
                controle(f"{p.name} : run_id", False, corps["run_id"])
        except Exception as e:                       # noqa: BLE001
            controle(f"{p.relative_to(RACINE)} : chaîne", False, str(e))
    controle(f"{run} : chaîne vérifiée pour tous les résultats", ok == len(fichiers), f"{ok}/{len(fichiers)}")
    print(f"     {run} : resume.json {empreinte(dossier / 'resume.json')}")
    noms = {p.name for p in fichiers}
    controle(f"{run} : aucun arret.json", "arret.json" not in noms)
    controle(f"{run} : aucun arret-comparaison", not any(n.startswith("arret-comparaison") for n in noms))
cmp_ = RACINE / "diag" / RUN_B / f"comparaison-{RUN_A}.json"
print(f"     comparaison : {empreinte(cmp_)}")

print("\n== 5. Sortie des tests (P0)")
for run in (RUN_A, RUN_B):
    t = verifier_resultat(RACINE, RACINE / "diag" / run / "tests-instance.json")["resultat"]
    print(f"     {run} : dernière ligne {t['derniere_ligne']!r}")
    controle(f"{run} : P0 (206 réussis, rien d'autre)", tests_conformes(t["sortie"], 206)
             and t["derniere_ligne"] == t["sortie"].strip().splitlines()[-1])
    trace = (RACINE / "traces/t04-20261006-120752-qRPl/tests.txt").read_text(encoding="utf-8")
    controle(f"{run} : sortie scellée = sortie des traces", t["sortie"] == trace)
    texte = t["sortie"]
    for mot in ("failed", "error", "skipped", "deselected", "xfail", "xpass"):
        controle(f"{run} : sortie sans « {mot} »", mot not in texte.lower())

print("\n== 6. Traces et arbre")
for d in ("traces/t04-20261006-120752-qRPl", "traces/t04-instance-54476244-20261006-121128"):
    r = subprocess.run(["sha256sum", "-c", "empreintes.sha256"], cwd=RACINE / d, capture_output=True, text=True)
    controle(f"{d} : empreintes.sha256", r.returncode == 0, r.stdout.strip().replace("\n", " ; "))
problemes = verifier_arbre(RACINE)
controle("verifier-arbre du clone", not problemes, f"{len(problemes)} problème(s)")
for p in problemes[:20]:
    print("     ", p)

print("\n== Bilan :", "tout conforme" if not ECHECS else f"{len(ECHECS)} échec(s) : {ECHECS}")
sys.exit(1 if ECHECS else 0)
