"""Recalcul 12 (juge R13, T0.4 v3) : zéros exacts et niveaux des écarts, par phase et par zone (contexte, zone
générée), y compris les deux contrôles positifs ; domaines des contrôles positifs. À lancer depuis la racine du clone,
avec PYTHONPATH=src : python <ce script> <run>"""
import statistics
import sys
from pathlib import Path

from controle_ia.manifeste import verifier_resultat

R = verifier_resultat(Path("."), Path("diag") / sys.argv[1] / "resume.json")["resultat"]
C = ("7", "15", "23")
for phase in ("logique", "controle_positif", "chemin", "controle_positif_chemin", "production"):
    if phase.startswith("controle"):
        profs = [e["profils"][k] for e in R[phase]["episodes"] for k in e["profils"]]
    else:
        profs = [e["equivalence"]["profils"][k] for e in R[phase]["episodes"] if e["equivalence"]["ecarts"]
                 for k in e["equivalence"]["profils"]]
    for z in ("contexte", "generee"):
        nuls = {c: sum(p[c][z]["nuls"] for p in profs) for c in C}
        tot = {c: sum(p[c][z]["jetons"] for p in profs) for c in C}
        q50 = statistics.median(p[c][z]["q50"] for p in profs for c in C)
        mx = max(p[c][z]["max"] for p in profs for c in C)
        print(f"{phase:>24} {z:>8} : nuls/positions par couche {[(nuls[c], tot[c]) for c in C]} ; "
              f"médiane des q50 par action et couche {q50:.3g} ; maximum {mx:.3g}")
    ctx = max(p["7"]["contexte"]["jetons"] for p in profs)
    gen = max(p["7"]["generee"]["jetons"] for p in profs)
    print(f"{phase:>24} domaine : contexte comparé ≤ {ctx}, générés relus ≤ {gen}, plus long contexte rempli "
          f"{R[phase]['debit']['longueur_remplie_max']}")
