"""Recalcul 04 (juge R13, T0.4 v3) : valeurs que le préenregistrement confie au juge, descriptifs, recoupements.

- rapport au repère ρ_ℓ ; normalisations en double précision (logique) ; chargement du chemin ;
- séparation entre D1 et l'arrondi, maximum du contexte des contrôles positifs ;
- domaines du chemin et de la production ; part de la zone générée de chaque action comparée de la production ;
- sondes d'audit ; panne de mémoire du débit ;
- P1 (format, date, fichiers du modèle, mémoires) et recoupement des empreintes des fichiers avec la v1 et la v2 ;
- recoupement des rapports avec les trajectoires écrites (contexte = début de l'action ; zone générée relue = m) ;
- repère (nombre de jetons recoupé avec les trajectoires de la logique), maxima de la production, débit, mémoire,
  réglages relus, noyaux permis, durées ; ordres de grandeur attendus contre observés.

À lancer depuis la racine du clone, avec PYTHONPATH=src : python <ce script> <run> [<sortie JSON>]
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

from controle_ia.manifeste import verifier_resultat

RACINE = Path(".").resolve()
RUN = sys.argv[1]
SORTIE = sys.argv[2] if len(sys.argv) > 2 else None
COUCHES = ("7", "15", "23")
ECHECS: list[str] = []
V: dict = {}


def controle(nom: str, ok: bool, detail: str = "") -> bool:
    print(f"{'OK   ' if ok else 'ÉCHEC'} {nom}{' : ' + detail if detail else ''}")
    if not ok:
        ECHECS.append(nom)
    return ok


def k_de(n: int) -> int:
    return n - math.floor(0.99 * (n - 1))


def trajectoire(prefixe: str, ep: str) -> dict:
    return verifier_resultat(RACINE, RACINE / "diag" / RUN / f"{prefixe}-{ep}-trajectoire.json")["resultat"]


R = verifier_resultat(RACINE, RACINE / "diag" / RUN / "resume.json")["resultat"]
prod = R["production"]
rep = prod["repere_precision"]

print("== 1. Chargements (logique : 65 normalisations en double précision ; chemin : torch.float32, 0)")
print("     logique :", R["chargement"])
print("     chemin  :", R["chemin"]["chargement"])
controle("logique : 65 normalisations en double précision, poids torch.float64",
         R["chargement"]["normalisations_en_double"] == 65 and R["chargement"]["type_des_poids"] == "torch.float64")
controle("chemin : poids torch.float32, 0 normalisation en double précision",
         R["chemin"]["chargement"]["type_des_poids"] == "torch.float32"
         and R["chemin"]["chargement"]["normalisations_en_double"] == 0)
controle("attention « sdpa » aux deux chargements",
         R["chargement"]["attention"] == "sdpa" and R["chemin"]["chargement"]["attention"] == "sdpa")
V["chargements"] = {"logique": R["chargement"], "chemin": R["chemin"]["chargement"]}

print("\n== 2. Rapport au repère ρ_ℓ = plus grand 99e centile par action de la production / 99e centile du repère")
actions = [(e["episode"], cle, e["equivalence"]) for e in prod["episodes"] if e["equivalence"]["ecarts"]
           for cle in e["equivalence"]["ecarts"]]
rho = {}
for c in COUCHES:
    ep, cle, r = max(actions, key=lambda x: x[2]["ecarts_q99"][x[1]][c])
    q = r["ecarts_q99"][cle][c]
    rho[c] = q / rep[c]["q99"]
    print(f"     couche {c} : {q:.6g} ({ep}, action {cle}) / {rep[c]['q99']:.6g} = ρ {rho[c]:.4f}")
controle("ρ_ℓ ≤ 3 à chaque couche (ligne de table « P4 conforme, ρ > 3 » non applicable)", all(x <= 3 for x in rho.values()))
print(f"     ρ_ℓ sous 1/3 (descriptif, jamais une réserve par lui-même) : "
      f"{[c for c in COUCHES if rho[c] < 1 / 3] or 'aucune couche'}")
V["rho"] = rho

print("\n== 3. Maxima de la production par couche, localisation, rapport au maximum du repère")
loc = {}
for c in COUCHES:
    ep, cle, r = max(actions, key=lambda x: x[2]["ecarts"][x[1]][c])
    p = r["profils"][cle][c]
    zone = "zone générée" if p["generee"].get("max", -1) >= p["contexte"].get("max", -1) else "contexte"
    ligne = r["lignes"][cle]
    loc[c] = {"max": r["ecarts"][cle][c], "episode": ep, "action": cle, "zone": zone, "remplissage": ligne["remplissage"],
              "finie_avant": ligne["finie_avant"], "rapport_max_repere": r["ecarts"][cle][c] / rep[c]["max"]}
    print(f"     couche {c} : maximum {loc[c]['max']:.6g} ({ep}, action {cle}, {zone}, remplissage {ligne['remplissage']}) ;"
          f" maximum du repère {rep[c]['max']:.6g} ; rapport {loc[c]['rapport_max_repere']:.4f}")
V["maxima_production"] = loc
q99_gen = {c: max(r["profils"][cle][c]["generee"]["q99"] for _, cle, r in actions) for c in COUCHES}
q50_gen = {c: sorted(r["profils"][cle][c]["generee"]["q50"] for _, cle, r in actions)[len(actions) // 2] for c in COUCHES}
print(f"     zone générée de la production : plus grand 99e centile par action {q99_gen} ; médiane des q50 par action {q50_gen}")
remplies = [(ep, cle) for ep, cle, r in actions if r["lignes"][cle]["remplissage"] > 0]
ctx_rempli = max((r["profils"][cle][c]["contexte"]["max"] for ep, cle, r in actions for c in COUCHES
                  if r["lignes"][cle]["remplissage"] > 0), default=None)
print(f"     actions remplies à gauche : {len(remplies)} ; maximum du contexte sur ces actions : {ctx_rempli!r}")
V["production_contexte_rempli_max"] = ctx_rempli

print("\n== 4. Contrôles positifs : séparation entre D1 et l'arrondi, maximum du contexte")
for cle_pc, phase, tau in (("controle_positif", "logique", 1e-4), ("controle_positif_chemin", "chemin", 3e-3)):
    b = R[cle_pc]["bilan"]
    sep = b["min_des_maxima"] / R[phase]["equivalence"]["ecart_max"]
    print(f"     {cle_pc} : minimum des maxima {b['min_des_maxima']:.6g} ; maximum de la phase {phase} "
          f"{R[phase]['equivalence']['ecart_max']:.6g} ; séparation {sep:.4g} ; contexte {b['max_contexte']:.6g} "
          f"(seuil {tau}) ; {b['vus']}/{b['comparables']} vus")
    controle(f"{cle_pc} : maximum du contexte ≤ seuil de sa phase (ligne de réserve non applicable)", b["max_contexte"] <= tau)
    V[f"separation_{cle_pc}"] = sep

print("\n== 5. Domaines observés")
for phase in ("logique", "chemin", "production"):
    d = R[phase]["equivalence"]["domaine"]
    print(f"     {phase} : {d} ; plus long contexte rempli d'un lot : {R[phase]['debit']['longueur_remplie_max']}")
for cle_pc in ("controle_positif", "controle_positif_chemin"):
    print(f"     {cle_pc} : plus long contexte rempli d'un lot : {R[cle_pc]['debit']['longueur_remplie_max']}")
V["domaines"] = {p: dict(R[p]["equivalence"]["domaine"], longueur_remplie_max=R[p]["debit"]["longueur_remplie_max"])
                 for p in ("logique", "chemin", "production")}
print(f"     production au-delà du domaine strict du chemin : contexte comparé {R['production']['equivalence']['domaine']['contexte_max']}"
      f" contre {R['chemin']['equivalence']['domaine']['contexte_max']} ; contexte rempli "
      f"{R['production']['debit']['longueur_remplie_max']} contre {R['chemin']['debit']['longueur_remplie_max']} ; "
      f"générés relus {R['production']['equivalence']['domaine']['generes_relus_max']} contre "
      f"{R['chemin']['equivalence']['domaine']['generes_relus_max']}")

print("\n== 6. Part de la zone générée, actions comparées de la production (n − 1 positions lues, m − 1 décalées)")
lignes = []
for ep, cle, r in actions:
    n = r["positions_capturees"][cle]
    lc = r["longueurs_contexte"][cle]
    m = n - lc
    k = k_de(n - 1)
    zone = r["controle_negatif_zone_generee"][cle]
    lignes.append({"episode": ep, "action": cle, "n": n, "lc": lc, "m": m, "part_decalee": (m - 1) / (n - 1),
                   "k": k, "marge": (m - 1) - k, "q99_decale_min": min(zone[c]["q99"] for c in COUCHES),
                   "remplissage": r["lignes"][cle]["remplissage"]})
lignes.sort(key=lambda x: x["part_decalee"])
for x in lignes:
    print(f"     {x['episode']:>10} {x['action']:>4} : n {x['n']:4d}, contexte {x['lc']:4d}, m {x['m']:3d} ; "
          f"part (m−1)/(n−1) {x['part_decalee']:.4f} ; k(n−1) {x['k']:2d} ; marge {x['marge']:3d} ; "
          f"q99 décalé (min des couches) {x['q99_decale_min']:.4f}")
print(f"     part minimale {lignes[0]['part_decalee']:.4f}, maximale {lignes[-1]['part_decalee']:.4f} ; marge minimale "
      f"{min(x['marge'] for x in lignes)} ; actions en échec de P5 : "
      f"{R['production']['equivalence']['controle_negatif']['echecs']}")
V["parts"] = lignes

print("\n== 7. Sondes d'audit et panne de mémoire du débit")
for phase in ("logique", "chemin", "production"):
    acts = [(e["episode"], cle, e["equivalence"]) for e in R[phase]["episodes"] if e["equivalence"]["ecarts"]
            for cle in e["equivalence"]["ecarts"]]
    s = [r["sondes"][cle] for _, cle, r in acts]
    ok = all(x["tableaux_distincts"] for x in s) and all(x["ulp_vu"] for x in s)
    controle(f"{phase} : sondes d'audit (tableaux distincts et ulp vu, {len(s)} actions)", ok)
controle("débit : aucune panne de mémoire consignée", R["debit"]["panne_memoire"] is False)
controle("débit : trois lots mesurés (1, 8, 32), sans erreur",
         [m["taille_lot"] for m in R["debit"]["mesures"]] == [1, 8, 32]
         and all("erreur" not in m for m in R["debit"]["mesures"]))

print("\n== 8. P1 : format, date, fichiers du modèle, mémoires")
f = R["format"]
controle("garde de format vérifiée", f["verifie"] is True, f"format {f['format']}, {f['tours']} tours, {f['jetons']} jetons")
controle("ouverture décodée avec « Today Date: 26 Jul 2024 »", "Today Date: 26 Jul 2024" in f["ouverture"])
fm = R["fichiers_modele"]
controle("fichiers du modèle : tous conformes aux empreintes publiées", all(x["conforme"] for x in fm.values()),
         f"{len(fm)} fichiers, dont {sum(n.endswith('.safetensors') for n in fm)} de poids")
controle("mémoire de la carte ≥ 130 Gio", R["reglages"]["memoire_carte_gio"] >= 130, str(R["reglages"]["memoire_carte_gio"]))
controle("mémoire vive effective ≥ 96 Go", R["memoire_vive_go"]["effective_go"] >= 96, json.dumps(R["memoire_vive_go"]))
for nom_run in ("20261005-144628-validation-reelle", "20261005-102042-validation-reelle"):
    p = RACINE / "diag" / nom_run / "arret.json"
    try:
        partiel = verifier_resultat(RACINE, p)["resultat"]["partiel"]
    except Exception as e:                                         # noqa: BLE001
        print(f"     {nom_run} : illisible ({e})")
        continue
    autres = partiel.get("fichiers_modele") or {}
    communs = sorted(set(autres) & set(fm))
    egaux = [n for n in communs if autres[n]["sha256"] == fm[n]["sha256"]]
    controle(f"recoupement avec {nom_run} (même révision) : empreintes sha256 des fichiers égales",
             bool(communs) and len(egaux) == len(communs) and set(autres) == set(fm), f"{len(egaux)}/{len(communs)}")
    g = (partiel.get("format") or {}).get("gabarit_sha256")
    controle(f"recoupement avec {nom_run} : même gabarit", g == f["gabarit_sha256"], str(g)[:16])

print("\n== 9. Recoupement des rapports avec les trajectoires écrites")
probs = []
for phase, prefixe in (("logique", "logique"), ("chemin", "chemin"), ("production", "production")):
    for e in R[phase]["episodes"]:
        r = e["equivalence"]
        if not r["ecarts"]:
            continue
        t = trajectoire(prefixe, e["episode"])
        par_cle = {f"{a['agent']},{a['pas']}": a for tr in t["transcriptions"] for a in tr["actions"]}
        for cle in r["ecarts"]:
            a = par_cle[cle]
            lc, n = r["longueurs_contexte"][cle], r["positions_capturees"][cle]
            m, n_gen = n - lc, len(a["ids"])
            attendu = n_gen if r["lignes"][cle]["finie_avant"] else n_gen - 1
            if lc != a["debut"] or a["fin"] - a["debut"] != n_gen or m != attendu:
                probs.append((phase, e["episode"], cle, lc, a["debut"], m, n_gen, r["lignes"][cle]["finie_avant"]))
controle("contexte capturé = début de l'action ; zone générée relue = jetons générés (ligne finie avant) ou un de moins",
         not probs, f"{len(probs)} écart(s) {probs[:3]}")
probs = []
for cle_pc, prefixe in (("controle_positif", "controle-positif"), ("controle_positif_chemin", "controle-positif-chemin")):
    for e in R[cle_pc]["episodes"]:
        t = trajectoire(prefixe, e["episode"])
        par_cle = {f"{a['agent']},{a['pas']}": a for tr in t["transcriptions"] for a in tr["actions"]}
        for cle, prof in e["profils"].items():
            a = par_cle[cle]
            lc, m = prof["7"]["contexte"]["jetons"], prof["7"]["generee"]["jetons"]
            if lc != a["debut"] or m not in (len(a["ids"]), len(a["ids"]) - 1):
                probs.append((cle_pc, e["episode"], cle, lc, a["debut"], m, len(a["ids"])))
controle("contrôles positifs : contexte = début de l'action, zone générée = jetons générés ou un de moins", not probs,
         str(probs[:3]))
jetons_ref = sum(len(tr["ids"]) for ep in ("episode-1", "episode-6") for tr in trajectoire("logique", ep)["transcriptions"])
controle("repère : nombre de jetons par couche = longueur des transcriptions des épisodes 1 et 6 de la logique",
         all(rep[c]["jetons"] == jetons_ref for c in COUCHES), f"{jetons_ref} jetons")
lg = {(e["episode"]): sum(len(tr["ids"]) for tr in trajectoire("production", e["episode"])["transcriptions"])
      for e in prod["episodes"]}
controle("production : jetons par épisode = trajectoires", all(lg[e["episode"]] == e["jetons"] for e in prod["episodes"]))
longueurs = [len(tr["ids"]) for k in range(16) for tr in trajectoire("production", f"episode-{k}")["transcriptions"]]
tronquees = [min(x, 2048) for x in longueurs]
print(f"     débit : contextes (32 transcriptions de production tronquées à 2 048) : moyenne {sum(tronquees) / 32:.1f}, "
      f"maximum {max(tronquees)} ; lot de 8 : maximum {max(tronquees[:8])} ; lot de 1 : {tronquees[0]}")
V["debit_contextes"] = {"moyenne_32": sum(tronquees) / 32, "max_32": max(tronquees), "max_8": max(tronquees[:8]),
                        "lot_1": tronquees[0]}

print("\n== 10. Repère, débit, mémoire, réglages, noyaux, durée")
for c in COUCHES:
    print(f"     repère couche {c} : q50 {rep[c]['q50']:.5f}, q99 {rep[c]['q99']:.5f}, maximum {rep[c]['max']:.5f} "
          f"({rep[c]['jetons']} jetons)")
for ph in ("logique", "controle_positif", "chemin", "controle_positif_chemin", "production"):
    d = R[ph]["debit"]
    print(f"     {ph} : pic de mémoire {R[ph]['memoire_max_go']} Go ; génération {d['jetons_generes_par_s']:.1f} jetons/s ; "
          f"passe unique {d['jetons_passe_unique_par_s']:.0f} jetons/s ; générés {d['jetons_generes']} ; "
          f"remplissage {d['jetons_remplissage']} ; lignes finies avant {d['lignes_finies_avant']} ; "
          f"plus long contexte rempli {d['longueur_remplie_max']}")
print(f"     débit (noyau {R['debit']['noyau_attention']}) : pic {R['debit']['memoire_max_go']} Go ; "
      + " ; ".join(f"lot {m['taille_lot']} : {m['jetons_par_s']:.1f} jetons/s ({m['jetons_generes']} jetons, "
                   f"{m['duree_s']:.2f} s, contexte moyen {m['contexte_moyen']:.0f})" for m in R["debit"]["mesures"]))
print(f"     projection : {prod['projection_heures']} ; stockage : {json.dumps(prod['stockage']['projection'], ensure_ascii=False)}")
print(f"     octets par jeton et couche : {prod['stockage']['octets_par_jeton_et_couche']} ; fichiers par jeton : "
      f"{prod['stockage']['fichiers_par_jeton_octets']}")
print(f"     réglages relus : {json.dumps(R['reglages']['relus'], ensure_ascii=False)}")
print(f"     carte {R['reglages']['carte']}, capacité {R['reglages']['capacite']}, pilote {R['reglages']['pilote']}, "
      f"CUDA {R['reglages']['cuda']}, cuDNN {R['reglages']['cudnn']}, torch {R['reglages']['torch']}, espace cuBLAS "
      f"{R['reglages']['cublas_workspace']}")
relus = R["reglages"]["relus"]
controle("réglages relus : déterministe, TF32 coupé, réductions réduites coupées, cuDNN déterministe sans banc d'essai, 1 fil",
         relus["algorithmes_deterministes"] and not relus["tf32_produits"] and not relus["tf32_cudnn"]
         and not relus["reduction_reduite_bf16"] and not relus["reduction_reduite_fp16"] and relus["cudnn_deterministe"]
         and not relus["cudnn_banc_essai"] and relus["fils"] == 1 and relus["precision_produits_simple"] == "highest")
for ph in ("logique", "chemin", "production"):
    print(f"     noyaux permis ({ph}, noyau {R[ph]['noyau_attention']}) : {R[ph]['noyaux_permis']}")
    controle(f"{ph} : seul « math » permis, sans réduction en demi-précision",
             R[ph]["noyaux_permis"] == {"cudnn": False, "flash": False, "math": True, "memoire_efficace": False,
                                        "reduction_demi_dans_math": False} and R[ph]["noyau_attention"] == "math")
controle("débit au noyau « math »", R["debit"]["noyau_attention"] == "math")
print(f"     durée du run : {R['duree_s']:.1f} s")

print("\n== 11. Ordres de grandeur attendus (préenregistrement) contre observés")
cnmax = {}
for phase, stat in (("logique", "max"), ("chemin", "max"), ("production", "q99")):
    acts = [(e["equivalence"], cle) for e in R[phase]["episodes"] if e["equivalence"]["ecarts"] for cle in e["equivalence"]["ecarts"]]
    vals = [min(z[c][stat] for c in COUCHES) for r, cle in acts for z in [r["controle_negatif_zone_generee"][cle]] if z]
    cnmax[phase] = (min(vals), max(vals))
attendus = [
    ("P2 (logique, maximum)", "1e-16 à 1e-11", R["logique"]["equivalence"]["ecart_max"], 1e-16, 1e-11),
    ("P2b (minimum des maxima, zone générée)", "1e-2 à 1", R["controle_positif"]["bilan"]["min_des_maxima"], 1e-2, 1),
    ("P3 (min, max par action de l'écart décalé)", "0,1 à 2", cnmax["logique"], 0.1, 2),
    ("C1 (chemin, maximum)", "1e-5 à 5e-4", R["chemin"]["equivalence"]["ecart_max"], 1e-5, 5e-4),
    ("C2 (minimum des maxima, zone générée)", "1e-2 à 1", R["controle_positif_chemin"]["bilan"]["min_des_maxima"], 1e-2, 1),
    ("C3 (min, max par action de l'écart décalé)", "0,1 à 2", cnmax["chemin"], 0.1, 2),
    ("P4 (plus grand 99e centile)", "2e-2 à 1,2e-1", R["production"]["equivalence"]["ecart_q99_max"], 2e-2, 1.2e-1),
    ("P5 (min, max par action du q99 décalé)", "0,3 à 2", cnmax["production"], 0.3, 2),
]
for nom, texte, obs, lo, hi in attendus:
    vals = obs if isinstance(obs, tuple) else (obs,)
    dedans = all(lo <= x <= hi for x in vals)
    print(f"     {nom} : attendu {texte} ; observé {', '.join(f'{x:.4g}' for x in vals)} ; "
          f"{'dans l’ordre attendu' if dedans else 'HORS de l’ordre attendu (descriptif, ne réfute rien)'}")
V["controle_negatif_min_max"] = cnmax

print("\n== Bilan :", "tout conforme" if not ECHECS else f"{len(ECHECS)} échec(s) : {ECHECS}")
if SORTIE:
    Path(SORTIE).write_text(json.dumps(V, indent=1, ensure_ascii=False, default=str) + "\n", encoding="utf-8")
sys.exit(1 if ECHECS else 0)
