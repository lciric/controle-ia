"""Recalcul 09 (juge R13, T0.4 v3) : localisation des extrêmes (maximum de P2 et de C1, plus grand 99e centile de
P4, minima des contrôles positifs et des contrôles négatifs), depuis les données par action du résumé.
À lancer depuis la racine du clone, avec PYTHONPATH=src : python <ce script> <run>"""
import sys
from pathlib import Path

from controle_ia.manifeste import verifier_resultat

R = verifier_resultat(Path("."), Path("diag") / sys.argv[1] / "resume.json")["resultat"]
C = ("7", "15", "23")
for phase, cle_stat in (("logique", "ecarts"), ("chemin", "ecarts"), ("production", "ecarts_q99"), ("production", "ecarts")):
    acts = [(e["episode"], k, e["equivalence"]) for e in R[phase]["episodes"] if e["equivalence"]["ecarts"]
            for k in e["equivalence"]["ecarts"]]
    ep, k, r = max(((ep, k, r) for ep, k, r in acts), key=lambda x: max(x[2][cle_stat][x[1]].values()))
    c = max(C, key=lambda c: r[cle_stat][k][c])
    p = r["profils"][k][c]
    zone = "zone générée" if p["generee"]["max"] >= p["contexte"]["max"] else "contexte"
    print(f"{phase} {cle_stat} : extrême {r[cle_stat][k][c]!r} ({ep}, action ({k}), couche {c}, maximum en {zone}, "
          f"remplissage {r['lignes'][k]['remplissage']}, contexte {r['longueurs_contexte'][k]}, "
          f"positions {r['positions_capturees'][k]})")
    stat = "q99" if phase == "production" else "max"
    ep, k, r = min(((ep, k, r) for ep, k, r in acts), key=lambda x: min(z[stat] for z in x[2]["controle_negatif_zone_generee"][x[1]].values()))
    z = r["controle_negatif_zone_generee"][k]
    c = min(C, key=lambda c: z[c][stat])
    print(f"   contrôle négatif ({stat}) : minimum {z[c][stat]!r} ({ep}, action ({k}), couche {c}, "
          f"{z[c]['au_dessus']}/{z[c]['positions']} positions décalées au-dessus du seuil)")
for cle_pc in ("controle_positif", "controle_positif_chemin"):
    acts = [(e["episode"], k, e["profils"][k]) for e in R[cle_pc]["episodes"] for k in e["profils"]]
    ep, k, prof = min(acts, key=lambda x: min(x[2][c]["generee"]["max"] for c in C))
    c = min(C, key=lambda c: prof[c]["generee"]["max"])
    print(f"{cle_pc} : minimum des maxima {prof[c]['generee']['max']!r} ({ep}, action ({k}), couche {c}, "
          f"{prof[c]['generee']['jetons']} positions générées, contexte {prof[c]['contexte']['jetons']})")
    ep, k, prof = max(acts, key=lambda x: max(x[2][c]["contexte"]["max"] for c in C))
    c = max(C, key=lambda c: prof[c]["contexte"]["max"])
    print(f"   maximum du contexte {prof[c]['contexte']['max']!r} ({ep}, action ({k}), couche {c})")
