"""Recalcul 11 (juge R13, T0.4 v3) : P8, ce que le résumé permet de vérifier sans les fichiers npz (restés sur le disque
de l'instance) : épisodes à activations par jeton conservées, empreintes et tailles des npz, égalité A/B des empreintes,
codage (2 octets par valeur), jetons par épisode. À lancer depuis la racine du clone, avec PYTHONPATH=src."""
from pathlib import Path

from controle_ia.manifeste import verifier_resultat

A, B = "20261006-114025-validation-reelle", "20261006-115440-validation-reelle"
ra = verifier_resultat(Path("."), Path("diag") / A / "resume.json")["resultat"]["production"]
rb = verifier_resultat(Path("."), Path("diag") / B / "resume.json")["resultat"]["production"]
conserves = [e["episode"] for e in ra["episodes"] if e["par_jeton_conserve"]]
print("activations par jeton conservées pour :", conserves, "(attendu : episode-1 et episode-14)")
print("ok :", conserves == ["episode-1", "episode-14"])
for ea, eb in zip(ra["episodes"], rb["episodes"]):
    print(f"  {ea['episode']:>10} : npz {ea['tableaux_sha256'][:16]}… {ea['tableaux_octets']:>10} octets ; "
          f"B identique : {ea['tableaux_sha256'] == eb['tableaux_sha256'] and ea['tableaux_octets'] == eb['tableaux_octets']} ; "
          f"jetons {ea['jetons']}")
s = ra["stockage"]
print("codage :", s["codage"], "; octets par valeur (construction) :", s["octets_par_valeur_construction"],
      "; octets par jeton et couche (épisodes 1 et 14) :", s["octets_par_jeton_et_couche"],
      "; = 2 × largeur", 2 * ra["largeur"], ":", all(x == 2 * ra["largeur"] for x in s["octets_par_jeton_et_couche"]))
print("fichiers par jeton (octets) :", s["fichiers_par_jeton_octets"])
