#!/bin/sh
# Recalcul 06 (juge R13, T0.4 v3) : suite de tests du clone, sur processeur (contrôle de cohérence ; P0 se lit sur la
# sortie de l'instance). Commande lancée depuis la racine du clone ; sortie : 06_tests_processeur_clone.sortie.txt.
PYTHONPATH=src timeout 900 /home/user/controle-ia/.venv/bin/python -m pytest -q -p no:cacheprovider
