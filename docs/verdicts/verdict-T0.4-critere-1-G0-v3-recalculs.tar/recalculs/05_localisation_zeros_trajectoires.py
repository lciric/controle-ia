"""Recalcul 05 (juge R13, T0.4 v3) : audit de symétrie (R4), localisation.

- Empreintes des trajectoires recalculées depuis les fichiers écrits (même formule que `empreinte_episode`), comparées
  aux empreintes du résumé.
- Remplissage de chaque action comparée, recalculé depuis les trajectoires des 8 épisodes de son lot (longueur du
  plus long contexte du lot moins celle du contexte de l'action), comparé au champ `lignes` quand il existe.
- Par phase (logique, chemin, production, et les deux contrôles positifs) : actions dont le contexte est exactement
  nul (à toutes les positions et toutes les couches), selon le remplissage ; maximum du contexte des actions remplies
  et non remplies ; zone générée selon le remplissage ; ligne la plus longue (dernier jeton non relu).

À lancer depuis la racine du clone, avec PYTHONPATH=src : python <ce script> <run>
"""
from __future__ import annotations

import hashlib
import json
import statistics
import sys
from pathlib import Path

from controle_ia.manifeste import verifier_resultat

RACINE = Path(".").resolve()
RUN = sys.argv[1]
COUCHES = ("7", "15", "23")
ECHECS: list[str] = []


def controle(nom: str, ok: bool, detail: str = "") -> None:
    print(f"{'OK   ' if ok else 'ÉCHEC'} {nom}{' : ' + detail if detail else ''}")
    if not ok:
        ECHECS.append(nom)


def traj(prefixe: str, k: int) -> dict:
    return verifier_resultat(RACINE, RACINE / "diag" / RUN / f"{prefixe}-episode-{k}-trajectoire.json")["resultat"]


R = verifier_resultat(RACINE, RACINE / "diag" / RUN / "resume.json")["resultat"]

print("== 1. Empreintes des trajectoires (recalculées depuis les fichiers écrits)")
for phase, prefixe, n_ep in (("logique", "logique", 8), ("chemin", "chemin", 8), ("production", "production", 16),
                             ("controle_positif", "controle-positif", 8),
                             ("controle_positif_chemin", "controle-positif-chemin", 8)):
    emp = {e["episode"]: e["empreintes"]["trajectoire"] for e in R[phase]["episodes"]}
    bons = 0
    for k in range(n_ep):
        t = traj(prefixe, k)
        h = hashlib.sha256(json.dumps(t, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()
        if f"episode-{k}" in emp:
            bons += h == emp[f"episode-{k}"]
    controle(f"{phase} : empreintes de trajectoire égales au résumé", bons == len(emp), f"{bons}/{len(emp)} épisodes résumés")

print("\n== 2. Remplissage recalculé depuis les trajectoires, contexte exactement nul, zone générée")


def contextes_du_lot(prefixe: str, lot: list[int]) -> dict:
    """{(k, i, t): (longueur du contexte, jetons générés, ligne la plus longue ?)} pour les épisodes du lot."""
    par = {}
    ts = {k: traj(prefixe, k) for k in lot}
    for k, t in ts.items():
        for tr in t["transcriptions"]:
            for a in tr["actions"]:
                par[(k, a["agent"], a["pas"])] = (a["debut"], len(a["ids"]))
    sortie = {}
    for (k, i, p), (lc, ng) in par.items():
        autres = [par[(kk, i, p)] for kk in lot]
        L = max(x[0] for x in autres)
        plus_longue = max(x[1] for x in autres)
        sortie[(k, i, p)] = {"lc": lc, "remplissage": L - lc, "generes": ng, "la_plus_longue": ng == plus_longue}
    return sortie


for phase, prefixe, cle_pc in (("logique", "logique", None), ("chemin", "chemin", None),
                               ("production", "production", None), ("controle_positif", "controle-positif", "logique"),
                               ("controle_positif_chemin", "controle-positif-chemin", "chemin")):
    plan = R[phase]["plan_lots"]
    infos = {}
    for lot in plan:
        infos.update(contextes_du_lot(prefixe, lot))
    lignes = []
    desaccords = []
    for e in R[phase]["episodes"]:
        k = int(e["episode"].split("-")[1])
        if cle_pc is None:
            r = e["equivalence"]
            if not r["ecarts"]:
                continue
            profils = r["profils"]
        else:
            profils, r = e["profils"], None
        for cle, prof in profils.items():
            i, p = (int(x) for x in cle.split(","))
            inf = infos[(k, i, p)]
            if r is not None:
                li = r["lignes"][cle]
                if li["remplissage"] != inf["remplissage"] or bool(li["finie_avant"]) == inf["la_plus_longue"]:
                    desaccords.append((e["episode"], cle, li, inf))
            ctx_nul = all(prof[c]["contexte"]["nuls"] == prof[c]["contexte"]["jetons"] for c in COUCHES)
            ctx_max = max(prof[c]["contexte"]["max"] for c in COUCHES)
            gen_max = max(prof[c]["generee"]["max"] for c in COUCHES)
            gen_q50 = statistics.median(prof[c]["generee"]["q50"] for c in COUCHES)
            gen_nuls = sum(prof[c]["generee"]["nuls"] for c in COUCHES)
            lignes.append({"episode": e["episode"], "action": cle, **inf, "ctx_nul": ctx_nul, "ctx_max": ctx_max,
                           "gen_max": gen_max, "gen_q50": gen_q50, "gen_nuls": gen_nuls,
                           "m": prof["7"]["generee"]["jetons"]})
    if cle_pc is None:
        controle(f"{phase} : remplissage et « finie avant » du résumé = trajectoires", not desaccords,
                 f"{len(desaccords)} {desaccords[:2]}")
    remplies = [x for x in lignes if x["remplissage"] > 0]
    non_remplies = [x for x in lignes if x["remplissage"] == 0]
    print(f"\n     {phase} : {len(lignes)} actions ; remplies {len(remplies)} (remplissage {min((x['remplissage'] for x in remplies), default=0)}"
          f" à {max((x['remplissage'] for x in remplies), default=0)}) ; non remplies {len(non_remplies)}")
    for nom, groupe in (("non remplies", non_remplies), ("remplies", remplies)):
        if not groupe:
            continue
        nuls = sum(x["ctx_nul"] for x in groupe)
        print(f"       {nom} : contexte exactement nul pour {nuls}/{len(groupe)} actions ; maximum du contexte "
              f"{max(x['ctx_max'] for x in groupe):.3g} ; zone générée : maximum {max(x['gen_max'] for x in groupe):.3g},"
              f" médiane des q50 {statistics.median(x['gen_q50'] for x in groupe):.3g}, écarts nuls {sum(x['gen_nuls'] for x in groupe)}")
    nul_list = [(x["episode"], x["action"], x["remplissage"], x["lc"]) for x in lignes if x["ctx_nul"]]
    print(f"       actions à contexte exactement nul : {nul_list[:12]}{' …' if len(nul_list) > 12 else ''}")
    longues = [(x["episode"], x["action"], x["generes"], x["m"]) for x in lignes if x["la_plus_longue"]]
    print(f"       lignes les plus longues de leur lot (dernier jeton non relu) : {len(longues)} ; "
          f"m = générés − 1 pour elles : {all(m == g - 1 for _, _, g, m in longues)} ; "
          f"m = générés pour les autres : {all(x['m'] == x['generes'] for x in lignes if not x['la_plus_longue'])}")

print("\n== Bilan :", "tout conforme" if not ECHECS else f"{len(ECHECS)} échec(s) : {ECHECS}")
sys.exit(1 if ECHECS else 0)
