#!/bin/bash
# Recalcul 08 (juge R13, T0.4 v3) : commits faits sur l'instance, fichiers ajoutés, fichiers des runs inchangés depuis.
# Commande lancée avec D = racine du clone ; sortie : 08_historique_commits_instance.sortie.txt.
D=${1:-.}
echo "== Historique des commits de l'instance"; git -C "$D" --no-optional-locks log --format='%H %P %an %ci %s' -6 | cut -c1-230; echo
echo "== Fichiers des runs inchangés depuis les commits de l'instance (git diff vide attendu)"
for c in 29a00cf39bd52ffe2d2c770154aa58cdb0f43ea6:runs/20261006-114025-validation-reelle 29a00cf39bd52ffe2d2c770154aa58cdb0f43ea6:diag/20261006-114025-validation-reelle fc9d851:runs/20261006-115440-validation-reelle fc9d851:diag/20261006-115440-validation-reelle 5e7087a:traces/t04-20261006-120752-qRPl; do
  com=${c%%:*}; p=${c#*:}; n=$(git -C "$D" --no-optional-locks diff --stat "$com" HEAD -- "$p" | wc -l); echo "$p depuis $com : $n ligne(s) de différence"
done; echo
echo "== Fichiers ajoutés par chaque commit de l'instance"
for com in 29a00cf fc9d851 5e7087a; do
  echo "-- $com : $(git -C "$D" --no-optional-locks show --stat --format=%s $com | tail -1)"
  git -C "$D" --no-optional-locks show --name-only --format= $com | sed 's#/[^/]*$##' | sort | uniq -c
done; echo
echo "== Parents"
git -C "$D" --no-optional-locks rev-list --parents -n1 29a00cf; git -C "$D" --no-optional-locks rev-list --parents -n1 fc9d851
git -C "$D" --no-optional-locks rev-list --parents -n1 5e7087a; git -C "$D" --no-optional-locks rev-list --parents -n1 59de002
