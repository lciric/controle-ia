"""Recalcul 02 (juge R13, T0.4 v3) : prédictions P2, P2b, P3, C1, C2, C3, P4, P5, P6, P9 et lectures,
recalculées depuis les données par action du résumé (rapports, profils, ecarts_q99, contrôles négatifs, lignes),
et non depuis les bilans ; puis comparées aux bilans du code et à sa lecture.

Seuils et règles : ceux du préenregistrement scellé (tables « Prédiction » et « Seuil »), écrits ici en dur, sans
les lire dans la configuration du code.

À lancer depuis la racine du clone, avec PYTHONPATH=src :
    python <ce script> <run> [<fichier JSON de sortie>]
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

from controle_ia.harnais.validation_reelle import CONFIG_REELLE, lire
from controle_ia.manifeste import verifier_resultat

RACINE = Path(".").resolve()
RUN = sys.argv[1]
SORTIE = sys.argv[2] if len(sys.argv) > 2 else None
COUCHES = ("7", "15", "23")
# seuils du préenregistrement (section Seuil)
TAU = {"logique": 1e-4, "chemin": 3e-3, "production": 0.2}
STAT = {"logique": "max", "chemin": "max", "production": "q99"}
POS_MIN, ACT_MIN, FRAC_MIN = 4, 10, 0.95
EPISODES_EQ = {"logique": ("episode-1", "episode-6"), "chemin": ("episode-1", "episode-6"),
               "production": ("episode-1", "episode-14")}
LIGNES_ATTENDUES = {"logique": {"episode-1": 1, "episode-6": 6}, "chemin": {"episode-1": 1, "episode-6": 6},
                    "production": {"episode-1": 1, "episode-14": 6}}
ECHECS: list[str] = []
VALEURS: dict = {}


def controle(nom: str, ok: bool, detail: str = "") -> bool:
    print(f"{'OK   ' if ok else 'ÉCHEC'} {nom}{' : ' + detail if detail else ''}")
    if not ok:
        ECHECS.append(nom)
    return ok


def inf_si_nan(x):
    return math.inf if (x is None or x != x) else x


def k_de(n: int) -> int:
    """Nombre de positions qui suffit à atteindre le 99e centile (interpolation linéaire) sur n positions."""
    return n - math.floor(0.99 * (n - 1))


R = verifier_resultat(RACINE, RACINE / "diag" / RUN / "resume.json")["resultat"]
print(f"run {RUN} ; résumé vérifié (chaîne)")

# ------------------------------------------------------------------ phases comparées
for phase in ("logique", "chemin", "production"):
    print(f"\n==== Phase {phase} (seuil {TAU[phase]}, statistique {STAT[phase]})")
    ph = R[phase]
    bil = ph["equivalence"]
    rapports = [(e["episode"], e["equivalence"]) for e in ph["episodes"] if e["equivalence"]["ecarts"]]
    controle(f"{phase} : épisodes comparés = {EPISODES_EQ[phase]}",
             tuple(sorted(ep for ep, _ in rapports)) == tuple(sorted(EPISODES_EQ[phase])),
             str([ep for ep, _ in rapports]))
    actions = [(ep, cle, r) for ep, r in rapports for cle in r["ecarts"]]
    controle(f"{phase} : 40 actions comparées", len(actions) == 40, str(len(actions)))
    for ep, r in rapports:
        controle(f"{phase} {ep} : tolérance et statistique du rapport",
                 r["tolerance"] == TAU[phase] and r["statistique"] == STAT[phase],
                 f"{r['tolerance']} {r['statistique']}")
    # cohérence interne par action et par couche
    incoh = []
    for ep, cle, r in actions:
        pc, lc = r["positions_capturees"][cle], r["longueurs_contexte"][cle]
        for c in COUCHES:
            p = r["profils"][cle][c]
            if set(r["ecarts"][cle]) != set(COUCHES):
                incoh.append((ep, cle, "couches"))
            if r["ecarts"][cle][c] != p["max"]:
                incoh.append((ep, cle, c, "ecarts != profil max"))
            if r["ecarts_q99"][cle][c] != p["q99"]:
                incoh.append((ep, cle, c, "ecarts_q99 != profil q99"))
            if p["jetons"] != pc or p["contexte"]["jetons"] != lc or p["generee"]["jetons"] != pc - lc:
                incoh.append((ep, cle, c, "jetons"))
            mx = max(p["contexte"].get("max", -1.0), p["generee"].get("max", -1.0))
            if mx != p["max"]:
                incoh.append((ep, cle, c, "max != max(contexte, générée)"))
            if p["nuls"] != p["contexte"].get("nuls", 0) + p["generee"].get("nuls", 0):
                incoh.append((ep, cle, c, "nuls"))
            zone = r["controle_negatif_zone_generee"][cle]
            if zone is not None and zone[c]["positions"] != pc - lc - 1:
                incoh.append((ep, cle, c, "positions décalées != m - 1"))
    controle(f"{phase} : cohérence par action (écarts = profil, q99 = profil, jetons, zones, positions décalées)",
             not incoh, f"{len(incoh)} incohérence(s) {incoh[:5]}")

    # --- équivalence : grandeur de la garde
    par_couche_max = {c: max(inf_si_nan(r["ecarts"][cle][c]) for _, cle, r in actions) for c in COUCHES}
    par_couche_q99 = {c: max(inf_si_nan(r["ecarts_q99"][cle][c]) for _, cle, r in actions) for c in COUCHES}
    ecart_max = max(par_couche_max.values())
    q99_max = max(par_couche_q99.values())
    max_ctx = max(inf_si_nan(r["profils"][cle][c]["contexte"]["max"]) for _, cle, r in actions for c in COUCHES
                  if r["profils"][cle][c]["contexte"]["jetons"])
    max_gen = max(inf_si_nan(r["profils"][cle][c]["generee"]["max"]) for _, cle, r in actions for c in COUCHES
                  if r["profils"][cle][c]["generee"]["jetons"])
    grandeur = q99_max if STAT[phase] == "q99" else ecart_max
    print(f"     maximum par couche : {par_couche_max}")
    print(f"     plus grand 99e centile par action, par couche : {par_couche_q99}")
    print(f"     maximum {ecart_max!r} ; plus grand 99e centile {q99_max!r} ; contexte {max_ctx!r} ; "
          f"zone générée {max_gen!r}")
    controle(f"{phase} : bilan du code = recalcul (ecart_max, ecart_q99_max, max_contexte, max_zone_generee)",
             (bil["ecart_max"], bil["ecart_q99_max"], bil["max_contexte"], bil["max_zone_generee"])
             == (ecart_max, q99_max, max_ctx, max_gen))
    controle(f"{phase} : bilan, tolérance {bil['tolerance']} et statistique {bil['statistique']} = préenregistrement",
             bil["tolerance"] == TAU[phase] and bil["statistique"] == STAT[phase])
    equiv_ok = grandeur <= TAU[phase]
    print(f"     grandeur de la garde ({STAT[phase]}) {grandeur!r} {'≤' if equiv_ok else '>'} {TAU[phase]}")
    au_dessus = [(ep, cle, c, r[('ecarts_q99' if STAT[phase] == 'q99' else 'ecarts')][cle][c]) for ep, cle, r in actions
                 for c in COUCHES if not r[('ecarts_q99' if STAT[phase] == 'q99' else 'ecarts')][cle][c] <= TAU[phase]]
    print(f"     actions × couches au-dessus du seuil : {len(au_dessus)} {au_dessus[:5]}")

    # --- couverture (logique, chemin) et lignes
    lignes = [(ep, cle, r["lignes"][cle]) for ep, cle, r in actions]
    remplies = sum(x["remplissage"] > 0 for _, _, x in lignes)
    finies = sum(bool(x["finie_avant"]) for _, _, x in lignes)
    generes = [r["positions_capturees"][cle] - r["longueurs_contexte"][cle] for _, cle, r in actions]
    lignes_ech = sorted({x["ligne"] for _, _, x in lignes})
    mauvaises_lignes = [(ep, cle, x["ligne"]) for ep, cle, x in lignes if x["ligne"] != LIGNES_ATTENDUES[phase][ep]]
    controle(f"{phase} : lignes de l'échantillon = {LIGNES_ATTENDUES[phase]}", not mauvaises_lignes,
             str(mauvaises_lignes[:3]))
    cv = {"actions_remplies": remplies, "actions_finies_avant": finies, "positions_generees_comparees": sum(generes),
          "lignes_echantillon": lignes_ech}
    print(f"     couverture recalculée : {cv}")
    controle(f"{phase} : couverture du code = recalcul", bil["couverture"] == cv, json.dumps(bil["couverture"]))
    couverture_ok = remplies > 0 and finies > 0 and sum(generes) > 0 and any(x != 0 for x in lignes_ech)
    tailles = sorted({x["taille_lot"] for _, _, x in lignes})
    dom = {"contexte_max": max(r["longueurs_contexte"][cle] for _, cle, r in actions),
           "generes_relus_max": max(generes), "taille_lot": max(tailles)}
    controle(f"{phase} : domaine du code = recalcul", bil["domaine"] == dom, json.dumps(dom))
    print(f"     domaine : {dom} ; plus long contexte rempli d'un lot (débit de la phase) : "
          f"{ph['debit']['longueur_remplie_max']}")

    # --- contrôle négatif de phase (P3, C3, P5)
    comp, passent, courtes, echecs, mini = 0, 0, 0, [], math.inf
    for ep, cle, r in actions:
        zone = r["controle_negatif_zone_generee"][cle]
        if zone is None or min(v["positions"] for v in zone.values()) < POS_MIN:
            courtes += 1
            continue
        comp += 1
        m = min(-math.inf if v[STAT[phase]] != v[STAT[phase]] else v[STAT[phase]] for v in zone.values())
        mini = min(mini, m)
        if m > TAU[phase]:
            passent += 1
        else:
            echecs.append(f"{ep}:{cle}")
    frac = passent / comp if comp else None
    cn = {"comparables": comp, "passent": passent, "courtes": courtes, "echecs": echecs, "fraction": frac,
          "min_des_maxima": mini if comp else None, "positions_min": POS_MIN, "statistique": STAT[phase]}
    print(f"     contrôle négatif recalculé : {json.dumps(cn, ensure_ascii=False)}")
    controle(f"{phase} : bilan du contrôle négatif du code = recalcul", bil["controle_negatif"] == cn)
    cn_lecture = "non concluant" if comp < ACT_MIN else ("conforme" if frac >= FRAC_MIN else "contraire")

    # --- P5 : vérification partielle du 99e centile décalé par les comptes « au_dessus » (indépendants du q99)
    if phase == "production":
        parts, incoherences_q99, marges = [], [], []
        for ep, cle, r in actions:
            pc, lc = r["positions_capturees"][cle], r["longueurs_contexte"][cle]
            m_gen = pc - lc
            n_lus = pc - 1                         # positions lues par le contrôle négatif : lc + (m − 1)
            decalees = m_gen - 1
            k = k_de(n_lus)
            parts.append((decalees / n_lus, ep, cle, decalees, n_lus, k))
            marges.append(decalees - k)
            zone = r["controle_negatif_zone_generee"][cle]
            for c in COUCHES:
                z = zone[c]
                j = math.floor(0.99 * (n_lus - 1))
                ctx_max = r["profils"][cle][c]["contexte"]["max"]
                kc_max = 0 if ctx_max <= TAU[phase] else lc       # positions du contexte au-dessus du seuil, au plus
                # suffisant : au moins k valeurs au-dessus du seuil ⇒ q99 au-dessus
                if z["au_dessus"] >= k and not z["q99"] > TAU[phase]:
                    incoherences_q99.append((ep, cle, c, "au_dessus ≥ k mais q99 ≤ seuil"))
                # nécessaire : q99 au-dessus ⇒ au moins n − 1 − j valeurs au-dessus du seuil
                if z["q99"] > TAU[phase] and z["au_dessus"] + kc_max < n_lus - 1 - j:
                    incoherences_q99.append((ep, cle, c, "q99 > seuil sans assez de valeurs au-dessus"))
                if z["max"] > TAU[phase] and z["au_dessus"] == 0:
                    incoherences_q99.append((ep, cle, c, "max > seuil, au_dessus = 0"))
        parts.sort()
        controle("production : q99 décalé cohérent avec les comptes au-dessus du seuil (toutes actions, couches)",
                 not incoherences_q99, f"{len(incoherences_q99)} {incoherences_q99[:5]}")
        print(f"     part de la zone générée décalée (m − 1)/(n − 1) : minimum {parts[0][0]:.4f} "
              f"({parts[0][1]} {parts[0][2]} : {parts[0][3]} sur {parts[0][4]}, k = {parts[0][5]}) ; "
              f"maximum {parts[-1][0]:.4f} ; marge minimale (m − 1) − k(n − 1) = {min(marges)}")
        sous_k = [p for p in parts if p[3] < p[5]]
        print(f"     actions dont la zone décalée compte moins de k(n − 1) positions : {len(sous_k)} {sous_k[:5]}")
        VALEURS["production_parts"] = [{"episode": p[1], "action": p[2], "decalees": p[3], "n_moins_1": p[4],
                                        "k": p[5], "part": p[0]} for p in parts]
        VALEURS["production_marge_min"] = min(marges)
        # parts m/n aussi (zone générée sur toutes les positions)
        parts_mn = sorted(((r["positions_capturees"][cle] - r["longueurs_contexte"][cle]) / r["positions_capturees"][cle],
                           ep, cle) for ep, cle, r in actions)
        print(f"     part de la zone générée m/n : minimum {parts_mn[0][0]:.4f} ({parts_mn[0][1]} {parts_mn[0][2]}), "
              f"maximum {parts_mn[-1][0]:.4f}")
        VALEURS["production_part_mn_min"] = parts_mn[0][0]
        VALEURS["production_part_mn_max"] = parts_mn[-1][0]

    # --- zéros (P9) et sondes d'audit
    zeros = {c: {z: [sum(r["profils"][cle][c][z].get("nuls", 0) for _, cle, r in actions),
                     sum(r["profils"][cle][c][z]["jetons"] for _, cle, r in actions)] for z in ("contexte", "generee")}
             for c in COUCHES}
    controle(f"{phase} : zéros du code = recalcul", bil["zeros"] == zeros, json.dumps(zeros))
    gen = [zeros[c]["generee"] for c in COUCHES]
    p9_declenche = sum(t for _, t in gen) > 0 and all(n == t for n, t in gen)
    print(f"     zéros (nuls, jetons) : {zeros} ; P9 {'DÉCLENCHÉ' if p9_declenche else 'non déclenché'}")
    sondes = [r["sondes"][cle] for _, cle, r in actions]
    distincts = sum(s["tableaux_distincts"] for s in sondes)
    ulp = sum(s["ulp_vu"] for s in sondes)
    print(f"     sondes d'audit : tableaux distincts {distincts}/{len(sondes)} ; ulp vu {ulp}/{len(sondes)}")
    controle(f"{phase} : sondes d'audit du code = recalcul", bil["sondes_audit"] ==
             {"tableaux_distincts": distincts == len(sondes), "ulp_vu": ulp == len(sondes)})

    if STAT[phase] == "q99":
        eq_lecture = "conforme" if equiv_ok else "contraire"
    else:
        eq_lecture = ("contraire" if not equiv_ok else ("conforme" if couverture_ok else "non concluant"))
    VALEURS[phase] = {"ecart_max": ecart_max, "q99_max": q99_max, "max_par_couche": par_couche_max,
                      "q99_par_couche": par_couche_q99, "max_contexte": max_ctx, "max_zone_generee": max_gen,
                      "couverture": cv, "domaine": dom, "longueur_remplie_max": ph["debit"]["longueur_remplie_max"],
                      "controle_negatif": cn, "zeros": zeros, "p9_declenche": p9_declenche,
                      "sondes": {"distincts": distincts, "ulp": ulp, "total": len(sondes)},
                      "lecture_equivalence": eq_lecture, "lecture_controle_negatif": cn_lecture}

# ------------------------------------------------------------------ contrôles positifs (P2b, C2)
for cle_pc, phase in (("controle_positif", "logique"), ("controle_positif_chemin", "chemin")):
    print(f"\n==== {cle_pc} (seuil de la phase {phase} : {TAU[phase]})")
    pc = R[cle_pc]
    controle(f"{cle_pc} : T = 5, décalage +1", pc["T"] == 5 and pc["decalage_positions"] == 1,
             f"T {pc['T']} décalage {pc['decalage_positions']}")
    controle(f"{cle_pc} : un lot de 8", pc["plan_lots"] == [list(range(8))], str(pc["plan_lots"]))
    eps = [e["episode"] for e in pc["episodes"]]
    controle(f"{cle_pc} : épisodes 1 et 6", sorted(eps) == ["episode-1", "episode-6"], str(eps))
    acts = [(e["episode"], cle, e["profils"][cle]) for e in pc["episodes"] for cle in e["profils"]]
    controle(f"{cle_pc} : 20 actions", len(acts) == 20, str(len(acts)))
    comp, vus, courtes, manques, mini, ctx = 0, 0, 0, [], math.inf, []
    gen_min_par_couche = {c: math.inf for c in COUCHES}
    for ep, cle, prof in acts:
        zones = [prof[c]["generee"] for c in COUCHES]
        if any(z["jetons"] < POS_MIN for z in zones):
            courtes += 1
            continue
        comp += 1
        ctx += [prof[c]["contexte"]["max"] for c in COUCHES if prof[c]["contexte"]["jetons"]]
        m = min(-math.inf if z["max"] != z["max"] else z["max"] for z in zones)
        for c in COUCHES:
            gen_min_par_couche[c] = min(gen_min_par_couche[c], prof[c]["generee"]["max"])
        mini = min(mini, m)
        if m > TAU[phase]:
            vus += 1
        else:
            manques.append(f"{ep}:{cle}")
    bilan = {"tolerance": TAU[phase], "comparables": comp, "vus": vus, "courtes": courtes, "manques": manques,
             "fraction": vus / comp if comp else None, "min_des_maxima": mini if comp else None,
             "positions_min": POS_MIN, "max_contexte": max(inf_si_nan(x) for x in ctx) if ctx else None}
    print(f"     bilan recalculé : {json.dumps(bilan, ensure_ascii=False)}")
    print(f"     minimum par couche du maximum de la zone générée : {gen_min_par_couche}")
    controle(f"{cle_pc} : bilan du code = recalcul", pc["bilan"] == bilan, json.dumps(pc["bilan"], ensure_ascii=False))
    lect = "non concluant" if comp < ACT_MIN else ("conforme" if bilan["fraction"] >= FRAC_MIN else "contraire")
    separation = bilan["min_des_maxima"] / VALEURS[phase]["ecart_max"]
    print(f"     séparation D1 / arrondi : {bilan['min_des_maxima']!r} / {VALEURS[phase]['ecart_max']!r} = "
          f"{separation:.4g} ; marge au seuil : {bilan['min_des_maxima'] / TAU[phase]:.4g} fois le seuil")
    print(f"     maximum du contexte des actions comparables : {bilan['max_contexte']!r} "
          f"({'≤' if bilan['max_contexte'] <= TAU[phase] else '>'} seuil {TAU[phase]})")
    zeros_ctx = [sum(prof[c]["contexte"].get("nuls", 0) for _, _, prof in acts) for c in COUCHES]
    jetons_ctx = [sum(prof[c]["contexte"]["jetons"] for _, _, prof in acts) for c in COUCHES]
    print(f"     zéros du contexte (D1 ne le touche pas) : {list(zip(zeros_ctx, jetons_ctx))}")
    VALEURS[cle_pc] = {**bilan, "lecture": lect, "separation": separation,
                       "gen_min_par_couche": gen_min_par_couche, "zeros_contexte": list(zip(zeros_ctx, jetons_ctx))}

# ------------------------------------------------------------------ P6 : rejeu du lot 0 dans le processus
print("\n==== P6 : rejeu dans le processus")
prod = R["production"]
par_ep = {e["episode"]: e for e in prod["episodes"]}
rej = prod["rejeu_en_processus"]
controle("P6 : 8 épisodes rejoués (lot 0 = épisodes 0 à 7)", sorted(x["episode"] for x in rej)
         == sorted(f"episode-{k}" for k in range(8)), str([x["episode"] for x in rej]))
diffs = []
for x in rej:
    e = par_ep[x["episode"]]
    for cle in ("trajectoire", "activations", "logits", "vecteurs", "scores"):
        if x["empreintes"].get(cle) is None or x["empreintes"].get(cle) != e["empreintes"].get(cle):
            diffs.append((x["episode"], cle))
    if x["empreintes_capture"] != e["equivalence"]["empreintes_capture"]:
        diffs.append((x["episode"], "captures"))
    if x["empreintes_logits"] != e["equivalence"]["empreintes_logits"]:
        diffs.append((x["episode"], "logits par action"))
    recalc = (x["empreintes"] == e["empreintes"] and x["empreintes_capture"] == e["equivalence"]["empreintes_capture"])
    if recalc != x["identique"]:
        diffs.append((x["episode"], "drapeau identique incohérent"))
captures_comparees = sum(len(x["empreintes_capture"]) for x in rej)
print(f"     différences : {diffs} ; empreintes de captures comparées : {captures_comparees}")
controle("P6 : 5 empreintes, captures et logits par action identiques", not diffs)
VALEURS["P6"] = {"differences": diffs, "captures_comparees": captures_comparees,
                 "lecture": "conforme" if not diffs and rej else "contraire"}

# ------------------------------------------------------------------ lecture du code, rejouée sur le résumé
print("\n==== Lecture")
config = dict(CONFIG_REELLE, revision="0e9e39f249a16976918f6564b8830bc894c89659")
relue = lire({k: v for k, v in R.items() if k != "lecture"}, config)
controle("lecture du code rejouée sur le résumé = lecture consignée", relue == R["lecture"])
mienne = {
    "logique_equivalence": VALEURS["logique"]["lecture_equivalence"],
    "logique_controle_negatif": VALEURS["logique"]["lecture_controle_negatif"],
    "chemin_equivalence": VALEURS["chemin"]["lecture_equivalence"],
    "chemin_controle_negatif": VALEURS["chemin"]["lecture_controle_negatif"],
    "production_equivalence": VALEURS["production"]["lecture_equivalence"],
    "production_controle_negatif": VALEURS["production"]["lecture_controle_negatif"],
    "controle_positif": VALEURS["controle_positif"]["lecture"],
    "controle_positif_chemin": VALEURS["controle_positif_chemin"]["lecture"],
    "rejeu_en_processus": VALEURS["P6"]["lecture"],
    "audit_symetrie": "non déclenché" if not any(VALEURS[p]["p9_declenche"] for p in ("logique", "chemin", "production"))
    else "déclenché",
}
for cle, v in mienne.items():
    controle(f"lecture du juge = lecture du code : {cle}", R["lecture"].get(cle) == v, f"juge {v!r}, code {R['lecture'].get(cle)!r}")
VALEURS["lecture_juge"] = mienne
VALEURS["lecture_code"] = R["lecture"]

print("\n== Bilan :", "tout cohérent" if not ECHECS else f"{len(ECHECS)} échec(s) : {ECHECS}")
if SORTIE:
    Path(SORTIE).write_text(json.dumps(VALEURS, indent=1, ensure_ascii=False, default=str) + "\n", encoding="utf-8")
sys.exit(1 if ECHECS else 0)
