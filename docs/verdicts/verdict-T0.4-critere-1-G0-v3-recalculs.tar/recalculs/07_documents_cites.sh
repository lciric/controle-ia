#!/bin/sh
# Recalcul 07 (juge R13, T0.4 v3) : empreintes des documents cités en tête du préenregistrement v3, comparées aux
# citations ; empreintes de lancement des documents qui font foi ; code cité (fichiers lus par le juge).
# À lancer depuis la racine du clone.
set -u
verifie() { # chemin empreinte_citée
  h=$(sha256sum "$1" | cut -d' ' -f1)
  if [ "$h" = "$2" ]; then echo "OK    $h  $1"; else echo "ÉCHEC $h  $1 (cité $2)"; fi
}
echo "== Documents cités en tête du préenregistrement v3"
verifie prereg/T0.4-validation-modele-reel-v2.md 886c8c07c6954a46c666b294c391523f0cdd3d03a5b99dae5079507503de3fb9
verifie docs/verdicts/verdict-T0.4-critere-1-G0-v2.md 98d53c70c09ff9b4c0eea4f7ae8779d6dfa10bb6401ca6ac4567283c6fac07cb
verifie docs/decisions/proposition-N-011-v1.md aed4bd6c9db802775071bb37ff2ca8939f4c81dc4a85e2fdd6a36f992a81b35b
verifie docs/brief-claude-code-programme-complet-v2.md 9261932a11f29e8643175bc6e150d5455067f58a3cb1e57dca99e02cb17aa3b2
verifie docs/programme-controle-ia-v2.md 2fd63badb5afea48f48d3ca501ae3b027c4094a8b176508488a41a22e45aa18c
verifie livrables/premier-rendu-v1/devis-v1.md 16d71febf1491780ab1230ed1fb8e4d8b1bec47fbed202e0ef26ca666def04c2
verifie docs/notes/memoire-double-precision-T0.4-v1.md b013428ab8502a61a3ea19404ea3a6cdc64ea6a587010c45627e33f13ef29148
verifie docs/notes/memoire-noyau-math-T0.4-v3-v2.md 2e4e9683aaa8ea42d5f8bddb2fa26489a44485252b3fe1d461397e5beaf8d32b
verifie diag/20261005-102042-validation-reelle/arret.json 4eb2d92069e270631bf3e4d25345b44191cbe419d71a4f06725659c32846aeed
verifie diag/20261005-144628-validation-reelle/arret.json e3ca201edef75f50409e42848f5c4faee0c411dd4a169933751c08bb228c63e6
verifie docs/procedures/surveiller-instance-t04-v1.sh 5188c13c8f52746dcb5ba5aa52c6df0671eb9618411a6950299d080658eb526d
echo
echo "== Empreintes de lancement (docs/sha256sums-lancement-v2.txt)"
(cd docs && sha256sum -c sha256sums-lancement-v2.txt)
echo
echo "== Code cité b6ab5d1 (git show <commit>:<chemin> | sha256sum), égal au clone"
for f in src/controle_ia/harnais/validation_reelle.py src/controle_ia/harnais/episode.py src/controle_ia/harnais/activations.py \
         src/controle_ia/harnais/modeles.py src/controle_ia/harnais/politique.py src/controle_ia/manifeste.py \
         src/controle_ia/scellement.py scripts/validation_t04_instance.sh scripts/amorce_instance_t04.sh; do
  a=$(git --no-optional-locks show b6ab5d15e76972a70e7ffc90cce4dbe280d03061:"$f" | sha256sum | cut -d' ' -f1)
  b=$(sha256sum "$f" | cut -d' ' -f1)
  if [ "$a" = "$b" ]; then echo "OK    $a  $f"; else echo "ÉCHEC $a  $f (clone $b)"; fi
done
echo
echo "== Registres lus pour le contexte (non scellés ; à HEAD $(git --no-optional-locks rev-parse HEAD))"
sha256sum registres/decisions.md registres/depenses.md registres/arrets.md registres/go.md
