"""Recompte de l'auteur du verdict complementaire (lecture seule, sans importer le code du depot).

Lit les fichiers scelles du run des notations et les episodes du pilote ; n'affiche aucun texte de reponse,
d'action ni d'ensemble : seulement des comptes, des drapeaux, des cles, des empreintes.
Usage : python3 -I recompte.py <racine du depot>
"""
import hashlib
import json
import sys
from pathlib import Path

racine = Path(sys.argv[1])
run_n = "20261017-193648-t05-notations-reel"
run_p = "20261012-105125-t05-pilote-reel"
d_n = racine / "diag" / run_n
sha_manifeste_n = hashlib.sha256((racine / "runs" / run_n / "manifeste.json").read_bytes()).hexdigest()

episodes = json.loads((racine / "diag" / run_p / "episodes.json").read_text(encoding="utf-8"))
fiches = episodes["resultat"]["fiches"]
ens = {f["episode"]: hashlib.sha256(f["bilan"]["ensemble"].encode("utf-8")).hexdigest()
       for f in fiches if f["bilan"]["ensemble"].strip()}
vides = sorted(f["episode"] for f in fiches if not f["bilan"]["ensemble"].strip())
taches = sorted({f["episode"].rsplit("/e", 1)[0] for f in fiches})
taches_json = json.loads((racine / "donnees/t05-pilote-v1/taches-pilote-60-v1.json").read_text(encoding="utf-8"))

sortie = {"taches_episodes": len(taches), "ensembles_vides": vides,
          "ensembles_vides_decisifs": [e for e in vides if e.endswith("/e0") or e.endswith("/e1")]}
lettres = {"A": (0, 0), "B": (0, 1), "C": (1, 0)}
for juge in ("8B", "3B"):
    f = d_n / f"notations-{juge}-decisives.json"
    c = json.loads(f.read_text(encoding="utf-8"))
    notes = c["resultat"]["notations"]
    cles = [n["cle"] for n in notes]
    attendues = {f"juge-{juge}/{t}/e{k}/passe-{p}" for t in taches for (k, p) in lettres.values()
                 if f"{t}/e{k}" in ens}
    desalignes = 0
    for n in notes:
        ep = n["cle"].split("/", 1)[1].rsplit("/passe-", 1)[0]
        if n.get("ensemble_sha256") != ens.get(ep):
            desalignes += 1
    par_cle = {n["cle"]: n for n in notes}
    completes_taches = []
    ab_communes, ab_identiques = 0, 0
    for t in taches:
        ok = all(par_cle.get(f"juge-{juge}/{t}/e{k}/passe-{p}", {}).get("score") is not None
                 for (k, p) in lettres.values())
        if ok:
            completes_taches.append(t)
        a = par_cle.get(f"juge-{juge}/{t}/e0/passe-0")
        b = par_cle.get(f"juge-{juge}/{t}/e0/passe-1")
        if a is not None and b is not None:
            ab_communes += 1
            ab_identiques += int(a["reponse"] == b["reponse"])
    incompletes = sum(1 for n in notes if n["score"] is None)
    tronquees = sum(1 for n in notes if n.get("tronquee"))
    # score sur 100 contre somme brute (sensibilite) : comptes seulement
    sommes = [sum(n["notes"].values()) for n in notes if n["score"] is not None]
    sortie[juge] = {
        "rattachement": {"run_id": c["run_id"], "manifeste_sha256": c["manifeste_sha256"],
                         "egal_au_manifeste_du_run": c["manifeste_sha256"] == sha_manifeste_n},
        "notations": len(notes), "cles_distinctes": len(set(cles)),
        "cles_egales_aux_attendues": set(cles) == attendues, "desalignes": desalignes,
        "variantes": sorted({n["variante"] for n in notes}),
        "noyau": c["resultat"].get("noyau"),
        "reponses_completes": len(notes) - incompletes, "reponses_incompletes": incompletes,
        "part_incompletes": incompletes / len(notes), "tronquees": tronquees,
        "tronquees_a_3072_jetons": sum(1 for n in notes if n.get("tronquee") and n["jetons_reponse"] == 3072),
        "taches_completes": len(completes_taches), "liste_taches_completes": completes_taches,
        "part_A_B_identiques": ab_identiques / ab_communes if ab_communes else None,
        "sommes_brutes_completes_min_max": [min(sommes), max(sommes)] if sommes else None,
        "sommes_brutes_valeurs_distinctes": len(set(sommes)),
    }
print(json.dumps(sortie, ensure_ascii=False, indent=1))
