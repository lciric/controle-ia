"""Comptes des motifs d'incompletude par juge (lecture seule ; aucun texte de reponse affiche).

Les anomalies sont des chaines ecrites par le code gele (rubrique.py, pilote_a.py) ; certaines portent jusqu'a
30 caracteres de la reponse : elles ne sont jamais affichees, seulement classees par motif.
Usage : python3 -I motifs.py <racine du depot>
"""
import json
import re
import sys
from pathlib import Path

racine = Path(sys.argv[1])
d = racine / "diag" / "20261017-193648-t05-notations-reel"
MOTIFS = {
    "tronquee": re.compile(r"^réponse tronquée \(sans jeton de fin\)"),
    "absente": re.compile(r"^[A-Z_]+ : absente$"),
    "hors_echelle": re.compile(r"^[A-Z_]+ : -?\d+ hors de \["),
    "non_entiere_ou_illisible": re.compile(r"^[A-Z_]+ : note non entière ou illisible"),
    "echelle_ecrite_autre": re.compile(r"^[A-Z_]+ : échelle écrite /"),
}
sortie = {}
for juge in ("8B", "3B"):
    notes = json.loads((d / f"notations-{juge}-decisives.json").read_text(encoding="utf-8"))["resultat"]["notations"]
    comptes = {k: 0 for k in MOTIFS}
    inconnus = 0
    sans_score = 0
    etroit = 0          # tronquee ou au moins une note absente
    seulement_valeur = 0  # sans score, ni tronquee ni absente : seulement hors echelle, non entiere, echelle autre
    incoherences = 0
    for n in notes:
        an = n["anomalies"]
        vus = set()
        for a in an:
            k = next((k for k, r in MOTIFS.items() if r.search(a)), None)
            if k is None:
                inconnus += 1
            else:
                vus.add(k)
        for k in vus:
            comptes[k] += 1
        if n["score"] is None:
            sans_score += 1
            if "tronquee" in vus or "absente" in vus:
                etroit += 1
            else:
                seulement_valeur += 1
        # coherence : score present si et seulement si aucune anomalie
        if (n["score"] is None) != bool(an):
            incoherences += 1
        if bool(n.get("tronquee")) != ("tronquee" in vus):
            incoherences += 1
    sortie[juge] = {"reponses": len(notes), "sans_score": sans_score, "reponses_par_motif": comptes,
                    "anomalies_de_motif_inconnu": inconnus,
                    "lecture_etroite_tronquee_ou_absente": etroit,
                    "part_lecture_etroite": round(etroit / len(notes), 4),
                    "sans_score_seulement_par_la_valeur": seulement_valeur,
                    "incoherences_score_anomalies": incoherences}
print(json.dumps(sortie, ensure_ascii=False, indent=1))
