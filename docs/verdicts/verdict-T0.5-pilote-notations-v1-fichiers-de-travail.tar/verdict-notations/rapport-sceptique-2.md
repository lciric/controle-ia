# Contre-vérification du brouillon de verdict T0.5 (notations décisives refaites, juges 8B et 3B) — sceptique 2

Le brouillon tient. Tous les nombres sont retrouvés et toutes les lectures gelées qu'il applique tiennent. Il faut corriger la façon dont il présente deux « lectures nommées ».

L'empreinte du brouillon est conforme (`7af483a3…7719`). Je n'ai pas lu le dossier `sceptique-1`, ni les fichiers de l'auteur. J'ai seulement haché ces derniers pour vérifier les renvois de sa section 11.

## Constats

| identifiant | brouillon, ligne | ce qu'il dit | ce qui est juste et pourquoi | gravité | correction proposée |
|---|---|---|---|---|---|
| S2-01 | l. 46 ; §3.5 l. 159-175 ; l. 266, 290, 302 | « Ce qu'est une réponse incomplète » serait une vraie ambiguïté. À la lettre étroite (« notes manquantes ou réponse tronquée »), le 3B passerait en nœud (0,156). Le point est soumis à Lazar pour prise d'acte. | **La lecture appliquée (celle du code) est juste, mais le texte gelé l'impose : il n'y a pas d'ambiguïté réelle.** Appuis : complément l. 85 (« Le plan B, la rubrique, P2 et P3 ne se lisent que sur un fichier `notations-<juge>-decisives.json` scellé, par `lire_notations_pilote.py` ») ; complément l. 139 (« aucune lecture ne se fait hors de ce lecteur ») ; complément l. 87 (le lecteur prend `notes_alignees` et `lecture_juge` du code gelé) ; pilote l. 174 (« applique les critères gelés, depuis les résultats scellés, avec le code d'analyse cité ») ; pilote l. 133, D-18 (« les réponses illisibles relèvent de l'incomplétude ») ; code gelé `lire_pilote.py` (2660b07) l. 262-263 : « None pour une réponse incomplète (le score sur 100 est None exactement dans ce cas : notes manquantes, anomalie ou réponse tronquée) », et l. 310 : incomplète = `score is None`. Cette définition a été gelée avant tout résultat. La lecture étroite serait une lecture hors du lecteur, faite après les résultats. De plus, le calcul étroit de l'auteur oublie D-18 : avec les notes illisibles, le 3B a 29 incomplètes (0,161) ; avec aussi les décimales, 33 (0,183). La phrase « la décomposition reste impossible » ne vaut que si les réponses hors échelle restent sans score. Si on les somme telles qu'écrites, le 3B a 30 tâches complètes : c'est un nœud par « moins de 48 », pas par « impossible ». L'issue (nœud) ne change pas. | majeur (aucune lecture gelée ne change) | Réécrire §3.5 en « lecture imposée par le texte gelé », avec les appuis ci-dessus. La retirer des points soumis à Lazar (l. 46, l. 290, l. 302) ; garder au plus une remarque descriptive. Si on garde les comptes étroits, les corriger (D-18) et préciser le chemin. |
| S2-02 | l. 45 ; §3.4 l. 144-157 | Les lignes « plan B pour un juge » et « nœud de décomposition » formeraient une lecture nommée soumise à prise d'acte. | **La lecture appliquée est juste et c'est la seule que le texte permet.** Pilote l. 132 : « Une décomposition impossible donne de même plan B par l'incomplétude, **sinon** nœud (D-13) » ; « sauf plan B par l'incomplétude ». La règle des l. 129-131 est ordonnée (plan B, sinon nœud, sinon rubrique gardée). Si l'autre lecture valait, le cas « indécision » de la parenthèse coexisterait avec un plan B, contre cet ordre. Pilote l. 41-46 : les issues sont exclusives (« plan B pour les deux : les deux passent à la rubrique simplifiée » ; « nœud pour un juge : proposition à Lazar »). Le complément l. 40 renvoie à cette table. Pilote l. 247 : « motif de plan B pour ce juge (et non suspension) ». La ligne « combinaisons » ne joue que pour des issues présentes ; ici, le nœud ne l'est pas. | mineur | Dire que le texte tranche ; ajouter ces appuis ; retirer le point des prises d'acte, ou le marquer « sans ambiguïté ». |
| S2-03 | l. 308 (réserve 7) ; §7 l. 282-297 | La surveillance s'est éteinte avant la fin du run ; sa qualification « revient à Lazar s'il le souhaite ». | Les faits sont exacts : création à 19:09:43 UTC (1792264183) ; borne « création plus 26 400 s » = 18 octobre, 02:29:43 UTC ; arrêt le 18 à 21:36:57 UTC (`arrets.md` l. 22). La borne scellée du complément (l. 84) n'a donc pas été tenue. C'est un écart de procédure à un préenregistrement scellé, non déclaré (R-205 ne le qualifie pas). `CLAUDE.md` l. 53 range ce cas parmi les nœuds. Il n'a aucun effet sur la lecture. | mineur | Le porter en §7 comme nœud à prendre en compte par Lazar, sans effet sur la lecture, au lieu de « s'il le souhaite ». |
| S2-04 | §10 l. 357 et l. 361 ; l. 25 | Empreintes de `registres/decisions.md` (`58723749…`) et `registres/etat.md` (`11de4b67…`), « à la lecture ». | Elles sont justes au commit `1b46eed` (et `d2ea7ba`), mais ne correspondent plus à l'arbre actuel (tête `261f93e`). Le commit `f096dba` (R-208, R-209) les a changées après la lecture de l'auteur. Les lignes citées (297, 312, 327, 337, 338, 341, 342 ; `etat.md` l. 26) restent valables. R-208 et R-209 ne touchent pas ce verdict. | mineur | Écrire « au commit `1b46eed` » dans le tableau, ou rafraîchir au scellement. |
| S2-05 | §11 l. 367-380 ; nombres l. 124, 139, 170, 174-175 | Le recompte de l'auteur renvoie à des fichiers du bloc-notes, hors dépôt. | Les empreintes de la section 11 sont exactes. Mais certains nombres ne reposent que sur ces fichiers, qui ne dureront pas : surtout les comptes étroits 87 et 28, et 39 et 102 (R6). Les autres se retrouvent dans l'audit scellé (l. 31, 141-149, 179). Le verdict v1 a fait de même ; l'audit, lui, a versé ses rapports sources. | mineur | Verser les scripts et les sorties avec le verdict, scellés, par exemple sous `docs/verdicts/verdict-T0.5-pilote-notations-v1-sources/`. Ou retirer les nombres qui n'y renvoient pas. |
| S2-06 | l. 271-273, l. 285 | « Le plan B du 8B déclenche la bascule 8B trop faible → rubrique simplifiée » ; c'est un nœud. | C'est défendable : le pilote se rattache à cette bascule (l. 34). Mais c'est un rapprochement de l'auteur, pas une ligne gelée. Et « 8B trop faible » n'est pas établi comme propriété du modèle : le chemin de génération n'est pas exclu (réserve 1). | pour information | Le marquer « rapprochement de l'auteur » et renvoyer à la réserve 1. |
| S2-07 | l. 7, l. 284 | « Soumettre à Lazar pour GO (R13) ». | Le complément l. 102 dit « scellé, soumis à Lazar », sans GO. `CLAUDE.md` l. 47 parle de GO pour un verdict de porte. Demander le GO est la version prudente. | pour information | Aucune, ou citer les deux textes. |
| S2-08 | §5 l. 251-255 ; réserve 8 | `c63d4f1` est un ancêtre de `b604164` ; cela contredit l'audit. | Exact. Vérifié par `git merge-base --is-ancestor` : 29 commits sur le chemin, aucun ne touche `src`, `tests` ni `scripts`. La limite du clone superficiel (`197e909`, 12 octobre, 01:25:08 UTC) est antérieure. | pour information | Aucune. |

## Nombres recalculés

Mes scripts sont dans `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-notations/sceptique-2/` : `recalcul_s2.py`, `variantes_etroites.py`, `variante_d18.py`, et leurs sorties `*-sortie.json`. Ils sont lancés par `python3 -I`, sans module du dépôt. J'ai écrit mon propre analyseur des notes, sur la règle écrite.

**Retrouvés, tous, sans écart numérique :**

- **Lecture des juges (`lecture-juges.json`)** :
  - `declenche` vrai, « trop propre » vide, « trop sale » à 2 entrées, `lecture_suspendue` vrai ;
  - issue « resume », juges 8B et 3B « écrit » ;
  - 8B : 0 tâche complète, part incomplète 0,7, 60 tronquées, part A et B identiques 0,0, « plan B » ;
  - 3B : 2 tâches complètes, 0,7222, 9 tronquées, 0,0, « plan B » ;
  - différence appariée : borne nulle, « 0 tâches complètes pour les deux juges » ;
  - P1 à P7 égales à la première lecture ;
  - `arbre_propre` vrai, `statut_arbre` vide ;
  - tous les numéros de ligne cités sont exacts.
- **Notations** :
  - par juge : 180 notations, 180 clés distinctes égales aux attendues, 0 désalignée, variante b0 partout ;
  - incomplètes : 126 (8B) et 130 (3B). Le score du fichier et mon analyseur s'accordent sur 180 réponses sur 180 pour chaque juge, avec les mêmes notes relues ;
  - complètes : 54 et 50 ; tronquées : 60 et 9, toutes à 3 072 jetons ;
  - tâches complètes : 0 pour le 8B ; 2 pour le 3B (`2506.18862v3`, `2509.24912v2`) ;
  - sommes des réponses complètes : 11 à 28 (16 valeurs) pour le 8B ; 19 à 28 (9 valeurs) pour le 3B ;
  - lecture étroite : 87 (0,483) et 28 (0,156) ; différences 39 et 102 ;
  - motifs du 3B : 107 hors échelle, 21 absente, 9 tronquée, 5 non entière ou illisible (4 décimales et 1 illisible), 1 échelle écrite autre.
- **`resume.json`** : `commit_cite` = `c63d4f1…` ; rattaché ; aucun `arret.json`.
- **Manifeste des notations** (`9f143f7c…`) :
  - commit `b604164`, préenregistrement `66784ceb…`, décisif, mode réel, dépôt propre ;
  - empreinte canonique de la configuration recalculée : `b3d24dec…` ;
  - 360 graines des juges égales, clé à clé, aux 360 clés décisives du pilote ;
  - paramètres des juges et versions de torch, transformers, tokenizers et numpy égaux au pilote.
- **Manifeste de la lecture** (`5349b231…`) : commit `9c7dcef`, numpy 2.4.6, quatre graines égales à celles de la première analyse.
- **Tâches** : 60 distinctes, `287e8348…`.
- **Épisodes** : 180 fiches, aucun ensemble vide ; manifeste du pilote `8c3d7985…`.
- **Première lecture** (`lecture.json`) :
  - valeurs exactes aux lignes 42, 110, 119, 628, 631, 654, 667 et 706-712 ;
  - elle avait tiré 0 réponse et 10 actions ; aucune action commune avec le nouveau tirage.
- **Tirage de l'audit** : je l'ai refait de façon indépendante. Les 10 réponses (sur 360) et les 10 actions (sur 1 800) sont identiques.
- **Empreintes de la section 10** : 31 conformes sur 33. Les deux restantes sont celles du constat S2-04.
- **Dates et code** :
  - dates exactes : `b604164` le 15 octobre à 04:15:45 UTC ; `1c6c900` le 12 octobre à 06:21:52 UTC ; `1a0232a` le 18 octobre à 22:09:05 UTC ;
  - les neuf modules de lecture, plus `pilote_a.py` et `harnais/episode.py`, ont la même empreinte aux commits `2660b07`, `c63d4f1` et `9c7dcef` et dans l'arbre ; aucun commit ne les touche depuis `2660b07` ;
  - les deux modules neufs sont identiques de `c63d4f1` à la tête.
- **Renvois** : toutes les lignes citées dans `CLAUDE.md`, le programme, le brief, `go.md`, `decisions.md`, `arrets.md`, `depenses.md`, les traces, les plans v1 et v2, le verdict v1 et l'audit sont exactes. La reprise de l'audit scellé (`d69a8700…`) est fidèle, citations comprises.

**Écarts** : aucun nombre faux. Seuls écarts : les empreintes des deux registres (S2-04) et les comptes étroits sans D-18 (S2-01).

## Ce que je n'ai pas pu vérifier

- Je n'ai lu aucun texte de réponse ni d'action. Les constats qualitatifs de l'audit (dégénérescence, notes fondées) ne sont donc pas vérifiés.
- La troncature (« sans jeton de fin ») n'est pas vérifiable sans les jetons. J'ai seulement vérifié qu'elle coïncide avec 3 072 jetons.
- Je n'ai pas recalculé le format ni les grandeurs de P1 et P4 à P7 à partir des épisodes. Je les ai seulement comparés à la première lecture.
- La décomposition est impossible, donc rien à recalculer.
- Je n'ai lancé ni les tests ni `verifier-arbre`. Je n'ai pas consulté le dépôt distant ni l'état des instances Vast.ai.
- Je n'ai pas lu les invites H.3 et H.4 ; les bornes d'échelle sont celles du code gelé `rubrique.py`.
- Je n'ai pas lu l'annexe C.1 de 2606.08892.
- Les dossiers de travail de l'audit, hors du dépôt, ne me sont pas accessibles.
- Les heures de lecture de l'auteur (`d2ea7ba` puis `1b46eed`) ne sont pas vérifiables.
- J'ai refait le tirage avec numpy 2.5.3, pas 2.4.6. Le résultat est pourtant identique.

## Jugement d'ensemble

Non réfuté.
