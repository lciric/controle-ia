"""Champs des manifestes (notations, lecture, analyse, pilote), sans module du dépôt. Usage : python3 -I manifestes_c.py DEPOT"""
import json, os, sys, hashlib
depot = sys.argv[1]
def charger(rel):
    with open(os.path.join(depot, rel), encoding="utf-8") as f:
        return json.load(f)
mn = charger("runs/20261017-193648-t05-notations-reel/manifeste.json")
ml = charger("runs/20261018-214028-t05-lecture-juges/manifeste.json")
ma = charger("runs/20261012-150724-t05-pilote-analyse/manifeste.json")
mp = charger("runs/20261012-105125-t05-pilote-reel/manifeste.json")
out = {"cles_manifeste_notations": sorted(mn.keys()), "cles_manifeste_lecture": sorted(ml.keys())}
def champs(m):
    r = {}
    for k in ("commit", "prereg", "prereg_sha256", "decisif", "mode", "depot_propre", "commande", "config_sha256", "run_id"):
        if k in m:
            v = m[k]
            r[k] = v if not isinstance(v, (dict, list)) else type(v).__name__
    return r
out["notations"] = champs(mn); out["lecture"] = champs(ml); out["analyse"] = champs(ma); out["pilote"] = champs(mp)
for nom, m in (("notations", mn), ("lecture", ml), ("analyse", ma), ("pilote", mp)):
    v = m.get("versions") or {}
    out[nom]["versions"] = {k: v.get(k) for k in ("numpy", "torch", "transformers", "tokenizers", "python") if k in v}
    g = m.get("graines") or {}
    out[nom]["graines_n"] = len(g)
gl, ga, gp, gn = (m.get("graines") or {} for m in (ml, ma, mp, mn))
out["graines_lecture_egales_analyse"] = {k: (gl[k] == ga.get(k)) for k in gl}
dec = {k for k in gp if k.startswith("juge-") and ("/e0/" in k or "/e1/" in k)}
out["graines_juges_notations"] = {"n": len(gn), "cles_decisives_pilote": len(dec), "memes_cles": set(gn) == dec,
                                  "egales": sum(1 for k in gn if gn[k] == gp.get(k))}
cn, cp = mn.get("config") or {}, mp.get("config") or {}
cles = ("agent", "juges", "lot_juge", "max_nouveaux_juge", "temperature_juge", "variante_juge", "fils", "episodes_decisifs", "episodes_notes_deux_fois")
out["config_juges_egales_pilote"] = {k: (cn.get(k) == cp.get(k)) for k in cles}
out["config_notations_run_pilote"] = cn.get("run_pilote")
print(json.dumps(out, ensure_ascii=False, indent=1, default=str))
