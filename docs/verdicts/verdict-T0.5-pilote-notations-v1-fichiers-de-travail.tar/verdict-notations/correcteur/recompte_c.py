"""Recompte du correcteur, sans aucun module du dépôt. Usage : python3 -I recompte_c.py DEPOT
N'affiche que des nombres, des drapeaux, des clés et des empreintes ; aucun texte de réponse, d'action, d'ensemble
ni de motif d'anomalie n'est affiché (les motifs « note non entière ou illisible » recopient 30 caractères de la réponse).
"""
import hashlib, json, os, re, sys

depot = sys.argv[1]
def charger(rel):
    with open(os.path.join(depot, rel), encoding="utf-8") as f:
        return json.load(f)
def sha_fichier(rel):
    with open(os.path.join(depot, rel), "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()
def sha(t):
    return hashlib.sha256(t.encode("utf-8")).hexdigest()

RUN = "20261017-193648-t05-notations-reel"
man_rel = f"runs/{RUN}/manifeste.json"
sortie = {"manifeste_notations_sha256": sha_fichier(man_rel)}

taches = [t["identifiant"] for t in charger("donnees/t05-pilote-v1/taches-pilote-60-v1.json")["taches"]]
sortie["taches"] = {"n": len(taches), "distinctes": len(set(taches)),
                    "sha256": sha_fichier("donnees/t05-pilote-v1/taches-pilote-60-v1.json")}
ep = charger("diag/20261012-105125-t05-pilote-reel/episodes.json")
fiches = ep["resultat"]["fiches"]
ens = {f["episode"]: sha(f["bilan"]["ensemble"]) for f in fiches if f["bilan"]["ensemble"].strip()}
sortie["episodes"] = {"fiches": len(fiches), "ensembles_non_vides": len(ens),
                      "vides_par_rang": {k: sum(1 for f in fiches if f["episode"].endswith(f"/e{k}") and not f["bilan"]["ensemble"].strip()) for k in (0, 1, 2)},
                      "manifeste_sha256": ep.get("manifeste_sha256"),
                      "manifeste_pilote_reel": sha_fichier("runs/20261012-105125-t05-pilote-reel/manifeste.json")}

# motifs d'anomalie, d'après les chaînes que le code gelé écrit (rubrique.py l. 51, 56, 59, 92 ; pilote_a.py l. 180)
M_ABS = re.compile(r"^[A-Z_]+ : absente$")
M_ECH = re.compile(r"^[A-Z_]+ : échelle écrite /\d+, attendue /-?\d+$")
M_NONENT = re.compile(r"^[A-Z_]+ : note non entière ou illisible \(")
M_DEC = re.compile(r"^[A-Z_]+ : note non entière ou illisible \((['\"])\s*[+-]?\d+[.,]\d")
M_HORS = re.compile(r"^[A-Z_]+ : -?\d+ hors de \[-?\d+, -?\d+\]$")
M_TRONQ = re.compile(r"^réponse tronquée \(sans jeton de fin\) : incomplète$")

def motifs(n):
    m = {"absente": False, "echelle_autre": False, "decimale": False, "illisible": False, "hors_echelle": False,
         "tronquee": False, "non_classe": 0}
    for a in n["anomalies"]:
        if M_ABS.match(a): m["absente"] = True
        elif M_ECH.match(a): m["echelle_autre"] = True
        elif M_NONENT.match(a):
            if M_DEC.match(a): m["decimale"] = True
            else: m["illisible"] = True
        elif M_HORS.match(a): m["hors_echelle"] = True
        elif M_TRONQ.match(a): m["tronquee"] = True
        else: m["non_classe"] += 1
    return m

lettres = {"A": (0, 0), "B": (0, 1), "C": (1, 0)}
for juge in ("8B", "3B"):
    rel = f"diag/{RUN}/notations-{juge}-decisives.json"
    d = charger(rel)
    nots = d["resultat"]["notations"]
    cles = [n["cle"] for n in nots]
    attendues = {f"juge-{juge}/{t}/e{k}/passe-{p}" for t in taches for k, p in lettres.values() if f"{t}/e{k}" in ens}
    par = {n["cle"]: n for n in nots}
    desal = sum(1 for c, n in par.items() if n["ensemble_sha256"] != ens.get(c.split("/", 1)[1].rsplit("/passe-", 1)[0]))
    r = {"sha256": sha_fichier(rel), "run_id": d["run_id"], "manifeste_sha256": d["manifeste_sha256"],
         "notations": len(nots), "cles_distinctes": len(set(cles)), "cles_egales_attendues": set(cles) == attendues,
         "desalignees": desal, "variantes": sorted(set(n["variante"] for n in nots))}
    complet = {c: n["score"] is not None for c, n in par.items()}
    r["completes"] = sum(complet.values()); r["incompletes"] = len(nots) - r["completes"]
    r["part_incompletes"] = r["incompletes"] / len(nots)
    r["tronquees"] = sum(1 for n in nots if n["tronquee"])
    r["jetons_des_tronquees"] = sorted(set(n["jetons_reponse"] for n in nots if n["tronquee"]))
    # cohérence interne
    r["score_avec_anomalie"] = sum(1 for n in nots if n["score"] is not None and n["anomalies"])
    r["sans_score_sans_anomalie"] = sum(1 for n in nots if n["score"] is None and not n["anomalies"])
    r["drapeau_tronquee_desaccord"] = sum(1 for n in nots if n["tronquee"] != any(M_TRONQ.match(a) for a in n["anomalies"]))
    r["score_ecart_formule"] = sum(1 for n in nots if n["score"] is not None and abs(n["score"] - 100.0 * max(0, sum(n["notes"].values())) / 33) > 1e-9)
    sommes = sorted(sum(n["notes"].values()) for n in nots if n["score"] is not None)
    r["sommes_completes"] = {"min": sommes[0] if sommes else None, "max": sommes[-1] if sommes else None, "distinctes": len(set(sommes))}
    def taches_completes(est_complete):
        return [t for t in taches if all(est_complete(par[f"juge-{juge}/{t}/e{k}/passe-{p}"]) for k, p in lettres.values())]
    tc = taches_completes(lambda n: n["score"] is not None)
    r["taches_completes"] = len(tc); r["taches_completes_ids"] = tc
    ab = [t for t in taches]
    r["A_B_identiques"] = sum(1 for t in ab if par[f"juge-{juge}/{t}/e0/passe-0"]["reponse"] == par[f"juge-{juge}/{t}/e0/passe-1"]["reponse"])
    # motifs, par réponse
    mot = {c: motifs(n) for c, n in par.items()}
    r["motifs_par_reponse"] = {k: sum(1 for m in mot.values() if m[k]) for k in ("tronquee", "absente", "decimale", "illisible", "hors_echelle", "echelle_autre")}
    r["motifs_par_reponse"]["non_entiere_ou_illisible"] = sum(1 for m in mot.values() if m["decimale"] or m["illisible"])
    r["anomalies_non_classees"] = sum(m["non_classe"] for m in mot.values())
    r["incompletes_sans_motif_classe"] = sum(1 for c, n in par.items() if n["score"] is None and not any(mot[c][k] for k in ("tronquee", "absente", "decimale", "illisible", "hors_echelle", "echelle_autre")))
    r["defaut_unique"] = {}
    for k in ("tronquee", "absente", "decimale", "illisible", "hors_echelle", "echelle_autre"):
        r["defaut_unique"][k] = sum(1 for m in mot.values() if m[k] and sum(m[j] for j in ("tronquee", "absente", "decimale", "illisible", "hors_echelle", "echelle_autre")) == 1)
    # variantes de la lecture étroite : ensemble des motifs qui rendent une réponse incomplète
    variantes = {
        "V0 code (tout motif)": ("tronquee", "absente", "decimale", "illisible", "hors_echelle", "echelle_autre"),
        "N0 tronquee ou absente": ("tronquee", "absente"),
        "N1 + illisible": ("tronquee", "absente", "illisible"),
        "N2 + echelle autre": ("tronquee", "absente", "illisible", "echelle_autre"),
        "N3 + decimale": ("tronquee", "absente", "illisible", "echelle_autre", "decimale"),
        "N1b tronquee, absente, illisible, decimale (sans echelle autre)": ("tronquee", "absente", "illisible", "decimale"),
    }
    rv = {}
    for nom, ks in variantes.items():
        inc = {c for c, m in mot.items() if any(m[k] for k in ks)}
        tcv = taches_completes(lambda n, inc=inc: n["cle"] not in inc)
        rv[nom] = {"incompletes": len(inc), "part": round(len(inc) / len(nots), 4), "plus_de_20_pourcent": len(inc) / len(nots) > 0.2,
                   "taches_completes_si_les_autres_ont_un_score": len(tcv)}
    r["variantes"] = rv
    r["incompletes_hors_N0"] = r["incompletes"] - rv["N0 tronquee ou absente"]["incompletes"]
    sortie[juge] = r

res = charger(f"diag/{RUN}/resume.json")
sortie["resume"] = {"sha256": sha_fichier(f"diag/{RUN}/resume.json"), "run_id": res["run_id"], "manifeste_sha256": res["manifeste_sha256"],
                    "commit_cite": res["resultat"]["commit_cite"],
                    "statuts": {j: res["resultat"]["juges"][j]["statut"] for j in ("8B", "3B")},
                    "completes": {j: res["resultat"]["juges"][j]["completes"] for j in ("8B", "3B")},
                    "notations": {j: res["resultat"]["juges"][j]["notations"] for j in ("8B", "3B")},
                    "arret_json_present": os.path.exists(os.path.join(depot, f"diag/{RUN}/arret.json"))}
print(json.dumps(sortie, ensure_ascii=False, indent=1))
