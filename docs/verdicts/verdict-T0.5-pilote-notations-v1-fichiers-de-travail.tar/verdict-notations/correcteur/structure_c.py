"""Structure des fichiers scellés (clés et types seulement, aucune chaîne affichée). Usage : python3 -I structure_c.py DEPOT"""
import json, sys, os
depot = sys.argv[1]
def forme(x, prof=0):
    if isinstance(x, dict):
        if prof > 3:
            return "dict(...)"
        return {k: forme(v, prof + 1) for k, v in list(x.items())[:40]}
    if isinstance(x, list):
        return [f"list[{len(x)}]", forme(x[0], prof + 1) if x else None]
    return type(x).__name__
for rel in ("diag/20261017-193648-t05-notations-reel/notations-8B-decisives.json",
            "diag/20261017-193648-t05-notations-reel/resume.json",
            "diag/20261012-105125-t05-pilote-reel/episodes.json",
            "donnees/t05-pilote-v1/taches-pilote-60-v1.json"):
    with open(os.path.join(depot, rel), encoding="utf-8") as f:
        d = json.load(f)
    print(rel)
    print(json.dumps(forme(d), ensure_ascii=False)[:3000])
