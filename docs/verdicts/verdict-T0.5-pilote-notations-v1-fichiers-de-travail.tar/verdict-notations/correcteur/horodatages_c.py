"""Horodatages de la surveillance (complément, l. 84) : création et borne lues dans lancement.txt (l. 16-17), arrêt dans registres/arrets.md (l. 22), fin du run dans le journal (l. 58). Usage : python3 -I horodatages_c.py DEPOT"""
import datetime as d, os, re, sys, json
depot = sys.argv[1]
lignes = open(os.path.join(depot, "traces/t05-notations-v2-20261017-1846-session/lancement.txt"), encoding="utf-8").read().splitlines()
creation = int(re.match(r"^creation (\d+)$", lignes[15]).group(1))
borne = int(re.match(r"^plafond de la surveillance (\d+) ", lignes[16]).group(1))
arret_l22 = open(os.path.join(depot, "registres/arrets.md"), encoding="utf-8").read().splitlines()[21]
h = re.search(r"à (\d\d):(\d\d):(\d\d) UTC, par son identifiant", arret_l22)
arret = d.datetime(2026, 10, 18, int(h[1]), int(h[2]), int(h[3]), tzinfo=d.timezone.utc)
journal = open(os.path.join(depot, "traces/t05-notations-20261017-235701-mDaN/journal.txt"), encoding="utf-8").read().splitlines()
fin = d.datetime.fromisoformat(journal[57].split(" ")[0].replace("Z", "+00:00"))
u = lambda t: d.datetime.fromtimestamp(t, d.timezone.utc)
print(json.dumps({"creation": u(creation).isoformat(), "borne_surveillance": u(borne).isoformat(), "borne_moins_creation_s": borne - creation,
                  "fin_du_run": fin.isoformat(), "fin_moins_creation_s": (fin - u(creation)).total_seconds(),
                  "arret_instance": arret.isoformat(), "arret_moins_borne_s": (arret - u(borne)).total_seconds(),
                  "arret_moins_creation_h": round((arret - u(creation)).total_seconds() / 3600, 3)}, indent=1))
