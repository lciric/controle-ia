**Jugement d'ensemble : non réfuté.** Aucune lecture gelée ne change. Le 8B et le 3B sont tous deux en plan B par l'incomplétude.

L'empreinte du brouillon est vérifiée : `7af483a3a9b5aa3a3ef33fe96524b4a69444b0f900e52c1d13d66bed099e7719`, conforme.

## 1. Constats, le plus grave d'abord

| id | brouillon (ligne) | ce qu'il dit | ce qui est juste, et pourquoi | gravité | correction proposée |
|---|---|---|---|---|---|
| S1-01 | l. 44-46, 159-175, 290, 302 | Lecture nommée 2 (b). La définition de « réponse incomplète » serait ouverte. La « lettre étroite » est proposée à Lazar pour prise d'acte ; sous elle, le 3B passerait en nœud. | **Le texte gelé impose la lecture du code.** Ce n'est pas une vraie ambiguïté. (1) La parenthèse du pilote l. 83 n'est pas exhaustive : le même texte dit, l. 133 (D-18) : « les réponses illisibles relèvent de l'incomplétude ». (2) Le pilote, l. 82, renvoie lui-même au module gelé : « sensibilité : échelle sur 100 (`rubrique.score_sur_100`) ». Or ce module refuse toute note en anomalie (`rubrique.py` à `2660b07`, l. 73-79). (3) Le module de lecture gelé définit le terme en toutes lettres. `lire_pilote.py`, l. 262-263 : « None pour une réponse incomplète (le score sur 100 est None exactement dans ce cas : notes manquantes, anomalie ou réponse tronquée) ». Il compte ensuite ces réponses, l. 310. (4) Le pilote confie le calcul de la règle au code : l. 161-164 (« la règle du plan B … écrits et scellés ») et l. 174 (« avec le code d'analyse cité »). (5) Le complément dit la même chose : l. 56 (« calculée par les fonctions gelées au commit … `2660b07` »), l. 68 (« appliqué par la fonction gelée `lecture_juge` ») et l. 77 (en cas d'omission, « le code gelé au commit `2660b07` font foi »). Adopter la lettre étroite maintenant serait un écart au préenregistrement scellé, choisi après avoir vu les résultats (R1). C'est un nœud, pas une prise d'acte. | majeur (la forme seulement ; la lecture appliquée est la bonne) | Réécrire 3.5 en « lecture imposée », avec les citations (1) à (5). Garder l'autre lecture en réserve, « examinée, écartée par le texte gelé ; l'adopter serait un écart (nœud) ». Retirer le point 2 de la liste « soumis à Lazar pour prise d'acte ». |
| S1-02 | l. 46, 170, 174, 266 | Autre lecture (b) : 8B à 87 sur 180 (0,483), 3B à 28 sur 180 (0,156). Pour le 3B, « la décomposition reste impossible ». | Les comptes 87 et 28 sont retrouvés, mais ils oublient D-18, que le brouillon cite lui-même (l. 163). En ajoutant les réponses illisibles, l'échelle écrite autre et les décimales : 8B de 89 à 121 sur 180 (0,494 à 0,672) ; 3B de 29 à 34 sur 180 (0,161 à 0,189). Pour le 3B, c'est toujours au plus 36 réponses, donc pas « plus de 20 % ». Ensuite, « reste impossible » ne vaut que pour la version hybride du brouillon : les réponses gardent le score nul du code sans être comptées incomplètes. Le brouillon critique lui-même cette version (l. 174). Une lecture étroite cohérente donnerait un score aux notes hors échelle, prises telles qu'écrites. Le 3B aurait alors 30 tâches complètes : décomposition possible mais non concluante (moins de 48), donc nœud (pilote l. 132). Le déclencheur « décomposition impossible » ne jouerait plus pour le 3B. L'issue du 3B reste « nœud » ; seul le chemin change. L'audit le dit aussi (l. 165 et l. 293). | mineur | Corriger les comptes (3B de 29 à 34 sur 180 ; 8B de 89 à 121 sur 180), et la phrase sur la décomposition : « impossible sous la version hybride ; non concluante sur 30 tâches sous la version cohérente ; nœud dans les deux cas ». |
| S1-03 | l. 45, 144-157, 266 | Lecture nommée 1 (a). La ligne « nœud de décomposition » jouerait peut-être en plus du plan B. | **Le texte impose la lecture appliquée.** Pilote l. 132 : « décomposition « non concluant » (nœud) sous 48 tâches complètes pour ce juge, ou sur une part illisible, sauf plan B par l'incomplétude (CL-15 ; D-2). Une décomposition impossible donne de même plan B par l'incomplétude, sinon nœud (D-13). » La parenthèse de la l. 185 (« indécision, moins de 48 tâches complètes, part illisible, décomposition impossible ») énumère exactement les cas que la règle range en nœud, sous ces exceptions. La section « Hypothèse » (l. 41-46) traite « plan B pour les deux » et « nœud pour un juge » comme deux issues distinctes, pas cumulables. Le code gelé dit pareil (l. 320-323 et l. 334). L'effet est nul : le brouillon le dit bien (l. 157). | mineur | Dire « lecture imposée par l. 132 et l. 41-46 ; l'autre lecture contredirait « sauf » et « sinon » ». Retirer ou déclasser le point 1 de la prise d'acte. |
| S1-04 | l. 307-308 (réserve 7), section 7 (l. 282-297) | La surveillance s'est éteinte avant la borne. « Sa qualification revient à Lazar s'il le souhaite. » | Les faits sont retrouvés. Le complément, l. 84, fixe « surveillance : arrêt au plus tard à la création plus 26 400 s ». Cela tombe le 18 à 02:29:43 UTC (`lancement.txt` l. 16-17, horodatages convertis). L'instance a été arrêtée le 18 à 21:36:57 UTC (`registres/arrets.md` l. 22). R-205 ne qualifie pas ce point comme un écart. Or `CLAUDE.md` l. 53 range « écart à un préenregistrement scellé » parmi les nœuds. Ce n'est pas facultatif. Aucun effet sur la lecture. | mineur | L'ajouter à la section 7 comme nœud : écart de procédure au complément l. 84, sans effet sur la lecture, dépense consignée sous le plafond. |
| S1-05 | l. 367-380 | Fichiers de travail hors dépôt, avec leurs empreintes. | Le verdict v1 a versé ses fichiers de travail dans une archive scellée (`verdict-T0.5-pilote-v1.md` l. 449 ; `docs/verdicts/verdict-T0.5-pilote-v1-fichiers-de-travail.tar`). Sinon, les recomptes cités (87, 28, motifs) renvoient à un dossier éphémère (R6). | mineur | Annoncer le versement des fichiers de l'auteur et des sceptiques dans `docs/verdicts/verdict-T0.5-pilote-notations-v1-fichiers-de-travail.tar`, avec son sceau. |
| S1-06 | l. 25, 356-361 | Les empreintes des registres sont prises « à la lecture » (`main` à `1b46eed`). | Elles sont exactes à `1b46eed`. Depuis, le commit `f096dba` (19 oct. 08:12 UTC, R-208 et R-209) a changé `registres/decisions.md` (désormais `4949a684…`) et `registres/etat.md` (désormais `ca7f3467…`). Les lignes citées sont inchangées : decisions l. 1-342 identiques, etat l. 26 identique. | pour information | Écrire « à `1b46eed` » dans la colonne, puis revérifier au scellement. |
| S1-07 | l. 301 (réserve 1) | La garde couvre « contextes d'au plus 6 030 jetons, 400 jetons générés », pas « jusqu'à environ 10 000 positions ». Renvoi : audit l. 295 et l. 334. | Ces nombres sont à l'audit l. 195, pas aux lignes citées. | pour information | Citer l'audit, l. 195. |
| S1-08 | l. 238-242 | Constats de l'audit repris. | Le brouillon omet la nuance de l'audit, l. 165 et l. 293 : « impossible » plutôt que « non concluant » tient à la règle stricte, et tolérer la troncature donnerait 3 tâches au 8B. Elle éclaire S1-02. Sans effet sur la lecture. | pour information | La citer en 3.5 ou à la section 5. |

## 2. Nombres recalculés

Mon script n'importe aucun module du dépôt, ne lit que les fichiers scellés et n'affiche aucun texte. Lancement : `python3 -I`.

**Tous retrouvés, aucun écart :**
- **Tâches** : 60, toutes distinctes ; sha256 `287e8348…`.
- **Épisodes** : 180 fiches ; 0 ensemble vide en e0, e1 et e2. `episodes.json` est rattaché au manifeste du pilote `8c3d7985…`.
- **Notations, pour chaque juge** : 180 notations et 180 clés distinctes, égales aux clés attendues ; 0 double ; 0 notation désalignée ; variante `b0` partout. Les deux fichiers et `resume.json` portent le bon `run_id` et `manifeste_sha256` = `9f143f7c…`.
- **Cohérence interne des fichiers** : 0 score avec anomalie ; 0 réponse sans score et sans anomalie ; drapeau « tronquée » toujours d'accord avec l'anomalie ; score = 100 × max(0, somme) / 33 partout.
- **8B** : 54 réponses complètes, 126 incomplètes, part 0,7. Réponses tronquées : 60, toutes à 3 072 jetons. Tâches complètes : 0. Sommes brutes des réponses complètes : de 11 à 28, 16 valeurs distinctes. Réponses A et B identiques : 0 sur 60.
- **3B** : 50 réponses complètes, 130 incomplètes, part 0,7222. Réponses tronquées : 9, toutes à 3 072 jetons. Tâches complètes : 2 (`2506.18862v3`, `2509.24912v2`). Sommes : de 19 à 28, 9 valeurs distinctes. Réponses A et B identiques : 0 sur 60.
- **Motifs, réponses du 3B** : 107 hors échelle, 21 à note absente, 9 tronquées, 5 à note non entière ou illisible, 1 à échelle écrite autre.
- **Motifs, réponses du 8B** (absents du brouillon, cohérents avec l'audit) : 60 tronquées, 55 à note absente, 11 hors échelle, 52 à note non entière ou illisible (47 à décimale, 7 illisibles), 7 à échelle écrite autre.
- **Lettre étroite** (tronquée ou note absente) : 8B 87 (0,483) ; 3B 28 (0,156). Réponses sans score hors de cette lecture : 39 (8B) et 102 (3B).
- **`resume.json`** : statuts « écrit » et « écrit » ; 54 et 50 réponses complètes ; `commit_cite` = `c63d4f1…` ; aucun `arret.json`.
- **Prédictions** : P1 à P7 sont égales entre `lecture-juges.json` et `lecture.json`. Valeurs aux lignes citées : 0,868333 ; 0,324074 ; 0,929630 ; 0,937940 et −0,180864 ; 0,171936 et 0,047503.
- **Déclencheurs hors juges** : kappas de 0,043 à 0,172 ; format 0,868 ; ensembles à couverture des contrôles de 0 ou 1 : 0,133 ; probabilité du « oui » de 2,75 × 10⁻⁵ à 0,991 (14 910 paires). Aucun ne joue.
- **Graines et réglages** : les quatre graines de la lecture sont égales à celles de l'analyse. Les 360 graines des juges sont égales à celles du pilote. Paramètres des juges égaux ; torch, transformers, tokenizers et numpy égaux.
- **Tirage de l'audit** : 10 réponses (6 du 3B, 4 du 8B), toutes présentes dans les fichiers. 10 actions, toutes présentes parmi les 1 800, dont 4 en e2. Aucune action commune avec la première lecture, qui avait tiré 0 réponse et 10 actions.
- **Empreintes** : les 33 pièces de la section 10 sont conformes à `1b46eed`. Seuls les deux registres ont changé depuis (S1-06).
- **Commits** :
  - S `b604164` du 2026-10-15 à 04:15:45 UTC, qui n'ajoute que 4 fichiers.
  - `c63d4f1` **est** un ancêtre de `b604164` (29 commits sur le chemin ; parent de `f309d14`). Le brouillon a raison contre l'audit, l. 260.
  - Aucun commit ne touche `src`, `tests` ou `scripts` entre `c63d4f1` et `b604164`.
  - Limite du clone : `197e909`, du 2026-10-12 à 01:25:08 UTC.
  - `1c6c900` à 06:21:52 ; `1a0232a` à 22:09:05 ; `5188a74` est ancêtre de `38cf9e3` ; S est ancêtre de la tête de branche.
  - Les modules gelés sont identiques à `2660b07`, `c63d4f1`, `b604164`, `9c7dcef`, à la tête et dans l'arbre. Aucun commit ne touche `MODULES_LECTURE` depuis `2660b07`.
- **Horodatages** : création à 19:09:43 UTC ; borne de surveillance le 18 à 02:29:43 UTC ; fin du run 23:56:59 (journal, l. 58) ; « 763 passed » (journal, l. 7).
- **Renvois** : toutes les lignes citées des préenregistrements, de l'audit, du verdict v1, des registres, de `CLAUDE.md`, du programme, du brief et des traces ont été relues. Elles disent ce que le brouillon leur fait dire, sauf S1-07.

**Nombres nouveaux (S1-02) :**

| variante de la lecture étroite | 8B | 3B |
|---|---|---|
| tronquée ou absente, + illisibles | 89 | 29 |
| + échelle écrite autre | 92 | 30 |
| + décimales | 121 | 34 |
| tâches complètes si les notes hors échelle sont prises telles qu'écrites | 1 | 30 |

## 3. Ce que je n'ai pas pu vérifier

- **Textes des réponses et des actions** : non lus. Les constats qualitatifs de l'audit (dégénérescence, notes fondées ou non) ne sont pas vérifiés.
- **Reconstruction des notes** : je n'ai pas relu les notes dans le texte brut des réponses. Mes motifs viennent des champs `anomalies` consignés par le code gelé, dont j'ai vérifié la cohérence interne. 11 anomalies du 8B et 10 du 3B n'ont pas été classées par mon expression régulière. Je les ai comptées comme illisibles ; les totaux égalent ceux de l'audit (7 et 1).
- **Contrefactuel S1-02** : je n'ai calculé ni décomposition ni part pour la lecture « hors échelle prise telle qu'écrite ». Seuls les comptes sont faits.
- **Lecteur et format** : le lecteur n'a pas été rejoué et le format n'a pas été recalculé. Je me fie à la garde du lecteur et au recalcul de l'audit.
- **Dépôt distant, Vast.ai et dépense réelle** : non relus. Seuls les registres l'ont été.
- **Dossiers de travail de l'audit** (bloc-notes d'une autre session) : inaccessibles. La cause de la phrase de l'audit sur l'ascendance de `c63d4f1` n'est pas établie.

## 4. Fichiers de travail

Tous dans `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-notations/sceptique-1/`. Aucune écriture dans le dépôt.

| fichier | sha256 |
|---|---|
| `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-notations/sceptique-1/recalcul_s1.py` | `0a4bc1e4…` |
| `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-notations/sceptique-1/recalcul-sortie.json` | `eec35b10…` |
| `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-notations/sceptique-1/variantes_s1.py` | `35dbbaf3…` |
| `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-notations/sceptique-1/variantes-sortie.json` | `a3b689c4…` |
| `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-notations/sceptique-1/empreintes-controle.txt` | `4e00abae…` |
| `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-notations/sceptique-1/empreintes-attendues.txt` | `6e39cf05…` |
| `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-notations/sceptique-1/lire_pilote_2660b07.py` (copie de `lire_pilote.py` au commit `2660b07`) | `0fa78147…` |

**Jugement : non réfuté.** La lecture appliquée par le brouillon (plan B pour le 8B et pour le 3B) est la seule que permet le texte gelé. Il faut corriger la forme des deux « lectures nommées » (S1-01 à S1-03) et faire passer l'écart de la surveillance en nœud (S1-04).
