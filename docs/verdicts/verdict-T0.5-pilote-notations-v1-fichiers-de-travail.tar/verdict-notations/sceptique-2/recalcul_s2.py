"""Recalcul indépendant (sceptique 2) des nombres du brouillon de verdict T0.5 notations.
N'importe aucun module du dépôt. Lit seulement les fichiers scellés. N'affiche aucun texte de réponse,
d'action ni d'ensemble : seulement des nombres, des clés, des empreintes et des comptes.
Usage : python3 -I recalcul_s2.py /home/user/controle-ia-travail
"""
import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path

R = Path(sys.argv[1])
out = {}


def sha_fichier(p):
    return hashlib.sha256((R / p).read_bytes()).hexdigest()


def charge(p):
    return json.loads((R / p).read_text(encoding="utf-8"))


def sceau_ok(p):
    lignes = (R / (p + ".sha256")).read_text().split()
    return lignes[0] == sha_fichier(p) and lignes[1] == Path(p).name


# --- Fichiers -------------------------------------------------------------------------------------------------
P_TACHES = "donnees/t05-pilote-v1/taches-pilote-60-v1.json"
P_EPIS = "diag/20261012-105125-t05-pilote-reel/episodes.json"
P_MAN_PIL = "runs/20261012-105125-t05-pilote-reel/manifeste.json"
P_MAN_ANA = "runs/20261012-150724-t05-pilote-analyse/manifeste.json"
P_LECT1 = "diag/20261012-150724-t05-pilote-analyse/lecture.json"
P_NOT = {j: f"diag/20261017-193648-t05-notations-reel/notations-{j}-decisives.json" for j in ("8B", "3B")}
P_RES = "diag/20261017-193648-t05-notations-reel/resume.json"
P_MAN_NOT = "runs/20261017-193648-t05-notations-reel/manifeste.json"
P_LJ = "diag/20261018-214028-t05-lecture-juges/lecture-juges.json"
P_MAN_LJ = "runs/20261018-214028-t05-lecture-juges/manifeste.json"

out["sceaux"] = {p: sceau_ok(p) for p in [P_TACHES, P_EPIS, P_MAN_PIL, P_MAN_ANA, P_LECT1, P_NOT["8B"], P_NOT["3B"],
                                          P_RES, P_MAN_NOT, P_LJ, P_MAN_LJ]}

# --- Tâches ---------------------------------------------------------------------------------------------------
taches = [t["identifiant"] for t in charge(P_TACHES)["taches"]]
out["taches"] = {"n": len(taches), "distinctes": len(set(taches)), "sha256": sha_fichier(P_TACHES)}

# --- Épisodes du pilote ---------------------------------------------------------------------------------------
ep = charge(P_EPIS)
fiches = ep["resultat"]["fiches"]
ens = {}
vides = Counter()
for f in fiches:
    k = f["episode"].rsplit("/e", 1)[1]
    if f["bilan"]["ensemble"].strip():
        ens[f["episode"]] = hashlib.sha256(f["bilan"]["ensemble"].encode("utf-8")).hexdigest()
    else:
        vides["e" + k] += 1
out["episodes"] = {"fiches": len(fiches), "vides_par_episode": dict(vides),
                   "taches_des_fiches_egales": sorted({f["tache"] for f in fiches}) == sorted(taches),
                   "manifeste_sha256_cite": ep["manifeste_sha256"] == sha_fichier(P_MAN_PIL),
                   "run_id": ep["run_id"]}
out["dossier_pilote"] = sorted(x.name for x in (R / "diag/20261012-105125-t05-pilote-reel").iterdir())

# --- Lecture indépendante des notes (mon propre analyseur, d'après la règle écrite : dernière occurrence,
#     entier, échelle ; « n/m » seulement si m = maximum) ----------------------------------------------------------
CRIT = {"SPECIFICITY": (0, 5), "COHERENCE": (0, 5), "COVERAGE": (0, 5), "FEASIBILITY": (0, 4), "NOVELTY": (0, 4),
        "RIGOR": (0, 4), "BALANCE": (0, 3), "RESULT_REASONING": (0, 3), "REDUNDANCY_PENALTY": (-2, 0),
        "IRRELEVANCE_PENALTY": (-2, 0)}
LIGNE = re.compile(r"^[ \t>*_#-]*([A-Z_]+)[ \t*_]*:[ \t*_]*([^\n]*)$", re.M)
FRAC = re.compile(r"^([+-]?\d+)\s*/\s*(\d+)(?!\d)")
ENT = re.compile(r"^([+-]?\d+)(?:\.0+)?(?=$|[\s,;)\]]|\.(?!\d))")


def mes_notes(texte):
    dern = {}
    for m in LIGNE.finditer(texte):
        if m.group(1) in CRIT:
            dern[m.group(1)] = m.group(2).strip().strip("*_ ").strip()
    notes, motifs = {}, []
    for nom, (lo, hi) in CRIT.items():
        if nom not in dern:
            motifs.append("absente")
            continue
        s = dern[nom].replace("−", "-")
        m = FRAC.match(s)
        if m:
            if hi <= 0 or int(m.group(2)) != hi:
                motifs.append("echelle_ecrite")
                continue
            v = int(m.group(1))
        else:
            m = ENT.match(s)
            if not m:
                motifs.append("non_entiere_ou_illisible")
                continue
            v = int(m.group(1))
        if not lo <= v <= hi:
            motifs.append("hors_echelle")
            continue
        notes[nom] = v
    return notes, motifs


man_not = charge(P_MAN_NOT)
sha_man_not = sha_fichier(P_MAN_NOT)
juges = {}
for j in ("8B", "3B"):
    d = charge(P_NOT[j])
    nots = d["resultat"]["notations"]
    cles = [n["cle"] for n in nots]
    attendues = {f"juge-{j}/{t}/e{k}/passe-{p}" for t in taches for (k, p) in ((0, 0), (0, 1), (1, 0))
                 if f"{t}/e{k}" in ens}
    desal = 0
    for n in nots:
        epi = n["cle"].split("/", 1)[1].rsplit("/passe-", 1)[0]
        if n["ensemble_sha256"] != ens.get(epi):
            desal += 1
    # incomplétude selon le fichier (score None)
    inc_fichier = sum(1 for n in nots if n["score"] is None)
    tronq = [n for n in nots if n["tronquee"]]
    # incomplétude selon mon analyseur + troncature
    mes = {}
    desaccord_notes = 0
    motifs_par_rep = Counter()
    for n in nots:
        notes, motifs = mes_notes(n["reponse"])
        if notes != n["notes"]:
            desaccord_notes += 1
        complet = (not motifs) and len(notes) == 10 and not n["tronquee"]
        mes[n["cle"]] = (complet, sum(notes.values()) if complet else None)
        for m in set(motifs):
            motifs_par_rep[m] += 1
        if n["tronquee"]:
            motifs_par_rep["tronquee"] += 1
    inc_mien = sum(1 for c, _ in mes.values() if not c)
    accord_score = sum(1 for n in nots if (n["score"] is None) == (not mes[n["cle"]][0]))
    # lecture étroite : tronquée ou au moins une note absente
    etroite = 0
    for n in nots:
        _, motifs = mes_notes(n["reponse"])
        if n["tronquee"] or "absente" in motifs:
            etroite += 1
    # anomalies écrites par le code, classées par motif (sans les afficher)
    anom = Counter()
    for n in nots:
        vus = set()
        for a in n["anomalies"]:
            if "absente" in a:
                vus.add("absente")
            elif "hors de [" in a:
                vus.add("hors_echelle")
            elif "non entière ou illisible" in a:
                vus.add("non_entiere_ou_illisible")
            elif "échelle écrite" in a:
                vus.add("echelle_ecrite")
            elif "tronquée" in a:
                vus.add("tronquee")
            else:
                vus.add("autre")
        for v in vus:
            anom[v] += 1
    # tâches complètes : A, B et C notées et complètes (score non nul au sens du fichier)
    par = {n["cle"]: n for n in nots}
    def cle(t, k, p):
        return f"juge-{j}/{t}/e{k}/passe-{p}"
    completes = [t for t in taches if all(par[cle(t, k, p)]["score"] is not None for k, p in ((0, 0), (0, 1), (1, 0)))]
    completes_mien = [t for t in taches if all(mes[cle(t, k, p)][0] for k, p in ((0, 0), (0, 1), (1, 0)))]
    sommes = [sum(n["notes"].values()) for n in nots if n["score"] is not None]
    communes = [t for t in taches if cle(t, 0, 0) in par and cle(t, 0, 1) in par]
    ident = sum(1 for t in communes if par[cle(t, 0, 0)]["reponse"] == par[cle(t, 0, 1)]["reponse"])
    juges[j] = {
        "notations": len(nots), "cles_distinctes": len(set(cles)), "cles_egales_attendues": set(cles) == attendues,
        "desalignees": desal, "variantes": dict(Counter(n["variante"] for n in nots)),
        "run_id": d["run_id"], "manifeste_rattache": d["manifeste_sha256"] == sha_man_not,
        "incompletes_fichier": inc_fichier, "part_incompletes_fichier": inc_fichier / len(nots),
        "incompletes_mon_analyseur": inc_mien, "accord_score_fichier_et_mien": accord_score,
        "notes_relues_differentes_du_fichier": desaccord_notes,
        "completes_fichier": len(nots) - inc_fichier,
        "tronquees": len(tronq), "jetons_des_tronquees": dict(Counter(n["jetons_reponse"] for n in tronq)),
        "non_tronquees_a_3072": sum(1 for n in nots if not n["tronquee"] and n["jetons_reponse"] >= 3072),
        "lecture_etroite_incompletes": etroite, "part_lecture_etroite": etroite / len(nots),
        "sans_score_hors_lecture_etroite": inc_fichier - etroite,
        "motifs_par_reponse_mon_analyseur": dict(motifs_par_rep),
        "motifs_par_reponse_anomalies_du_code": dict(anom),
        "taches_completes": len(completes), "taches_completes_liste": completes,
        "taches_completes_mon_analyseur": len(completes_mien),
        "sommes_completes_min_max": [min(sommes), max(sommes)] if sommes else None,
        "sommes_valeurs_distinctes": len(set(sommes)),
        "AB_communes": len(communes), "AB_identiques": ident,
        "part_AB_identiques": ident / len(communes) if communes else None,
        "descriptifs_lots": d["resultat"]["descriptifs"].get("lots"),
    }
out["juges"] = juges

# --- Résumé et manifeste des notations ------------------------------------------------------------------------
res = charge(P_RES)
out["resume"] = {"run_id": res["run_id"], "manifeste_rattache": res["manifeste_sha256"] == sha_man_not,
                 "commit_cite": res["resultat"]["commit_cite"],
                 "statuts": {j: res["resultat"]["juges"][j]["statut"] for j in ("8B", "3B")},
                 "completes": {j: res["resultat"]["juges"][j]["completes"] for j in ("8B", "3B")},
                 "notations": {j: res["resultat"]["juges"][j]["notations"] for j in ("8B", "3B")},
                 "run_pilote": res["resultat"]["run_pilote"],
                 "episodes_sha256": res["resultat"]["episodes_sha256"],
                 "taches_sha256": res["resultat"]["taches_sha256"],
                 "arret_json_present": (R / "diag/20261017-193648-t05-notations-reel/arret.json").exists()}
out["manifeste_notations"] = {"sha256": sha_man_not, "commit": man_not["commit"],
                              "prereg": man_not["preenregistrement"], "decisif": man_not["decisif"],
                              "mode": man_not["config"]["mode"], "depot_propre": man_not["depot_propre"],
                              "run_pilote": man_not["config"]["run_pilote"],
                              "versions": {k: man_not["versions"][k] for k in ("torch", "transformers", "tokenizers", "numpy")}}
man_pil = charge(P_MAN_PIL)
g_pil = {k: v for k, v in man_pil["graines"].items() if k.startswith("juge-")}
g_not = {k: v for k, v in man_not["graines"].items() if k.startswith("juge-")}
dec = {k for k in g_pil if not k.split("/")[2] == "e2"}
out["graines_juges"] = {"n_notations_manifeste": len(g_not), "n_pilote_juges_total": len(g_pil),
                        "n_pilote_decisives": len(dec), "egales_cle_a_cle": all(g_not[k] == g_pil.get(k) for k in g_not),
                        "cles_notations_egales_decisives_pilote": set(g_not) == dec}
cmp = {}
for k in ("agent", "juges", "lot_juge", "max_nouveaux_juge", "temperature_juge", "variante_juge", "fils",
          "episodes_decisifs", "episodes_notes_deux_fois"):
    cmp[k] = man_not["config"].get(k) == man_pil["config"].get(k)
out["parametres_juges_egaux_pilote"] = cmp
out["versions_egales_pilote"] = {k: man_not["versions"][k] == man_pil["versions"][k]
                                 for k in ("torch", "transformers", "tokenizers", "numpy")}

# --- Lecture des juges et son manifeste -----------------------------------------------------------------------
lj = charge(P_LJ)
man_lj = charge(P_MAN_LJ)
man_ana = charge(P_MAN_ANA)
out["manifeste_lecture"] = {"sha256": sha_fichier(P_MAN_LJ), "commit": man_lj["commit"], "commande": man_lj["commande"],
                            "prereg": man_lj["preenregistrement"], "decisif": man_lj["decisif"],
                            "depot_propre": man_lj["depot_propre"], "numpy": man_lj["versions"]["numpy"],
                            "graines_egales_analyse": {k: man_lj["graines"][k] == man_ana["graines"][k]
                                                       for k in man_lj["graines"]},
                            "lj_rattache": lj["manifeste_sha256"] == sha_fichier(P_MAN_LJ)}
out["manifeste_analyse"] = {"numpy": man_ana["versions"]["numpy"], "run_pilote": man_ana["config"]["run_pilote"],
                            "manifeste_pilote_egal": man_ana["config"]["manifeste_pilote_sha256"] == sha_fichier(P_MAN_PIL),
                            "prereg": man_ana["preenregistrement"]["sha256"]}

# --- Première lecture : valeurs citées ---------------------------------------------------------------------------
l1 = charge(P_LECT1)
out["premiere_lecture_rattachee"] = l1["manifeste_sha256"] == sha_fichier(P_MAN_ANA)
out["premiere_lecture_predictions"] = l1["resultat"].get("predictions")
out["predictions_lj"] = lj["resultat"]["predictions"]
out["P1_P4_P7_egales"] = all(lj["resultat"]["predictions"][p] == l1["resultat"]["predictions"][p]
                             for p in ("P1", "P4", "P5", "P6", "P7"))
ra1 = l1["resultat"].get("relectures_audit") or l1["resultat"].get("audit_r4", {}).get("relectures")
out["premiere_lecture_relectures"] = ra1 if ra1 is None else {k: len(v) for k, v in ra1.items()}
if ra1:
    out["actions_communes_avec_premiere"] = sorted(set(ra1.get("actions", [])) & set(lj["resultat"]["relectures_audit"]["actions"]))

# --- Tirage de l'audit, refait (générateur neuf par la graine consignée) ----------------------------------------
try:
    import numpy as np
    g = man_lj["graines"]["analyse/audit"]
    ss = np.random.SeedSequence(int(g["entropie"]), spawn_key=tuple(int(k) for k in g["spawn_key"]))
    ctrl = [int(x) for x in ss.generate_state(2)] == g["etat_controle"]
    # clé de dérivation recalculée depuis le nom
    cle_nom = int.from_bytes(hashlib.sha256(b"analyse/audit").digest()[:8], "big")
    rng = np.random.default_rng(ss)
    reps = sorted(c for j in ("8B", "3B") for c in [n["cle"] for n in charge(P_NOT[j])["resultat"]["notations"]])
    acts = sorted(f"{f['episode']}/{a['agent']},{a['pas']}" for f in fiches for a in f["actions"])
    tire = lambda xs: [xs[i] for i in sorted(rng.choice(len(xs), size=min(10, len(xs)), replace=False).tolist())]
    tr, ta = tire(reps), tire(acts)
    out["tirage_audit"] = {"numpy": np.__version__, "etat_controle_ok": ctrl,
                           "spawn_key_egale_nom": str(cle_nom) == g["spawn_key"][0],
                           "population_reponses": len(reps), "population_actions": len(acts),
                           "reponses_egales": tr == lj["resultat"]["relectures_audit"]["reponses_de_juge"],
                           "actions_egales": ta == lj["resultat"]["relectures_audit"]["actions"]}
except Exception as e:  # pas de repli silencieux : consigné
    out["tirage_audit"] = {"erreur": repr(e)}

print(json.dumps(out, ensure_ascii=False, indent=1))
