"""Variantes de la lecture étroite de « réponse incomplète » : comptes seulement, aucun texte affiché.
Usage : python3 -I variantes_etroites.py /home/user/controle-ia-travail"""
import json, re, sys
from pathlib import Path
R = Path(sys.argv[1])
CRIT = {"SPECIFICITY": (0, 5), "COHERENCE": (0, 5), "COVERAGE": (0, 5), "FEASIBILITY": (0, 4), "NOVELTY": (0, 4),
        "RIGOR": (0, 4), "BALANCE": (0, 3), "RESULT_REASONING": (0, 3), "REDUNDANCY_PENALTY": (-2, 0),
        "IRRELEVANCE_PENALTY": (-2, 0)}
LIGNE = re.compile(r"^[ \t>*_#-]*([A-Z_]+)[ \t*_]*:[ \t*_]*([^\n]*)$", re.M)
FRAC = re.compile(r"^([+-]?\d+)\s*/\s*(\d+)(?!\d)")
ENT = re.compile(r"^([+-]?\d+)(?:\.0+)?(?=$|[\s,;)\]]|\.(?!\d))")
def motifs(texte):
    dern = {}
    for m in LIGNE.finditer(texte):
        if m.group(1) in CRIT:
            dern[m.group(1)] = m.group(2).strip().strip("*_ ").strip()
    s_ = set()
    for nom, (lo, hi) in CRIT.items():
        if nom not in dern: s_.add("absente"); continue
        s = dern[nom].replace("−", "-")
        m = FRAC.match(s)
        if m:
            if hi <= 0 or int(m.group(2)) != hi: s_.add("echelle_ecrite"); continue
            v = int(m.group(1))
        else:
            m = ENT.match(s)
            if not m: s_.add("illisible"); continue
            v = int(m.group(1))
        if not lo <= v <= hi: s_.add("hors_echelle")
    return s_
taches = [t["identifiant"] for t in json.loads((R/"donnees/t05-pilote-v1/taches-pilote-60-v1.json").read_text())["taches"]]
out = {}
for j in ("8B", "3B"):
    nots = json.loads((R/f"diag/20261017-193648-t05-notations-reel/notations-{j}-decisives.json").read_text())["resultat"]["notations"]
    par = {}
    for n in nots:
        m = motifs(n["reponse"])
        if n["tronquee"]: m.add("tronquee")
        par[n["cle"]] = m
    variantes = {
        "V1 tronquee|absente": {"tronquee", "absente"},
        "V2 + illisible (D-18)": {"tronquee", "absente", "illisible"},
        "V3 + illisible + echelle_ecrite": {"tronquee", "absente", "illisible", "echelle_ecrite"},
        "code (tout motif)": {"tronquee", "absente", "illisible", "echelle_ecrite", "hors_echelle"},
    }
    r = {}
    for nom, inc in variantes.items():
        incompletes = [c for c, m in par.items() if m & inc]
        # tâches où A, B, C sont toutes hors de cet ensemble ET sans aucun motif (score calculable sans note hors échelle)
        def complete_sans_hors(c): return not par[c]
        def complete_avec_hors(c): return not (par[c] & inc) and not (par[c] - {"hors_echelle"})
        ks = lambda t: [f"juge-{j}/{t}/e0/passe-0", f"juge-{j}/{t}/e0/passe-1", f"juge-{j}/{t}/e1/passe-0"]
        r[nom] = {"incompletes": len(incompletes), "part": round(len(incompletes)/len(par), 4),
                  "plus_de_20_pourcent": len(incompletes)/len(par) > 0.2,
                  "taches_ABC_sans_aucun_motif": sum(all(complete_sans_hors(c) for c in ks(t)) for t in taches),
                  "taches_ABC_si_notes_hors_echelle_sommees": sum(all(complete_avec_hors(c) for c in ks(t)) for t in taches)}
    out[j] = r
print(json.dumps(out, ensure_ascii=False, indent=1))
