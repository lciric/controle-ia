import json, sys
def shape(o, d=0, maxd=4):
    if d > maxd: return "..."
    if isinstance(o, dict):
        return {k: shape(v, d+1, maxd) for k, v in list(o.items())[:40]}
    if isinstance(o, list):
        return [f"list[{len(o)}]", shape(o[0], d+1, maxd) if o else None]
    if isinstance(o, str):
        return f"str[{len(o)}]"
    return o if isinstance(o,(int,float,bool)) or o is None else type(o).__name__
for p in sys.argv[1:]:
    with open(p) as f: o = json.load(f)
    print("==", p)
    print(json.dumps(shape(o), ensure_ascii=False, indent=1)[:6000])
