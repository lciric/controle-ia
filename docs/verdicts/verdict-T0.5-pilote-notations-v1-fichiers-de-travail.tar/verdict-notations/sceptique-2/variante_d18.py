"""Lecture étroite + D-18 : tronquée, note absente, ou note illisible (hors demi-points et décimales).
Comptes seulement. Usage : python3 -I variante_d18.py /home/user/controle-ia-travail"""
import json, re, sys
from pathlib import Path
R = Path(sys.argv[1])
CRIT = {"SPECIFICITY": (0, 5), "COHERENCE": (0, 5), "COVERAGE": (0, 5), "FEASIBILITY": (0, 4), "NOVELTY": (0, 4),
        "RIGOR": (0, 4), "BALANCE": (0, 3), "RESULT_REASONING": (0, 3), "REDUNDANCY_PENALTY": (-2, 0),
        "IRRELEVANCE_PENALTY": (-2, 0)}
LIGNE = re.compile(r"^[ \t>*_#-]*([A-Z_]+)[ \t*_]*:[ \t*_]*([^\n]*)$", re.M)
FRAC = re.compile(r"^([+-]?\d+)\s*/\s*(\d+)(?!\d)")
ENT = re.compile(r"^([+-]?\d+)(?:\.0+)?(?=$|[\s,;)\]]|\.(?!\d))")
DEC = re.compile(r"^[+-]?\d+\.\d+")
out = {}
for j in ("8B", "3B"):
    nots = json.loads((R/f"diag/20261017-193648-t05-notations-reel/notations-{j}-decisives.json").read_text())["resultat"]["notations"]
    n_etroite_d18 = 0; n_illis = 0; n_dec = 0
    for n in nots:
        dern = {}
        for m in LIGNE.finditer(n["reponse"]):
            if m.group(1) in CRIT: dern[m.group(1)] = m.group(2).strip().strip("*_ ").strip()
        absente = any(c not in dern for c in CRIT)
        illis = dec = False
        for c, (lo, hi) in CRIT.items():
            if c not in dern: continue
            s = dern[c].replace("−", "-")
            if FRAC.match(s) or ENT.match(s): continue
            if DEC.match(s): dec = True
            else: illis = True
        n_illis += illis; n_dec += dec
        if n["tronquee"] or absente or illis: n_etroite_d18 += 1
    out[j] = {"etroite_plus_illisible_strict": n_etroite_d18, "part": round(n_etroite_d18/len(nots), 4),
              "reponses_a_note_illisible_strict": n_illis, "reponses_a_decimale": n_dec}
print(json.dumps(out, ensure_ascii=False))
