"""Recalcul indépendant (sceptique 1). N'importe aucun module du dépôt. N'affiche aucun texte de réponse,
d'action ou d'ensemble : seulement des comptes, des clés, des drapeaux et des empreintes.
Usage : python3 -I recalcul_s1.py /home/user/controle-ia-travail > sortie.json
"""
import hashlib
import json
import re
import sys
from pathlib import Path

R = Path(sys.argv[1])
RUN_N = "20261017-193648-t05-notations-reel"
RUN_L = "20261018-214028-t05-lecture-juges"
RUN_P = "20261012-105125-t05-pilote-reel"


def sha_fichier(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def sha_txt(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


out = {}

# 1. tâches
taches_doc = json.loads((R / "donnees/t05-pilote-v1/taches-pilote-60-v1.json").read_text())
taches = [t["identifiant"] for t in taches_doc["taches"]]
out["taches"] = {"n": len(taches), "distinctes": len(set(taches)),
                 "sha256": sha_fichier(R / "donnees/t05-pilote-v1/taches-pilote-60-v1.json")}

# 2. épisodes du pilote
ep_doc = json.loads((R / f"diag/{RUN_P}/episodes.json").read_text())
fiches = ep_doc["resultat"]["fiches"]
ens = {}
vides = {"e0": 0, "e1": 0, "e2": 0}
for f in fiches:
    e = f["episode"]
    k = e.rsplit("/", 1)[1]
    if f["bilan"]["ensemble"].strip():
        ens[e] = sha_txt(f["bilan"]["ensemble"])
    else:
        vides[k] += 1
out["episodes"] = {"fiches": len(fiches), "ensembles_vides": vides,
                   "episodes_taches_hors_liste": sorted({f["episode"].rsplit("/", 1)[0] for f in fiches} - set(taches))[:5],
                   "manifeste_sha256_porte": ep_doc.get("manifeste_sha256"),
                   "manifeste_pilote_sha256": sha_fichier(R / f"runs/{RUN_P}/manifeste.json")}

man_n = sha_fichier(R / f"runs/{RUN_N}/manifeste.json")
out["manifeste_notations_sha256"] = man_n

# 3. notations
lettres = {"A": ("e0", 0), "B": ("e0", 1), "C": ("e1", 0)}
CRIT = {"SPECIFICITY": (0, 5), "COHERENCE": (0, 5), "COVERAGE": (0, 5), "FEASIBILITY": (0, 4), "NOVELTY": (0, 4),
        "RIGOR": (0, 4), "BALANCE": (0, 3), "RESULT_REASONING": (0, 3), "REDUNDANCY_PENALTY": (-2, 0),
        "IRRELEVANCE_PENALTY": (-2, 0)}
re_hors = re.compile(r"^(?P<nom>[A-Z_]+) : (?P<v>-?\d+) hors de \[(?P<lo>-?\d+), (?P<hi>-?\d+)\]$")


def classe(a):
    if a.startswith("réponse tronquée"):
        return "tronquee"
    if a.endswith(": absente"):
        return "absente"
    if re_hors.match(a):
        return "hors_echelle"
    if "non entière ou illisible" in a:
        return "non_entiere_illisible"
    if "échelle écrite" in a:
        return "echelle_autre"
    return "autre"


juges = {}
for j in ("8B", "3B"):
    p = R / f"diag/{RUN_N}/notations-{j}-decisives.json"
    d = json.loads(p.read_text())
    ns = d["resultat"]["notations"]
    par = {}
    doubles = 0
    for n in ns:
        if n["cle"] in par:
            doubles += 1
        par[n["cle"]] = n
    attendues = {f"juge-{j}/{t}/{e}/passe-{ps}" for t in taches for (e, ps) in lettres.values() if f"{t}/{e}" in ens}
    desal = 0
    for c, n in par.items():
        epi = c.split("/", 1)[1].rsplit("/passe-", 1)[0]
        if n.get("ensemble_sha256") != ens.get(epi):
            desal += 1
    # incohérences internes
    incoh = {"score_none_sans_anomalie": 0, "score_avec_anomalie": 0, "tronquee_sans_anomalie_tronquee": 0,
             "anomalie_tronquee_sans_drapeau": 0, "complete_pas_10_notes": 0, "score_faux": 0, "classe_autre": 0}
    motifs = {"tronquee": 0, "absente": 0, "hors_echelle": 0, "non_entiere_illisible": 0, "echelle_autre": 0}
    etroite = 0          # tronquée ou au moins une note absente
    etroite_d18 = 0      # + illisible / non entière / échelle autre (D-18 « illisibles »)
    tolerante_hors = 0   # incomplète si une anomalie autre que « hors échelle », ou tronquée
    sommes_tol = {}
    sommes = {}
    reps = {}
    for c, n in par.items():
        cl = [classe(a) for a in n["anomalies"]]
        ens_cl = set(cl)
        incoh["classe_autre"] += cl.count("autre")
        if n["score"] is None and not n["anomalies"]:
            incoh["score_none_sans_anomalie"] += 1
        if n["score"] is not None and n["anomalies"]:
            incoh["score_avec_anomalie"] += 1
        if n["tronquee"] and "tronquee" not in ens_cl:
            incoh["tronquee_sans_anomalie_tronquee"] += 1
        if "tronquee" in ens_cl and not n["tronquee"]:
            incoh["anomalie_tronquee_sans_drapeau"] += 1
        if n["score"] is not None:
            if len(n["notes"]) != 10 or set(n["notes"]) != set(CRIT):
                incoh["complete_pas_10_notes"] += 1
            s = sum(n["notes"].values())
            if abs(n["score"] - 100.0 * max(0, s) / 33) > 1e-9:
                incoh["score_faux"] += 1
            sommes[c] = s
        for m in motifs:
            if m in ens_cl:
                motifs[m] += 1
        if n["tronquee"] or "absente" in ens_cl:
            etroite += 1
        if n["tronquee"] or ens_cl & {"absente", "non_entiere_illisible", "echelle_autre"}:
            etroite_d18 += 1
        if n["tronquee"] or (ens_cl - {"hors_echelle"}):
            tolerante_hors += 1
        else:
            # somme avec les notes hors échelle prises telles qu'écrites
            vals = dict(n["notes"])
            for a in n["anomalies"]:
                m = re_hors.match(a)
                vals[m["nom"]] = int(m["v"])
            if len(vals) == 10:
                sommes_tol[c] = sum(vals.values())
            else:
                tolerante_hors += 1
        reps[c] = hashlib.sha256(n["reponse"].encode("utf-8")).hexdigest()
    jetons_tronquees = sorted({n["jetons_reponse"] for n in par.values() if n["tronquee"]})
    incompletes = sum(1 for n in par.values() if n["score"] is None)

    def complet(t, base):
        return all(f"juge-{j}/{t}/{e}/passe-{ps}" in base for (e, ps) in lettres.values())

    completes = [t for t in taches if complet(t, sommes)]
    completes_tol = [t for t in taches if complet(t, sommes_tol)]
    ident = sum(1 for t in taches if reps.get(f"juge-{j}/{t}/e0/passe-0") is not None
                and reps.get(f"juge-{j}/{t}/e0/passe-0") == reps.get(f"juge-{j}/{t}/e0/passe-1"))
    communes = sum(1 for t in taches if f"juge-{j}/{t}/e0/passe-0" in reps and f"juge-{j}/{t}/e0/passe-1" in reps)
    sv = list(sommes.values())
    juges[j] = {
        "run_id": d["run_id"], "manifeste_sha256_ok": d["manifeste_sha256"] == man_n,
        "notations": len(ns), "cles_distinctes": len(par), "doubles": doubles,
        "egales_aux_attendues": set(par) == attendues, "attendues": len(attendues), "desalignees": desal,
        "variantes": sorted({n["variante"] for n in ns}),
        "incoherences": incoh,
        "completes": 180 - incompletes, "incompletes": incompletes, "part_incompletes": incompletes / len(par),
        "tronquees": sum(1 for n in par.values() if n["tronquee"]), "jetons_des_tronquees": jetons_tronquees,
        "taches_completes": len(completes), "taches_completes_liste": completes,
        "sommes_completes_min_max_distinctes": [min(sv), max(sv), len(set(sv))] if sv else None,
        "part_A_B_identiques": ident / communes if communes else None, "A_B_communes": communes,
        "motifs_par_reponse": motifs,
        "lecture_etroite_tronquee_ou_absente": [etroite, etroite / 180],
        "lecture_etroite_plus_illisibles_D18": [etroite_d18, etroite_d18 / 180],
        "lecture_tolerante_hors_echelle_incompletes": [tolerante_hors, tolerante_hors / 180],
        "lecture_tolerante_hors_echelle_taches_completes": len(completes_tol),
        "sans_score_hors_lecture_etroite": incompletes - etroite,
    }
out["juges"] = juges

# 4. resume.json
res = json.loads((R / f"diag/{RUN_N}/resume.json").read_text())
out["resume"] = {"run_id": res["run_id"], "manifeste_ok": res["manifeste_sha256"] == man_n,
                 "commit_cite": res["resultat"]["commit_cite"],
                 "statuts": {k: v["statut"] for k, v in res["resultat"]["juges"].items()},
                 "completes": {k: v["completes"] for k, v in res["resultat"]["juges"].items()},
                 "arret_present": (R / f"diag/{RUN_N}/arret.json").exists()}

# 5. manifestes
mn = json.loads((R / f"runs/{RUN_N}/manifeste.json").read_text())
ml = json.loads((R / f"runs/{RUN_L}/manifeste.json").read_text())
ma = json.loads((R / "runs/20261012-150724-t05-pilote-analyse/manifeste.json").read_text())


def cles_plates(d, pref=""):
    o = {}
    if isinstance(d, dict):
        for k, v in d.items():
            if isinstance(v, (dict, list)):
                o.update(cles_plates(v, pref + k + "."))
            else:
                o[pref + k] = v
    return o


out["manifeste_notations"] = {k: v for k, v in cles_plates(mn).items()
                              if any(x in k for x in ("commit", "prereg", "decisif", "mode", "depot_propre", "run_id",
                                                      "numpy", "run_pilote", "manifeste_pilote"))
                              and "graines" not in k}
out["manifeste_lecture"] = {k: v for k, v in cles_plates(ml).items()}
out["graines_lecture_egales_analyse"] = {}
gl = ml.get("graines") or {}
ga = ma.get("graines") or {}
for k in ("analyse/bootstrap-parts-8B", "analyse/bootstrap-parts-3B", "analyse/bootstrap-difference", "analyse/audit"):
    out["graines_lecture_egales_analyse"][k] = (k in gl and k in ga and gl[k] == ga[k])

# 6. lecture.json (première lecture) et lecture-juges.json
lj = json.loads((R / f"diag/{RUN_L}/lecture-juges.json").read_text())
lp = json.loads((R / "diag/20261012-150724-t05-pilote-analyse/lecture.json").read_text())
out["lecture_juges_manifeste_ok"] = lj["manifeste_sha256"] == sha_fichier(R / f"runs/{RUN_L}/manifeste.json")
out["predictions_egales"] = {k: (lj["resultat"]["predictions"][k], lp["resultat"]["predictions"][k])
                             for k in ("P1", "P2", "P3", "P4", "P5", "P6", "P7")}
lpj = lp["resultat"].get("juges")
out["premiere_lecture_juges"] = lpj if not isinstance(lpj, dict) else {k: (v if not isinstance(v, dict) else {
    kk: vv for kk, vv in v.items() if not isinstance(vv, (dict, list))}) for k, v in lpj.items()}
rel = lp["resultat"].get("relectures_audit")
out["premiere_lecture_relectures"] = {k: len(v) for k, v in rel.items()} if isinstance(rel, dict) else rel
out["actions_communes"] = sorted(set(lj["resultat"]["relectures_audit"]["actions"]) &
                                 set((rel or {}).get("actions", [])))
# réponses tirées pour l'audit : présentes dans les fichiers ?
toutes = set()
for j in ("8B", "3B"):
    d = json.loads((R / f"diag/{RUN_N}/notations-{j}-decisives.json").read_text())
    toutes |= {n["cle"] for n in d["resultat"]["notations"]}
out["reponses_audit_presentes"] = all(c in toutes for c in lj["resultat"]["relectures_audit"]["reponses_de_juge"])
acts = set()
for f in fiches:
    for a in f["actions"]:
        acts.add(f"{f['episode']}/{a['agent']},{a['pas']}")
out["actions_audit_presentes"] = all(a in acts for a in lj["resultat"]["relectures_audit"]["actions"])
out["actions_total"] = len(acts)
json.dump(out, sys.stdout, ensure_ascii=False, indent=1, default=str)
