"""Variantes de la lecture étroite (sceptique 1) : comptes seulement, aucun texte affiché.
Usage : python3 -I variantes_s1.py /home/user/controle-ia-travail"""
import json, re, sys
from pathlib import Path
R = Path(sys.argv[1])
re_ne = re.compile(r"note non entière ou illisible \('(?P<brut>.*)'\)$|note non entière ou illisible \(\"(?P<brut2>.*)\"\)$")
re_dec = re.compile(r"^[+-]?\d+[.,]\d+")
out = {}
for j in ("8B", "3B"):
    ns = json.loads((R / f"diag/20261017-193648-t05-notations-reel/notations-{j}-decisives.json").read_text())["resultat"]["notations"]
    c = {"decimale": 0, "illisible": 0, "non_classee": 0}
    v_tr_abs = v_tr_abs_ill = v_tr_abs_ill_ech = v_tr_abs_ill_ech_dec = 0
    for n in ns:
        has_abs = any(a.endswith(": absente") for a in n["anomalies"])
        has_dec = has_ill = False
        for a in n["anomalies"]:
            if "non entière ou illisible" in a:
                m = re_ne.search(a)
                brut = (m["brut"] or m["brut2"]) if m else None
                if brut is None:
                    c["non_classee"] += 1; has_ill = True
                elif re_dec.match(brut.strip()):
                    has_dec = True
                else:
                    has_ill = True
        has_ech = any("échelle écrite" in a for a in n["anomalies"])
        c["decimale"] += has_dec; c["illisible"] += has_ill
        t = n["tronquee"]
        v_tr_abs += (t or has_abs)
        v_tr_abs_ill += (t or has_abs or has_ill)
        v_tr_abs_ill_ech += (t or has_abs or has_ill or has_ech)
        v_tr_abs_ill_ech_dec += (t or has_abs or has_ill or has_ech or has_dec)
    out[j] = {"reponses_a_decimale": c["decimale"], "reponses_illisibles_au_sens_strict": c["illisible"],
              "non_classees": c["non_classee"],
              "tronquee_ou_absente": v_tr_abs, "+illisible": v_tr_abs_ill, "+echelle_autre": v_tr_abs_ill_ech,
              "+decimale": v_tr_abs_ill_ech_dec, "seuil_plus_de_20_pourcent": "> 36"}
json.dump(out, sys.stdout, ensure_ascii=False, indent=1)
