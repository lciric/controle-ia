Version finale du verdict R13 complémentaire, non scellée : `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-notations/correcteur/verdict-T0.5-pilote-notations-v1.md`
sha256 : `d861605c178e1fb0c43c05e62782200ba936ddd00982230b3013e5cc3d60a8cc`

**Décompte des constats** : 16 au total, 16 intégrés, 0 écarté.
- Sceptique 1 : S1-01 à S1-08 intégrés.
- Sceptique 2 : S2-01 à S2-08 intégrés. S2-08 se limite à confirmer l'ascendance de `c63d4f1` et ne demande aucun changement.
- La section 12 du verdict donne, pour chaque constat, son sort et la raison.

**Verdict d'ensemble** :
1. Les deux juges, 8B et 3B, passent au plan B par l'incomplétude : 126 réponses incomplètes sur 180 pour le 8B, 130 sur 180 pour le 3B. La décomposition est impossible pour les deux (0 et 2 tâches complètes). P2 et P3 sont non concluantes. P1 et P4 à P7 sont inchangées.
2. L'audit R4 est scellé. Il écarte toute erreur de mesure ou de calcul. Le chemin de génération des juges sur la carte n'est pas exclu : c'est une réserve. Aucune lecture gelée ne change.
3. Les deux « lectures nommées » du brouillon sont tranchées par le texte gelé lui-même (pilote, ligne 132 ; complément, lignes 77, 85, 102 et 139). Je juge qu'aucune ambiguïté ne demeure, donc je ne tranche rien. Les autres lectures possibles et leurs comptes restent écrits, pour information.
4. Si l'on comptait les réponses incomplètes à la lettre étroite, le 3B aurait de 28 à 34 réponses incomplètes, sous le seuil de 36, et passerait en nœud. Le 8B resterait en plan B. Adopter cette lecture maintenant serait un écart au préenregistrement scellé, choisi après les résultats (règle R1). Le verdict ne la propose pas ; elle figure en réserve 2.
5. Tous les nombres ont été retrouvés par mon propre recalcul. Les 33 empreintes citées : 31 sont égales à la tête `95bef7e`. Les deux autres, les registres des décisions et d'état, sont datées au commit `1b46eed`, puisque `f096dba` les a changés ; les lignes citées sont inchangées.

**Nœuds pour Lazar** :
1. GO sur ce verdict (`CLAUDE.md`, ligne 47 ; le complément et le pilote disent « scellé, puis soumis à Lazar »).
2. Bascule « 8B trop faible → rubrique simplifiée ». Aucune ligne gelée ne relie le plan B du 8B à cette bascule : c'est un rapprochement de l'auteur, porté comme nœud par prudence.
3. Voie du plan B pour les deux juges : préenregistrer la rubrique simplifiée, la faire contre-lire, puis la requalifier par une étape de notation sur la carte. Cette étape est une dépense de calcul : il faut un devis et un GO.
4. Nouveau : écart de procédure au complément scellé (lignes 84 et 93).
   - La surveillance devait arrêter l'instance au plus tard le 18 à 02:29:43 UTC ; elle s'était éteinte le 17 à 20:42 UTC.
   - L'instance a été arrêtée le 18 à 21:36:57 UTC, soit 68 834 secondes après cette borne.
   - L'écart ne touche aucune lecture. La dépense reste au plus 8,23 USD, sous le plafond.
   - R-205 consigne les faits sans les qualifier d'écart : c'est à Lazar de le qualifier.
5. Suites de l'audit : cause profonde (rejeu sur la carte, donc dépense), tout changement de réglage des juges (écart), et la question de savoir si une rubrique simplifiée, aux mêmes réglages, éviterait la dégénérescence.
6. À joindre à la soumission : proposer la destruction de l'instance 56438435, et statuer sur l'instance du pilote 55538944, gardée jusqu'à ce verdict.

Pour information, sans décision demandée : les deux lectures examinées et écartées par le texte gelé (sections 3.4 et 3.5 du verdict).

**Pour la session, au scellement** :
- Verser dans `docs/verdicts/verdict-T0.5-pilote-notations-v1-fichiers-de-travail.tar`, avec son sceau : les fichiers de l'auteur, des deux sceptiques et du correcteur, et les deux rapports des sceptiques tels qu'ils m'ont été transmis.
- Revérifier les empreintes des registres à ce moment-là.

Aucune écriture dans le dépôt, aucune commande Vast.ai, aucun refus du filtre de sûreté.

Mes fichiers de travail sont tous dans `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-notations/correcteur/` :
- `recompte_c.py` et `recompte-sortie.json`
- `manifestes_c.py` et `manifestes-sortie.json`
- `horodatages_c.py` et `horodatages-sortie.json`
- `structure_c.py`
- `empreintes-section10-brouillon.txt`
