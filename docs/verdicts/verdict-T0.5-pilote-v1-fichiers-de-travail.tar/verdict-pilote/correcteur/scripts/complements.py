"""Correcteur : kappas recalculés, sensibilité approchée à la convention stricte (> 0,5), coûts à séparateur en espace.
Aucun texte affiché : seuls des comptes."""
import json, re, sys
import numpy as np
R, OUT = sys.argv[1], sys.argv[2]
ap = json.load(open(f"{R}/diag/20261012-105125-t05-pilote-reel/appariements.json"))["resultat"]
ep = json.load(open(f"{R}/diag/20261012-105125-t05-pilote-reel/episodes.json"))["resultat"]
el = json.load(open(f"{R}/diag/20261012-150724-t05-pilote-analyse/etiquettes.json"))["resultat"]["elements"]
lec = json.load(open(f"{R}/diag/20261012-150724-t05-pilote-analyse/lecture.json"))["resultat"]
tf = json.load(open(f"{R}/donnees/t05-pilote-v1/taches-pilote-60-v1.json"))
avec = {t["identifiant"] for t in tf["taches"] if t["cibles"]["compute"].get("reference_gpu_hours")}
pa = {a["cle"]: a["p_oui"] for a in ap["appariements"]}
def kap(r, j, w):
    r, j, w = np.asarray(r, bool), np.asarray(j, bool), np.asarray(w, float)
    W = w.sum(); po = w[r == j].sum() / W; pr = w[r].sum() / W; pj = w[j].sum() / W
    pe = pr * pj + (1 - pr) * (1 - pj)
    return float((po - pe) / (1 - pe))
G = {"controls": ("controls",), "fruitful_directions": ("fruitful_directions",),
     "sterile_directions": ("sterile_directions",), "directions": ("fruitful_directions", "sterile_directions")}
out = {"kappas": {}}
for g, fams in G.items():
    e = [x for x in el if x["famille"] in fams]
    k = kap([x["etiquette"] == "Yes" for x in e], [x["oui_8b"] for x in e], [x["poids"] for x in e])
    eg = [x for x in e if pa[x["cle"]] == 0.5]
    ks = kap([x["etiquette"] == "Yes" for x in e], [x["oui_8b"] and pa[x["cle"]] > 0.5 for x in e], [x["poids"] for x in e])
    out["kappas"][g] = {"n": len(e), "kappa": k, "lecture": lec["kappas"][g]["kappa"],
                        "ecart": abs(k - lec["kappas"][g]["kappa"]),
                        "egalites_0_5_dans_echantillon": len(eg),
                        "egalites_etiquetees_Yes": sum(x["etiquette"] == "Yes" for x in eg),
                        "kappa_approche_strict_memes_poids": ks}
out["coherence_decision"] = all(x["oui_8b"] == (pa[x["cle"]] >= 0.5) for x in el)
motif = re.compile(r"\d[   ]\d{3}\b")
n = n_sous = n_sous_ref = 0
for f in ep["fiches"]:
    for p in f["bilan"]["propositions"]:
        ct = p.get("cout_texte") or ""
        if motif.search(ct):
            n += 1
            if p.get("cout_heures") is not None and p["cout_heures"] < 1000:
                n_sous += 1
                n_sous_ref += f["bilan"]["tache"] in avec
out["cout_separateur_espace"] = {"propositions": n, "lues_sous_1000": n_sous, "dont_taches_a_reference": n_sous_ref}
json.dump(out, open(OUT, "w"), indent=1, ensure_ascii=False)
print(json.dumps(out, indent=1, ensure_ascii=False))
