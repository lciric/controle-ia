"""Correcteur : vérifie les constats chiffrés des deux sceptiques, depuis les fichiers scellés, sans le code du dépôt.
Ne lit que des nombres, des drapeaux, des identifiants et des motifs écrits par le code ; n'affiche aucun texte."""
import json, math, re, sys, statistics
from collections import Counter
import numpy as np

R = sys.argv[1]
OUT = sys.argv[2]
ep = json.load(open(f"{R}/diag/20261012-105125-t05-pilote-reel/episodes.json"))["resultat"]
ap = json.load(open(f"{R}/diag/20261012-105125-t05-pilote-reel/appariements.json"))["resultat"]
lec = json.load(open(f"{R}/diag/20261012-150724-t05-pilote-analyse/lecture.json"))["resultat"]
tf = json.load(open(f"{R}/donnees/t05-pilote-v1/taches-pilote-60-v1.json"))
taches = {}
for t in tf["taches"]:
    ident = t.get("id") or t.get("identifiant") or t.get("arxiv_id")
    taches[ident] = t
out = {}
fiches = ep["fiches"]
assert len(fiches) == 180
assert all(f["bilan"]["tache"] in taches for f in fiches), "identifiants de tâches"

# 1. Domaine de la garde
DOM = 4752
ctx_all = []
comp = []
for f in fiches:
    lens = {f"{a['agent']},{a['pas']}": (a["debut"] + len(a["ids"]), len(a["ids"])) for a in f["actions"]}
    for a in f["actions"]:
        ctx_all.append(a["debut"] + len(a["ids"]))
    eq = f["equivalence"]
    for cle, n in eq["positions_capturees"].items():
        q = max(float(v) for v in eq["ecarts_q99"][cle].values())
        lc = eq["longueurs_contexte"].get(cle)
        rem = eq["lignes"][cle]["remplissage"]
        comp.append({"ctx": lens[cle][0], "longueur_contexte": lc, "positions": n, "remplissage": rem,
                     "q99max": q, "zone": lens[cle][1] / n if n else None})
ctx_all.sort()
c_ctx = sorted(c["ctx"] for c in comp)
out["domaine"] = {
    "actions": len(ctx_all), "comparees": len(comp),
    "contexte_max": max(ctx_all), "contexte_q99": float(np.quantile(ctx_all, 0.99)),
    "actions_au_dela_4752": sum(c > DOM for c in ctx_all),
    "comparees_au_dela_4752": sorted([(c["ctx"], round(c["q99max"], 4)) for c in comp if c["ctx"] > DOM]),
    "comparee_ctx_max": max(c_ctx),
    "actions_au_dela_ctx_max_comparee": sorted(c for c in ctx_all if c > max(c_ctx)),
    "comparee_longueur_contexte_max": max(c["longueur_contexte"] for c in comp),
    "comparee_ctx_plus_remplissage_max": max(c["ctx"] + c["remplissage"] for c in comp),
    "comparee_positions_max": max(c["positions"] for c in comp),
    "comparee_lc_plus_rem_max": max(c["longueur_contexte"] + c["remplissage"] for c in comp),
    "q99_max": max(c["q99max"] for c in comp),
    "zone_min": min(c["zone"] for c in comp), "zone_mediane": float(np.median([c["zone"] for c in comp])),
    "longueur_remplie_max": ep["descriptifs"]["longueur_remplie_max"],
}

# 2. Durées
d = ep["descriptifs"]
g, pu = d["generation_s"], d["passe_unique_s"]
out["durees"] = {"generation_s": g, "passe_unique_s": pu, "somme": g + pu, "part_projection_somme": (g + pu) / 7584.02,
                 "duree_s_episodes": d["duree_s"], "part_projection_duree": d["duree_s"] / 7584.02,
                 "etape_entiere": ep["duree_s"]}

# 3. Coût
lettres = {}
def lettre(e):
    m = re.search(r"/e(\d+)$", e)
    return {0: "A", 1: "C", 2: "D"}[int(m.group(1))]
refs = {i: t["cibles"]["compute"] for i, t in taches.items()}
avec = sorted(i for i, c in refs.items() if c.get("reference_gpu_hours"))
bases = Counter(refs[i]["basis"] for i in avec)
logs, par_base, sans = [], {"reported": [], "estimated": []}, 0
taches_base = {"reported": set(), "estimated": set()}
for f in fiches:
    tid = f["bilan"]["tache"]
    if tid not in avec:
        continue
    for p in f["bilan"]["propositions"]:
        h = p.get("cout_heures")
        if h is None or not (h > 0) or not math.isfinite(h):
            sans += 1; continue
        v = math.log10(h / float(refs[tid]["reference_gpu_hours"]))
        logs.append(v); par_base[refs[tid]["basis"]].append(v); taches_base[refs[tid]["basis"]].add(tid)
logs_s = sorted(logs)
n = len(logs_s)
def borne_mediane(k):
    # k valeurs déplacées arbitrairement : la médiane reste entre les statistiques d'ordre de rangs décalés de k
    # (médiane d'un n pair = moyenne des rangs n/2-1 et n/2, base 0)
    lo_vals = [-1e9] * k + logs_s[:n - k] if k else logs_s     # k valeurs envoyées à -inf (les plus hautes retirées)
    hi_vals = logs_s[k:] + [1e9] * k if k else logs_s
    return float(np.median(lo_vals)), float(np.median(hi_vals))
out["cout"] = {
    "taches_reference_non_nulle": len(avec), "taches_sans_reference": len(taches) - len(avec),
    "bases_des_taches_a_reference": dict(bases),
    "taches_par_base_avec_propositions": {b: len(s) for b, s in taches_base.items()},
    "propositions": n, "sans_nombre": sans, "mediane": float(np.median(logs_s)),
    "par_base": {b: {"n": len(v), "mediane": float(np.median(v)) if v else None} for b, v in par_base.items()},
    "borne_mediane_7": borne_mediane(7), "borne_mediane_20": borne_mediane(20),
    "part_au_dela_facteur_10": sum(abs(x) > 1 for x in logs_s) / n,
    "part_au_dela_facteur_100": sum(abs(x) > 2 for x in logs_s) / n,
    "q05": float(np.quantile(logs_s, 0.05)), "q95": float(np.quantile(logs_s, 0.95)),
    "lecture_mediane": lec["cout"]["mediane_log10"],
}

# 4. Couvertures aux seuils >= 0,5 et > 0,5 (définition de `couvertures`, recopiée)
pa = {a["cle"]: a["p_oui"] for a in ap["appariements"]}
def couv(strict):
    oui_ = (lambda p: p > 0.5) if strict else (lambda p: p >= 0.5)
    pt = {"controles_ensemble": {}, "controles_proposition": {}, "fecondes_ensemble": {}, "steriles_proposition": {}}
    for f in fiches:
        if lettre(f["episode"]) not in ("A", "C", "D"):
            continue
        t = taches[f["bilan"]["tache"]]
        nums = [p["numero"] for p in f["bilan"]["propositions"]]
        if not nums:
            continue
        def oui(nm, c):
            return oui_(pa[f"{f['episode']}/{nm}/{c['id']}"])
        ctl, fec, ste = t["cibles"]["controls"], t["cibles"]["fruitful_directions"], t["cibles"]["sterile_directions"]
        tid = f["bilan"]["tache"]
        if ctl:
            pt["controles_ensemble"].setdefault(tid, []).append(sum(any(oui(nm, c) for nm in nums) for c in ctl) / len(ctl))
            pt["controles_proposition"].setdefault(tid, []).append(sum(any(oui(nm, c) for c in ctl) for nm in nums) / len(nums))
        if fec:
            pt["fecondes_ensemble"].setdefault(tid, []).append(sum(any(oui(nm, c) for nm in nums) for c in fec) / len(fec))
        if ste:
            pt["steriles_proposition"].setdefault(tid, []).append(sum(any(oui(nm, c) for c in ste) for nm in nums) / len(nums))
    return {k: float(np.mean([np.mean(x) for x in v.values()])) for k, v in pt.items()}
c_ge, c_gt = couv(False), couv(True)
out["couvertures"] = {"seuil_ge_0_5": c_ge, "seuil_strict": c_gt,
                      "lecture": {k: lec["familles"][k]["valeur"] for k in c_ge},
                      "egalites_0_5": sum(1 for v in pa.values() if v == 0.5),
                      "valeurs_distinctes": len(set(pa.values()))}

# 5. Énoncé seul : parts globales et moyennes par tâche
pe = {a["cle"]: a["p_oui"] for a in ap["enonce_seul"]}
glob = {}
for fam in ("controls", "fruitful_directions", "sterile_directions"):
    tot = cov = 0; parts = []
    for tid, t in taches.items():
        ids = [c["id"] for c in t["cibles"][fam]]
        if not ids: continue
        o = [c for c in ids if pe[f"{tid}/enonce/{c}"] >= 0.5]
        tot += len(ids); cov += len(o); parts.append(len(o) / len(ids))
    glob[fam] = {"cibles": tot, "couvertes": cov, "part_globale": cov / tot, "moyenne_par_tache": float(np.mean(parts)),
                 "taches": len(parts)}
out["enonce_seul"] = {"calcul": glob, "lecture_parts": lec["enonce_seul"]["parts"],
                      "lecture_cibles_couvertes": lec["enonce_seul"]["cibles_couvertes"]}

# 6. Motifs d'invalidité (écrits par le code ; classés sans afficher leur texte brut)
cl = Counter()
inval = 0
for f in fiches:
    for h in f["bilan"]["historique"]:
        if h["valide"]:
            continue
        inval += 1
        m = h["motif"] or ""
        if m.startswith("REVISE without a proposal number"): cl["revision_sans_numero"] += 1
        elif m.startswith("no ACTION line"): cl["sans_ligne_ACTION"] += 1
        elif m.startswith("missing field(s)"): cl["champ_manquant"] += 1
        elif re.fullmatch(r"proposal \d+ does not exist", m): cl["proposition_inexistante"] += 1
        elif m.startswith("the set already has"): cl["ensemble_plein"] += 1
        else: cl["autre"] += 1
out["invalides"] = {"total": inval, "motifs": dict(cl),
                    "valides": sum(f["bilan"]["actions_valides"] for f in fiches)}

json.dump(out, open(OUT, "w"), indent=1, ensure_ascii=False)
print(json.dumps(out, indent=1, ensure_ascii=False))
