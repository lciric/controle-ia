"""Affiche la structure (clés, types, longueurs) d'un JSON, sans aucune chaîne."""
import json, sys
def s(x, p="", d=0, out=None):
    if d > 7: return
    if isinstance(x, dict):
        for k, v in list(x.items())[:40]:
            t = type(v).__name__
            extra = f" len={len(v)}" if isinstance(v, (list, dict, str)) else (f" = {v}" if isinstance(v, (int, float, bool)) or v is None else "")
            print(f"{'  '*d}{k}: {t}{extra}")
            s(v, p+"."+k, d+1)
    elif isinstance(x, list) and x:
        print(f"{'  '*d}[0]: {type(x[0]).__name__}")
        s(x[0], p+"[0]", d+1)
s(json.load(open(sys.argv[1])))
