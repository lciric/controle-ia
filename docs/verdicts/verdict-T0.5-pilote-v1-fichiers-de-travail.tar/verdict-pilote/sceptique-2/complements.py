# Contrôles complémentaires du sceptique 2 : nombres seulement (aucun texte d'action, d'ensemble ou d'énoncé lu ni affiché).
import json, math, re, sys
from collections import Counter, defaultdict
import numpy as np
R = '/home/user/controle-ia-travail/'
ep = json.load(open(R + 'diag/20261012-105125-t05-pilote-reel/episodes.json'))['resultat']
app = json.load(open(R + 'diag/20261012-105125-t05-pilote-reel/appariements.json'))['resultat']
taches = json.load(open(R + 'donnees/t05-pilote-v1/taches-pilote-60-v1.json'))['taches']
out = {}
# 1. motifs d'invalidité (motifs écrits par le code, propositions.py)
c = Counter()
for f in ep['fiches']:
    for h in f['bilan']['historique']:
        if not h['valide']:
            m = h['motif'] or ''
            k = ('sans ligne ACTION' if m.startswith('no ACTION line') else 'révision sans numéro' if m.startswith('REVISE without')
                 else 'champ manquant' if m.startswith('missing field') else 'ensemble plein' if m.startswith('the set already has')
                 else 'proposition inexistante' if re.fullmatch(r'proposal \d+ does not exist', m) else 'autre')
            c[k] += 1
out['motifs_invalidite'] = dict(c); out['invalides'] = sum(c.values())
# 2. borne de l'effet de k coûts mal lus sur la médiane du log10 (mêmes règles que mesures_cout)
ref = {t['identifiant']: t['cibles']['compute']['reference_gpu_hours'] for t in taches}
logs = []
for f in ep['fiches']:
    r = ref[f['tache']]
    if not r: continue
    for p in f['bilan']['propositions']:
        h = p['cout_heures']
        if h is None or not (h > 0) or not math.isfinite(h): continue
        logs.append(math.log10(h / r))
s = np.sort(np.array(logs))
out['cout_n'] = len(s); out['cout_mediane'] = float(np.median(s))
out['cout_bornes_mediane'] = {k: [float(np.median(np.concatenate([s[:-k], np.full(k, -np.inf)]))),
                                  float(np.median(np.concatenate([s[k:], np.full(k, np.inf)])))] for k in (7, 20, 50)}
out['cout_part_abs_log10_sup_1'] = float(np.mean(np.abs(s) > 1)); out['cout_part_abs_log10_sup_2'] = float(np.mean(np.abs(s) > 2))
out['cout_quantiles_5_25_75_95'] = [float(x) for x in np.quantile(s, [.05, .25, .75, .95])]
# 3. domaine des contextes et actions comparées par la garde en ligne
ctx = {(f['episode'], f"{a['agent']},{a['pas']}"): a['debut'] + len(a['ids']) for f in ep['fiches'] for a in f['actions']}
comp = [ctx[(f['episode'], k)] for f in ep['fiches'] for k, n in f['equivalence']['positions_capturees'].items() if n]
allc = np.array(list(ctx.values()))
out['contexte_max'] = int(allc.max()); out['contexte_max_compare'] = int(max(comp)); out['actions_comparees'] = len(comp)
out['actions_contexte_sup_4752'] = int((allc > 4752).sum()); out['dont_comparees'] = int(sum(x > 4752 for x in comp))
# 4. couvertures au seuil strict (> 0,5) et égalités
def couv(fam, test):
    ens = defaultdict(lambda: defaultdict(dict)); cib = defaultdict(set)
    for p in app['appariements']:
        if p['famille'] != fam: continue
        t, e, i, cc = p['cle'].split('/'); ens[(t, e)][i][cc] = test(p['p_oui']); cib[t].add(cc)
    pt = defaultdict(list)
    for (t, e), props in ens.items():
        pt[t].append(sum(any(props[i].get(x, False) for i in props) for x in cib[t]) / len(cib[t]))
    return sum(sum(v) / len(v) for v in pt.values()) / len(pt)
out['fecondes_ensemble_strict'] = couv('fruitful_directions', lambda x: x > 0.5)
out['controles_ensemble_strict'] = couv('controls', lambda x: x > 0.5)
out['egalites_05'] = sum(1 for p in app['appariements'] if p['p_oui'] == 0.5)
json.dump(out, open(sys.argv[1], 'w'), indent=1, ensure_ascii=False)
print(json.dumps(out, indent=1, ensure_ascii=False))
