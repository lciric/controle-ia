import json, sys
def walk(x, p, out, maxlist):
    if isinstance(x, dict):
        for k, v in x.items():
            walk(v, p + '.' + str(k), out, maxlist)
    elif isinstance(x, list):
        if len(x) > maxlist:
            out.append(f"{p}: <liste de {len(x)}>")
            for i, v in enumerate(x[:2]):
                walk(v, f"{p}[{i}]", out, maxlist)
        else:
            if not x: out.append(f"{p}: []")
            for i, v in enumerate(x):
                walk(v, f"{p}[{i}]", out, maxlist)
    elif isinstance(x, str):
        if len(x) > 120:
            out.append(f"{p}: <texte de {len(x)} caractères, non affiché>")
        else:
            out.append(f"{p}: {x!r}")
    else:
        out.append(f"{p}: {x!r}")
f = sys.argv[1]; maxlist = int(sys.argv[2]) if len(sys.argv) > 2 else 20
d = json.load(open(f))
out = []
walk(d, '', out, maxlist)
print('\n'.join(out))
