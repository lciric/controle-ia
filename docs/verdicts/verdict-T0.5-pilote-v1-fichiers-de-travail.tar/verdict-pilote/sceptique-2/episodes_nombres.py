# Lit episodes.json : nombres, booléens et étiquettes enumérées courtes seulement ; aucun texte d'action.
import json, sys
d = json.load(open(sys.argv[1]))['resultat']
cn = d['controle_negatif']
print('controle_negatif.lecture =', cn['lecture'] if cn['lecture'] in ('conforme','non concluant') else '<autre>')
print('statistique =', cn['statistique'] if cn['statistique'] in ('q99',) else '<autre>')
f = d['fiches']
print('fiches', len(f))
print('somme actions', sum(x['bilan']['actions'] for x in f), 'somme valides', sum(x['bilan']['actions_valides'] for x in f))
print('propositions finales (somme des longueurs)', sum(len(x['bilan']['propositions']) for x in f))
print('ensembles finaux vides', sum(1 for x in f if len(x['bilan']['propositions'])==0))
eq = [a for x in f for a in x['equivalence']['actions']]
print('actions comparees', len(eq))
# clés de la première action comparée, sans valeurs textuelles
a0 = eq[0]
print('cles equivalence.actions[0]:', {k: (v if isinstance(v,(int,float,bool)) else type(v).__name__) for k,v in a0.items()})
