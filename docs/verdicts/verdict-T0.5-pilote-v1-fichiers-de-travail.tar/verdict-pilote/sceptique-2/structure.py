# N'affiche que les clés, les types, les nombres et les booléens ; jamais une chaîne.
import json, sys
def walk(x, p, depth, maxd):
    if depth > maxd: return
    if isinstance(x, dict):
        for k, v in x.items():
            t = type(v).__name__
            if isinstance(v, (int, float, bool)) or v is None:
                print(f"{p}.{k}: {v!r}")
            elif isinstance(v, str):
                print(f"{p}.{k}: <str {len(v)}>")
            elif isinstance(v, list):
                print(f"{p}.{k}: <list {len(v)}>")
                if v: walk(v[0], f"{p}.{k}[0]", depth+1, maxd)
            else:
                walk(v, f"{p}.{k}", depth+1, maxd)
    elif isinstance(x, list):
        if x: walk(x[0], p+'[0]', depth+1, maxd)
    elif isinstance(x, (int,float,bool)) or x is None:
        print(f"{p}: {x!r}")
    elif isinstance(x, str):
        print(f"{p}: <str {len(x)}>")
d = json.load(open(sys.argv[1]))
walk(d, '', 0, int(sys.argv[2]))
