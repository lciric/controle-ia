import json, sys, statistics
from collections import defaultdict
R = '/home/user/controle-ia-travail/'
app = json.load(open(R+'diag/20261012-105125-t05-pilote-reel/appariements.json'))['resultat']
lec = json.load(open(R+'diag/20261012-150724-t05-pilote-analyse/lecture.json'))['resultat']
eti = json.load(open(R+'diag/20261012-150724-t05-pilote-analyse/etiquettes.json'))['resultat']
ech = json.load(open(R+'diag/20261012-150724-t05-pilote-analyse/echantillon-etiquetage.json'))['resultat']
out = {}
paires = app['appariements']; en = app['enonce_seul']
out['n_paires'] = len(paires); out['n_enonce'] = len(en)
ps = [p['p_oui'] for p in paires] + [p['p_oui'] for p in en]
out['p_oui_toutes_sous_005'] = all(x < 0.05 for x in ps)
out['p_oui_toutes_sur_095'] = all(x > 0.95 for x in ps)
out['part_p_sous_005'] = sum(x<0.05 for x in ps)/len(ps)
out['part_p_sur_095'] = sum(x>0.95 for x in ps)/len(ps)
ms = [p['masse_oui_non'] for p in paires] + [p['masse_oui_non'] for p in en]
out['masse_mediane_tout'] = statistics.median(ms)
out['masse_mediane_propositions'] = statistics.median([p['masse_oui_non'] for p in paires])
out['part_masse_sous_01'] = sum(m<0.1 for m in ms)/len(ms)
out['egalites_05'] = sum(1 for p in paires if p['p_oui']==0.5)
out['ge05'] = sum(1 for p in paires if p['p_oui']>=0.5)
out['gt05'] = sum(1 for p in paires if p['p_oui']>0.5)
out['valeurs_distinctes'] = len(set(p['p_oui'] for p in paires))
out['valeurs_distinctes_r6'] = len(set(round(p['p_oui'],6) for p in paires))
# strates
st = defaultdict(int)
for p in paires:
    st[(p['famille'], p['p_oui']>=0.5)] += 1
out['strates'] = {f"{k[0]}|{'oui' if k[1] else 'non'}": v for k,v in sorted(st.items())}
out['strates_egales_echantillon'] = all(ech['strates'][k]==v for k,v in out['strates'].items())
# familles
# structure: tache -> episode -> prop idx -> famille -> {cible: oui}
cov = defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))
cibles = defaultdict(lambda: defaultdict(set))
for p in paires:
    t, e, i, c = p['cle'].split('/')
    cov[(t,e)][int(i)][c] = p['p_oui']>=0.5
    cibles[t][p['famille']].add(c)
fam_de = {}
for p in paires:
    fam_de[(p['cle'].split('/')[0], p['cle'].split('/')[3])] = p['famille']
ensembles = defaultdict(dict)
for (t,e) in cov: ensembles[t][e] = cov[(t,e)]
def mesure(fam, mode, exclure=None):
    par_tache = {}
    for t, eps in ensembles.items():
        cs = sorted(c for c in cibles[t][fam] if not (exclure and (t,c) in exclure))
        if not cs: continue
        vals = []
        for e, props in eps.items():
            if mode == 'ensemble':
                vals.append(sum(any(props[i].get(c, False) for i in props) for c in cs)/len(cs))
            else:
                vals.append(sum(any(props[i].get(c, False) for c in cs) for i in props)/len(props))
        par_tache[t] = sum(vals)/len(vals)
    return sum(par_tache.values())/len(par_tache), len(par_tache), par_tache
for nom, fam, mode, champ in [('controles_ensemble','controls','ensemble','controles_ensemble'),
                         ('controles_proposition','controls','proposition','controles_proposition'),
                         ('fecondes_ensemble','fruitful_directions','ensemble','fecondes_ensemble'),
                         ('steriles_proposition','sterile_directions','proposition','steriles_proposition')]:
    v, n, pt = mesure(fam, mode)
    out[nom] = (v, n, v - lec['familles'][champ]['valeur'])
# enonce seul
couv_en = set(); tot = defaultdict(int); cv = defaultdict(int)
pt_en = defaultdict(lambda: defaultdict(list))
for p in en:
    t, _, c = p['cle'].split('/')
    tot[p['famille']] += 1
    pt_en[p['famille']][t].append(p['p_oui']>=0.5)
    if p['p_oui']>=0.5:
        couv_en.add((t,c)); cv[p['famille']] += 1
out['enonce_cibles_couvertes'] = len(couv_en)
out['enonce_global'] = {f: cv[f]/tot[f] for f in tot}
out['enonce_par_tache'] = {f: sum(sum(v)/len(v) for v in d.values())/len(d) for f, d in pt_en.items()}
for nom, fam, mode in [('hors_controles_ensemble','controls','ensemble'),('hors_controles_proposition','controls','proposition'),('hors_fecondes_ensemble','fruitful_directions','ensemble'),('hors_steriles_proposition','sterile_directions','proposition')]:
    v, n, _ = mesure(fam, mode, exclure=couv_en)
    out[nom] = (v, n)
# part ensembles controles 0 ou 1
n01 = 0; nens = 0
for t, eps in ensembles.items():
    cs = cibles[t]['controls']
    for e, props in eps.items():
        x = sum(any(props[i].get(c, False) for i in props) for c in cs)/len(cs)
        nens += 1; n01 += (x in (0.0, 1.0))
out['part_ens_ctrl_0_1'] = (n01/nens, nens)
out['steriles_taches'] = sum(1 for t in cibles if cibles[t]['sterile_directions'])
out['n_taches'] = len(cibles)
# kappas
els = eti['elements']
def kappa(sel):
    a=b=c=d=0.0
    for x in sel:
        w = x['poids']; o = x['oui_8b']; y = x['etiquette']=='Yes'
        if o and y: a+=w
        elif o and not y: b+=w
        elif (not o) and y: c+=w
        else: d+=w
    n=a+b+c+d; po=(a+d)/n; p1=(a+b)/n; p2=(a+c)/n
    pe=p1*p2+(1-p1)*(1-p2)
    return dict(kappa=(po-pe)/(1-pe), accord=po, pos=2*a/(2*a+b+c), neg=2*d/(2*d+b+c), part_oui_8b=p1, part_yes=p2, n=len(sel))
dec = defaultdict(lambda: [0,0])
for x in els:
    dec[(x['famille'], x['oui_8b'])][0 if x['etiquette']=='Yes' else 1] += 1
out['decomptes'] = {f"{k[0]}|{'oui' if k[1] else 'non'}": v for k,v in sorted(dec.items())}
out['etiquettes_valeurs'] = sorted(set(x['etiquette'] for x in els))
# poids check
pc = defaultdict(set)
for x in els: pc[(x['famille'], x['oui_8b'])].add(x['poids'])
out['poids'] = {f"{k[0]}|{k[1]}": sorted(v) for k,v in pc.items()}
for g, fams in [('controls',['controls']),('fruitful_directions',['fruitful_directions']),('sterile_directions',['sterile_directions']),('directions',['fruitful_directions','sterile_directions'])]:
    k = kappa([x for x in els if x['famille'] in fams])
    k['ecart_lecture'] = k['kappa'] - lec['kappas'][g]['kappa']
    k['ecart_accord_pos'] = k['pos'] - lec['kappas'][g]['accord_positif']
    out['kappa_'+g] = k
out['diff_kappas'] = out['kappa_directions']['kappa'] - out['kappa_controls']['kappa']
# taches et ids distinctes dans échantillon
out['taches_echantillon'] = len(set(x['tache'] for x in els))
json.dump(out, open(sys.argv[1],'w'), indent=1, ensure_ascii=False, default=str)
print(json.dumps(out, indent=1, ensure_ascii=False, default=str))
