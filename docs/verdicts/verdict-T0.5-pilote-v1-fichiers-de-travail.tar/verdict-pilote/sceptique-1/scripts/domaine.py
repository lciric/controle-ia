import json, sys
import numpy as np
ep = json.load(open(sys.argv[1] + "/diag/20261012-105125-t05-pilote-reel/episodes.json"))["resultat"]
tot, comp_tot, comp_rempli, comp_q99 = [], [], [], []
for f in ep["fiches"]:
    eq = f["equivalence"]
    long_tot = {f"{a['agent']},{a['pas']}": a["debut"] + len(a["ids"]) for a in f["actions"]}
    tot += list(long_tot.values())
    for k, n in eq["positions_capturees"].items():
        comp_tot.append(long_tot[k])
        comp_rempli.append(n + eq["lignes"][k]["remplissage"])
        comp_q99.append((long_tot[k], max(eq["ecarts_q99"][k].values())))
print("actions", len(tot), "max total", max(tot), "> 4752 :", sum(t > 4752 for t in tot))
print("comparees", len(comp_tot), "max total comparee", max(comp_tot), "comparees > 4752 :", sum(t > 4752 for t in comp_tot))
print("max (capturees + remplissage) comparee", max(comp_rempli))
print("q99 de la comparee la plus longue", max(comp_q99)[1])
print("contexte total des 5 plus longues comparees", sorted(comp_tot)[-5:])
au_dela = [(t, q) for t, q in comp_q99 if t > 4752]
print("comparees > 4752 : (longueur totale, q99 max sur couches)", sorted(au_dela))
print("ensemble des longueurs > 4752 (toutes actions)", sorted(t for t in tot if t > 4752))
