import json, sys
def walk(x, p, depth, maxlist):
    if isinstance(x, dict):
        for k, v in x.items():
            walk(v, p + "." + str(k), depth + 1, maxlist)
    elif isinstance(x, list):
        if len(x) and all(isinstance(e,(int,float,bool)) or e is None for e in x) and len(x) <= 12:
            print(p, "=", x)
            return
        print(p, "list len", len(x))
        for i, e in enumerate(x[:maxlist]):
            walk(e, p + "[%d]" % i, depth + 1, maxlist)
    elif isinstance(x, str):
        if len(x) <= int(sys.argv[3]):
            print(p, "=", repr(x))
        else:
            print(p, "= <str len %d>" % len(x))
    else:
        print(p, "=", x)
d = json.load(open(sys.argv[1]))
walk(d, "", 0, int(sys.argv[2]))
