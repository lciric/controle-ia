import json, sys
# Affiche uniquement les clés et les types (jamais les valeurs de chaîne), nombres et booléens affichés.
def walk(x, p, seen):
    if isinstance(x, dict):
        for k, v in x.items():
            walk(v, p + "." + str(k), seen)
    elif isinstance(x, list):
        key = p + "[]"
        if key not in seen:
            seen.add(key); print(key, "list")
        for e in x[:2]:
            walk(e, key, seen)
    else:
        if p not in seen:
            seen.add(p)
            if isinstance(x, str):
                print(p, "str")
            else:
                print(p, type(x).__name__, x if isinstance(x,(int,float,bool)) or x is None else "")
d = json.load(open(sys.argv[1]))
walk(d, "", set())
