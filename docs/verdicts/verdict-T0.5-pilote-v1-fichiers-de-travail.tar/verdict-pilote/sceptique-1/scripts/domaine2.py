import json, sys
ep = json.load(open(sys.argv[1] + "/diag/20261012-105125-t05-pilote-reel/episodes.json"))["resultat"]
d = []
for f in ep["fiches"]:
    eq = f["equivalence"]
    a_ = {f"{a['agent']},{a['pas']}": a for a in f["actions"]}
    for k, n in eq["positions_capturees"].items():
        a = a_[k]
        d.append((n, a["debut"] + len(a["ids"]), eq["longueurs_contexte"][k], a["debut"], len(a["ids"]), a["fin"]))
eg = sum(1 for x in d if x[0] == x[1]); print("capturees == debut+len(ids):", eg, "/", len(d))
print(d[:3])
print("max capturees", max(x[0] for x in d))
