# Recalcul indépendant (sceptique 1) : nombres seulement, aucun texte affiché, sans le code du dépôt.
import json, math, sys
from collections import Counter, defaultdict
import numpy as np
R = sys.argv[1]
ep = json.load(open(R + "/diag/20261012-105125-t05-pilote-reel/episodes.json"))["resultat"]
ap = json.load(open(R + "/diag/20261012-105125-t05-pilote-reel/appariements.json"))["resultat"]
et = json.load(open(R + "/diag/20261012-150724-t05-pilote-analyse/etiquettes.json"))["resultat"]
ec = json.load(open(R + "/diag/20261012-150724-t05-pilote-analyse/echantillon-etiquetage.json"))["resultat"]
le = json.load(open(R + "/diag/20261012-150724-t05-pilote-analyse/lecture.json"))["resultat"]
tb = json.load(open(R + "/donnees/t05-pilote-v1/taches-pilote-60-v1.json"))
taches = tb["resultat"]["taches"] if "resultat" in tb else tb["taches"]
T = {t["identifiant"]: {f: [c["id"] for c in t["cibles"][f]] for f in ("controls", "fruitful_directions", "sterile_directions")} for t in taches}
REF = {t["identifiant"]: (t["cibles"]["compute"].get("reference_gpu_hours"), t["cibles"]["compute"].get("basis")) for t in taches}
out = {}
fiches = ep["fiches"]
out["fiches"] = len(fiches)
out["actions"] = sum(f["bilan"]["actions"] for f in fiches)
out["actions_liste"] = sum(len(f["actions"]) for f in fiches)
out["valides"] = sum(f["bilan"]["actions_valides"] for f in fiches)
out["part_valides"] = out["valides"] / out["actions"]
# contextes
ctx = [a["debut"] + len(a["ids"]) for f in fiches for a in f["actions"]]
out["contexte_max"] = max(ctx); out["contexte_q99"] = float(np.quantile(ctx, 0.99))
comp_ctx, comp_q99 = [], []
for f in fiches:
    eq = f["equivalence"]
    for k, v in eq["longueurs_contexte"].items():
        comp_ctx.append(v)
    for k, d in eq["ecarts_q99"].items():
        comp_q99 += list(d.values()) if isinstance(d, dict) else [d]
out["comparees"] = len(comp_ctx)
out["contexte_max_comparees"] = max(comp_ctx)
out["comparees_au_dela_4752"] = sum(1 for c in comp_ctx if c > 4752)
out["actions_au_dela_4752"] = sum(1 for c in ctx if c > 4752)
out["q99_max_recalc"] = max(comp_q99)
out["controle_negatif"] = {k: ep["controle_negatif"][k] for k in ("comparables", "passent", "fraction", "lecture")}
# appariement
app = ap["appariements"]
out["paires"] = len(app); out["enonce_seul"] = len(ap["enonce_seul"])
p = np.array([a["p_oui"] for a in app])
out["egalites_0_5"] = int(np.sum(p == 0.5)); out["ge_0_5"] = int(np.sum(p >= 0.5)); out["gt_0_5"] = int(np.sum(p > 0.5))
out["valeurs_distinctes"] = len(set(p.tolist())); out["valeurs_distinctes_arrondi6"] = len(set(np.round(p, 6).tolist()))
strates = Counter((a["famille"], a["p_oui"] >= 0.5) for a in app)
out["strates"] = {f"{k[0]}|{'oui' if k[1] else 'non'}": v for k, v in sorted(strates.items())}
masse = np.array([a["masse_oui_non"] for a in app])
out["masse_mediane"] = float(np.median(masse)); out["masse_sous_0_1"] = float(np.mean(masse < 0.1))
# couvertures (A, C, D = e0, e1, e2), seuil ge et gt
pa = {a["cle"]: a["p_oui"] for a in app}
def couv(strict):
    oui = (lambda v: v > 0.5) if strict else (lambda v: v >= 0.5)
    pt = defaultdict(list)
    for f in fiches:
        nums = [q["numero"] for q in f["bilan"]["propositions"]]
        fec = T[f["tache"]]["fruitful_directions"]
        if nums and fec:
            pt[f["tache"]].append(sum(1 for c in fec if any(oui(pa[f"{f['episode']}/{n}/{c}"]) for n in nums)) / len(fec))
    return float(np.mean([np.mean(v) for v in pt.values()])), len(pt)
out["fecondes_ensemble_ge"] = couv(False); out["fecondes_ensemble_gt"] = couv(True)
# épisodes : vérifier lettres
out["episodes_par_suffixe"] = dict(Counter(f["episode"].rsplit("/", 1)[-1] for f in fiches))
# coût
logs, base = [], defaultdict(list); sans = 0
for f in fiches:
    ref, b = REF[f["tache"]]
    if not ref:
        continue
    for q in f["bilan"]["propositions"]:
        h = q.get("cout_heures")
        if h is None or not (h > 0) or not math.isfinite(h):
            sans += 1; continue
        v = math.log10(h / float(ref)); logs.append(v); base[b].append(v)
out["cout"] = {"taches_ref": sum(1 for r in REF.values() if r[0]), "n": len(logs), "sans": sans, "med": float(np.median(logs)),
               "par_base": {k: (len(v), float(np.median(v))) for k, v in base.items()}}
# étiquetage
el = et["elements"]
out["elements"] = len(el)
cnt = Counter((x["famille"], x["oui_8b"], x["etiquette"]) for x in el)
out["decomptes"] = {f"{k[0]}|8B={'oui' if k[1] else 'non'}|{k[2]}": v for k, v in sorted(cnt.items())}
# poids = effectif strate / 80
pw = Counter()
for x in el:
    pw[(x["famille"], x["oui_8b"])] += 1
out["poids_coherents"] = all(abs(x["poids"] - strates[(x["famille"], x["oui_8b"])] / pw[(x["famille"], x["oui_8b"])]) < 1e-9 for x in el)
def kap(xs):
    r = np.array([x["etiquette"] == "Yes" for x in xs]); j = np.array([x["oui_8b"] for x in xs]); w = np.array([x["poids"] for x in xs], float)
    W = w.sum(); po = w[r == j].sum() / W; pr = w[r].sum() / W; pj = w[j].sum() / W
    pe = pr * pj + (1 - pr) * (1 - pj)
    return {"kappa": float((po - pe) / (1 - pe)), "part_oui_8b": float(pj), "part_yes": float(pr), "accord": float(po)}
G = {"controls": ("controls",), "fruitful_directions": ("fruitful_directions",), "sterile_directions": ("sterile_directions",),
     "directions": ("fruitful_directions", "sterile_directions")}
out["kappas"] = {g: kap([x for x in el if x["famille"] in fs]) for g, fs in G.items()}
out["ecart_kappa_max"] = max(abs(out["kappas"][g]["kappa"] - le["kappas"][g]["kappa"]) for g in G)
out["diff_kappa"] = out["kappas"]["directions"]["kappa"] - out["kappas"]["controls"]["kappa"]
# relectures
out["relectures_actions"] = le["relectures_audit"]["actions"]
json.dump(out, open(sys.argv[2], "w"), indent=1, ensure_ascii=False)
print(json.dumps(out, indent=1, ensure_ascii=False))
