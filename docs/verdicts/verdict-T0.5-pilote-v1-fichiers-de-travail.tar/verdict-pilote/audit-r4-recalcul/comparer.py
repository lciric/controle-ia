import json, sys
L = json.load(open(sys.argv[1]))["resultat"]
R = json.load(open(sys.argv[2]))
def g(d, chemin):
    for k in chemin.split("."):
        d = d[k]
    return d
paires = [
 ("format.actions","format.actions"),("format.valides","format.valides"),("format.part_valides","format.part_valides"),
 ("format.part_strictes","format.part_strictes"),("format.part_plafond","format.part_plafond"),
 ("format.completude_controles","format.completude_controles"),("format.completude_cout","format.completude_cout"),
 ("format.part_cout_lu","format.part_cout_lu"),("format.ensembles_vides","format.ensembles_vides"),
 ("familles.controles_ensemble.valeur","familles.controles_ensemble.valeur"),("familles.controles_ensemble.taches","familles.controles_ensemble.taches"),
 ("familles.controles_proposition.valeur","familles.controles_proposition.valeur"),
 ("familles.fecondes_ensemble.valeur","familles.fecondes_ensemble.valeur"),
 ("familles.steriles_proposition.valeur","familles.steriles_proposition.valeur"),("familles.steriles_proposition.taches","familles.steriles_proposition.taches"),
 ("familles.part_ensembles_controles_0_ou_1","familles.part_ensembles_controles_0_ou_1"),
 ("enonce_seul.cibles_couvertes","enonce_seul.cibles_couvertes"),
 ("enonce_seul.parts.controls","enonce_seul.parts.controls"),("enonce_seul.parts.fruitful_directions","enonce_seul.parts.fruitful_directions"),
 ("enonce_seul.parts.sterile_directions","enonce_seul.parts.sterile_directions"),
 ("familles_hors_enonce.controles_ensemble.valeur","familles_hors_enonce.controles_ensemble.valeur"),
 ("familles_hors_enonce.controles_ensemble.taches","familles_hors_enonce.controles_ensemble.taches"),
 ("familles_hors_enonce.controles_proposition.valeur","familles_hors_enonce.controles_proposition.valeur"),
 ("familles_hors_enonce.fecondes_ensemble.valeur","familles_hors_enonce.fecondes_ensemble.valeur"),
 ("familles_hors_enonce.fecondes_ensemble.taches","familles_hors_enonce.fecondes_ensemble.taches"),
 ("familles_hors_enonce.steriles_proposition.valeur","familles_hors_enonce.steriles_proposition.valeur"),
 ("familles_hors_enonce.steriles_proposition.taches","familles_hors_enonce.steriles_proposition.taches"),
 ("cout.taches_avec_reference","cout.taches_avec_reference"),("cout.propositions","cout.propositions"),("cout.sans_nombre","cout.sans_nombre"),
 ("cout.mediane_log10","cout.mediane_log10"),("cout.par_base.estimated.mediane_log10","cout.par_base.estimated.mediane_log10"),
 ("cout.par_base.estimated.n","cout.par_base.estimated.n"),("cout.par_base.reported.mediane_log10","cout.par_base.reported.mediane_log10"),
 ("cout.par_base.reported.n","cout.par_base.reported.n"),
 ("lisibilite_appariement.mediane","lisibilite.mediane"),("lisibilite_appariement.part_sous_seuil","lisibilite.part_sous_seuil"),
 ("lisibilite_appariement.lisible","lisibilite.lisible"),
]
for g_ in ("controls","fruitful_directions","sterile_directions","directions"):
    for k in ("n","kappa","accord","accord_positif","accord_negatif"):
        paires.append((f"kappas.{g_}.{k}", f"kappas.{g_}.{k}"))
paires.append(("difference_kappas.difference","difference_kappas"))
paires.append(("steriles_taches","steriles_taches"))
emax = 0
for a, b in paires:
    x, y = g(L, a), g(R, b)
    if isinstance(x, bool) or isinstance(x, int) and isinstance(y, int):
        e = "0" if x == y else "DIFF"
    else:
        d = abs(x - y); emax = max(emax, d); e = f"{d:.1e}"
    print(f"| {a} | {x} | {y} | {e} |")
print("ecart max flottant", emax)
