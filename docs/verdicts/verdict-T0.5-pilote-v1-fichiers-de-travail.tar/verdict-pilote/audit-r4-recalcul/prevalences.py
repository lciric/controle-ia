import json, sys
from collections import Counter
e = json.load(open(sys.argv[1]))["resultat"]["elements"]
for fam in ("controls","fruitful_directions","sterile_directions"):
    el=[x for x in e if x["famille"]==fam]
    W=sum(x["poids"] for x in el)
    pr=sum(x["poids"] for x in el if x["etiquette"]=="Yes")/W
    pj=sum(x["poids"] for x in el if x["oui_8b"])/W
    c=Counter((x["oui_8b"],x["etiquette"]) for x in el)
    print(fam, "Yes pondere", round(pr,3), "oui 8B pondere", round(pj,3), dict(c))
