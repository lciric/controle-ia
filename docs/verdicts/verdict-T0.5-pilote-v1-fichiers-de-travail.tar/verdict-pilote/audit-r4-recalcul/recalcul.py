"""Recalcul indépendant (audit R4) des grandeurs du pilote T0.5 depuis les résultats scellés.

N'importe rien du dépôt. Lit : episodes.json, appariements.json, taches-pilote-60-v1.json, etiquettes.json,
echantillon-etiquetage.json. Vérifie les sceaux .sha256. Écrit recalcul.json dans le dossier de travail.
Usage : python3 -I recalcul.py RACINE_DEPOT DOSSIER_SORTIE
"""
import hashlib
import json
import math
import re
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

RACINE = Path(sys.argv[1])
SORTIE = Path(sys.argv[2])
PILOTE = RACINE / "diag/20261012-105125-t05-pilote-reel"
ANALYSE = RACINE / "diag/20261012-150724-t05-pilote-analyse"
TACHES = RACINE / "donnees/t05-pilote-v1/taches-pilote-60-v1.json"
SEUIL = 0.5
PLAFOND = 400
TAILLE_MAX = 10


def sha_fichier(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for bloc in iter(lambda: f.read(1 << 20), b""):
            h.update(bloc)
    return h.hexdigest()


def charger_scelle(p: Path):
    sceau = Path(str(p) + ".sha256").read_text().split()
    assert sceau[1] == p.name, (p, sceau)
    calc = sha_fichier(p)
    assert calc == sceau[0], f"sceau non conforme : {p}"
    return json.loads(p.read_text(encoding="utf-8")), calc


sceaux = {}
episodes, sceaux["episodes.json"] = charger_scelle(PILOTE / "episodes.json")
appar, sceaux["appariements.json"] = charger_scelle(PILOTE / "appariements.json")
etiq, sceaux["etiquettes.json"] = charger_scelle(ANALYSE / "etiquettes.json")
ech, sceaux["echantillon-etiquetage.json"] = charger_scelle(ANALYSE / "echantillon-etiquetage.json")
taches_brut, sceaux["taches-pilote-60-v1.json"] = charger_scelle(TACHES)

fiches = episodes["resultat"]["fiches"]
taches = {t["identifiant"]: t for t in taches_brut["taches"]}
FAMS = ("controls", "fruitful_directions", "sterile_directions")
PREFIXE = {"controls": "C", "fruitful_directions": "F", "sterile_directions": "S"}

# ---------------------------------------------------------------------------------------------- lecture d'action
CLES = ("ACTION", "TITLE", "PROPOSAL", "CONTROLS", "COST", "PREDICTION")
RE_MD = re.compile(r"[*_]{1,3}(" + "|".join(CLES) + r")\s*:?\s*[*_]{1,3}\s*:?", re.I)
RE_ACT = re.compile(r"^\s*ACTION\s*:\s*(ADD|REVISE)\b\s*(?:proposal\s*)?[#(]?\s*(\d+)?", re.I | re.M)
RE_CLE = re.compile(r"^\s*(" + "|".join(CLES) + r")\s*:", re.I | re.M)
RE_NB = re.compile(r"(\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:[.,]\d+)?)\s*([kK])?(?![A-Za-z])")
RE_MIL = re.compile(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?")


def lire(texte: str, premiere_stricte: bool = False):
    """Rend (operation, numero, champs) ou None si pas de ligne ACTION exploitable."""
    t = RE_MD.sub(lambda m: m.group(1) + ":", texte)
    m = RE_ACT.search(t)
    if not m:
        return None
    op = m.group(1).upper()
    num = int(m.group(2)) if m.group(2) else None
    if op == "REVISE" and num is None:
        return None
    pos = [(x.start(), x.end(), x.group(1).upper()) for x in RE_CLE.finditer(t)]
    champs, vus = {}, set()
    for i, (d, f, cle) in enumerate(pos):
        if cle == "ACTION":
            continue
        if premiere_stricte and cle in vus:
            continue
        vus.add(cle)
        if cle in champs:
            continue
        fin = pos[i + 1][0] if i + 1 < len(pos) else len(t)
        v = t[f:fin].strip()
        if v:
            champs[cle] = v
    return op, num, champs


def heures(cout):
    if not cout:
        return None
    m = RE_NB.search(cout)
    if not m:
        return None
    n = m.group(1)
    v = float(n.replace(",", "")) if RE_MIL.fullmatch(n) else float(n.replace(",", "."))
    return v * 1000 if m.group(2) else v


def strict(texte: str) -> bool:
    if not texte.lstrip().startswith("ACTION"):
        return False
    vues = []
    for ligne in texte.split("\n"):
        m = re.match(r"(ACTION|TITLE|PROPOSAL|CONTROLS|COST|PREDICTION)\s*:", ligne)
        if m:
            vues.append(m.group(1))
    return vues == list(CLES)


# ---------------------------------------------------------------------------------------------- format
tot = val_rejeu = val_stocke = strictes = plafond = ctl = cst = lu = lu_naif = 0
desaccords_valide = 0
desaccords_valide_premiere = 0
for f in fiches:
    acts, hist = f["actions"], f["bilan"]["historique"]
    assert len(acts) == len(hist)
    props = {}  # numero -> version
    props_p = {}
    for a, h in zip(acts, hist):
        tot += 1
        strictes += strict(a["texte"])
        plafond += len(a["ids"]) >= PLAFOND
        val_stocke += bool(h["valide"])
        # rejeu indépendant
        r = lire(a["texte"])
        ok = r is not None and "TITLE" in r[2] and "PROPOSAL" in r[2]
        if ok and r[0] == "ADD" and len(props) >= TAILLE_MAX:
            ok = False
        if ok and r[0] == "REVISE" and r[1] not in props:
            ok = False
        if ok:
            n = len(props) + 1 if r[0] == "ADD" else r[1]
            props[n] = props.get(n, 0) + 1
            val_rejeu += 1
            ctl += "CONTROLS" in r[2]
            cst += "COST" in r[2]
            lu += heures(r[2].get("COST")) is not None
            lu_naif += bool(re.search(r"\d", r[2].get("COST", "")))
        desaccords_valide += ok != bool(h["valide"])
        # variante « première occurrence stricte »
        r2 = lire(a["texte"], premiere_stricte=True)
        ok2 = r2 is not None and "TITLE" in r2[2] and "PROPOSAL" in r2[2]
        if ok2 and r2[0] == "ADD" and len(props_p) >= TAILLE_MAX:
            ok2 = False
        if ok2 and r2[0] == "REVISE" and r2[1] not in props_p:
            ok2 = False
        if ok2:
            n2 = len(props_p) + 1 if r2[0] == "ADD" else r2[1]
            props_p[n2] = 1
        desaccords_valide_premiere += ok2 != bool(h["valide"])
    # l'ensemble final rejoué doit avoir le nombre de propositions consigné
    assert len(props) == len(f["bilan"]["propositions"]), f["episode"]

fmt = {"actions": tot, "valides": val_rejeu, "valides_stockees": val_stocke,
       "part_valides": val_rejeu / tot, "part_strictes": strictes / tot, "part_plafond": plafond / tot,
       "completude_controles": ctl / val_rejeu, "completude_cout": cst / val_rejeu, "part_cout_lu": lu / val_rejeu,
       "part_cout_lu_naif_un_chiffre": lu_naif / val_rejeu,
       "desaccords_valide_rejeu_vs_historique": desaccords_valide,
       "desaccords_valide_variante_premiere_occurrence": desaccords_valide_premiere,
       "ensembles_vides": sum(1 for f in fiches if not f["bilan"]["propositions"])}

# ---------------------------------------------------------------------------------------------- appariements
app = appar["resultat"]["appariements"]
enonce = appar["resultat"]["enonce_seul"]
P = {a["cle"]: a for a in app}
assert len(P) == len(app)
attendues = set()
fam_de = {}
for f in fiches:
    t = taches[f["tache"]]
    for p in f["bilan"]["propositions"]:
        for fam in FAMS:
            for c in t["cibles"][fam]:
                k = f"{f['episode']}/{p['numero']}/{c['id']}"
                attendues.add(k)
                fam_de[k] = fam
paires_controle = {"posees_attendues": len(attendues), "notees": len(P),
                   "manquantes": len(attendues - set(P)), "en_trop": len(set(P) - attendues),
                   "famille_incoherente": sum(1 for k in P if k in fam_de and P[k]["famille"] != fam_de[k])}


def episode_k(ep):
    return ep.rsplit("/e", 1)[1]


def couvertures(exclues=None):
    exclues = exclues or {}
    vals = {m: defaultdict(list) for m in ("ce", "cp", "fe", "sp")}
    ens_ctl, vides = [], 0
    for f in fiches:
        assert episode_k(f["episode"]) in ("0", "1", "2")
        t = taches[f["tache"]]
        nums = [p["numero"] for p in f["bilan"]["propositions"]]
        if not nums:
            vides += 1
            continue

        def oui(n, c):
            return P[f"{f['episode']}/{n}/{c}"]["p_oui"] >= SEUIL

        def ids(fam):
            return [c["id"] for c in t["cibles"][fam] if c["id"] not in exclues.get((f["tache"], fam), set())]

        C, F, S = ids("controls"), ids("fruitful_directions"), ids("sterile_directions")
        if C:
            couv = sum(any(oui(n, c) for n in nums) for c in C) / len(C)
            vals["ce"][f["tache"]].append(couv)
            vals["cp"][f["tache"]].append(sum(any(oui(n, c) for c in C) for n in nums) / len(nums))
            ens_ctl.append(couv)
        if F:
            vals["fe"][f["tache"]].append(sum(any(oui(n, c) for n in nums) for c in F) / len(F))
        if S:
            vals["sp"][f["tache"]].append(sum(any(oui(n, c) for c in S) for n in nums) / len(nums))
    out = {"ensembles_vides": vides}
    noms = {"ce": "controles_ensemble", "cp": "controles_proposition", "fe": "fecondes_ensemble",
            "sp": "steriles_proposition"}
    for m, d in vals.items():
        par_t = [sum(v) / len(v) for v in d.values()]
        out[noms[m]] = {"valeur": (sum(par_t) / len(par_t)) if par_t else None, "taches": len(par_t)}
    out["part_ensembles_controles_0_ou_1"] = sum(c in (0.0, 1.0) for c in ens_ctl) / len(ens_ctl)
    out["ensembles_par_tache"] = sorted(Counter(len(v) for v in vals["ce"].values()).items())
    return out


fam = couvertures()

# base « énoncé seul »
E = {a["cle"]: a for a in enonce}
exclues, parts, ncouv = {}, {f: [] for f in FAMS}, 0
for ident, t in taches.items():
    for fm in FAMS:
        ids = [c["id"] for c in t["cibles"][fm]]
        if not ids:
            continue
        oui = [c for c in ids if E[f"{ident}/enonce/{c}"]["p_oui"] >= SEUIL]
        parts[fm].append(len(oui) / len(ids))
        ncouv += len(oui)
        if oui:
            exclues[(ident, fm)] = set(oui)
base = {"cibles_couvertes": ncouv, "paires_enonce": len(E),
        "parts": {fm: sum(v) / len(v) for fm, v in parts.items()},
        "taches_par_famille": {fm: len(v) for fm, v in parts.items()}}
hors = couvertures(exclues)

# ---------------------------------------------------------------------------------------------- coût
logs, par_base, sans, ecart_heures = [], defaultdict(list), 0, 0
avec_ref = {i for i, t in taches.items() if t["cibles"]["compute"].get("reference_gpu_hours")}
for f in fiches:
    if f["tache"] not in avec_ref:
        continue
    ref = taches[f["tache"]]["cibles"]["compute"]
    for p in f["bilan"]["propositions"]:
        h = heures(p.get("cout_texte"))
        hs = p.get("cout_heures")
        if (h is None) != (hs is None) or (h is not None and h != hs):
            ecart_heures += 1
        if h is None or not (h > 0) or not math.isfinite(h):
            sans += 1
            continue
        v = math.log10(h / float(ref["reference_gpu_hours"]))
        logs.append(v)
        par_base[ref["basis"]].append(v)
cout = {"taches_avec_reference": len(avec_ref), "propositions": len(logs), "sans_nombre": sans,
        "mediane_log10": statistics.median(logs),
        "par_base": {b: {"n": len(v), "mediane_log10": statistics.median(v)} for b, v in par_base.items()},
        "heures_recalculees_differentes_du_stocke": ecart_heures}

# ---------------------------------------------------------------------------------------------- lisibilité
masses = sorted(a["masse_oui_non"] for a in app)
lis = {"mediane": statistics.median(masses), "part_sous_seuil": sum(m < 0.1 for m in masses) / len(masses),
       "n": len(masses), "p_oui_min": min(a["p_oui"] for a in app), "p_oui_max": max(a["p_oui"] for a in app)}
lis["lisible"] = lis["mediane"] >= 0.5 and lis["part_sous_seuil"] < 0.05

# ---------------------------------------------------------------------------------------------- kappa
elements = etiq["resultat"]["elements"]
pop = Counter((a["famille"], a["p_oui"] >= SEUIL) for a in app)
ech_n = Counter((x["famille"], x["oui_8b"]) for x in elements)
controles_el = {"elements": len(elements), "cles_absentes": 0, "oui_8b_incoherent": 0, "famille_incoherente": 0,
                "tache_incoherente": 0, "strate_incoherente": 0, "poids_ecart_max": 0.0, "doublons": 0,
                "etiquettes": dict(Counter(x["etiquette"] for x in elements))}
controles_el["doublons"] = len(elements) - len({x["cle"] for x in elements})
poids = {}
for x in elements:
    a = P.get(x["cle"])
    if a is None:
        controles_el["cles_absentes"] += 1
        continue
    o = a["p_oui"] >= SEUIL
    controles_el["oui_8b_incoherent"] += o != x["oui_8b"]
    controles_el["famille_incoherente"] += (a["famille"] != x["famille"]) or \
        (x["cle"].rsplit("/", 1)[1][0] != PREFIXE[x["famille"]])
    controles_el["tache_incoherente"] += x["cle"].split("/e", 1)[0] != x["tache"]
    controles_el["strate_incoherente"] += list(x["strate"]) != [x["famille"], x["oui_8b"]]
    w = pop[(a["famille"], o)] / ech_n[(a["famille"], o)]
    poids[x["id"]] = w
    controles_el["poids_ecart_max"] = max(controles_el["poids_ecart_max"], abs(w - x["poids"]))
controles_el["strates_population"] = {f"{k[0]}|{'oui' if k[1] else 'non'}": v for k, v in sorted(pop.items())}
controles_el["strates_echantillon"] = {f"{k[0]}|{'oui' if k[1] else 'non'}": v for k, v in sorted(ech_n.items())}
controles_el["strates_population_egales_echantillon_etiquetage_json"] = (
    controles_el["strates_population"] == ech["resultat"]["strates"])
# engagement : éléments sans étiquette, même ordre
sans_etiq = [{k: v for k, v in x.items() if k != "etiquette"} for x in elements]
eng = hashlib.sha256(json.dumps(sans_etiq, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()
controles_el["engagement_recalcule_egal"] = eng == ech["resultat"]["engagement_sha256"]


def kappa_w(el):
    W = sum(poids[x["id"]] for x in el)
    r = [x["etiquette"] == "Yes" for x in el]
    j = [x["oui_8b"] for x in el]
    w = [poids[x["id"]] for x in el]
    a = sum(wi for ri, ji, wi in zip(r, j, w) if ri and ji)
    b = sum(wi for ri, ji, wi in zip(r, j, w) if ri and not ji)
    c = sum(wi for ri, ji, wi in zip(r, j, w) if not ri and ji)
    d = sum(wi for ri, ji, wi in zip(r, j, w) if not ri and not ji)
    po = (a + d) / W
    pr, pj = (a + b) / W, (a + c) / W
    pe = pr * pj + (1 - pr) * (1 - pj)
    return {"n": len(el), "kappa": (po - pe) / (1 - pe) if pe < 1 else None, "accord": po,
            "accord_positif": 2 * a / (2 * a + b + c) if 2 * a + b + c else None,
            "accord_negatif": 2 * d / (2 * d + b + c) if 2 * d + b + c else None,
            "kappa_non_pondere": None}


def kappa_simple(el):
    n = len(el)
    r = [x["etiquette"] == "Yes" for x in el]
    j = [x["oui_8b"] for x in el]
    po = sum(ri == ji for ri, ji in zip(r, j)) / n
    pr, pj = sum(r) / n, sum(j) / n
    pe = pr * pj + (1 - pr) * (1 - pj)
    return (po - pe) / (1 - pe) if pe < 1 else None


GROUPES = {"controls": ("controls",), "fruitful_directions": ("fruitful_directions",),
           "sterile_directions": ("sterile_directions",), "directions": ("fruitful_directions", "sterile_directions")}
kap = {}
for g, fs in GROUPES.items():
    el = [x for x in elements if x["famille"] in fs]
    kap[g] = kappa_w(el)
    kap[g]["kappa_non_pondere"] = kappa_simple(el)
diff_kappa = kap["directions"]["kappa"] - kap["controls"]["kappa"]

# ---------------------------------------------------------------------------------------------- retenue (contrôle)
steriles_taches = sum(1 for t in taches.values() if t["cibles"]["sterile_directions"])

res = {"sceaux": sceaux, "format": fmt, "paires": paires_controle, "familles": fam, "enonce_seul": base,
       "familles_hors_enonce": hors, "cout": cout, "lisibilite": lis, "controles_elements": controles_el,
       "kappas": kap, "difference_kappas": diff_kappa, "steriles_taches": steriles_taches}
SORTIE.mkdir(parents=True, exist_ok=True)
(SORTIE / "recalcul.json").write_text(json.dumps(res, indent=1, ensure_ascii=False), encoding="utf-8")
print(json.dumps(res, indent=1, ensure_ascii=False))
