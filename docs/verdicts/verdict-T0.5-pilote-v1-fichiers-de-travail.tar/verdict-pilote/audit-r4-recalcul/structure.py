import json, sys
def shape(x, depth=0, maxd=4):
    if depth > maxd: return "…"
    if isinstance(x, dict):
        return {k: shape(v, depth+1, maxd) for k, v in list(x.items())[:40]}
    if isinstance(x, list):
        return [f"len={len(x)}", shape(x[0], depth+1, maxd)] if x else []
    if isinstance(x, str):
        return f"str({len(x)})"
    return type(x).__name__ + ":" + (repr(x) if isinstance(x,(int,float,bool)) or x is None else "")
for p in sys.argv[1:]:
    d = json.load(open(p))
    print("=====", p)
    print(json.dumps(shape(d, maxd=int(__import__('os').environ.get('MAXD','5'))), ensure_ascii=False, indent=1)[:6000])
