# Action 6 : 2510.18828v1/e1/0,5
tâche 2510.18828v1 ; jetons de l'action 196 ; jetons ids 196
## Historique de cette action
[{"agent": 0, "manquants": [], "motif": "REVISE without a proposal number", "numero": null, "operation": "REVISE", "pas": 5, "valide": false}]
## Texte de l'action
ACTION: REVISE
TITLE: Improving Actor-Free Methods with Hierarchical Exploration-Exploitation
PROPOSAL: We will modify the distributional Q-Learning method to incorporate hierarchical exploration-exploitation, by using a meta-policy to select a sub-policy that can adapt to different parts of the value function. This should allow us to better balance exploration and exploitation, and improve the agency's ability to adapt to high-dimensional action spaces.
CONTROLS: Evaluating the efficacy of standard hierarchy-free exploration-exploitation methods, such as epsilon-greedy and Thompson sampling
COST: 20,000 GPU-hours
PREDICTION: Our modified distributional Q-Learning method may allow it to outperform the standard method on a range of synthetic and simulated tasks, by leveraging the structure of the value function to improve the exploration-exploitation trade-off. However, we also expect that the added complexity of the meta-policy may lead to increased computational requirements.

## Historique complet de l'épisode (opérations seulement)
pas 0: ADD n°1 valide=True motif=None manquants=[]; pas 1: ADD n°2 valide=True motif=None manquants=[]; pas 2: REVISE n°None valide=False motif=REVISE without a proposal number manquants=[]; pas 3: ADD n°3 valide=True motif=None manquants=[]; pas 4: ADD n°4 valide=True motif=None manquants=[]; pas 5: REVISE n°None valide=False motif=REVISE without a proposal number manquants=[]; pas 6: ADD n°5 valide=True motif=None manquants=[]; pas 7: ADD n°6 valide=True motif=None manquants=[]; pas 8: ADD n°7 valide=True motif=None manquants=[]; pas 9: ADD n°8 valide=True motif=None manquants=[]
## Ensemble final : numéros et pas d'origine, titres
- n°1 pas 0 auteur 0 ; coût '20,000 GPU-hours'
- n°2 pas 1 auteur 0 ; coût '15,000 GPU-hours'
- n°3 pas 3 auteur 0 ; coût '12,000 GPU-hours'
- n°4 pas 4 auteur 0 ; coût '25,000 GPU-hours'
- n°5 pas 6 auteur 0 ; coût '8,000 GPU-hours (note: this proposal does not require significant computational resources)'
- n°6 pas 7 auteur 0 ; coût '35,000 GPU-hours'
- n°7 pas 8 auteur 0 ; coût '30,000 GPU-hours'
- n°8 pas 9 auteur 0 ; coût '40,000 GPU-hours'
## Propositions de l'ensemble final issues de cette action (pas égal)
## Cibles de la tâche, avec P(oui) de l'énoncé seul et P(oui) par proposition de l'ensemble final
### controls
- C1 [énoncé 0.593] [couvert par l'ensemble : False] par proposition {1: 0.068, 2: 0.245, 3: 0.006, 4: 0.133, 5: 0.165, 6: 0.033, 7: 0.029, 8: 0.076}
    Compares the proposed method against a strong, well-tuned deterministic actor-critic baseline for continuous control (e.g., TD3 with twin critics, delayed policy updates and target policy smoothing), the established approach an actor-free method must match.
- C2 [énoncé 0.562] [couvert par l'ensemble : False] par proposition {1: 0.053, 2: 0.068, 3: 0.107, 4: 0.107, 5: 0.06, 6: 0.047, 7: 0.095, 8: 0.269}
    Includes prior actor-free value-based methods for continuous actions as baselines (e.g., a quadratic-advantage method such as NAF and a radial-basis-function Q-network such as RBF-DQN), run with their official code and hyperparameters, or tuned when these are unavailable.
- C3 [énoncé 0.622] [couvert par l'ensemble : True] par proposition {1: 0.119, 2: 0.245, 3: 0.047, 4: 0.622, 5: 0.095, 6: 0.005, 7: 0.009, 8: 0.068}
    Evaluates on action-constrained variants of standard tasks (only the admissible action set is restricted, e.g. to a union of regions, with observations, dynamics and rewards unchanged) alongside their unconstrained originals, to test performance on non-convex Q-landscapes against the standard case.
- C4 [énoncé 0.245] [couvert par l'ensemble : False] par proposition {1: 0.223, 2: 0.202, 3: 0.06, 4: 0.085, 5: 0.033, 6: 0.042, 7: 0.076, 8: 0.245}
    Runs every method with multiple independent random seeds (around 10), evaluates periodically over several rollout episodes, and reports the mean with standard error across seeds.
- C5 [énoncé 0.407] [couvert par l'ensemble : False] par proposition {1: 0.269, 2: 0.119, 3: 0.002, 4: 0.053, 5: 0.002, 6: 0.06, 7: 0.085, 8: 0.148}
    Implements the proposed method in the same codebase as the baselines (with baselines using official implementations and tuned hyperparameters) to rule out implementation-level differences.
- C6 [énoncé 0.469] [couvert par l'ensemble : False] par proposition {1: 0.245, 2: 0.321, 3: 0.003, 4: 0.076, 5: 0.026, 6: 0.008, 7: 0.004, 8: 0.06}
    Measures wall-clock time and memory of the actor-free method against actor-critic baselines, with the critic parameter count matched so that the effect of removing the actor is isolated.
### fruitful_directions
- F1 [énoncé 0.932] [couvert par l'ensemble : True] par proposition {1: 0.407, 2: 0.622, 3: 0.622, 4: 0.731, 5: 0.622, 6: 0.294, 7: 0.438, 8: 0.5}
    Make the Q-function structurally maximizable: represent Q(s, a) through a finite set of state-dependent learned candidate actions (control-points) and their values, combined by wire-fitting (inverse-distance weighted) interpolation so that the maximum is guaranteed to lie at the highest-valued control-point; greedy action selection and the Bellman max then reduce to an argmax over a few scalars, with no actor network, trained with TD3-style tools (twin critics, target networks, target policy smoothing, Gaussian exploration noise).
- F2 [énoncé 0.798] [couvert par l'ensemble : False] par proposition {1: 0.245, 2: 0.119, 3: 0.349, 4: 0.321, 5: 0.107, 6: 0.148, 7: 0.182, 8: 0.245}
    Stabilize deep control-point Q-learning with: action-conditioned Q-value generation (one network proposes the control-point actions, a shared Q-estimator scores each of them), top-k relevance filtering of control-points in the interpolation, a separation/diversity loss that spreads control-points over the action space, and normalization of Q-value differences (with an annealed smoothing factor) in the interpolation weights for robustness across tasks.
- F3 [énoncé 0.755] [couvert par l'ensemble : True] par proposition {1: 0.593, 2: 0.562, 3: 0.593, 4: 0.798, 5: 0.223, 6: 0.245, 7: 0.349, 8: 0.294}
    Target constrained action spaces with non-convex Q-landscapes, where direct maximization over a learned structurally maximizable Q-function avoids the local optima of gradient-based actors and consistently beats TD3.
### sterile_directions
- S1 [énoncé 0.223] [couvert par l'ensemble : False] par proposition {1: 0.095, 2: 0.047, 3: 0.294, 4: 0.165, 5: 0.026, 6: 0.047, 7: 0.076, 8: 0.003}
    Directly applying classical wire-fitting (control-point interpolation) Q-learning with deep networks, without stabilizing modifications such as action-conditioned values, relevance filtering, diversity loss or normalization.
- S2 [énoncé 0.076] [couvert par l'ensemble : True] par proposition {1: 0.562, 2: 0.182, 3: 0.378, 4: 0.593, 5: 0.202, 6: 0.095, 7: 0.076, 8: 0.182}
    Constraining the Q-function (advantage) to be quadratic in the action, NAF-style, so that the maximizing action is obtained analytically.
- S3 [énoncé 0.777] [couvert par l'ensemble : True] par proposition {1: 0.407, 2: 0.407, 3: 0.294, 4: 0.622, 5: 0.133, 6: 0.245, 7: 0.119, 8: 0.182}
    Using a radial-basis-function output layer over action centroids (RBF-DQN-style) as the actor-free Q-function representation.
## Énoncé de la tâche
Reinforcement learning has been highly effective in many domains, ranging from robotics to gaming and recommender systems. Value-based algorithms such as Deep Q-Networks are a cornerstone of off-policy reinforcement learning and are widely used in discrete action spaces because of their simplicity, training stability, and sample-efficiency. However, they rely on estimating Q-values for individual state-action pairs and require a maximization over the action space, both to derive the greedy policy and to evaluate the best next-state value in the Bellman target. This maximization is straightforward when the actions can be enumerated, but in continuous action spaces evaluating the Q-value over the entire action space becomes computationally infeasible, which has traditionally restricted value-based methods to discrete actions.

In continuous control, actor-critic methods such as DDPG, TD3, and SAC are typically used instead: a critic is trained on off-policy data to estimate Q-values, and an actor (policy) is trained to output actions that maximize the critic. While powerful, these methods often suffer from instability caused by the coupled training of actor and critic, from sensitivity to hyperparameters, and from the difficulty of predicting in high-dimensional action spaces. The additional actor network brings its own hyperparameters, which makes reproducibility a challenge, and adds computational and memory overhead. Moreover, an actor trained by gradient ascent on the Q-function landscape can only find locally optimal actions, which becomes a serious limitation when the Q-function is complex or non-convex, for instance when the action space is constrained so that actions must remain within specific safety bounds. Training several actors to explore different modes of the Q-function alleviates this, but adds computational overhead and inference-time latency, and the actor's parameterization may still be too limited to capture complex optimal actions.

Actor-free, value-based alternatives must instead carry out the maximization over continuous actions themselves, and finding the maximizing action has been their primary bottleneck. Methods that perform this maximization numerically, through mixed-integer programming, the cross-entropy method and other sampling-based or evolutionary search, or gradient ascent on the action, tend either to return suboptimal local maxima or to be computationally impractical, and sampling becomes progressively less efficient as the action dimension grows. Discretizing the action space is effective in low dimensions but does not scale to high-dimensional tasks. Another line of work restricts the functional form of the Q-function so that its maximizer can be obtained directly, for example by assuming that the advantage is quadratic in the action or that the Q-function is convex in the action; such assumptions limit expressivity and practical applicability. Representing the Q-function with a radial basis function output layer makes the best action easier to identify, but introduces an implicit trade-off between how expressive the Q-function can be in modeling multiple local optima and how accurately its maximizing action is recovered.

This raises the question of whether an actor-free, value-based algorithm can efficiently and accurately select optimal actions in continuous action spaces without imposing restrictive assumptions on the shape of the Q-function, while remaining stable to train, robust across diverse tasks, and scalable to high-dimensional action spaces. Such an algorithm would retain the simplicity of Q-learning and avoid the cost and instability of learning a separate actor; it could also avoid the local optima that trap gradient-based actors when the Q-function is highly non-convex, as in constrained action spaces. Can such an approach be made competitive with established actor-critic methods for continuous control, and can it outperform them where gradient-based action maximization struggles?