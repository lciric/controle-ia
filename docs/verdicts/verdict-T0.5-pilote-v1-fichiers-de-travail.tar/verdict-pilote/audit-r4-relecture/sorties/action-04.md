# Action 4 : 2509.21880v3/e1/0,3
tâche 2509.21880v3 ; jetons de l'action 184 ; jetons ids 184
## Historique de cette action
[{"agent": 0, "manquants": [], "motif": "REVISE without a proposal number", "numero": null, "operation": "REVISE", "pas": 3, "valide": false}]
## Texte de l'action
ACTION: REVISE
TITLE: Reward Shaping with Zero-Variance Prompts
PROPOSAL: Incorporate a novel zero-variance loss function into the model training process, which computes a weighted difference between the policy's output logit and a target logit estimated from the zero-variance prompt's logit distribution. This loss function is designed to provide informative feedback for policy optimization, even in the absence of contrasting responses.
CONTROLS: Compare to standard rewards, existing methods that filter out zero-variance prompts, and the previous version of Reward Shaping with Zero-Variance Prompts (Turn 3); analyze the effect of zero-variance loss function hyperparameters on model performance.
COST: 25 GPU-hours
PREDICTION: We expect that the revised zero-variance loss function will lead to improved training stability and overall model performance, especially in scenarios where zero-variance prompts are prevalent.

## Historique complet de l'épisode (opérations seulement)
pas 0: ADD n°1 valide=True motif=None manquants=[]; pas 1: ADD n°2 valide=True motif=None manquants=[]; pas 2: ADD n°3 valide=True motif=None manquants=[]; pas 3: REVISE n°None valide=False motif=REVISE without a proposal number manquants=[]; pas 4: REVISE n°None valide=False motif=REVISE without a proposal number manquants=[]; pas 5: ADD n°4 valide=True motif=None manquants=[]; pas 6: ADD n°5 valide=True motif=None manquants=[]; pas 7: ADD n°6 valide=True motif=None manquants=[]; pas 8: ADD n°7 valide=True motif=None manquants=[]; pas 9: ADD n°8 valide=True motif=None manquants=[]
## Ensemble final : numéros et pas d'origine, titres
- n°1 pas 0 auteur 0 ; coût '10 GPU-hours'
- n°2 pas 1 auteur 0 ; coût '20 GPU-hours'
- n°3 pas 2 auteur 0 ; coût '30 GPU-hours'
- n°4 pas 5 auteur 0 ; coût '50 GPU-hours'
- n°5 pas 6 auteur 0 ; coût '80 GPU-hours'
- n°6 pas 7 auteur 0 ; coût '60 GPU-hours ( approximating using cpus)'
- n°7 pas 8 auteur 0 ; coût '90 GPU-hours'
- n°8 pas 9 auteur 0 ; coût '120 GPU-hours'
## Propositions de l'ensemble final issues de cette action (pas égal)
## Cibles de la tâche, avec P(oui) de l'énoncé seul et P(oui) par proposition de l'ensemble final
### controls
- C1 [énoncé 0.294] [couvert par l'ensemble : True] par proposition {1: 0.378, 2: 0.349, 3: 0.651, 4: 0.651, 5: 0.223, 6: 0.294, 7: 0.469, 8: 0.029}
    Standard GRPO baseline, in which prompts whose rollouts all receive the same reward get zero advantage, trained on the same data with the same hyperparameters, pipeline and number of rollouts as the proposed method.
- C2 [énoncé 0.321] [couvert par l'ensemble : True] par proposition {1: 0.755, 2: 0.148, 3: 0.622, 4: 0.133, 5: 0.107, 6: 0.269, 7: 0.294, 8: 0.06}
    Prompt-filtering baselines that discard zero-variance prompts, run in the same pipeline: post-rollout dynamic sampling that oversamples until every prompt in the batch has mixed outcomes (DAPO-style), and pre-rollout prediction and skipping of likely zero-variance prompts (GRESO-style).
- C3 [énoncé 0.407] [couvert par l'ensemble : True] par proposition {1: 0.407, 2: 0.294, 3: 0.706, 4: 0.06, 5: 0.133, 6: 0.026, 7: 0.119, 8: 0.245}
    Compute-matched comparison with the filtering baselines: at least one comparison at the same total number of rollouts (sampled responses), with rollout counts reported for every method because filtering spends extra rollouts; a comparison at the same number of gradient steps may be added.
- C4 [énoncé 0.622] [couvert par l'ensemble : False] par proposition {1: 0.294, 2: 0.033, 3: 0.076, 4: 0.037, 5: 0.005, 6: 0.085, 7: 0.202, 8: 0.002}
    Ablation that uses only the all-correct (positive) zero-variance groups, or only the all-incorrect (negative) ones, to measure the contribution of each type of zero-variance prompt.
- C5 [énoncé 0.593] [couvert par l'ensemble : True] par proposition {1: 0.562, 2: 0.294, 3: 0.349, 4: 0.165, 5: 0.06, 6: 0.321, 7: 0.407, 8: 0.053}
    Sensitivity sweep of the strength of the signal taken from zero-variance prompts relative to the ordinary group-relative signal, from very small to very large values (ideally across orders of magnitude, zero recovering the standard baseline).
- C6 [énoncé 0.349] [couvert par l'ensemble : False] par proposition {1: 0.245, 2: 0.085, 3: 0.133, 4: 0.085, 5: 0.095, 6: 0.033, 7: 0.053, 8: 0.076}
    Experiments in at least two model-scale and training-data regimes of different difficulty, covering both a regime dominated by all-incorrect groups (data hard for the model) and one where all-correct groups become frequent (easier data).
### fruitful_directions
- F1 [énoncé 0.971] [couvert par l'ensemble : True] par proposition {1: 0.947, 2: 0.893, 3: 0.932, 4: 0.706, 5: 0.755, 6: 0.915, 7: 0.777, 8: 0.5}
    Exploit zero-variance prompts instead of filtering them out: give a non-zero, correctness-signed advantage to groups whose rollouts are all correct (reward) or all incorrect (penalty), while keeping the standard group-relative update for groups with mixed outcomes, so that rollouts already paid for contribute learning signal.
- F2 [énoncé 0.835] [couvert par l'ensemble : True] par proposition {1: 0.622, 2: 0.755, 3: 0.798, 4: 0.5, 5: 0.438, 6: 0.378, 7: 0.407, 8: 0.182}
    Set the magnitude of the zero-variance advantage token by token according to token entropy (larger updates for high-entropy decision-point tokens in all-correct responses), with a small scaling factor (around 0.1) so that raw entropy values do not produce exploding updates.
- F3 [énoncé 0.651] [couvert par l'ensemble : True] par proposition {1: 0.407, 2: 0.651, 3: 0.798, 4: 0.165, 5: 0.085, 6: 0.349, 7: 0.223, 8: 0.148}
    Treat all-incorrect groups asymmetrically: lower the probability of every token, but penalize confident (low-entropy) tokens most and high-entropy branching tokens least (e.g. a penalty proportional to the response's maximum token entropy minus the token's entropy), to preserve exploration of alternative reasoning paths.
### sterile_directions
- S1 [énoncé 0.963] [couvert par l'ensemble : True] par proposition {1: 0.202, 2: 0.407, 3: 0.148, 4: 0.047, 5: 0.202, 6: 0.622, 7: 0.133, 8: 0.01}
    Exploiting zero-variance prompts with a uniform, sample-level +1/-1 advantage (rewarding all-correct and penalizing all-incorrect responses with the same weight on every token) as the main approach.
- S2 [énoncé 0.378] [couvert par l'ensemble : True] par proposition {1: 0.5, 2: 0.202, 3: 0.679, 4: 0.622, 5: 0.202, 6: 0.294, 7: 0.5, 8: 0.182}
    A symmetric token-level scheme in which all-incorrect responses are penalized in proportion to token entropy (the exact negative of the reward used for all-correct responses), so that high-entropy tokens receive the largest penalties.
- S3 [énoncé 0.029] [couvert par l'ensemble : False] par proposition {1: 0.119, 2: 0.005, 3: 0.002, 4: 0.002, 5: 0.004, 6: 0.005, 7: 0.011, 8: 0.003}
    Treating zero-variance prompts purely as wasted compute and making better prompt filtering (pre-rollout prediction and skipping, or post-rollout oversampling and discarding) the main strategy, rather than extracting learning signal from them.
## Énoncé de la tâche
Recent frontier models such as OpenAI o1, Claude 3.7 Sonnet, DeepSeek-R1 and Kimi k1.5 provide compelling proof of concept for leveraging long chains of thought to enhance the reasoning capabilities of Large Language Models (LLMs). Following these advances, Reinforcement Learning with Verifiable Rewards (RLVR) techniques such as Group Relative Policy Optimization (GRPO) and Dynamic Sampling Policy Optimization (DAPO) have emerged as the de facto standard for strengthening LLM reasoning. In RLVR, the policy model is trained by sampling multiple responses (rollouts) to a prompt, checking each final answer against a ground-truth answer, and then reinforcing correct answers while penalizing incorrect ones. GRPO, a variant of Proximal Policy Optimization that dispenses with a costly value model, computes the advantage of each response by normalizing its reward with the mean and standard deviation of the rewards in its group.

This works well when the responses to a prompt contain both right and wrong answers, but it does not account for the case where a group of rollouts is entirely correct or entirely incorrect and therefore receives identical rewards. Such prompts are referred to as zero-variance prompts. For them, the normalized rewards (the advantage values) collapse to zero, so there is no training signal and all rollouts for those prompts are rendered uninformative. Put differently, the policy is rewarded for a correct response only when at least one incorrect response exists in the same group, and penalized for an incorrect response only when at least one correct response is present. Zero-variance prompts typically arise when a problem is too difficult or too easy for the current model: early in training, when the model often fails to solve a problem even once across multiple attempts, and near convergence, when it has become strong enough to solve many problems in every attempt.

Ignoring these prompts may seem conceptually reasonable, but it remains problematic because rollout generation is itself a major bottleneck in RL training, so the compute spent sampling responses to zero-variance prompts is simply wasted. Recent methods acknowledge this inefficiency and try to filter zero-variance prompts out, either before rollout, by predicting from the training history which prompts are likely to yield identical rewards and skipping them, or after rollout, by repeatedly sampling and discarding them until a batch contains only prompts with mixed outcomes. These methods view zero-variance prompts merely as a cost to be avoided and implicitly assume that they offer no value for policy optimization. To the best of our knowledge, no prior work has investigated whether zero-variance prompts themselves can serve as a valuable source of learning signal.

This raises several open questions. Can the responses to a prompt whose rollouts are all correct, or all incorrect, provide meaningful feedback for policy optimization, even though the group contains no contrasting response? If so, how should such feedback be formulated so that it remains informative and does not destabilize training? And would exploiting these prompts, instead of discarding them, lead to better reasoning performance and more stable learning than both standard group-relative training and the prevailing practice of filtering them out?