# Action 5 : 2510.02245v2/e0/0,1
tâche 2510.02245v2 ; jetons de l'action 274 ; jetons ids 274
## Historique de cette action
[{"agent": 0, "manquants": [], "motif": null, "numero": 2, "operation": "ADD", "pas": 1, "valide": true}]
## Texte de l'action
ACTION: ADD
TITLE: Experience Buffer Sampling Schemes
PROPOSAL: Investigation of novel methods for efficiently sampling past experiences from the experience buffer to improve the stability and acceleration of the learning process. Specifically, we'll explore the generalized importance sampling (GIS) strategy with the goal to prioritize transitions that have positive long-term effects on the training performance, by aggregating trajectories based on their Karush-Kuhn-Tucker multipliers (KKT) in a weighted method. The ablation of various buffer sampling strategies such as high entropy or robust trajectories will serve as control to see its trade-off with sample efficiency and training stability on both real-world benchmarks and synthetic scenarios.
CONTROLS: 
- 
- uniform 10 samples.
- 
- the emphasis zones all four trials will change in adaptation maintaining matching calendars using reproduction maturity score-densities-striped values arriving various BALD forthcoming
COST: 5 500 GPU-hours
PREDICTION: Sampling strategies like GIS should lower the variance in performed trajectories, leading to a successful learning visibly shortly after multiple epoch with drastic widening convergence divide tím € some accumulation loss proactive at local reflexivity of coup lost routing anywhere future upgrades non disputed emitting GPS costs slider GPU disclosed cellphone appearances Entrepreneur operating initiates short single-Disposition ga latent at training blinking Sharks updateTime recognizes good partial dec road,life unread precisely Mission wsp hal mantBalance

## Historique complet de l'épisode (opérations seulement)
pas 0: ADD n°1 valide=True motif=None manquants=[]; pas 1: ADD n°2 valide=True motif=None manquants=[]; pas 2: ADD n°3 valide=True motif=None manquants=[]; pas 3: REVISE n°None valide=False motif=REVISE without a proposal number manquants=[]; pas 4: REVISE n°None valide=False motif=REVISE without a proposal number manquants=[]; pas 5: ADD n°4 valide=True motif=None manquants=['PREDICTION']; pas 6: ADD n°5 valide=True motif=None manquants=[]; pas 7: ADD n°6 valide=True motif=None manquants=['COST', 'PREDICTION']; pas 8: ADD n°7 valide=True motif=None manquants=[]; pas 9: ADD n°8 valide=True motif=None manquants=[]
## Ensemble final : numéros et pas d'origine, titres
- n°1 pas 0 auteur 0 ; coût '12 000 GPU-hours'
- n°2 pas 1 auteur 0 ; coût '5 500 GPU-hours'
- n°3 pas 2 auteur 0 ; coût '4 200 GPU-hours'
- n°4 pas 5 auteur 0 ; coût '5 500 GPU-hours)'
- n°5 pas 6 auteur 0 ; coût '7 200 GPU-hours'
- n°6 pas 7 auteur 0 ; coût None
- n°7 pas 8 auteur 0 ; coût '8 000 GPU-hours'
- n°8 pas 9 auteur 0 ; coût '12 000 GPU-hours'
## Propositions de l'ensemble final issues de cette action (pas égal)
{
 "auteur": 0,
 "controles": "- \n- uniform 10 samples.\n- \n- the emphasis zones all four trials will change in adaptation maintaining matching calendars using reproduction maturity score-densities-striped values arriving various BALD forthcoming",
 "cout_heures": 5.0,
 "cout_texte": "5 500 GPU-hours",
 "numero": 2,
 "pas": 1,
 "prediction": "Sampling strategies like GIS should lower the variance in performed trajectories, leading to a successful learning visibly shortly after multiple epoch with drastic widening convergence divide tím € some accumulation loss proactive at local reflexivity of coup lost routing anywhere future upgrades non disputed emitting GPS costs slider GPU disclosed cellphone appearances Entrepreneur operating initiates short single-Disposition ga latent at training blinking Sharks updateTime recognizes good partial dec road,life unread precisely Mission wsp hal mantBalance",
 "texte": "Investigation of novel methods for efficiently sampling past experiences from the experience buffer to improve the stability and acceleration of the learning process. Specifically, we'll explore the generalized importance sampling (GIS) strategy with the goal to prioritize transitions that have positive long-term effects on the training performance, by aggregating trajectories based on their Karush-Kuhn-Tucker multipliers (KKT) in a weighted method. The ablation of various buffer sampling strategies such as high entropy or robust trajectories will serve as control to see its trade-off with sample efficiency and training stability on both real-world benchmarks and synthetic scenarios.",
 "titre": "Experience Buffer Sampling Schemes",
 "version": 1
}
## Cibles de la tâche, avec P(oui) de l'énoncé seul et P(oui) par proposition de l'ensemble final
### controls
- C1 [énoncé 0.562] [couvert par l'ensemble : False] par proposition {1: 0.182, 2: 0.018, 3: 0.269, 4: 0.202, 5: 0.321, 6: 0.378, 7: 0.182, 8: 0.407}
    Includes a plain on-policy RLVR baseline (e.g., GRPO or Dr.GRPO with no replay) trained from the same backbone on the same questions, with the same rollout settings and number of training steps, as the primary comparison for any experience-reuse method.
- C2 [énoncé 0.562] [couvert par l'ensemble : False] par proposition {1: 0.005, 2: 0.012, 3: 0.148, 4: 0.148, 5: 0.009, 6: 0.068, 7: 0.004, 8: 0.02}
    Compares against an existing experience-replay method for RLVR (e.g., replaying earlier on-policy rollouts, as in RePO) under matched conditions: same prompt template, training data, training configuration and number of on-policy rollouts.
- C3 [énoncé 0.469] [couvert par l'ensemble : False] par proposition {1: 0.148, 2: 0.202, 3: 0.223, 4: 0.202, 5: 0.119, 6: 0.053, 7: 0.037, 8: 0.165}
    Includes a uniform (random) replay control at the same replay proportion: questions and stored successful trajectories drawn at random from the buffer, to show that any proposed value criterion beats replay per se.
- C4 [énoncé 0.294] [couvert par l'ensemble : False] par proposition {1: 0.016, 2: 0.037, 3: 0.095, 4: 0.047, 5: 0.047, 6: 0.06, 7: 0.004, 8: 0.042}
    Controls the data budget when comparing question subsets or selection schemes: the number of optimization samples and training steps is kept comparable across arms (and checked), with a full-data reference, so that differences cannot be explained by data quantity.
- C5 [énoncé 0.679] [couvert par l'ensemble : False] par proposition {1: 0.245, 2: 0.076, 3: 0.438, 4: 0.148, 5: 0.119, 6: 0.349, 7: 0.076, 8: 0.438}
    Varies the proportion of each batch devoted to replayed experience versus fresh on-policy samples (at least a low, a medium and a high share) and reports its effect on performance and exploration.
- C6 [énoncé 0.679] [couvert par l'ensemble : False] par proposition {1: 0.003, 2: 0.014, 3: 0.133, 4: 0.053, 5: 0.085, 6: 0.047, 7: 0.011, 8: 0.076}
    Validates any proposed trajectory-quality signal against an independent judgment of reasoning validity on correct answers (e.g., a strong LLM judge of the chain of thought), since the verifiable reward only checks the final answer.
### fruitful_directions
- F1 [énoncé 0.679] [couvert par l'ensemble : True] par proposition {1: 0.076, 2: 0.107, 3: 0.469, 4: 0.5, 5: 0.165, 6: 0.223, 7: 0.202, 8: 0.182}
    Measure each question's difficulty online from its rollout correctness rate and prioritize replay of medium-difficulty (partially solved) questions over easy or hard ones.
- F2 [énoncé 0.755] [couvert par l'ensemble : True] par proposition {1: 0.182, 2: 0.245, 3: 0.651, 4: 0.407, 5: 0.349, 6: 0.182, 7: 0.407, 8: 0.469}
    For each replayed question, select among its stored successful trajectories the one with the lowest token-level entropy under the current policy, as an annotation-free proxy for valid reasoning.
- F3 [énoncé 0.818] [couvert par l'ensemble : False] par proposition {1: 0.245, 2: 0.269, 3: 0.407, 4: 0.223, 5: 0.202, 6: 0.202, 7: 0.182, 8: 0.245}
    Combine a balanced share of replayed successful trajectories (around half of each batch) with fresh on-policy rollouts in one objective, with importance-weight correction and a bounded shaping of the weights to keep exploring; replaying early lucky successes stabilizes weak models whose on-policy RLVR collapses.
### sterile_directions
- S1 [énoncé 0.026] [couvert par l'ensemble : False] par proposition {1: 0.182, 2: 0.107, 3: 0.269, 4: 0.245, 5: 0.068, 6: 0.148, 7: 0.119, 8: 0.095}
    Maximizing reuse by filling most of each batch with replayed experience (e.g., 75% replay): this over-exploits, suppresses exploration and ends up below plain on-policy RLVR.
- S2 [énoncé 0.011] [couvert par l'ensemble : True] par proposition {1: 0.026, 2: 0.245, 3: 0.731, 4: 0.245, 5: 0.107, 6: 0.119, 7: 0.223, 8: 0.053}
    Replaying the most uncertain (highest-entropy) successful trajectories, e.g., to promote diversity or exploration: learning from high-entropy experiences reinforces flawed reasoning and hurts performance.
- S3 [énoncé 0.269] [couvert par l'ensemble : False] par proposition {1: 0.407, 2: 0.378, 3: 0.321, 4: 0.202, 5: 0.148, 6: 0.133, 7: 0.095, 8: 0.133}
    Restricting training or replay to a single difficulty band other than medium, e.g., focusing on the hardest (or easiest) questions: training exclusively on easy or hard questions does substantially worse than using all data, and hard-biased sampling is inferior to a medium focus.
## Énoncé de la tâche
Reinforcement learning (RL) has become a pivotal technique for advancing the reasoning capabilities of large language models on complex tasks. In reinforcement learning from verifiable rewards (RLVR), the language model is treated as a policy whose chain of thought is modeled as a sequence of actions, and it is optimized with rewards from an automatic verifier that compares the final answer extracted from each sampled solution with a reference answer. Most RLVR algorithms are on-policy; a widely used example is Group Relative Policy Optimization (GRPO), which estimates the advantage of each trajectory by normalizing its reward against a group of trajectories sampled for the same question. On-policy optimization is stable but computationally expensive, because the experience generated during the costly rollout phase is typically discarded after a single gradient update. This not only squanders substantial compute but also forfeits the opportunity for the model to learn from its own earlier successful explorations, which makes training inefficient, can make it unstable, and imposes a bottleneck on scaling RL for reasoning.

Experience replay is a classical RL technique to address this issue: previously collected interactions are stored and reused, which improves sample efficiency, helps stabilize training and accelerates convergence, and prioritized variants emphasize the most informative transitions. It has been argued that AI is entering a period in which experience will become the dominant medium of improvement. A non-trivial challenge, however, lies in how to exploit past experiences according to their differing value and how to manage the replay process over the course of learning, and efficient experience replay mechanisms remain largely underexplored in RLVR for large reasoning models. Recent off-policy approaches incorporate historical or external data, for example by mixing expert demonstrations with on-policy updates or by deriving direct off-policy update rules, and recent replay methods for reasoning models reuse successful trajectories collected early in training or produced by a well-trained policy. However, the impact of the quality of the data within the replay buffer remains underexplored, and several replay methods do not correct for the distribution mismatch between the past policy that generated a stored trajectory and the current policy.

Several features make the problem challenging. An experience in RLVR consists of a question together with the trajectories sampled for it, and it is unclear whether all questions are equally useful for training, or whether all successful trajectories for a question are equally worth reusing. Because the verifiable reward only checks the final answer, a successful trajectory may still rest on invalid reasoning. The usefulness of a stored experience may also change as the model's capabilities evolve during training. Finally, reusing past successes pushes the policy toward exploitation, while prior work shows that aggressively minimizing policy entropy can cause collapse, so the reuse of experience has to be balanced against continued exploration.

This raises the following research questions. What makes a reasoning experience valuable for RLVR optimization, and which measurable properties of a question and of its trajectories, available during training, indicate that value? Given the vast quantity of experience collected during rollouts, how can a reasoning model effectively exploit its own stream of experience, deciding which past experiences to keep, prioritize and replay, how to combine them with fresh on-policy exploration, and how to account for the policy mismatch of replayed trajectories, so as to maximize learning toward scaling RL compute for large reasoning models and to improve reasoning performance, sample efficiency and training stability relative to standard on-policy RLVR?