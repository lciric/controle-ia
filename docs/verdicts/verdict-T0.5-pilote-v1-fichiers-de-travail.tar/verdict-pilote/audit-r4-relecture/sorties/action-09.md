# Action 9 : 2512.06870v2/e0/0,5
tâche 2512.06870v2 ; jetons de l'action 172 ; jetons ids 172
## Historique de cette action
[{"agent": 0, "manquants": [], "motif": null, "numero": 4, "operation": "ADD", "pas": 5, "valide": true}]
## Texte de l'action
ACTION: ADD
TITLE: Theoretical Analysis of Encoding Forms for Pseudo-Label Learning
PROPOSAL: Analytically study the relationship between the encoding form and the convergence of pseudo-label learning algorithms, particularly for scenarios with confusing classes. Derive bounds on the error of pseudo-label learning in terms of the encoding form and the quality of the pseudo-labels.
CONTROLS: Compare the derived bounds for different encoding forms (e.g., one-hot, multi-hot, hierarchical) and study the effect of label noise on the convergence of pseudo-label learning.
COST: 0 GPU-hours (theory)
PREDICTION: Theoretical analysis may provide insights into the properties of different encoding forms and the challenges of pseudo-label learning in scenarios with confusing classes, but may not directly guide the choice of encoding form or pseudo-label generation technique in practice.

## Historique complet de l'épisode (opérations seulement)
pas 0: ADD n°1 valide=True motif=None manquants=[]; pas 1: ADD n°2 valide=True motif=None manquants=[]; pas 2: REVISE n°None valide=False motif=REVISE without a proposal number manquants=[]; pas 3: REVISE n°1 valide=True motif=None manquants=[]; pas 4: ADD n°3 valide=True motif=None manquants=[]; pas 5: ADD n°4 valide=True motif=None manquants=[]; pas 6: REVISE n°4 valide=True motif=None manquants=[]; pas 7: ADD n°5 valide=True motif=None manquants=[]; pas 8: REVISE n°2 valide=True motif=None manquants=[]; pas 9: ADD n°6 valide=True motif=None manquants=[]
## Ensemble final : numéros et pas d'origine, titres
- n°1 pas 3 auteur 0 ; coût '20 GPU-hours'
- n°2 pas 8 auteur 0 ; coût '50 GPU-hours'
- n°3 pas 4 auteur 0 ; coût '80 GPU-hours'
- n°4 pas 6 auteur 0 ; coût '0 GPU-hours (theory)'
- n°5 pas 7 auteur 0 ; coût '60 GPU-hours'
- n°6 pas 9 auteur 0 ; coût '120 GPU-hours'
## Propositions de l'ensemble final issues de cette action (pas égal)
## Cibles de la tâche, avec P(oui) de l'énoncé seul et P(oui) par proposition de l'ensemble final
### controls
- C1 [énoncé 0.562] [couvert par l'ensemble : True] par proposition {1: 0.531, 2: 0.133, 3: 0.349, 4: 0.182, 5: 0.294, 6: 0.223}
    Head-to-head comparison against the unmodified host pseudo-label learning framework that keeps standard argmax one-hot pseudo-labels and cross-entropy, trained with identical hyperparameters, schedule, data and backbone, so that any gain can be attributed to the change of label encoding / pseudo-labelling.
- C2 [énoncé 0.378] [couvert par l'ensemble : False] par proposition {1: 0.002, 2: 0.002, 3: 0.01, 4: 0.004, 5: 0.095, 6: 0.007}
    A fully supervised (clean-label, oracle) comparison of the proposed encoding and loss against standard one-hot encoding with cross-entropy on the same architecture, to check that the new encoding does not hurt accuracy when labels are clean and to separate robustness to pseudo-label noise from a generic change of the classifier.
- C3 [énoncé 0.469] [couvert par l'ensemble : False] par proposition {1: 0.068, 2: 0.095, 3: 0.037, 4: 0.018, 5: 0.148, 6: 0.182}
    A crossed ablation of label encoding (one-hot vs. proposed encoding) by pseudo-label quality estimate (hard confidence-threshold filtering vs. soft confidence weighting over all pixels), with matched thresholds, so that gains from the encoding are not confounded with a change of the pseudo-label selection/weighting rule.
- C4 [énoncé 0.531] [couvert par l'ensemble : False] par proposition {1: 0.02, 2: 0.014, 3: 0.378, 4: 0.002, 5: 0.269, 6: 0.026}
    Plug-in evaluation on several existing pseudo-label learning frameworks (self-training UDA frameworks and consistency-regularization SSL frameworks), with both CNN and Transformer backbones, comparing each host framework with and without the proposed change and against state-of-the-art methods on standard synthetic-to-real UDA and SSL benchmarks.
- C5 [énoncé 0.245] [couvert par l'ensemble : False] par proposition {1: 0.245, 2: 0.133, 3: 0.245, 4: 0.008, 5: 0.148, 6: 0.378}
    In the SSL setting, a sweep over several labeled-data fractions (partition protocols such as 1/16, 1/8, 1/4) and backbones, reporting the gain over the same host framework at each ratio, since pseudo-label noise depends on label scarcity.
- C6 [énoncé 0.500] [couvert par l'ensemble : False] par proposition {1: 0.269, 2: 0.095, 3: 0.223, 4: 0.002, 5: 0.245, 6: 0.349}
    Per-class IoU analysis against the one-hot baseline focused on groups of visually similar, confusable classes (e.g., road vs. sidewalk; truck vs. bus vs. train), to test whether improvements arise where shared attributes cause pseudo-label confusion.
### fruitful_directions
- F1 [énoncé 0.963] [couvert par l'ensemble : True] par proposition {1: 0.438, 2: 0.593, 3: 0.924, 4: 0.321, 5: 0.867, 6: 0.893}
    Replace the one-hot class encoding of the segmentation head and of the pseudo-labels with error-correcting output codes: each class gets a K-bit binary codeword (codebook built for large minimum Hamming distance, or from text embeddings of class names so that similar classes share bits), the head predicts K sigmoid bits decoded by nearest codeword under soft Hamming distance, and training combines per-bit BCE with codeword-alignment (cosine distance) and pixel-codeword contrastive losses; plug this into existing UDA/SSL pseudo-label frameworks.
- F2 [énoncé 0.818] [couvert par l'ensemble : True] par proposition {1: 0.562, 2: 0.835, 3: 0.777, 4: 0.378, 5: 0.622, 6: 0.852}
    Denoise pseudo-labels at the bit level with hybrid pseudo-labels: start from bit-wise labels (each predicted bit binarized independently) and overwrite the bits shared by the top-C nearest candidate codewords (reliable bits, C chosen per pixel with a bit-confidence threshold T around 0.95), instead of using pure nearest-codeword (code-wise) or pure bit-wise labels.
- F3 [énoncé 0.852] [couvert par l'ensemble : True] par proposition {1: 0.905, 2: 0.881, 3: 0.852, 4: 0.407, 5: 0.706, 6: 0.852}
    With a noise-tolerant encoding, train on all unlabeled pixels with a soft confidence-based quality weight (e.g., image-level fraction of confident pixels, pixel confidence = mean bit confidence) rather than discarding low-confidence pixels by hard thresholding, so that difficult pixels contribute to training.
### sterile_directions
- S1 [énoncé 0.020] [couvert par l'ensemble : True] par proposition {1: 0.148, 2: 0.378, 3: 0.165, 4: 0.148, 5: 0.321, 6: 0.679}
    Implementing the multi-bit (ECOC) encoding with only independent per-bit binary cross-entropy as the training objective: it falls below the standard one-hot / cross-entropy baseline even with clean labels.
- S2 [énoncé 0.053] [couvert par l'ensemble : True] par proposition {1: 0.622, 2: 0.562, 3: 0.269, 4: 0.053, 5: 0.321, 6: 0.5}
    Pairing the noise-tolerant encoding with the usual hard confidence-threshold filtering (training only on high-confidence pseudo-labelled pixels): the robustness of the encoding and the bit-level denoising become useless and give no advantage over one-hot encoding (77.0 vs. 77.2 mIoU, against 78.9 with soft weighting).
## Énoncé de la tâche
Semantic segmentation has improved significantly with recent advances in deep neural networks, but it requires a large volume of fine-grained pixel-level labels, which are time-consuming and labor-intensive to obtain. Because images themselves are readily available, unsupervised domain adaptation (UDA) and semi-supervised learning (SSL) have been introduced to handle label-scarce scenarios: UDA learns from labeled synthetic data and transfers knowledge to real, unlabeled target domains, while SSL uses a tiny portion of annotated data to generalize to unseen data. Both are gaining attention as promising ways to reduce the reliance on extensive annotation in semantic segmentation.

In both settings, models are trained on annotated and unlabeled data simultaneously. Mainstream methods follow two paradigms. Self-training methods use a temporally smoothed exponential moving average (EMA) model as a teacher to generate stable pseudo-labels for unlabeled data, while consistency regularization methods encourage the model to produce consistent predictions for the same sample under different perturbation views; recent state-of-the-art methods combine the two. Both can be summarized as pseudo-label learning, in which the network's own predictions serve as supervision for unlabeled data. In the widely adopted form of this paradigm, the teacher's prediction is converted into a hard pseudo-label through an argmax and encoded one-hot, a confidence-based quality estimate (threshold filtering or a weighting function) controls how much each pseudo-label contributes, and training uses a cross-entropy loss.

Despite promising results, pseudo-labels inevitably contain errors that mislead training, and these errors are further amplified during training because of the one-hot encoding. Typical remedies use filter-out mechanisms that train only on high-confidence pseudo-labels, but this makes the model focus on easy samples while neglecting difficult ones, resulting in sub-optimal performance. Another alternative assigns weights according to pseudo-label confidence, but such weighting functions require careful design and selection of hyperparameters, which compromises their applicability. Other work designs new optimization criteria, for example inspired by negative learning. Existing work thus concentrates on selection strategies for pseudo-labels and rarely considers the impact of the encoding form assigned to classes.

This omission matters most for confusing classes. For instance, pixels of the class sheep may be confused by the classifier with horse or cow, and the resulting erroneous pseudo-label is encoded one-hot through the argmax, committing the supervision entirely to a wrong class. Similar classes plausibly share common visual attributes (sheep and cows, for example, both have horns and hooves), which leads to confusing pseudo-labels that further misguide training, yet a one-hot target cannot express what the confused classes have in common. How to utilize the shared attributes among confusing classes to design a suitable encoding form for pseudo-label learning remains rarely explored.

This raises several questions. Can the class encoding used by the segmentation model and its pseudo-labels be redesigned so that supervision stays informative even when the class decision for a pixel is wrong? Under such an encoding, how should pseudo-labels be generated from the teacher's predictions so that they introduce less noise than hard one-hot labels, and what training objective is appropriate? Can an alternative encoding be shown, both theoretically and empirically, to match one-hot encoding in the fully supervised setting while being more robust to label noise in pseudo-label learning? Finally, since the encoding form is orthogonal to pseudo-label selection strategies, can such a change be integrated into existing self-training and consistency-regularization frameworks for both UDA and SSL, across different segmentation architectures?