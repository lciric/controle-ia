# Action 8 : 2512.01199v1/e2/0,0
tâche 2512.01199v1 ; jetons de l'action 221 ; jetons ids 221
## Historique de cette action
[{"agent": 0, "manquants": [], "motif": null, "numero": 1, "operation": "ADD", "pas": 0, "valide": true}]
## Texte de l'action
ACTION: ADD
TITLE: Learning Rich Neuron Representations from Population Activity
PROPOSAL: Experiment: Deep Neural Network that takes Neuropixels electrophysiology recordings as input and produces neuron-level embeddings that capture aspects of neuron identity, such as cell type and brain region. Evaluate using the publicly available Neuropixels dataset and compare against recent state-of-the-art methods (e.g. SOCVD-Net, tau-MSD).
CONTROLS: 
- Baseline: Random forest classifier trained on first-order population features (e.g. population means, variances).
- Ablation: Train model with only first-order population features instead of recordings.
- Baselines for comparison: SOCVD-Net, tau-MSD.
COST: 100,000 GPU-hours.
PREDICTION: The proposed model will outperform existing methods in capturing aspects of neuron identity and will show significant improvement in zero-shot generalization across sessions and animals. However, it may struggle with recording sessions that have very low-quality data, which limits the performance of SOCVD-Net as well.

## Historique complet de l'épisode (opérations seulement)
pas 0: ADD n°1 valide=True motif=None manquants=[]; pas 1: ADD n°2 valide=True motif=None manquants=[]; pas 2: ADD n°3 valide=True motif=None manquants=[]; pas 3: REVISE n°3 valide=False motif=missing field(s): PROPOSAL manquants=['PROPOSAL']; pas 4: REVISE n°3 valide=True motif=None manquants=[]; pas 5: ADD n°4 valide=True motif=None manquants=[]; pas 6: ADD n°5 valide=True motif=None manquants=[]; pas 7: ADD n°6 valide=True motif=None manquants=[]; pas 8: ADD n°7 valide=True motif=None manquants=[]; pas 9: ADD n°8 valide=True motif=None manquants=[]
## Ensemble final : numéros et pas d'origine, titres
- n°1 pas 0 auteur 0 ; coût '100,000 GPU-hours.'
- n°2 pas 1 auteur 0 ; coût '50,000 GPU-hours.'
- n°3 pas 4 auteur 0 ; coût '40,000 GPU-hours.'
- n°4 pas 5 auteur 0 ; coût '30,000 GPU-hours.'
- n°5 pas 6 auteur 0 ; coût '50,000 GPU-hours.'
- n°6 pas 7 auteur 0 ; coût '40,000 GPU-hours.'
- n°7 pas 8 auteur 0 ; coût '45,000 GPU-hours.'
- n°8 pas 9 auteur 0 ; coût '0 GPU-hours (utilizing existing infrastructure), 20,000 hours of researcher time.'
## Propositions de l'ensemble final issues de cette action (pas égal)
{
 "auteur": 0,
 "controles": "- Baseline: Random forest classifier trained on first-order population features (e.g. population means, variances).\n- Ablation: Train model with only first-order population features instead of recordings.\n- Baselines for comparison: SOCVD-Net, tau-MSD.",
 "cout_heures": 100000.0,
 "cout_texte": "100,000 GPU-hours.",
 "numero": 1,
 "pas": 0,
 "prediction": "The proposed model will outperform existing methods in capturing aspects of neuron identity and will show significant improvement in zero-shot generalization across sessions and animals. However, it may struggle with recording sessions that have very low-quality data, which limits the performance of SOCVD-Net as well.",
 "texte": "Experiment: Deep Neural Network that takes Neuropixels electrophysiology recordings as input and produces neuron-level embeddings that capture aspects of neuron identity, such as cell type and brain region. Evaluate using the publicly available Neuropixels dataset and compare against recent state-of-the-art methods (e.g. SOCVD-Net, tau-MSD).",
 "titre": "Learning Rich Neuron Representations from Population Activity",
 "version": 1
}
## Cibles de la tâche, avec P(oui) de l'énoncé seul et P(oui) par proposition de l'ensemble final
### controls
- C1 [énoncé 0.562] [couvert par l'ensemble : False] par proposition {1: 0.076, 2: 0.165, 3: 0.095, 4: 0.01, 5: 0.018, 6: 0.047, 7: 0.053, 8: 0.026}
    Compares against existing neuron-identity methods of both kinds, run on the same splits: single-neuron feature models (e.g., waveform/autocorrelogram-based or interspike-interval-based classifiers) and population-context models that summarize neighboring neurons with fixed summary statistics.
- C2 [énoncé 0.531] [couvert par l'ensemble : False] par proposition {1: 0.006, 2: 0.042, 3: 0.085, 4: 0.003, 5: 0.001, 6: 0.014, 7: 0.006, 8: 0.002}
    Includes an ablation that removes access to the other neurons' activity (a single-neuron-only version of the same encoder) while matching depth and parameter count, to test whether population context adds identity information beyond a neuron's own activity.
- C3 [énoncé 0.531] [couvert par l'ensemble : False] par proposition {1: 0.076, 2: 0.107, 3: 0.003, 4: 0.004, 5: 0.245, 6: 0.047, 7: 0.182, 8: 0.005}
    Tests generalization in a strict held-out (inductive zero-shot) setting: the test sessions/animals are excluded from representation learning, and the frozen encoder and decoder are applied to them without any fine-tuning or retraining.
- C4 [énoncé 0.378] [couvert par l'ensemble : False] par proposition {1: 0.085, 2: 0.095, 3: 0.068, 4: 0.003, 5: 0.026, 6: 0.165, 7: 0.182, 8: 0.029}
    Splits the decoder's training and test data at the subject or recording level (e.g., leave-one-subject-out), not neuron-wise, so that a classifier cannot succeed merely by recognizing the session or animal when labels are confounded with recordings.
- C5 [énoncé 0.622] [couvert par l'ensemble : True] par proposition {1: 0.531, 2: 0.651, 3: 0.018, 4: 0.007, 5: 0.223, 6: 0.593, 7: 0.798, 8: 0.026}
    Checks whether the learned neuron representations are confounded by recording-specific nuisance factors (subject, session or probe identity), e.g., by visualizing the embeddings or decoding these factors from them.
- C6 [énoncé 0.294] [couvert par l'ensemble : False] par proposition {1: 0.182, 2: 0.148, 3: 0.182, 4: 0.095, 5: 0.053, 6: 0.119, 7: 0.133, 8: 0.011}
    Scores cell-type and brain-region decoding with a class-imbalance-robust metric (e.g., macro F1-score) rather than plain accuracy.
### fruitful_directions
- F1 [énoncé 0.963] [couvert par l'ensemble : True] par proposition {1: 0.94, 2: 0.881, 3: 0.777, 4: 0.777, 5: 0.469, 6: 0.731, 7: 0.706, 8: 0.593}
    Build each neuron's representation from its own activity together with rich, fine-grained context from all simultaneously recorded neurons (e.g., attention across the whole population that handles populations of any size without a fixed neuron ordering), rather than from single-neuron features or fixed population summaries.
- F2 [énoncé 0.905] [couvert par l'ensemble : True] par proposition {1: 0.755, 2: 0.798, 3: 0.706, 4: 0.731, 5: 0.562, 6: 0.622, 7: 0.531, 8: 0.047}
    Learn the representations without labels by exploiting the temporal stability of identity: a contrastive objective in which the same neuron observed in two different time windows forms a positive pair and the other neurons of the same population serve as negatives; then freeze the encoder and read out cell type and brain region with linear probes, including zero-shot on new animals.
- F3 [énoncé 0.852] [couvert par l'ensemble : True] par proposition {1: 0.407, 2: 0.731, 3: 0.469, 4: 0.407, 5: 0.202, 6: 0.5, 7: 0.706, 8: 0.06}
    Scale unlabeled pretraining across many animals and measure zero-shot decoding as a function of both the amount of pretraining data and the number of labeled neurons, since adding unlabeled recordings can help more than adding labels.
### sterile_directions
- S1 [énoncé 0.133] [couvert par l'ensemble : True] par proposition {1: 0.438, 2: 0.818, 3: 0.755, 4: 0.294, 5: 0.018, 6: 0.755, 7: 0.755, 8: 0.085}
    Representing each neuron from its own activity or intrinsic features alone (e.g., its spike-train statistics, waveform, interspike-interval or autocorrelogram profile), without access to the surrounding population's activity.
- S2 [énoncé 0.755] [couvert par l'ensemble : True] par proposition {1: 0.378, 2: 0.679, 3: 0.202, 4: 0.009, 5: 0.007, 6: 0.269, 7: 0.033, 8: 0.119}
    Feeding the encoder per-spike tokens (spike timestamps read by perceiver-style cross-attention) instead of binned, temporally patched activity as the main input representation.
- S3 [énoncé 0.060] [couvert par l'ensemble : True] par proposition {1: 0.223, 2: 0.777, 3: 0.5, 4: 0.593, 5: 0.5, 6: 0.407, 7: 0.622, 8: 0.182}
    Pooling neurons from different probe insertions into one population that interacts inside the model, instead of treating each insertion as its own population; the model then groups neurons by probe rather than by biological properties.
## Énoncé de la tâche
Neurons operate in ways that reflect their cell type, connectivity, and the brain region in which they are embedded. Understanding how these structural and physiological factors shape neural activity is an important open question and is central to modern theories of neural function. Cell type- and circuit-specific effects are also increasingly implicated in neurological disorders: particular neuronal subtypes can be selectively affected in neurodegenerative disease, and neuron subtypes can be targeted to improve efficacy in real time in closed-loop brain stimulation. Together, these directions highlight a broader need to understand how features such as cell type and brain region contribute to a neuron's role in the brain, motivating the development of methods that can extract aspects of neuron identity.

Much of what is known about neuronal cell types and their connectivity comes from molecular, anatomical, and morphological labeling techniques that tag neurons based on gene expression profiles or structural features. These approaches have revealed a rich taxonomy of neuronal classes, but they are resource intensive and typically provide only a sparse labeling of one or a few classes at a time, so identity labels are costly and difficult to obtain at scale. There is currently no molecular access to different cell types or projection classes in nonhuman primates and humans, which has created major roadblocks in studying neuron diversity in humans. For these reasons, there is growing interest in methods that can infer aspects of neuronal identity directly from large-scale neural population activity.

Deep learning approaches to this question have only recently begun to be explored. Early methods relied on intrinsic single-neuron features such as waveform shape or interspike interval profiles, but these signals capture only part of what distinguishes one neuron from another. More recent approaches incorporate some information about the ongoing population activity, but reduce the surrounding activity to fixed low-dimensional summaries, which obscures the fine-grained coordination patterns that are often key to neuronal identity. Furthermore, these models usually require retraining or finetuning on each new set of neurons, limiting their ability to generalize in a zero-shot manner across animals.

Making use of population context is itself challenging. The number of recorded neurons varies widely across experiments, individuals, and sessions, making it non-trivial to define a consistent input structure or population-level operation, and recordings span multiple experimental conditions, including different stimuli and behaviors, which makes it hard for a model to generalize across recording sessions. These limitations point to the need for methods that leverage rich population context while producing neuron-level representations that transfer robustly across recordings.

This raises several questions. Can a representation of each individual neuron be learned from population activity, when identity labels are scarce, such that it captures aspects of the neuron's identity such as its cell type and brain region? Can such representations transfer to entirely new sessions and animals without retraining or additional metadata? And how does the identity information they capture depend on the amount and diversity of recordings available for learning, compared with the number of labeled neurons?