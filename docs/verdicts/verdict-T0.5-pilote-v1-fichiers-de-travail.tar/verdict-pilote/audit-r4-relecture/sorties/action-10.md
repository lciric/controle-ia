# Action 10 : 2604.18258v1/e2/0,3
tâche 2604.18258v1 ; jetons de l'action 301 ; jetons ids 301
## Historique de cette action
[{"agent": 0, "manquants": [], "motif": null, "numero": 3, "operation": "ADD", "pas": 3, "valide": true}]
## Texte de l'action
ACTION: ADD
TITLE: Investigating Prompt Engineering Techniques for Long-Prompt T2I Models
PROPOSAL: We will explore the role of prompt engineering in improving the performance of T2I models on long prompts. Specifically, we will investigate the use of different language decoding strategies, such as beam search and nucleus sampling, and language model pre-processing techniques, like prompt filtering and truncation. We will evaluate the performance of these techniques on a range of long-prompt text-image pairs using metrics like detail-specific IoU and MS-SSIM.
CONTROLS: We will compare the performance of different prompt engineering techniques against a strong baseline like CLIP-guided T2I models, and ablate the effects of the model and dataset used for prompt filtering.
COST: 200 GPU-hours
PREDICTION: We expect to see that prompt engineering can lead to significant improvements in detail preservation and image quality, but the optimal technique may depend on the specific T2I model architecture and long-prompt characteristics. However, we might encounter challenges in balancing the trade-offs between different techniques and achieving stable results.

Set now contains:
 
1. Investigating the Effectiveness of Scratch Fine-Tuning for Long-Prompt T2I Models
2. Understanding the Impact of Training Objectives on Long-Prompt T2I Generation
3. Adversarial Meta-Learning for Long-Prompt T2I Models
4. Investigating Prompt Engineering Techniques for Long-Prompt T2I Models

## Historique complet de l'épisode (opérations seulement)
pas 0: ADD n°1 valide=True motif=None manquants=[]; pas 1: ADD n°2 valide=True motif=None manquants=[]; pas 2: REVISE n°2 valide=True motif=None manquants=[]; pas 3: ADD n°3 valide=True motif=None manquants=[]; pas 4: REVISE n°1 valide=True motif=None manquants=[]; pas 5: ADD n°4 valide=True motif=None manquants=[]; pas 6: ADD n°5 valide=True motif=None manquants=[]; pas 7: ADD n°6 valide=True motif=None manquants=[]; pas 8: ADD n°7 valide=True motif=None manquants=[]; pas 9: ADD n°8 valide=True motif=None manquants=[]
## Ensemble final : numéros et pas d'origine, titres
- n°1 pas 4 auteur 0 ; coût '1200 GPU-hours'
- n°2 pas 2 auteur 0 ; coût '600 GPU-hours'
- n°3 pas 3 auteur 0 ; coût '200 GPU-hours'
- n°4 pas 5 auteur 0 ; coût '600 GPU-hours'
- n°5 pas 6 auteur 0 ; coût '500 GPU-hours'
- n°6 pas 7 auteur 0 ; coût '350 GPU-hours'
- n°7 pas 8 auteur 0 ; coût '700 GPU-hours'
- n°8 pas 9 auteur 0 ; coût '1000 GPU-hours'
## Propositions de l'ensemble final issues de cette action (pas égal)
{
 "auteur": 0,
 "controles": "We will compare the performance of different prompt engineering techniques against a strong baseline like CLIP-guided T2I models, and ablate the effects of the model and dataset used for prompt filtering.",
 "cout_heures": 200.0,
 "cout_texte": "200 GPU-hours",
 "numero": 3,
 "pas": 3,
 "prediction": "We expect to see that prompt engineering can lead to significant improvements in detail preservation and image quality, but the optimal technique may depend on the specific T2I model architecture and long-prompt characteristics. However, we might encounter challenges in balancing the trade-offs between different techniques and achieving stable results.\n\nSet now contains:\n \n1. Investigating the Effectiveness of Scratch Fine-Tuning for Long-Prompt T2I Models\n2. Understanding the Impact of Training Objectives on Long-Prompt T2I Generation\n3. Adversarial Meta-Learning for Long-Prompt T2I Models\n4. Investigating Prompt Engineering Techniques for Long-Prompt T2I Models",
 "texte": "We will explore the role of prompt engineering in improving the performance of T2I models on long prompts. Specifically, we will investigate the use of different language decoding strategies, such as beam search and nucleus sampling, and language model pre-processing techniques, like prompt filtering and truncation. We will evaluate the performance of these techniques on a range of long-prompt text-image pairs using metrics like detail-specific IoU and MS-SSIM.",
 "titre": "Investigating Prompt Engineering Techniques for Long-Prompt T2I Models",
 "version": 1
}
## Cibles de la tâche, avec P(oui) de l'énoncé seul et P(oui) par proposition de l'ensemble final
### controls
- C1 [énoncé 0.438] [couvert par l'ensemble : False] par proposition {1: 0.182, 2: 0.202, 3: 0.223, 4: 0.321, 5: 0.407, 6: 0.321, 7: 0.321, 8: 0.182}
    Fine-tuning baseline: the same pre-trained text-to-image backbone fine-tuned directly on the same long-caption training data (e.g., LongAlign-style long-caption fine-tuning), so that any gain is attributable to the proposed method rather than to the training data.
- C2 [énoncé 0.818] [couvert par l'ensemble : False] par proposition {1: 0.033, 2: 0.042, 3: 0.068, 4: 0.029, 5: 0.469, 6: 0.026, 7: 0.053, 8: 0.047}
    Projection/adapter baseline: a method that encodes the long prompt with a language model and projects it into the frozen text-to-image model's original text-embedding space or context window (e.g., ELLA- or LLM4GEN-style adapters).
- C3 [énoncé 0.469] [couvert par l'ensemble : False] par proposition {1: 0.068, 2: 0.085, 3: 0.119, 4: 0.165, 5: 0.245, 6: 0.182, 7: 0.321, 8: 0.223}
    Comparison with the unmodified pre-trained base model(s) on the same long prompts, including at least one strong modern text-to-image model with a powerful text encoder (T5-XXL or multimodal LLM, e.g., SD-3.5, FLUX, Qwen-Image), to show that the gain is not merely a matter of using a stronger text encoder.
- C4 [énoncé 0.622] [couvert par l'ensemble : False] par proposition {1: 0.068, 2: 0.068, 3: 0.148, 4: 0.321, 5: 0.085, 6: 0.06, 7: 0.042, 8: 0.06}
    Evaluation stratified by prompt length (e.g., token-length bins up to and beyond 500 tokens), including prompts longer than those in the training data, to measure length generalization rather than only an overall average.
- C5 [énoncé 0.531] [couvert par l'ensemble : False] par proposition {1: 0.06, 2: 0.053, 3: 0.06, 4: 0.047, 5: 0.068, 6: 0.026, 7: 0.02, 8: 0.012}
    Regression check on standard-length prompts: evaluation on standard short-prompt text-to-image benchmarks (e.g., T2I-CompBench, GenEval) to verify that long-prompt handling does not degrade ordinary generation or erase pre-trained knowledge.
- C6 [énoncé 0.349] [couvert par l'ensemble : False] par proposition {1: 0.047, 2: 0.026, 3: 0.085, 4: 0.165, 5: 0.085, 6: 0.107, 7: 0.107, 8: 0.016}
    Compute-matched comparison: baselines (e.g., fine-tuned or single-condition variants) trained with an equivalent compute or parameter budget, so that gains cannot be explained by extra training compute or capacity.
### fruitful_directions
- F1 [énoncé 0.947] [couvert par l'ensemble : True] par proposition {1: 0.651, 2: 0.245, 3: 0.438, 4: 0.531, 5: 0.531, 6: 0.107, 7: 0.269, 8: 0.119}
    Compose rather than compress: factorize the long prompt into several components that each stay within the short-prompt input domain of a frozen pre-trained text-to-image model, run the model on each component and sum the noise predictions (energy-based, product-of-experts concept conjunction), avoiding full fine-tuning; this keeps performance robust as prompts get longer than the training prompts.
- F2 [énoncé 0.731] [couvert par l'ensemble : True] par proposition {1: 0.5, 2: 0.085, 3: 0.018, 4: 0.5, 5: 0.531, 6: 0.047, 7: 0.349, 8: 0.003}
    Learn the prompt decomposition end-to-end without decomposition labels, directly in the text-representation space (e.g., a light query transformer over the language-model encoding, or LoRA on an LLM text encoder that emits several component representations), trained only by the diffusion loss of the composed prediction through the frozen generator.
- F3 [énoncé 0.026] [couvert par l'ensemble : False] par proposition {1: 0.202, 2: 0.095, 3: 0.165, 4: 0.321, 5: 0.294, 6: 0.068, 7: 0.165, 8: 0.06}
    Vary the decomposition granularity (number of components) and test finer decompositions: more components give larger gains over compute-matched baselines.
### sterile_directions
- S1 [énoncé 0.007] [couvert par l'ensemble : True] par proposition {1: 0.593, 2: 0.622, 3: 0.349, 4: 0.407, 5: 0.622, 6: 0.269, 7: 0.378, 8: 0.107}
    Splitting the paragraph linguistically (e.g., one sub-prompt per sentence) and composing the frozen model's predictions on these sub-prompts: each component loses the global context, giving inconsistent or broken scenes.
- S2 [énoncé 0.321] [couvert par l'ensemble : True] par proposition {1: 0.777, 2: 0.378, 3: 0.245, 4: 0.818, 5: 0.349, 6: 0.269, 7: 0.349, 8: 0.007}
    Relying on direct fine-tuning of the text-to-image model on long-caption data as the main solution and expecting it to extrapolate: it works within training lengths but degrades sharply on prompts longer than those seen in training (up to a 30% drop beyond 500 tokens).
- S3 [énoncé 0.010] [couvert par l'ensemble : False] par proposition {1: 0.009, 2: 0.006, 3: 0.003, 4: 0.011, 5: 0.037, 6: 0.003, 7: 0.011, 8: 0.003}
    Compressing the whole paragraph into a single condition projected into the model's original text-embedding space (a projection/adapter approach with one component) as the main approach: the information bottleneck makes it inferior to a multi-component composition at equal budget.
## Énoncé de la tâche
Modern text-to-image (T2I) diffusion models generate images of unprecedented diversity and quality from natural-language descriptions, and progress in architectures and theoretical foundations has allowed them to scale to billions of parameters. This paradigm works well for concise prompts but falters when the input becomes a descriptive paragraph. While a model may excel at rendering "a house in the middle of a forest", it often fails when the prompt expands, detailing the terracotta roof tiles, the weathered white panels of the house, and the striking contrast cast by the afternoon sun.

This failure stems from a fundamental conflict between the nature of long-form text and the models' training paradigm. T2I models are predominantly trained on vast datasets of images paired with short, concise, often label-like captions. They learn to map keywords and short phrases to visual features, but are undertrained on interpreting the narrative flow and distributed details of a paragraph, so a descriptive paragraph is effectively an out-of-distribution input for them. Part of the difficulty is often attributed to the fixed context window of text encoders such as CLIP, which can be lifted by switching to more powerful language models; yet even modern models that use powerful text encoders struggle on these inputs, missing more than half of the specified objects.

Existing methods attempt to bridge this gap through two strategies. The most direct approach fine-tunes the T2I model on long-captioned data. While effective within the training lengths, it requires intensive tuning, extrapolating to even longer prompts remains challenging, and the tuned models risk "catastrophic forgetting" of their pre-trained knowledge. The second strategy adopts projection-based methods that map the long prompt, typically encoded by a language model, into the effective context window or original text-embedding space of the pre-trained model. There, the information bottleneck sacrifices the very details that make long prompts compelling.

These limitations reveal an open question: how can we utilize a pre-trained model's existing knowledge of short prompts to render long, intricate paragraphs, preserving their many details while remaining robust as prompts grow longer than those seen during training?