# Action 3 : 2506.16404v3/e1/0,9
tâche 2506.16404v3 ; jetons de l'action 150 ; jetons ids 150
## Historique de cette action
[{"agent": 0, "manquants": [], "motif": null, "numero": 9, "operation": "ADD", "pas": 9, "valide": true}]
## Texte de l'action
ACTION: ADD
TITLE: Discussion and Future Directions for Directed Graph Generation
PROPOSAL: Provide a comprehensive discussion of the results and implications of the aforementioned experiments, highlighting their contributions to the field of directed graph generation, and outlining future research directions and challenges, including potential applications in neural architecture search, scene graph generation, and other areas.
CONTROLS: Include a critical evaluation of the current state-of-the-art in directed graph generation and a roadmap for future research, addressing potential limitations and open questions.
COST: N/A (this proposal is a qualitative analysis).
PREDICTION: This final proposal will provide a comprehensive summary of the research, showcase the contributions of the research, and inspire future work in the field of directed graph generation.

## Historique complet de l'épisode (opérations seulement)
pas 0: ADD n°1 valide=True motif=None manquants=[]; pas 1: ADD n°2 valide=True motif=None manquants=['PREDICTION']; pas 2: REVISE n°None valide=False motif=REVISE without a proposal number manquants=[]; pas 3: ADD n°3 valide=True motif=None manquants=[]; pas 4: ADD n°4 valide=True motif=None manquants=[]; pas 5: ADD n°5 valide=True motif=None manquants=[]; pas 6: ADD n°6 valide=True motif=None manquants=[]; pas 7: ADD n°7 valide=True motif=None manquants=[]; pas 8: ADD n°8 valide=True motif=None manquants=[]; pas 9: ADD n°9 valide=True motif=None manquants=[]
## Ensemble final : numéros et pas d'origine, titres
- n°1 pas 0 auteur 0 ; coût '10 GPU-hours.'
- n°2 pas 1 auteur 0 ; coût '1 GPU-hour (dataset creation).\nPREDICATION: We expect these datasets to serve as a valuable resource for the community, facilitating more rigorous evaluation and comparison of directed graph generators.\n\n(This proposal addresses the lack of standardized benchmarks mentioned in the problem statement, providing a foundation for the remaining experiments.)'
- n°3 pas 3 auteur 0 ; coût '5 GPU-hours.'
- n°4 pas 4 auteur 0 ; coût '3 GPU-hours.'
- n°5 pas 5 auteur 0 ; coût '20 GPU-hours.'
- n°6 pas 6 auteur 0 ; coût '15 GPU-hours.'
- n°7 pas 7 auteur 0 ; coût '5 GPU-hours (analysis) + 1 human-hour (annotation).'
- n°8 pas 8 auteur 0 ; coût '10 GPU-hours (fine-tuning) + 1 human-hour (validation).'
- n°9 pas 9 auteur 0 ; coût 'N/A (this proposal is a qualitative analysis).'
## Propositions de l'ensemble final issues de cette action (pas égal)
{
 "auteur": 0,
 "controles": "Include a critical evaluation of the current state-of-the-art in directed graph generation and a roadmap for future research, addressing potential limitations and open questions.",
 "cout_heures": null,
 "cout_texte": "N/A (this proposal is a qualitative analysis).",
 "numero": 9,
 "pas": 9,
 "prediction": "This final proposal will provide a comprehensive summary of the research, showcase the contributions of the research, and inspire future work in the field of directed graph generation.",
 "texte": "Provide a comprehensive discussion of the results and implications of the aforementioned experiments, highlighting their contributions to the field of directed graph generation, and outlining future research directions and challenges, including potential applications in neural architecture search, scene graph generation, and other areas.",
 "titre": "Discussion and Future Directions for Directed Graph Generation",
 "version": 1
}
## Cibles de la tâche, avec P(oui) de l'énoncé seul et P(oui) par proposition de l'ensemble final
### controls
- C1 [énoncé 0.562] [couvert par l'ensemble : False] par proposition {1: 0.076, 2: 0.321, 3: 0.321, 4: 0.321, 5: 0.107, 6: 0.011, 7: 0.245, 8: 0.016, 9: 0.321}
    A baseline that adapts state-of-the-art undirected graph generative models to directed graphs simply by removing the edge symmetrization (e.g., directed versions of DiGress and DeFoG), i.e. the same kind of generator without any explicit direction-aware component, to test whether dedicated directional modeling is needed.
- C2 [énoncé 0.269] [couvert par l'ensemble : False] par proposition {1: 0.269, 2: 0.107, 3: 0.042, 4: 0.033, 5: 0.026, 6: 0.011, 7: 0.053, 8: 0.012, 9: 0.076}
    A trivial statistical baseline that samples graphs from empirical maximum-likelihood distributions of the node count, node types and edge types (edge types conditioned on node-type pairs), to calibrate every metric against a model that learns no structure.
- C3 [énoncé 0.223] [couvert par l'ensemble : True] par proposition {1: 0.731, 2: 0.622, 3: 0.5, 4: 0.076, 5: 0.245, 6: 0.007, 7: 0.002, 8: 0.005, 9: 0.349}
    On directed acyclic graph datasets, a comparison with existing DAG-specific generators (e.g., the autoregressive D-VAE and LayerDAG), which rely on topological ordering to guarantee acyclicity.
- C4 [énoncé 0.321] [couvert par l'ensemble : False] par proposition {1: 0.182, 2: 0.245, 3: 0.165, 4: 0.202, 5: 0.202, 6: 0.029, 7: 0.068, 8: 0.042, 9: 0.107}
    A memorization and diversity control: validity is reported together with uniqueness (generated graphs non-isomorphic to each other) and novelty (generated graphs not isomorphic to any training graph), e.g. as the fraction of samples that are simultaneously valid, unique and novel.
- C5 [énoncé 0.269] [couvert par l'ensemble : True] par proposition {1: 0.438, 2: 0.469, 3: 0.5, 4: 0.349, 5: 0.531, 6: 0.085, 7: 0.148, 8: 0.02, 9: 0.119}
    For acyclic targets, acyclicity and adherence to the target structural distribution are reported as separate metrics (and jointly), so that a method that guarantees acyclicity but misses the distribution, or the reverse, is exposed.
- C6 [énoncé 0.562] [couvert par l'ensemble : False] par proposition {1: 0.407, 2: 0.119, 3: 0.029, 4: 0.029, 5: 0.053, 6: 0.026, 7: 0.005, 8: 0.003, 9: 0.182}
    A capacity-matched control: when direction-specific architectural components are added, the plan compares against a direction-agnostic model widened to the same parameter count, to separate gains from directional inductive bias from gains due to model size.
### fruitful_directions
- F1 [énoncé 0.835] [couvert par l'ensemble : True] par proposition {1: 0.622, 2: 0.622, 3: 0.593, 4: 0.269, 5: 0.438, 6: 0.294, 7: 0.731, 8: 0.562, 9: 0.531}
    Make the denoising network explicitly direction-aware by modeling source-to-target (outgoing) and target-to-source (incoming) relations separately, e.g. a dual cross-attention between edge features and their transposes with a single softmax over both directions, instead of a standard graph transformer.
- F2 [énoncé 0.731] [couvert par l'ensemble : True] par proposition {1: 0.731, 2: 0.593, 3: 0.679, 4: 0.777, 5: 0.706, 6: 0.798, 7: 0.593, 8: 0.755, 9: 0.407}
    Feed the generator direction-aware positional encodings (e.g., magnetic Laplacian eigenvectors, multi-potential magnetic Laplacian, or forward and reverse random-walk probabilities) rather than encodings from a symmetrized Laplacian; random-walk encodings give the best scalability and runtime trade-off.
- F3 [énoncé 0.881] [couvert par l'ensemble : True] par proposition {1: 0.202, 2: 0.5, 3: 0.531, 4: 0.469, 5: 0.182, 6: 0.269, 7: 0.622, 8: 0.223, 9: 0.378}
    Use a one-shot, discrete-state iterative-refinement generator (discrete flow matching or discrete diffusion) over all ordered node pairs, with no node ordering, letting it learn constraints such as acyclicity implicitly while matching the target structural distribution.
### sterile_directions
- S1 [énoncé 0.005] [couvert par l'ensemble : False] par proposition {1: 0.007, 2: 0.002, 3: 0.068, 4: 0.085, 5: 0.018, 6: 0.085, 7: 0.033, 8: 0.008, 9: 0.01}
    Taking a generative architecture designed for undirected graphs and simply removing its symmetrization, without explicit directional components, as the main model for directed graphs.
- S2 [énoncé 0.026] [couvert par l'ensemble : False] par proposition {1: 0.007, 2: 0.004, 3: 0.068, 4: 0.014, 5: 0.033, 6: 0.011, 7: 0.004, 8: 0.012, 9: 0.148}
    Relying on scaling model capacity (widening or doubling the parameters of an adapted undirected model) instead of adding a directional inductive bias.
- S3 [énoncé 0.018] [couvert par l'ensemble : True] par proposition {1: 0.593, 2: 0.469, 3: 0.349, 4: 0.679, 5: 0.593, 6: 0.469, 7: 0.223, 8: 0.622, 9: 0.531}
    Building on autoregressive, topologically ordered DAG generators that enforce acyclicity by construction as the main approach: they satisfy the constraint but fail to capture the target structural distribution.
## Énoncé de la tâche
Directed graphs (digraphs) model systems with asymmetric relationships, capturing essential structures such as flows, dependencies, and hierarchies that arise in many real-world applications. This makes digraphs particularly well-suited for problems in diverse domains including biology, transportation, social dynamics, and, more recently, image and video understanding, where structured and directional representations are critical for interpretation and reasoning. Consequently, generating digraphs is central to tasks such as simulation, data augmentation and novel instance discovery in domains with directional structure.

Graph generative models aim to learn the probability distribution of a set of observed graphs, enabling the generation of new samples that preserve structural and statistical properties. Such models have shown strong potential in diverse applications, including drug discovery, finance, social network modeling, and medicine. However, most generative models focus on undirected graphs, with only limited efforts on directed settings. The vast majority of works on directed graph generation focus solely on directed acyclic graphs (DAGs), with autoencoders, autoregressive methods and, more recently, diffusion combined with an auto-regressive process; these require the input DAGs to be topologically ordered, which can result in higher computational cost. Other approaches are tailored to specific applications and, therefore, to DAGs. A general digraph generation method, following an auto-regressive perspective, has only recently been proposed, and its implementation is not publicly available, limiting its accessibility for study and evaluation.

Two main factors limit progress in this direction. First, at the modeling level, the directed setting is inherently more challenging than its undirected counterpart: edge directionality greatly enlarges the learnable space (for graphs with 4 nodes, there are 218 possible digraphs, compared to only 11 undirected ones) and introduces a substantially larger dependency space, making the underlying distribution harder to learn. In directed graphs, a model must distinguish the different semantics carried by incoming and outgoing edges. The difficulty is further amplified in settings where domain-specific structural constraints must be respected, such as acyclicity in DAGs. Second, beyond these technical challenges, the lack of standardized benchmarks for directed graph generation is a barrier to rigorous evaluation and fair comparison: existing approaches typically rely only on proxy metrics derived from downstream tasks, failing to directly evaluate generative quality, and there are no established benchmarks to evaluate digraph generative quality systematically.

This raises several questions. How can a generative model be made expressive enough to learn distributions over general directed graphs, capturing directional dependencies and respecting structural properties such as acyclicity, without being restricted to DAGs or relying on a prescribed node ordering? Is it sufficient to extend generative architectures designed for undirected graphs to the directed case, or must such models be explicitly sensitive to directional topology? And how can the generative quality of directed graph generators be evaluated directly and systematically, rather than through downstream proxies, so that different approaches can be compared fairly?