# Action 1 : 2506.05216v2/e2/0,5
tâche 2506.05216v2 ; jetons de l'action 179 ; jetons ids 179
## Historique de cette action
[{"agent": 0, "manquants": [], "motif": null, "numero": 4, "operation": "ADD", "pas": 5, "valide": true}]
## Texte de l'action
ACTION: ADD
TITLE: Comparison of KernelSHAP and LeverageSHAP on High-Dimensional Data
PROPOSAL: We investigate the performance of KernelSHAP and LeverageSHAP when applied to high-dimensional data. Specifically, we evaluate the accuracy, stability, and computational efficiency of both methods on large real-world datasets with thousands of features. We also assess the impact of dimensionality reduction techniques on the results.
CONTROLS: We compare the performance of KernelSHAP and LeverageSHAP with and without dimensionality reduction.
COST: 12,000 GPU-hours (high-dimensional data and dimensionality reduction)
PREDICTION: Our comparison should provide insights into the performance of KernelSHAP and LeverageSHAP in high-dimensional settings. We expect that both methods will perform well when combined with dimensionality reduction techniques, but may struggle with extremely high-dimensional data.

## Historique complet de l'épisode (opérations seulement)
pas 0: ADD n°1 valide=True motif=None manquants=[]; pas 1: ADD n°2 valide=True motif=None manquants=[]; pas 2: REVISE n°None valide=False motif=REVISE without a proposal number manquants=[]; pas 3: REVISE n°None valide=False motif=REVISE without a proposal number manquants=[]; pas 4: ADD n°3 valide=True motif=None manquants=[]; pas 5: ADD n°4 valide=True motif=None manquants=[]; pas 6: ADD n°5 valide=True motif=None manquants=[]; pas 7: ADD n°6 valide=True motif=None manquants=[]; pas 8: ADD n°7 valide=True motif=None manquants=[]; pas 9: ADD n°8 valide=True motif=None manquants=[]
## Ensemble final : numéros et pas d'origine, titres
- n°1 pas 0 auteur 0 ; coût '0 GPU-hours (theoretical result)'
- n°2 pas 1 auteur 0 ; coût '1000 GPU-hours (empirical analysis on several real-world datasets)'
- n°3 pas 4 auteur 0 ; coût '8000 GPU-hours (comparison on several real-world datasets and different scenarios)'
- n°4 pas 5 auteur 0 ; coût '12,000 GPU-hours (high-dimensional data and dimensionality reduction)'
- n°5 pas 6 auteur 0 ; coût '6000 GPU-hours (evaluation of SimSHAP and comparison to other methods)'
- n°6 pas 7 auteur 0 ; coût '12000 GPU-hours (evaluation on a range of datasets)'
- n°7 pas 8 auteur 0 ; coût '5000 GPU-hours (evaluation using our framework)'
- n°8 pas 9 auteur 0 ; coût '0 GPU-hours (software development)'
## Propositions de l'ensemble final issues de cette action (pas égal)
{
 "auteur": 0,
 "controles": "We compare the performance of KernelSHAP and LeverageSHAP with and without dimensionality reduction.",
 "cout_heures": 12000.0,
 "cout_texte": "12,000 GPU-hours (high-dimensional data and dimensionality reduction)",
 "numero": 4,
 "pas": 5,
 "prediction": "Our comparison should provide insights into the performance of KernelSHAP and LeverageSHAP in high-dimensional settings. We expect that both methods will perform well when combined with dimensionality reduction techniques, but may struggle with extremely high-dimensional data.",
 "texte": "We investigate the performance of KernelSHAP and LeverageSHAP when applied to high-dimensional data. Specifically, we evaluate the accuracy, stability, and computational efficiency of both methods on large real-world datasets with thousands of features. We also assess the impact of dimensionality reduction techniques on the results.",
 "titre": "Comparison of KernelSHAP and LeverageSHAP on High-Dimensional Data",
 "version": 1
}
## Cibles de la tâche, avec P(oui) de l'énoncé seul et P(oui) par proposition de l'ensemble final
### controls
- C1 [énoncé 0.706] [couvert par l'ensemble : True] par proposition {1: 0.165, 2: 0.562, 3: 0.531, 4: 0.202, 5: 0.223, 6: 0.438, 7: 0.269, 8: 0.349}
    Use models whose exact Shapley values can be computed (e.g., tree ensembles with an exact tree-based Shapley solver) as ground truth, and score every estimator by its normalized mean squared error to these exact Shapley values.
- C2 [énoncé 0.798] [couvert par l'ensemble : True] par proposition {1: 0.148, 2: 0.321, 3: 0.562, 4: 0.438, 5: 0.438, 6: 0.562, 7: 0.223, 8: 0.835}
    Include the KernelSHAP implementation of the SHAP library as a baseline, alongside a plain KernelSHAP (kernel-weight sampling followed by the constrained regression).
- C3 [énoncé 0.755] [couvert par l'ensemble : True] par proposition {1: 0.269, 2: 0.622, 3: 0.893, 4: 0.593, 5: 0.165, 6: 0.731, 7: 0.294, 8: 0.706}
    Include the existing estimators that already have convergence guarantees, LeverageSHAP and unbiased KernelSHAP, as baselines.
- C4 [énoncé 0.531] [couvert par l'ensemble : False] par proposition {1: 0.133, 2: 0.223, 3: 0.026, 4: 0.026, 5: 0.085, 6: 0.037, 7: 0.085, 8: 0.133}
    Compare all estimators at matched sample budgets (the same number m of value-function evaluations), sweeping m over several orders of magnitude to trace error versus budget instead of reporting a single budget.
- C5 [énoncé 0.679] [couvert par l'ensemble : True] par proposition {1: 0.119, 2: 0.622, 3: 0.223, 4: 0.085, 5: 0.042, 6: 0.202, 7: 0.223, 8: 0.095}
    Repeat each configuration over many random seeds (on the order of 100) and report the median error together with interquartile ranges, rather than a single run.
- C6 [énoncé 0.593] [couvert par l'ensemble : True] par proposition {1: 0.06, 2: 0.245, 3: 0.438, 4: 0.5, 5: 0.245, 6: 0.165, 7: 0.269, 8: 0.321}
    In high-dimensional settings (hundreds to thousands of features), report wall-clock running time alongside estimation error for each estimator, so that accuracy-versus-cost trade-offs can be compared.
### fruitful_directions
- F1 [énoncé 0.893] [couvert par l'ensemble : True] par proposition {1: 0.798, 2: 0.818, 3: 0.798, 4: 0.679, 5: 0.012, 6: 0.835, 7: 0.562, 8: 0.798}
    Rewrite the constrained Shapley regression as an unconstrained problem (an ordinary least-squares problem or a matrix-vector product with a matrix having orthonormal columns), view KernelSHAP-type estimators as randomized sketches of it, and use randomized numerical linear algebra (matrix concentration, subspace embedding) to prove non-asymptotic sample-complexity bounds covering KernelSHAP, LeverageSHAP and unbiased KernelSHAP, for sampling with and without replacement.
- F2 [énoncé 0.924] [couvert par l'ensemble : True] par proposition {1: 0.407, 2: 0.835, 3: 0.562, 4: 0.085, 5: 0.003, 6: 0.033, 7: 0.223, 8: 0.033}
    Build the estimator as a sketched least-squares (regression) problem on the sampled subsets rather than as an approximate matrix-vector product: regression estimators gave lower error at the same sample budget across datasets.
- F3 [énoncé 0.940] [couvert par l'ensemble : True] par proposition {1: 0.5, 2: 0.438, 3: 0.438, 4: 0.06, 5: 0.001, 6: 0.026, 7: 0.076, 8: 0.014}
    Scale provable sampling-based estimators to thousands of features by never computing the binomial coefficients in the sampling probabilities and weights explicitly, and by replacing draws from very large binomial distributions with Poisson approximations.
### sterile_directions
- S1 [énoncé 0.182] [couvert par l'ensemble : True] par proposition {1: 0.469, 2: 0.593, 3: 0.622, 4: 0.165, 5: 0.01, 6: 0.148, 7: 0.119, 8: 0.06}
    Adopting an unbiased approximate matrix-vector multiplication estimator (the unbiased KernelSHAP style of estimating the closed-form solution directly from sampled subsets) as the main estimator: it gave worse approximations than sketched regression for a fixed number of samples, and the gap widened as the dimension increased.
- S2 [énoncé 0.245] [couvert par l'ensemble : True] par proposition {1: 0.562, 2: 0.867, 3: 0.562, 4: 0.085, 5: 0.002, 6: 0.165, 7: 0.068, 8: 0.018}
    Relying on i.i.d. sampling with replacement in low-dimensional problems where the sample budget m can exceed 2^d: such an estimator does not recover the exact Shapley values and does worse than brute-force enumeration of all subsets.
## Énoncé de la tâche
Explaining the prediction of a machine learning model is as important as building the model itself, since it helps determine whether the model can be trusted to give meaningful predictions when deployed in the real world. Such explanations of black-box decisions are all the more important in sensitive applications, such as medicine, finance, and law.

In the quest to explain models, a recent line of research has focused on developing local explanation methods, whose objective is to identify the degree of influence that each feature of a specific data point has on the model prediction. These include explanation vectors, LIME, and Shapley values. When local methods are expressed as additive feature attribution methods, i.e., when the feature influences add up linearly to give the model prediction, game-theoretic results guarantee that Shapley values provide the unique solution to additive feature attribution. For these reasons, Shapley values have emerged as a front-runner among model-agnostic explanation tools. They have also found relevance in other machine learning applications, such as global sensitivity analysis, where they have been used to partition the coefficient of determination in linear regression. More concretely, Shapley values offer a general approach to answering the following question: given a model $f$ trained on data points with $d$ features and evaluated on a test sample $\bm{q} \in \mathbb{R}^d$, how does each feature of $\bm{q}$ locally influence the final model decision $f(\bm{q})$?

Consider a value function $v: 2^{[d]} \to \mathbb{R}$, where $v(S)$ depends on the output of the model on the test sample $\bm{q}$ using only the features in the subset $S$ of $[d] = \{1, \ldots, d\}$. For instance, given a baseline $\bm{q}^{\textup{base}}$, one may define $v(S) = f(\bm{q}^{(S)})$, where $\bm{q}^{(S)}_j = \bm{q}_j$ if $j \in S$ and $\bm{q}^{(S)}_j = \bm{q}^{\textup{base}}_j$ otherwise. The Shapley value of the $j$-th feature is $\phi_j^* = \sum_{S \subseteq [d] \setminus \{j\}} \frac{|S|!(d-|S|-1)!}{d!} (v(S \cup \{j\}) - v(S))$, the aggregate of the marginal contributions of feature $j$ to the model prediction over all subsets $S$ that do not contain $j$. Computing it requires evaluating $v(S)$ on each of the exponentially many subsets of $[d]$, and each evaluation of $v(S)$ is itself costly, with the exact cost depending on how $v(S)$ is defined. This cost can be reduced for certain types of simple models, but an appealing aspect of Shapley values is their potential for model-agnostic explanations; as $d$ increases, an exact solution quickly cannot be computed and estimation techniques are required. Because Shapley values are increasingly used to interpret model behavior, the quality of the estimator is of the utmost importance: an unfaithful explanation may lead to incorrect model interventions, business decisions, or court judgments whenever model assessment is involved.

To make Shapley values computationally tractable for arbitrary models, multiple randomized estimators have been proposed; they aim to approximate the Shapley values while using only a sub-exponential number of value-function evaluations. Perhaps the most popular is KernelSHAP, which is implemented in the widely used SHAP library. KernelSHAP and related estimators rely on the observation that the Shapley values are the solution to a constrained weighted least-squares problem. Let $\bm{Z}$ be the $(2^d-2) \times d$ binary matrix whose row indexed by a nonempty proper subset $S$ of $[d]$ has entry one in column $j$ exactly when $j \in S$, let $\bm{W}$ be the diagonal matrix of kernel weights $k(S) = (d-1)/(\binom{d}{|S|}|S|(d-|S|))$, and let $\bm{v}_S = v(S) - v(\emptyset)$. Then the vector of Shapley values $\bm{\phi}^*$ minimizes $\|\sqrt{\bm{W}}(\bm{Z}\bm{\phi} - \bm{v})\|^2$ over all $\bm{\phi} \in \mathbb{R}^d$ satisfying $\bm{1}^\top \bm{\phi} = v([d]) - v(\emptyset)$. Like the definition itself, this regression formulation requires knowing $v(S)$ for every subset of $[d]$. To get around this cost, KernelSHAP randomly subsamples and reweights the rows of the regression problem, sampling the row of subset $S$ with probability proportional to its kernel weight $k(S)$ (a choice motivated by the fact that the least-squares objective can be written as an expectation with respect to this sampling distribution), and then outputs the solution of the much smaller constrained regression problem. Other practical improvements, such as paired sampling and sampling without replacement, are also included in the SHAP library implementation of KernelSHAP.

A large number of subsequent works have built on KernelSHAP. Of particular relevance are unbiased KernelSHAP and LeverageSHAP, which appear to be the only extensions of KernelSHAP with theoretical convergence guarantees. Unbiased KernelSHAP is an unbiased variant of KernelSHAP for which an asymptotic variance analysis is given; however, it has been observed to underperform the original KernelSHAP in practice. LeverageSHAP is a regression-based estimator that samples the rows of the regression problem according to their statistical leverage scores, and it satisfies strong non-asymptotic theoretical guarantees; numerical experiments suggest that it may outperform KernelSHAP in most settings. By contrast, theoretical bounds for KernelSHAP itself, the most influential and widely used of these estimators, have remained elusive, and the tradeoffs between these existing estimators are not well understood.

Several works have also focused specifically on the challenges of computing Shapley values for high-dimensional data. Many of them use parametric approaches to the computation of Shapley values, such as methods based on latent features or the recently proposed SimSHAP, which require overhead model pretraining; others, such as approaches for data structured on graphs, avoid computing Shapley values in large dimensions by leveraging inductive biases, and methods for large language models have also recently been developed. However, no algorithm at present is tailored to high-dimensional settings while providing provable guarantees on sample efficiency.

This leaves several open questions. Can non-asymptotic sample-complexity guarantees be proved for KernelSHAP and, more broadly, for the family of randomized estimators related to it, including estimators that sample subsets with or without replacement? What would such guarantees reveal about the relative performance of existing estimators such as KernelSHAP and LeverageSHAP, and about how the choice of sampling distribution affects accuracy? And can estimators that come with provable guarantees be made to scale to high-dimensional inputs?