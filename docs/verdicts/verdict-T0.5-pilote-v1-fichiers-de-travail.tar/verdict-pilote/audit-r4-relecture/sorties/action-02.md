# Action 2 : 2506.16404v3/e0/0,6
tâche 2506.16404v3 ; jetons de l'action 178 ; jetons ids 178
## Historique de cette action
[{"agent": 0, "manquants": [], "motif": null, "numero": 6, "operation": "ADD", "pas": 6, "valide": true}]
## Texte de l'action
ACTION: ADD
TITLE: Investigating the Impact of Architectural Variants on Directed Graph Generation
PROPOSAL: We propose to investigate the impact of different architectural variants on the performance of directed graph generative models. This includes exploring alternative GNN architectures, different latent representations, and varying numbers of layers and attention mechanisms. By systematically examining the effects of these architectural choices, we can gain a deeper understanding of what contributes to the success or failure of these models.
CONTROLS: Controls will be set by comparing different architectural variants and using the standardized dataset for evaluation.
COST: 25 GPU-hours
PREDICTION: This investigation may reveal important insights into the design of effective directed graph generative models and provide guidelines for navigating the space of possible architectures. However, the results may be influenced by the specific dataset used, and the generality of the findings may be limited.

## Historique complet de l'épisode (opérations seulement)
pas 0: ADD n°1 valide=True motif=None manquants=[]; pas 1: ADD n°2 valide=True motif=None manquants=[]; pas 2: REVISE n°1 valide=True motif=None manquants=[]; pas 3: ADD n°3 valide=True motif=None manquants=[]; pas 4: ADD n°4 valide=True motif=None manquants=[]; pas 5: ADD n°5 valide=True motif=None manquants=[]; pas 6: ADD n°6 valide=True motif=None manquants=[]; pas 7: REVISE n°4 valide=True motif=None manquants=[]; pas 8: ADD n°7 valide=True motif=None manquants=[]; pas 9: ADD n°8 valide=True motif=None manquants=[]
## Ensemble final : numéros et pas d'origine, titres
- n°1 pas 2 auteur 0 ; coût '20 GPU-hours (addition to original 10 GPU-hours)'
- n°2 pas 1 auteur 0 ; coût '30 GPU-hours'
- n°3 pas 3 auteur 0 ; coût '20 GPU-hours'
- n°4 pas 7 auteur 0 ; coût '50 GPU-hours (increase from original 40 GBP-hours)'
- n°5 pas 5 auteur 0 ; coût '30 GPU-hours'
- n°6 pas 6 auteur 0 ; coût '25 GPU-hours'
- n°7 pas 8 auteur 0 ; coût '20 GPU-hours'
- n°8 pas 9 auteur 0 ; coût '60 GPU-hours (aggregated cost from previous experiments)'
## Propositions de l'ensemble final issues de cette action (pas égal)
{
 "auteur": 0,
 "controles": "Controls will be set by comparing different architectural variants and using the standardized dataset for evaluation.",
 "cout_heures": 25.0,
 "cout_texte": "25 GPU-hours",
 "numero": 6,
 "pas": 6,
 "prediction": "This investigation may reveal important insights into the design of effective directed graph generative models and provide guidelines for navigating the space of possible architectures. However, the results may be influenced by the specific dataset used, and the generality of the findings may be limited.",
 "texte": "We propose to investigate the impact of different architectural variants on the performance of directed graph generative models. This includes exploring alternative GNN architectures, different latent representations, and varying numbers of layers and attention mechanisms. By systematically examining the effects of these architectural choices, we can gain a deeper understanding of what contributes to the success or failure of these models.",
 "titre": "Investigating the Impact of Architectural Variants on Directed Graph Generation",
 "version": 1
}
## Cibles de la tâche, avec P(oui) de l'énoncé seul et P(oui) par proposition de l'ensemble final
### controls
- C1 [énoncé 0.562] [couvert par l'ensemble : False] par proposition {1: 0.223, 2: 0.378, 3: 0.223, 4: 0.119, 5: 0.133, 6: 0.107, 7: 0.349, 8: 0.085}
    A baseline that adapts state-of-the-art undirected graph generative models to directed graphs simply by removing the edge symmetrization (e.g., directed versions of DiGress and DeFoG), i.e. the same kind of generator without any explicit direction-aware component, to test whether dedicated directional modeling is needed.
- C2 [énoncé 0.269] [couvert par l'ensemble : False] par proposition {1: 0.095, 2: 0.202, 3: 0.076, 4: 0.076, 5: 0.202, 6: 0.068, 7: 0.119, 8: 0.202}
    A trivial statistical baseline that samples graphs from empirical maximum-likelihood distributions of the node count, node types and edge types (edge types conditioned on node-type pairs), to calibrate every metric against a model that learns no structure.
- C3 [énoncé 0.223] [couvert par l'ensemble : False] par proposition {1: 0.026, 2: 0.085, 3: 0.023, 4: 0.378, 5: 0.047, 6: 0.165, 7: 0.182, 8: 0.269}
    On directed acyclic graph datasets, a comparison with existing DAG-specific generators (e.g., the autoregressive D-VAE and LayerDAG), which rely on topological ordering to guarantee acyclicity.
- C4 [énoncé 0.321] [couvert par l'ensemble : False] par proposition {1: 0.245, 2: 0.165, 3: 0.06, 4: 0.245, 5: 0.148, 6: 0.119, 7: 0.321, 8: 0.165}
    A memorization and diversity control: validity is reported together with uniqueness (generated graphs non-isomorphic to each other) and novelty (generated graphs not isomorphic to any training graph), e.g. as the fraction of samples that are simultaneously valid, unique and novel.
- C5 [énoncé 0.269] [couvert par l'ensemble : False] par proposition {1: 0.165, 2: 0.269, 3: 0.107, 4: 0.165, 5: 0.095, 6: 0.085, 7: 0.133, 8: 0.245}
    For acyclic targets, acyclicity and adherence to the target structural distribution are reported as separate metrics (and jointly), so that a method that guarantees acyclicity but misses the distribution, or the reverse, is exposed.
- C6 [énoncé 0.562] [couvert par l'ensemble : False] par proposition {1: 0.119, 2: 0.165, 3: 0.037, 4: 0.269, 5: 0.033, 6: 0.148, 7: 0.042, 8: 0.068}
    A capacity-matched control: when direction-specific architectural components are added, the plan compares against a direction-agnostic model widened to the same parameter count, to separate gains from directional inductive bias from gains due to model size.
### fruitful_directions
- F1 [énoncé 0.835] [couvert par l'ensemble : True] par proposition {1: 0.777, 2: 0.947, 3: 0.94, 4: 0.915, 5: 0.731, 6: 0.531, 7: 0.438, 8: 0.053}
    Make the denoising network explicitly direction-aware by modeling source-to-target (outgoing) and target-to-source (incoming) relations separately, e.g. a dual cross-attention between edge features and their transposes with a single softmax over both directions, instead of a standard graph transformer.
- F2 [énoncé 0.731] [couvert par l'ensemble : True] par proposition {1: 0.798, 2: 0.835, 3: 0.867, 4: 0.947, 5: 0.706, 6: 0.622, 7: 0.593, 8: 0.165}
    Feed the generator direction-aware positional encodings (e.g., magnetic Laplacian eigenvectors, multi-potential magnetic Laplacian, or forward and reverse random-walk probabilities) rather than encodings from a symmetrized Laplacian; random-walk encodings give the best scalability and runtime trade-off.
- F3 [énoncé 0.881] [couvert par l'ensemble : True] par proposition {1: 0.622, 2: 0.818, 3: 0.835, 4: 0.706, 5: 0.593, 6: 0.349, 7: 0.349, 8: 0.016}
    Use a one-shot, discrete-state iterative-refinement generator (discrete flow matching or discrete diffusion) over all ordered node pairs, with no node ordering, letting it learn constraints such as acyclicity implicitly while matching the target structural distribution.
### sterile_directions
- S1 [énoncé 0.005] [couvert par l'ensemble : False] par proposition {1: 0.033, 2: 0.119, 3: 0.469, 4: 0.007, 5: 0.119, 6: 0.076, 7: 0.005, 8: 0.002}
    Taking a generative architecture designed for undirected graphs and simply removing its symmetrization, without explicit directional components, as the main model for directed graphs.
- S2 [énoncé 0.026] [couvert par l'ensemble : False] par proposition {1: 0.026, 2: 0.068, 3: 0.009, 4: 0.005, 5: 0.085, 6: 0.01, 7: 0.001, 8: 0.014}
    Relying on scaling model capacity (widening or doubling the parameters of an adapted undirected model) instead of adding a directional inductive bias.
- S3 [énoncé 0.018] [couvert par l'ensemble : True] par proposition {1: 0.349, 2: 0.531, 3: 0.881, 4: 0.798, 5: 0.469, 6: 0.119, 7: 0.269, 8: 0.037}
    Building on autoregressive, topologically ordered DAG generators that enforce acyclicity by construction as the main approach: they satisfy the constraint but fail to capture the target structural distribution.
## Énoncé de la tâche
Directed graphs (digraphs) model systems with asymmetric relationships, capturing essential structures such as flows, dependencies, and hierarchies that arise in many real-world applications. This makes digraphs particularly well-suited for problems in diverse domains including biology, transportation, social dynamics, and, more recently, image and video understanding, where structured and directional representations are critical for interpretation and reasoning. Consequently, generating digraphs is central to tasks such as simulation, data augmentation and novel instance discovery in domains with directional structure.

Graph generative models aim to learn the probability distribution of a set of observed graphs, enabling the generation of new samples that preserve structural and statistical properties. Such models have shown strong potential in diverse applications, including drug discovery, finance, social network modeling, and medicine. However, most generative models focus on undirected graphs, with only limited efforts on directed settings. The vast majority of works on directed graph generation focus solely on directed acyclic graphs (DAGs), with autoencoders, autoregressive methods and, more recently, diffusion combined with an auto-regressive process; these require the input DAGs to be topologically ordered, which can result in higher computational cost. Other approaches are tailored to specific applications and, therefore, to DAGs. A general digraph generation method, following an auto-regressive perspective, has only recently been proposed, and its implementation is not publicly available, limiting its accessibility for study and evaluation.

Two main factors limit progress in this direction. First, at the modeling level, the directed setting is inherently more challenging than its undirected counterpart: edge directionality greatly enlarges the learnable space (for graphs with 4 nodes, there are 218 possible digraphs, compared to only 11 undirected ones) and introduces a substantially larger dependency space, making the underlying distribution harder to learn. In directed graphs, a model must distinguish the different semantics carried by incoming and outgoing edges. The difficulty is further amplified in settings where domain-specific structural constraints must be respected, such as acyclicity in DAGs. Second, beyond these technical challenges, the lack of standardized benchmarks for directed graph generation is a barrier to rigorous evaluation and fair comparison: existing approaches typically rely only on proxy metrics derived from downstream tasks, failing to directly evaluate generative quality, and there are no established benchmarks to evaluate digraph generative quality systematically.

This raises several questions. How can a generative model be made expressive enough to learn distributions over general directed graphs, capturing directional dependencies and respecting structural properties such as acyclicity, without being restricted to DAGs or relying on a prescribed node ordering? Is it sufficient to extend generative architectures designed for undirected graphs to the directed case, or must such models be explicitly sensitive to directional topology? And how can the generative quality of directed graph generators be evaluated directly and systematically, rather than through downstream proxies, so that different approaches can be compared fairly?