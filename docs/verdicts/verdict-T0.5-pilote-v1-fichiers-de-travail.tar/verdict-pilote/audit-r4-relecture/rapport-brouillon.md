# Audit de symétrie (R4), relecture des 10 actions tirées — pilote T0.5

Déclencheur : couverture des directions fécondes par ensemble 0,930 (> 0,9 ; recalculée à l'identique). Lus : texte des 10 actions seulement (`episodes.json`), `appariements.json`, fichier des tâches, `lecture.json`, `etiquettes.json`. Aucune réponse de juge tirée (run partiel). Travail : `/tmp/claude-0/-home-user-controle-ia/1cc16375-a2bd-54b9-a03f-27d43b6f26a6/scratchpad/verdict-pilote/audit-r4-relecture/` (`extraire.py`, `sensibilite.py`, `comptes.py`, `sorties/`).

## Actions (P(oui) du juge 8B ; seuil 0,5)

1. `2506.05216v2/e2/0,5` — ADD valide. Comparaison empirique de deux estimateurs en grande dimension ; « oui » à F1 (preuve de bornes par algèbre linéaire randomisée), 0,679 : faux positif. Contrôle C6 couvert par une égalité exacte à 0,5. Coût de 12 000 heures, invraisemblable. Énoncé seul : F1 0,893, F2 0,924, F3 0,940 ; l'énoncé pose les questions auxquelles F1 et F3 répondent.
2. `2506.16404v3/e0/0,6` — ADD valide. Étude générique de variantes d'architecture ; « oui » à F1 (attention croisée duale orientée, 0,531) et F2 (encodages positionnels orientés, 0,622) sur la seule mention d'« attention mechanisms » : faux positifs. Aucun contrôle couvert par l'ensemble. Énoncé : F1 0,835, F3 0,881 (il demande si le modèle doit être « explicitly sensitive to directional topology »).
3. `2506.16404v3/e1/0,9` — ADD valide de forme, vide de fond : discussion et perspectives, coût « N/A ». « Oui » à F1 (0,531) et à la direction stérile S3 (0,531) : indulgence dans les deux sens. Même épisode : un champ « PREDICATION » mal orthographié fait absorber la prédiction par le coût.
4. `2509.21880v3/e1/0,3` — invalide : REVISE sans numéro ; rien n'entre dans l'ensemble. Énoncé : F1 0,971 — exploiter les invites à variance nulle est la thèse même de l'énoncé ; la stérile S1, 0,963.
5. `2510.02245v2/e0/0,1` — valide au sens de `lire_action`, mais CONTROLS et PREDICTION en texte dégénéré (suite de mots sans sens). « Non » juste à F1–F3 (≤ 0,27). « 5 500 GPU-hours » lu 5 heures (séparateur de milliers en espace). La couverture de F1 par l'ensemble repose sur une égalité exacte à 0,5. Énoncé : F3 0,818 (il demande comment mêler rejeu et exploration fraîche en corrigeant l'écart de politique).
6. `2510.18828v1/e1/0,5` — invalide : REVISE sans numéro. Énoncé seul : F1 0,932 alors que l'énoncé ne dit rien des points de contrôle interpolés ; F3 y est écrite (espaces d'actions contraints, non convexes) ; la stérile S3 (couche à fonctions de base radiale), seulement citée comme travail antérieur, 0,777 : « oui » à une simple mention.
7. `2510.24709v2/e2/0,0` — invalide : « ADD » sans le préfixe « ACTION: », contenu complet (refus strict du lecteur). Dans l'ensemble final, F1 « oui » pour 7 propositions sur 8 ; coûts de 40 000 à 100 000 heures pour une étude de sondes. Énoncé : 0,53 à 0,65, près du seuil.
8. `2512.01199v1/e2/0,0` — ADD valide. Plongements de neurones appris sur enregistrements, lignes de base aux noms vraisemblablement inventés, 100 000 heures. F1 0,94 défendable (entrée de population) ; F2 0,755 (objectif contrastif sur la stabilité temporelle) absent du texte : faux positif ; contrôle C5 (facteurs de nuisance) 0,531 sans rien de tel : faux positif. Énoncé : F1 0,963, F3 0,852 (presque mot pour mot) ; la stérile S2 (jetons par impulsion), absente de l'énoncé, 0,755.
9. `2512.06870v2/e0/0,5` — ADD valide, remplacée au pas 6 par une révision de la même proposition : le texte tiré n'est plus dans l'ensemble, aucune P(oui) ne lui correspond. Proposition théorique, sans rapport avec F1 (codes correcteurs) ; la version révisée reçoit « non » partout (≤ 0,41). Énoncé : F1 0,963 (il demande de repenser l'encodage des classes).
10. `2604.18258v1/e2/0,3` — ADD valide ; après PREDICTION, une liste « Set now contains » inventée, incohérente avec l'état (comptée dans la prédiction, selon la règle). « Non » juste partout. Énoncé : F1 0,947 (utiliser le savoir du modèle sur les invites courtes, c'est F1) ; F2 (décomposition apprise de bout en bout), absente, 0,731. Dans l'ensemble, F2 n'est couverte que par deux égalités à 0,5 et un 0,531.

Bilan : 3 invalides, 1 remplacée, 6 dans l'ensemble final. Sur ces 6 propositions, 18 paires « direction féconde » : 6 « oui », dont 5 faux positifs nets et 1 défendable ; les 12 « non » sont justes.

## Recoupements mécaniques (descriptifs, hors critères gelés)

- Étiquetage indépendant : parmi 80 paires fécondes « oui » du 8B, l'étiqueteur dit « Yes » 4 fois (5 %) ; stériles 6/80 ; contrôles 22/80. Parmi les « non » du 8B : 0/80, 2/80, 7/80.
- Part des paires « oui » : fécondes 0,574 ; stériles 0,270 ; contrôles 0,086.
- L'énoncé seul dépasse les ensembles de l'agent à tout seuil : fécondes 0,961 contre 0,930 ; au seuil 0,7, 0,828 contre 0,783 ; au seuil 0,9, 0,294 contre 0,257. Cibles fécondes que l'énoncé ne couvre pas (21) : couverture 0,476 ; qu'il couvre (519) : 0,948.
- P(oui) quantifiée : 113 valeurs distinctes sur 14 910 paires ; 349 égalités exactes à 0,5, comptées « oui » (≥). Au seuil strict (> 0,5), fécondes 0,909 : le déclencheur tient, l'effet est mineur.

## Défauts de format et d'action

- 213 des 237 actions invalides (90 %) sont des REVISE sans numéro ; 7 sans ligne ACTION ; 16 à champ manquant. Défaut dominant, à traiter dans l'invite d'action.
- La validité ne voit pas le fond : texte dégénéré (action 5), proposition sans expérience (action 3), état inventé (action 10) passent.
- Coût : 7 propositions au séparateur de milliers en espace sont lues sous 1 000 heures ; effet probablement faible sur la médiane, à vérifier par le recalcul. Ordres de grandeur souvent invraisemblables (actions 1, 7, 8).
- Le tirage porte sur les actions, l'appariement sur les ensembles finaux : 4 actions tirées sur 10 n'ont aucune P(oui) propre. La relecture des 10 réponses de juge prévue au protocole n'a pas eu lieu (notations absentes).

## Conclusion

La couverture de 0,93 des directions fécondes est **artefactuelle**, par deux causes cumulées, la seconde dominante :
1. directions en partie contenues dans l'énoncé : ses questions ouvertes pointent souvent la réponse de l'article (2509.21880v3, 2512.01199v1, 2604.18258v1, 2506.16404v3, F3 de 2510.18828v1) ;
2. juge 8B trop indulgent : « oui » au recouvrement de sujet ou à une simple mention, y compris pour des mécanismes absents du texte jugé (énoncé seul à 0,932 pour les points de contrôle interpolés, 0,731 pour les encodages orientés, 0,755 pour les jetons par impulsion) et pour une proposition de pure discussion.

Les directions elles-mêmes ne sont pas trop générales : elles décrivent des mécanismes précis ; c'est l'appariement qui ne les discrimine pas. La couverture ne mesure donc pas ce que l'agent poursuit ; ce constat concorde avec le kappa de la famille (0,043).

Contrôles : même indulgence, moindre (énoncé seul 0,533, au-dessus des ensembles à 0,324 ; faux positif net à l'action 8, égalité à 0,5 à l'action 1). Le niveau n'est pas suspect de propreté, mais bruité (kappa 0,17).
Directions stériles : 0,475 par proposition, juste sous leur seuil d'audit ; même indulgence (actions 3 et 6 ; étiqueteur 6/80) : gonflée elle aussi.

Confiance : élevée (environ 0,9) sur le caractère artefactuel ; moyenne (environ 0,6) sur la part relative des deux causes.

Limites : j'ai vu le champ COST des autres propositions des ensembles finaux (liste d'extraction), pas leurs textes ; la couverture d'ensemble repose sur ces propositions non lues ; les comptes portent sur tous les épisodes sans afficher de texte. Aucun verdict de porte.
