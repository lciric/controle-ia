"""Comptes mécaniques (aucun texte affiché) : motifs d'invalidité, coût à séparateur de milliers en espace."""
import json, re, collections
from pathlib import Path
R = Path("/home/user/controle-ia-travail")
ep = json.load(open(R/"diag/20261012-105125-t05-pilote-reel/episodes.json"))["resultat"]
m = collections.Counter()
for f in ep["fiches"]:
    for h in f["bilan"]["historique"]:
        if not h["valide"]:
            mot = h["motif"] or ""
            m["REVISE sans numéro" if "without a proposal number" in mot else ("ligne ACTION absente" if "no ACTION line" in mot else ("champ manquant" if "missing field" in mot else "autre"))] += 1
print("actions invalides par motif :", dict(m), "total", sum(m.values()))
motif_espace = re.compile(r"\d[   ]\d{3}\b")
n_esp = n_esp_sous = n_props = 0
for f in ep["fiches"]:
    for p in f["bilan"]["propositions"]:
        n_props += 1
        ct = p.get("cout_texte") or ""
        if motif_espace.search(ct):
            n_esp += 1
            if p.get("cout_heures") is not None and p["cout_heures"] < 1000:
                n_esp_sous += 1
print(f"propositions des ensembles finaux : {n_props} ; coût à séparateur en espace : {n_esp} ; dont lu < 1 000 heures : {n_esp_sous}")
