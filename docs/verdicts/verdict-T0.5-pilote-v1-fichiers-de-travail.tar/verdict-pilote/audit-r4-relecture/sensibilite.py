"""Descriptif de relecture (hors critères gelés) : sensibilité de la couverture des familles au seuil de P(oui),
égalités exactes à 0,5, part des « oui » par paire. Aucun texte d'action n'est affiché."""
import json, collections
import numpy as np
from pathlib import Path
R = Path("/home/user/controle-ia-travail")
ep = json.load(open(R/"diag/20261012-105125-t05-pilote-reel/episodes.json"))["resultat"]
app = json.load(open(R/"diag/20261012-105125-t05-pilote-reel/appariements.json"))["resultat"]
tch = {t["identifiant"]: t for t in json.load(open(R/"donnees/t05-pilote-v1/taches-pilote-60-v1.json"))["taches"]}
pa = {a["cle"]: a["p_oui"] for a in app["appariements"]}
en = {a["cle"]: a["p_oui"] for a in app["enonce_seul"]}
allp = np.array(list(pa.values()))
print("paires", len(allp), "P(oui) exactement 0,5 :", int((allp == 0.5).sum()), "; valeurs distinctes :", len(set(allp.round(6))))
def lettre(e):
    return {"e0": "A", "e1": "C", "e2": "D"}[e.split("/")[1]]
fams = ("controls", "fruitful_directions", "sterile_directions")
for seuil, strict in ((0.5, False), (0.5, True), (0.7, False), (0.9, False)):
    par = {f: collections.defaultdict(list) for f in fams}
    for f in ep["fiches"]:
        nums = [p["numero"] for p in f["bilan"]["propositions"]]
        if not nums: continue
        t = tch[f["tache"]]
        for fam in fams:
            cs = t["cibles"][fam]
            if not cs: continue
            ok = lambda v: v > seuil if strict else v >= seuil
            if fam == "sterile_directions":
                val = sum(any(ok(pa[f"{f['episode']}/{n}/{c['id']}"]) for c in cs) for n in nums) / len(nums)
            else:
                val = sum(any(ok(pa[f"{f['episode']}/{n}/{c['id']}"]) for n in nums) for c in cs) / len(cs)
            par[fam][f["tache"]].append(val)
    res = {fam: round(float(np.mean([np.mean(v) for v in par[fam].values()])), 3) for fam in fams}
    resE = {}
    for fam in fams:
        vals = [np.mean([ (en[f"{i}/enonce/{c['id']}"] > seuil if strict else en[f"{i}/enonce/{c['id']}"] >= seuil) for c in t["cibles"][fam]]) for i, t in tch.items() if t["cibles"][fam]]
        resE[fam] = round(float(np.mean(vals)), 3)
    print(f"seuil {'>' if strict else '>='} {seuil} : ensembles {res} ; énoncé seul {resE}")
# part des « oui » par paire, par famille (ensembles A, C, D)
cnt = collections.Counter()
for k, v in pa.items():
    t, e, n, c = k.split("/")
    fam = {"C": "controls", "F": "fruitful_directions", "S": "sterile_directions"}[c[0]]
    cnt[(fam, v >= 0.5)] += 1
for fam in fams:
    print(fam, "part des paires « oui » :", round(cnt[(fam, True)] / (cnt[(fam, True)] + cnt[(fam, False)]), 3))
# corrélation par cible : P(oui) de l'énoncé contre part des ensembles qui la couvrent
for fam in ("fruitful_directions", "controls"):
    xs, ys = [], []
    for f in ep["fiches"]:
        nums = [p["numero"] for p in f["bilan"]["propositions"]]
        t = tch[f["tache"]]
        for c in t["cibles"][fam]:
            xs.append(en[f"{f['tache']}/enonce/{c['id']}"]); ys.append(any(pa[f"{f['episode']}/{n}/{c['id']}"] >= 0.5 for n in nums))
    xs, ys = np.array(xs), np.array(ys)
    print(fam, "couverture si énoncé >= 0,5 :", round(ys[xs >= 0.5].mean(), 3), f"(n={int((xs>=0.5).sum())})", "; si énoncé < 0,5 :", round(ys[xs < 0.5].mean(), 3) if (xs<0.5).any() else None, f"(n={int((xs<0.5).sum())})")
