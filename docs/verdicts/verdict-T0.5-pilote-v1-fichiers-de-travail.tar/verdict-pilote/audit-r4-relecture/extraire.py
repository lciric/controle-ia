"""Extraction, pour chaque action tirée par l'audit R4, de son texte, de sa tâche et des décisions du juge 8B."""
import json, sys
from pathlib import Path
R = Path("/home/user/controle-ia-travail")
SORTIE = Path(sys.argv[1])
lec = json.load(open(R/"diag/20261012-150724-t05-pilote-analyse/lecture.json"))["resultat"]
actions = lec["relectures_audit"]["actions"]
ep = json.load(open(R/"diag/20261012-105125-t05-pilote-reel/episodes.json"))["resultat"]
app = json.load(open(R/"diag/20261012-105125-t05-pilote-reel/appariements.json"))["resultat"]
tch = {t["identifiant"]: t for t in json.load(open(R/"donnees/t05-pilote-v1/taches-pilote-60-v1.json"))["taches"]}
pa = {a["cle"]: a for a in app["appariements"]}
en = {a["cle"]: a for a in app["enonce_seul"]}
fiches = {f["episode"]: f for f in ep["fiches"]}
for i, a in enumerate(actions):
    epi, ap = a.rsplit("/", 1)
    agent, pas = map(int, ap.split(","))
    f = fiches[epi]
    tache = f["tache"]; t = tch[tache]
    act = [x for x in f["actions"] if x["agent"] == agent and x["pas"] == pas][0]
    hist = [h for h in f["bilan"]["historique"] if h["agent"] == agent and h["pas"] == pas]
    props = f["bilan"]["propositions"]
    lignes = [f"# Action {i+1} : {a}", f"tâche {tache} ; jetons de l'action {f['jetons_par_action'][pas]} ; jetons ids {len(act['ids'])}",
              "## Historique de cette action", json.dumps(hist, ensure_ascii=False),
              "## Texte de l'action", act["texte"], "",
              "## Historique complet de l'épisode (opérations seulement)",
              "; ".join(f"pas {h['pas']}: {h['operation']} n°{h['numero']} valide={h['valide']} motif={h['motif']} manquants={h['manquants']}" for h in f["bilan"]["historique"]),
              "## Ensemble final : numéros et pas d'origine, titres",
              ]
    for p in props:
        lignes.append(f"- n°{p['numero']} pas {p['pas']} auteur {p['auteur']} ; coût {p.get('cout_texte')!r}")
    lignes.append("## Propositions de l'ensemble final issues de cette action (pas égal)")
    for p in props:
        if p["pas"] == pas:
            lignes.append(json.dumps(p, ensure_ascii=False, indent=1))
    lignes.append("## Cibles de la tâche, avec P(oui) de l'énoncé seul et P(oui) par proposition de l'ensemble final")
    for fam in ("controls", "fruitful_directions", "sterile_directions"):
        lignes.append(f"### {fam}")
        for c in t["cibles"][fam]:
            e = en[f"{tache}/enonce/{c['id']}"]["p_oui"]
            par = {p["numero"]: round(pa[f"{epi}/{p['numero']}/{c['id']}"]["p_oui"], 3) for p in props}
            couv = any(v >= 0.5 for v in par.values())
            lignes.append(f"- {c['id']} [énoncé {e:.3f}] [couvert par l'ensemble : {couv}] par proposition {par}")
            lignes.append(f"    {c['description']}")
    lignes.append("## Énoncé de la tâche")
    lignes.append(t["questions"])
    (SORTIE/f"action-{i+1:02d}.md").write_text("\n".join(lignes), encoding="utf-8")
print("écrit", len(actions))
