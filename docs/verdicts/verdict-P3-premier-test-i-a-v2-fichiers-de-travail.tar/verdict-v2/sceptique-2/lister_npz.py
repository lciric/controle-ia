import numpy as np
R="/home/user/controle-ia-travail/"
z=np.load(R+"donnees/20261019-230011-p3-reel/scores-p3.npz", allow_pickle=False)
for k in z.files:
    a=z[k]; print(k, a.dtype, a.shape, (a[:3] if a.ndim==1 else a[:1,:3]))
print(np.__version__)
