import json, math, re, numpy as np
R="/home/user/controle-ia-travail/"
raw=open(R+"diag/20261020-220858-addendum2-p3/lecture-addendum2-p3.json").read()
A2=json.loads(raw)["resultat"]
S=np.load(R+"donnees/20261019-230011-p3-reel/scores-p3.npz", allow_pickle=False)
cond=S["condition"]; tache=S["tache"]; cout=S["cout"]
FORMES=["cout_plusieurs_nombres","cout_multiplication","cout_intervalle","cout_suffixe_k","cout_milliers_espace"]
uf=np.zeros(len(cout),bool)
for f in FORMES: uf|=S[f]
lis=np.isfinite(cout)&(cout>0)
# parcours
interdites={"etabli","etablie","conforme","retenue","au_dessus_du_plancher","a_au_dessus_de_b","detecte","presque_detecte"}
trouve=[]; nonfini=[]; t2=[]
def parcours(o,ch="$"):
    if isinstance(o,dict):
        for k,v in o.items():
            if k in interdites: trouve.append(ch+"."+k)
            if re.search(r"\bT2\b",k): t2.append(ch+"."+k)
            parcours(v,ch+"."+k)
    elif isinstance(o,list):
        for i,v in enumerate(o): parcours(v,f"{ch}[{i}]")
    elif isinstance(o,float):
        if not math.isfinite(o): nonfini.append(ch)
    elif isinstance(o,str):
        if re.search(r"\bT2\b",o): t2.append(ch+" = "+o[:80])
parcours(json.loads(raw))
print("clés interdites :", trouve); print("valeurs non finies :", nonfini); print("T2 :", t2)
print("NaN/Infinity littéraux dans le texte brut :", [w for w in ["NaN","Infinity"] if w in raw])
print("presque :", [m.start() for m in re.finditer("presque", raw)][:5])
# tables par tâche
lig=A2["descriptifs"]["B1"]["saboteur-honnete"]["table_par_tache"]["lignes"]
print("exemple de ligne :", json.dumps(lig[0],ensure_ascii=False)[:500])
def stat(c,t,ret=None):
    m=(cond==c)&(tache==t)&lis
    if ret is not None: m&=~ret
    return float(np.mean(np.log10(cout[m]))) if m.any() else None
emax=0; diff_comptes=0; nl=0
for analyse,c in [("B1","saboteur"),("B2","temoin"),("B2","mention")]:
    lig=A2["descriptifs"][analyse][f"{c}-honnete"]["table_par_tache"]["lignes"]
    for l in lig:
        t=l["tache"]; nl+=1
        a0,b0=stat(c,t),stat("honnete",t); asf,bsf=stat(c,t,uf),stat("honnete",t,uf)
        d0=None if a0 is None or b0 is None else a0-b0
        dsf=None if asf is None or bsf is None else asf-bsf
        for nom,mien in [("d_0",d0),("d_sf",dsf)]:
            v=l.get(nom)
            if (v is None)!=(mien is None): diff_comptes+=1; print("écart d'existence",analyse,c,t,nom,v,mien)
            elif v is not None: emax=max(emax,abs(v-mien))
print("lignes comparées :", nl, "; écart max d_0/d_sf :", emax, "; écarts d'existence :", diff_comptes)
