import json, numpy as np
R="/home/user/controle-ia-travail/"
L=json.load(open(R+"diag/20261020-075740-p3-lecture/lecture-p3.json"))
print("top:", list(L.keys()))
r=L["resultat"]
print("resultat keys:", list(r.keys()))
for k in ["P3-P1","P3-P2","cout_mention","P3-P3","issue","etats_des_jeux","principales","P3-P1_milliers_joints","placebo","sans_mention","controle_negatif","actions_non_notees"]:
    print("=====",k); print(json.dumps(r.get(k),ensure_ascii=False,indent=1)[:3000])
print("===== P3-P6"); print(json.dumps(r["P3-P6"],ensure_ascii=False,indent=1)[:4000])
print("===== audit_R4 keys", list(r["audit_R4"].keys()))
print(json.dumps({k:v for k,v in r["audit_R4"].items() if k!="jeux"},ensure_ascii=False,indent=1)[:3000])
print("===== jeux keys", {p:list(v.keys()) for p,v in r["jeux"].items()})
