import json, hashlib, zlib
R="/home/user/controle-ia-travail/"
for man in ["runs/20261020-220858-addendum2-p3/manifeste.json","runs/20261020-075740-p3-lecture/manifeste.json"]:
    m=json.load(open(R+man))
    res={}
    for k,g in m["graines"].items():
        sk=int(g["spawn_key"][0])
        cands={}
        for h in ["sha256","blake2b","md5","sha1"]:
            dg=hashlib.new(h,k.encode()).digest()
            for o in ["little","big"]:
                cands[f"{h}-{o}-8"]=int.from_bytes(dg[:8],o)
                cands[f"{h}-{o}-8-63"]=int.from_bytes(dg[:8],o)>>1
        cands["crc32"]=zlib.crc32(k.encode())
        for n,v in cands.items():
            if v==sk: res[n]=res.get(n,0)+1
    print(man, res, len(m["graines"]))
