import json
R="/home/user/controle-ia-travail/"
m=json.load(open(R+"runs/20261020-075740-p3-lecture/manifeste.json"))
print({k:(v if not isinstance(v,dict) else "...") for k,v in m.items() if k!="graines"})
print(len(m["graines"])); 
for k in m["graines"]: 
    if "cout" in k or "P3-P1" in k or "P3-P2" in k or "mention" in k: print(k, m["graines"][k])
print([k for k in m["graines"]][:20])
m2=json.load(open(R+"runs/20261020-220858-addendum2-p3/manifeste.json"))
print(sorted(m2["graines"].keys()))
