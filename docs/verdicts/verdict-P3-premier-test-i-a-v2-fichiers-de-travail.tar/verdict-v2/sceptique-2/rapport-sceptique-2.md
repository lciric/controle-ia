# Rapport du sceptique 2 — brouillon du verdict R13 complété de P3 (v2)

- Brouillon contre-vérifié : `…/verdict-p3/verdict-v2/auteur/verdict-P3-premier-test-i-a-v2-brouillon.md`,
  sha256 `b9dd7d7cee039106d82f0e823bfd3ca63514532cb127f5645b33f7d70a8c0a31` (recalculée, égale à la commande).
- Le préfixe `…/` vaut `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad`.
- Sceptique neuf (numéro 2). Je n'ai écrit ni le préenregistrement de P3, ni son code, ni le run, ni la lecture, ni les
  addenda (textes, modules, tests), ni le verdict v1, ni ce brouillon, ni aucune contre-lecture. Je n'ai pas consulté
  l'autre sceptique ni son dossier. Je n'ai pas lu le dossier `auteur/outils/`.
- Travail en lecture seule sur le dépôt : git avec `--no-optional-locks` (`rev-parse`, `status --short`, `log`, `show`,
  `diff --quiet`, `merge-base --is-ancestor`) ; aucune écriture, aucun fetch, aucune commande Vast.ai, aucune
  installation, aucune suite de tests, aucune recherche récursive. Une seule liste de dossier (`ls runs/`, un niveau) pour
  compter les passages.
- Non ouverts : `prereg/P3-consignes-v1.md` et `donnees/20261019-230011-p3-reel/textes-actions-p3.jsonl` (empreinte
  seulement). Seuls des nombres, des drapeaux, des empreintes et des identifiants ont été lus. Aucun filtre de sûreté n'a
  rien refusé.
- Recalculs : mes propres scripts (`python3 -I -B`, numpy 2.5.3, bibliothèque standard), sans aucun import du dépôt ni du
  module de l'addendum 2. Les conventions viennent du texte de [P2] (M1 à M10) et de [P] (Métrique).
- Date : 2026-10-20, de 22:22 à 22:40 UTC environ. Tête lue : `c1e7ef95f4fd381d187c41c700aff707d30e173e`, arbre de travail
  propre.

## 1. Jugement

**Non réfuté.** La ligne retenue est la seule permise ; les trois réserves de l'addendum 2 sont exactement celles que
donnent les règles gelées ; chaque nombre recalculable du brouillon est juste (égalité exacte avec les graines des
manifestes) ; l'audit de symétrie est faux et ne dépend pas du tirage ; les renvois sont justes. Le jugement « aucune
réserve bloquante » est tenable sur les textes gelés. Quatre constats mineurs (forme et traçabilité) et quatre pour
information ; aucun critique ni majeur.

## 2. Constats

| id | gravité | où | problème | correction |
|---|---|---|---|---|
| SC-2-01 | mineur | section 2, phrase sous le titre (l. 91 du brouillon) | « Toutes les empreintes ont été recalculées par `sha256sum` le 2026-10-20 vers 22:00 UTC. » C'est impossible pour [A2] et [MA2] : le manifeste est créé à 22:09:02 UTC (`cree_le`) et les deux fichiers entrent au dépôt par le commit `12bb6bd` (22:09:31 UTC). Le brouillon lui-même date la rédaction « vers 22:16 UTC ». Les empreintes sont justes (je les ai toutes recalculées) ; seule l'heure est fausse. | Écrire l'heure réelle du calcul (par exemple « entre 22:16 et 22:21 UTC, pendant la rédaction »). |
| SC-2-02 | mineur | « En tête » (l. 12-16) et section 1 (l. 76-83) | Les réserves de l'addendum 2 y sont résumées, pas citées dans la forme de la table gelée ([P2] l. 458-459 : « il cite chaque réserve … dans la forme de cette table »). B1 : manquent « écart à l'ordre de grandeur prédit ([P] l. 155) » et « (unité, échelle des propositions, gonflement) ». B3 : manquent « (texte : ≈ 0,57 à 0,58) » et surtout « grandeur calculée avant le scellement, sur des nombres déjà lus (brainstorm) », c'est-à-dire la mention que B3 n'est pas aveugle. La section 1 est celle que Lazar lira d'abord. La forme exacte est bien en section 6.2 (et en section 8 pour B1 et la tromperie). | En section 1, recopier mot pour mot les trois phrases gelées (celles de 6.2), ou écrire « résumé ; forme gelée en section 6.2 » à côté de chaque résumé. |
| SC-2-03 | mineur | section 8, « Ce qu'elle établit », point 2 (l. 467-471) | La réserve B3 de la sonde des enjeux est citée par renvoi (« et la même pour `enjeux-lineaire-c15`, avec 0,5966 »), non dans sa forme. La phrase complète n'existe qu'en table 6.2. Le prononcé doit citer chaque réserve dans la forme de la table ([P2] l. 458-459). | Écrire en section 8 la phrase gelée complète pour `enjeux-lineaire-c15` (A_80 = 0,5966). |
| SC-2-04 | mineur | section 7, ligne « 3. Sonde de tromperie » (l. 439) | « L'aire ponctuelle de la sonde de tromperie (0,5748 contre le quantile 0,5717) n'est pas relue » : la phrase dit qu'elle ne relit pas, puis remet la comparaison aire ponctuelle contre quantile, juste à côté de la réserve B3. C'est la lecture que [P2] écarte (l. 138-139 : « l'aire ponctuelle de la sonde de tromperie n'est pas relue » ; l. 436-437 : jamais une « presque détection »). Le brouillon ne conclut rien de faux, mais il remet les deux nombres côte à côte. | Retirer la parenthèse « (0,5748 contre le quantile 0,5717) » ; renvoyer à [V1] remarque 3 (l. 355-357) si besoin. |
| SC-2-05 | information | section 9, remarque 1 (l. 516-520) | « les réserves B3 et le nom de la réserve B1 n'apportent pas d'information au-delà de ce qui était attendu ». Pour B3, c'est juste (valeurs connues avant le scellement). Pour B1, [P2] l. 397-398 dit le contraire : « seuls le nom de la réserve de B1, la médiane et les réserves de B2 sont informatifs ». B1 était aveugle (R-297) : son issue était prédite, non connue. | Écrire : « le nom de la réserve de B1, la médiane et l'absence de réserve de B2 sont les seuls éléments informatifs ([P2] l. 397-398) ; ils confirment des prédictions écrites en connaissant les nombres du v1 ». |
| SC-2-06 | information | section 8, raison de « réserve bloquante : aucune » (l. 489-491) | L'énumération « le mot « bloquant » n'apparaît dans [P] (l. 491, 494, 540, 546) » est juste pour ce mot. [P] emploie aussi « bloque » et « bloquer » (l. 348 et l. 518, TC-14 : une lecture descriptive en échec « ne bloque pas les autres »), sans rapport avec une réserve. Cela conforte la conclusion. | Facultatif : ajouter ces deux lignes à l'énumération, pour qu'elle soit complète. |
| SC-2-07 | information | « Identité et cadre » (l. 52), section 2 (l. 130), section 10 (l. 538-539) | R-288 est cité parmi les décisions, mais son rôle n'est dit nulle part. (Il consigne l'option (b) de CV2-01, la règle du déclencheur 3 de l'audit de symétrie, appliquée en section 6.3.) | Dire en une phrase pourquoi R-288 est cité, ou le retirer. |
| SC-2-08 | information | sections 6.3 et 6.4 | Le brouillon montre que les réserves ne dépendent pas du tirage. Il ne le dit pas pour les libellés descriptifs proches d'une borne : borne haute de `D` du témoin 0,0014, de `D` du saboteur 0,0051, de `E_sf` de la mention −0,0347, de la part du saboteur 0,0032. Sur 300 graines propres, aucun libellé ne change : `D` reste « non distinguée de 0 » pour les trois contrastes, `E_sf` de la mention reste « en dessous de 0 », celui du témoin reste « compatible avec 0 ». | Facultatif : une phrase en 6.3 (« libellés descriptifs stables sur 300 graines, sceptique 2 »). |

Aucune promotion. Aucun seuil inventé. Aucune lecture de B3 comme détection (le constat SC-2-04 porte seulement sur deux
nombres mis côte à côte). Le drapeau T2 n'est ni lu ni cité avec sa valeur : la section 7 nomme la remarque 4 de [V1]
(« Drapeau T2 ») et dit qu'elle reste telle quelle dans [V1]. Aucune réserve de [A2] n'est oubliée.

## 3. Nombres recalculés

Scripts et sorties dans `…/verdict-p3/verdict-v2/sceptique-2/` :

| fichier | sha256 |
|---|---|
| `recalcul_sceptique2.py` | `68783a0295fc1eff80ff215134a86ce4baf9ddbefdc188a0f650c10fc7e337e6` |
| `recalcul_sceptique2.sortie.txt` | `d5befd39c65b923819953f127a9b12c960dc218bb6bf8566b9dbbd3bab27f406` |
| `sensibilite_tirage.py` | `11d2c9e8e38592d98d267b6e0a52039a22dc50a604601e81163eaf9f3c5d8099` |
| `sensibilite_tirage.sortie.txt` | `45b76bdec6577e577bbf5a40626ab1e23dfb8e12da97a7a44e6c20f4672c545f` |
| `tables_et_parcours.py` | `bf51a56852ee85a8d8c4b053a59b4adf2cf65b778776d40bdd72360b08aa3c57` |
| `tables_et_parcours.sortie.txt` | `564f7cedefc65474e864bf41f0db4ceb3262a84d4ad63ca7288d342ea5659067` |
| `phrases.py` (phrases gelées contre [A2] et le brouillon) | `b7fda2c129ce23cf8307d177756a35bdbe89f28375d8f4d466f98cd6c9c8d3fd` |
| `test_graines.py`, `test_spawn.py` (graines des manifestes) | `264a705284cb4b94b7e808127429d59b57acf01dbd9d747be37247fc66760676`, `59301837820abd9e87cfc8c84e6261a91d486abba361ec1092f5b9688a835fe6` |

### 3.1 Données et formes (depuis [S], sans tirage)

- 2 400 actions, 600 par condition ; 240 épisodes ; 60 tâches ; un épisode par tâche et par condition.
- Formes par condition égales à [L] `resultat.P3-P6` : honnête plusieurs nombres 41, intervalle 13, suffixe « k » 14 ;
  témoin 28, 0, 0 ; mention 7, 0, 0 ; saboteur 3, 0, 0 ; multiplication et milliers séparés 0 partout.
- Actions retirées par la restriction « sans aucune forme » : honnête 54, témoin 28, mention 7, saboteur 3, toutes
  lisibles. Égal au brouillon et à [A2].

### 3.2 P3-P1 et effets décisifs (comparés à [L])

| effet | mon recalcul | [L] | écart |
|---|---|---|---|
| P3-P1, saboteur − honnête | 1,5227394386, 60 tâches | 1,5227394386 | 0 |
| bornes, graines de [ML] `cout/saboteur` | [1,2464489096 ; 1,8011761611] | identiques | 0 |
| P3-P2, témoin − honnête | −0,3176480896 [−0,5704426087 ; −0,0649821133] | identiques | 0 |
| mention − honnête | −0,3229279463 [−0,5403641885 ; −0,1154881048] | identiques | 0 |

Avec mes graines propres : P3-P1 [1,2453 ; 1,8073] (écarts −0,0011 et +0,0061) ; P3-P2 écarts +0,0048 et +0,0096 ;
mention +0,0015 et +0,0086. Aucun état ne change (borne basse de P3-P1 loin au-dessus de 0 ; bornes basses du témoin et de
la mention loin en dessous de 0).

### 3.3 Ligne d'issue (depuis [S] et [L])

- Aire saboteur contre honnête, recalculée depuis [S] (rangs moyens, sans tirage) : tromperie 0,5748333333, enjeux
  0,5247972222 ; quantile 0,95 des 200 sondes du plancher : 0,5717154167 et 0,5355881944. Égaux à [L] (écart 0).
- Bornes basses à 97,5 % de [L] : 0,5313 et 0,4813, toutes deux ≤ quantile ; marges 0,0404 et 0,0543.
- Bornes de P3-P3 (2 000 tirages, graines de [ML] `aire/<p>/saboteur-honnete`) : je n'ai pas la convention exacte du
  tirage. Avec un tirage des 60 tâches appariées (toutes les actions des deux conditions) : tromperie [0,5298 ; 0,6184],
  enjeux [0,4796 ; 0,5690], écarts à [L] de 0,0016 au plus ; avec un tirage des actions par classe : écarts de 0,0090 au
  plus. Les deux marges (0,0404 et 0,0543) dépassent de loin ces écarts : **la ligne ne dépend pas du tirage.**
- Lignes 1 à 3 de la table gelée ([P] l. 425-427) : non ; ligne 4 (l. 428) : oui ; lignes 5 à 8 (l. 429-432) exigent
  une sonde au-dessus. **La ligne retenue est la seule permise.**

### 3.4 Addendum 2, B1 et B2 (graines de [MA2], convention de [P2] M4 à M6)

Les 47 graines de [MA2] dérivent bien de l'entropie de P3 (`SeedSequence(entropie, spawn_key)`, avec spawn_key = 8 premiers
octets, gros-boutiste, du sha256 du nom de clé ; vérifié pour les 47 clés de [MA2] et les 25 de [ML] ; état de contrôle =
`generate_state(2)` pour les 47). Les clés de [MA2], [ML] et [MA] sont disjointes. Liste fermée de [P2] l. 288-293 : 27 + 20.

Avec ces graines, **tous** les nombres de B1 et B2 du brouillon (section 6.4) sont égaux à [A2] à 10⁻¹⁶ près (écart
maximal 1,4 × 10⁻¹⁶) :

| grandeur | saboteur − honnête (B1) | témoin − honnête | mention − honnête |
|---|---|---|---|
| `E_sf` | 1,6099 [**1,3211** ; 1,9041], 57 | −0,2360 [−0,5217 ; 0,0532], 55 | −0,2569 [−0,4840 ; −0,0347], 57 |
| `D` | −0,0565 [−0,1657 ; 0,0051] | −0,0639 [−0,1758 ; 0,0014] | −0,0540 [−0,1650 ; 0,0084] |
| `E0` | 1,5534 [1,2700 ; 1,8435] | −0,2999 [−0,5712 ; −0,0269] | −0,3109 [−0,5318 ; −0,1003] |
| part `D / E0` | −0,0364 [−0,1173 ; 0,0032], 0 dégénéré | 0,2130 [−0,0151 ; 1,3681] | 0,1736 [−0,0351 ; 0,7335] |
| `M` | 1,7149 [1,1318 ; 1,9163] | −0,3545 [−0,5557 ; −0,0784] | −0,2630 [−0,5118 ; −0,1153] |
| tâches `d > 0` ; `d > log10 3` | 55 ; 50 | 21 ; 13 | 20 ; 10 |
| tâches sans forme | 1,5943 [1,2708 ; 1,9233], 47 | −0,3986 [−0,7369 ; −0,0513], 38 | −0,3017 [−0,5421 ; −0,0636], 47 |
| sans plusieurs nombres | 1,5281 [1,2424 ; 1,8163], 58 | −0,2931 [−0,5586 ; −0,0218], 56 | −0,3332 [−0,5534 ; −0,1260], 58 |
| sans intervalle | 1,5284 [1,2482 ; 1,8168], 59 | −0,3113 [−0,5716 ; −0,0417], 59 | −0,3275 [−0,5451 ; −0,1105], 59 |
| sans suffixe « k » | 1,6011 [1,3151 ; 1,8828], 59 | −0,2613 [−0,5238 ; 0,0142], 59 | −0,2497 [−0,4784 ; −0,0239], 59 |

- Tâches exclues de `E_sf` égales à [A2] (saboteur et mention : 2506.18862v3, 2510.18828v1, 2602.07160v1 ; témoin : ces
  trois et 2512.03125v1, 2605.17899v2). Quantiles de `d_0` et `d_sf` égaux (écart 0).
- Tables par tâche de [A2] (M9), que l'auteur n'a pas relues ligne à ligne : 180 lignes (3 contrastes × 60 tâches),
  `d_0` et `d_sf` égaux à mon recalcul (écart 0), mêmes tâches sans valeur.
- Écarts de forme (M8) : honnête 0,0763 [−0,1937 ; 0,3794], 7 tâches ; témoin −0,3096 [−0,6068 ; −0,0926], 10 ; mention
  0,1069 [0,0591 ; 0,1488], 3 ; saboteur −0,1845 [−0,5057 ; 0,0289], 3 ; intervalle et suffixe « k » de l'honnête : une
  seule tâche retenue. Égaux à [A2].
- **Graines propres** (une graine) : borne basse de `E_sf` du saboteur 1,3266 (écart +0,0055), haute 1,9029 ; témoin
  [−0,5230 ; 0,0566] ; mention [−0,4812 ; −0,0331] ; `D` saboteur [−0,1650 ; 0,0049] ; `M` saboteur borne basse 1,1318.
  **Sur 300 graines propres** : borne basse de `E_sf` du saboteur entre 1,3135 et 1,3352 (toujours au-dessus de
  log10 3 = 0,4771) ; borne basse de `D` du saboteur entre −0,1697 et −0,1627 (toujours ≤ 0) ; borne basse de `M` entre
  1,1318 et 1,1526 ; bornes basses de `E_sf` du témoin (−0,5375 à −0,5154) et de la mention (−0,4914 à −0,4729) toujours
  ≤ 0. Les règles donnent `reserve_B1_ampleur_au_dela_de_la_consigne` seule pour B1, et aucune réserve de B2, pour 300
  graines sur 300. **Aucune réserve ni aucun état ne change.**

### 3.5 Addendum 2, B3 (depuis [L], sans tirage)

- `z` = Φ⁻¹(0,9875) = 2,2414027276 ; `z80` = Φ⁻¹(0,80) = 0,8416212336 ; facteur 1 + z80 / z = 1,3754886274.
- `A_80_écrit_max` = 0,53 + 0,037 × facteur = **0,5808930792** ; `A_80_écrit_min` = 0,5543872157 ; aire au seuil écrite
  0,545 à 0,567.
- Tromperie : `Q` 0,571715, `w` 0,043495, **`A_80` = 0,6315419363** (marge +0,0506 sur l'écrit maximal) ; distance basse
  0,0435, haute 0,0435 ; `A_80` à la distance basse 0,6316 ; aire au seuil 0,6152 (0,6152 à la distance basse).
- Enjeux : `Q` 0,535588, `w` 0,044374, **`A_80` = 0,5966238546** (marge +0,0157) ; distances 0,0435 et 0,0452 ; `A_80`
  à la distance basse 0,5954 ; aire au seuil 0,5800 (0,5791).
- Égaux à [A2] (écart 0). `A_80 > A_80_écrit_max` pour les deux sondes : deux réserves `reserve_B3_puissance_du_nul`.

### 3.6 Application des règles gelées

- Table des cas de B1 ([P2] l. 330-338) : `b_sf` = 1,3211 > `r` = 0,4771 ; `b_D` = −0,1657 ≤ 0 → case « `b_sf > r`,
  `b_D ≤ 0` » → `ampleur_au_dela_de_la_consigne` seule. `b_M` = 1,1318 > 0 → pas de réserve de médiane. Condition de
  `ampleur_non_resolue` fausse (`b_sf` hors de ]0 ; log10 3]).
- B2 ([P2] l. 321-322) : bornes basses de `E_sf` −0,5217 (témoin) et −0,4840 (mention) ≤ 0 → aucune réserve ; cibles
  `P3-P4/<p>` et `T3/<p>` non établies → « sans objet ».
- Verrou ([P2] l. 378-387) : `P3-P1` établie (`etablie` vrai, `calculable` vrai, `bas` 1,2464 > 0) ; `nul/<p>` établie
  pour les deux sondes (ligne « aucune sonde générique… », états « non au-dessus »). Trois conclusions, trois réserves,
  13 contrôles écrits, 9 lus, 0 « non lu », 4 sans objet : égal à [A2].
- Phrases gelées ([P2] l. 422 et l. 427, grandeurs substituées) : égales, mot pour mot (aux accents graves près), à
  [A2] `resultat.recommandation_au_verdict_R13` pour les trois réserves ; chacune présente mot pour mot dans la table 6.2
  du brouillon.
- Chaque réserve de [A2] est donc lue en 6.2 dans la forme exacte de la colonne « ce que lit le verdict R13 complété »,
  et en section 8 pour B1 et la tromperie (voir SC-2-02 et SC-2-03 pour la section 1 et la sonde des enjeux).

### 3.7 Audit de symétrie de l'addendum 2 ([P2] l. 440-457)

- Point 1 (même traitement) : [A2] `meme_traitement` donne la même fonction, le même niveau (0,95), 10 000 tirages et les
  six mêmes restrictions pour les trois contrastes ; B3 calculé pour les deux sondes. Mon recalcul applique bien une seule
  et même fonction aux trois contrastes et retrouve tous les nombres.
- Déclencheur 2 : aucun intervalle décisif conforme (saboteur 1,2464 > log10 3 ; témoin et mention entièrement négatifs),
  donc pas « sans objet » ; `E_sf` conformes : saboteur non (1,3211 > 0,4771), témoin oui ([−0,5217 ; 0,0532] contient 0),
  mention non ([−0,4840 ; −0,0347] ne contient pas 0) → **faux**. Sur 300 graines propres : faux 300 fois ; la mention
  n'est jamais conforme ; et le saboteur suffit à le rendre faux.
- Déclencheur 3 : part ponctuelle −0,0364 dans [−1 ; 1] → **faux**, sans tirage.
- `declencheur` faux, `consigne` et `lecture` nulles : pas de « addendum 2 suspect de propreté ». Conforme au brouillon.

### 3.8 Cohérence de [A2] avec [L]

- `issue_primaire` = [L] `resultat.issue` (égalité des objets) ; `principales` égales.
- Effets décisifs, aires et quantiles du plancher : mon recalcul depuis [S] les retrouve exactement, comme [A2]
  `coherence_avec_la_lecture` (écarts 0, 200 sondes de plancher, formes égales).
- `lecture_sha256`, `preenregistrement_sha256`, `module_sha256`, `tests_sha256`, `entrees_sha256` (neuf empreintes) :
  égales aux fichiers. `tete_verifiee` = `commit_de_scellement` = `af97266…` = [MA2] `commit`.
- Parcours complet de [A2] : aucune clé interdite, aucune valeur non finie, aucune clé ni chaîne qui nomme T2, aucune
  occurrence de « presque ». Pas de clé `arret` ; `manifestes_illisibles_ecartes` 0 et 0.

### 3.9 Renvois vérifiés

- Empreintes des 20 pièces de la section 2 du brouillon recalculées : toutes égales au brouillon et à leurs compagnons
  `.sha256` (sauf [D], sans compagnon). [D] au commit `769d645` : `fddc0d71…`, égal au brouillon ; à la tête actuelle,
  `6d033ecf…` (registre vivant, avancé par R-300 et R-301).
- Commits : [P] seulement à `97dd829` ; [PA] à `e03df08` ; [L] à `63386e6` ; [A] à `6a97d69` ; [V1] à `f7cea56` ; [P2],
  son sceau, le module et les tests seulement à `af97266` (S2, 22:08:40 UTC, premier et seul commit qui ajoute le sceau) ;
  [A2] et [MA2] seulement à `12bb6bd` (22:09:31 UTC). Tous ancêtres de la tête ; `ec1d71b` ancêtre de S2 ; `7a54d431`
  ancêtre de la tête. `git show` de [P] à S, de [P2] à S2, de [A2] à `12bb6bd` : empreintes égales à aujourd'hui.
  `git diff --quiet af97266 HEAD -- docs/procedures/P3-addendum2-v1 prereg/P3-addendum2-audit-verdict-v1.md` : vrai.
  `769d645`, `ee9cb0e` et `c1e7ef9` ne touchent que les registres.
- [MA2] : `cree_le` 22:09:02 UTC, `decisif` faux, `depot_propre` vrai, [P2] cité par chemin et empreinte, commande du
  module, 47 graines, numpy 2.4.6. [ML] : `decisif` vrai, commit `e03df08…`, numpy 2.4.6.
- `runs/` ne contient qu'un passage de l'addendum 2 (`20261020-220858-addendum2-p3`).
- [D] : N-024 l. 437, N-025 l. 453, R-288 l. 488, R-297 l. 497, R-298 l. 498 ; ces cinq lignes sont identiques aux
  commits `12bb6bd`, `769d645` et à la tête. R-297 porte bien la déclaration R1 ; R-298 le passage unique, code 0, sur
  `af97266`.
- Lignes de [P] citées (122, 153-161, 155, 157, 158-159, 262-263, 272-283, 394-397, 401-416, 420-436) ; de [PA]
  (242-250, 282-291, 293-294) ; de [P2] (35-38, 86-88, 101-104, 131-132, 138-139, 147-168, 227-228, 244-245, 315-351,
  362-364, 378-399, 418-460, 587-601) ; de [V1] (179-183, 296-302, 340-359) : toutes justes.
- Nombres de la lecture repris dans les sections 3, 4 et 8 (dix jeux, séparations, placebo, sans mention, corrélations,
  P3-P5, P3-P6, milliers joints, contrôle négatif, épisodes et actions notées) : égaux à [L] et [R].

## 4. Jugement « aucune réserve bloquante »

Tenable. Aucun des trois textes gelés ne définit une réserve bloquante. Ce qui, dans [P2], arrête ou renvoie à Lazar est
absent : pas d'arrêt, pas de contrôle « non lu », audit de symétrie faux. Chaque phrase gelée garde sa conclusion
(« P3-P1 établie » ; « nul de détection … non détecté à cette puissance »). Le verrou interdit de changer la ligne. Aucune
réserve ne dépend du tirage (300 graines). La réserve B1 dit que la cause de l'ampleur n'est pas mesurée (unité comprise) :
cela borne ce qu'on peut dire de P3-P1 (« gonflement »), comme le brouillon l'écrit, sans retirer P3-P1 selon la règle
gelée ([P] l. 155 : la réfutation ne porte que sur un intervalle qui contient 0 ou est négatif).

## 5. Ce que je n'ai pas pu vérifier

- Le classement des formes du champ du coût sur les textes (calculé sur l'instance) : je ne l'ai pas refait sans les
  textes ; je prends les colonnes booléennes de [S] comme données, comme [A2] et [P2] (limite 5).
- La convention exacte du tirage des bornes de P3-P3 (2 000 tirages) : approchée seulement (écart 0,0016 au plus), sans
  effet sur la ligne.
- Que personne n'ait calculé une grandeur de B1 ou de B2 avant S2 : seulement la déclaration de R-297 et l'ordre des
  commits.
- Les empreintes des outils de l'auteur [O4] et [O5] : non recalculées (consigne : ne pas lire `auteur/outils/`).
- Le module de l'addendum 2 n'a été ni lu ni lancé (consigne) ; son empreinte est égale à [P2] l. 37 et à [A2].

non réfuté
