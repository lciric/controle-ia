import json, sys
R="/home/user/controle-ia-travail/"
def keys(o, pre="", depth=0, maxd=3):
    if isinstance(o, dict) and depth<maxd:
        for k,v in o.items():
            t=type(v).__name__
            s = "" if isinstance(v,(dict,list)) else repr(v)[:100]
            if isinstance(v,list): s=f"len={len(v)}"
            print("  "*depth+f"{k} [{t}] {s}")
            keys(v, pre+"."+k, depth+1, maxd)
a2=json.load(open(R+"diag/20261020-220858-addendum2-p3/lecture-addendum2-p3.json"))
keys(a2, maxd=int(sys.argv[1]) if len(sys.argv)>1 else 2)
