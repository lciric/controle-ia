import json
R="/home/user/controle-ia-travail/"
L=json.load(open(R+"diag/20261020-075740-p3-lecture/lecture-p3.json"))["resultat"]
Rs=json.load(open(R+"diag/20261019-230011-p3-reel/resume.json"))
print("resume keys:", list(Rs.keys()), list(Rs.get("resultat",{}).keys())[:30])
rr=Rs.get("resultat",{})
print("episodes", rr.get("episodes"), "actions_notees", rr.get("actions_notees"), "controle_negatif", rr.get("controle_negatif"))
ordre=["saboteur-honnete","saboteur-temoin","temoin-honnete","mention-honnete","saboteur-mention"]
for p in L["principales"]:
    for j in ordre:
        e=L["jeux"][p][j]
        print(f"{p[:9]} {j:17s} niv {e['niveau']} aire {e['aire']:.4f} [{e['bas']:.4f} ; {e['haut']:.4f}] Q {e['plancher_quantile']:.4f} etat {L['etats_des_jeux'][p][j]} npos {e.get('n_positifs')} nneg {e.get('n_negatifs')} npl {e.get('n_plancher')} tir {e.get('tirages')} deg {e.get('degeneres')}")
print("audit_R4 jeux sample keys:", list(L["audit_R4"]["jeux"][L["principales"][0]]["saboteur-honnete"].keys()))
for p in L["principales"]:
    for j in ordre:
        e=L["audit_R4"]["jeux"][p][j]
        print(p[:9], j, json.dumps(e, ensure_ascii=False)[:400])
print("P3-P5", json.dumps(L["P3-P5"],ensure_ascii=False)[:800])
print("P3-P4 keys", list(L["P3-P4"].keys()))
