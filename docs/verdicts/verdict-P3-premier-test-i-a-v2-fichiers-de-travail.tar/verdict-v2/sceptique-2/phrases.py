import json, re
R="/home/user/controle-ia-travail/"
P2=open(R+"prereg/P3-addendum2-audit-verdict-v1.md").read().split("\n")
A2=json.load(open(R+"diag/20261020-220858-addendum2-p3/lecture-addendum2-p3.json"))["resultat"]
V=open("/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-p3/verdict-v2/auteur/verdict-P3-premier-test-i-a-v2-brouillon.md").read()
def guill(l):
    m=re.search(r"« (.*?) »(?: ;|$| \|)", l)
    i=l.index("« "); j=l.rindex(" »", 0, l.index(" »", i)+2) 
    # premier « ... » de la colonne de lecture, jusqu'au » qui le ferme (gère les guillemets imbriqués absents)
    s=l.split("| ",2)[2]
    a=s.index("« ")+2
    # fermer au premier « » » suivi de ' ;' ou ' |'
    k=a; prof=1
    while prof:
        n1=s.find("« ",k); n2=s.find(" »",k)
        if n1!=-1 and n1<n2: prof+=1; k=n1+2
        else: prof-=1; k=n2+2
    return s[a:k-2]
b1=guill(P2[421]); b3=guill(P2[426])
print("P2 l.422:", b1[:120]); print("P2 l.427:", b3[:120])
rec={r["conclusion"]:r["lecture"] for r in A2["recommandation_au_verdict_R13"]}
att_b1=b1.replace("(borne basse de `E_sf`)","(borne basse de `E_sf` = 1,3211)")
for p,a80 in [("tromperie-difference_moyennes-c15","0,6315"),("enjeux-lineaire-c15","0,5966")]:
    att=b3.replace("`<p>`","`"+p+"`").replace("`A_80(p)`",a80).replace("`A_80_écrit_max`","0,5809")
    print(p, "A2 = P2 substituée (sans accents graves) :", rec["nul/"+p]==att.replace("`",""), "; présente mot pour mot dans le brouillon :", V.count(att))
print("B1 A2 = P2 substituée :", rec["P3-P1"]==att_b1.replace("`",""), "; présente dans le brouillon :", V.count(att_b1))
