import json
R="/home/user/controle-ia-travail/"
m=json.load(open(R+"runs/20261020-220858-addendum2-p3/manifeste.json"))
def show(o,d=0):
    for k,v in o.items():
        if isinstance(v,dict):
            print("  "*d+k+":"); 
            if k=="graines":
                ks=list(v.keys()); print("  "*(d+1)+f"{len(ks)} clés ; ex. {ks[0]} -> {json.dumps(v[ks[0]])[:300]}")
            else: show(v,d+1)
        elif isinstance(v,list):
            print("  "*d+f"{k}: liste {len(v)} : {json.dumps(v,ensure_ascii=False)[:300]}")
        else: print("  "*d+f"{k}: {str(v)[:200]}")
show(m)
