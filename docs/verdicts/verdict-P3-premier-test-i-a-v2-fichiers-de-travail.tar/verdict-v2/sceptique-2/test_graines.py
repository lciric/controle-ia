import json, numpy as np
R="/home/user/controle-ia-travail/"
m=json.load(open(R+"runs/20261020-220858-addendum2-p3/manifeste.json"))
ok=0
for k,g in m["graines"].items():
    ss=np.random.SeedSequence(int(g["entropie"]), spawn_key=tuple(int(x) for x in g["spawn_key"]))
    st=ss.generate_state(2).tolist()
    ok+= (st==g["etat_controle"])
print("etat_controle = generate_state(2) pour", ok, "clés sur", len(m["graines"]))
