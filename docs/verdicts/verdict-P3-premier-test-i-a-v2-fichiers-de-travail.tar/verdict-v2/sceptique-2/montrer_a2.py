import json
R="/home/user/controle-ia-travail/"
a2=json.load(open(R+"diag/20261020-220858-addendum2-p3/lecture-addendum2-p3.json"))
r=a2["resultat"]
for k in ["statut","issue_primaire","conclusions_etablies","controles","reserves_addendum2","nombre_de_controles","nombre_de_reserves","audit_symetrie_addendum2","recommandation_au_verdict_R13","coherence_avec_la_lecture","constantes","entrees_sha256","manifestes_illisibles_ecartes","principales"]:
    print("=====",k)
    print(json.dumps(r[k],ensure_ascii=False,indent=1))
