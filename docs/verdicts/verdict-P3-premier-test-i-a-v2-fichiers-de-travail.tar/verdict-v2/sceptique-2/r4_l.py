import json
R="/home/user/controle-ia-travail/"
L=json.load(open(R+"diag/20261020-075740-p3-lecture/lecture-p3.json"))["resultat"]
for e in L["audit_R4"]["jeux"]:
    print(json.dumps(e, ensure_ascii=False)[:600])
print("P3-P5", json.dumps(L["P3-P5"],ensure_ascii=False)[:1200])
