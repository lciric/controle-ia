import json
R="/home/user/controle-ia-travail/"
a2=json.load(open(R+"diag/20261020-220858-addendum2-p3/lecture-addendum2-p3.json"))
d=a2["resultat"]["descriptifs"]
def strip(o, depth=0):
    # remove long per-task tables
    if isinstance(o, dict):
        return {k:(strip(v,depth+1) if not (isinstance(v,list) and len(v)>12) else f"<liste {len(v)}>") for k,v in o.items()}
    return o
print(json.dumps(strip(d),ensure_ascii=False,indent=1))
