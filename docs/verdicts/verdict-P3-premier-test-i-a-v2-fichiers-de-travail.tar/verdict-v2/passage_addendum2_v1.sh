#!/usr/bin/env bash
# Passage unique de l'addendum 2 de P3 (plan d'analyse, points 1 et 2) : arbre propre, dépôt complet, texte scellé,
# commit de scellement dans l'histoire de HEAD ; journaux dans le bloc-notes ; la session relit avant de committer.
set -euo pipefail
D=/home/user/controle-ia-travail
PY=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/scellement-revalidation/venv-gpu-neuf/bin/python
J=/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-p3/verdict-v2
P=prereg/P3-addendum2-audit-verdict-v1.md
cd "$D"
[ -z "$(git status --porcelain)" ] || { echo "ARRÊT : arbre de travail sale"; exit 1; }
[ "$(git rev-parse --is-shallow-repository)" = "false" ] || { echo "ARRÊT : dépôt superficiel"; exit 1; }
[ -f "$P.sha256" ] || { echo "ARRÊT : addendum 2 non scellé"; exit 1; }
S2=$(git log --diff-filter=A --format=%H -- "$P.sha256" | tail -1)
[ -n "$S2" ] && git merge-base --is-ancestor "$S2" HEAD || { echo "ARRÊT : commit de scellement hors de l'histoire de HEAD"; exit 1; }
for x in runs diag; do ls -d "$x"/*-addendum2-p3 2>/dev/null && { echo "ARRÊT : un passage de l'addendum 2 existe déjà ($x)"; exit 1; }; done
A="$(date -u +%Y%m%d-%H%M%S)-addendum2-p3"
echo "S2 $S2 ; HEAD $(git rev-parse HEAD) ; passage $A (début $(date -u +%H:%M:%S))"
PYTHONPATH=src "$PY" -B docs/procedures/P3-addendum2-v1/audit_verdict_p3_v1.py --run-source 20261019-230011-p3-reel \
  --lecture 20261020-075740-p3-lecture --run-addendum2 "$A" --prereg "$P" \
  --entropie 173398867739501636779144561928402532101 > "$J/addendum2-$A.sortie.txt" 2> "$J/addendum2-$A.erreurs.txt" && rc=0 || rc=$?
echo "code $rc ; fin $(date -u +%H:%M:%S) ; passage $A"
git status --short | head -20
