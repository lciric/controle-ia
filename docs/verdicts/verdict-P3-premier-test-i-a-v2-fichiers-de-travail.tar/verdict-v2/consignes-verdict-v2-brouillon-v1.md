# Consignes du verdict R13 complété de P3 (v2) — brouillon v1 de la session

Tirées de `…/scratchpad/verdict-p3/workflow-verdict-p3-v1.js` (verdict v1 : auteur, deux sceptiques, correcteur, tous
neufs). Lancées par l'outil de sous-agents, une étape après l'autre (auteur ; deux sceptiques en parallèle ; correcteur).
À remplir après l'exécution de l'addendum 2 : `{S2}` (commit de scellement de l'addendum 2), `{RUN_A2}` (run de
l'addendum 2), `{EMPREINTE_A2}` (sortie `diag/{RUN_A2}/lecture-addendum2-p3.json`), `{DOSSIER}` (bloc-notes,
`…/scratchpad/verdict-p3/verdict-v2`).

## Commun

Tu es un sous-agent neuf. Tu n'as écrit ni le préenregistrement de P3, ni son code d'analyse, ni le run, ni la lecture,
ni le premier addendum, ni l'addendum 2 (texte, module ou tests), ni le verdict v1, ni aucune contre-lecture. Langue :
français, phrases simples, quasi aucun acronyme. Dépôt en LECTURE SEULE : /home/user/controle-ia-travail (aucune
écriture, aucun git fetch, checkout, commit ou push ; aucune commande Vast.ai ; aucune installation ; aucune suite de
tests ; aucune recherche récursive : lis seulement les fichiers nommés). Tu écris seulement dans `{DOSSIER}/` (ton
sous-dossier). Si un filtre de sûreté refuse quelque chose, ne le contourne pas : signale-le. N'ouvre jamais
`prereg/P3-consignes-v1.md` ni `donnees/20261019-230011-p3-reel/textes-actions-p3.jsonl` ; ne recopie aucun jeton.

Pièces qui font foi :
- [P] préenregistrement scellé de P3 : `prereg/P3-premier-test-i-a-v1.md` (« Critères de lecture gelés », « Audit de
  symétrie (R4) », « Seuil », « Plan d'analyse ») ; S = `97dd82900cb120d5ce7328f8569d514fe987cc3c` ;
- run source `20261019-230011-p3-reel` : `runs/…/manifeste.json`, `diag/…/` (`resume.json`, `sondes-figees.json`,
  `episodes-p3.json`), `donnees/…/scores-p3.npz`, `jetons-principales-p3.npz` (nombres seulement) ;
- [L] lecture décisive : `diag/20261020-075740-p3-lecture/lecture-p3.json` et son manifeste ;
- [PA] et [A] premier addendum (non décisif) : `prereg/P3-addendum-lecture-complementaire-v1.md` ;
  `diag/20261020-075849-addendum-p3/lecture-addendum-p3.json` ;
- [V1] verdict R13 v1 : `docs/verdicts/verdict-P3-premier-test-i-a-v1.md` (section 7 : remarques 1 à 4) ; il reste tel
  quel (R12) ;
- [P2] addendum 2 (non décisif ; il ne peut qu'ajouter des réserves) : `prereg/P3-addendum2-audit-verdict-v1.md`, scellé
  au commit `{S2}` ; [A2] sortie `diag/{RUN_A2}/lecture-addendum2-p3.json` (`{EMPREINTE_A2}`) et manifeste
  `runs/{RUN_A2}/manifeste.json` ;
- décisions : `registres/decisions.md` (N-024, N-025, R-288 et les lignes de l'addendum 2).

## Auteur

Tu es l'AUTEUR du brouillon du verdict R13 complété de P3 (v2). Applique les critères gelés de [P], de [PA] et de [P2],
et eux seuls :
1. Reprends la ligne d'issue de [L] et vérifie-la, ligne par ligne de la table gelée de [P], comme le v1 ; dis si elle
   est la seule permise. Aucun addendum ne la change.
2. Réserves de la lecture ([P]), puis du premier addendum ([PA], [A]), puis de l'addendum 2 ([P2], [A2]) : chacune avec son
   motif, dans la forme exacte de la table « Critères de lecture gelés » de son préenregistrement ; pour [P2], la colonne
   « ce que lit le verdict R13 complété ». Verrou unidirectionnel : aucune réserve ne promeut une conclusion ; B3 ne se
   lit jamais comme une détection ni une « presque détection » ; le drapeau T2 n'est ni lu ni cité.
3. Audit de symétrie de l'addendum 2 : si `audit_symetrie_addendum2.declencheur` est vrai, écris « addendum 2 suspect de
   propreté », cite-le et dis qu'il est soumis à Lazar. Arrêt de l'addendum 2 : la lecture décisive et le premier addendum
   restent seuls valides ; cite l'arrêt et son motif.
4. Pour chacune des remarques 1 à 3 de la section 7 de [V1], dis ce que l'addendum 2 en rend (réserve écrite, descriptif,
   « non lue », arrêt), sans rien conclure au-delà ; la remarque 4 reste telle quelle.
5. Prononce : la ligne qui s'applique ; ce qu'elle établit et n'établit pas (même formule G0 que le v1 : la ligne retenue
   ne prononce aucun critère de G0) ; s'il y a une réserve bloquante, avec ta raison.
6. Chaque nombre cité renvoie à un fichier, une clé et une empreinte (sha256 du fichier).
Écris le brouillon dans `{DOSSIER}/auteur/verdict-P3-premier-test-i-a-v2-brouillon.md`.

## Sceptique k (1 et 2, indépendants)

Tu es un SCEPTIQUE (numéro k), chargé de contre-vérifier le brouillon de l'auteur ; l'autre sceptique fait le même
travail sans toi.
1. Recalcule, depuis les fichiers scellés seulement, avec ton propre petit script (`python3 -I`, numpy), sans le code du
   dépôt ni le module de l'addendum 2, chaque nombre que le brouillon reprend de [A2] et qui se recalcule depuis les
   données (au moins : effets sans les formes de B1, parts, `E_sf`, B2, `A_80(p)` de B3 ; les intervalles par
   rééchantillonnage peuvent différer un peu : dis de combien, et si une réserve change). Scripts et sorties dans
   `{DOSSIER}/sceptique-k/`.
2. Vérifie l'application des critères gelés : chaque réserve de [A2] lue dans la forme de la table de [P2] ; aucune
   promotion ; ligne d'issue inchangée ; déclencheurs de l'audit de symétrie lus.
3. Vérifie les renvois (fichier, clé, empreinte, commit, ligne de registre).
Rapport : `{DOSSIER}/sceptique-k/rapport-sceptique-k.md` : constats (SC-k-NN, gravité, où, problème, correction), nombres
recalculés, ce que tu n'as pas pu vérifier, puis une ligne : « réfuté » ou « non réfuté ».

## Correcteur

Tu es le CORRECTEUR, neuf lui aussi. Traite chaque constat des sceptiques (accepté et corrigé, ou refusé avec la raison,
appuyée sur les fichiers). Écris `{DOSSIER}/correcteur/verdict-P3-premier-test-i-a-v2.md` : en tête, la ligne d'issue,
la porte (établi, non établi), les réserves (lecture ; premier addendum ; addendum 2), l'audit de symétrie de l'addendum 2,
s'il y a une réserve bloquante ; puis le détail avec renvois ; puis « Traitement des constats des sceptiques ». Écris
aussi `{DOSSIER}/correcteur/retour-correcteur.md`.
