"""Vérification mécanique du verdict final de P3 (v2) par le correcteur.

Lancer : python3 -I -B verifier_phrases.py
Vérifie, sans rien écrire :
1. les trois phrases gelées de [P2] (l. 422 telle quelle ; l. 427 avec <p>, A_80(p), A_80_écrit_max remplacés par les
   valeurs de [A2]) sont présentes mot pour mot dans l'en tête, la section 1, la section 6 et la section 8 ;
2. leur rapport avec [A2] resultat.recommandation_au_verdict_R13 (accents graves retirés) ;
3. l'absence des formulations retirées à la demande des sceptiques ;
4. que chaque nombre écrit du brouillon de l'auteur figure encore dans le verdict final.
"""
import hashlib
import json
import re

DEPOT = "/home/user/controle-ia-travail/"
BASE = "/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-p3/verdict-v2/"
P2 = DEPOT + "prereg/P3-addendum2-audit-verdict-v1.md"
A2 = DEPOT + "diag/20261020-220858-addendum2-p3/lecture-addendum2-p3.json"
BROUILLON = BASE + "auteur/verdict-P3-premier-test-i-a-v2-brouillon.md"
FINAL = BASE + "correcteur/verdict-P3-premier-test-i-a-v2.md"

EMPREINTES = {
    P2: "c91a3b4e600bca029f77fbd8ecea12fe9d9658da26219ddcbf3d95102f02ddb6",
    A2: "916f453647af00992528a5bb3ede9be3dcc68be9618eff990fffc58a47358c8a",
    BROUILLON: "b9dd7d7cee039106d82f0e823bfd3ca63514532cb127f5645b33f7d70a8c0a31",
}


def sha(chemin):
    with open(chemin, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def virgule(x):
    return f"{x:.4f}".replace(".", ",")


def phrases_gelees():
    lignes = open(P2, encoding="utf-8").read().split("\n")
    l422, l427 = lignes[421], lignes[426]
    assert "`reserve_B1_ampleur_au_dela_de_la_consigne`" in l422, "l. 422 de [P2] inattendue"
    assert "`reserve_B3_puissance_du_nul`" in l427, "l. 427 de [P2] inattendue"
    b1 = l422[l422.index("«"): l422.rindex("»") + 1]
    gabarit = re.search(r"« nul de détection.*?\(brainstorm\) »", l427).group(0)
    a2 = json.load(open(A2, encoding="utf-8"))["resultat"]
    b3 = a2["descriptifs"]["B3"]
    sorties = {"B1": b1}
    for p in ("tromperie-difference_moyennes-c15", "enjeux-lineaire-c15"):
        sorties["B3/" + p] = (
            gabarit.replace("`<p>`", "`" + p + "`")
            .replace("`A_80(p)`", virgule(b3[p]["A_80"]))
            .replace("`A_80_écrit_max`", virgule(b3[p]["A_80_ecrit_max"]))
        )
    return sorties, a2


def sections(texte):
    morceaux = re.split(r"\n(?=## )", texte)
    return {m.split("\n", 1)[0]: m for m in morceaux}


def main():
    for chemin, attendu in EMPREINTES.items():
        assert sha(chemin) == attendu, f"empreinte inattendue : {chemin}"
    phrases, a2 = phrases_gelees()
    final = open(FINAL, encoding="utf-8").read()
    secs = sections(final)
    cles = {
        "en tête": "## En tête",
        "section 1": "## 1. Verdict",
        "section 6": "## 6. Réserves de l'addendum 2 ([P2], [A2] ; N-025)",
        "section 8": "## 8. Prononcé",
    }
    bon = True
    for nom, ph in phrases.items():
        print(f"{nom} : {ph}")
        for etiquette, titre in cles.items():
            n = secs[titre].count(ph)
            print(f"  {etiquette} : {n} occurrence(s)")
            bon &= n >= 1
    # rapport avec [A2]
    reco = {r["conclusion"]: r["lecture"] for r in a2["recommandation_au_verdict_R13"]}
    sans = lambda s: s.replace("`", "").strip("« »")
    b1_a2 = reco["P3-P1"]
    b1_attendu = sans(phrases["B1"]).replace("borne basse de E_sf)", "borne basse de E_sf = 1,3211)")
    print("B1 : [A2] = [P2] l. 422 avec « = 1,3211 » ajouté après « borne basse de E_sf » :", b1_a2 == b1_attendu)
    bon &= b1_a2 == b1_attendu
    for p in ("tromperie-difference_moyennes-c15", "enjeux-lineaire-c15"):
        egal = reco["nul/" + p] == sans(phrases["B3/" + p])
        print(f"B3/{p} : [A2] = [P2] l. 427 substituée (accents graves retirés) :", egal)
        bon &= egal
    # formulations retirées
    retirees = [
        "(0,5748 contre le quantile 0,5717)",
        "vers 22:00 UTC",
        "Drapeau T2",
        "n'apportent pas d'information",
        "Prédictions toutes tenues",
        "Les prédictions tiennent toutes",
        "contrôles passés (A6)",
        "borne basse de `E_sf` = 1,3211) :",
        "et la même pour `enjeux-lineaire-c15`",
        "brouillon de l'auteur, non scellé",
    ]
    partout = {"(0,5748 contre le quantile 0,5717)", "Drapeau T2"}
    hors_11 = "\n".join(c for titre, c in secs.items() if not titre.startswith("## 11."))
    for r in retirees:
        ou = final if r in partout else hors_11
        n = ou.count(r)
        print(f"absente {'partout' if r in partout else 'hors section 11'} : {r!r} -> {n == 0}")
        bon &= n == 0
    # aucune phrase qui rapproche l'aire ponctuelle du quantile hors des tables exigées par [P]
    sec7 = secs["## 7. Ce que l'addendum 2 rend des remarques 1 à 4 de [V1] (section 7, l. 340-359)"]
    print("section 7 sans 0,5748 ni 0,5717 :", "0,5748" not in sec7 and "0,5717" not in sec7)
    bon &= "0,5748" not in sec7 and "0,5717" not in sec7
    # nombres du brouillon conservés
    nombre = re.compile(r"−?\d+,\d+")
    avant = set(nombre.findall(open(BROUILLON, encoding="utf-8").read()))
    apres = set(nombre.findall(final))
    manquants = sorted(avant - apres)
    print("nombres du brouillon absents du verdict final :", manquants)
    bon &= not manquants
    statut = "verdict final non scellé ; à sceller (R6), puis à soumettre à Lazar pour GO (R13)"
    print("statut écrit dans l'en tête :", statut in secs["## En tête"])
    bon &= statut in secs["## En tête"]
    print("verdict final sha256 :", sha(FINAL))
    print("TOUT CONFORME" if bon else "ÉCART")


if __name__ == "__main__":
    main()
