# Retour du correcteur — verdict R13 complété de P3 (v2)

## Verdict final

- Fichier : `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-p3/verdict-v2/correcteur/verdict-P3-premier-test-i-a-v2.md`
- sha256 : `05e896daed17cdb089cd10641878a5014b505eab0aa3d45d0dd7a60d87435751` (compagnon `.sha256` à côté).
- Statut : verdict final non scellé ; à sceller (R6), puis à soumettre à Lazar pour GO (R13).

## Qui, quoi, comment

- Correcteur : sous-agent neuf. Il n'a écrit ni le préenregistrement de P3, ni son code, ni le run, ni la lecture, ni les
  addenda (textes, modules, tests), ni le verdict v1, ni le brouillon, ni les rapports des sceptiques, ni aucune
  contre-lecture.
- Pièces traitées, empreintes vérifiées avant lecture : brouillon de l'auteur `b9dd7d7c…` ; rapport du sceptique 1
  `b5eb94c9…` (« non réfuté ») ; rapport du sceptique 2 `54307bcf…` (« non réfuté »). Outils de l'auteur : quatre « OK »
  (`sha256sum -c` depuis `auteur/outils/`).
- Dépôt en lecture seule : git avec `--no-optional-locks` (`rev-parse`, `status --short`, `log`, `show`, `diff --quiet`,
  `diff --name-only`, `merge-base --is-ancestor`) ; aucune écriture, aucun fetch, aucune commande Vast.ai, aucune
  installation, aucune suite de tests, aucune recherche récursive. Python avec `-I -B`.
- Non ouverts : `prereg/P3-consignes-v1.md` ; le fichier des textes des actions (haché seulement par `sha256sum`, jamais
  affiché ni décodé). Aucun filtre de sûreté n'a rien refusé.
- Têtes lues : `c1e7ef9` au début (22:37 UTC), `6a449d2` à la fin (22:49 UTC) ; le commit `6a449d2` (R-302) ne touche que
  `registres/decisions.md` et `registres/go.md`. Aucune pièce changée depuis `12bb6bd` ; lignes N-024, N-025, R-288,
  R-297, R-298 identiques à `12bb6bd`, `769d645`, `c1e7ef9` et `6a449d2`.
- Méthode : le verdict final est produit par un script, à partir du brouillon, par remplacements exacts (chacun doit
  trouver une seule occurrence) ; les phrases gelées sont lues dans [P2] (l. 422, l. 427) et les grandeurs dans [A2], jamais
  retapées. Une vérification mécanique séparée contrôle le résultat.

## Ce qui ne change pas

- **Ligne d'issue** : « aucune sonde générique au-dessus du plancher sur (i-a) » ([P] l. 428), seule permise.
- **Porte** : P3-P1 établie ; P3-P3 réfutée au sens de la table des prédictions, lue « non détecté à cette puissance » ;
  P3-P4 et P3-P7 sans objet ; aucun critère de G0 prononcé ; aucune porte franchie.
- **Réserves** : lecture, aucune ; premier addendum, aucune ; addendum 2, trois (`reserve_B1_ampleur_au_dela_de_la_consigne`
  sur P3-P1 ; `reserve_B3_puissance_du_nul` sur `nul/tromperie-difference_moyennes-c15` et sur `nul/enjeux-lineaire-c15`).
- **Audit de symétrie de l'addendum 2** : faux. **Arrêt** : aucun. **Contrôles « non lus »** : aucun.
- **Réserve bloquante** : aucune.
- **Nombres** : aucun. Contrôle mécanique : chaque nombre écrit du brouillon (forme « 0,1234 ») figure encore dans le
  verdict final. Seuls nombres ajoutés : les deux demi-largeurs-seuils de B3 (0,0329 et 0,0067, calcul sans tirage), les
  heures réelles et les empreintes nouvelles.

Aucun constat accepté n'exigeait de changer la ligne, une réserve, un nombre ou le jugement sur la réserve bloquante.

## Ce qui change, et pourquoi

Dix-huit constats, tous acceptés, aucun refusé (détail : section 11 du verdict).

1. **Réserves de l'addendum 2 citées dans la forme gelée exacte de [P2]** (SC-1-01, SC-2-02, SC-1-05, SC-2-03, SC-1-10 et
   consigne du correcteur). Les trois phrases sont écrites mot pour mot dans l'en tête, la section 1, la section 6.2 et la
   section 8 ; la section 1 et l'en tête ne les paraphrasent plus ; la phrase des enjeux est entière en section 8.
   Ailleurs (section 7, ligne 1 ; section 8, « Ce qu'elle n'établit pas »), seuls des fragments exacts entre guillemets.
   **Choix à signaler** : la phrase de B1 est maintenant [P2] l. 422 telle quelle (« (borne basse de `E_sf`) »), et la
   grandeur 1,3211 est écrite à côté, hors des guillemets. Le brouillon reprenait la forme de [A2], où le module a ajouté
   « = 1,3211 » dans la parenthèse. Même réserve, même nombre ; seule la forme citée change, pour suivre [P2] l. 458-459.
2. **Caractère informatif de B1** (SC-1-02, SC-2-05) : la phrase qui contredisait [P2] l. 397-398 est retirée ; l'en tête,
   la section 6.1 et la remarque 1 de la section 9 disent maintenant : « seuls le nom de la réserve de B1, la médiane et
   les réserves de B2 sont informatifs », et que B1 a été calculé à l'aveugle après S2 (R-297).
3. **Statut des prédictions** (SC-1-03) : l'hypothèse de travail de B2 est « non tranchée », non « tenue » ; « les trois
   prédictions de B1 tiennent ; B3 n'est pas une prédiction » ([P2] l. 170).
4. **Aire ponctuelle et quantile** (SC-1-04, SC-2-04) : la parenthèse qui les rapprochait dans la ligne de B3 (section 7)
   est retirée ; aucune autre phrase ne les compare. Les tables des sections 3 et 8 gardent l'aire, l'intervalle et le
   quantile, exigés par [P] l. 272-274.
5. **Heures réelles** (SC-1-06, SC-2-01) : « vers 22:00 UTC » retiré ; empreintes recalculées par le correcteur à 22:39:55
   UTC, toutes égales ; dates de l'auteur, des sceptiques et du correcteur écrites.
6. **Tirage de B3** (SC-1-07) : `w` vient des 2 000 tirages de [L] ; seuils sans tirage ajoutés (la réserve ne tomberait
   que pour `w` < 0,0329 aux enjeux, < 0,0067 à la tromperie).
7. **Drapeau de la remarque 4** (SC-1-08) : le titre de la ligne 4 de la section 7 ne nomme plus le drapeau.
8. **Forme « contrôles de l'addendum passés »** (SC-1-09) dans l'en tête ([PA] l. 288).
9. **« Bloque », « bloquer »** (SC-2-06) : [P] l. 348 et l. 518 ajoutées à la raison de « aucune réserve bloquante ».
10. **Rôle de R-288** (SC-2-07) dit en section 2.
11. **Graines neuves des sceptiques** (SC-2-08) : une phrase en section 6.3, marquée non opposable, sans verdict sur les
    descriptifs.
12. Hors constats numérotés : renvoi « [V1], l. 147-149 » corrigé en « [P2] l. 147-149 » (sceptique 1, « Renvois ») ;
    identité et cadre réécrits pour la version finale ; tête `6a449d2` ajoutée ; dernière limite de la section 10 précisée
    (l'état n'a été relu ni par l'auteur ni par le correcteur).

## Ce que le correcteur n'a pas fait

- Aucun recalcul de B1, B2 ni B3 (les deux sceptiques l'ont fait, égalité exacte avec [A2]) ; seuls les deux seuils de
  `w`, sans tirage.
- Module de l'addendum 2 non relu ; tests non lancés ; `verifier-arbre` non rejoué ; `registres/etat.md` non lu.

## Préalables pour la session

- Sceller le verdict (R6) et le verser comme `docs/verdicts/verdict-P3-premier-test-i-a-v2.md` (R12 ; le v1 reste tel
  quel) ; le consigner au registre des décisions ; puis le soumettre à Lazar pour GO (R13).

## Fichiers écrits par le correcteur (dossier `…/verdict-p3/verdict-v2/correcteur/`)

| fichier | rôle | sha256 |
|---|---|---|
| `verdict-P3-premier-test-i-a-v2.md` | verdict final | `05e896daed17cdb089cd10641878a5014b505eab0aa3d45d0dd7a60d87435751` |
| `ecrire_verdict_final.py` | produit le verdict depuis le brouillon | `c704e74d14a89ba6ca38d0ff244678f6c083932e4db34814cb9c46279ef7bdc4` |
| `verifier_phrases.py` | vérification mécanique | `04f18da6fdd4b1855a6c4efba4fa66e754ee1cdfbb11590fb58743bbb52c4961` |
| `verifier_phrases.sortie.txt` | sortie de la vérification (« TOUT CONFORME ») | `c84a9a57e6d44217ee43bf8af79f5df6c3f6d4cdcf8b45c3a2d2b4bce9c7f724` |
| `empreintes-pieces.txt` | empreintes des 19 pièces du dépôt, 22:39:55 UTC | `e4ec41344c5a36f52b06a91fb65580542f99851bd578411fc3e6250610264edb` |
| `retour-correcteur.md` | ce fichier | dans son compagnon `.sha256` |

Chaque fichier a son compagnon `<nom>.sha256` (« empreinte, deux espaces, nom de base »). Le préfixe `…/` vaut
`/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad`.
