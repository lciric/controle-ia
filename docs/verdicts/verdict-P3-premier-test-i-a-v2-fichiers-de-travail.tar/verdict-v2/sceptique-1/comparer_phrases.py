"""Compare les phrases gelées citées par le brouillon (sections 6.2 et 8) à [A2] recommandation_au_verdict_R13
et à [P2] l. 422 et l. 427 (grandeurs substituées). Usage : python3 -I -B comparer_phrases.py <brouillon> <A2> <P2>"""
import json
import re
import sys

br = open(sys.argv[1], encoding="utf-8").read().splitlines()
a2 = json.load(open(sys.argv[2]))["resultat"]["recommandation_au_verdict_R13"]
p2 = open(sys.argv[3], encoding="utf-8").read().splitlines()


def norm(s):
    return re.sub(r"\s+", " ", s.replace("`", "")).strip()


def gras(ligne):
    m = re.findall(r"\*\*« (.*?) »\*\*", ligne)
    return [norm(x) for x in m]


for no in (314, 319, 320):
    for g in gras(br[no - 1]):
        egal = [r["conclusion"] for r in a2 if norm(r["lecture"]) == g]
        print(f"brouillon l. {no} : égal à [A2] pour {egal}")
# section 8 (phrases coupées sur plusieurs lignes)
s8 = norm(" ".join(br[456:459]))
s8b = norm(" ".join(br[467:471]))
for r in a2:
    L = norm(r["lecture"])
    print(f"[A2] {r['conclusion']} : dans la section 8 (B1) {L in s8} ; dans la section 8 (B3) {L in s8b}")
# forme gelée de [P2]
g422 = re.search(r"\| « (.*) » \|$", p2[421]).group(1)
g427 = re.search(r"\| « (.*?) » ;", p2[426]).group(1)
print("P2 l. 422 :", norm(g422))
print("A2 B1     :", norm(a2[0]["lecture"]))
for r in a2[1:]:
    p = r["conclusion"].split("/", 1)[1]
    import math
    v = re.search(r"vaut (0,\d{4})", r["lecture"]).group(1)
    attendu = norm(g427.replace("<p>", p).replace("A_80(p)", v).replace("A_80_écrit_max", "0,5809"))
    print(f"P2 l. 427 substituée = A2 pour {p} : {attendu == norm(r['lecture'])}")
