# Contre-vérification du brouillon du verdict R13 complété de P3 (v2) — sceptique 1

## Cadre

- **Brouillon relu** : `…/verdict-p3/verdict-v2/auteur/verdict-P3-premier-test-i-a-v2-brouillon.md`, sha256
  `b9dd7d7cee039106d82f0e823bfd3ca63514532cb127f5645b33f7d70a8c0a31` (vérifié). Le préfixe `…/` vaut
  `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad`.
- **Sceptique 1** : sous-agent neuf. Il n'a écrit ni le préenregistrement de P3, ni son code, ni le run, ni la lecture, ni
  les addenda (textes, modules, tests), ni le verdict v1, ni ce brouillon, ni aucune contre-lecture. Il n'a pas consulté le
  sceptique 2 ni son dossier.
- **Lecture seule** : aucune écriture dans le dépôt ; git en lecture seulement, avec `--no-optional-locks` (`log`, `show`,
  `diff --quiet`, `merge-base --is-ancestor`, `rev-parse`, `status --short`) ; aucune commande Vast.ai ; aucune
  installation ; aucune suite de tests ; aucune recherche récursive (un seul `ls runs/`, sans descente). Tête lue :
  `c1e7ef95f4fd381d187c41c700aff707d30e173e`, arbre de travail propre.
- **Non ouverts** : `prereg/P3-consignes-v1.md`, `donnees/20261019-230011-p3-reel/textes-actions-p3.jsonl` (empreinte
  seule), le dossier `auteur/outils/` (ni lu, ni haché). Aucun filtre de sûreté n'a rien refusé.
- **Code** : mes propres scripts (`python3 -I -B`, numpy 2.5.3, bibliothèque standard) ; aucun import du dépôt, ni du module
  de l'addendum 2. Seuls des nombres, des booléens, des identifiants et des empreintes ont été lus dans les données.

Scripts et sorties (dossier `…/verdict-p3/verdict-v2/sceptique-1/`) :

| fichier | sha256 |
|---|---|
| `recalcul_sceptique1.py` | `28df2ce3b53f4142475ea05eb534dfa376fbcde43b7a8546120cef9106d4176e` |
| `recalcul_sceptique1.sortie.txt` | `3f2bee4b6487b065fcf42342ea3710e643835bf42a9b4d25ee6782c76b5910c5` |
| `recalcul_lecture_sans_tirage.py` | `bbcb4e1b8fdf2b16d486453f53b126b8378c3e3b2bbf843a1cd5ce91bb07fa81` |
| `recalcul_lecture_sans_tirage.sortie.txt` | `ee8b809e0f3cada350907140ccef5d4c9d1e7759cbd64c094d65a945cc9bd79f` |
| `sensibilite_descriptifs.py` | `b72ae63d5e036ce85744c321e27da07077c250da8ee2d02caad2206f3bf6e6e4` |
| `sensibilite_descriptifs.sortie.txt` | `784dfa0ed1f608a36e6b4cb6483811eec8d35d670045151f4f59807cb345849d` |
| `sensibilite_B3.py` | `6c0b278ef4d31f2f60789a3bd63d37a8c8d170c9032bfd7a9731407575f46fc6` |
| `sensibilite_B3.sortie.txt` | `6cce9a50f7d055b78d2c7b17d9c5c70612c5900cbec27f76492e9f434cfa9356` |
| `comparer_phrases.py` | `77c5cb51aa46f1289304d0697b5df9d4a499b49c624fbfd6f1d84662949b53ea` |
| `comparer_phrases.sortie.txt` | `830b48db04ac63bd09315db0f1fca45c8d89a8cacc51e8b74a99d46686c87104` |

## Résumé

Aucun constat critique ni majeur. Tous les nombres recalculables que le brouillon reprend sont **reproduits exactement**
(écart maximal 3,3·10⁻¹⁶ sur 110 nombres de B1, B2, écarts de forme, B3, P3-P1, P3-P2, mention ; 0 sur les aires et
quantiles des dix jeux), y compris les intervalles par rééchantillonnage, avec les graines consignées dans [ML] et [MA2].
La ligne retenue est la seule permise ; les trois réserves de [A2] sont exactement celles que donnent les règles gelées ;
l'audit de symétrie est faux ; les renvois sont justes. Quatre constats mineurs (formulation : paraphrase des réserves en
section 1, une remarque qui contredit [P2] l. 397-398, une « prédiction tenue » tirée d'un descriptif, un rapprochement
aire ponctuelle / quantile dans la case de B3) et six pour information.

## Constats

| id | gravité | où | problème | correction |
|---|---|---|---|---|
| SC-1-01 | mineur | Section 1 « Verdict » (l. 76-83) ; en tête (l. 23-26) | Les réserves de l'addendum 2 y sont paraphrasées, non citées « dans la forme de cette table » ([P2] l. 458-459). La paraphrase omet, pour B1, la grandeur (borne basse de `E_sf` = 1,3211) et « écart à l'ordre de grandeur prédit ([P] l. 155) » ; pour B3, « (texte : ≈ 0,57 à 0,58) » et surtout « grandeur calculée avant le scellement, sur des nombres déjà lus (brainstorm) », seule mention que B3 n'est pas aveugle. Les formes exactes sont bien aux sections 6.2 et 8 (comparaison mécanique : égales à [A2]). | Écrire les trois phrases gelées mot pour mot en section 1, ou y renvoyer explicitement (« réserves citées dans leur forme gelée, section 8 ») et marquer la paraphrase comme simple résumé. |
| SC-1-02 | mineur | Section 9, remarque 1 (l. 518-520) | « les réserves B3 et le nom de la réserve B1 n'apportent pas d'information au-delà de ce qui était attendu » contredit [P2] l. 397-398 : « seuls le nom de la réserve de B1, la médiane et les réserves de B2 sont informatifs ». La remarque confond « prédit » et « certain » : la prédiction de B1 a été écrite en connaissant l'effet décisif, mais B1 a été calculé après S2, à l'aveugle (R-297, déclaration R1). Seul B3 était connu d'avance. | Reformuler : « trois réserves étaient certaines ([P2] l. 396-399) ; le nom de la réserve B1, la médiane et B2 étaient informatifs ; le nom obtenu est celui que le rédacteur avait prédit (prédiction écrite en connaissant l'effet décisif, avant tout calcul de B1) ». |
| SC-1-03 | mineur | Section 6.4, table « Statut des prédictions » (l. 424) et l. 427 ; section 9, remarque 1 (« Prédictions toutes tenues ») | La ligne B2 range parmi les prédictions qui « tiennent » une hypothèse de travail qui n'en est pas une ([P2] l. 157 : « aucune prédiction de signe ; hypothèse de travail … sans réserve »), sur le seul signe ponctuel de deux `D` « non distinguée de 0 ». C'est tirer un statut d'un descriptif (classements de B2 : « rapportés sans verdict … jamais cités comme conclusion », [P2] l. 431), et cela peut se lire comme un appui à « la référence honnête commune porte une part du signe négatif », que B2 ne sépare pas ([P2] l. 131-132). | Pour B2 : « hypothèse de travail, sans prédiction de signe : non tranchée (`D` non distinguée de 0 pour les deux ; la réfutation écrite, signes opposés, n'est pas atteinte) » ; écrire « les prédictions de B1 et de B3 tiennent » au lieu de « toutes ». |
| SC-1-04 | mineur | Section 7, remarque 3 (l. 439) | « L'aire ponctuelle de la sonde de tromperie (0,5748 contre le quantile 0,5717) n'est pas relue » : la phrase qui dit ne pas relire l'aire ponctuelle la remet à côté du quantile, dans la case de B3. [P2] l. 138-139 (aire ponctuelle non relue) et M10 « Exclu » (l. 266-268 : ni puissance à l'aire observée, ni « seuil moins aire observée », qui « inviterait une lecture presque détecté ») visent ce rapprochement. Le brouillon n'écrit pas « presque détecté », mais le rapprochement en est la forme. ([V1] l. 355-357 l'écrivait, avant [P2].) | Retirer la parenthèse « (0,5748 contre le quantile 0,5717) ». Les nombres restent dans les tables des sections 3 et 8, exigés par [P] l. 273-274. |
| SC-1-05 | information | Section 8 (l. 471) | La réserve B3 de la sonde `enjeux-lineaire-c15` n'y est pas écrite en entier (« et la même pour … avec 0,5966 ») ; elle l'est en section 6.2 (l. 320). | L'écrire en entier en section 8 ([P2] l. 459 : « chaque réserve »). |
| SC-1-06 | information | Section 2 (l. 91) | « empreintes recalculées … vers 22:00 UTC » : [A2] et [MA2] n'existent qu'à partir de 22:09 (commit `12bb6bd`, 22:09:31 UTC) ; la rédaction est datée vers 22:16-22:21 (l. 47-50). | Corriger l'heure. |
| SC-1-07 | information | Section 6.3 (l. 351, l. 379-380) | « B3 est sans tirage » : vrai pour le calcul de B3, mais son entrée `w` vient du rééchantillonnage de [L] (2 000 tirages). Mon essai (convention de blocs supposée, 30 graines neuves, non opposable) : `w` de 0,0415 à 0,0450 (tromperie), de 0,0435 à 0,0487 (enjeux) ; `A_80` de 0,6288 à 0,6336 et de 0,5955 à 0,6026 ; la réserve des enjeux ne tomberait que pour `w` < 0,0329. Aucun état ne change. | Écrire « B3 ne tire rien ; son entrée `w` vient des tirages de [L], loin de la marge ». |
| SC-1-08 | information | Section 7 (l. 440) | Le titre « Drapeau T2 » nomme le drapeau (sans valeur ni état ; aucune lecture). [P2] l. 437-438 : « ni lu ni cité ». | Écrire « Remarque 4 de [V1] (exclue par N-025, [P2] l. 104) ». |
| SC-1-09 | information | En tête (l. 12) | « contrôles passés (A6) » au lieu de la forme gelée « contrôles de l'addendum passés » ([PA] l. 288), donnée exactement aux sections 5 et 8. | Reprendre la forme gelée. |
| SC-1-10 | information | Section 6.2 (l. 328-330) | « grandeurs substituées, égalité exacte pour les trois » : exact pour B3 (l. 427 substituée = [A2], vérifié) ; pour B1, [P2] l. 422 n'a pas d'emplacement de grandeur, et [A2] (donc le brouillon) ajoute « = 1,3211 » après « borne basse de `E_sf` ». Fidèle sur le fond. | Le dire : « pour B1, grandeur ajoutée par le module après « borne basse de `E_sf` » ». |

## Nombres recalculés

Depuis [S] (`scores-p3.npz`, colonnes `condition`, `tache`, `cout`, cinq formes, `scores`, `noms_sondes`, `jetons_notes`,
`pas`, `mention_texte_prive`, `titre_sans_capitale`), [L] et les deux manifestes ; détail dans les sorties citées.

**Graines.** `SeedSequence(entropie, spawn_key)` rend l'`etat_controle` consigné pour les 47 clés de [MA2] et pour
`cout/saboteur` de [ML] (vrai). La dérivation des `spawn_key` depuis les noms de clés n'est pas revérifiée (voir plus bas).

**Ligne d'issue.**

| grandeur | recalculé | [L] / brouillon | écart |
|---|---|---|---|
| P3-P1, effet (60 tâches, aucune exclue ; illisibles 140 / 134, nuls 0 / 7) | 1,5227394386 | 1,5227 | 0 |
| P3-P1, intervalle à 95 % (graine `cout/saboteur` de [ML]) | [1,2464489096 ; 1,8011761611] | [1,2464 ; 1,8012] | 0 |
| P3-P2 ; mention (effets et intervalles, graines de [ML]) | −0,3176 [−0,5704 ; −0,0650] ; −0,3229 [−0,5404 ; −0,1155] | idem | 0 |
| aire tromperie, saboteur contre honnête | 0,574833 | 0,5748 | 0 |
| quantile 0,95 du plancher, tromperie (200 sondes) | 0,571715 | 0,5717 | 0 |
| aire enjeux, saboteur contre honnête | 0,524797 | 0,5248 | 0 |
| quantile 0,95 du plancher, enjeux (200 sondes) | 0,535588 | 0,5356 | 0 |
| bornes basses de P3-P3 (essai par blocs de tâches, convention supposée, graine de [ML]) | 0,5298 ; 0,4796 | 0,5313 ; 0,4813 | 0,0016 et 0,0016 (convention non lue ; non opposable) |
| mêmes bornes, 20 graines neuves | 0,5269 à 0,5338 ; 0,4733 à 0,4810 | quantiles 0,5717 ; 0,5356 | toutes ≤ quantile : **aucun état ne change** |

Les aires et quantiles des dix jeux, les séparations de l'audit R4 (sonde, longueur notée, pas, mention, coût seul avec ses
effectifs 926/919/925/930/924, titre seul), les corrélations de rangs (0,256987 ; −0,117969), les aires sans mention
(0,5753 et 0,5254, quantiles 0,5705 et 0,5335, 596/599 actions) et les comptes de P3-P6 cités sont égaux à [L] et aux
tables des sections 3 et 4 du brouillon (transcription vérifiée à quatre décimales).

**Addendum 2 (graines de [MA2]).** Tous égaux à [A2] à 3,3·10⁻¹⁶ près :

| grandeur | saboteur − honnête | témoin − honnête | mention − honnête |
|---|---|---|---|
| `E_sf` | 1,6099 [**1,3211** ; 1,9041], 57 | −0,2360 [−0,5217 ; 0,0532], 55 | −0,2569 [−0,4840 ; −0,0347], 57 |
| `D` | −0,0565 [−0,1657 ; 0,0051] | −0,0639 [−0,1758 ; 0,0014] | −0,0540 [−0,1650 ; 0,0084] |
| `E0` | 1,5534 [1,2700 ; 1,8435] | −0,2999 [−0,5712 ; −0,0269] | −0,3109 [−0,5318 ; −0,1003] |
| part `D / E0` | −0,0364 [−0,1173 ; 0,0032], 0 dégénéré | 0,2130 [−0,0151 ; 1,3681], 0 | 0,1736 [−0,0351 ; 0,7335], 0 |
| `M` | 1,7149 [1,1318 ; 1,9163] | −0,3545 [−0,5557 ; −0,0784] | −0,2630 [−0,5118 ; −0,1153] |
| `d > 0` ; `d > log10 3` | 55 ; 50 | 21 ; 13 | 20 ; 10 |
| tâches sans forme | 1,5943 [1,2708 ; 1,9233], 47 | −0,3986 [−0,7369 ; −0,0513], 38 | −0,3017 [−0,5421 ; −0,0636], 47 |
| sans plusieurs nombres ; sans intervalle ; sans « k » | égaux à la table 6.4 du brouillon | idem | idem |

Actions retirées par `R_sf` : honnête 54, témoin 28, mention 7, saboteur 3, toutes lisibles ; comptes de formes égaux à
[L] `P3-P6`. Écarts de forme (M8) : honnête 0,0763 [−0,1937 ; 0,3794], 7 ; témoin −0,3096 [−0,6068 ; −0,0926], 10 ;
mention 0,1069 [0,0591 ; 0,1488], 3 ; saboteur −0,1845 [−0,5057 ; 0,0289], 3 ; intervalle et « k » chez l'honnête : une
tâche, non calculables. Tables par tâche de B1 et B2 (`d_0`, `d_sf`, 60 lignes chacune) : écart 0.

**B3 (sans tirage, depuis [L]).** `z` = 2,241402727605 ; `z80` = 0,841621233573 ; facteur 1,3754886274.
`A_80_écrit_max` = 0,53 + 0,037 × 1,3754886274 = **0,5808930792** ; `A_80_écrit_min` = 0,5543872157 ; aire au seuil
écrite 0,545 à 0,567. Tromperie : `w` = 0,043495, `A_80` = **0,6315419363** (marge 0,0506) ; enjeux : `w` = 0,044374,
`A_80` = **0,5966238546** (marge 0,0157). Descriptifs : aire au seuil 0,6152 et 0,5800 ; à la distance basse, `A_80`
0,6316 et 0,5954, aire au seuil 0,6152 et 0,5791 ; distances basse / haute 0,0435 / 0,0435 et 0,0435 / 0,0452. Égaux à
[A2] et au brouillon.

**Règles de réserve réappliquées** : `b_sf` = 1,3211 > `r` = 0,4771, `b_D` = −0,1657 ≤ 0 → seule
`ampleur_au_dela_de_la_consigne` ; `b_M` = 1,1318 > 0 → pas de médiane ; `ampleur_non_resolue` faux ; témoin et mention :
bornes basses ≤ 0 → rien ; B3 vrai pour les deux sondes. **Trois réserves, exactement celles de [A2].**

**Sensibilité au tirage (graines neuves).** 50 graines : bornes basses `E_sf` saboteur 1,3153 à 1,3309, `D` saboteur
−0,1692 à −0,1621, `M` saboteur 1,1318 à 1,1526, `E_sf` témoin −0,5352 à −0,5180, mention −0,4886 à −0,4786 : aucune
règle de réserve ne change. 200 graines : bornes hautes de `D` 0,0042 à 0,0053 (saboteur), 0,0007 à 0,0020 (témoin),
0,0075 à 0,0089 (mention), jamais < 0 ; `E0` ne contient jamais 0 (aucune part « instable ») ; borne haute de `E_sf`
témoin 0,0480 à 0,0677, mention −0,0388 à −0,0230 : les classements descriptifs du brouillon ne changent pas. Écart à
[A2] avec d'autres graines : au plus ≈ 0,016 sur une borne (borne haute de `E_sf` du témoin, 0,0696 contre 0,0532) ;
aucune réserve ni aucun état ne change.

## Application des critères gelés

- **Ligne d'issue** : P3-P1 établie (borne basse 1,2464 > 0) ; P3-P3 calculée pour les deux sondes, 0 dégénéré, aucune
  entrée en échec ; aucune borne basse au-dessus de son quantile (marges 0,0404 et 0,0543). Les lignes 1 à 3 de [P]
  l. 425-427 ne s'appliquent pas, la ligne 4 (l. 428) s'applique, les lignes 5 à 8 exigent une sonde au-dessus. **Seule
  ligne permise** ; elle ne dépend pas du tirage (essai ci-dessus).
- **Réserves de [A2] dans la forme de [P2]** : sections 6.2 et 8, égalité mécanique avec [A2]
  `recommandation_au_verdict_R13` pour les trois phrases (6.2) et pour B1 et la tromperie (8) ; B3 égale à [P2] l. 427
  substituée. Paraphrase en section 1 (SC-1-01) ; enjeux abrégée en section 8 (SC-1-05).
- **Réserve oubliée** : aucune (lecture : 0 ; premier addendum : 0 ; addendum 2 : 3, toutes citées).
- **Promotion** : aucune. Pas de « contrôles de l'addendum 2 passés » (ligne non applicable, chaque conclusion porte une
  réserve, bien lu) ; « contrôles de l'addendum passés » (A6) du premier addendum gardé à part, conforme à [PA] l. 288.
- **Seuil inventé** : aucun. Les « marges » et le « 0,0075 » ([V1] l. 179-183) sont des remarques de robustesse, non des
  critères.
- **B3 lu comme « presque détection »** : jamais écrit ; un rapprochement aire ponctuelle / quantile subsiste (SC-1-04).
- **Drapeau T2** : jamais lu ni cité par sa valeur ; nommé comme titre de la remarque 4 (SC-1-08). [A2] ne contient aucune
  clé ni chaîne « T2 » (vérifié).
- **« Aucune réserve bloquante »** : **tenable**. Le terme n'est défini dans aucun texte gelé (vérifié : « bloquant »
  seulement dans [P] l. 491, 494, 540, 546 et [PA] l. 446, pour des gravités de constats ; absent de [P2]). Les seules
  issues gelées qui iraient au-delà d'une citation — audit de symétrie vrai (« cité et soumis à Lazar », [P2] l. 432),
  arrêt de l'addendum 2 (l. 433), run sans résumé, lecture en échec ou réserve de validité de [P] (l. 425, l. 427,
  l. 430) — sont absentes. Chaque
  réserve laisse sa conclusion établie (phrases gelées « P3-P1 établie ; … », « nul de détection … non détecté à cette
  puissance ; … »). Les remarques SC-1-02 et SC-1-03 ne touchent pas ce jugement.
- **Descriptifs** rapportés à part (section 6.4), sans verdict, sauf la ligne B2 du « statut des prédictions »
  (SC-1-03).

## Audit de symétrie de l'addendum 2 et cohérence avec [L]

- **Déclencheur 2** (« explication trop propre ») : intervalles décisifs conformes ? saboteur non (1,2464 > 0,4771),
  témoin non (haut −0,0650 < 0), mention non (haut −0,1155 < 0) → pas « sans objet ». `E_sf` conformes : saboteur non
  (1,3211 > 0,4771), témoin oui ([−0,5217 ; 0,0532] contient 0), mention non ([−0,4840 ; −0,0347]) → **faux**, égal à
  [A2]. Stable : il faudrait que la borne basse de `E_sf` du saboteur perde 0,8440 ; et la borne haute de la mention reste
  < 0 sous 200 graines.
- **Déclencheur 3** (« part hors bornes ») : part ponctuelle −0,036361 ∈ [−1 ; 1] → **faux** (sans tirage).
- `declencheur` faux, `consigne` et `lecture` nulles ; « même traitement » : une fonction, 0,95, 10 000 tirages, six
  restrictions pour les trois contrastes ; B3 pour les deux sondes. Conforme à [P2] l. 440-457.
- **Cohérence [A2] / [L]** : `issue_primaire` = [L] `issue` ; `principales` égales ; `coherence_avec_la_lecture` (écarts
  0,0 ; `n_plancher` 200 ; formes « égales ») confirmée par mon recalcul (effets, aires, quantiles, comptes de formes) ;
  entrées B3 de [A2] (`aire`, `bas`, `haut`, `plancher_quantile`, `niveau`) égales à [L] `P3-P3` ; contrôles de [A2] qui
  citent des bornes décisives (1,2464 ; −0,5704 ; −0,5404) égaux à [L] ; `lecture_sha256`, les neuf `entrees_sha256`,
  `preenregistrement_sha256`, `module_sha256`, `tests_sha256`, `commit_cite` (= [P2] l. 35), entropie (= l. 36),
  47 clés de graines, `tete_verifiee` = `commit_de_scellement` = S2 = [MA2] `commit` : justes. Aucune clé interdite,
  aucune valeur non finie (570 flottants), pas de clé `arret`, `manifestes_illisibles_ecartes` 0 et 0.

## Renvois

- **Empreintes** : les 19 pièces de la table de la section 2 hors [D], [O4], [O5] sont égales au calcul et à leur
  compagnon `.sha256` ; [D] à `769d645` = `fddc0d71…` (vérifié ; le fichier vivant à la tête vaut `6d033ecf…`, ce que le
  brouillon dit en substance). [O4], [O5] : non vérifiés (consigne : `auteur/outils/` non lu).
- **Commits** : sceaux ajoutés par `97dd829` ([P]), `e03df08` ([PA]), `af97266` ([P2], 22:08:40 UTC, seul commit qui
  touche [P2], le module et ses tests) ; [L] seul `63386e6`, [A] seul `6a97d69`, [V1] seul `f7cea56`, [A2] et [MA2] seuls
  `12bb6bd` (22:09:31 UTC) ; tous ancêtres de la tête ; `ec1d71b` ancêtre de S2 ; empreintes à ces commits = aujourd'hui ;
  les `git diff --quiet` cités sont vrais ; `769d645` ne touche que `registres/decisions.md` et `registres/etat.md`,
  `ee9cb0e` et `c1e7ef9` que `registres/decisions.md`. [MA2] : `cree_le` 22:09:02 UTC, `decisif` faux, `depot_propre`
  vrai, [P2] cité par chemin et empreinte, numpy 2.4.6. Un seul dossier de l'addendum 2 sous `runs/`.
- **Registre** : N-024 l. 437, N-025 l. 453, R-288 l. 488, R-297 l. 497, R-298 l. 498, identiques à `12bb6bd`, `769d645`
  et à la tête ; R-297 porte la déclaration R1, R-298 le passage unique (code 0, tête `af97266`).
- **Lignes des textes gelés** : toutes celles vérifiées sont justes ([P] l. 122, 153-161, 155, 157, 158-159, 262-263,
  272-283, 273, 278, 401-416, 420-436 ; [PA] l. 242-250, 282-291, 293-294, 446 ; [P2] l. 35-38, 86-88, 101-104, 131-132,
  138-139, 147-168, 227-228, 244-245, 315-344, 349-351, 362-364, 378-399, 418-460, 587-601 ; [V1] l. 179-183, 296-302,
  340-359). Seule ambiguïté : l. 416-417 du brouillon, « [V1], l. 147-149 » vise [P2] l. 147-149.

## Ce que je n'ai pas pu vérifier

- Le classement des formes du champ du coût (booléens calculés sur l'instance) : sans les textes, je les prends de [S]
  comme donnée ; seuls leurs comptes sont recoupés avec [L] et [A2].
- La convention exacte du rééchantillonnage par blocs de P3-P3 (code gelé non lu) : mon essai approche les bornes de [L]
  à 0,0016 près ; il n'est pas opposable. Les bornes de [L] sont prises telles quelles.
- La dérivation des `spawn_key` depuis les noms de clés (`manifeste.graines`, non lu) : seule la cohérence `entropie`,
  `spawn_key`, `etat_controle` est vérifiée, et l'usage de ces graines redonne [A2] exactement.
- Les empreintes de [O4], [O5] et de `outils-sha256.txt` (consigne). L'indépendance de l'auteur et l'absence de calcul de
  B1 ou B2 avant S2 (déclaration R-297 seulement, et ordre des commits).
- `verifier-arbre` non rejoué (lecture seule).

## Jugement

Le brouillon applique les critères gelés : la ligne est la seule permise, les trois réserves de l'addendum 2 sont les
bonnes et sont citées dans leur forme gelée aux sections 6.2 et 8, l'audit de symétrie est faux, « aucune réserve
bloquante » est tenable, et chaque nombre recalculable est reproduit exactement. Les quatre constats mineurs portent sur
la formulation et sont à corriger avant le scellement.

non réfuté
