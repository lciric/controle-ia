"""Sensibilité au tirage des classements descriptifs proches de 0 (D haut, E0 haut, E_sf haut).
Usage : python3 -I -B sensibilite_descriptifs.py <racine du dépôt>"""
import sys

import numpy as np

RAC = sys.argv[1]
S = np.load(RAC + "/donnees/20261019-230011-p3-reel/scores-p3.npz", allow_pickle=False)
FORMES = ["cout_plusieurs_nombres", "cout_multiplication", "cout_intervalle", "cout_suffixe_k",
          "cout_milliers_espace"]
COND, TACHE, COUT = S["condition"], S["tache"], S["cout"].astype(float)
SF = np.zeros(len(COUT), bool)
for f in FORMES:
    SF |= S[f].astype(bool)
TACHES = sorted(set(TACHE.tolist()))
B = 10000


def st(cond, cout):
    out = {}
    for t in TACHES:
        c = cout[(COND == cond) & (TACHE == t)]
        c = c[np.isfinite(c) & (c > 0)]
        out[t] = float(np.mean(np.log10(c))) if len(c) else None
    return out


for a in ["saboteur", "temoin", "mention"]:
    c_sf = COUT.copy()
    c_sf[SF & ((COND == a) | (COND == "honnete"))] = np.nan
    sa, sb, sa0, sb0 = st(a, c_sf), st("honnete", c_sf), st(a, COUT), st("honnete", COUT)
    T = [t for t in TACHES if sa[t] is not None and sb[t] is not None]
    dsf = np.array([sa[t] - sb[t] for t in T])
    d0 = np.array([sa0[t] - sb0[t] for t in T])
    Dh, E0h, Esh, flipsD, flipsE0, flipsEs = [], [], [], 0, 0, 0
    N = 200
    for s in range(N):
        r = np.random.default_rng(np.random.SeedSequence(990000 + s))
        idx = r.integers(0, len(T), size=(B, len(T)))
        Db = (d0 - dsf)[idx].mean(axis=1)
        E0b = d0[idx].mean(axis=1)
        dh = np.quantile(Db, 0.975)
        eh = np.quantile(E0b, 0.975)
        el = np.quantile(E0b, 0.025)
        Dh.append(dh)
        E0h.append(eh if a != "saboteur" else el)
        flipsD += dh < 0
        flipsE0 += (el <= 0 <= eh)
        r2 = np.random.default_rng(np.random.SeedSequence(880000 + s))
        idx2 = r2.integers(0, len(T), size=(B, len(T)))
        m = dsf[idx2].mean(axis=1)
        sh = np.quantile(m, 0.975)
        Esh.append(sh)
        flipsEs += (sh < 0) if a == "temoin" else (sh >= 0) if a == "mention" else 0
    print(f"{a}: D haut de {min(Dh):.4f} à {max(Dh):.4f} ; part des graines où D haut < 0 (classement « abaissent ») :"
          f" {flipsD}/{N}")
    print(f"   E0 : intervalle contenant 0 (part « instable ») dans {flipsE0}/{N} graines ;"
          f" borne {'basse' if a == 'saboteur' else 'haute'} de E0 de {min(E0h):.4f} à {max(E0h):.4f}")
    print(f"   E_sf haut de {min(Esh):.4f} à {max(Esh):.4f} ; classement changé dans {flipsEs}/{N} graines")
