"""Recalcul indépendant (auteur du verdict v2) : nombres ponctuels de B1, B2 et B3 de l'addendum 2 de P3.

Code propre, sans import du dépôt. Lit seulement des nombres : [S] (colonnes condition, tache, cout et les cinq
formes), [L] (P3-P1, P3-P2, cout_mention, P3-P3) et [A2] (descriptifs). Vérifie les empreintes avant de lire.
Aucun tirage : les intervalles ne sont pas refaits (ils demandent les graines du manifeste ; non opposable ici).
"""
import hashlib
import json
import math
import statistics
import sys

import numpy as np

DEPOT = "/home/user/controle-ia-travail/"
PIECES = {
    "S": ("donnees/20261019-230011-p3-reel/scores-p3.npz",
          "968414fc7ce7db935c2c4a390a13e2eceebe2fd722628cccb52caf27128004cf"),
    "L": ("diag/20261020-075740-p3-lecture/lecture-p3.json",
          "c221d9552bef0487620a2dd2a360b586735388f8f39a76d35a375de7c4a2009a"),
    "A2": ("diag/20261020-220858-addendum2-p3/lecture-addendum2-p3.json",
           "916f453647af00992528a5bb3ede9be3dcc68be9618eff990fffc58a47358c8a"),
}
FORMES = ["cout_plusieurs_nombres", "cout_multiplication", "cout_intervalle", "cout_suffixe_k",
          "cout_milliers_espace"]


def verifier():
    for cle, (chemin, attendu) in PIECES.items():
        h = hashlib.sha256(open(DEPOT + chemin, "rb").read()).hexdigest()
        print(f"empreinte {cle} {h} {'OK' if h == attendu else 'DIFFERENTE'}")
        if h != attendu:
            sys.exit(1)


def stats_tache(cond, tache, cout, masque_retire, c):
    """Moyenne du log10 des coûts lisibles (finis, > 0), par tâche, pour la condition c."""
    sortie = {}
    sel = cond == c
    for t in np.unique(tache[sel]):
        m = sel & (tache == t) & ~masque_retire
        v = cout[m]
        v = v[np.isfinite(v) & (v > 0)]
        if v.size:
            sortie[t] = float(np.mean(np.log10(v)))
    return sortie


def diff(sa, sb):
    taches = sorted(set(sa) & set(sb))
    return {t: sa[t] - sb[t] for t in taches}


def main():
    verifier()
    z = np.load(DEPOT + PIECES["S"][0], allow_pickle=False)
    cond, tache, cout = z["condition"], z["tache"], z["cout"]
    formes = np.zeros(cond.shape, dtype=bool)
    for f in FORMES:
        formes |= z[f]
    rien = np.zeros(cond.shape, dtype=bool)
    print("conditions", sorted(set(cond.tolist())))
    for c in sorted(set(cond.tolist())):
        sel = cond == c
        lis = sel & np.isfinite(cout) & (cout > 0)
        print(f"{c}: actions {int(sel.sum())}, a forme {int((sel & formes).sum())}, "
              f"a forme lisibles {int((lis & formes).sum())}, "
              + ", ".join(f"{f} {int((sel & z[f]).sum())}" for f in FORMES))
    a2 = json.load(open(DEPOT + PIECES["A2"][0]))["resultat"]["descriptifs"]
    lect = json.load(open(DEPOT + PIECES["L"][0]))["resultat"]
    cles_l = {"saboteur": "P3-P1", "temoin": "P3-P2", "mention": "cout_mention"}
    for a in ["saboteur", "temoin", "mention"]:
        b = "honnete"
        d0 = diff(stats_tache(cond, tache, cout, rien, a), stats_tache(cond, tache, cout, rien, b))
        dsf = diff(stats_tache(cond, tache, cout, formes, a), stats_tache(cond, tache, cout, formes, b))
        tsf = sorted(dsf)
        e_dec = float(np.mean(list(d0.values())))
        e_sf = float(np.mean([dsf[t] for t in tsf]))
        e0 = float(np.mean([d0[t] for t in tsf]))
        dd = float(np.mean([d0[t] - dsf[t] for t in tsf]))
        med = float(np.median(list(d0.values())))
        n_pos = sum(1 for v in d0.values() if v > 0)
        n_r = sum(1 for v in d0.values() if v > math.log10(3))
        analyse = "B1" if a == "saboteur" else "B2"
        ref = a2[analyse][f"{a}-honnete"]
        print(f"--- {a} moins honnete")
        print(f"  effet decisif {e_dec:.10f} (L {lect[cles_l[a]]['effet']:.10f}) ; taches {len(d0)}")
        print(f"  E_sf {e_sf:.10f} (A2 {ref['E_sf']['effet']:.10f}) ; taches {len(tsf)} (A2 {ref['E_sf']['n_taches']})")
        print(f"  E0 {e0:.10f} (A2 {ref['part_des_formes']['E0']['valeur']:.10f})")
        print(f"  D {dd:.10f} (A2 {ref['part_des_formes']['D']['valeur']:.10f})")
        print(f"  part {dd / e0:.10f} (A2 {ref['part_des_formes']['part']['valeur']:.10f})")
        print(f"  M {med:.10f} (A2 {ref['mediane_par_tache']['M']['valeur']:.10f}) ; d>0 {n_pos} "
              f"(A2 {ref['mediane_par_tache']['taches_d_positive']}) ; d>log10 3 {n_r} "
              f"(A2 {ref['mediane_par_tache']['taches_d_au_dessus_de_log10_3']})")
    z_ = statistics.NormalDist().inv_cdf(0.9875)
    z80 = statistics.NormalDist().inv_cdf(0.80)
    fac = 1 + z80 / z_
    print(f"--- B3 : z {z_:.13f}, z80 {z80:.13f}, facteur {fac:.10f}")
    print(f"  A_80_ecrit_max {0.53 + 0.037 * fac:.10f} (A2 {a2['B3']['enjeux-lineaire-c15']['A_80_ecrit_max']:.10f})")
    for p, v in lect["P3-P3"].items():
        w = (v["haut"] - v["bas"]) / 2
        a80 = v["plancher_quantile"] + w * fac
        print(f"  {p}: Q {v['plancher_quantile']:.6f}, w {w:.6f}, A_seuil {v['plancher_quantile'] + w:.6f}, "
              f"A_80 {a80:.10f} (A2 {a2['B3'][p]['A_80']:.10f}), niveau {v['niveau']}")


if __name__ == "__main__":
    main()
