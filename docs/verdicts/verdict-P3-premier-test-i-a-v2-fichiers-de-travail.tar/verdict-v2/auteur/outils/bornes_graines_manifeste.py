"""Recalcul indépendant des bornes de E_sf, D, part et M (B1, B2) avec les graines consignées au manifeste de [A2].

Code propre, sans import du dépôt. Convention écrite en [P2] (M4 à M6) : tâches triées, une matrice
rng.integers(0, n, size=(10000, n)) par clé, percentiles à 2,5 % et 97,5 % (np.quantile par défaut).
Graine : SeedSequence(entropie, spawn_key=(clé,)), np.random.default_rng, contrôle de generate_state(2).
"""
import hashlib, json, sys
import numpy as np

DEPOT = "/home/user/controle-ia-travail/"
S = ("donnees/20261019-230011-p3-reel/scores-p3.npz", "968414fc7ce7db935c2c4a390a13e2eceebe2fd722628cccb52caf27128004cf")
A2 = ("diag/20261020-220858-addendum2-p3/lecture-addendum2-p3.json", "916f453647af00992528a5bb3ede9be3dcc68be9618eff990fffc58a47358c8a")
MA2 = ("runs/20261020-220858-addendum2-p3/manifeste.json", "9bc77d2a13e4e8d363087137c4d3c6ce5578174b905ef73eeafab4895f898d37")
for chemin, att in (S, A2, MA2):
    h = hashlib.sha256(open(DEPOT + chemin, "rb").read()).hexdigest()
    print("empreinte", chemin, "OK" if h == att else "DIFFERENTE")
    if h != att: sys.exit(1)
FORMES = ["cout_plusieurs_nombres", "cout_multiplication", "cout_intervalle", "cout_suffixe_k", "cout_milliers_espace"]
z = np.load(DEPOT + S[0], allow_pickle=False)
cond, tache, cout = z["condition"], z["tache"], z["cout"]
formes = np.zeros(cond.shape, bool)
for f in FORMES: formes |= z[f]
graines = json.load(open(DEPOT + MA2[0]))["graines"]
ref = json.load(open(DEPOT + A2[0]))["resultat"]["descriptifs"]

def gen(cle):
    g = graines[cle]
    ss = np.random.SeedSequence(int(g["entropie"]), spawn_key=tuple(int(k) for k in g["spawn_key"]))
    assert [int(x) for x in ss.generate_state(2)] == g["etat_controle"], cle
    return np.random.default_rng(ss)

def s_tache(c, retire):
    out = {}
    for t in np.unique(tache[cond == c]):
        m = (cond == c) & (tache == t) & ~retire
        v = cout[m]; v = v[np.isfinite(v) & (v > 0)]
        out[t] = float(np.mean(np.log10(v))) if v.size else None
    return out

def d_par_tache(a, retire):
    sa, sb = s_tache(a, retire), s_tache("honnete", retire)
    return {t: sa[t] - sb[t] for t in sorted(sa) if sa[t] is not None and sb[t] is not None}

rien = np.zeros(cond.shape, bool)
for a, an in (("saboteur", "B1"), ("temoin", "B2"), ("mention", "B2")):
    contraste = f"{a}-honnete"; r = ref[an][contraste]
    d0, dsf = d_par_tache(a, rien), d_par_tache(a, formes)
    # E_sf
    x = np.array([dsf[t] for t in sorted(dsf)])
    rng = gen(f"addendum2/{an}/{contraste}/sans-forme")
    tb = x[rng.integers(0, x.size, size=(10000, x.size))].mean(axis=1)
    print(f"{contraste} E_sf bas {np.quantile(tb,0.025):.10f} (A2 {r['E_sf']['bas']:.10f}) haut {np.quantile(tb,0.975):.10f} (A2 {r['E_sf']['haut']:.10f})")
    # D, E0, part
    tsf = sorted(dsf)
    dd = np.array([d0[t] - dsf[t] for t in tsf]); e0 = np.array([d0[t] for t in tsf])
    rng = gen(f"addendum2/{an}/{contraste}/part-des-formes")
    idx = rng.integers(0, len(tsf), size=(10000, len(tsf)))
    Db, E0b = dd[idx].mean(axis=1), e0[idx].mean(axis=1)
    pb = Db[E0b != 0] / E0b[E0b != 0]
    print(f"{contraste} D bas {np.quantile(Db,0.025):.10f} (A2 {r['part_des_formes']['D']['bas']:.10f}) haut {np.quantile(Db,0.975):.10f} (A2 {r['part_des_formes']['D']['haut']:.10f})")
    print(f"{contraste} E0 bas {np.quantile(E0b,0.025):.10f} (A2 {r['part_des_formes']['E0']['bas']:.10f}) ; part bas {np.quantile(pb,0.025):.10f} (A2 {r['part_des_formes']['part']['bas']:.10f}) haut {np.quantile(pb,0.975):.10f} (A2 {r['part_des_formes']['part']['haut']:.10f})")
    # M
    m = np.array([d0[t] for t in sorted(d0)])
    rng = gen(f"addendum2/{an}/{contraste}/mediane-par-tache")
    mb = np.median(m[rng.integers(0, m.size, size=(10000, m.size))], axis=1)
    print(f"{contraste} M bas {np.quantile(mb,0.025):.10f} (A2 {r['mediane_par_tache']['M']['bas']:.10f}) haut {np.quantile(mb,0.975):.10f} (A2 {r['mediane_par_tache']['M']['haut']:.10f})")
