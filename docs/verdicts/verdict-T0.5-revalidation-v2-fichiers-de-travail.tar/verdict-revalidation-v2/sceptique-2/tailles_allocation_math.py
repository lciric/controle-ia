"""Inférence sur les tailles d'allocation de run.err (bras « math »).

L'allocateur de la bibliothèque arrondit les grands blocs au multiple de 2 Mio supérieur : une taille T rapportée
correspond à un tenseur de taille dans ]T − 2 Mio, T]. On cherche L entier tel que 8 × 32 × L × L × 4 octets
(matrice d'attention en simple précision, lot de 8, 32 têtes : ce que matérialise le noyau « math » avec la
remontée en simple précision) tombe dans cette fenêtre ; puis les formes voisines (un octet par élément ; lot de 1).
"""
TAILLES = {"23:38:56": 10362028032, "23:41:29": 18020827136, "23:43:00": 22833790976, "23:44:05": 26013073408,
           "23:44:07 (échec final)": 6503268352}
MIO2 = 2 * 2 ** 20
for heure, t in TAILLES.items():
    bas, haut = t - MIO2, t
    sol = {}
    for nom, k in (("8×32×L²×4 (lot de 8, simple précision)", 1024), ("8×32×L²×1 (un octet)", 256),
                   ("1×32×L²×4 (lot de 1, simple précision)", 128)):
        L = [x for x in range(1, 20000) if bas < k * x * x <= haut]
        sol[nom] = L
    print(heure, t, f"{t / 2**30:.3f} Gio", sol)
# Mémoire au moment de la panne (message consigné) : 68,64 Gio alloués ; poids du 8B en bfloat16 :
poids_gio = 8.03e9 * 2 / 2**30
kv_gio = 32 * 2 * 8 * 8 * 5040 * 128 * 2 / 2**30          # cache clé-valeur, 32 couches, 8 têtes clé-valeur, lot de 8
score_gio = 1024 * 5040**2 / 2**30
print(f"poids {poids_gio:.2f} Gio ; cache à L=5040 {kv_gio:.2f} Gio ; une matrice d'attention à L=5040 {score_gio:.2f} Gio")
print(f"poids + cache + 2 matrices = {poids_gio + kv_gio + 2*score_gio:.2f} Gio (consigné : 68,64 Gio alloués)")
print(f"avec en plus le modèle de simple précision du bras « defaut » (fuite hypothétique) : "
      f"{poids_gio*2 + poids_gio + kv_gio + 2*1024*4722**2/2**30:.2f} Gio dès L=4722 (> 79,44 Gio de la carte)")
