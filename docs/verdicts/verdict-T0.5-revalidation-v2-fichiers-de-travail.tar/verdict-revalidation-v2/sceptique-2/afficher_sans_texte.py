"""Affiche un JSON en masquant toute chaîne de plus de 400 caractères (règle D-20)."""
import json, sys
def masquer(x, chemin=""):
    if isinstance(x, dict):
        return {k: masquer(v, chemin + "." + str(k)) for k, v in x.items()}
    if isinstance(x, list):
        return [masquer(v, chemin + "[]") for v in x]
    if isinstance(x, str) and len(x) > 400:
        return f"<chaîne masquée, {len(x)} caractères, chemin {chemin}>"
    return x
for p in sys.argv[1:]:
    with open(p, encoding="utf-8") as f:
        d = json.load(f)
    print("=====", p)
    print(json.dumps(masquer(d), ensure_ascii=False, indent=1))
