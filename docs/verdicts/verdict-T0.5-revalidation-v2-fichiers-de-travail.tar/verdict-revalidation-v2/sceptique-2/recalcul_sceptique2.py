"""Recalcul indépendant (sceptique 2) du verdict T0.5 revalidation v2.

Lecture seule. Ne lit que des nombres, des drapeaux, des empreintes et des longueurs (règle D-20) :
aucun champ de texte des fiches (texte, ensemble, propositions, énoncés) n'est affiché ni comparé.
Usage : PYTHONPATH=src python recalcul_sceptique2.py <racine du clone> <fichier de sortie json>
"""
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np

RACINE = Path(sys.argv[1]).resolve()
SORTIE = Path(sys.argv[2])
RUN = "20261011-225701-t05-revalidation-reel"
DIAG = RACINE / "diag" / RUN
constats, ecarts = [], []


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def note(nom, attendu, obtenu, egal=None):
    ok = (attendu == obtenu) if egal is None else egal
    constats.append({"constat": nom, "attendu": attendu, "obtenu": obtenu, "egal": bool(ok)})
    if not ok:
        ecarts.append(nom)
    return ok


def finite(x):
    return float("inf") if x is None or x != x else float(x)


# ---------- 1. Sceaux ----------
sys.path.insert(0, str(RACINE / "src"))
from controle_ia.manifeste import verifier_resultat, lire_manifeste, config_canonique  # noqa: E402
from controle_ia.manifeste import graines as graines_module  # noqa: E402
from controle_ia.environnements import revalider_pilote_a as R  # noqa: E402

fichiers = sorted(p.name for p in DIAG.glob("*.json"))
note("fichiers de résultats", ["chemin-defaut.json", "episodes-defaut.json", "lecture-defaut.json",
                               "lecture-math.json", "mesures-defaut.json", "resume.json"], fichiers)
corps = {}
for nom in fichiers:
    corps[nom] = verifier_resultat(RACINE, DIAG / nom)       # lève si sceau, manifeste ou rattachement faux
    compagnon = (DIAG / (nom + ".sha256")).read_text().split()
    note(f"sceau {nom}", compagnon[0], sha(DIAG / nom))
manifeste, sha_m = lire_manifeste(RACINE / "runs" / RUN / "manifeste.json")
note("sha du manifeste", "06ee7ed9776427b91bd892de630c9bab462d15e2d922409dabe3ae7eb9f13fbb", sha_m)
note("commit du manifeste", "8f74adaa4b7912f87c9d22ec1594a12910d1930a", manifeste["commit"])
note("préenregistrement du manifeste",
     {"chemin": "prereg/T0.5-revalidation-equivalence-pilote-v2.md",
      "sha256": "4ff2b07548e90fc515fe8944a789bf44267be6e239dee02d2b479e9c701dcc61"},
     manifeste["preenregistrement"])
note("sha du préenregistrement sur disque", "4ff2b07548e90fc515fe8944a789bf44267be6e239dee02d2b479e9c701dcc61",
     sha(RACINE / "prereg/T0.5-revalidation-equivalence-pilote-v2.md"))
note("décisif, dépôt propre, sans réserve", [True, True, []],
     [manifeste["decisif"], manifeste["depot_propre"], manifeste["reserves"]])

# ---------- 2. Configuration ----------
config_fichier = json.loads((RACINE / "prereg/T0.5-revalidation-config-v1.json").read_text(encoding="utf-8"))
note("empreinte canonique de la configuration citée",
     "50930b3794216c3b857cd906d8b2066eb495534d637041f4d089aa00a9edeefb",
     hashlib.sha256(config_canonique(config_fichier)).hexdigest())
cm = dict(manifeste["config"])
ajoutees = {k: cm.pop(k) for k in ("taches_entrainement", "taches_entrainement_sha256", "taches_evaluation",
                                   "taches_evaluation_sha256")}
note("configuration du manifeste = configuration citée (hors 4 clés de tâches)", config_fichier, cm)
note("sha des tâches d'entraînement",
     "8d20a698d76baa8a42cd1494227fc411ef043d24a67a413e5cf812541166a4fd",
     sha(RACINE / ajoutees["taches_entrainement"]))
note("sha des tâches d'évaluation",
     "76cdeace861d2fff45ca732c55c2d97611dcd47edc7c27d62bdad4c37755e67e",
     sha(RACINE / ajoutees["taches_evaluation"]))
C = config_fichier
seuils = {k: C[k] for k in ("tolerance_equivalence", "marge_q99", "actions_min_comparees", "part_min_contexte_couvert",
                            "memoire_pic_max_gio", "duree_max_episodes_pilote_s", "rho_max",
                            "positions_min_controle_negatif", "actions_min_controle_negatif",
                            "fraction_min_controle_negatif", "nombre_taches", "lot", "T", "N", "max_nouveaux",
                            "transcriptions_repere", "duree_max_s", "duree_max_bras_s", "bras", "couches",
                            "fraction_equivalence", "statistique_equivalence")}
seuils["chemin"], seuils["controle_positif"] = C["chemin"], C["controle_positif"]
note("seuils gelés (texte du préenregistrement, section Seuil et Configuration)",
     {"tolerance_equivalence": 0.2, "marge_q99": 0.15, "actions_min_comparees": 40, "part_min_contexte_couvert": 0.9,
      "memoire_pic_max_gio": 70, "duree_max_episodes_pilote_s": 7800, "rho_max": 3,
      "positions_min_controle_negatif": 4, "actions_min_controle_negatif": 10, "fraction_min_controle_negatif": 0.95,
      "nombre_taches": 16, "lot": 8, "T": 10, "N": 1, "max_nouveaux": 400, "transcriptions_repere": 2,
      "duree_max_s": 12600, "duree_max_bras_s": 6300, "bras": ["defaut", "math"], "couches": [7, 15, 23],
      "fraction_equivalence": 1.0, "statistique_equivalence": "q99",
      "chemin": C["chemin"], "controle_positif": C["controle_positif"]},
     seuils, egal=all([
         seuils["tolerance_equivalence"] == 0.2, seuils["marge_q99"] == 0.15, seuils["actions_min_comparees"] == 40,
         seuils["part_min_contexte_couvert"] == 0.9, seuils["memoire_pic_max_gio"] == 70,
         seuils["duree_max_episodes_pilote_s"] == 7800, seuils["rho_max"] == 3,
         seuils["positions_min_controle_negatif"] == 4, seuils["actions_min_controle_negatif"] == 10,
         seuils["fraction_min_controle_negatif"] == 0.95, seuils["nombre_taches"] == 16, seuils["lot"] == 8,
         seuils["T"] == 10, seuils["N"] == 1, seuils["max_nouveaux"] == 400, seuils["transcriptions_repere"] == 2,
         seuils["duree_max_s"] == 12600, seuils["duree_max_bras_s"] == 6300, seuils["bras"] == ["defaut", "math"],
         seuils["couches"] == [7, 15, 23], seuils["fraction_equivalence"] == 1.0,
         seuils["statistique_equivalence"] == "q99",
         C["chemin"].get("T") == 5 and abs(C["chemin"].get("tolerance") - 3e-3) < 1e-15,
         C["controle_positif"] == {"T": 5, "decalage_positions": 1, "positions_min": 4, "actions_min": 10,
                                   "fraction_min": 0.95}]))

# ---------- 3. Graines (R9) ----------
ids_ep = [f["episode"] for f in corps["episodes-defaut.json"]["resultat"]["fiches"]]
cles = ids_ep + [f"chemin/{e}" for e in ids_ep] + [f"controle-positif/{e}" for e in ids_ep] + ["modele-jouet"]
ent = 120571628831802510081029698987406594891
recalc = {}
for t in cles:
    cle = int.from_bytes(hashlib.sha256(t.encode("utf-8")).digest()[:8], "big")
    ss = np.random.SeedSequence(ent, spawn_key=(cle,))
    recalc[t] = {"entropie": str(ent), "spawn_key": [str(cle)], "etat_controle": [int(x) for x in ss.generate_state(2)]}
note("graines recalculées (SeedSequence, entropie citée) = manifeste", manifeste["graines"], recalc)
note("nombre de graines", 49, len(manifeste["graines"]))

# ---------- 4. Plan : 16 tâches aux énoncés les plus longs ----------
def charger(p):
    brut = json.loads((RACINE / p).read_text(encoding="utf-8"))
    return brut["resultat"]["taches"] if "resultat" in brut else brut["taches"]


ent_t, eva_t = charger(ajoutees["taches_entrainement"]), charger(ajoutees["taches_evaluation"])
lg = [len(t["questions"]) for t in ent_t]                       # longueurs seulement
rangs = sorted(range(len(ent_t)), key=lambda i: (-lg[i], i))[:16]
choisies = sorted(rangs)
note("épisodes des fiches = 16 tâches aux énoncés les plus longs, ordre de la liste",
     [f"{ent_t[i]['identifiant']}/e0" for i in choisies], ids_ep)
lg_ch = sorted(lg[i] for i in choisies)
lg_ev = sorted(len(t["questions"]) for t in eva_t)
dom = {"longueur_max_choisies": lg_ch[-1], "longueur_min_choisies": lg_ch[0],
       "longueur_max_evaluation": lg_ev[-1], "longueur_q90_evaluation": float(np.quantile(lg_ev, 0.9)),
       "couvre_le_pilote": lg_ch[-1] >= lg_ev[-1]}
resume = corps["resume.json"]["resultat"]
note("domaine des énoncés", resume["domaine_enonces"], dom)
note("nombres de tâches (entraînement, évaluation)", None, [len(ent_t), len(eva_t)], egal=len(eva_t) >= 64)
eval_ids = {t["identifiant"] for t in eva_t}
import re
sv = lambda s: re.sub(r"v\d+$", "", s)
note("aucune tâche d'entraînement retenue n'est une tâche d'évaluation", 0,
     sum(1 for i in choisies if ent_t[i]["identifiant"] in eval_ids or sv(ent_t[i]["identifiant"]) in
         {sv(x) for x in eval_ids}))

# ---------- 5. Bras « defaut » : recalcul propre depuis les fiches ----------
fiches = corps["episodes-defaut.json"]["resultat"]["fiches"]
tol = C["tolerance_equivalence"]
q99, maxima, ctx_comp, remplies, comparees = [], [], [], 0, 0
cn_comp = cn_pass = cn_court = 0
cn_min = float("inf")
zg_q99, zg_parts, zg_comp, zg_pass = [], [], 0, 0
nuls, jet, q99c, sondes_ok, sondes_n = {}, {}, {}, True, 0
q99_par_action = []
jetons_gen = jetons_ctx = jetons_rempl = finies = 0
debuts = []
for f in fiches:
    for a in f["actions"]:
        debuts.append(int(a["debut"]))
        jetons_gen += len(a["ids"])                      # longueur seulement
    eq = f["equivalence"]
    note(f"statistique et tolérance de {f['episode'][:6]}…", ["q99", 0.2], [eq["statistique"], eq["tolerance"]])
    for cle in eq["ecarts_q99"]:
        comparees += 1
        vals = [finite(v) for v in eq["ecarts_q99"][cle].values()]
        q99 += vals
        q99_par_action.append(max(vals))
        maxima += [finite(v) for v in eq["ecarts"][cle].values()]
        lc = int(eq["longueurs_contexte"][cle])
        ctx_comp.append(lc)
        rp = int(eq["lignes"][cle]["remplissage"])
        remplies += int(rp > 0)
        jetons_ctx += lc
        jetons_rempl += rp
        finies += int(bool(eq["lignes"][cle]["finie_avant"]))
        # contrôle négatif de l'action entière (q99), règle P5 réécrite
        zone = eq["controle_negatif_zone_generee"][cle]
        if zone is None or min(v["positions"] for v in zone.values()) < 4:
            cn_court += 1
        else:
            cn_comp += 1
            m = min(float("-inf") if v["q99"] != v["q99"] else v["q99"] for v in zone.values())
            cn_min = min(cn_min, m)
            cn_pass += int(m > tol)
        # garde restreinte à la zone générée
        n = eq["positions_capturees"][cle]
        zg_parts.append((n - lc) / n)
        for c, prof in eq["profils"][cle].items():
            z = prof["generee"]
            if z["jetons"]:
                zg_q99.append(finite(z["q99"]))
                nuls[c] = nuls.get(c, 0) + z["nuls"]
                jet[c] = jet.get(c, 0) + z["jetons"]
        if zone is not None and min(v["positions"] for v in zone.values()) >= 4:
            zg_comp += 1
            # condition suffisante gelée (RV-11) : au moins n − ⌊0,99 (n − 1)⌋ positions au-dessus
            zg_pass += int(all(v["au_dessus"] >= v["positions"] - math.floor(0.99 * (v["positions"] - 1))
                               for v in zone.values()))
        for c, v in eq["ecarts_q99"][cle].items():
            q99c[c] = max(q99c.get(c, 0.0), finite(v))
        s = eq["sondes"][cle]
        sondes_n += 1
        sondes_ok = sondes_ok and bool(s["tableaux_distincts"]) and bool(s["ulp_vu"])

mesures = corps["mesures-defaut.json"]["resultat"]
lecture_d = corps["lecture-defaut.json"]["resultat"]
mes = {"actions_comparees": comparees, "q99_max": max(q99), "ecart_max": max(maxima),
       "contexte_max": max(ctx_comp), "contexte_max_joue": max(debuts), "actions_remplies": remplies}
note("mesures (R1, R5) recalculées", mesures["mesures"], mes)
note("aucune valeur illisible (NaN) parmi les 99e centiles", 0, sum(1 for x in q99 if x == float("inf")))
cn = {"comparables": cn_comp, "passent": cn_pass, "courtes": cn_court, "fraction": cn_pass / cn_comp,
      "min_des_maxima": cn_min}
note("contrôle négatif (R2) recalculé", {k: mesures["controle_negatif"][k] for k in cn}, cn)
zg = {"q99_generee_max": max(zg_q99), "comparables": zg_comp, "passent": zg_pass, "fraction": zg_pass / zg_comp,
      "part_zone_generee_sous_1pc": sum(x < 0.01 for x in zg_parts) / len(zg_parts)}
note("garde restreinte à la zone générée recalculée", lecture_d["zone_generee"], zg)
rep = lecture_d["repere"]
rho = {c: q99c[c] / rep[c]["q99"] for c in q99c}
aud = {"nuls_zone_generee": nuls, "jetons_zone_generee": jet, "rho": rho, "rho_max_observe": max(rho.values()),
       "P9_zone_generee_non_nulle": all(nuls[c] < jet[c] for c in jet), "sondes_conformes": sondes_ok}
note("audit recalculé", lecture_d["audit"], aud)
note("sondes : une par action comparée", 160, sondes_n)
note("chrono : jetons générés", mesures["chrono"]["jetons_generes"], jetons_gen)
note("chrono : jetons de contexte", mesures["chrono"]["jetons_contexte"], jetons_ctx)
note("chrono : jetons de remplissage", mesures["chrono"]["jetons_remplissage"], jetons_rempl)
note("chrono : contextes remplis = contexte + remplissage", mesures["chrono"]["jetons_contexte_remplis"],
     jetons_ctx + jetons_rempl)
note("chrono : lignes finies avant", mesures["chrono"]["lignes_finies_avant"], finies)
note("chrono : longueur remplie maximale = max(contexte + remplissage)", mesures["chrono"]["longueur_remplie_max"],
     max(int(f["equivalence"]["longueurs_contexte"][k]) + int(f["equivalence"]["lignes"][k]["remplissage"])
         for f in fiches for k in f["equivalence"]["ecarts_q99"]))
note("zone générée = jetons générés − lignes non finies avant", jet["7"],
     jetons_gen - (len(q99_par_action) - finies))
# Repère : deux plus longues transcriptions (longueurs seulement)
toutes = [(f["episode"], tr["agent"], len(tr["ids"])) for f in fiches for tr in f.get("transcriptions", [])]
rg = sorted(range(len(toutes)), key=lambda i: (-toutes[i][2], i))[:2]
rt = {f"defaut|{toutes[i][0]}|{toutes[i][1]}": toutes[i][2] for i in sorted(rg)}
note("transcriptions du repère", mesures["repere_transcriptions"], rt)
note("jetons du repère par couche = somme des deux transcriptions", [sum(rt.values())] * 3,
     [rep[c]["jetons"] for c in ("7", "15", "23")])
note("jetons des passes uniques = somme des transcriptions finales", mesures["chrono"]["jetons_passe_unique"],
     sum(t[2] for t in toutes))

# ---------- 6. Phase « chemin » ----------
ch = corps["chemin-defaut.json"]["resultat"]
tol_c, cp = C["chemin"]["tolerance"], C["controle_positif"]
c1 = max(finite(v) for f in ch["sain"] for d in f["equivalence"]["ecarts"].values() for v in d.values())
c2c = c2v = 0
for f in ch["d1"]:
    for prof in f["equivalence"]["profils"].values():
        zs = [p["generee"] for p in prof.values()]
        if any(z["jetons"] < cp["positions_min"] for z in zs):
            continue
        c2c += 1
        c2v += int(all(z["max"] == z["max"] and z["max"] > tol_c for z in zs))
c3c = c3p = 0
c3min = float("inf")
for f in ch["sain"]:
    assert f["equivalence"]["statistique"] == "max" and f["equivalence"]["tolerance"] == tol_c
    for cle, zone in f["equivalence"]["controle_negatif_zone_generee"].items():
        if zone is None or min(v["positions"] for v in zone.values()) < 4:
            continue
        c3c += 1
        m = min(v["max"] for v in zone.values())
        c3min = min(c3min, m)
        c3p += int(m > tol_c)
c3 = "non concluant" if c3c < 10 else ("conforme" if c3p / c3c >= 0.95 else "contraire")
c2 = "non concluant" if c2c < cp["actions_min"] else ("conforme" if c2v / c2c >= cp["fraction_min"] else "contraire")
chemin = {"C1_ecart_max": c1, "C1": c1 <= tol_c, "C2_comparables": c2c, "C2_vus": c2v, "C2": c2, "C3": c3,
          "conforme": c1 <= tol_c and c2 == "conforme" and c3 == "conforme"}
note("phase chemin recalculée", lecture_d["chemin"]["lecture"], chemin)
note("contrôle négatif du chemin", [lecture_d["chemin"]["controle_negatif"][k] for k in
                                    ("comparables", "passent", "min_des_maxima")], [c3c, c3p, c3min])
note("épisodes du chemin (sain, d1) : lot 0, T = 5", [8, 8, 5, 5],
     [len(ch["sain"]), len(ch["d1"]), max(len(f["actions"]) for f in ch["sain"]),
      max(len(f["actions"]) for f in ch["d1"])])
note("épisodes du chemin = lot 0 des fiches", ids_ep[:8], [f["episode"] for f in ch["sain"]])

# ---------- 7. R8 ----------
ch_ = mesures["chrono"]
r8 = (ch_["generation_s"] + ch_["passe_unique_s"]) * 192 / 16
note("R8 recalculée", mesures["duree_projetee_episodes_pilote_s"], r8)
note("épisodes du bras = 16", 16, len(fiches))
note("R8 par le code cité", r8, R.duree_projetee_pilote(ch_, 16))
note("EPISODES_PILOTE du code cité", 192, R.EPISODES_PILOTE)

# ---------- 8. Lecture indépendante des règles gelées ----------
r1 = mes["q99_max"] <= 0.2
marge = r1 and mes["q99_max"] <= 0.15
r2 = "non concluant" if cn_comp < 10 else ("conforme" if cn_pass / cn_comp >= 0.95 else "contraire")
r3 = all(2 * rep[c]["q99"] <= 0.2 for c in rep)
r4 = mesures["rejeu_identique"] is True
r5 = comparees >= 40 and remplies >= 1 and mes["contexte_max"] >= 0.9 * mes["contexte_max_joue"]
r6 = chemin["conforme"]
r7 = mesures["memoire_pic_gio"] <= 70
r8ok = r8 <= 7800
audit_ok = aud["P9_zone_generee_non_nulle"] and aud["sondes_conformes"] and aud["rho_max_observe"] <= 3
conf = all([r1, r2 == "conforme", r3, r4, r5, r6, r7, r8ok, audit_ok])
moi = {"R1": r1, "marge": marge, "R2": r2, "R3": r3, "R4": r4, "R5": r5, "R6": r6, "R7": r7, "R8": r8ok,
       "audit": audit_ok, "conforme": conf, "conforme_avec_marge": conf and marge}
code = lecture_d["lecture"]
note("ma lecture = lecture scellée", {"R1": code["R1_garde_saine"], "marge": code["R1_marge"],
                                      "R2": code["R2_controle_negatif"], "R3": code["R3_seuil_fonde"],
                                      "R4": code["R4_rejeu"], "R5": code["R5_domaine_couvert"],
                                      "R6": code["R6_chemin_defaut"], "R7": code["R7_memoire"],
                                      "R8": code["R8_duree"], "audit": code["audit_conforme"],
                                      "conforme": code["conforme"],
                                      "conforme_avec_marge": code["conforme_avec_marge"]}, moi)
# le code cité, rejoué
lb = R.lire_bras(mesures["mesures"], mesures["controle_negatif"], rep, mesures["rejeu_identique"], C,
                 zone_generee=lecture_d["zone_generee"], audit=lecture_d["audit"],
                 chemin=lecture_d["chemin"]["lecture"], bras="defaut", memoire_pic_gio=mesures["memoire_pic_gio"],
                 duree_projetee_s=mesures["duree_projetee_episodes_pilote_s"])
note("lire_bras rejoué = lecture-defaut", lecture_d["lecture"], lb)
lm = corps["lecture-math.json"]["resultat"]["lecture"]
lbm = R.lire_bras({}, {}, None, None, C, panne=lm["panne"])
note("lire_bras(panne) rejoué = lecture-math", lm, lbm)
note("préfixe de la panne (site du rattrapage l. 516, pendant _jouer_bras)", True,
     lm["panne"].startswith("mémoire : ") and not lm["panne"].startswith("mémoire pendant"))
noyau, prop = R.choisir_noyau({"defaut": lb, "math": lbm})
note("choisir_noyau rejoué", [None, None], [noyau, prop])
note("résumé : noyau, nœud, proposition", [None, True, None],
     [resume["noyau_retenu"], resume["noeud"], resume["proposition_au_noeud"]])
note("résumé : lectures = fichiers de lecture", {"defaut": lecture_d["lecture"], "math": lm}, resume["lectures"])
note("résumé : bras lus et mesurés", ["defaut"], sorted(resume["bras"]))
note("résumé : réserves", ["énoncés de la revalidation plus courts que le plus long énoncé du pilote (RV-5)"],
     resume["reserves"])
# Contre-factuels de la règle : quelle valeur de R8 aurait suffi ?
seuil_mesure = 7800 * 16 / 192
contrefactuels = {
    "R8_projetee_s": r8,
    "depassement_s": r8 - 7800,
    "depassement_relatif": (r8 - 7800) / 7800,
    "generation_plus_passes_mesurees_s": ch_["generation_s"] + ch_["passe_unique_s"],
    "plafond_equivalent_mesure_s": seuil_mesure,
    "secondes_mesurees_a_retirer_pour_conformite": ch_["generation_s"] + ch_["passe_unique_s"] - seuil_mesure,
    "part_de_generation_s_a_retirer": (ch_["generation_s"] + ch_["passe_unique_s"] - seuil_mesure) / ch_["generation_s"],
    "duree_max_s_pilote_si_retenu_formule_gelee": min(15000, math.ceil((1.2 * r8 + 7200) / 60) * 60),
}
# descriptifs
qa = np.array(q99_par_action)
desc = {"q99_par_action_min": float(qa.min()), "q99_par_action_mediane": float(np.median(qa)),
        "q99_par_action_max": float(qa.max()), "actions_q99_au_dessus_0_15": int((qa > 0.15).sum()),
        "q99_max_par_couche": q99c, "actions_ecart_max_au_dessus_0_2": None,
        "zone_generee_part_min": min(zg_parts), "zone_generee_part_mediane": float(np.median(zg_parts)),
        "zone_generee_part_max": max(zg_parts), "zg_q99_au_dessus_0_15": int(sum(x > 0.15 for x in zg_q99)),
        "debit_jetons_par_s": jetons_gen / ch_["generation_s"]}
mx_par_action = [max(finite(v) for v in f["equivalence"]["ecarts"][k].values()) for f in fiches
                 for k in f["equivalence"]["ecarts"]]
desc["actions_ecart_max_au_dessus_0_2"] = int(sum(x > 0.2 for x in mx_par_action))

SORTIE.write_text(json.dumps({"constats": constats, "ecarts": ecarts, "contrefactuels_R8": contrefactuels,
                              "descriptifs": desc, "lecture_independante": moi}, ensure_ascii=False, indent=1,
                             default=str), encoding="utf-8")
print(f"{len(constats)} constats, {len(ecarts)} écarts : {ecarts}")
print(json.dumps(contrefactuels, ensure_ascii=False, indent=1))
print(json.dumps(desc, ensure_ascii=False, indent=1, default=str))
print(json.dumps(moi, ensure_ascii=False))
