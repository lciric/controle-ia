"""Schéma d'un fichier JSON : clés, types, longueurs ; jamais le contenu d'une chaîne (règle D-20)."""
import json, sys
def schema(x, prof=0, max_prof=7, cle=""):
    pad = "  " * prof
    if isinstance(x, dict):
        print(f"{pad}{cle}: dict[{len(x)}]")
        if prof < max_prof:
            # pour les dicts à clés numériques ou nombreuses, n'en montrer que 2
            items = list(x.items())
            montre = items if len(items) <= 25 else items[:2]
            for k, v in montre:
                ks = k if len(str(k)) < 60 else f"<clé de {len(str(k))} car.>"
                schema(v, prof + 1, max_prof, str(ks))
            if len(items) > len(montre):
                print(f"{pad}  … {len(items) - len(montre)} autres clés")
    elif isinstance(x, list):
        print(f"{pad}{cle}: list[{len(x)}]")
        if x and prof < max_prof:
            schema(x[0], prof + 1, max_prof, "[0]")
    elif isinstance(x, str):
        print(f"{pad}{cle}: str (longueur {len(x)})")
    else:
        print(f"{pad}{cle}: {type(x).__name__} = {x!r}" if not isinstance(x, (int, float)) or prof > 2 else f"{pad}{cle}: {type(x).__name__}")
d = json.load(open(sys.argv[1], encoding="utf-8"))
schema(d, max_prof=int(sys.argv[2]) if len(sys.argv) > 2 else 7)
