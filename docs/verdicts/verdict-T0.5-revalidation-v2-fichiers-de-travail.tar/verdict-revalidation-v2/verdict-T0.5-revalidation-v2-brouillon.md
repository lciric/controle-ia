# Verdict — T0.5 — revalidation courte de l'équivalence sur le domaine du pilote — v2 (brouillon)

- **Auteur** : sous-agent neuf (R13), qui n'a écrit ni le préenregistrement ni l'analyse ; il applique les critères gelés avec le code de lecture cité, en lecture seule (aucune écriture dans les dépôts, aucun commit, aucune commande Vast.ai).
- **Date** : 2026-10-12 00:05 UTC. Brouillon non scellé : à sceller, puis à soumettre à Lazar pour GO (R13).
- **Préenregistrement appliqué** : `prereg/T0.5-revalidation-equivalence-pilote-v2.md`, sha256 `4ff2b07548e90fc515fe8944a789bf44267be6e239dee02d2b479e9c701dcc61` ; commit de scellement `8f74adaa4b7912f87c9d22ec1594a12910d1930a` ; code cité `6ec7434119781a3abebac789174101b9ed6ae087`.
- **Run** : `20261011-225701-t05-revalidation-reel` ; clone propre à la tête de la branche `calcul/t05-revalidation-reel-v2`, commit `5b428608575fea8db57e90f47c096229e21074b4`.
- **Règle D-20** : aucun champ de texte des fiches (actions, ensembles, énoncés) n'a été ouvert ni affiché ; seuls des nombres, des drapeaux, des empreintes et des identifiants d'épisode ont été lus. Les longueurs d'énoncés citées viennent de `resume.json` et du recalcul par `taches_d_entrainement`, sans affichage de texte.

Sauf mention contraire, les résultats sont sous `diag/20261011-225701-t05-revalidation-reel/` ; leurs empreintes complètes sont à la section 6.

## 1. Verdict

**Nœud : aucun noyau n'est retenu pour le pilote ; rien ne tourne.**
Le bras « defaut » est non conforme par le seul critère R8 : la durée projetée des épisodes du pilote vaut 8 089,62 s, pour un plafond gelé de 7 800 s. Tous ses autres critères et son audit sont conformes, R1 compris avec marge (0,1354 ≤ 0,15).
Le bras « math » est non conforme : une panne de mémoire a été signalée pendant ses épisodes, et aucune mesure n'a été écrite. Aucun des deux cas de « proposition prête » ne s'applique.

## 2. Règle appliquée

**Règle de choix gelée** (section « Règle de choix gelée » ; `choisir_noyau`) :
1. Premier bras conforme avec marge, dans l'ordre « defaut » puis « math » : **aucun**. « defaut » : `conforme` faux (R8) ; « math » : `conforme` faux (panne).
2. Sinon, nœud ; proposition prête dans deux cas.
   - « un bras conforme sans marge (0,15 < R1 ≤ 0,2) » : **ne s'applique pas**. Aucun bras n'est conforme, et le R1 de « defaut » (0,1354) est d'ailleurs dans la marge.
   - « un bras qui ne manque que le contrôle négatif de l'action entière, sa garde restreinte étant conforme » : **ne s'applique pas**. « defaut » a un contrôle négatif conforme (160 sur 160) et manque R8 ; son drapeau `aveugle_action_entiere_seulement` est faux (`lecture-defaut.json` → `resultat.lecture.aveugle_action_entiere_seulement`). « math » est en panne.
   - Le code de lecture rend la même issue : `choisir_noyau` → (aucun noyau, aucune proposition) ; `resume.json` → `resultat.noyau_retenu` = null, `resultat.proposition_au_noeud` = null, `resultat.noeud` = true.

**Lignes de la table des critères gelés qui s'appliquent** (texte gelé, mot pour mot) :
- « aucun bras conforme avec marge | **nœud** : rien ne tourne ; proposition à Lazar, prête si un bras est conforme sans marge ou ne manque que le contrôle négatif de l'action entière (règle de choix) ; sinon, options à proposer (seuil refondé sur le repère du domaine, autre carte, autre lot : chacun un domaine nouveau, à revalider) »
- Bras « math » : « panne de mémoire signalée dans un bras, y compris pendant son repère ou sa phase « chemin » (W-2) | consignée ; ce bras est non conforme ; la règle s'applique à l'autre »
- « énoncés de la revalidation plus courts que le plus long du pilote | réserve (domaine partiellement couvert) »

**Ce que prévoit le texte gelé** quand aucune proposition n'est prête : « sinon, options à proposer (seuil refondé sur le repère du domaine, autre carte, autre lot : chacun un domaine nouveau, à revalider) ». Ce verdict n'en propose ni n'en choisit aucune : la résolution du nœud revient à Lazar. La formule gelée de `duree_max_s` du pilote n'est pas appliquée, puisqu'aucun noyau n'est retenu.

**Lignes qui ne s'appliquent pas** :
- **Run arrêté** : ne s'applique pas. Il n'y a pas d'`arret.json` pour ce run ; le résumé est écrit et l'instance a consigné « run terminé » à 23:44:09 UTC (`traces/t05-20261011-234411-9q7N/journal.txt`).
- **R2 ou R5 non concluant** : ne s'applique pas ; les deux sont conformes pour « defaut ».
- **Deux bras « contraire » en R2** : ne s'applique pas.
- **Audit en défaut** : ne s'applique pas.
- **Un bras qui ne manque que l'audit** : ne s'applique pas.
- **ρ > 3 au noyau « math »** : sans objet, le bras « math » n'a pas été mesuré.
- **Écarts tous nuls** : ne s'applique pas ; aucun écart nul sur 36 375 jetons de zone générée, à chaque couche.
- **Part des actions à zone générée sous 1 % > 0,2 dans le bras retenu** : sans objet, aucun bras n'est retenu.

## 3. Tableau par bras

### Bras « defaut »

Carte `NVIDIA A100-SXM4-80GB` (`resume.json` → `resultat.carte`). Noyaux permis : flash, mémoire efficace, cuDNN et « math » (`mesures-defaut.json` → `resultat.noyaux_permis`).

| critère | grandeur (fichier → clé) | valeur | seuil gelé | conforme |
|---|---|---|---|---|
| R1, garde saine | `mesures-defaut.json` → `resultat.mesures.q99_max` | 0,13539323886582585 | ≤ 0,2 | oui |
| R1, marge | même clé | 0,13539323886582585 | ≤ 0,15 | oui |
| R2, contrôle négatif de l'action entière (99e centile) | `mesures-defaut.json` → `resultat.controle_negatif` (`comparables`, `passent`, `fraction`, `min_des_maxima`) | 160 comparables, 160 passent, fraction 1,0, aucune action courte ; plus petit 99e centile décalé : 0,8836 | ≥ 95 % des comparables, au moins 10 comparables | oui (« conforme ») |
| R3, repère | `lecture-defaut.json` → `resultat.repere.{7,15,23}.q99` | q99 : 0,03251 / 0,08003 / 0,08761, soit 2 × q99 = 0,0650 / 0,1601 / 0,1752 (couches 7 / 15 / 23 ; 9 714 jetons par couche) | 2 × q99 ≤ 0,2 à chaque couche | oui |
| R4, rejeu du lot 0 | `mesures-defaut.json` → `resultat.rejeu_identique` | vrai | identité au bit près | oui |
| R5, domaine | `mesures-defaut.json` → `resultat.mesures` (`actions_comparees`, `actions_remplies`, `contexte_max`, `contexte_max_joue`) | 160 ; 140 ; 4 752 ; 4 752 | ≥ 40 ; ≥ 1 ; ≥ 0,9 × 4 752 = 4 276,8 | oui |
| R6, chemin (simple précision, noyau par défaut, lot 0, T = 5) | `lecture-defaut.json` → `resultat.chemin.lecture` (`C1_ecart_max`, `C2_vus`, `C2_comparables`, `C3`) et `resultat.chemin.controle_negatif` | C1 : 3,0496e-4 ; C2 : 40 vus sur 40 ; C3 : conforme (40 sur 40, plus petit maximum décalé 1,185) | C1 ≤ 3e-3 ; C2 ≥ 95 %, au moins 10 ; C3 conforme | oui |
| R7, mémoire | `mesures-defaut.json` → `resultat.memoire_pic_gio` | 24,02 Gio | ≤ 70 Gio | oui |
| **R8, durée projetée des épisodes du pilote** | `mesures-defaut.json` → `resultat.duree_projetee_episodes_pilote_s` | **8 089,6213 s** = (665,8512 + 8,2839) × 192 / 16 (`resultat.chrono.generation_s`, `resultat.chrono.passe_unique_s`) | ≤ 7 800 s | **non** (dépassement de 289,62 s, soit 3,71 %) |
| Audit, P9 | `lecture-defaut.json` → `resultat.audit.nuls_zone_generee`, `resultat.audit.jetons_zone_generee` | 0 écart nul sur 36 375 jetons, à chaque couche | au moins un écart non nul par couche | oui |
| Audit, sondes | `lecture-defaut.json` → `resultat.audit.sondes_conformes` | vrai (160 actions sur 160 : tableaux distincts, perturbation d'une unité au dernier rang vue) | toutes conformes | oui |
| Audit, ρ | `lecture-defaut.json` → `resultat.audit.rho` | 1,139 / 1,403 / 1,545 (couches 7 / 15 / 23) | ≤ 3 (au-dessus : non conforme au noyau par défaut) | oui |
| Garde restreinte à la zone générée (mesure secondaire) | `lecture-defaut.json` → `resultat.zone_generee` | 99e centile maximal 0,1699 ; contrôle négatif 160 sur 160 ; part sous 1 % : 0,0 | ≤ 0,2 ; ≥ 95 %, au moins 10 | conforme (`resultat.lecture.garde_zone_generee_conforme` vrai) |
| **Bras** | `lecture-defaut.json` → `resultat.lecture.conforme`, `resultat.lecture.conforme_avec_marge` | faux ; faux | R1 à R8 et audit ; marge R1 ≤ 0,15 | **non conforme** |

### Bras « math »

| critère | grandeur (fichier → clé) | valeur | seuil gelé | conforme |
|---|---|---|---|---|
| Panne de mémoire | `lecture-math.json` → `resultat.lecture.panne` | « mémoire : CUDA out of memory. Tried to allocate 6.06 GiB. GPU 0 has a total capacity of 79.44 GiB of which 2.94 GiB is free. […] 68.64 GiB is allocated by PyTorch, and 7.33 GiB is reserved by PyTorch but unallocated. […] » | table : panne de mémoire signalée, bras non conforme | non |
| R1 à R8, audit | aucun fichier | non mesurés. La panne a été rattrapée dans `_jouer_bras` (préfixe « mémoire : », `revalider_pilote_a.py`, l. 516), c'est-à-dire pendant les épisodes, le rejeu du lot 0 ou les passes du repère en demi-précision, avant toute écriture : il n'y a ni `episodes-math.json` ni `mesures-math.json`, et `resume.json` → `resultat.bras` ne contient que « defaut ». | — | non lus |
| **Bras** | `lecture-math.json` → `resultat.lecture.conforme`, `resultat.lecture.conforme_avec_marge` | faux ; faux | — | **non conforme** |

## 4. Recalcul

**Méthode.** Le recalcul part des résultats scellés et appelle le code cité, importé depuis `src/` du clone (`PYTHONPATH=src`, interpréteur `/home/user/controle-ia/.venv/bin/python`, sans écriture de code compilé). Fonctions appelées :
- module `controle_ia.manifeste` : `verifier_resultat`, `lire_manifeste`, `config_canonique`, `graines` ;
- module de lecture : `exiger_citations`, `taches_d_entrainement`, `domaine_et_garde`, `garde_zone_generee`, `plus_longues_transcriptions`, `audit_symetrie`, `lire_chemin`, `duree_projetee_pilote`, `lire_bras`, `choisir_noyau` ;
- `controle_ia.harnais.episode.bilan_controle_negatif`.

Fichiers de travail (hors dépôt) :
- `verdict-revalidation-v2/recalcul_verdict.py` (`f2b843d8c5049d947308e6068a19b90e5709d5b0b69edfaf9192ba1526eba38f`) ;
- journal `recalcul-journal.txt` (`e44ffb4852a4efcd6ced2bbfd357e60907d78784c6692c941b0c1fced55b053a`) ;
- sortie `recalcul-sortie.json` (`e36b796f927b93baf7f1bdccd05f9013a524bdd71af74e3550a0f78511f470a0`) ;
- exploration de structure sans texte `schema_fiches.py` (`70cae427a4dc813e912a6f7db76bc2417e3b215a73004daaa84c6da63f87b2eb`).

**Résultat : 75 constats, 0 écart.** Les valeurs recalculées sont égales, à l'identique (flottants égaux, drapeaux et dictionnaires égaux), à celles de `resume.json`, `lecture-defaut.json`, `lecture-math.json`, `mesures-defaut.json` et de `run.json` de l'instance.

**Sceaux et chaîne de provenance**
- `verifier_resultat` passe pour les six résultats : chaque résultat est intact, son manifeste est intact et le rattachement par empreinte est vérifié (`manifeste_sha256` = `06ee7ed9…`).
- `lire_manifeste` passe : l'empreinte de la configuration du manifeste est cohérente.
- La vérification de l'arbre scellé du clone (`verifier-arbre .`) donne « arbre intact ».
- Les empreintes de lancement (`docs/sha256sums-lancement-v2.txt`) sont conformes.

**Contenu du manifeste**
- Commit `8f74adaa4b7912f87c9d22ec1594a12910d1930a`.
- Préenregistrement `prereg/T0.5-revalidation-equivalence-pilote-v2.md`, sha256 `4ff2b075…dcc61`, identique au fichier sur disque et à celui du commit `8f74ada`.
- `decisif` vrai, `depot_propre` vrai, aucune réserve.

**Arbre gelé et scripts**
- L'arbre gelé (`CHEMINS_GELES`) est identique entre `6ec7434`, `8f74ada` et `5b42860` ; `src/`, `scripts/` et `tests/` sont identiques à `6ec7434`.
- Les deux commits de résultats n'ajoutent que 21 fichiers, sous `diag/`, `runs/` et `traces/`.
- Les scripts de l'instance au commit `8f74ada` ont les empreintes citées (`59f49aab…de73`, `9e053ae6…1502841`).

**Configuration**
- L'empreinte canonique de `prereg/T0.5-revalidation-config-v1.json` est `50930b3794216c3b857cd906d8b2066eb495534d637041f4d089aa00a9edeefb`, l'empreinte citée.
- La configuration du manifeste, privée des quatre clés des tâches ajoutées par le lanceur, est identique au fichier cité.
- La clé `config_sha256` du manifeste (`2aa955bb…9025`) est l'empreinte canonique de la configuration augmentée de ces quatre clés ; ce n'est pas un écart.

**Citations et graines**
- `exiger_citations` rejouée passe : configuration, tâches d'entraînement (`8d20a698…a4fd`), tâches d'évaluation (`76cdeace…755e67e`), index des invites (`adb4b8bc…e2d9`) et entropie `120571628831802510081029698987406594891`.
- Les 49 graines recalculées par `SeedSequence` depuis l'entropie citée et les clés du plan sont égales à celles du manifeste (R9).

**Plan et domaine des énoncés**
- `taches_d_entrainement` redonne les 16 épisodes dans l'ordre des fiches.
- Le domaine des énoncés est égal à `resume.json` → `resultat.domaine_enonces`.

**Bras « defaut »**
- Fiches : 16 épisodes, 10 actions chacun, toutes comparées (statistique q99, tolérance 0,2).
- `domaine_et_garde`, contrôle négatif (`bilan_controle_negatif` et lecture), `garde_zone_generee` et `audit_symetrie` (avec le repère scellé) sont égaux aux fichiers.
- Repère : les deux plus longues transcriptions (4 932 et 4 782 jetons) sont égales à `mesures-defaut.json` → `resultat.repere_transcriptions`, et leur somme vaut le nombre de jetons du repère (9 714).
- Phase « chemin » : contrôle négatif du passage sain (statistique « max », tolérance 3e-3 ; 8 épisodes du lot 0, 5 actions chacun) et `lire_chemin` sont égaux.
- `duree_projetee_pilote(chrono, 16)` vaut 8 089,6213105190545, égal à `mesures-defaut.json` et à `resume.json`.
- `lire_bras` est égal à `lecture-defaut.json` → `resultat.lecture` et à `resume.json` → `resultat.lectures.defaut`.

**Bras « math »** : `lire_bras(…, panne=…)` est égal à `lecture-math.json` et à `resume.json`.

**Choix et réserves**
- `choisir_noyau` rend (aucun noyau, aucune proposition), égal à `resume.json`.
- Réserves recalculées égales à `resume.json` → `resultat.reserves`.

**Cohérence du chronométrage** (`mesures-defaut.json` → `resultat.chrono`, contre les fiches) :

| grandeur | valeur | contrôle |
|---|---|---|
| jetons générés | 36 397 | somme des jetons par action |
| jetons de contexte | 428 157 | somme des longueurs de contexte |
| jetons de remplissage | 45 915 | somme des remplissages |
| contextes remplis | 474 072 | contexte + remplissage |
| lignes finies avant | 138 | décompte des fiches |
| jetons des passes uniques | 70 274 | somme des transcriptions finales |
| passes de décodage | 6 480 | somme, par lot et par pas, de la plus longue action moins 1 |
| longueur remplie maximale | 4 752 | plus grand contexte augmenté de son remplissage |

Tous ces décomptes sont égaux.

**Relu, non recalculable depuis les résultats scellés**
- Le rejeu : les empreintes du rejeu ne sont pas gardées, seul le drapeau l'est.
- Les statistiques du repère : les activations ne sont pas gardées ; R3 est recalculé depuis les statistiques scellées.
- Le pic de mémoire.
- Les durées chronométrées.

## 5. Réserves

- **RV-5, énoncés (réserve de la table, acquise d'avance)**.
  - Les 16 énoncés retenus vont de 3 709 à 5 340 caractères.
  - Le plus long énoncé des tâches d'évaluation du pilote compte 6 786 caractères, et leur 90e centile 4 902,8 (`resume.json` → `resultat.domaine_enonces`, `couvre_le_pilote` = false).
  - Le domaine n'est donc que partiellement couvert.
  - La réserve figure dans `resume.json` → `resultat.reserves`. Le préenregistrement la déclare connue d'avance (section « Transparence ») ; elle n'entre pas dans R5.
- **ρ > 3 au noyau « math »** : sans objet, le bras « math » n'a pas été mesuré. Au noyau par défaut, le ρ maximal vaut 1,545, sous 3.
- **Part des actions à zone générée sous 1 % > 0,2 dans le bras retenu** : sans objet, aucun bras n'est retenu. Pour mémoire, « defaut » donne 0,0 (`lecture-defaut.json` → `resultat.zone_generee.part_zone_generee_sous_1pc`) ; sa plus petite part de zone générée par action est 2,97 %.
- Aucune autre réserve prévue par la table ne s'applique : pas d'écarts tous nuls, pas d'audit en défaut, pas de deux bras « contraire ».

## 6. Fichiers lus (sha256 complets)

| fichier | sha256 | rôle |
|---|---|---|
| `prereg/T0.5-revalidation-equivalence-pilote-v2.md` | `4ff2b07548e90fc515fe8944a789bf44267be6e239dee02d2b479e9c701dcc61` | critères gelés |
| `prereg/T0.5-revalidation-config-v1.json` | `ee0945a8b29c54d0918b8c653303a8354bec82a02af1f79e855949ed0743f618` (canonique : `50930b3794216c3b857cd906d8b2066eb495534d637041f4d089aa00a9edeefb`) | configuration |
| `runs/20261011-225701-t05-revalidation-reel/manifeste.json` | `06ee7ed9776427b91bd892de630c9bab462d15e2d922409dabe3ae7eb9f13fbb` | manifeste |
| `diag/…/resume.json` | `d759b05df286913c5a1226657aea80cced67fdd33ef4896a3ee4dacabf47b639` | résumé |
| `diag/…/lecture-defaut.json` | `3c8e76ba3dfd4eba5990d01aaa511c03b129e55349aaa910f853b33ac5a432c7` | lecture, repère, audit, zone générée, chemin |
| `diag/…/lecture-math.json` | `bcebcc576ba2ee73de8cc7b22372a87166cf4f8f161945166d8cd1e47eb5b8c5` | panne du bras « math » |
| `diag/…/mesures-defaut.json` | `bdc78cb29f94b787851b35641644bfebaeb09c9983267c3f95bc34be1ef8a1b0` | mesures, contrôle négatif, chronométrage, mémoire |
| `diag/…/episodes-defaut.json` | `89c9c9d14ea6ee1744238605fe2b1f2bc5de30043fa6ff59366f59526a6cf455` | fiches (nombres seulement) |
| `diag/…/chemin-defaut.json` | `1a0e389eca7a57119d18f8befb3cc4203d6db8a04cc25a941e84ac8c50e90881` | phase « chemin » (nombres seulement) |
| `donnees/20261007-082440-t05-extraction/taches-entrainement.json` | `8d20a698d76baa8a42cd1494227fc411ef043d24a67a413e5cf812541166a4fd` | plan, longueurs (sans affichage) |
| `donnees/20261007-082440-t05-extraction/taches-evaluation.json` | `76cdeace861d2fff45ca732c55c2d97611dcd47edc7c27d62bdad4c37755e67e` | longueurs (sans affichage) |
| `docs/sources/invites-2606.08892-v1/index.json` | `adb4b8bca7788baf2c4714df96dcdcc2c5043e8f1943542d0fbe1863491ae2d9` | citation vérifiée |
| `traces/t05-20261011-234411-9q7N/journal.txt` | `c516228840ca8c7d4d524f88075873b82eae9a24d630d85e3b5e0d430219b273` | journal de l'instance |
| `traces/t05-20261011-234411-9q7N/run.json` | `32de0e562715a76be5ac4d6e29a813d383d830ea18ce56d9f6e92c0b702cbbdd` | sortie du lanceur |
| `traces/t05-20261011-234411-9q7N/run.err` | `608f6f9a10b73f6f30c1fe8fbd7fd8f34e408f3157435fb79874ed88e1ff3b26` | erreurs de l'instance |
| `traces/t05-20261011-234411-9q7N/tests.txt` | `3ec427e9297c1c4e99b4327f83b98141c8a70bd19a898f0e5e19fda89fb6dbef` | « 670 passed in 491.38s » |
| `traces/t05-20261011-234411-9q7N/tests.err` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | vide |
| `traces/t05-20261011-234411-9q7N/nvidia-smi.txt` | `cfaee76e8b48a2f4e750b495ab2645474316257fc8eccebde415aea023a8bb6f` | carte |
| `traces/t05-20261011-234411-9q7N/empreintes.sha256` | `a3a58430be36141a34cd00ebf4c441d98d8dbde817e405d400cb60e645879163` | empreintes des traces |
| `src/controle_ia/environnements/revalider_pilote_a.py` | `5c8d109d55f22e75bb385eb8c1a728bcdc7e4f151157738ef93c861ced13cea7` | code de lecture |
| `src/controle_ia/environnements/pilote_a.py` | `624761e2831a3fa14ccc1fe817d38a59014c9ef157e600cbd67e411607869bfc` | jeu des épisodes |
| `src/controle_ia/harnais/episode.py` | `79113b4973d64bbcf0af16b2d7114c009b34132e1392e95ff83cef4d0a488c32` | chronométrage, contrôle négatif |
| `src/controle_ia/harnais/activations.py` | `adeb5856d430f3a6163989c2a53c8ced459235c6dcdd03834b694404c57e0095` | écarts, profils, sondes |
| `src/controle_ia/harnais/validation_reelle.py` | `d25e4cd92d73eef4d2bd6c7d17328daf49a49c76eab7afd91500d9c04ded8289` | arbre gelé, noyau |
| `src/controle_ia/manifeste.py` | `1a5c7464523e224ca29d62ab70d83f9e7043d9bde3000ef1a4adc9ed74c8188d` | sceaux, graines |
| `src/controle_ia/scellement.py` | `93beeb1c8aae75463afc98e76ffb330b1e4f26be9c08ae8fee539a2df6a94ef2` | sceaux |
| `scripts/amorce_instance_t05.sh` | `59f49aab394c4b7659b716792203663243a106355fbabf666bbb1f61ed55de73` | empreinte citée, vérifiée |
| `scripts/pilote_t05_instance.sh` | `9e053ae69bce6a8fb53bae30e368f0fbf849e19dfa355f0d5fdbb08f31502841` | empreinte citée, vérifiée |
| `docs/sha256sums-lancement-v2.txt` | `dbf8f929b437a38081018685ca358864aca4c726f150371f0ce9fa1ed5b41975` | empreintes de lancement |

## 7. Grandeurs descriptives (sans seuil)

Toutes viennent de `episodes-defaut.json`, sauf mention contraire.

**99e centile par action** (maximum sur les couches)
- 160 actions : minimum 0,0352, médiane 0,0660, maximum 0,1354.
- Aucune action au-dessus de 0,15.
- Maximum par couche : 0,0370, 0,1123 et 0,1354 (couches 7, 15 et 23).

**Maximum par action** (grandeur que la garde du 99e centile ne lit pas)
- 139 actions sur 160 dépassent 0,2 ; le maximum vaut 1,1232 (`mesures-defaut.json` → `resultat.mesures.ecart_max`).
- Le repère a aussi des maxima de 0,720 et 0,792 aux couches 15 et 23 (`lecture-defaut.json` → `resultat.repere`).

**Zone générée**
- 99e centile par action : maximum 0,1699 ; 1 action au-dessus de 0,15, aucune au-dessus de 0,2.
- Part de la zone générée dans l'action : minimum 2,97 %, médiane 7,81 %, maximum 25,14 %.

**Chronométrage** (`mesures-defaut.json` → `resultat.chrono`)
- Génération : 665,85 s pour 36 397 jetons, soit 54,7 jetons par seconde, capture comprise.
- Passes uniques : 8,28 s, soit 1,2 % de la projection.
- 42,13 s par épisode dans la projection.
- Premier passage des 16 épisodes, comparaisons comprises : 1 012,18 s (`resultat.duree_s`).
- Plus long contexte rempli : 4 752 jetons.

**Phase « chemin »** (`chemin-defaut.json`)
- Plus grand écart du passage sain : 4,92e-5, 1,54e-4 et 3,05e-4 (couches 7, 15 et 23).
- Sous D1, le plus petit maximum de zone générée parmi les actions comparables vaut 0,2103, au-dessus de 3e-3.

**Run**
- Tests : 670 réussis en 491,38 s (`tests.txt`).
- Run de 22:57:01 à 23:44:09 UTC, soit 2 828 s, pour une échéance de 12 600 s (`journal.txt`).
- Carte de 79,44 Gio (`resume.json` → `resultat.memoire_carte_gio`) ; réglages déterministes acceptés (`resume.json` → `resultat.reglages.deterministe`).

**Comparaison aux prédictions chiffrées** (descriptive ; Rk-1 à Rk-5 lues pour k = « defaut »)
- Rk-1 : attendu de 0,03 à 0,15 ; observé 0,1354.
- Rk-2 : attendu « presque toutes » ; observé 160 sur 160.
- Rk-3 : q99 attendu de 0,03 à 0,09 ; observé 0,0325, 0,0800 et 0,0876.
- Rk-4 : identité attendue ; observée.
- Rk-5 : 160 actions comparées attendues ; 160 observées.
- Rd-6 : C1 attendu de l'ordre de 3,16e-4 ; observé 3,05e-4.
- Rk-7 au noyau « math » : « panne probable au-delà d'environ 4 400 jetons remplis au lot de 8 » ; une panne est observée. Les longueurs remplies propres au bras « math » ne sont pas consignées.
- R8 : aucune valeur prédite, le plafond étant dérivé du budget du pilote ; observé 8 089,62 s.

## 8. Limites (du verdict et des mesures)

1. **Composition de la durée de génération (R8).** Dans `jouer_episodes` (`harnais/episode.py`), `generation_s` est compté depuis l'entrée dans les crochets de capture jusqu'après `relire_crochets_lot`.
   - Il comprend donc la capture des activations de toutes les actions, puisque toutes sont comparées ici (fraction 1,0).
   - Le texte gelé n'exclut de la projection que les comparaisons (« les comparaisons, faites ici sur toutes les actions, n'y entrent pas ») ; il n'exclut pas la capture.
   - La part de la capture n'est mesurée séparément nulle part dans les résultats scellés.
   - Le rejeu du lot 0 et la phase « chemin » ne sont pas chronométrés et n'entrent pas dans la projection.
   - La règle est appliquée telle que gelée : R8 est faux, avec un dépassement de 3,71 %.
2. **Extrapolation linéaire (R8).** La formule gelée projette 16 épisodes (2 lots de 8, énoncés d'entraînement les plus longs) vers les 192 épisodes du pilote par un facteur 12. Elle ne tient pas compte de la distribution des longueurs des énoncés du pilote (voir RV-5).
3. **Bras « math » non mesuré.** La panne est survenue dans `_jouer_bras`, avant toute écriture.
   - Le texte gelé (X-7) ne garde les mesures d'un bras en panne que pour une panne pendant son repère ou sa phase « chemin ». Il n'y a donc pour « math » ni épisodes, ni mesures, ni noyaux permis, ni pic de mémoire, ni longueurs remplies.
   - Le message consigné indique 68,64 Gio alloués par la bibliothèque et une demande de 6,06 Gio.
   - `run.err` montre des échecs d'allocation antérieurs, à 23:38:56, 23:41:29, 23:43:00 et 23:44:05 UTC (de 10,4 à 26,0 Go demandés), suivis de trois échecs de 6,06 Gio à 23:44:07 UTC. Rien ne permet de dire, depuis ces seules traces, dans quel bras ni à quelle étape les premiers se sont produits.
   - Sur le chemin de code de la revalidation, les seuls rattrapages d'une panne de mémoire sont ceux de `revalider_pilote_a.py`, l. 516 et 544. Tous deux consignent la panne et rendent le bras non conforme : aucun repli silencieux.
4. **Grandeurs relues, non recalculées** : rejeu, statistiques du repère, pic de mémoire et durées (section 4). Leur intégrité repose sur les sceaux, qui sont vérifiés.
5. **Traces de l'instance.** Elles ne sont pas scellées par des empreintes compagnons. Elles sont contrôlées contre `empreintes.sha256` et par leur présence au commit `5b428608575fea8db57e90f47c096229e21074b4`.
6. **Règle D-20.** Le contenu des actions n'a pas été lu ; aucun critère gelé n'en dépend.
7. **Champ du verdict.** Ce verdict applique les critères gelés et ne porte aucun jugement sur la suite. Il ne propose aucune résolution du nœud.
