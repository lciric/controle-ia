"""Recalcul du verdict de la revalidation T0.5 v2 depuis les résultats scellés (sous-agent neuf, R13).

Lecture seule : n'écrit que dans le dossier de sortie passé en argument. N'affiche AUCUN texte d'action,
d'ensemble ni d'énoncé (règle D-20) : seulement des nombres, des drapeaux, des empreintes et des identifiants.

Usage : PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=<clone>/src python recalcul_verdict.py <clone> <dossier_sortie>
"""
import hashlib
import json
import sys
from pathlib import Path

RACINE = Path(sys.argv[1]).resolve()
SORTIE = Path(sys.argv[2]).resolve()
RUN = "20261011-225701-t05-revalidation-reel"
PREREG = "prereg/T0.5-revalidation-equivalence-pilote-v2.md"
PREREG_SHA = "4ff2b07548e90fc515fe8944a789bf44267be6e239dee02d2b479e9c701dcc61"
COMMIT_SCELLEMENT = "8f74ada"
CONFIG_CANONIQUE_CITEE = "50930b3794216c3b857cd906d8b2066eb495534d637041f4d089aa00a9edeefb"

from controle_ia.manifeste import (config_canonique, graines, lire_manifeste,  # noqa: E402
                                   verifier_resultat)
from controle_ia.scellement import verifier  # noqa: E402
from controle_ia.harnais.episode import bilan_controle_negatif  # noqa: E402
from controle_ia.environnements import revalider_pilote_a as rv  # noqa: E402

constats = []          # (identifiant, attendu, obtenu, égal)
journal = []


SANS = object()        # aucune valeur attendue (distinct de None, qui est une valeur attendue)


def note(ident, obtenu, attendu=SANS, egal=None):
    if egal is None:
        egal = (obtenu == attendu) if attendu is not SANS else None
    attendu = None if attendu is SANS else attendu
    constats.append({"id": ident, "obtenu": obtenu, "attendu": attendu, "egal": egal})
    journal.append(f"{'OK ' if egal else ('-- ' if egal is None else 'ÉCART')} {ident} : obtenu={obtenu!r}"
                   + ("" if attendu is None else f" ; attendu={attendu!r}"))


def charger(rel):
    return json.loads((RACINE / rel).read_text(encoding="utf-8"))


# ---------------------------------------------------------------- 1. sceaux
D = f"diag/{RUN}"
fichiers = ["resume.json", "lecture-defaut.json", "lecture-math.json", "mesures-defaut.json", "episodes-defaut.json",
            "chemin-defaut.json"]
sceaux = {}
for f in fichiers:
    corps = verifier_resultat(RACINE, RACINE / D / f)          # résultat → manifeste → rattachement
    sceaux[f"{D}/{f}"] = verifier(RACINE / D / f)
    note(f"verifier_resultat({f}) run_id", corps["run_id"], RUN)
m, sha_m = lire_manifeste(RACINE / f"runs/{RUN}/manifeste.json")
sceaux[f"runs/{RUN}/manifeste.json"] = sha_m
note("manifeste : commit (préfixe 8f74ada)", m["commit"][:7], COMMIT_SCELLEMENT)
note("manifeste : préenregistrement, chemin", m["preenregistrement"]["chemin"], PREREG)
note("manifeste : préenregistrement, sha256", m["preenregistrement"]["sha256"], PREREG_SHA)
note("manifeste : décisif", m["decisif"], True)
note("manifeste : dépôt propre", m["depot_propre"], True)
note("manifeste : réserves", m["reserves"], [])
sceaux[PREREG] = verifier(RACINE / PREREG)
note("préenregistrement sur disque, sha256", sceaux[PREREG], PREREG_SHA)

# configuration : fichier scellé, empreinte canonique citée, identité avec le manifeste hors chemins des tâches
cfg_rel = "prereg/T0.5-revalidation-config-v1.json"
sceaux[cfg_rel] = verifier(RACINE / cfg_rel)
config = json.loads((RACINE / cfg_rel).read_text(encoding="utf-8"))
note("configuration : empreinte canonique du fichier", hashlib.sha256(config_canonique(config)).hexdigest(),
     CONFIG_CANONIQUE_CITEE)
ajouts = ("taches_entrainement", "taches_entrainement_sha256", "taches_evaluation", "taches_evaluation_sha256")
cfg_m = {k: v for k, v in m["config"].items() if k not in ajouts}
note("configuration du manifeste, hors des 4 clés des tâches = fichier cité", cfg_m == config, True)
note("configuration du manifeste : config_sha256 = empreinte canonique de config + 4 clés des tâches",
     hashlib.sha256(config_canonique(m["config"])).hexdigest(), m["config_sha256"])

# tâches et index des invites : sceaux et empreintes citées (garde du lanceur rejouée)
ent_rel = m["config"]["taches_entrainement"]
eva_rel = m["config"]["taches_evaluation"]
sceaux[ent_rel] = verifier(RACINE / ent_rel)
sceaux[eva_rel] = verifier(RACINE / eva_rel)
idx_rel = "docs/sources/invites-2606.08892-v1/index.json"
sceaux[idx_rel] = verifier(RACINE / idx_rel)
note("tâches d'entraînement : sha256 = manifeste", sceaux[ent_rel], m["config"]["taches_entrainement_sha256"])
note("tâches d'évaluation : sha256 = manifeste", sceaux[eva_rel], m["config"]["taches_evaluation_sha256"])
entropie = rv.exiger_citations(RACINE / PREREG, config, sceaux[ent_rel], sceaux[eva_rel], sha_index=sceaux[idx_rel])
note("exiger_citations (configuration, tâches, index, entropie citées) : entropie", str(entropie),
     "120571628831802510081029698987406594891")

# domaine des énoncés et plan des épisodes (identifiants seulement ; aucun texte affiché)
choisies, domaine = rv.taches_d_entrainement(RACINE / ent_rel, RACINE / eva_rel, config["nombre_taches"])
ids_episodes = [f"{t['identifiant']}/e0" for t in choisies]
del choisies
resume = charger(f"{D}/resume.json")["resultat"]
note("domaine des énoncés recalculé = resume.json domaine_enonces", domaine, resume["domaine_enonces"])

# graines (R9) : recalculées depuis l'entropie citée et les clés du plan
g_rec = graines(rv.cles_des_graines(ids_episodes), entropie)
note("graines recalculées = manifeste (49 clés)", g_rec == m["graines"], True)
note("nombre de clés de graines", len(m["graines"]), 49)

# ---------------------------------------------------------------- 2. bras « defaut »
ep = charger(f"{D}/episodes-defaut.json")["resultat"]["fiches"]
mes = charger(f"{D}/mesures-defaut.json")["resultat"]
lec_d = charger(f"{D}/lecture-defaut.json")["resultat"]
lec_m = charger(f"{D}/lecture-math.json")["resultat"]
ch = charger(f"{D}/chemin-defaut.json")["resultat"]
bras_d = resume["bras"]["defaut"]

note("fiches : épisodes, dans l'ordre du plan", [f["episode"] for f in ep], ids_episodes)
note("fiches : actions par épisode (T = 10)", sorted({len(f["actions"]) for f in ep}), [10])
note("fiches : actions comparées par épisode (fraction 1,0)", sorted({len(f["equivalence"]["ecarts_q99"]) for f in ep}),
     [10])
note("fiches : statistique et tolérance de la garde", sorted({(f["equivalence"]["statistique"],
                                                              f["equivalence"]["tolerance"]) for f in ep}),
     [("q99", 0.2)])

mesures = rv.domaine_et_garde(ep)
note("mesures recalculées = mesures-defaut.json mesures", mesures, mes["mesures"])
note("mesures recalculées = resume.json bras.defaut.mesures", mesures, bras_d["mesures"])

rapports = [{"episode": f["episode"], "tolerance": f["equivalence"]["tolerance"],
             "statistique": f["equivalence"]["statistique"],
             "controle_negatif_zone_generee": f["equivalence"]["controle_negatif_zone_generee"]} for f in ep]
cn = bilan_controle_negatif(rapports, positions_min=config["positions_min_controle_negatif"])
cn["lecture"] = ("non concluant" if cn["comparables"] < config["actions_min_controle_negatif"]
                 else ("conforme" if cn["fraction"] >= config["fraction_min_controle_negatif"] else "contraire"))
note("contrôle négatif recalculé = mesures-defaut.json controle_negatif", cn, mes["controle_negatif"])
note("contrôle négatif recalculé = resume.json bras.defaut.controle_negatif", cn, bras_d["controle_negatif"])

zone = rv.garde_zone_generee(ep, config["tolerance_equivalence"], config["positions_min_controle_negatif"])
note("zone générée recalculée = lecture-defaut.json zone_generee", zone, lec_d["zone_generee"])
note("zone générée recalculée = resume.json bras.defaut.zone_generee", zone, bras_d["zone_generee"])

repere = lec_d["repere"]
note("repère : lecture-defaut.json = resume.json", repere, bras_d["repere"])
tr = rv.plus_longues_transcriptions(ep, int(config["transcriptions_repere"]), "defaut")
tr_long = {k: len(v) for k, v in tr.items()}
del tr
note("repère : deux plus longues transcriptions (longueurs) = mesures-defaut.json repere_transcriptions", tr_long,
     mes["repere_transcriptions"])
note("repère : jetons par couche = somme des deux transcriptions", sorted({v["jetons"] for v in repere.values()}),
     [sum(tr_long.values())])

audit = rv.audit_symetrie(ep, repere)
note("audit recalculé = lecture-defaut.json audit", audit, lec_d["audit"])
note("audit recalculé = resume.json bras.defaut.audit", audit, bras_d["audit"])

sain, d1 = ch["sain"], ch["d1"]
c_chemin = dict(config, T=config["chemin"]["T"], statistique_equivalence="max",
                tolerance_equivalence=config["chemin"]["tolerance"])
note("chemin : épisodes sain = lot 0", [f["episode"] for f in sain], ids_episodes[:config["lot"]])
note("chemin : épisodes D1 = lot 0", [f["episode"] for f in d1], ids_episodes[:config["lot"]])
note("chemin : actions par épisode, sain et D1 (T = 5)", sorted({len(f["actions"]) for f in sain + d1}), [5])
note("chemin : statistique et tolérance (sain)", sorted({(f["equivalence"]["statistique"],
                                                         f["equivalence"]["tolerance"]) for f in sain}),
     [("max", 0.003)])
rap_sain = [{"episode": f["episode"], "tolerance": f["equivalence"]["tolerance"],
             "statistique": f["equivalence"]["statistique"],
             "controle_negatif_zone_generee": f["equivalence"]["controle_negatif_zone_generee"]} for f in sain]
cn_sain = bilan_controle_negatif(rap_sain, positions_min=c_chemin["positions_min_controle_negatif"])
cn_sain["lecture"] = ("non concluant" if cn_sain["comparables"] < c_chemin["actions_min_controle_negatif"]
                      else ("conforme" if cn_sain["fraction"] >= c_chemin["fraction_min_controle_negatif"]
                            else "contraire"))
note("chemin : contrôle négatif (sain) recalculé = lecture-defaut.json chemin.controle_negatif", cn_sain,
     lec_d["chemin"]["controle_negatif"])
chemin = rv.lire_chemin(sain, cn_sain, d1, config)
note("chemin : lecture recalculée = lecture-defaut.json chemin.lecture", chemin, lec_d["chemin"]["lecture"])
note("chemin : lecture recalculée = resume.json bras.defaut.chemin", chemin, bras_d["chemin"])

rejeu = mes["rejeu_identique"]
note("rejeu (relu, non recalculable : empreintes du rejeu non gardées) = resume.json", rejeu, bras_d["rejeu_identique"])
pic = mes["memoire_pic_gio"]
note("pic de mémoire (relu) = resume.json", pic, bras_d["memoire_pic_gio"])
duree = rv.duree_projetee_pilote(mes["chrono"], len(ids_episodes))
note("durée projetée recalculée = mesures-defaut.json", duree, mes["duree_projetee_episodes_pilote_s"])
note("durée projetée recalculée = resume.json", duree, bras_d["duree_projetee_episodes_pilote_s"])
note("longueur remplie maximale (chrono) = resume.json", mes["chrono"]["longueur_remplie_max"],
     bras_d["longueur_remplie_max"])

lecture_d = rv.lire_bras(mesures, cn, repere, rejeu, config, zone_generee=zone, audit=audit, chemin=chemin,
                         bras="defaut", memoire_pic_gio=pic, duree_projetee_s=duree)
note("lire_bras(defaut) recalculé = lecture-defaut.json lecture", lecture_d, lec_d["lecture"])
note("lire_bras(defaut) recalculé = resume.json lectures.defaut", lecture_d, resume["lectures"]["defaut"])

# ---------------------------------------------------------------- 3. bras « math » (panne)
panne = lec_m["lecture"]["panne"]
lecture_m = rv.lire_bras({}, {}, None, None, config, panne=panne)
note("lire_bras(math, panne) recalculé = lecture-math.json lecture", lecture_m, lec_m["lecture"])
note("lire_bras(math, panne) recalculé = resume.json lectures.math", lecture_m, resume["lectures"]["math"])
note("panne du bras math : rattrapée pendant les épisodes, le rejeu ou les passes en demi-précision (préfixe)",
     panne.startswith("mémoire : ") and not panne.startswith("mémoire pendant"), True)
note("resume.json : pas de bras math dans « bras » (aucune mesure écrite)", "math" in resume["bras"], False)

# ---------------------------------------------------------------- 4. règle de choix
lectures = {"defaut": lecture_d, "math": lecture_m}
noyau_retenu, proposition = rv.choisir_noyau(lectures)
note("choisir_noyau : noyau retenu = resume.json", noyau_retenu, resume["noyau_retenu"])
note("choisir_noyau : proposition = resume.json", proposition, resume["proposition_au_noeud"])
note("nœud = resume.json", noyau_retenu is None, resume["noeud"])
reserves = ([] if domaine["couvre_le_pilote"] else
            ["énoncés de la revalidation plus courts que le plus long énoncé du pilote (RV-5)"]) + \
           [f"rapport au repère au-dessus de {config['rho_max']} au noyau « {b} »" for b, x in lectures.items()
            if x.get("reserve_rho")]
note("réserves recalculées = resume.json", reserves, resume["reserves"])

# sortie de l'instance (traces, non scellées par compagnon ; empreintes listées dans empreintes.sha256)
TR = "traces/t05-20261011-234411-9q7N"
for ligne in (RACINE / TR / "empreintes.sha256").read_text(encoding="utf-8").splitlines():
    h, nom = ligne.split("  ", 1)
    note(f"traces : empreinte de {nom}", hashlib.sha256((RACINE / TR / nom).read_bytes()).hexdigest(), h)
run_json = json.loads((RACINE / TR / "run.json").read_text(encoding="utf-8"))
note("traces : run.json lectures = lectures recalculées", run_json["lectures"], lectures)
note("traces : run.json noyau_retenu", run_json["noyau_retenu"], None)

# ---------------------------------------------------------------- 5. contrôles de cohérence du chronométrage
chrono = mes["chrono"]
jpa = [f["jetons_par_action"] for f in ep]
note("chrono : jetons générés = somme des jetons par action", chrono["jetons_generes"], sum(map(sum, jpa)))
note("chrono : jetons de contexte = somme des longueurs de contexte",
     chrono["jetons_contexte"], sum(v for f in ep for v in f["equivalence"]["longueurs_contexte"].values()))
note("chrono : jetons de remplissage = somme des remplissages",
     chrono["jetons_remplissage"], sum(v["remplissage"] for f in ep for v in f["equivalence"]["lignes"].values()))
note("chrono : contextes remplis = contexte + remplissage", chrono["jetons_contexte_remplis"],
     chrono["jetons_contexte"] + chrono["jetons_remplissage"])
note("chrono : lignes finies avant = décompte des fiches", chrono["lignes_finies_avant"],
     sum(bool(v["finie_avant"]) for f in ep for v in f["equivalence"]["lignes"].values()))
note("chrono : jetons des passes uniques = longueur des transcriptions finales", chrono["jetons_passe_unique"],
     sum(len(t["ids"]) for f in ep for t in f["transcriptions"]))
lot = config["lot"]
passes = 0
for debut in range(0, len(ep), lot):
    for t in range(config["T"]):
        passes += max(f["jetons_par_action"][t] for f in ep[debut:debut + lot]) - 1
note("chrono : passes de décodage = Σ (plus longue action du lot et du pas − 1)", chrono["passes_decodage"], passes)
lr = max(max(v["remplissage"] + f["equivalence"]["longueurs_contexte"][k] for k, v in f["equivalence"]["lignes"].items())
         for f in ep)
note("chrono : longueur remplie maximale = max(contexte + remplissage)", chrono["longueur_remplie_max"], lr)

# ---------------------------------------------------------------- 6. grandeurs descriptives (pour le verdict)
desc = {}
q99_action = sorted(max(v.values()) for f in ep for v in f["equivalence"]["ecarts_q99"].values())
desc["q99_par_action_max_sur_couches"] = {"n": len(q99_action), "min": q99_action[0], "mediane": q99_action[len(q99_action) // 2],
                                          "max": q99_action[-1],
                                          "au_dessus_de_0_15": sum(x > 0.15 for x in q99_action),
                                          "au_dessus_de_0_2": sum(x > 0.2 for x in q99_action)}
par_couche = {}
for c in ("7", "15", "23"):
    vals = [f["equivalence"]["ecarts_q99"][k][c] for f in ep for k in f["equivalence"]["ecarts_q99"]]
    par_couche[c] = max(vals)
desc["q99_max_par_couche"] = par_couche
maxima = sorted(max(v.values()) for f in ep for v in f["equivalence"]["ecarts"].values())
desc["maximum_par_action"] = {"au_dessus_de_0_2": sum(x > 0.2 for x in maxima), "n": len(maxima), "max": maxima[-1]}
gen = sorted(max(p["generee"]["q99"] for p in f["equivalence"]["profils"][k].values())
             for f in ep for k in f["equivalence"]["profils"])
desc["q99_zone_generee_par_action"] = {"max": gen[-1], "au_dessus_de_0_15": sum(x > 0.15 for x in gen),
                                       "au_dessus_de_0_2": sum(x > 0.2 for x in gen)}
parts = sorted((f["equivalence"]["positions_capturees"][k] - f["equivalence"]["longueurs_contexte"][k])
               / f["equivalence"]["positions_capturees"][k] for f in ep for k in f["equivalence"]["ecarts_q99"])
desc["part_zone_generee"] = {"min": parts[0], "mediane": parts[len(parts) // 2], "max": parts[-1]}
desc["repere_2xq99"] = {c: 2 * v["q99"] for c, v in repere.items()}
desc["R8_depassement_s"] = duree - config["duree_max_episodes_pilote_s"]
desc["R8_depassement_relatif"] = duree / config["duree_max_episodes_pilote_s"] - 1
desc["duree_par_episode_s"] = (chrono["generation_s"] + chrono["passe_unique_s"]) / len(ids_episodes)
desc["part_passes_uniques_dans_la_projection"] = chrono["passe_unique_s"] / (chrono["generation_s"] + chrono["passe_unique_s"])
desc["debit_generation_jetons_par_s"] = chrono["jetons_generes"] / chrono["generation_s"]
desc["formule_duree_max_s_pilote_au_bras_defaut_pour_memoire"] = None   # non appliquée : aucun noyau retenu
desc["sondes_conformes_par_action"] = sum(s["tableaux_distincts"] and s["ulp_vu"] for f in ep
                                          for s in f["equivalence"]["sondes"].values())
desc["chemin_C1_max_par_couche"] = {c: max(f["equivalence"]["ecarts"][k][c] for f in sain for k in f["equivalence"]["ecarts"])
                                    for c in ("7", "15", "23")}
desc["chemin_D1_min_du_max_zone_generee"] = min(
    min(p["generee"]["max"] for p in f["equivalence"]["profils"][k].values()) for f in d1
    for k in f["equivalence"]["profils"] if all(p["generee"]["jetons"] >= 4 for p in f["equivalence"]["profils"][k].values()))

SORTIE.mkdir(parents=True, exist_ok=True)
(SORTIE / "recalcul-sortie.json").write_text(json.dumps(
    {"sceaux": sceaux, "constats": constats, "lecture_defaut": lecture_d, "lecture_math": lecture_m,
     "choix": {"noyau_retenu": noyau_retenu, "proposition": proposition}, "reserves": reserves,
     "mesures": mesures, "controle_negatif": cn, "zone_generee": zone, "audit": audit, "chemin": chemin,
     "duree_projetee_s": duree, "domaine_enonces": domaine, "descriptif": desc},
    indent=2, ensure_ascii=False, sort_keys=True, default=str) + "\n", encoding="utf-8")
print("\n".join(journal))
print("ÉCARTS :", sum(1 for c in constats if c["egal"] is False), "sur", len(constats), "constats")
print(json.dumps({"sceaux": sceaux, "descriptif": desc}, indent=1, ensure_ascii=False, default=str))
