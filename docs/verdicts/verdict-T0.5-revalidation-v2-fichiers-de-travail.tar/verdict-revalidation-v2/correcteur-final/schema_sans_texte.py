"""Structure d'un résultat JSON sans aucun texte (règle D-20) : clés, types, nombres et drapeaux ;
pour une chaîne, seulement sa longueur. Les listes sont résumées par leur longueur et leur premier élément."""
import json
import sys


def decrire(x, prefixe="", profondeur=0, max_prof=6):
    if profondeur > max_prof:
        print(f"{prefixe} : …")
        return
    if isinstance(x, dict):
        print(f"{prefixe} : dict({len(x)})")
        for k, v in x.items():
            decrire(v, f"{prefixe}.{k}", profondeur + 1, max_prof)
    elif isinstance(x, list):
        print(f"{prefixe} : list({len(x)})")
        if x:
            decrire(x[0], f"{prefixe}[0]", profondeur + 1, max_prof)
    elif isinstance(x, str):
        print(f"{prefixe} : str(len={len(x)})")
    else:
        print(f"{prefixe} : {type(x).__name__} = {x!r}")


if __name__ == "__main__":
    chemin = sys.argv[1]
    max_prof = int(sys.argv[2]) if len(sys.argv) > 2 else 6
    with open(chemin, encoding="utf-8") as f:
        decrire(json.load(f), "", 0, max_prof)
