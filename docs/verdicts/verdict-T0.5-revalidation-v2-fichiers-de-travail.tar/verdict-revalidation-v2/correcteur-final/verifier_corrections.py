"""Vérifications des corrections mineures du verdict T0.5 v2 (sous-agent correcteur, neuf).
Règle D-20 : aucun champ de texte n'est affiché ; seuls des nombres, drapeaux et identifiants sont lus.
Usage : python3 -I -B verifier_corrections.py <racine du dépôt> <fichier de sortie json>"""
import json
import math
import re
import statistics
import sys
from pathlib import Path

racine = Path(sys.argv[1])
sortie = {}
D = racine / "diag/20261011-225701-t05-revalidation-reel"
COUCHES = ("7", "15", "23")


def charger(nom):
    return json.load(open(D / nom, encoding="utf-8"))["resultat"]


# 1. Médianes vraies (section 7)
fiches = charger("episodes-defaut.json")["fiches"]
q99_action, parts = [], []
for f in fiches:
    eq = f["equivalence"]
    for cle in eq["ecarts_q99"]:
        q99_action.append(max(eq["ecarts_q99"][cle][c] for c in COUCHES))
        pc, lc = eq["positions_capturees"][cle], eq["longueurs_contexte"][cle]
        parts.append((pc - lc) / pc)
qs, ps = sorted(q99_action), sorted(parts)
n = len(qs)
sortie["mediane"] = {
    "n_actions": n,
    "q99_par_action": {"min": qs[0], "rang_80_sur_160": qs[79], "rang_81_sur_160": qs[80],
                       "mediane": statistics.median(qs), "max": qs[-1],
                       "au_dessus_0_15": sum(v > 0.15 for v in qs)},
    "part_zone_generee": {"min": ps[0], "rang_80_sur_160": ps[79], "rang_81_sur_160": ps[80],
                          "mediane": statistics.median(ps), "moyenne": statistics.fmean(ps), "max": ps[-1]},
}

# 2. Longueurs remplies par lot et par pas, bras « defaut »
remplies = {}
for i, f in enumerate(fiches):
    eq = f["equivalence"]
    for cle, lc in eq["longueurs_contexte"].items():
        _, p = map(int, cle.split(","))
        lot = i // 8
        L = lc + eq["lignes"][cle]["remplissage"]
        remplies.setdefault((lot, p), set()).add(L)
par_lot_pas = {f"{lot},{p}": sorted(v) for (lot, p), v in sorted(remplies.items())}
toutes = sorted({L for v in remplies.values() for L in v})
sortie["remplies_defaut"] = {
    "une_seule_longueur_par_lot_et_pas": all(len(v) == 1 for v in remplies.values()),
    "nombre_lot_pas": len(remplies), "min": toutes[0], "max": toutes[-1],
    "valeurs": par_lot_pas,
    "longueurs_des_allocations_presentes": {L: (L in toutes) for L in (3181, 4195, 4722, 5040)},
}

# 3. Phase « chemin » : longueur remplie maximale
chemin = charger("chemin-defaut.json")
maxi_chemin = {}
for phase in ("sain", "d1"):
    m = 0
    for f in chemin[phase]:
        eq = f["equivalence"]
        for cle, lc in eq["longueurs_contexte"].items():
            m = max(m, lc + eq["lignes"][cle]["remplissage"])
    maxi_chemin[phase] = m
sortie["chemin_remplie_max"] = maxi_chemin

# 4. Tailles d'allocation de run.err
err = (racine / "traces/t05-20261011-234411-9q7N/run.err").read_text(encoding="utf-8", errors="replace")
motif = re.compile(r"\[W1011 (\d\d:\d\d:\d\d\.\d+) CUDACachingAllocator\.cpp:\d+\] memory allocation failed with OOM "
                   r"on device 0 while trying to allocate (\d+) bytes \(free: (\d+), total: (\d+)\)")
MIO2 = 2 * 1024 * 1024
allocs = []
for h, taille, libre, total in motif.findall(err):
    taille = int(taille)
    sol = {}
    for octets in (1, 2, 4):
        for lot in (1, 8):
            for tetes in (8, 32):
                k = octets * lot * tetes
                Ls = [L for L in range(1, 20001) if math.ceil(k * L * L / MIO2) * MIO2 == taille]
                if Ls:
                    sol[f"{octets}o_lot{lot}_tetes{tetes}"] = Ls
    allocs.append({"heure": h, "octets": taille, "unites_2Mio": taille / MIO2, "Gio": taille / 2**30,
                   "libre_octets": int(libre), "libre_Gio": int(libre) / 2**30, "total_Gio": int(total) / 2**30,
                   "solutions_entieres": sol})
sortie["allocations_run_err"] = allocs
sortie["chargements_poids"] = len(re.findall(r"Loading weights: 100%", err))

# 5. Bilan de mémoire à la panne (Llama-3.1-8B : 8 030 261 248 paramètres, 32 couches, 8 têtes clé-valeur de 128)
params = 8_030_261_248
poids_bf16 = params * 2 / 2**30
cache_kv = 32 * 2 * 8 * 128 * 2 * 8 * 5040 / 2**30
mat = math.ceil(8 * 32 * 5040**2 * 4 / MIO2) * MIO2 / 2**30
sortie["bilan_memoire"] = {"poids_bf16_Gio": poids_bf16, "cache_kv_lot8_5040_Gio": cache_kv,
                           "matrice_fp32_8x32x5040x5040_Gio": mat,
                           "somme_poids_cache_2_matrices": poids_bf16 + cache_kv + 2 * mat,
                           "alloues_message_Gio": 68.64,
                           "poids_fp32_Gio": params * 4 / 2**30,
                           "poids_double_Go_note": params * 8 / 1e9}

# 6. Décomposition de R8
m = charger("mesures-defaut.json")
ch = m["chrono"]
gen, pu = ch["generation_s"], ch["passe_unique_s"]
cible = 7800 * 16 / 192
sortie["R8"] = {"generation_s": gen, "passe_unique_s": pu, "somme": gen + pu, "equivalent_plafond_s": cible,
                "exces_s": gen + pu - cible, "exces_sur_generation_pc": 100 * (gen + pu - cible) / gen,
                "projetee": (gen + pu) * 192 / 16, "depassement_s": (gen + pu) * 192 / 16 - 7800,
                "depassement_pc": 100 * ((gen + pu) * 192 / 16 - 7800) / 7800,
                "passes_par_s": ch["passes_decodage"] / gen, "ms_par_passe": 1000 * gen / ch["passes_decodage"],
                "jetons_par_s": ch["jetons_generes"] / gen, "part_pas_avec_capture_5pc_lot8": 1 - 0.95**8,
                "calcul_borne_12x_min": 17 * 60 * 12, "calcul_borne_12x_max": 25 * 60 * 12,
                "duree_s_episodes": m["duree_s"]}

# 7. Repère et noyaux permis
lec = charger("lecture-defaut.json")
sortie["repere"] = lec["repere"]
sortie["noyaux_permis"] = m["noyaux_permis"]

json.dump(sortie, open(sys.argv[2], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps({k: v for k, v in sortie.items() if k != "remplies_defaut"}, ensure_ascii=False, indent=1))
r = sortie["remplies_defaut"]
print("remplies_defaut :", {k: v for k, v in r.items() if k != "valeurs"})
print("valeurs par lot,pas :", r["valeurs"])
