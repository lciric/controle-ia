"""Structure des fichiers de résultats : clés, types, longueurs. N'affiche AUCUNE chaîne de caractères
(règle D-20 : ni actions, ni ensembles, ni énoncés). Les clés des dictionnaires indexés par action ou par
couche sont résumées (nombre et un exemple seulement si la clé est faite de chiffres, virgules, barres)."""
import json
import re
import sys

SURS = re.compile(r"^[0-9,|./e-]{1,40}$")   # clés d'identifiants numériques (actions « i,t », couches)
JAMAIS = {"texte", "bilan", "questions", "ensembles", "enonce", "énoncé"}   # champs jamais explorés


def schema(x, prof=0, nom="", max_prof=7):
    ind = "  " * prof
    if nom in JAMAIS:
        print(f"{ind}{nom}: <{type(x).__name__}, non exploré (D-20)>")
        return
    if isinstance(x, dict):
        cles = list(x)
        if cles and all(SURS.match(str(c)) for c in cles) and len(cles) > 3:
            print(f"{ind}{nom}: dict[{len(cles)} clés numériques, ex. {cles[0]!r}]")
            if prof < max_prof:
                schema(x[cles[0]], prof + 1, f"[{cles[0]!r}]")
            return
        print(f"{ind}{nom}: dict({len(cles)})")
        if prof < max_prof:
            for c in cles:
                schema(x[c], prof + 1, str(c) if SURS.match(str(c)) or re.match(r"^[A-Za-z_0-9éèêàçôû ]{1,40}$", str(c)) else "<clé texte>")
    elif isinstance(x, list):
        types = sorted({type(v).__name__ for v in x})
        print(f"{ind}{nom}: list[{len(x)}] de {types}")
        if x and isinstance(x[0], (dict, list)) and prof < max_prof:
            schema(x[0], prof + 1, "[0]")
    elif isinstance(x, str):
        est_hex = bool(re.fullmatch(r"[0-9a-f]{64}", x))
        print(f"{ind}{nom}: str{'(sha256)' if est_hex else ''}")
    else:
        print(f"{ind}{nom}: {type(x).__name__}")


if __name__ == "__main__":
    for chemin in sys.argv[1:]:
        print(f"===== {chemin}")
        d = json.load(open(chemin, encoding="utf-8"))
        schema(d)
