"""Recalcul indépendant du sceptique 1 (verdict T0.5, revalidation v2).

Règle D-20 : aucun champ de texte des fiches n'est lu pour affichage. Le script n'accède qu'à des nombres, des
drapeaux, des empreintes et des identifiants d'épisode ; les identifiants de jetons ne servent qu'à des longueurs.
Les champs `texte`, `bilan`, `tache` des fiches ne sont jamais lus.

Les lectures sont recalculées par un code écrit ici (indépendant du module de lecture), puis comparées aux fichiers
scellés ET aux fonctions du code cité (contre-épreuve).

Usage : python -B recalcul_sceptique.py <clone> <sortie.json>
"""
import hashlib
import json
import math
import subprocess
import sys
from pathlib import Path

import numpy as np

CLONE = Path(sys.argv[1]).resolve()
SORTIE = Path(sys.argv[2])
sys.path.insert(0, str(CLONE / "src"))
sys.dont_write_bytecode = True

RUN = "20261011-225701-t05-revalidation-reel"
DIAG = CLONE / "diag" / RUN
MANIF = CLONE / "runs" / RUN / "manifeste.json"
PREREG = CLONE / "prereg" / "T0.5-revalidation-equivalence-pilote-v2.md"
CONFIG = CLONE / "prereg" / "T0.5-revalidation-config-v1.json"
ENTR = CLONE / "donnees" / "20261007-082440-t05-extraction" / "taches-entrainement.json"
EVAL = CLONE / "donnees" / "20261007-082440-t05-extraction" / "taches-evaluation.json"
INDEX = CLONE / "docs" / "sources" / "invites-2606.08892-v1" / "index.json"

constats = []      # (nom, valeur recalculée, valeur scellée, égal ?)
ecarts = []


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def constater(nom, recalc, scelle, tol=0.0):
    if isinstance(recalc, float) and isinstance(scelle, float) and tol > 0:
        ok = abs(recalc - scelle) <= tol * max(1.0, abs(scelle))
    else:
        ok = recalc == scelle
    constats.append({"nom": nom, "recalcul": recalc, "scelle": scelle, "egal": ok})
    if not ok:
        ecarts.append(nom)
    print(("OK   " if ok else "ÉCART"), nom, "|", repr(recalc)[:120], "|", repr(scelle)[:120])


def charger(nom):
    return json.loads((DIAG / f"{nom}.json").read_text(encoding="utf-8"))


# ---------------------------------------------------------------- 1. sceaux et chaîne
from controle_ia.manifeste import (verifier_resultat, lire_manifeste, config_canonique, graines)  # noqa: E402
from controle_ia.scellement import verifier  # noqa: E402

print("== 1. Sceaux et chaîne")
for nom in ("resume", "lecture-defaut", "lecture-math", "mesures-defaut", "episodes-defaut", "chemin-defaut"):
    corps = verifier_resultat(CLONE, DIAG / f"{nom}.json")
    constater(f"sceau+rattachement {nom}", corps["manifeste_sha256"], sha(MANIF))
    compagnon = (DIAG / f"{nom}.json.sha256").read_text().split()
    constater(f"compagnon {nom}.json.sha256", compagnon, [sha(DIAG / f"{nom}.json"), f"{nom}.json"])
for absent in ("arret", "episodes-math", "mesures-math", "chemin-math"):
    constater(f"absence de {absent}.json", (DIAG / f"{absent}.json").exists(), False)
constater("fichiers du dossier diag", sorted(p.name for p in DIAG.iterdir()),
          sorted([f"{n}.json{s}" for n in ("chemin-defaut", "episodes-defaut", "lecture-defaut", "lecture-math",
                                            "mesures-defaut", "resume") for s in ("", ".sha256")]))

m, sha_m = lire_manifeste(MANIF)
constater("manifeste : sha256", sha_m, "06ee7ed9776427b91bd892de630c9bab462d15e2d922409dabe3ae7eb9f13fbb")
constater("manifeste : commit", m["commit"], "8f74adaa4b7912f87c9d22ec1594a12910d1930a")
constater("manifeste : prereg chemin", m["preenregistrement"]["chemin"], "prereg/T0.5-revalidation-equivalence-pilote-v2.md")
constater("manifeste : prereg sha256 = disque", m["preenregistrement"]["sha256"], sha(PREREG))
constater("prereg : sha256 cité par la consigne", sha(PREREG), "4ff2b07548e90fc515fe8944a789bf44267be6e239dee02d2b479e9c701dcc61")
prereg_commit = subprocess.run(["git", "-C", str(CLONE), "show", f"{m['commit']}:prereg/T0.5-revalidation-equivalence-pilote-v2.md"],
                               capture_output=True, check=True).stdout
constater("prereg : identique au commit du manifeste", hashlib.sha256(prereg_commit).hexdigest(), sha(PREREG))
verifier(PREREG)
constater("manifeste : decisif, depot_propre, reserves", (m["decisif"], m["depot_propre"], m["reserves"]), (True, True, []))
constater("manifeste : run_id", m["run_id"], RUN)
constater("manifeste : versions torch/transformers", (m["versions"]["torch"], m["versions"]["transformers"]), ("2.14.1", "5.18.0"))

# configuration
verifier(CONFIG)
config = json.loads(CONFIG.read_text(encoding="utf-8"))
canon = hashlib.sha256(config_canonique(config)).hexdigest()
constater("config : empreinte canonique = citée", canon, "50930b3794216c3b857cd906d8b2066eb495534d637041f4d089aa00a9edeefb")
cm = dict(m["config"])
ajoutees = {k: cm.pop(k) for k in ("taches_entrainement", "taches_entrainement_sha256", "taches_evaluation",
                                    "taches_evaluation_sha256")}
constater("config du manifeste sans les 4 clés = fichier cité", cm, config)
constater("config_sha256 du manifeste = canonique de la config augmentée",
          hashlib.sha256(config_canonique(m["config"])).hexdigest(), m["config_sha256"])
constater("tâches : sha256 entraînement", (ajoutees["taches_entrainement_sha256"], sha(ENTR)),
          ("8d20a698d76baa8a42cd1494227fc411ef043d24a67a413e5cf812541166a4fd",) * 2)
constater("tâches : sha256 évaluation", (ajoutees["taches_evaluation_sha256"], sha(EVAL)),
          ("76cdeace861d2fff45ca732c55c2d97611dcd47edc7c27d62bdad4c37755e67e",) * 2)
constater("index des invites : sha256", sha(INDEX), "adb4b8bca7788baf2c4714df96dcdcc2c5043e8f1943542d0fbe1863491ae2d9")

# seuils de la configuration = texte gelé
attendus = {"N": 1, "T": 10, "episodes_par_tache": 1, "lot": 8, "max_nouveaux": 400, "temperature": 1.0,
            "couches": [7, 15, 23], "fraction_equivalence": 1.0, "statistique_equivalence": "q99",
            "tolerance_equivalence": 0.2, "positions_min_controle_negatif": 4, "actions_min_controle_negatif": 10,
            "fraction_min_controle_negatif": 0.95, "mode": "reel", "fils": 1, "bras": ["defaut", "math"],
            "nombre_taches": 16, "transcriptions_repere": 2, "actions_min_comparees": 40,
            "part_min_contexte_couvert": 0.9, "memoire_carte_min_gio": 75, "memoire_pic_max_gio": 70,
            "marge_q99": 0.15, "rho_max": 3, "duree_max_s": 12600, "duree_max_bras_s": 6300,
            "duree_max_episodes_pilote_s": 7800, "chemin": {"T": 5, "tolerance": 0.003},
            "controle_positif": {"T": 5, "decalage_positions": 1, "positions_min": 4, "actions_min": 10,
                                 "fraction_min": 0.95}}
constater("config : valeurs = table de configuration du texte gelé", {k: config[k] for k in attendus}, attendus)
constater("config : agent", (config["agent"]["modele"], config["agent"]["revision"],
                             config["agent"]["variables_gabarit"]),
          ("meta-llama/Llama-3.1-8B-Instruct", "0e9e39f249a16976918f6564b8830bc894c89659",
           {"date_string": "26 Jul 2024"}))

# citations, entropie, graines
import re  # noqa: E402
texte_prereg = PREREG.read_text(encoding="utf-8")
entropie = int(re.search(r"Entropie : `([0-9]+)`", texte_prereg).group(1))
constater("entropie citée", entropie, 120571628831802510081029698987406594891)
for motif, attendu in ((r"Configuration de la revalidation \(empreinte canonique\) : `([0-9a-f]{64})`", canon),
                       (r"Tâches d'entraînement : `([0-9a-f]{64})`", sha(ENTR)),
                       (r"Tâches d'évaluation : `([0-9a-f]{64})`", sha(EVAL)),
                       (r"Index des invites : `([0-9a-f]{64})`", sha(INDEX)),
                       (r"Commit du code d'analyse : `([0-9a-f]{40})`", "6ec7434119781a3abebac789174101b9ed6ae087")):
    constater(f"citation « {motif[:30]}… »", re.search(motif, texte_prereg).group(1), attendu)

# tâches retenues : recalcul propre (longueurs seulement, aucun affichage de texte)
def taches(chemin):
    brut = json.loads(Path(chemin).read_text(encoding="utf-8"))
    return brut["resultat"]["taches"] if "resultat" in brut else brut["taches"]


entr, ev = taches(ENTR), taches(EVAL)
long_entr = [len(t["questions"]) for t in entr]
rangs = sorted(range(len(entr)), key=lambda i: (-long_entr[i], i))[:16]
choisies = sorted(rangs)
ids_episodes = [f"{entr[i]['identifiant']}/e0" for i in choisies]
l_ch = sorted(long_entr[i] for i in choisies)
l_ev = sorted(len(t["questions"]) for t in ev)
domaine = {"longueur_max_choisies": l_ch[-1], "longueur_min_choisies": l_ch[0], "longueur_max_evaluation": l_ev[-1],
           "longueur_q90_evaluation": float(np.quantile(l_ev, 0.9)), "couvre_le_pilote": l_ch[-1] >= l_ev[-1]}
resume = charger("resume")["resultat"]
constater("domaine des énoncés (recalcul propre) = resume.json", domaine, resume["domaine_enonces"])
constater("nombre de tâches d'évaluation ≥ 64", len(ev) >= 64, True)
ids_eval = {t["identifiant"] for t in ev} | {re.sub(r"v\d+$", "", t["identifiant"]) for t in ev}
constater("aucune tâche d'entraînement retenue n'est une tâche d'évaluation",
          [e for e in ids_episodes if e[:-3] in ids_eval or re.sub(r"v\d+$", "", e[:-3]) in ids_eval], [])
# égalité stricte à la 16e place ? (sensibilité de la sélection)
seuil16 = sorted(long_entr, reverse=True)[15]
constater("pas d'égalité de longueur à la frontière des 16 (17e < 16e)",
          sorted(long_entr, reverse=True)[16] < seuil16, True)

cles = ids_episodes + [f"chemin/{e}" for e in ids_episodes] + [f"controle-positif/{e}" for e in ids_episodes] + ["modele-jouet"]
constater("graines : 49 recalculées par SeedSequence = manifeste", graines(cles, entropie), m["graines"])

# ---------------------------------------------------------------- 2. épisodes du bras « defaut » (nombres seulement)
print("== 2. Bras « defaut »")
fiches = charger("episodes-defaut")["resultat"]["fiches"]
mesures_f = charger("mesures-defaut")["resultat"]
lecture_f = charger("lecture-defaut")["resultat"]
constater("épisodes : identifiants dans l'ordre du plan", [f["episode"] for f in fiches], ids_episodes)
constater("épisodes : 16 fiches de 10 actions", [len(f["actions"]) for f in fiches], [10] * 16)
constater("épisodes : toutes les actions comparées", [len(f["equivalence"]["ecarts_q99"]) for f in fiches], [10] * 16)
constater("épisodes : statistique et tolérance des fiches", {(f["equivalence"]["statistique"], f["equivalence"]["tolerance"]) for f in fiches}, {("q99", 0.2)})


def nan_inf(x):
    return float("inf") if x is None or x != x else float(x)


q99s, maxs, ctx, remplies, n_comp = [], [], [], 0, 0
q99_par_couche, nuls, jetons_zg, sondes = {}, {}, {}, []
debut_max = max(a["debut"] for f in fiches for a in f["actions"])
cn_comp = cn_pass = cn_courtes = 0
cn_min = float("inf")
zg_q99, zg_comp, zg_pass, parts = [], 0, 0, []
q99_par_action = []
for f in fiches:
    eq = f["equivalence"]
    for cle in eq["ecarts_q99"]:
        n_comp += 1
        vals = [nan_inf(v) for v in eq["ecarts_q99"][cle].values()]
        q99s += vals
        q99_par_action.append(max(vals))
        maxs += [nan_inf(v) for v in eq["ecarts"][cle].values()]
        ctx.append(eq["longueurs_contexte"][cle])
        remplies += int(eq["lignes"][cle]["remplissage"] > 0)
        for c, v in eq["ecarts_q99"][cle].items():
            q99_par_couche[c] = max(q99_par_couche.get(c, 0.0), nan_inf(v))
        # contrôle négatif de l'action entière (q99, tolérance 0,2, au moins 4 positions)
        zone = eq["controle_negatif_zone_generee"][cle]
        if zone is None or min(v["positions"] for v in zone.values()) < 4:
            cn_courtes += 1
        else:
            cn_comp += 1
            mn = min(float("-inf") if v["q99"] != v["q99"] else v["q99"] for v in zone.values())
            cn_min = min(cn_min, mn)
            cn_pass += int(mn > 0.2)
            # garde restreinte : contrôle négatif sur le 99e centile de la zone générée décalée (condition suffisante)
            zg_comp += 1
            zg_pass += int(all(v["positions"] > 0 and v["au_dessus"] >= v["positions"] - math.floor(0.99 * (v["positions"] - 1))
                               for v in zone.values()))
        n = eq["positions_capturees"][cle]
        parts.append((n - eq["longueurs_contexte"][cle]) / n)
        for c, prof in eq["profils"][cle].items():
            g = prof["generee"]
            if g["jetons"]:
                zg_q99.append(nan_inf(g["q99"]))
                nuls[c] = nuls.get(c, 0) + g["nuls"]
                jetons_zg[c] = jetons_zg.get(c, 0) + g["jetons"]
        sondes.append(eq["sondes"][cle])

mes = {"actions_comparees": n_comp, "q99_max": max(q99s), "ecart_max": max(maxs), "contexte_max": max(ctx),
       "contexte_max_joue": debut_max, "actions_remplies": remplies}
constater("R1/R5 : mesures (recalcul propre) = mesures-defaut.json → resultat.mesures", mes, mesures_f["mesures"])
cn = {"comparables": cn_comp, "passent": cn_pass, "courtes": cn_courtes, "min_des_maxima": cn_min,
      "fraction": cn_pass / cn_comp}
constater("R2 : contrôle négatif (recalcul propre)", cn,
          {k: mesures_f["controle_negatif"][k] for k in cn})
lecture_cn = ("non concluant" if cn_comp < 10 else ("conforme" if cn_pass / cn_comp >= 0.95 else "contraire"))
constater("R2 : lecture", lecture_cn, mesures_f["controle_negatif"]["lecture"])
zg = {"q99_generee_max": max(zg_q99), "comparables": zg_comp, "passent": zg_pass, "fraction": zg_pass / zg_comp,
      "part_zone_generee_sous_1pc": sum(p < 0.01 for p in parts) / len(parts)}
constater("garde restreinte (recalcul propre) = lecture-defaut.json → resultat.zone_generee", zg, lecture_f["zone_generee"])
repere = lecture_f["repere"]
rho = {c: q99_par_couche[c] / repere[c]["q99"] for c in q99_par_couche}
audit = {"P9_zone_generee_non_nulle": all(nuls[c] < jetons_zg[c] for c in jetons_zg), "nuls_zone_generee": nuls,
         "jetons_zone_generee": jetons_zg, "rho": rho, "rho_max_observe": max(rho.values()),
         "sondes_conformes": all(s["tableaux_distincts"] and s["ulp_vu"] for s in sondes)}
constater("audit (recalcul propre) = lecture-defaut.json → resultat.audit", audit, lecture_f["audit"])
constater("sondes : nombre d'actions sondées", len(sondes), 160)

# chronométrage contre les fiches
chrono = mesures_f["chrono"]
jpa = sum(sum(f["jetons_par_action"]) for f in fiches)
constater("chrono : jetons générés = Σ jetons par action", jpa, chrono["jetons_generes"])
constater("chrono : jetons_par_action = longueurs des ids (longueurs seulement)",
          [f["jetons_par_action"] for f in fiches], [[len(a["ids"]) for a in f["actions"]] for f in fiches])
constater("chrono : jetons de contexte = Σ longueurs de contexte", sum(ctx), chrono["jetons_contexte"])
rempl = sum(f["equivalence"]["lignes"][c]["remplissage"] for f in fiches for c in f["equivalence"]["lignes"])
constater("chrono : jetons de remplissage", rempl, chrono["jetons_remplissage"])
constater("chrono : lignes finies avant", sum(f["equivalence"]["lignes"][c]["finie_avant"] for f in fiches for c in f["equivalence"]["lignes"]), chrono["lignes_finies_avant"])
# par lot et par pas : longueur remplie et passes de décodage
L_lot, passes = {}, 0
for lot in (0, 1):
    for t in range(10):
        cle = f"0,{t}"
        lignes = fiches[8 * lot: 8 * lot + 8]
        Ls = {f["equivalence"]["longueurs_contexte"][cle] + f["equivalence"]["lignes"][cle]["remplissage"] for f in lignes}
        assert len(Ls) == 1, Ls
        L_lot[(lot, t)] = Ls.pop()
        nmax = max(len(f["actions"][t]["ids"]) for f in lignes)
        p = max(f["equivalence"]["positions_capturees"][cle] - f["equivalence"]["longueurs_contexte"][cle] for f in lignes)
        assert p == nmax - 1, (lot, t, p, nmax)
        passes += p
constater("chrono : passes de décodage = Σ (plus longue action − 1)", passes, chrono["passes_decodage"])
constater("chrono : contextes remplis = Σ 8 × L", sum(8 * v for v in L_lot.values()), chrono["jetons_contexte_remplis"])
constater("chrono : longueur remplie maximale", max(L_lot.values()), chrono["longueur_remplie_max"])
tr = [(f["episode"], len(t["ids"])) for f in fiches for t in f["transcriptions"]]
constater("chrono : jetons des passes uniques = Σ longueurs des transcriptions", sum(n for _, n in tr), chrono["jetons_passe_unique"])
top2 = sorted(range(len(tr)), key=lambda i: (-tr[i][1], i))[:2]
constater("repère : deux plus longues transcriptions", {f"defaut|{tr[i][0]}|0": tr[i][1] for i in sorted(top2)},
          mesures_f["repere_transcriptions"])
constater("repère : jetons par couche = somme", {c: repere[c]["jetons"] for c in repere}, {c: sum(tr[i][1] for i in top2) for c in repere})

# R3, R4, R6, R7, R8
r3 = {c: 2 * repere[c]["q99"] for c in repere}
print("R3 2×q99 par couche :", r3)
chem = charger("chemin-defaut")["resultat"]
c1 = max(nan_inf(v) for f in chem["sain"] for d in f["equivalence"]["ecarts"].values() for v in d.values())
c2c = c2v = 0
for f in chem["d1"]:
    for prof in f["equivalence"]["profils"].values():
        zones = [p["generee"] for p in prof.values()]
        if any(z["jetons"] < 4 for z in zones):
            continue
        c2c += 1
        c2v += int(all(z["max"] == z["max"] and z["max"] > 0.003 for z in zones))
c3c = c3p = 0
c3min = float("inf")
for f in chem["sain"]:
    assert f["equivalence"]["statistique"] == "max" and f["equivalence"]["tolerance"] == 0.003
    for cle, zone in f["equivalence"]["controle_negatif_zone_generee"].items():
        if zone is None or min(v["positions"] for v in zone.values()) < 4:
            continue
        c3c += 1
        mn = min(float("-inf") if v["max"] != v["max"] else v["max"] for v in zone.values())
        c3min = min(c3min, mn)
        c3p += int(mn > 0.003)
chemin = {"C1": c1 <= 0.003, "C1_ecart_max": c1, "C2": "conforme" if c2c >= 10 and c2v / c2c >= 0.95 else "?",
          "C2_comparables": c2c, "C2_vus": c2v,
          "C3": "conforme" if c3c >= 10 and c3p / c3c >= 0.95 else "?"}
chemin["conforme"] = chemin["C1"] and chemin["C2"] == "conforme" and chemin["C3"] == "conforme"
constater("R6 : chemin (recalcul propre) = lecture-defaut.json → resultat.chemin.lecture", chemin, lecture_f["chemin"]["lecture"])
constater("R6/C3 : contrôle négatif du passage sain", {"comparables": c3c, "passent": c3p, "min_des_maxima": c3min},
          {k: lecture_f["chemin"]["controle_negatif"][k] for k in ("comparables", "passent", "min_des_maxima")})
constater("chemin : 8 épisodes du lot 0, T = 5", ([f["episode"] for f in chem["sain"]], [len(f["actions"]) for f in chem["sain"]],
                                                [f["episode"] for f in chem["d1"]], [len(f["actions"]) for f in chem["d1"]]),
          (ids_episodes[:8], [5] * 8, ids_episodes[:8], [5] * 8))
r8 = (chrono["generation_s"] + chrono["passe_unique_s"]) * 192 / 16
constater("R8 : (génération + passes uniques) × 192 / 16", r8, mesures_f["duree_projetee_episodes_pilote_s"])

conf = config
lec = {"R1_garde_saine": mes["q99_max"] <= conf["tolerance_equivalence"],
       "R1_marge": mes["q99_max"] <= conf["marge_q99"],
       "R2_controle_negatif": lecture_cn,
       "R3_seuil_fonde": all(v <= conf["tolerance_equivalence"] for v in r3.values()),
       "R4_rejeu": bool(mesures_f["rejeu_identique"]),
       "R5_domaine_couvert": (mes["actions_comparees"] >= conf["actions_min_comparees"] and mes["actions_remplies"] > 0
                              and mes["contexte_max"] >= conf["part_min_contexte_couvert"] * mes["contexte_max_joue"]),
       "R6_chemin_defaut": chemin["conforme"],
       "R7_memoire": mesures_f["memoire_pic_gio"] <= conf["memoire_pic_max_gio"],
       "R8_duree": r8 <= conf["duree_max_episodes_pilote_s"],
       "audit_conforme": audit["P9_zone_generee_non_nulle"] and audit["sondes_conformes"] and audit["rho_max_observe"] <= conf["rho_max"],
       "reserve_rho": False, "audit_R4_ecarts_tous_nuls": mes["ecart_max"] == 0}
base = all(lec[k] for k in ("R1_garde_saine", "R3_seuil_fonde", "R4_rejeu", "R5_domaine_couvert", "R6_chemin_defaut",
                            "R7_memoire", "R8_duree", "audit_conforme")) and lec["R2_controle_negatif"] == "conforme"
lec["conforme"] = base
lec["conforme_avec_marge"] = base and lec["R1_marge"]
g1 = zg["q99_generee_max"] <= 0.2
g2 = zg["comparables"] >= 10 and zg["fraction"] >= 0.95
lec["garde_zone_generee_conforme"] = g1 and g2
# « ne manque que le contrôle négatif de l'action entière » : tout le reste conforme, R2 non conforme, garde restreinte conforme
lec["aveugle_action_entiere_seulement"] = (lec["R2_controle_negatif"] != "conforme" and g1 and g2 and all(
    lec[k] for k in ("R1_garde_saine", "R3_seuil_fonde", "R4_rejeu", "R5_domaine_couvert", "R6_chemin_defaut",
                     "R7_memoire", "R8_duree", "audit_conforme")))
constater("lecture du bras « defaut » (logique propre) = lecture-defaut.json → resultat.lecture", lec, lecture_f["lecture"])
constater("lecture du bras « defaut » = resume.json → resultat.lectures.defaut", lecture_f["lecture"], resume["lectures"]["defaut"])
manquants = [k for k in ("R1_garde_saine", "R3_seuil_fonde", "R4_rejeu", "R5_domaine_couvert", "R6_chemin_defaut",
                         "R7_memoire", "R8_duree", "audit_conforme") if not lec[k]]
constater("critères manquants du bras « defaut »", manquants, ["R8_duree"])

# ---------------------------------------------------------------- 3. bras « math »
print("== 3. Bras « math »")
lm = charger("lecture-math")["resultat"]["lecture"]
constater("math : panne consignée, préfixe du rattrapage pendant le bras (l. 516)", lm["panne"].startswith("mémoire : CUDA out of memory"), True)
constater("math : lecture", {k: lm[k] for k in ("conforme", "conforme_avec_marge")}, {"conforme": False, "conforme_avec_marge": False})
constater("math : = resume.json", lm, resume["lectures"]["math"])
constater("resume : bras mesurés", sorted(resume["bras"]), ["defaut"])

# ---------------------------------------------------------------- 4. règle de choix
print("== 4. Règle de choix")
lectures = {"defaut": lec, "math": lm}
retenu = next((b for b in ("defaut", "math") if lectures[b].get("conforme_avec_marge")), None)
prop = None
if retenu is None:
    for b in ("defaut", "math"):
        if lectures[b].get("conforme"):
            prop = ("conforme sans marge", b)
            break
    if prop is None:
        for b in ("defaut", "math"):
            if lectures[b].get("aveugle_action_entiere_seulement"):
                prop = ("garde par zone", b)
                break
constater("règle de choix (logique propre)", (retenu, prop), (resume["noyau_retenu"], resume["proposition_au_noeud"]))
constater("nœud", resume["noeud"], True)
reserves = [] if domaine["couvre_le_pilote"] else ["énoncés de la revalidation plus courts que le plus long énoncé du pilote (RV-5)"]
constater("réserves (recalcul propre)", reserves, resume["reserves"])

# ---------------------------------------------------------------- 5. contre-épreuve : fonctions du code cité
print("== 5. Contre-épreuve par le code cité")
from controle_ia.environnements import revalider_pilote_a as R  # noqa: E402
from controle_ia.harnais.episode import bilan_controle_negatif  # noqa: E402

constater("code : domaine_et_garde", R.domaine_et_garde(fiches), mesures_f["mesures"])
bil = bilan_controle_negatif([{"episode": f["episode"], **f["equivalence"]} for f in fiches], positions_min=4)
bil["lecture"] = lecture_cn
constater("code : bilan_controle_negatif", bil, mesures_f["controle_negatif"])
constater("code : garde_zone_generee", R.garde_zone_generee(fiches, 0.2, 4), lecture_f["zone_generee"])
constater("code : audit_symetrie", R.audit_symetrie(fiches, repere), lecture_f["audit"])
constater("code : duree_projetee_pilote(chrono, 16)", R.duree_projetee_pilote(chrono, 16), mesures_f["duree_projetee_episodes_pilote_s"])
constater("code : EPISODES_PILOTE", R.EPISODES_PILOTE, 192)
bil_c = bilan_controle_negatif([{"episode": f["episode"], **f["equivalence"]} for f in chem["sain"]], positions_min=4)
bil_c["lecture"] = "conforme" if bil_c["comparables"] >= 10 and bil_c["fraction"] >= 0.95 else "?"
constater("code : contrôle négatif du chemin", bil_c, lecture_f["chemin"]["controle_negatif"])
constater("code : lire_chemin", R.lire_chemin(chem["sain"], bil_c, chem["d1"], config), lecture_f["chemin"]["lecture"])
lb = R.lire_bras(mesures_f["mesures"], mesures_f["controle_negatif"], repere, mesures_f["rejeu_identique"], config,
                 zone_generee=lecture_f["zone_generee"], audit=lecture_f["audit"], chemin=lecture_f["chemin"]["lecture"],
                 bras="defaut", memoire_pic_gio=mesures_f["memoire_pic_gio"],
                 duree_projetee_s=mesures_f["duree_projetee_episodes_pilote_s"])
constater("code : lire_bras(defaut)", lb, lecture_f["lecture"])
constater("code : lire_bras(math, panne)", R.lire_bras({}, {}, None, None, config, panne=lm["panne"]), lm)
constater("code : choisir_noyau", R.choisir_noyau({"defaut": lb, "math": lm}), (None, None))
ch, dom = R.taches_d_entrainement(ENTR, EVAL, 16)
constater("code : taches_d_entrainement (identifiants)", [f"{t['identifiant']}/e0" for t in ch], ids_episodes)
constater("code : domaine des énoncés", dom, resume["domaine_enonces"])
constater("code : exiger_citations → entropie", R.exiger_citations(PREREG, config, sha(ENTR), sha(EVAL), sha(INDEX)), entropie)
constater("code : plus_longues_transcriptions (longueurs)",
          {k: len(v) for k, v in R.plus_longues_transcriptions(fiches, 2, "defaut").items()},
          mesures_f["repere_transcriptions"])

# ---------------------------------------------------------------- 6. sensibilités (descriptif, sans effet sur la règle)
print("== 6. Sensibilités")
gen, pu = chrono["generation_s"], chrono["passe_unique_s"]
seuil_somme = 7800 * 16 / 192
sens = {
    "R8_s": r8, "depassement_s": r8 - 7800, "depassement_pc": (r8 - 7800) / 7800 * 100,
    "somme_mesuree_s": gen + pu, "somme_max_pour_R8_s": seuil_somme,
    "reduction_necessaire_de_la_generation_pc": (gen + pu - seuil_somme) / gen * 100,
    "duree_s_premier_passage": mesures_f["duree_s"],
    "duree_max_s_pilote_si_formule_appliquee": min(15000, math.ceil((1.2 * r8 + 7200) / 60) * 60),
    "part_juges_si_d_projete_s": 15000 - r8,
    "debit_jetons_par_s": chrono["jetons_generes"] / gen,
    "passes_par_s": chrono["passes_decodage"] / gen,
    "q99_par_action_min_med_max": [min(q99_par_action), float(np.median(q99_par_action)), max(q99_par_action)],
    "actions_q99_sup_0_15": sum(x > 0.15 for x in q99_par_action),
    "q99_par_couche_max": q99_par_couche,
    "part_zone_generee_min_med_max": [min(parts), float(np.median(parts)), max(parts)],
    "L_par_lot_et_pas": {f"{k[0]},{k[1]}": v for k, v in sorted(L_lot.items())},
    "debuts_pas0_lot0": [f["actions"][0]["debut"] for f in fiches[:8]],
    "debuts_pas0_lot1": [f["actions"][0]["debut"] for f in fiches[8:]],
    "estimation_calcul_prereg_R8_s": [(17 * 60 + pu) * 12, (25 * 60 + pu) * 12],
}
# tailles des échecs d'allocation de run.err, lues en longueur remplie L d'une matrice [8, 32, L, L]
octets = [10362028032, 18020827136, 22833790976, 26013073408, 6503268352]
deux_mio = 2 * 2 ** 20
sens["allocations_en_unites_de_2Mio"] = [o / deux_mio for o in octets]
sens["L_si_float32_8x32xLxL"] = [math.sqrt(o / (8 * 32 * 4)) for o in octets]
sens["L_si_octet_8x32xLxL"] = [math.sqrt(o / (8 * 32 * 1)) for o in octets]
sens["arrondi_2Mio_de_8x32x5040x5040_octets"] = math.ceil(8 * 32 * 5040 * 5040 / deux_mio) * deux_mio
sens["arrondi_2Mio_de_8x32x5040x5040x4"] = math.ceil(8 * 32 * 5040 * 5040 * 4 / deux_mio) * deux_mio
sens["arrondi_2Mio_de_8x32x3181x3181x4"] = math.ceil(8 * 32 * 3181 * 3181 * 4 / deux_mio) * deux_mio
sens["arrondi_2Mio_de_8x32x4195x4195x4"] = math.ceil(8 * 32 * 4195 * 4195 * 4 / deux_mio) * deux_mio
sens["arrondi_2Mio_de_8x32x4722x4722x4"] = math.ceil(8 * 32 * 4722 * 4722 * 4 / deux_mio) * deux_mio
for k, v in sens.items():
    print(k, ":", v)

SORTIE.write_text(json.dumps({"constats": constats, "ecarts": ecarts, "sensibilites": sens}, ensure_ascii=False,
                             indent=1, default=str) + "\n", encoding="utf-8")
print(f"\n{len(constats)} constats, {len(ecarts)} écart(s) : {ecarts}")
