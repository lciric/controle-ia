"""Exploration de structure SANS texte (règle D-20) : n'affiche que des noms de clés, des types et des tailles.
Aucune valeur de chaîne n'est affichée ; les listes d'entiers (identifiants de jetons) ne sont jamais affichées."""
import json
import sys


def decrire(x, chemin, profondeur, sortie, vus):
    t = type(x).__name__
    if isinstance(x, dict):
        cle_type = chemin + "{}"
        if cle_type not in vus:
            vus.add(cle_type)
            sortie.append(f"{'  ' * profondeur}{chemin}: dict[{len(x)}]")
        # pour les dictionnaires indexés par action ou couche, ne décrire que la première entrée
        cles = list(x.keys())
        generiques = all(("," in k or k.isdigit()) for k in cles) and cles
        for k in (cles[:1] if generiques else cles):
            decrire(x[k], f"{chemin}.{'<cle>' if generiques else k}", profondeur + 1, sortie, vus)
    elif isinstance(x, list):
        if chemin + "[]" not in vus:
            vus.add(chemin + "[]")
            sortie.append(f"{'  ' * profondeur}{chemin}: list[{len(x)}] de {type(x[0]).__name__ if x else '?'}")
        if x and isinstance(x[0], (dict, list)):
            decrire(x[0], chemin + "[0]", profondeur + 1, sortie, vus)
    else:
        if chemin not in vus:
            vus.add(chemin)
            sortie.append(f"{'  ' * profondeur}{chemin}: {t}")


for f in sys.argv[1:]:
    d = json.load(open(f, encoding="utf-8"))
    sortie, vus = [], set()
    decrire(d, "racine", 0, sortie, vus)
    print("=====", f)
    print("\n".join(sortie))
