"""Vérification des grandeurs descriptives de la section 7 du brouillon (nombres seulement ; règle D-20)."""
import json
import sys
from pathlib import Path

import numpy as np

DIAG = Path(sys.argv[1])
fiches = json.loads((DIAG / "episodes-defaut.json").read_text(encoding="utf-8"))["resultat"]["fiches"]
chem = json.loads((DIAG / "chemin-defaut.json").read_text(encoding="utf-8"))["resultat"]

q99_action, max_action, zg_q99_action, parts_pos, parts_jetons = [], [], [], [], []
for f in fiches:
    eq = f["equivalence"]
    for t, cle in enumerate(sorted(eq["ecarts_q99"], key=lambda k: int(k.split(",")[1]))):
        q99_action.append(max(eq["ecarts_q99"][cle].values()))
        max_action.append(max(eq["ecarts"][cle].values()))
        zg_q99_action.append(max(p["generee"]["q99"] for p in eq["profils"][cle].values()))
        n, lc = eq["positions_capturees"][cle], eq["longueurs_contexte"][cle]
        parts_pos.append((n - lc) / n)
        nj = f["jetons_par_action"][int(cle.split(",")[1])]
        parts_jetons.append(nj / (lc + nj))

q = np.array(q99_action)
print("q99 par action : min %.6f médiane %.6f max %.6f ; > 0,15 : %d" % (q.min(), np.median(q), q.max(), (q > 0.15).sum()))
print("  médiane exacte :", np.median(q), "; 80e et 81e valeurs triées :", sorted(q)[79], sorted(q)[80])
m = np.array(max_action)
print("max par action : > 0,2 : %d sur %d ; max %.6f" % ((m > 0.2).sum(), m.size, m.max()))
z = np.array(zg_q99_action)
print("q99 zone générée par action : max %.6f ; > 0,15 : %d ; > 0,2 : %d" % (z.max(), (z > 0.15).sum(), (z > 0.2).sum()))
pp, pj = np.array(parts_pos), np.array(parts_jetons)
print("part zone générée (positions capturées) : min %.4f médiane %.4f max %.4f" % (pp.min(), np.median(pp), pp.max()))
print("part zone générée (jetons générés / (contexte + jetons)) : min %.4f médiane %.4f max %.4f" % (pj.min(), np.median(pj), pj.max()))

# chemin : maximum par couche du passage sain ; plus petit maximum de zone générée sous D1 (actions comparables)
par_couche = {}
for f in chem["sain"]:
    for d in f["equivalence"]["ecarts"].values():
        for c, v in d.items():
            par_couche[c] = max(par_couche.get(c, 0.0), v)
print("chemin sain, maximum par couche :", par_couche)
mins = []
for f in chem["d1"]:
    for prof in f["equivalence"]["profils"].values():
        zones = [p["generee"] for p in prof.values()]
        if any(zz["jetons"] < 4 for zz in zones):
            continue
        mins.append(min(zz["max"] for zz in zones))
print("D1 : plus petit maximum de zone générée (sur les couches puis les actions comparables) : %.6f" % min(mins))

# longueurs remplies de la phase « chemin » (sain et D1), par pas
for nom in ("sain", "d1"):
    L = []
    for t in range(5):
        cle = f"0,{t}"
        Ls = {f["equivalence"]["longueurs_contexte"][cle] + f["equivalence"]["lignes"][cle]["remplissage"] for f in chem[nom]}
        L.append(sorted(Ls))
    print(f"chemin {nom} : L par pas :", L)
