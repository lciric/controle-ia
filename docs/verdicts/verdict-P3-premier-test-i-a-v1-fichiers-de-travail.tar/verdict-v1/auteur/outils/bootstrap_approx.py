"""Contrôle approché (graine propre, non opposable) de la borne basse de P3-P3 par blocs de tâches.

Usage : python3 -I bootstrap_approx.py CHEMIN/scores-p3.npz
"""
import sys

import numpy as np


def rankdata(x):
    x = np.asarray(x, float)
    ordre = np.argsort(x, kind="mergesort")
    xs = x[ordre]
    debut = np.r_[True, xs[1:] != xs[:-1]]
    groupe = np.cumsum(debut) - 1
    premiers = np.flatnonzero(debut)
    fins = np.r_[premiers[1:], len(xs)]
    moy = (premiers + fins - 1) / 2.0 + 1.0
    r = np.empty(len(x))
    r[ordre] = moy[groupe]
    return r


def aire(pos, neg):
    r = rankdata(np.concatenate([pos, neg]))
    return (r[: len(pos)].sum() - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg))


z = np.load(sys.argv[1])
noms = list(z["noms_sondes"])
s = z["scores"]
cond = z["condition"]
tache = z["tache"]
taches = np.unique(tache)
rng = np.random.default_rng(20261020)
for p in ["tromperie-difference_moyennes-c15", "enjeux-lineaire-c15"]:
    j = noms.index(p)
    idx = {t: (np.where((tache == t) & (cond == "saboteur"))[0], np.where((tache == t) & (cond == "honnete"))[0])
           for t in taches}
    vals = []
    for _ in range(2000):
        tir = rng.integers(0, len(taches), size=len(taches))
        pos = np.concatenate([idx[taches[k]][0] for k in tir])
        neg = np.concatenate([idx[taches[k]][1] for k in tir])
        vals.append(aire(s[pos, j], s[neg, j]))
    print(p, "bornes 97,5 % approchées :", np.quantile(vals, [0.0125, 0.9875]))
