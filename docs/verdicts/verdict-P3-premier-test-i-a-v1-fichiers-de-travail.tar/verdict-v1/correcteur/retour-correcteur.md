# Retour du correcteur — verdict R13 de P3, v1

- **Qui** : sous-agent neuf, correcteur. Je n'ai écrit ni le préenregistrement de P3, ni son code, ni le run, ni la lecture,
  ni l'addendum, ni le brouillon, ni les rapports des sceptiques.
- **Cadre** : dépôt en lecture seule (git en lecture seulement) ; aucune commande Vast.ai, aucune installation, aucune suite
  de tests ; textes des actions et consignes privées non ouverts ; aucun filtre de sûreté n'a rien refusé.
- **Entrées** : brouillon `…/auteur/verdict-P3-premier-test-i-a-v1-brouillon.md` (`278e64cd…`, recalculée, égale) ; rapports
  `…/sceptique-1/rapport-sceptique-1.md` (`05d53da8…`) et `…/sceptique-2/rapport-sceptique-2.md` (`e27c2e15…`, égale à son
  compagnon). Le préfixe `…/` vaut `/tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-p3/verdict-v1`.
- **Sortie** : `…/correcteur/verdict-P3-premier-test-i-a-v1.md` (empreinte dans `…/correcteur/empreintes-correcteur.txt`).

## Ce qui ne change pas

La ligne, les états, les nombres et l'absence de réserve sont ceux du brouillon. Je les ai contrôlés moi-même sur les pièces :
- empreintes des treize pièces du dépôt égales à leurs compagnons ; [D] égal à la version du commit `3fb9d34` ; [REC], [O1],
  [O2] égaux au brouillon ; `sha256sum -c ../outils-sha256.txt` passe depuis `auteur/outils/` ;
- [L] : ligne « aucune sonde générique au-dessus du plancher sur (i-a) », réserves [], en échec [], non interprétables [] ;
  P3-P1 borne basse 1,2464 > 0 ; P3-P3 bornes basses 0,5313 ≤ 0,5717 et 0,4813 ≤ 0,5356 à 97,5 % ; dix jeux « non
  au-dessus » ; audit R4 non déclenché ; contrôle négatif « conforme » ; témoin 500 sur 600 contre 4 sur 600 ; P3-P2 et
  mention à bornes basses négatives ;
- [A] : une conclusion établie (P3-P1) ; 53 contrôles, dont 52 « sans objet » et un seul sur P3-P1 (A6, non contraire) ;
  aucune réserve, aucune recommandation, aucun arrêt ; audit de symétrie de l'addendum non déclenché ;
- choix des sondes principales : neuf sondes de tromperie à 1,0 exactement ; la règle famille puis couche donne
  `tromperie-difference_moyennes-c15` ; enjeux : `enjeux-lineaire-c15` (0,99214) ;
- commits : S seul commit qui ajoute le sceau de [P] ; [PA] scellé à `e03df08` avant le manifeste de la lecture ; [L] et [A]
  touchés seulement par `63386e6` et `6a97d69`.

**Ligne retenue** : « aucune sonde générique au-dessus du plancher sur (i-a) » ([P] l. 428). **Réserves** : aucune (lecture),
aucune (addendum). **Réserve bloquante** : aucune.

## Ce que j'ai changé, et pourquoi

1. **Puissance** (SC-1-01, majeur ; SC-2-01). La phrase sur l'aire minimale détectable (≈ 0,57 à 0,58) est gardée, mais
   avec ses hypothèses écrites et les nombres observés : plancher 0,5717 et 0,5356 contre 0,52 à 0,53 ; demi-largeur 0,0435
   et 0,0444 contre 0,025 à 0,037. Le verdict dit que ces hypothèses ne tiennent pas et que les écarts vont dans le sens d'une
   puissance plus faible. Aucune aire minimale nouvelle n'est calculée (grandeur non écrite, nœud de Lazar, [P] l. 415-416).
   Le chiffre d'ordre de grandeur du sceptique 1 (≈ 0,537) n'est pas repris. La demi-largeur des enjeux est 0,0444 (le rapport
   du sceptique 2 écrivait 0,0435 pour les deux).
2. **Statut des prédictions** (SC-1-02). Ajout : P3-P3 « réfutée au sens de la table des prédictions » ([P] l. 157), lue « non
   détecté à cette puissance » ; P3-P4 et P3-P7 « sans objet ». En tête, en section 1 et en section 6.
3. **Dix jeux** (SC-1-03, SC-2-03). Table complète en section 3 : niveau, aire, intervalle, quantile du plancher, état, et
   colonne « lu ? » (seuls les deux jeux saboteur contre honnête sont lus). Nombres tirés de [L] par mon outil [O3].
4. **G0** (SC-1-04, SC-2-08). La phrase de la section 1 « P3 n'établit pas, même partiellement, les critères 2 et 3 de G0 »
   est remplacée par « la ligne retenue ne prononce aucun critère de G0 ». La section 6 dit que la seule formule G0 de la
   table est à la ligne « P3-P4 conforme », non atteinte, et que la table ne traduit P3-P1 en aucune formule sur G0.
5. **Formes du coût** (SC-1-05, SC-2-02). La remarque 1 de la section 7 affirmait à tort que le saboteur n'utilise aucune
   forme qui pourrait fabriquer l'effet ; il a 3 actions à plusieurs nombres. Remplacée par les comptes des deux conditions,
   sans argument ni sens d'effet. L'argument tiré du descriptif de A6 est retiré ([PA] l. 288 : « rien n'est ajouté ») ; en
   section 5, seuls les champs du contrôle A6 sont cités.
6. **Empreintes** (SC-1-06, SC-2-07). Colonne « compagnon » ajoutée ; [D], [REC], [O1], [O2], [O3] dits sans compagnon ; [D]
   rattaché au commit `3fb9d34` ; commits `63386e6` ([L]) et `6a97d69` ([A]) cités ; dossier d'où lancer la vérification de
   `outils-sha256.txt` indiqué. Le fichier de l'auteur n'est pas modifié (hors de mon dossier).
7. **Prédicteurs triviaux sur chaque jeu** (SC-1-07, SC-2-04). Table des séparations sur les dix jeux en section 4 (sonde,
   longueur notée, rang du pas, mention, coût seul, titre seul) et plus grandes séparations. Le verdict note que la longueur
   notée sépare autant ou plus que la sonde sur sept des huit jeux autres que saboteur contre honnête, et que c'est sans effet
   (règle de la fuite, jeu au-dessus du plancher seulement).
8. **Fuite avérée** (SC-2-05). Sortie de la table des réserves gelées ; écrite à part comme règle, « sans objet ».
9. **« Réserve bloquante »** (SC-2-06). Le terme est attribué à la commande du verdict ; le verdict écrit d'abord « aucune
   réserve, ni de la lecture, ni de l'addendum ».
10. **Registre** (SC-1-08). Mis en préalable au scellement (section 8) : la session doit consigner la lecture décisive
    (`63386e6`) et le run de l'addendum (`6a97d69`) au registre des décisions avant de sceller ce verdict. Vérifié : aucune
    ligne ne les nomme encore dans `registres/decisions.md` ni dans `registres/etat.md`.
11. **Petites précisions du correcteur** : en-tête « En tête » demandé par la commande (ligne, porte, réserves, réserve
    bloquante) ; écart maximal des bornes des sceptiques écrit séparément pour une aire (0,0075) et pour le coût (0,0109) ;
    placebo rapporté avec son aire et son intervalle ; 132 actions comparables du contrôle négatif citées ([E]) ; limites de
    ce qui n'a pas pu être vérifié reprises des deux rapports.

## Constats refusés

Aucun. Seul le chiffre d'ordre de grandeur de SC-1-01 n'est pas repris, en accord avec la correction proposée par le
sceptique lui-même.

## À faire par la session (hors de mon rôle)

- Consigner au registre des décisions la lecture décisive et le run de l'addendum (SC-1-08).
- Sceller le verdict (R6), puis le soumettre à Lazar pour GO (R13). Je n'ai rien écrit dans le dépôt.

## Fichiers du correcteur

- `…/correcteur/verdict-P3-premier-test-i-a-v1.md` (verdict final) ;
- `…/correcteur/retour-correcteur.md` (ce fichier) ;
- `…/correcteur/outils/extraire_tables.py` et `extraire_tables.sortie.txt` ([O3] : lancé par
  `python3 -I extraire_tables.py /home/user/controle-ia-travail/diag/20261020-075740-p3-lecture/lecture-p3.json`, code 0 ;
  vérifie l'empreinte de [L] avant de lire) ;
- `…/correcteur/empreintes-correcteur.txt` (chemins complets ; vérifiable par `sha256sum -c` depuis n'importe quel dossier).
