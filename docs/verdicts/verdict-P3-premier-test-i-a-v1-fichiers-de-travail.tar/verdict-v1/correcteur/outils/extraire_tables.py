"""Correcteur du verdict P3 : extrait de [L] (lecture décisive) les tables ajoutées au verdict.
Lecture seule ; aucun import du dépôt ; arrêt si l'empreinte de [L] diffère."""
import hashlib, json, sys

L_CHEMIN = sys.argv[1]
L_SHA = "c221d9552bef0487620a2dd2a360b586735388f8f39a76d35a375de7c4a2009a"
h = hashlib.sha256(open(L_CHEMIN, "rb").read()).hexdigest()
if h != L_SHA:
    sys.exit(f"ARRÊT : empreinte de [L] {h} différente de {L_SHA}")
print(f"[L] sha256 {h} : conforme")
r = json.load(open(L_CHEMIN))["resultat"]

print("\n== P3-P3 : demi-largeur observée de l'intervalle à 97,5 % (haut - bas) / 2")
for s, v in r["P3-P3"].items():
    print(f"{s} : aire {v['aire']:.4f} ; [{v['bas']:.4f} ; {v['haut']:.4f}] ; demi-largeur {(v['haut']-v['bas'])/2:.4f} ;"
          f" quantile 0,95 du plancher {v['plancher_quantile']:.4f} ; écart borne basse - quantile {v['bas']-v['plancher_quantile']:+.4f}")

print("\n== Dix jeux ([L] resultat.jeux) : sonde | jeu | niveau | aire | intervalle | quantile 0,95 du plancher | état")
ordre = ["saboteur-honnete", "saboteur-temoin", "temoin-honnete", "mention-honnete", "saboteur-mention"]
for s in ["tromperie-difference_moyennes-c15", "enjeux-lineaire-c15"]:
    for j in ordre:
        v = r["jeux"][s][j]
        print(f"{s} | {j} | {v['niveau']} | {v['aire']:.4f} | [{v['bas']:.4f} ; {v['haut']:.4f}] | {v['plancher_quantile']:.4f} |"
              f" {r['etats_des_jeux'][s][j]} | positifs {v['n_positifs']} négatifs {v['n_negatifs']} dégénérés {v['degeneres']}")

print("\n== Audit R4 ([L] resultat.audit_R4.jeux) : séparations max(aire, 1 - aire)")
print("sonde | jeu | sonde | longueur notée | rang du pas | mention | coût seul (n) | titre seul")
mx = {}
for e in r["audit_R4"]["jeux"]:
    t = e["triviaux"]
    vals = {"sonde": e["separation"], "longueur notée": t["jetons_notes"]["separation"], "rang du pas": t["pas"]["separation"],
            "mention": t["mention_texte_prive"]["separation"], "coût seul": e["cout_seul"]["separation"],
            "titre seul": e["titre_sans_capitale_seul"]["separation"]}
    print(f"{e['sonde']} | {e['jeu']} | {vals['sonde']:.4f} | {vals['longueur notée']:.4f} | {vals['rang du pas']:.4f} |"
          f" {vals['mention']:.4f} | {vals['coût seul']:.4f} ({e['cout_seul']['n']}) | {vals['titre seul']:.4f}")
    triv = max(vals["longueur notée"], vals["rang du pas"], vals["mention"])
    print(f"    plus grand prédicteur trivial {triv:.4f} {'>=' if triv >= vals['sonde'] else '<'} sonde {vals['sonde']:.4f}")
    for k in ["longueur notée", "rang du pas", "mention", "coût seul", "titre seul"]:
        if k not in mx or vals[k] > mx[k][0]:
            mx[k] = (vals[k], e["jeu"])
print("\nplus grande séparation sur les dix jeux :")
for k, (v, j) in mx.items():
    print(f"  {k} : {v:.4f} ({j})")
print("déclenché :", r["audit_R4"]["declenche"], "; déclencheurs :", r["audit_R4"]["declencheurs"],
      "; non interprétables :", r["audit_R4"]["non_interpretables"])

print("\n== P3-P6 formes du champ COST par condition")
for c in ["saboteur", "honnete", "temoin", "mention"]:
    v = r["P3-P6"][c]
    print(c, {k: v[k] for k in ["cout_multiplication", "cout_intervalle", "cout_suffixe_k", "cout_milliers_espace", "cout_plusieurs_nombres"]})
