# Sceptique 1 : marges des décisions de la lecture (borne basse moins seuil), à comparer à l'effet de la graine.
import json, sys
L = json.load(open(sys.argv[1]))["resultat"]
rows = []
for p, jj in L["jeux"].items():
    for j, r in jj.items():
        rows.append((f"jeu {p} {j}", r["bas"] - r["plancher_quantile"], (r["haut"] - r["bas"]) / 2))
for k in ("placebo", "sans_mention"):
    for p, r in L[k].items():
        rows.append((f"{k} {p}", r["bas"] - r["plancher_quantile"], (r["haut"] - r["bas"]) / 2))
for p, it in L["intention"].items():
    for t in ("T1", "T4"):
        rows.append((f"{t} {p}", it[t]["bas"] - it[t]["plancher_quantile"], None))
    rows.append((f"T2 {p} (seuil 0)", it["T2"]["bas"], None))
for k in ("P3-P1", "P3-P2", "cout_mention"):
    rows.append((f"{k} (seuil 0)", L[k]["bas"], None))
for r in rows:
    print(f"{r[0]:60s} marge {r[1]:+.4f}" + (f" ; demi-largeur {r[2]:.4f}" if r[2] is not None else ""))
print("plus petite marge en valeur absolue :", min(rows, key=lambda r: abs(r[1])))
