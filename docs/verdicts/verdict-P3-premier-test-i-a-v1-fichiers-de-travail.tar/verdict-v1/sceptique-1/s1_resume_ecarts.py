# Sceptique 1 : relevé des écarts d'intervalles (graine propre contre lecture), à partir de la sortie de s1_recalcul.py.
import re, sys
txt = open(sys.argv[1]).read().splitlines()
pat = re.compile(r"(?:IC95|IC) \[(-?[\d.]+) ; (-?[\d.]+)\] \((?:lecture|lect) \[(-?[\d.]+) ; (-?[\d.]+)\]")
rows = []
for l in txt:
    mm = pat.search(l)
    if mm and "digitize-droite" not in l:
        a, b, c, d = map(float, mm.groups())
        rows.append((l.split(":")[0][:70], a - c, b - d))
for r in rows:
    print(f"{r[0]:70s} bas {r[1]:+.4f} haut {r[2]:+.4f}")
print("écart maximal, bornes basses :", max(abs(r[1]) for r in rows), "; bornes hautes :", max(abs(r[2]) for r in rows), "; intervalles :", len(rows))
