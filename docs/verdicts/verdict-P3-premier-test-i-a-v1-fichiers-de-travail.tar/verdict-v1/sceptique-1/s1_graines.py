# Sceptique 1 : contrôle des graines des manifestes (R9), sans le code du dépôt.
import json, sys
import numpy as np
for chemin in sys.argv[1:]:
    m = json.load(open(chemin))
    ok = 0; ko = []
    for cle, g in m["graines"].items():
        ss = np.random.SeedSequence(int(g["entropie"]), spawn_key=tuple(int(x) for x in g["spawn_key"]))
        etat = [int(x) for x in ss.generate_state(2)]
        if etat == list(g["etat_controle"]): ok += 1
        else: ko.append(cle)
    ent = {g["entropie"] for g in m["graines"].values()}
    print(chemin, "graines", len(m["graines"]), "etat_controle reproduit", ok, "echecs", ko, "entropies", ent)
