#!/bin/sh
# Sceptique 1 : empreintes des pièces citées (lecture seule), comparées à leurs compagnons quand ils existent.
cd /home/user/controle-ia-travail || exit 1
for f in prereg/P3-premier-test-i-a-v1.md prereg/P3-addendum-lecture-complementaire-v1.md runs/20261019-230011-p3-reel/manifeste.json diag/20261019-230011-p3-reel/resume.json diag/20261019-230011-p3-reel/sondes-figees.json diag/20261019-230011-p3-reel/episodes-p3.json donnees/20261019-230011-p3-reel/scores-p3.npz donnees/20261019-230011-p3-reel/jetons-principales-p3.npz donnees/20261019-230011-p3-reel/textes-actions-p3.jsonl diag/20261020-075740-p3-lecture/lecture-p3.json runs/20261020-075740-p3-lecture/manifeste.json diag/20261020-075849-addendum-p3/lecture-addendum-p3.json runs/20261020-075849-addendum-p3/manifeste.json registres/decisions.md docs/procedures/P3-addendum-v1/complements_p3_v1.py; do
  a=$(sha256sum "$f" | cut -d' ' -f1)
  if [ -f "$f.sha256" ]; then c=$(cut -d' ' -f1 "$f.sha256"); if [ "$a" = "$c" ]; then e="= compagnon"; else e="DIFFÉRENT du compagnon $c"; fi; else e="(pas de compagnon)"; fi
  echo "$a $f $e"
done
sha256sum /tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/p3-recuperation-v1.sortie.txt
sha256sum /tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-p3/verdict-v1/auteur/verdict-P3-premier-test-i-a-v1-brouillon.md
sha256sum /tmp/claude-0/-home-user/50508bff-8fed-5fe9-beef-07f1bdcaf615/scratchpad/verdict-p3/verdict-v1/auteur/outils/*
echo "--- git (lecture seule)"
git log --diff-filter=A --format='%H %cI scellement P3' -- prereg/P3-premier-test-i-a-v1.md.sha256
git log --diff-filter=A --format='%H %cI scellement addendum' -- prereg/P3-addendum-lecture-complementaire-v1.md.sha256
git diff --quiet 7a54d431d89745839220f882b41b13e8c62ecfdd e03df08b2678c3d22a2908294faa2489cbba21e6 -- src tests && echo "src et tests identiques entre le commit du code 7a54d43 et e03df08 (commit de la lecture)"
git diff --quiet 97dd82900cb120d5ce7328f8569d514fe987cc3c HEAD -- prereg/P3-premier-test-i-a-v1.md prereg/P3-premier-test-config-v1.json && echo "préenregistrement et configuration inchangés depuis S"
git diff --quiet eb572dacc3b77c16d4e9468c7678a5073da59d7a HEAD -- diag/20261019-230011-p3-reel donnees/20261019-230011-p3-reel runs/20261019-230011-p3-reel && echo "données du run inchangées depuis la tête récupérée eb572da"
git diff --quiet 63386e608f741100a223543cec8c2d19309c2116 HEAD -- diag/20261020-075740-p3-lecture runs/20261020-075740-p3-lecture && echo "lecture inchangée depuis son commit 63386e6"
git merge-base --is-ancestor 7a54d431d89745839220f882b41b13e8c62ecfdd 97dd82900cb120d5ce7328f8569d514fe987cc3c && echo "7a54d43 ancêtre de S"
git merge-base --is-ancestor 97dd82900cb120d5ce7328f8569d514fe987cc3c HEAD && echo "S ancêtre de la tête"
