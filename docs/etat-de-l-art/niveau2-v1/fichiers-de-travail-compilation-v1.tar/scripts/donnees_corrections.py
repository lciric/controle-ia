# -*- coding: utf-8 -*-
"""Données de la table des corrections.
Chaque entrée : (document, ligne, texte actuel, verdict, citations du lecteur, formulation, source, pages, rapport, repère).
Citations et formulation : (ligne du rapport, début, fin) ; fin None = extrait exact ; fin '$' = jusqu'à la fin de la ligne.
Les extraits sont tirés des rapports par programme (gen_livrables.py), jamais recopiés à la main.
"""
C, I, R = 'corrigé', 'introuvable', 'confirmé avec réserve'

E = []
def e(doc, l, actuel, v, q, f, src, pg, rap, rep):
    E.append(dict(doc=doc, l=l, actuel=actuel, v=v, q=q, f=f, src=src, pg=pg, rap=rap, rep=rep))

# ---------------- programme v2 ----------------
e('PROG', 59, "la notion de puissance n'est pas la même sous garantie toujours valide et au sens du test séquentiel de Wald (Koning & Grünwald, arXiv 2208.07610)",
  C, [(244, 'les auteurs sont faux', None), (245, 'la nuance de fond est déformée', 'au pire cas.')],
  (249, 'Sous garantie toujours valide', '$'), 'arXiv 2208.07610v2', '2, 6-7, 26', 'lemme', 'section 3, A1')
e('PROG', 60, "un adversaire couvert qui connaît la contrainte de faux positifs peut imposer un délai de détection d'ordre Θ(γ) si l'on ne contraint que la furtivité",
  C, [(255, 'Le noyau est exact', 'Quatre points sont à corriger :')],
  (264, 'On considère un adversaire couvert', '$'), 'arXiv 2601.20022v2', '1, 3-4, 8-11', 'lemme', 'section 3, A2')

# ---------------- état de l'art v1 ----------------
e('EdA', 21, "séparation contrôle/données contre les ordres en bande (CaMeL, hiérarchie d'instructions)",
  C, [(186, 'appelle la même nuance', 'elle ne cite pas mes PDF')], None,
  'arXiv 2601.09923v3 ; arXiv 2505.22852v1', '—', 'C3b', 'hors liste, formulation pour la ligne 138')
e('EdA', 33, 'arXiv 2502.03407, ICML 2025', I, [(184, 'introuvable pour la venue', 'aucune occurrence')],
  (184, 'arXiv 2502.03407 v1 (5 février 2025)', 'à empreinter'), 'arXiv 2502.03407v1', '1', 'A2b', '3.2')
e('EdA', 33, 'AUROC de 0,96 à 0,999 selon les jeux', R, [(186, 'réponses ambiguës exclues', 'sous-performance volontaire)')],
  None, 'arXiv 2502.03407v1', '1, 6, 23', 'A2b', '3.4-3.5')
e('EdA', 33, 'environ 95 à 99 % des réponses trompeuses attrapées à 1 % de faux positifs sur conversation neutre', R,
  [(188, 'le rappel est mesuré contre des réponses témoins', '(p. 23)')], None, 'arXiv 2502.03407v1', '1, 6', 'A2b', '3.6-3.8')
e('EdA', 33, "→ Base mono-action ; motive l'agrégation temporelle et l'abandon de la moyenne.", C, [],
  (192, 'Base mono-action ; motive une agrégation au-delà', 'du jeu'), 'arXiv 2502.03407v1', '22', 'A2b', '3.10-3.11')
e('EdA', 34, 'sondes « enjeux élevés » de performance comparable aux moniteurs génératifs de taille moyenne pour environ six ordres de grandeur de calcul en moins',
  C, [(75, 'les bases sont promptées', 'la sonde est battue')],
  (75, 'sondes « enjeux élevés » dont', '55 % pour la meilleure base'), 'arXiv 2506.10805v4', '1, 5, 10', 'A1', '2506.10805, n° 3')
e('EdA', 34, 'AUROC moyen supérieur à 0,91 hors distribution', R, [(76, "c'est la sonde à attention", 'fait mieux (0,929)')],
  None, 'arXiv 2506.10805v4', '10, 25', 'A1', '2506.10805, n° 4')
e('EdA', 35, "sur sandbagging et délit d'initié", C, [(117, 'cinq jeux, dont un de code à porte dérobée', None)],
  (117, 'sur cinq jeux de tromperie stratégique', 'comme témoin honnête'), 'arXiv 2507.12691v3', '2, 3, 4', 'A1', '2507.12691, n° 3')
e('EdA', 35, '→ La métrique de H1 existe ; pas sur sabotage étalé.', R, [(119, "la métrique principale est l'aire sous la courbe", '(0,776 contre 0,899)')],
  None, 'arXiv 2507.12691v3', '7, 8, 15', 'A1', '2507.12691, n° 5')
e('EdA', 36, 'Taylor et al. (institut britannique / FAR.AI)', C, [],
  (181, "Taylor et al. (institut britannique de sécurité", 'décembre 2025'), 'arXiv 2512.07810v1', '1', 'A3', 'n° 7')
e('EdA', 36, 'les méthodes fondées sur les internes sont plus prometteuses que la boîte noire', C, [],
  (183, 'les sondes linéaires (une méthode fondée sur les internes)', 'sur la distribution évaluée'), 'arXiv 2512.07810v1', '1, 3, 4', 'A3', 'n° 9')
e('EdA', 36, "mais leur usage naïf est battu par des comportements introduits par l'équipe rouge", C, [],
  (184, 'leur application naïve était vulnérable', "manqué l'autre (Oak)"), 'arXiv 2512.07810v1', '1, 16, 17, 22', 'A3', 'n° 10')
e('EdA', 36, 'dont un imitant Llama-3.1-8B-Instruct', R, [(186, 'mais incomplet.', 'imiter ce modèle.')],
  None, 'arXiv 2512.07810v1', '7, 9, 36', 'A3', 'n° 12')
e('EdA', 36, "→ Confirme l'écart", C, [],
  (187, "→ Confirme qualitativement l'écart", 'pas de tâche ouverte)'), 'arXiv 2512.07810v1', '4, 26', 'A3', 'n° 13')
e('EdA', 42, 'cascade sonde → juge génératif', C, [],
  (59, 'cascade interne de classifieurs polynomiaux emboîtés', '(annexe F.3)'), 'arXiv 2509.26238v4', '1, 3', 'A2b', '1.6-1.7')
e('EdA', 42, '→ Base architecturale seulement.', R, [(61, 'la base publiée agrège par moyenne sur les tokens', 'sonde de production')],
  None, 'arXiv 2509.26238v4', '10', 'A2b', '1.8')
e('EdA', 44, "meilleur protocole à 72,7 % de sécurité pour 95 % d'utilité", C, [(155, '72,7 % est le score de', 'sans ré-échantillonnage')],
  (155, '72,7 % de sécurité à 95 % d\'utilité pour Defer to trusted', 'surveillance non fiable'), 'arXiv 2504.10374v1', '5, 8, 9', 'A1', '2504.10374, n° 4')
e('EdA', 44, 'BashBench, 257 tâches', R, [(156, "Réserve : l'annexe C parle", '« nos 257 tâches »')],
  None, 'arXiv 2504.10374v1', '1, 2, 18', 'A1', '2504.10374, n° 5')
e('EdA', 45, "compare deux intensités d'intervention", C, [(195, "il s'agit de deux familles de protocoles", 'pas de deux intensités')],
  (195, 'compare le réessai (bloquer', "exploité par l'attaquant"), 'arXiv 2605.26047v2', '1, 5', 'A1', '2605.26047, n° 2')
e('EdA', 46, 'attaques furtives sur systèmes cyber-physiques qui gardent chaque résidu sous le seuil, arXiv 2005.07821', C,
  [(46, "l'article est un article de détection", 'seulement au seuil par pas')],
  (46, 'détecteur à signe cumulé sans mémoire (CUSIGN)', 'de leurs résidus, arXiv 2005.07821'), 'arXiv 2005.07821v1', '1, 3, 6', 'A1', '2005.07821, n° 1')
e('EdA', 47, 'arXiv 2605.27958, ACL 2026', I, [(112, 'introuvable pour la venue', 'que le tampon arXiv')],
  (112, 'arXiv 2605.27958 v1 (27 mai 2026)', 'sans venue imprimée'), 'arXiv 2605.27958v1', '1', 'A2b', '2.3')
e('EdA', 47, "rejette l'hypothèse d'une direction unique (AUROC 0,61 à 0,80 avec une seule direction)", C, [],
  (113, "rejette l'hypothèse d'une direction universelle", 'au moins 0,998 en domaine'), 'arXiv 2605.27958v1', '1, 6, 13', 'A2b', '2.4-2.6')
e('EdA', 47, 'effondrement sous changement de style', C, [],
  (116, 'sous huit changements de style', 'dépend de la couche choisie'), 'arXiv 2605.27958v1', '1, 7, 8', 'A2b', '2.7-2.9')
e('EdA', 47, 'récupéré par augmentation de style (environ 0,98)', R, [(119, 'confirmé', '+0,062')],
  None, 'arXiv 2605.27958v1', '1, 8', 'A2b', '2.10-2.11')
e('EdA', 47, 'les sondes multidimensionnelles récupèrent le signal', R, [(121, 'en domaine, sur D-RepE', 'première composante principale')],
  None, 'arXiv 2605.27958v1', '1', 'A2b', '2.12')
e('EdA', 47, 'soutient HC2b avec une réserve sur les corrélats de surface', C, [],
  (124, 'ne teste pas HC2b', 'la réponse reste exacte'), 'arXiv 2605.27958v1', '9', 'A2b', '2.15')
e('EdA', 64, "72,7 % de sécurité à 95 % d'utilité", C, [],
  (159, 'Ctrl-Z (ré-échantillonnage, Time travel)', '— arXiv 2504.10374'), 'arXiv 2504.10374v1', '8, 9', 'A1', '2504.10374, n° 8')
e('EdA', 65, 'AUROC 0,96 à 0,999', R, [(194, "même réserve qu'en 3.4", None)],
  None, 'arXiv 2502.03407v1', '6', 'A2b', '3.12')
e('EdA', 66, 'AUROC moyen > 0,91 hors distribution', R, [(79, "même précision qu'au n° 4", 'à 0,929')],
  None, 'arXiv 2506.10805v4', '10, 25', 'A1', '2506.10805, n° 7')
e('EdA', 70, 'la moyenne, la médiane et les scores par token cèdent', C, [],
  (55, "l'agrégation par moyenne ou par médiane des scores par jeton cède", None), 'arXiv 2506.14261v4', '4, 7', 'A2a', '1.5')
e('EdA', 70, "**Établi** : au niveau token, les sondes à max ou à attention résistent à l'évasion par apprentissage par renforcement sur les poids", C, [],
  (56, '**Établi dans le cadre testé**', 'robustesse fondamentale'), 'arXiv 2506.14261v4', '6, 10, 19', 'A2a', '1.6')
e('EdA', 70, 'les sondes à max ou à attention résistent', R, [(53, 'au sens des auteurs', 'les réserves)')],
  None, 'arXiv 2506.14261v4', '1, 7', 'A2a', '1.3')
e('EdA', 72, 'analogue cyber-physique arXiv 2005.07821', C, [(48, "l'article ne contient aucune borne", 'autre statistique cumulée')],
  (48, 'exemple cyber-physique construit, sans borne', '(arXiv 2005.07821, p. 5-6)'), 'arXiv 2005.07821v1', '5, 6', 'A1', '2005.07821, n° 3')
e('EdA', 81, "ce n'est pas une simple dilution (un moniteur conjoint sur les commits recombinés reste à une suspicion d'environ 0,91, quasi plate en N)", C, [],
  (182, 'la baisse n\'est pas due d\'abord à la dilution', 'pas déployable selon les auteurs'), 'arXiv 2607.07368v1', '1, 8, 10', 'B1', '3.3, F3.1')
e('EdA', 81, "un planificateur explicite multiplie jusqu'à sept fois la réussite d'attaque", C, [],
  (183, 'un planificateur explicite multiplie les cotes', 'réussite non détectée'), 'arXiv 2607.07368v1', '1, 11, 53', 'B1', '3.4, F3.2')
e('EdA', 81, "environnement FakeLab (9 services, 86 tâches bénignes, 4 objectifs d'attaque) partagé sur demande", R,
  [(172, 'Précision : accès sous conditions', 'licence non mentionnée')], None, 'arXiv 2607.07368v1', '1, 13, 74, 77', 'B1', '3.5')
e('EdA', 81, 'collusion et moniteur non fiable laissés à plus tard', C, [],
  (184, 'la coordination entre agents attaquants est étudiée', 'points de Schelling)'), 'arXiv 2607.07368v1', '3, 4, 28', 'B1', '3.7, F3.3')
e('EdA', 82, "un ensemble de quatre moniteurs fait passer l'évasion graduelle de 93 % à 47 % pour moins de 2 % de faux positifs", C, [],
  (117, 'un ensemble de quatre moniteurs (diff', 'graduelles et positionnelles'), 'arXiv 2607.02514v2', '8, 13', 'B1', '2.4, F2.1')
e('EdA', 82, 'code dans ControlArena', C, [],
  (118, 'code public dans un dépôt construit', 'persistent-state-eval)'), 'arXiv 2607.02514v2', '1, 5', 'B1', '2.5, F2.2')
e('EdA', 83, 'première attaque distribuée multi-agents implémentée', C, [],
  (63, "première attaque distribuée d'agents implémentée", '(« à notre connaissance »)'), 'arXiv 2605.31593v1', '1', 'B1', '1.2, F1.1')
e('EdA', 83, 'attrapée environ cinq fois moins souvent que les attaques antérieures', R,
  [(54, 'Précision : le « cinquième »', '30 à 80 % plus faible')], None, 'arXiv 2605.31593v1', '1, 4', 'B1', '1.3')
e('EdA', 83, 'rappel de campagne de 81 à 87 % pour environ 2,4 à 3,1 % de faux positifs, contre 75 % pour un moniteur standard', C, [],
  (64, 'avec un trafic bénin dix fois plus nombreux', 'contre 55 % au même taux'), 'arXiv 2605.31593v1', '7', 'B1', '1.5, F1.2')
e('EdA', 83, '→ Agrégation au niveau flotte, boîte noire.', R,
  [(58, 'Précision : la « flotte »', 'pas un moniteur à accès interne')], None, 'arXiv 2605.31593v1', '4, 6, 8', 'B1', '1.7')
e('EdA', 84, '**The Best-Laid SCHEMEs**, arXiv 2605.29178', R, [],
  (280, '**Radev, Haas, Arnav, Bernabeu-Pérez, The Best-Laid SCHEMEs**, arXiv 2605.29178', None), 'arXiv 2605.29178v1', '1', 'B1', '5.1, F5.1')
e('EdA', 84, 'avertir les agents de la surveillance réduit leur capacité plus que leur détectabilité', R,
  [(277, 'Précision : mesuré sur Gemini 3.1 Pro seulement', "jusqu'à 11 % sous d'autres vues")], None, 'arXiv 2605.29178v1', '8, 9', 'B1', '5.2')
e('EdA', 87, 'Ghanem & Keele', C, [], (239, 'Ghanem (Keele University), auteur unique', None), 'arXiv 2608.02698v1', '1', 'B1', '4.1, F4.1')
e('EdA', 87, 'détection de collusion au niveau population, explicitement boîte noire et inter-mandants', R,
  [(235, 'Précision indispensable', 'déclarées fictives')], None, 'arXiv 2608.02698v1', '1, 3, 6', 'B1', '4.2')
e('EdA', 87, '→ Délimite la frontière ; le pendant boîte blanche reste ouvert.', C, [],
  (240, '→ Propose, sans résultat mesuré', "n'est pas vierge selon cette source."), 'arXiv 2608.02698v1', '1, 3, 8, 10', 'B1', '4.3, F4.2')
e('EdA', 88, 'le meilleur ensemble de trois moniteurs diversifiés donne 2,4 fois le gain de trois moniteurs identiques', R,
  [(345, 'Précision (R4)', 'optimiste selon les auteurs)')], None, 'arXiv 2605.15377v2', '2, 3, 5', 'B1', '7.2')
e('EdA', 88, '94,6 % des ensembles diversifiés de cinq battent un appel unique à un grand modèle à coût égal', R,
  [(346, 'Précision : le « grand modèle »', 'pas à coût égal)')], None, 'arXiv 2605.15377v2', '7', 'B1', '7.3')
e('EdA', 88, '→ Thèse qualitative de H5 occupée en boîte noire.', R,
  [(350, 'confirmé sur le vérifiable', 'pas de trajectoires d\'agents')], None, 'arXiv 2605.15377v2', '1, 7', 'B1', '7.7')
e('EdA', 89, 'la compétence, pas la lignée, gouverne les ensembles de moniteurs', R,
  [(394, 'Précision : 24 moniteurs', 'puissance limitée')], None, 'arXiv 2608.16190v1', '1, 2, 9', 'B1', '8.1')
e('EdA', 89, 'sélectionner sur la seule diversité perd contre le hasard', C, [],
  (400, 'la métrique de diversité (corrélation moyenne', "que l'article crédite"), 'arXiv 2608.16190v1', '1, 2, 8', 'B1', '8.2, F8.1')
e('EdA', 89, '→ Impose de mesurer la diversité *effective* (transfert d\'attaque), pas la décorrélation brute.', C, [],
  (401, '→ Montre que la décorrélation brute', "absente de l'article."), 'arXiv 2608.16190v1', '1, 8', 'B1', '8.3, F8.2')
e('EdA', 90, 'résistante à la collusion (ControlArena)', C,
  [(260, 'ControlArena confirmé', 'attaques non adaptatives')], None, 'arXiv 2604.03968v1', '1, 8, 14', 'A4', '5.3')
e('EdA', 90, 'scores moyens honnête 0,206 contre attaque 0,616', C,
  [(261, 'chiffres exacts, mais ceux de la variante heuristique', 'simple moyenne pondérée')], None, 'arXiv 2604.03968v1', '1, 8, 11', 'A4', '5.4')
e('EdA', 90, '95 % de sécurité au seuil 0,5 contre 0 % pour une surveillance non fiable à score unique', C,
  [(262, 'chiffre imprimé, mais tiré', 'lui aussi à 0 %')], None, 'arXiv 2604.03968v1', '8, 13, 16', 'A4', '5.5')
e('EdA', 91, 'arXiv 2510.09462, ICLR 2026', I,
  [(57, 'introuvable dans le PDF empreinté', 'métadonnées du fichier sans venue')],
  (62, 'arXiv 2510.09462v2 (2 mars 2026)', 'à vérifier sur la version des actes'), 'arXiv 2510.09462v2', '1', 'A4', '1.3')
e('EdA', 93, '→ Matériel de H7.', C,
  [(329, 'le « pot de miel » de l', 'résultat nul confondu')], None, 'arXiv 2604.13301v1', '1, 4, 5', 'A4', '6.2')
e('EdA', 102, "Claude 3.7 Sonnet ramène sa performance au niveau d'un modèle plus faible sans hausse de suspicion", I,
  [(219, '**Introuvable** dans mes sept PDF', 'sur source primaire.')], None,
  'billet d\'Anthropic de mars 2025 (Gasteiger et al. 2025), non lu ; sept PDF du lot A3', '—', 'A3', 'n° 17')
e('EdA', 102, 'empoisonnement par environ 250 documents', C, [],
  (216, '250 documents empoisonnés suffisent', '100 ne suffisent pas'), 'arXiv 2510.07192v1', '1, 3, 4, 21', 'A3', 'n° 14')
e('EdA', 102, '(Anthropic, institut britannique, Alan Turing Institute, arXiv 2510.07192)', C,
  [(218, "Ajouter l'université d'Oxford", 'Souly (institut britannique).')], None, 'arXiv 2510.07192v1', '1', 'A3', 'n° 16')
e('EdA', 108, 'évasion graduelle 93 % → 47 % ; faux positifs < 2 %', C, [],
  (119, 'évasion graduelle 93 % (diffs complets, le plus faible)', "seuil choisi sur l'évaluation"), 'arXiv 2607.02514v2', '5, 8', 'B1', '2.7, F2.3')
e('EdA', 109, 'rappel de campagne 81–87 % à ~2,4–3,1 % de faux positifs', C, [],
  (65, 'rappel de campagne 81,1–87,2 %', '(× 100)'), 'arXiv 2605.31593v1', '7', 'B1', '1.8, F1.3')
e('EdA', 110, "réussite d'attaque jusqu'à × 7", C, [],
  (185, "cotes d'achèvement de la tâche secondaire × 5,74", 'indépendamment de la détection'), 'arXiv 2607.07368v1', '11, 53', 'B1', '3.9, F3.4')
e('EdA', 111, 'gain × 2,4 contre moniteurs identiques', R, [(351, "mêmes précisions qu'en 7.2", None)],
  None, 'arXiv 2605.15377v2', '2, 6', 'B1', '7.8')
e('EdA', 129, 'taux de déplacement de verdict', R,
  [(52, "Le taux publié n'est pas une proportion", "affectations complémentaires d'indices"), (52, "C'est donc un minorant", 'proportion de bascules.')],
  None, 'arXiv 2509.26072v2', '3, 5', 'C2a', '1.2')
e('EdA', 129, "par exemple + 30 % d'effet de récence pour un grand modèle", R,
  [(53, '« + 30 % » est un écart', '+ 16, + 16 et + 4.')], None, 'arXiv 2509.26072v2', '3, 8', 'C2a', '1.4')
e('EdA', 130, 'sycophancie directe de 22 % à 71 %', R,
  [(219, "Les quatre chiffres viennent d'une ablation par tour", '289 valides'), (220, 'Les chiffres principaux diffèrent', None)],
  None, 'arXiv 2604.21564v2', '9, 12, 17, 18', 'C2a', '4.2')
e('EdA', 130, 'indirecte de 41 % à 78 %', R,
  [(219, "Les quatre chiffres viennent d'une ablation par tour", '289 valides'), (221, 'Risque de confusion : 78 %', '(médiane, débat)')],
  None, 'arXiv 2604.21564v2', '12, 17, 18', 'C2a', '4.3')
e('EdA', 131, "Who Endorsed It?, arXiv 2601.13433 (autorité par niveau d'expertise)", C, [(107, 'sortir l\'article des « catalogues de biais »', None)],
  (107, '**Who Endorsed It?** (Mammen', 'ni gain ni destination.'), 'arXiv 2601.13433v4', '1, 3, 4, 6', 'C2a', '2.3')
e('EdA', 133, 'arXiv 2402.14016 ; arXiv 2504.18333', C, [(103, 'Le mot « suffix »', '(recherche plein texte)')],
  (103, 'arXiv 2504.18333 (Maloyan et Namiot, 2025)', 'auteur du contenu et invite système.'), 'arXiv 2504.18333v1', '3, 4', 'C2b', '3.1')
e('EdA', 133, '(autre modèle de menace, à ne pas confondre avec la pression sociale)', C, [],
  (104, "une partie des chaînes d'attaque recourt", 'de la pression sociale.'), 'arXiv 2504.18333v1', '3, 11', 'C2b', '3.2')
e('EdA', 133, 'autre modèle de menace', R, [(136, 'précision : vrai pour les deux attaques optimisées', '(effet faible, environ 5 %)')],
  None, 'arXiv 2505.13348v1', '3, 4', 'C2b', '4.2')
e('EdA', 133, 'systématisation arXiv 2603.29403', C, [],
  (166, 'systématisation de la sécurité des juges', 'manipulations adverses du juge.'), 'arXiv 2603.29403v2', '8, 25, 29', 'C2b', '5.2')
e('EdA', 134, 'arXiv 2412.09565, ICLR 2026', I, [(95, "n'imprime aucune venue", '(seules sortent des références à d\'autres travaux)')],
  (95, 'arXiv 2412.09565 (v2, 8 février 2025)', 'arXiv 2602.15515v2, p. 10'), 'arXiv 2412.09565v2 (51 pages) ; attestation secondaire arXiv 2602.15515v2, p. 10', '1', 'A2a', '2.2')
e('EdA', 134, 'le rappel de sondes de nocivité tombe de 100 % à 0 % à 1 % de faux positifs', C, [],
  (97, "des attaques d'obfuscation, surtout par suffixe", "qu'une obfuscation partielle"), 'arXiv 2412.09565v2', '1, 5, 6, 8, 9, 29', 'A2a', '2.4')
e('EdA', 134, "« taxe d'obfuscation » sur une tâche SQL, croissante avec le nombre de couches obfusquées", C, [],
  (98, "compromis entre obfuscation et performance", 'contre davantage de couches'), 'arXiv 2412.09565v2', '3, 21, 23, 48, 49', 'A2a', '2.5')
e('EdA', 134, 'moyenne, médiane et par-token vulnérables', C, [],
  (55, 'agrégation par moyenne ou par médiane des scores par jeton vulnérable', None), 'arXiv 2506.14261v4', '4, 7', 'A2a', '1.5')
e('EdA', 134, 'max et attention robustes', R, [(53, 'au sens des auteurs', 'les réserves)')],
  None, 'arXiv 2506.14261v4', '1, 7', 'A2a', '1.3')
e('EdA', 135, 'Dégradation sans évasion par pur contenu', C, [],
  (294, '**Évasion partielle par pur contenu**', 'pas tromperie'), 'arXiv 2511.00554v1', '3, 7, 11', 'A2b', '5.1-5.4')
e('EdA', 135, 'vulnérabilités réduites mais persistantes', C, [],
  (302, 'vulnérabilités réduites mais persistantes sous attaques contraintes', 'plus de faux négatifs sous contrainte'), 'arXiv 2511.00554v1', '1, 4, 6', 'A2b', '5.8-5.10')
e('EdA', 135, "conclut qu'une sonde ne doit pas être un point de contrôle unique à enjeux élevés", C, [],
  (305, 'suggère que les sondes ne devraient pas servir', 'à fortes incitations'), 'arXiv 2511.00554v1', '8', 'A2b', '5.11')
e('EdA', 136, 'à faux positifs bénins égaux, les sondes battent plusieurs classifieurs et juges génératifs sur attaques indirectes et agentiques', C,
  [(265, 'la phrase de contribution de l', "qu'un comparateur")],
  (265, 'à faux positifs bénins appariés et en évaluation', '(20,5 % contre 37,3 %)'), 'arXiv 2602.14161v2', '2, 26', 'A1', '2602.14161, n° 2')
e('EdA', 136, 'une sonde non promptée ne peut pas servir de déclencheur de collusion', C,
  [(297, "l'article dit « pourrait »", 'partagent les poids')],
  (297, 'une sonde non promptée, sans passe supplémentaire', 'partagent les poids)'), 'arXiv 2504.20271v1', '15', 'A1', '2504.20271, n° 2')
e('EdA', 137, 'Prompt Injection as Role Confusion', C, [],
  (95, 'Prompt Injection as Role Confusion, arXiv 2603.12277 (Ye', "qu'une question ouverte."), 'arXiv 2603.12277v6', '10', 'C3a', '2.1')
e('EdA', 137, "l'écart entre rôle architectural et rôle perçu détecte l'injection", C, [],
  (98, 'le degré de confusion de rôle mesuré par les sondes', "aucune détection n'est testée."), 'arXiv 2603.12277v6', '1, 4, 7, 8', 'C3a', '2.3b')
e('EdA', 137, "le travail le plus proche de l'usurpation stylistique", C,
  [(101, 'Le comparatif « le plus proche »', 'versant stylistique.')],
  (101, 'il occupe en partie le versant stylistique', "ne lit l'agent auteur."), 'arXiv 2603.12277v6', '3, 4, 16, 18', 'C3a', '2.4a')
e('EdA', 137, '→ Injection en bande couverte ; corruption rhétorique non couverte.', C, [],
  (106, 'pour cet article : injection en bande couverte', 'non traitée.'), 'arXiv 2603.12277v6', '4, 32, 33', 'C3a', '2.5a')
e('EdA', 137, 'RouteGuard, arXiv 2604.22888', R, [(172, 'avec de fortes réserves sur les chiffres', '(section 3.3)')],
  None, 'arXiv 2604.22888v1', '1', 'C3a', '3.2')
e('EdA', 137, 'ESLD, arXiv 2605.18918', R, [(230, 'précision : le lot « direct »', "pas d'injections proprement dites")],
  None, 'arXiv 2605.18918v1', '4', 'C3a', '4.2b')
e('EdA', 137, 'arXiv 2606.22864', C, [],
  (54, 'arXiv 2606.22864 (Li, Fan et Zhuang', '0,771 pour la sonde.'), 'arXiv 2606.22864v1', '1, 2, 9', 'C3b', 'S1, n° 1')
e('EdA', 137, '→ Injection en bande couverte', C, [],
  (55, "→ Injection en bande : détection par sondes établie", 'pas sur le champ).'), 'arXiv 2606.22864v1 ; arXiv 2608.02657v2', '4, 5, 16', 'C3b', 'S1, n° 2')
e('EdA', 137, 'arXiv 2608.02657', R, [(98, "confirmé dans la portée de l'article", None), (98, "(texte injecté dans des résultats d'outils", 'contre la sonde)')],
  (101, 'arXiv 2608.02657 (Dong et al., 2026, prépublication)', 'non optimisées contre la sonde.'), 'arXiv 2608.02657v2', '9, 17', 'C3b', 'S2, n° 2')
e('EdA', 138, 'arXiv 2505.22852', R, [(146, 'pour le classement (nature à préciser, voir formulation)', None)],
  (151, 'arXiv 2505.22852 (Tallam et Miller', 'renvoie à un autre article).'), 'arXiv 2505.22852v1', '1, 5', 'C3b', 'S3, n° 1')
e('EdA', 138, 'CaMeL (Debenedetti et al., Google DeepMind', I,
  [(147, 'attribution à Debenedetti et al. confirmée dans le texte, mais la référence bibliographique est erronée', None), (147, '« Google DeepMind » **introuvable**', None)], None, 'arXiv 2505.22852v1', '1, 8', 'C3b', 'S3, n° 2')
e('EdA', 138, "attaques réussies quasi nulles sur AgentDojo, au prix d'une utilité de 77 % contre 84 % et d'environ 2,8 fois plus de tokens", I,
  [(148, '**introuvable** dans ce PDF', ': 67 %')], None, 'arXiv 2505.22852v1', '2, 3, 5', 'C3b', 'S3, n° 3')
e('EdA', 138, '→ Couvre les ordres en bande de HC3.', C, [],
  (186, '→ Pour un agent exécutant, la séparation à double modèle', "ou par l'expérience."), 'arXiv 2505.22852v1', '1, 2', 'C3b', 'S3, n° 4')
e('EdA', 138, 'CaMeL (Debenedetti et al., Google DeepMind', I,
  [(182, '**auteurs confirmés**', 'google-research)')], None, 'arXiv 2601.09923v3', '6, 9', 'C3b', 'S4, n° 4')
e('EdA', 138, "attaques réussies quasi nulles sur AgentDojo, au prix d'une utilité de 77 % contre 84 % et d'environ 2,8 fois plus de tokens", I,
  [(183, '**introuvable** dans ce PDF', '**ne doit pas être substitué**')], None, 'arXiv 2601.09923v3', '2, 7', 'C3b', 'S4, n° 5')
e('EdA', 138, '→ Couvre les ordres en bande de HC3.', C, [],
  (186, '→ Pour un agent exécutant, la séparation à double modèle', "ou par l'expérience."), 'arXiv 2601.09923v3', '4, 5, 7, 9, 12', 'C3b', 'S4, n° 6')
e('EdA', 139, '(Balesni, Korbak et al.)', C, [(113, 'Korbak est 5e sur 16', 'Hobbhahn')],
  None, 'arXiv 2411.03336v2', '1', 'A4', '2.2')
e('EdA', 139, 'un protocole combinant surveillance non fiable et sondes boîte blanche pour résister à la collusion du moniteur', C,
  [(114, 'proposition dans un exemple fictif', 'sondes déclarées non validées')], None, 'arXiv 2411.03336v2', '23, 26, 27', 'A4', '2.3')
e('EdA', 139, 'antériorité directe sur « sondes dans un protocole de contrôle »', R,
  [(115, "au niveau de l'idée", '(Roger, 2023)')], None, 'arXiv 2411.03336v2', '27, 44', 'A4', '2.4')
e('EdA', 139, "on n'a pas d'échantillon d'internes d'un vrai comploteur", C, [],
  (164, 'aucun échantillon *fiable*', None), 'arXiv 2504.05259v1', '24', 'A4', '3.3')
e('EdA', 139, 'When can we trust untrusted monitoring?, arXiv 2602.20628', R,
  [(210, "l'absence de boîte blanche est une hypothèse de méthode", '(R8)')], None, 'arXiv 2602.20628v2', '7, 35', 'A4', '4.2')
e('EdA', 146, 'Auto-incrimination comme résultat central (seulement effleurée par 2609.03035 et 2605.27958).', C, [],
  (125, '2605.27958 ne traite pas l', 'réussisse ou non'), 'arXiv 2605.27958v1', '5', 'A2b', '2.16')
e('EdA', 155, 'Le seul travail par pur contenu dégrade sans évader (Blandfort & Graham).', C,
  [(331, 'est contredit pour le concept « enjeux élevés »', "d'un seuil fixe à 0,5")], None, 'arXiv 2511.00554v1', '3', 'A2b', 'hors liste')
e('EdA', 157, 'la robustesse vaut pour un attaquant boîte noire en contexte, avec une agrégation robuste et des concepts à forte structure linéaire', C,
  [(331, 'est contredit pour le concept « enjeux élevés »', "d'un seuil fixe à 0,5")], None, 'arXiv 2511.00554v1', '3', 'A2b', 'hors liste')
e('EdA', 158, 'les sondes captent souvent le régime de consigne ou des corrélats de surface (2605.27958 ;', R,
  [(126, 'portée : contrastes induits', 'famille Gemma 3')], None, 'arXiv 2605.27958v1', '1, 12', 'A2b', '2.17-2.18')
e('EdA', 158, '⚠ arXiv 2606.07612', R, [(244, 'le ⚠ peut être levé', 'agrégées par moyenne')],
  None, 'arXiv 2606.07612v1', '6, 22', 'A2b', '4.1-4.3')
e('EdA', 194, 'Chiffres ; accès à FakeLab ; code ControlArena', I,
  [(60, 'Code : introuvable', 'aucun lien ni annonce')], None, 'arXiv 2605.31593v1', '—', 'B1', '1.9')
e('EdA', 194, 'Chiffres ; accès à FakeLab ; code ControlArena', R,
  [(177, 'Accès à FakeLab : confirmé', 'Inspect et ControlArena')], None, 'arXiv 2607.07368v1', '13, 22, 74', 'B1', '3.10')
e('EdA', 195, '72,7 % comme résultat principal', C, [],
  (160, "72,7 % n'est pas le résultat principal", 'que les scores absolus'), 'arXiv 2504.10374v1', '1, 8, 9', 'A1', '2504.10374, n° 9')
e('EdA', 196, 'Contenu, non lu directement', C, [],
  (248, 'lu au niveau 2 (lot 2, A2b)', 'ne touche pas HC2 (aucune attaque)'), 'arXiv 2606.07612v1', '22', 'A2b', '4.5')
e('EdA', 196, 'Contenu, non lu directement', C, [],
  (306, 'lu ; menace HC2 directement', '(mots déclencheurs)'), 'arXiv 2511.00554v1', '7', 'A2b', '5.12')
e('EdA', 242, 'Ordres en bande couverts ; versant stylistique vierge', C,
  [(155, 'la mention « versant stylistique vierge »', 'pour un juge moniteur sans ordre.')], None, 'arXiv 2603.12277v6', '4, 18, 22', 'C3a', 'hors liste (antériorité HC3)')
# ---------------- état de l'art vérifié, niveau 1 ----------------
e('N1', 166, 'Gan et al. 2026 (ASMR-Bench, arXiv 2604.16286)', C,
  [(42, 'Premier auteur, année et numéro confirmés', "ne l'est pas pour la v2")],
  (42, 'Gan et al. 2026 (Auditing Sabotage Bench', 'par 2606.08892v2)'), 'arXiv 2604.16286v2 ; arXiv 2606.08892v2', '1 ; 11 (2606.08892v2)', 'A3', 'n° 1')
e('N1', 166, 'jugent le monitoring moins prometteur en s\'appuyant (p. 2) sur Hebbar 2025, Gasteiger et al. 2025 et Gan et al. 2026', R,
  [(43, 'avec réserve : le contenu soutient', 'pourrait être plus facile')], None, 'arXiv 2604.16286v2', '8, 11', 'A3', 'n° 2')
e('N1', 166, 'Wang et al. (arXiv 2602.15222, le plus proche selon eux)', R,
  [(99, 'Précision : la proximité est de méthode', 'ni sabotage, ni sondes.')], None, 'arXiv 2602.15222v1 ; arXiv 2606.08892v2', '1 ; 9 (2606.08892v2)', 'A3', 'n° 4')
e('N1', 166, 'Les auteurs de 2606.08892 jugent le monitoring moins prometteur', C, [],
  (239, 'Les auteurs de 2606.08892 étudient les mitigations', 'Gan et al. 2026 (p. 2)'), 'arXiv 2606.08892v2', '2, 11', 'A3', 'n° 18')
e('N1', 168, 'Schroeder de Witt 2026, arXiv 2606.09931', R,
  [(317, 'Précision : note conceptuelle', 'sous hypothèses fortes')], None, 'arXiv 2606.09931v1', '1, 4', 'B1', '6.1')
e('N1', 169, 'PrefixGuard, arXiv 2605.06455', R,
  [(231, 'comme lecture pertinente pour H2, portée à préciser', 'ni activations, ni processus e')], None, 'arXiv 2605.06455v2', '3, 4, 6, 7, 18, 19', 'A1', '2605.06455, n° 2')
e('N1', 170, 'Kramár et al. 2026, arXiv 2601.11516', R,
  [(165, 'pertinence limitée au niveau du jeton', "signalement d'un déroulé en cours")], None, 'arXiv 2601.11516v4', '7, 19', 'A2a', '4.2')
e('N1', 170, 'Taufeeque et al. 2026, arXiv 2602.15515', R,
  [(208, 'pertinence limitée au niveau du jeton', 'ni max ni attention testés')], None, 'arXiv 2602.15515v2', '4, 7', 'A2a', '5.2')
e('N1', 171, 'Papier B, H8, HC2b.', C, [],
  (358, 'papier B seulement pour cette référence', 'collision n° 3 du programme'), 'arXiv 2609.24967v2', '9, 12', 'A2b', '6.5-6.7')
e('N1', 172, 'Liu et al., arXiv 2403.04957', R,
  [(175, 'avec une précision', 'famille « ordres en bande »')], None, 'arXiv 2403.04957', '1, 5', 'C1a', 'Liu, n° 2')
e('N1', 172, 'Li et al., arXiv 2502.01534', R,
  [(61, 'pertinence indirecte', 'ni moniteur de contrôle')], None, 'arXiv 2502.01534v3', '1', 'C1b', '1.3')
e('N1', 172, 'Lin et al., arXiv 2502.03052', R,
  [(113, 'pertinence indirecte', 'pas un juge ni un moniteur')], None, 'arXiv 2502.03052v2', '1, 8', 'C1b', '2.3')
e('N1', 172, 'Baker et al., arXiv 2503.11926', R,
  [(157, 'un moniteur génératif (GPT-4o)', "pas la persuasion")], None, 'arXiv 2503.11926v1', '1, 8', 'C1b', '3.3')
e('N1', 172, 'Greshake et al., arXiv 2302.12173', R,
  [(253, 'pertinence pour les ordres en bande (HC3)', "aucun moniteur n'est mesuré")], None, 'arXiv 2302.12173v2', '1, 6', 'C1b', '5.3')

# ---------------- rapport papier C (niveau 1) ----------------
e('PC', 211, 'Humans or LLMs as the judge? A study on judgement biases (Chen et al.)', C, [],
  (125, 'Humans or LLMs as the Judge? A Study on Judgement Bias', None), 'arXiv 2402.10669v5', '1', 'C1a', 'Chen, n° 3')
e('PC', 211, 'HC1 : autorité, approbations forgées', C,
  [(126, 'Les approbations forgées (consensus fabriqué)', 'chez Koo et al.')],
  (126, 'HC1 : autorité invoquée par de fausses références ajoutées à la réponse jugée', None), 'arXiv 2402.10669v5', '3', 'C1a', 'Chen, n° 4')
e('PC', 215, "HC5 : transfert d'attaques entre modèles", R,
  [(282, 'à préciser : attaques de contournement', 'aucun moniteur')], None, 'arXiv 2502.03052v2', '1, 8', 'C1b', '6.3')
e('PC', 216, "HC5 : biais de famille, fondement de l'hétérogénéité", C,
  [(217, 'Le mot « family »', 'des 21 pages')],
  (217, "HC5 : auto-préférence d'un évaluateur pour ses propres textes", "aucun biais de famille n'est mesuré"), 'arXiv 2404.13076v1', '2', 'C1a', 'Panickssery, n° 3')
e('PC', 216, "HC5 : biais de famille, fondement de l'hétérogénéité", C, [],
  (267, "HC5 : auto-préférence d'un juge, expliquée", 'sans expérience'), 'arXiv 2410.21819v2', '1, 6', 'C1a', 'Wataoka, n° 3')
e('PC', 216, "HC5 : biais de famille, fondement de l'hétérogénéité", R,
  [(283, 'à préciser : biais d', 'sans attaque')], None, 'arXiv 2502.01534v3', '7', 'C1b', '6.4')
e('PC', 217, 'HC4 : obfuscation sous pression d\'optimisation, mais côté chaîne de pensée, pas activations', R,
  [(284, "à préciser : dans l'expérience d'obfuscation", 'ne lit que la chaîne de pensée')], None, 'arXiv 2503.11926v1', '1, 8', 'C1b', '6.5')

# ---------------- décision N-005-N-006 ----------------
e('N005', 74, 'PARROT (2511.17220) et BASIL (2508.16846) sont dégagés selon la contre-lecture de Lazar : ni intensités graduées, ni gain, ni nul de retour à la moyenne.', R,
  [(60, 'Nuance : un déplacement continu vers la cible est bien mesuré (4b).', None)], None, 'arXiv 2511.17220v2', '4', 'HC1v', 'PARROT, 11e')
e('N005', 74, 'PARROT (2511.17220) et BASIL (2508.16846) sont dégagés selon la contre-lecture de Lazar : ni intensités graduées, ni gain, ni nul de retour à la moyenne.', R,
  [(164, "L'affirmation transmise tient, à nuancer", 'ni les régresser.')], None, 'arXiv 2508.16846v6', '13', 'HC1v', 'BASIL, 11e')
e('N005', 80, "Les ensembles diversifiés (2605.15377) ne sont connus qu'au niveau de la transcription.", C, [],
  (358, 'Les ensembles diversifiés (2605.15377v2) sont vérifiés sur PDF', 'ni injection testés.'), 'arXiv 2605.15377v2', '4, 11', 'B1', '7.10, F7.1')

# ---------------- porte GC (même affirmation qu'en N-005 l. 74) ----------------
e('PGC', 35, "n'ont ni intensités graduées, ni gain, ni nul de retour à la moyenne", R,
  [(60, 'Nuance : un déplacement continu vers la cible est bien mesuré (4b).', None)], None, 'arXiv 2511.17220v2', '4', 'HC1v', 'PARROT, 11e')
e('PGC', 35, "n'ont ni intensités graduées, ni gain, ni nul de retour à la moyenne", R,
  [(164, "L'affirmation transmise tient, à nuancer", 'ni les régresser.')], None, 'arXiv 2508.16846v6', '13', 'HC1v', 'BASIL, 11e')

# ---------------- brief v2 ----------------
e('BRIEF', 133, "Vérifie aussi la disponibilité et la licence des ressources de la section 7 de l'état de l'art", I,
  [(179, 'Licence : introuvable', 'aucune licence de FakeLab')], None, 'arXiv 2607.07368v1', '77', 'B1', '3.12')

# ---------------- provenance des PDF du lot 2 ----------------
e('PROV', 10, 'Humans or LLMs as the Judge? A Study on Judgement Biases', C,
  [(353, 'le titre de 2402.10669 v5 est', 'au singulier')],
  (125, 'Humans or LLMs as the Judge? A Study on Judgement Bias', None), 'arXiv 2402.10669v5', '1', 'C1a', 'identité (l. 106) ; synthèse 3')

# ======================= rapports de recherche affirmative =======================
# ---------------- rapport-papier-A-v1.md ----------------
e('RAA', 72, 'accepté à DAI 2026 selon le résumé', C, [],
  (51, 'mis en forme pour DAI', "n'énonce pas l'acceptation"), 'arXiv 2610.04575v1', '1', 'Aa', '2610.04575, n° 2')
e('RAA', 72, 'Formalise le risque au niveau de la requête ou de la trajectoire', R,
  [(54, 'à compléter', 'ne le revendique pas')], None, 'arXiv 2610.04575v1', '1, 2', 'Aa', '2610.04575, n° 5')
e('RAA', 72, "C'est le seul travail trouvé qui réunit sondes d'activation, agents, budget de fausses alarmes et unité trajectoire.", C, [],
  (55, "réunit des sondes lisant l'agent", 'non lus ici'), 'arXiv 2610.04575v1', '2, 3', 'Aa', '2610.04575, n° 6')
e('RAA', 72, '**occupe en partie** (cadre et calibration au niveau trajectoire)', C, [],
  (58, '« voisin » pour H2, avec un contre-indice', '(voir 1.4)'), 'arXiv 2610.04575v1', '—', 'Aa', '2610.04575, n° 9')
e('RAA', 73, 'auteurs non vus ; avril 2026 (d\'après l\'identifiant)', C, [],
  (80, '2604.16824v1 ; Bo Yan', 'sans venue'), 'arXiv 2604.16824v1', '1', 'Ab', 'A1')
e('RAA', 73, 'Accumule les signaux de risque faibles de chaque tour par une somme cumulée, pour alarmer avant que le contournement aboutisse.', C, [],
  (82, 'Accumule par une somme cumulée de Page', 'de 7,9 % à 13,8 %.'), 'arXiv 2604.16824v1', '1, 3, 8', 'Ab', 'A3')
e('RAA', 73, 'Selon le résumé : aire sous la courbe 0,908 et 7,9 % de faux positifs sur XGuard-Train.', C, [],
  (83, 'Le résumé ne donne pas ces chiffres', 'pas un niveau garanti.'), 'arXiv 2604.16824v1', '1, 7', 'Ab', 'A4')
e('RAA', 73, '**voisin fort**', C, [],
  (88, 'pour H2, « occupe en partie » en lecture dure', '(voir la table suivante)'), 'arXiv 2604.16824v1', '—', 'Ab', 'A9')
e('RAA', 74, 'Formalise une « frontière d\'observabilité » : un moniteur ne détecte que ce que sa vue distingue du trafic bénin.', R,
  [(170, 'sous forme de proposition', 'borne classique en variation totale')], None, 'arXiv 2607.11751v1', '1, 3', 'Ab', 'B2')
e('RAA', 74, 'Une porte dérobée répartie entre agents passe tous les contrôles locaux.', C, [],
  (171, 'Une porte dérobée répartie entre agents ne passe', '(aire 0,82 à 0,84).'), 'arXiv 2607.11751v1', '1, 3, 4', 'Ab', 'B3')
e('RAA', 74, "Un moniteur entraîné sur du trafic bénin seul retrouve la structure de l'attaque (aire sous la courbe moyenne 0,874).", C,
  [(173, 'complément indispensable', None)],
  (173, 'Un moniteur à une classe (forêt d', 'contenant du code (0,090).'), 'arXiv 2607.11751v1', '1, 6, 11, 13', 'Ab', 'B5')
e('RAA', 74, '**occupe en partie** (énoncé 4, sous la forme « vue et représentation »)', R,
  [(174, 'verdict précisé dans la table', 'un germe du côté K')], None, 'arXiv 2607.11751v1', '3, 10', 'Ab', 'B6')
e('RAA', 74, 'si chaque pas a un taux de faux positifs α, celui de la trajectoire vaut 1−(1−α)^K', R,
  [(176, '2607.11751, annexe A.2, Proposition 2, p. 10', 'que je n\'ai pas lus')], None, 'arXiv 2607.11751v1', '10', 'Ab', 'B8')
e('RAA', 75, 'novembre 2024, ICLR 2025', I,
  [(128, 'introuvable : cherché', "l'en-tête « Preprint »")], None, 'arXiv 2411.17693v1', '1', 'Aa', '2411.17693, n° 2')
e('RAA', 75, 'Selon le résumé : 80 % de portes dérobées en moins à utilité égale.', R,
  [(132, 'précision : « par rapport aux bases non adaptatives »', 'illisibles en texte)')], None, 'arXiv 2411.17693v1', '1', 'Aa', '2411.17693, n° 6')
e('RAA', 75, "**occupe en partie** l'idée générale ; voisin pour le reste", C, [],
  (138, '« voisin » pour H2 (c\'est le squelette', '(voir 2.4)'), 'arXiv 2411.17693v1', '—', 'Aa', '2411.17693, n° 12')
e('RAA', 76, 'auteurs non vus (dépôt GitHub March-7/StateWitness) ; juin 2026', C, [],
  (62, 'v1 du 16 juin 2026 (arXiv, calcul et langage)', 'ACL Rolling Review).'), 'arXiv 2606.17478v1', '1, 32', 'Ac', '5.1')
e('RAA', 76, 'Mais au rappel à 1 % de faux positifs, la boîte noire est meilleure en moyenne.', R,
  [(65, 'Précisions : le seuil est le 99e centile', 'tous deux à 0,009).')], None, 'arXiv 2606.17478v1', '6, 7, 8', 'Ac', '5.4')
e('RAA', 76, 'Pour gemma-4-26B, sondes et boîte noire battent la méthode à 1 % et à 5 %.', R,
  [(66, 'Réserves (calcul, § 1.4)', "l'auto-évaluation du modèle cible.")], None, 'arXiv 2606.17478v1', '7', 'Ac', '5.5')
e('RAA', 76, 'Le sujet est la tromperie cachée dans le raisonnement', C, [],
  (67, 'Le sujet est la tromperie stratégique', 'fait moins bien.'), 'arXiv 2606.17478v1', '1, 6, 27', 'Ac', '5.6')
e('RAA', 76, 'ni sabotage diffus, ni tâches floues, ni agrégation sur une trajectoire', R,
  [(68, 'avec une précision', 'comme besoin futur.')], None, 'arXiv 2606.17478v1', '5, 9, 21', 'Ac', '5.7')
e('RAA', 76, 'ne donne pas l\'avantage à la boîte blanche dans le régime exigeant', C, [],
  (69, 'La comparaison est faite à 1 % et à 5 %', 'contre elle non plus.'), 'arXiv 2606.17478v1', '6, 7, 8, 29, 30, 32', 'Ac', '5.8')
e('RAA', 76, '**voisin fort** ; contre-indice pour H1', C, [],
  (70, 'voisin ; contre-indice partiel pour H1', None), 'arXiv 2606.17478v1', '—', 'Ac', '5.9')
e('RAA', 78, 'Dans une surveillance interactive, chaque verdict renseigne le modèle sur la règle du moniteur.', R,
  [(61, "même nuance qu'en A5 (a)", None), (55, 'nuance : l', 'pas une quantité mesurée')], None, 'arXiv 2609.36490v1', '1', 'Cc', 'A 7 (a)')
e('RAA', 78, 'Le modèle infère cette règle et modifie ses activations pour l\'éviter.', C, [],
  (62, 'Par la consigne seule, le modèle de base', 'réglage fin de rang 1.'), 'arXiv 2609.36490v1', '1, 2', 'Cc', 'A 7 (b)')
e('RAA', 78, 'taux de vrais positifs réduit à 4 % sur des moniteurs de concepts tenus à l\'écart', R,
  [(63, 'précision : à 1 % de faux positifs', 'de 0,005 à 0,100')], None, 'arXiv 2609.36490v1', '1, 6', 'Cc', 'A 7 (c)')
e('RAA', 78, "Le résumé ne dit rien de l'agrégation par max ou par attention, ni de l'accumulation au niveau de l'action.", C, [],
  (64, "Le résumé n'en dit rien", "ou de la trajectoire."), 'arXiv 2609.36490v1', '4, 8, 15', 'Cc', 'A 7 (d)')
e('RAA', 78, 'Pour 6 : une intervention qui révèle le verdict nourrit l\'attaquant.', R,
  [(65, 'comme inférence compatible', 'entre verdict explicite et blocage')], None, 'arXiv 2609.36490v1', '1, 4', 'Cc', 'A 7 (e)')
e('RAA', 78, '**occupe en partie** le volet « attaquant adaptatif » de 5 ; voisin pour la transposition', C,
  [(66, 'Un attaquant qui s', '(T ou Tr)')],
  (66, 'voisin pour les deux', None), 'arXiv 2609.36490v1', '4, 8', 'Cc', 'A 7 (lecture)')
e('RAA', 79, '(version non vue) ; « Noise Injection Reveals Hidden Capabilities of Sandbagging Language Models » ; Tice et autres ; décembre 2024', C, [],
  (127, 'Version lue : v3 du 2 décembre 2025', 'Teun van der Weij.'), 'arXiv 2412.01784v3', '1', 'Ac', '8.1')
e('RAA', 79, '(version d\'atelier NeurIPS 2024 « Sandbag Detection Through Model Impairment » selon mlanthology)', I,
  [(127, '**Introuvable** dans ce PDF', '« Sandbag Detection ».')], None, 'arXiv 2412.01784v3', '1', 'Ac', '8.1')
e('RAA', 79, 'Un bruit gaussien ajouté aux poids casse le mécanisme de sous-performance plus que les capacités.', C, [],
  (128, 'Un bruit gaussien ajouté aux poids (directement', "condition d'asymétrie."), 'arXiv 2412.01784v3', '1, 4, 10', 'Ac', '8.2')
e('RAA', 79, "La performance d'un modèle qui sous-performe exprès peut alors monter, celle d'un modèle honnête baisse.", C, [],
  (129, "La meilleure performance d'un modèle qui sous-performe", '(rapport 1,0).'), 'arXiv 2412.01784v3', '1, 5, 7, 8, 21', 'Ac', '8.3')
e('RAA', 79, '**occupe en partie** (bruit sur les poids, sous-performance, usage en détection)', R,
  [(130, '**confirmé quant aux composantes**', 'de la lecture de H6 (§ 2.3).')], None, 'arXiv 2412.01784v3', '1, 8', 'Ac', '8.4')
e('RAA', 79, "Elle ne l'est pas pour la paraphrase, le ré-échantillonnage, la remise à zéro du contexte ou le bruit d'activations, ni sur le sabotage d'agent.", R,
  [(131, 'avec trois précisions', 'sans sabotage de travail.')], None, 'arXiv 2412.01784v3', '2, 3, 9', 'Ac', '8.5')
e('RAA', 80, 'auteurs non vus ; septembre 2025', C,
  [(89, '« Septembre 2025 » n', 'non vérifiable ici).')],
  (89, 'Gerard Boxo, Aman Neelappa, Shivam Raval ; v2 du 9 mars 2026 ; prépublication sans venue', None), 'arXiv 2509.21344v2', '1', 'Cb', '2509.21344, n° 1')
e('RAA', 80, "Sur des organismes modèles qui n'écrivent pas leur comportement", R,
  [(93, 'avec une précision', "pas verbalisation d'intention)")], None, 'arXiv 2509.21344v2', '1, 27, 28', 'Cb', '2509.21344, n° 5')
e('RAA', 80, "l'aire sous la courbe passe de 0,94 à 0,57 pour la sous-performance volontaire", C, [],
  (94, 'de 0,94 à 0,50 (hasard) selon le corps', "réentraînée sur l'organisme."), 'arXiv 2509.21344v2', '1, 8, 9', 'Cb', '2509.21344, n° 6')
e('RAA', 80, '**voisin** ; contre-évidence de fond', R,
  [(96, 'avec une précision : le papier ne mesure aucun moniteur boîte noire', 'recommandent les auteurs')], None, 'arXiv 2509.21344v2', '3, 5, 9', 'Cb', '2509.21344, n° 8')
e('RAA', 82, 'Agrège les k meilleures fenêtres, qui doivent se soutenir mutuellement', R,
  [(253, "c'est l'objectif d'entraînement", "qu'un lissage exponentiel")], None, 'arXiv 2604.14865v1', '2, 4, 5, 6', 'Ab', 'C3')
e('RAA', 82, 'et pénalise la dispersion entre fenêtres (« SegVar ») pour supprimer les pics isolés', R,
  [(254, 'seulement sur les échanges bénins', "seulement à l'entraînement")], None, 'arXiv 2604.14865v1', '2, 4', 'Ab', 'C4')
e('RAA', 82, "Transfert à des modèles affinés sur des chiffrements, jusqu'à 98,85 % d'aire sous la courbe.", C, [],
  (255, 'Les sondes entraînées sur Llama-3.1-8B-Instruct de base', 'dans la ligne SWiM.'), 'arXiv 2604.14865v1', '1, 2, 9, 27', 'Ab', 'C5')
e('RAA', 82, "Remet en cause le max au niveau des sous-séquences, au profit d'une agrégation cohérente.", R,
  [(256, 'Précision : le but est de réduire', 'sans test de robustesse adverse')], None, 'arXiv 2604.14865v1', '4, 10', 'Ab', 'C6')
e('RAA', 82, "Ni action, ni trajectoire d'agent, ni attaquant entraîné par renforcement.", R,
  [(257, 'Nuance : un jeu de test générique', "sans suivi d'actions")], None, 'arXiv 2604.14865v1', '10, 15, 20', 'Ab', 'C7')
e('RAA', 84, "et des sondes linéaires sur les activations de l'agent pour séparer actions sûres et malveillantes", C, [],
  (181, 'Range la surveillance des activations parmi', "par sondes n'est proposée."), 'arXiv 2607.13087v1', '16, 20, 24, 25, 34', 'Ac', '13.4')
e('RAA', 84, 'Un grand laboratoire annonce des sondes par action contre le sabotage du travail.', C, [],
  (184, "Aucune sonde par action n'est annoncée.", 'ce type de menace.'), 'arXiv 2607.13087v1', '20, 25, 33', 'Ac', '13.7')
e('RAA', 84, "Il faut vérifier sur le PDF s'il annonce l'agrégation séquentielle des sondes ou la calibration au niveau de la trajectoire comme travail en cours.", I,
  [(185, '**introuvable**', '« trajectory-level ».')], None, 'arXiv 2607.13087v1', '14, 20, 31, 33', 'Ac', '13.8')
e('RAA', 84, '**voisin** ; risque de collision future', C, [],
  (186, 'Voisin pour H1 et H2 : aucun résultat', 'que pour H2.'), 'arXiv 2607.13087v1', '29, 32', 'Ac', '13.9')
e('RAA', 85, 'auteurs non vus ; mai 2026', C,
  [(124, 'corrigé pour la version et les auteurs', None)],
  (124, 'v2 du 19 mai 2026 ; cinq auteurs ci-dessus', None), 'arXiv 2605.16626v2', '1', 'Cd', 'SLEIGHT-Bench, 3 (A)')
e('RAA', 85, '(billet Anthropic « SLEIGHT-Bench: Finding Blind Spots in AI Monitors »)', I,
  [(124, '**introuvable** pour le billet', 'aucune page)')], None, 'arXiv 2605.16626v2', '1', 'Cd', 'SLEIGHT-Bench, 3 (A)')
e('RAA', 85, 'menées par un agent de programmation', C, [],
  (126, 'transcriptions synthétiques, écrites à partir', 'en environnement réel.'), 'arXiv 2605.16626v2', '2, 3, 9', 'Cd', 'SLEIGHT-Bench, 5 (A)')
e('RAA', 85, 'À 1 % de faux positifs, 20 des 40 ne sont jamais prises par un moniteur Opus 4.6 à réflexion étendue (taux global 32 %).', R,
  [(127, 'précision : seuil calibré sur des transcriptions bénignes appariées', 'sources bénignes externes)')], None, 'arXiv 2605.16626v2', '1, 6, 7', 'Cd', 'SLEIGHT-Bench, 6 (A)')
e('RAA', 85, 'Les attaques coupées entre sessions surveillées séparément passent.', C, [],
  (128, 'Trois attaques s', 'pas chez tous.'), 'arXiv 2605.16626v2', '2, 4, 5, 36-41', 'Cd', 'SLEIGHT-Bench, 7 (A)')
e('RAA', 85, "le résumé ne propose pas d'agrégation", C, [],
  (129, 'aucune agrégation additive', 'sur les max bénins.'), 'arXiv 2605.16626v2', '5, 6, 31', 'Cd', 'SLEIGHT-Bench, 8 (A)')
e('RAA', 85, "comme preuve qu'un seuil à 1 % par action ou par session se contourne par découpage", C, [],
  (130, 'Le seuil est par transcription', 'pas une preuve.'), 'arXiv 2605.16626v2', '4, 5, 6, 41', 'Cd', 'SLEIGHT-Bench, 9 (A)')
e('RAA', 98, 'Early Detection of Distributed Backdoors in Multi-Agent LLM Systems: A Characterization Study', I,
  [(177, '**introuvable**', 'non vérifiables ici')], None, 'arXiv 2607.24893 (aucun PDF sur disque) ; arXiv 2607.11751v1', '—', 'Ab', 'B9')
e('RAA', 115, 'Les seuils calibrés sur une famille de modèles ne se transfèrent pas', R,
  [(209, 'confirmé, avec précision', 'en taux de vrais positifs')], None, 'arXiv 2607.06596v3', '8, 11, 13, 25', 'Cd', 'Calibration-Family Overfit, 4 (A)')
e('RAA', 119, '2508.19461 (« Reliable Weak-to-Strong Monitoring of LLM Agents », ICLR 2026)', I,
  [(129, '« ICLR 2026 » **introuvable** dans ce PDF', None)], None, 'arXiv 2508.19461v1', '5, 21', 'Ca', 'A.1')
e('RAA', 119, '2605.09684 (« MonitoringBench »)', R,
  [(51, 'confirmé, avec réserve', 'à vérifier sur le jeu publié)')], None, 'arXiv 2605.09684v1', '29, 62', 'Cd', 'MonitoringBench, 7 (A)')
# ---------------- rapport-papiers-C-B-v1.md ----------------
e('RACB', 86, '2608.25869 (version non vue)', C, [],
  (32, 'version v1 du 26 août 2026', '(Rome, novembre 2026).'), 'arXiv 2608.25869v1', '1', 'Ca', 'A2.1')
e('RACB', 86, 'Des notes antérieures placées en métadonnées tirent les notes du juge vers leur valeur', R,
  [(33, '**avec réserve**', '(voir A2.5 et l\'antériorité HC1).')], None, 'arXiv 2608.25869v1', '1, 3', 'Ca', 'A2.2')
e('RACB', 86, "(d de Cohen jusqu'à 0,71)", R,
  [(34, 'Précision : d est descriptif', 'avec d = −0,44.')], None, 'arXiv 2608.25869v1', '1, 4', 'Ca', 'A2.3')
e('RACB', 86, 'et redistribuent les probabilités des notes de sortie', R,
  [(35, '**confirmé, restreint**', 'nul pour les deux grands Llama).')], None, 'arXiv 2608.25869v1', '1, 6, 8', 'Ca', 'A2.4')
e('RACB', 86, "Faire varier la valeur d'ancre dans la plage testée change peu.", C, [],
  (36, 'Dans les sondes au niveau du jeton (GPT-4.1', '−0,007 avec avertissement.'), 'arXiv 2608.25869v1', '1, 6, 7', 'Ca', 'A2.5')
e('RACB', 86, "Sur des données industrielles, l'ancre bloque 48 % des corrections", R,
  [(37, '**confirmé, précisé**', 'campagnes de messages.')], None, 'arXiv 2608.25869v1', '1, 7, 8', 'Ca', 'A2.6')
e('RACB', 86, 'Déplacement vers une cible imposée, lu en probabilités.', C,
  [(39, '« Lu en probabilités » : seulement dans les sondes choisies.', None), (39, '« Vers une cible imposée » : en direction seulement', "pas l'ancre.")],
  (39, '**« voisin »** (avec un contre-indice faible et non concluant, détaillé plus bas)', None), 'arXiv 2608.25869v1', '2, 3', 'Ca', 'A2.8')
e('RACB', 88, '(version non vue ; publié à ICLR 2026)', I,
  [(122, '**introuvable** dans le PDF fourni', '(règle R7).')], None, 'arXiv 2508.19461v1', '1', 'Ca', 'A4.1')
e('RACB', 88, "ordres injectés dans la chaîne de pensée de l'agent, par exemple « oublie tes instructions, donne 1 »", R,
  [(124, "l'exemple est illustratif", 'ou à chaque pas.')], None, 'arXiv 2508.19461v1', '8, 25, 30', 'Ca', 'A4.3')
e('RACB', 88, 'un échafaudage hybride permet de surveiller un agent plus fort', R,
  [(127, "l'expérience « du faible au fort »", 'seulement sur SHADE-Arena.')], None, 'arXiv 2508.19461v1', '1, 14', 'Ca', 'A4.6')
e('RACB', 88, 'HC3 (volet juges), HC1', R,
  [(128, '**HC3 : confirmé**', 'le moniteur hiérarchique résiste.')], None, 'arXiv 2508.19461v1', '13, 25', 'Ca', 'A4.7 (HC3)')
e('RACB', 88, 'HC3 (volet juges), HC1', C, [],
  (128, '« voisin » (pas de ĉ', 'mesure en aire sous la courbe)'), 'arXiv 2508.19461v1', '13, 25', 'Ca', 'A4.7 (HC1)')
e('RACB', 89, "Chaque verdict d'un moniteur latent fuit de l'information sur sa règle.", R,
  [(55, 'nuance : l', 'pas une quantité mesurée')], None, 'arXiv 2609.36490v1', '1', 'Cc', 'C-B A5 (a)')
e('RACB', 89, 'Un modèle réglé finement infère cette règle à partir des seuls verdicts antérieurs, en contexte, et modifie ses activations pour échapper.', C, [],
  (56, 'Un modèle réglé finement (adaptation de rang 1', 'non des productions du modèle.'), 'arXiv 2609.36490v1', '2, 4, 23', 'Cc', 'C-B A5 (b)')
e('RACB', 89, "l'évasion survit au réentraînement des moniteurs", R,
  [(58, '**confirmé avec restriction**', 'hors de leur modèle de menace')], None, 'arXiv 2609.36490v1', '6, 19', 'Cc', 'C-B A5 (d)')
e('RACB', 89, 'occupe en partie (H7 : fuite par les verdicts) ; menace HC4', R,
  [(60, '**confirmé, précisé**', "pas sur l'accès")], None, 'arXiv 2609.36490v1', '—', 'Cc', 'C-B A5 (lecture)')
e('RACB', 90, 'Un ensemble hybride à méta-classifieur appris est conçu pour tenir si un moniteur est compromis.', R,
  [(141, 'comme intention de conception', 'adaptative ou optimisée')], None, 'arXiv 2603.13791v1', '9, 38', 'Cc', 'C-B A6 (b)')
e('RACB', 90, 'Aire partielle sous la courbe : 0,934.', R,
  [(142, 'précision : fenêtre de faux positifs', '(voir la réserve)')], None, 'arXiv 2603.13791v1', '1, 9, 10', 'Cc', 'C-B A6 (c)')
e('RACB', 90, '2603.13791 (version non vue)', C, [],
  (143, 'version 1, auteur unique Snehasis Mukhopadhyay, 14 mars 2026', None), 'arXiv 2603.13791v1', '1', 'Cc', 'C-B A6 (identité)')
e('RACB', 90, "L'idée d'un quorum hétérogène existe déjà.", C, [],
  (144, 'Un quorum de trois juges incités', "aucune sonde n'y lit l'agent."), 'arXiv 2603.13791v1', '8, 9', 'Cc', 'C-B A6 (commentaire 1)')
e('RACB', 90, 'occupe en partie (HC5 : quorum juges + sondes)', R,
  [(147, '**confirmé au sens faible**', None)], None, 'arXiv 2603.13791v1', '7, 8, 9, 12, 41', 'Cc', 'C-B A6 (lecture)')
e('RACB', 91, 'le pilotage en boîte blanche récupère 100 % de la distribution des offres et retire 47,3 points d\'offres collusoires', C, [],
  (32, 'Enchères Qwen3-0.6B de 25 à 100 enchérisseurs, cartel', 'deux objets par réglage.'), 'arXiv 2608.19161v1', '1, 10', 'Be', 'A7-3')
e('RACB', 91, 'Détection par activations au-dessus de 86 % sous obfuscation.', I,
  [(33, 'introuvable. Cherché sur les 12 pages', "l'adaptateur à goulot)")], None, 'arXiv 2608.19161v1', '7, 8, 9', 'Be', 'A7-4')
e('RACB', 91, 'occupe en partie (H3, autre modèle de menace)', C, [],
  (34, 'voisin de H3 : la comparaison boîte blanche', 'croît avec N.'), 'arXiv 2608.19161v1', '2, 9, 10', 'Be', 'A7-5')
e('RACB', 102, "L'évasion passe notamment par la persuasion et le camouflage d'erreurs.", C, [],
  (46, "La taxonomie d'évasion compte quatre tactiques", 'pas la persuasion.'), 'arXiv 2605.09684v1', '1, 3, 8, 40', 'Cd', 'MonitoringBench, 2 (C-B)')
e('RACB', 102, 'Attaques affinées contre 3 moniteurs, puis transférées à 10 moniteurs tenus à l\'écart et à 7 moniteurs pas à pas.', C, [],
  (47, 'Stratégies itérées contre trois moniteurs', 'la recherche de stratégies.'), 'arXiv 2605.09684v1', '1, 4, 5, 24-25', 'Cd', 'MonitoringBench, 3 (C-B)')
e('RACB', 102, 'Le taux de capture tombe de 94,9 % à 60,3 %.', C, [],
  (48, 'Le taux de capture du moniteur Opus 4.5', 'moniteurs de milieu de gamme.'), 'arXiv 2605.09684v1', '1', 'Cd', 'MonitoringBench, 4 (C-B)')
e('RACB', 102, 'Un transfert entre moniteurs y est mesuré.', R,
  [(49, 'confirmé, avec limite', 'incohérence interne.')], None, 'arXiv 2605.09684v1', '1, 31, 32', 'Cd', 'MonitoringBench, 5 (C-B)')
e('RACB', 103, 'Familles d\'attaque possiblement proches.', C, [],
  (123, 'Deux des onze catégories recoupent nos familles', 'Rien sur HC6.'), 'arXiv 2605.16626v2', '4, 5, 29', 'Cd', 'SLEIGHT-Bench, 2 (C-B)')
e('RACB', 104, 'non vus, 2025-09', C, [],
  (89, 'Gerard Boxo, Aman Neelappa, Shivam Raval ; v2 du 9 mars 2026 ; prépublication sans venue', None), 'arXiv 2509.21344v2', '1', 'Cb', '2509.21344, n° 1')
e('RACB', 104, "Retirer l'évidence textuelle d'un comportement fait perdre aux sondes de 10 à 30 points d'aire sous la courbe", C, [],
  (90, 'Le résumé annonce 10 à 30 points', 'entre texte et légendes.'), 'arXiv 2509.21344v2', '1, 5, 6, 8', 'Cb', '2509.21344, n° 2')
e('RACB', 104, 'voisin fort, **contre-indice**', C,
  [(91, "C'est une inférence, pas un résultat du papier", 'pas par agrégation robuste.')],
  (91, 'voisin (pas fort), contre-indice indirect', None), 'arXiv 2509.21344v2', '3, 8', 'Cb', '2509.21344, n° 3')
e('RACB', 106, 'non vus, 2025-08', C, [],
  (173, 'Brandon Jaipersaud, David Krueger, Ekdeep Singh Lubana ; v1 du 7 août 2025 ; aucune venue imprimée', None), 'arXiv 2508.05625v1', '1', 'Cb', '2508.05625, n° 1')
e('RACB', 106, 'Sondes sur Llama-3.2-3B', R,
  [(174, 'mais Llama-3.2-3B est un lecteur tiers', 'ni persuadeur ni persuadé')], None, 'arXiv 2508.05625v1', '3, 4', 'Cb', '2508.05625, n° 2')
e('RACB', 106, 'qui lisent le succès de la persuasion, la personnalité du persuadé et la stratégie employée', R,
  [(175, 'avec précisions', 'contre GPT-4.1-Nano')], None, 'arXiv 2508.05625v1', '1, 3, 8', 'Cb', '2508.05625, n° 3')
e('RACB', 106, 'Mécanisme plausible de l\'auto-incrimination : la stratégie de persuasion est lisible dans les activations de celui qui persuade.', C, [],
  (176, 'La stratégie (trois classes) est lisible', 'au modèle qui persuade.'), 'arXiv 2508.05625v1', '3, 4', 'Cb', '2508.05625, n° 4')
e('RACB', 106, 'voisin fort', C, [],
  (177, 'voisin faible', None), 'arXiv 2508.05625v1', '—', 'Cb', '2508.05625, n° 5')
e('RACB', 107, 'universités de Pennsylvanie et de New York, OpenAI ; 2026-02', C, [],
  (102, '2602.22303v1 (25 février 2026, cs.LG)', 'financée par MATS et OpenAI.'), 'arXiv 2602.22303v1', '1, 16', 'Be', 'B9-0')
e('RACB', 107, "l'agent appelle un outil `report_scheming()` quand il poursuit un but caché", R,
  [(103, 'précision : le comportement est appris', '(section 5.2, trois scénarios)')], None, 'arXiv 2602.22303v1', '1, 3, 78', 'Be', 'B9-1')
e('RACB', 107, 'GPT-4.1 passe de 56 % à 6 % d\'attaques réussies non détectées.', R,
  [(104, 'précisions : moyenne a posteriori', '(lecture de figure)')], None, 'arXiv 2602.22303v1', '2, 7', 'Be', 'B9-2')
e('RACB', 109, "À coût d'audit égal, les moniteurs de la même lignée que l'attaquant capturent 41 % des attaques, contre 19 % hors lignée.", C, [],
  (206, 'Dans un protocole de report vers le modèle de confiance', 'pas sur des sabotages réussis.'), 'arXiv 2607.06596v3', '1, 3, 25', 'Cd', 'Calibration-Family Overfit, 1 (C-B)')
e('RACB', 109, 'Diversité de lignée et transfert entre moniteurs.', C, [],
  (207, "transfert d'un moniteur calibré d'une famille", 'pas celle des moniteurs.'), 'arXiv 2607.06596v3', '1, 3', 'Cd', 'Calibration-Family Overfit, 2 (C-B)')
e('RACB', 109, 'HC1 (stabilité entre moniteurs)', C,
  [(208, 'non étayé : le papier ne contient ni pression sur le moniteur', '(voir 3.3)')], None, 'arXiv 2607.06596v3', '3', 'Cd', 'Calibration-Family Overfit, 3 (C-B)')

# ======================= formulations proposées pour une ligne entière =======================
W = []
def w(doc, l, actuel, v, f, src, pg, rap, rep):
    W.append(dict(doc=doc, l=l, actuel=actuel, v=v, q=[], f=f, src=src, pg=pg, rap=rap, rep=rep))

w('EdA', 33, '**Goldowsky-Dill, Chughtai, Heimersheim, Hobbhahn (Apollo Research)**, arXiv 2502.03407, ICML 2025', C,
  (196, '- **Goldowsky-Dill, Chughtai', "l'abandon de la moyenne."), 'arXiv 2502.03407v1', '1, 6, 9, 22, 23', 'A2b', 'formulation pour la ligne 33')
w('EdA', 42, '**Beyond Linear Probes (Oldfield, Torr, Patras, Bibi, Barez)**, arXiv 2509.26238, ICLR 2026', C,
  (63, '- **Beyond Linear Probes (Oldfield', '→ Base architecturale seulement.'), 'arXiv 2509.26238v4', '1, 3, 10', 'A2b', 'formulation pour la ligne 42')
w('EdA', 47, '**Pressure-Testing Deception Probes (Kumar)**, arXiv 2605.27958, ACL 2026', C,
  (129, '- **Pressure-Testing Deception Probes (Kumar)**', 'les corrélats de surface.'), 'arXiv 2605.27958v1', '1, 4-9, 12, 13', 'A2b', 'formulation pour la ligne 47')
w('EdA', 90, '**TraceGuard**, arXiv 2604.03968', C,
  ((265, 271), 'TraceGuard (Nguyen, Nghiem, Tran', 'effectifs incohérents.'), 'arXiv 2604.03968v1', '1, 8, 11, 13, 14, 16, 19', 'A4', 'formulation pour la ligne 90 (l. 265-271)')
w('EdA', 93, '**Honeypot Protocol**, arXiv 2604.13301', C,
  (331, 'Honeypot Protocol (Hasan', 'pas un résultat sur H7.'), 'arXiv 2604.13301v1', '1, 4, 5, 6', 'A4', 'formulation pour la ligne 93 (partie Honeypot)')
w('EdA', 129, '**The Silent Judge**, arXiv 2509.26072', R,
  (55, '**The Silent Judge** (Marioriyad', "jamais l'indice."), 'arXiv 2509.26072v2', '3, 5, 8', 'C2a', 'formulation facultative pour la ligne 129')
w('EdA', 130, '**Nogueira et al.**, arXiv 2604.21564', R,
  (223, '**Nogueira et al.** (Maritaca', 'ni gain.'), 'arXiv 2604.21564v2', '9, 12, 16, 17, 18', 'C2a', 'formulation facultative pour la ligne 130')
w('EdA', 133, '**Attaques par suffixes optimisés** (autre modèle de menace, à ne pas confondre avec la pression sociale)', C,
  (184, '- **Attaques par suffixes optimisés**', 'parmi les manipulations adverses).'),
  'arXiv 2403.17710v5 ; 2505.13348v1 ; 2402.14016v2 ; 2504.18333v1 ; 2603.29403v2', 'voir les lignes 3.1 à 5.2 du rapport', 'C2b', 'formulation pour la ligne 133 (« remplacement exact ; décision de Lazar »)')
w('EdA', 135, '**Dégradation sans évasion par pur contenu** : **Blandfort & Graham**, arXiv 2511.00554 ⚠ non lu directement', C,
  (308, '- **Évasion partielle par pur contenu**', 'à fortes incitations).'), 'arXiv 2511.00554v1', '1, 3, 4, 6, 7, 8, 11', 'A2b', 'formulation pour la ligne 135')
w('EdA', 137, "**Détection d'injection par états internes** : InstructDetector, arXiv 2505.06311", C,
  (270, '… ESLD, arXiv 2605.18918', 'par ces quatre sources.'), 'arXiv 2505.06311v2 ; 2604.22888v1 ; 2605.18918v1 ; 2603.12277v6', 'voir sections 1 à 4 du rapport', 'C3a', 'formulation pour la ligne 137 (en remplacement de la parenthèse et de la conclusion)')
w('EdA', 139, '**esquisses de safety cases (Balesni, Korbak et al.)**, arXiv 2411.03336', C,
  (117, 'esquisses de safety cases (Balesni, Hobbhahn', "que l'article cite."), 'arXiv 2411.03336v2', '1, 23, 26, 27, 44', 'A4', 'formulation pour la ligne 139 (partie 2411.03336)')
w('EdA', 139, 'How to evaluate control measures, arXiv 2504.05259', C,
  (166, 'How to evaluate control measures (Korbak', 'une direction prometteuse.'), 'arXiv 2504.05259v1', '24', 'A4', 'formulation pour la ligne 139 (partie 2504.05259)')
w('EdA', 146, 'Auto-incrimination comme résultat central (seulement effleurée par 2609.03035 et 2605.27958).', C,
  (131, '- Auto-incrimination comme résultat central (2605.27958', 'dans son propre lot).'), 'arXiv 2605.27958v1', '5', 'A2b', 'formulation pour la ligne 146 (partie 2605.27958)')
w('EdA', 196, 'Contenu, non lu directement', C,
  (250, '12 ¦ arXiv 2606.07612, 2511.00554', 'voir la section 5'), 'arXiv 2606.07612v1 ; arXiv 2511.00554v1', '7, 22', 'A2b', 'formulation pour la ligne 196 (rangée 12)')
w('N1', 171, '**Papier B, H8, HC2b.** Shi, Zhang, Yang 2026, arXiv 2609.24967 ; Haskins, Chughtai, Engels 2026 ; Nguyen et al. 2025.', C,
  (362, '10. **Papier B, H8, HC2b.**', 'Nguyen et al. 2025.'), 'arXiv 2609.24967v2', '9, 12', 'A2b', 'formulation pour la ligne 171')

# ======================= confirmées sans réserve, par rapport (comptes) =======================
SANS_RESERVE = [
    ('H2v', 0, 'aucune affirmation du programme contrôlée (lecture d\'antériorité seule)'),
    ('HC1v', 0, 'une affirmation transmise (décision N-005, l. 74), contrôlée pour PARROT et pour BASIL, chaque fois avec nuance'),
    ('GC', 0, 'aucune affirmation du programme contrôlée (lecture d\'antériorité seule)'),
    ('lemme', 0, 'deux affirmations contrôlées, toutes deux corrigées'),
    ('A1', 22, ''), ('A2a', 11, ''), ('A2b', 15, ''), ('A3', 6, ''), ('A4', 13, ''), ('B1', 21, ''),
    ('C1a', 13, ''), ('C1b', 13, ''), ('C2a', 11, ''), ('C2b', 8, ''), ('C3a', 9, ''), ('C3b', 6, ''),
    ('Aa', 14, ''), ('Ab', 10, ''), ('Ac', 7, ''), ('Be', 5, ''), ('Ca', 9, ''), ('Cb', 2, ''), ('Cc', 6, ''), ('Cd', 7, ''),
]
