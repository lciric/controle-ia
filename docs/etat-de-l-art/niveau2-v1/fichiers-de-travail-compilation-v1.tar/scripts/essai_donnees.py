# -*- coding: utf-8 -*-
"""Essai des données : signale tout extrait introuvable (sans rien écrire)."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from extraction import extrait, verifier_actuel, ErreurExtraction
import donnees_corrections as D

nerr = 0
for k, r in enumerate(D.E + D.W):
    if not verifier_actuel(r['doc'], r['l'], r['actuel']):
        nerr += 1; print('ACTUEL', k, r['doc'], r['l'], repr(r['actuel'][:60]))
    if '|' in r['actuel']:
        nerr += 1; print('BARRE-ACTUEL', k, r['doc'], r['l'])
    if len(r['actuel'].split()) > 25:
        nerr += 1; print('LONGUEUR', k, r['doc'], r['l'], len(r['actuel'].split()))
    for q in r['q']:
        try:
            extrait(r['rap'], q)
        except ErreurExtraction as ex:
            nerr += 1; print('CITATION', k, ex)
    if r['f']:
        try:
            x = extrait(r['rap'], r['f'])
            if '|' in x:
                nerr += 1; print('BARRE', k, r['rap'], r['f'][0])
        except ErreurExtraction as ex:
            nerr += 1; print('FORMULATION', k, ex)
print('entrées', len(D.E), '+', len(D.W), 'erreurs', nerr)
