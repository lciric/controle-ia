"""Chemins et utilitaires communs (lecture seule du dépôt)."""
import re

RACINE = '/home/user/controle-ia'
DOSSIER_RAPPORTS = RACINE + '/docs/sources/lecture-pdf-niveau2/'

DOCS = {
    'PROG': 'docs/programme-controle-ia-v2.md',
    'EdA': 'docs/etat-de-l-art-controle-ia-v1.md',
    'N1': 'docs/etat-de-l-art/etat-de-l-art-verifie-niveau1-v1.md',
    'PC': 'docs/sources/lecture-pdf-niveau1/rapport-papierC-v1.md',
    'N005': 'docs/decisions/decision-N-005-N-006-v1.md',
    'PGC': 'docs/etat-de-l-art/porte-GC-loi-de-deference-v1.md',
    'BRIEF': 'docs/brief-claude-code-programme-complet-v2.md',
    'PROV': 'docs/sources/pdf/provenance-niveau2-lot2-v1.md',
    'RAA': 'docs/sources/recherche-affirmative-20261006/rapport-papier-A-v1.md',
    'RACB': 'docs/sources/recherche-affirmative-20261006/rapport-papiers-C-B-v1.md',
}
ORDRE_DOCS = ['PROG', 'EdA', 'N1', 'PC', 'N005', 'PGC', 'BRIEF', 'PROV', 'RAA', 'RACB']

RAPPORTS = {
    'H2v': 'rapport-H2-voisins-v1.md',
    'HC1v': 'rapport-HC1-voisins-v1.md',
    'GC': 'rapport-GC-reseaux-v1.md',
    'lemme': 'rapport-lemme-v1.md',
    'A1': 'rapport-lot2-A1-bases-sequentielles-v1.md',
    'A2a': 'rapport-lot2-A2a-evasion-sondes-v1.md',
    'A2b': 'rapport-lot2-A2b-validite-sondes-v1.md',
    'A3': 'rapport-lot2-A3-sabotage-recherche-v1.md',
    'A4': 'rapport-lot2-A4-protocoles-controle-v1.md',
    'B1': 'rapport-lot2-B1-multi-agents-v1.md',
    'C1a': 'rapport-lot2-C1a-juges-biais-v1.md',
    'C1b': 'rapport-lot2-C1b-persuasion-v1.md',
    'C2a': 'rapport-lot2-C2a-deplacement-juges-v1.md',
    'C2b': 'rapport-lot2-C2b-suffixes-v1.md',
    'C3a': 'rapport-lot2-C3a-injection-etats-internes-v1.md',
    'C3b': 'rapport-lot2-C3b-separation-controle-donnees-v1.md',
    'Aa': 'rapport-lot3-Aa-H2-trajectoire-v1.md',
    'Ab': 'rapport-lot3-Ab-accumulation-agregation-v1.md',
    'Ac': 'rapport-lot3-Ac-blanc-noir-interventions-feuille-v1.md',
    'Be': 'rapport-lot3-Be-essaim-auto-signalement-v1.md',
    'Ca': 'rapport-lot3-Ca-juges-ancrage-v1.md',
    'Cb': 'rapport-lot3-Cb-sondes-texte-persuasion-v1.md',
    'Cc': 'rapport-lot3-Cc-evasion-quorum-v1.md',
    'Cd': 'rapport-lot3-Cd-bancs-attaque-v1.md',
}

VERDICTS = ('corrigé', 'introuvable', 'confirmé avec réserve')


def lire_lignes(chemin):
    with open(chemin, encoding='utf-8') as f:
        return f.read().split('\n')


def norm(t):
    """Réduit toute suite de blancs Unicode à une espace ; rien d'autre."""
    return re.sub(r'\s+', ' ', t).strip()


def segments_guillemets(t):
    """Segments de premier niveau entre « et », en tenant compte de l'emboîtement."""
    segs, prof, debut = [], 0, None
    for i, c in enumerate(t):
        if c == '«':
            if prof == 0:
                debut = i + 1
            prof += 1
        elif c == '»' and prof > 0:
            prof -= 1
            if prof == 0:
                segs.append(t[debut:i])
    if prof != 0:
        raise ValueError('guillemets non équilibrés : ' + t[:80])
    return segs
