# -*- coding: utf-8 -*-
"""Génère corrections.md à partir de donnees_corrections.py.
Tous les extraits des rapports sont tirés par programme (extraction.py) ; le texte actuel est contrôlé sur le document.
Usage : python3 -I gen_corrections.py SORTIE.md
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from communs import DOCS, ORDRE_DOCS, RAPPORTS, VERDICTS, norm, segments_guillemets
from extraction import extrait, verifier_actuel
import donnees_corrections as D

ENTETE = ['#', 'document', 'ligne', 'texte actuel', 'verdict', 'formulation de remplacement', 'source', 'page', 'rapport', 'repère dans le rapport']

def cellule(t):
    if '|' in t or '\n' in t:
        raise SystemExit('cellule interdite (barre ou saut de ligne) : ' + t[:80])
    return t

def ligne_table(n, r):
    if not verifier_actuel(r['doc'], r['l'], r['actuel']):
        raise SystemExit('texte actuel absent : %s l. %d' % (r['doc'], r['l']))
    if len(r['actuel'].split()) > 25:
        raise SystemExit('texte actuel trop long : %s l. %d' % (r['doc'], r['l']))
    assert r['v'] in VERDICTS
    v = r['v']
    cits = [extrait(r['rap'], q) for q in r['q']]
    for c in cits:
        if segments_guillemets('«' + c + '»') != [c]:
            raise SystemExit('citation non équilibrée : ' + c[:80])
    if cits:
        v += ' — ' + ' ; '.join('« ' + c + ' »' for c in cits)
    f = extrait(r['rap'], r['f']) if r['f'] else '—'
    if isinstance(r['f'], tuple) and isinstance(r['f'][0], tuple):
        lignes = '%d-%d' % r['f'][0]
    else:
        ls = sorted(set([q[0] for q in r['q']] + ([r['f'][0]] if r['f'] else [])))
        lignes = ', '.join(str(x) for x in ls)
    rep = r['rep'] + (' (l. %s)' % lignes if lignes else '')
    cells = [str(n), DOCS[r['doc']], str(r['l']), r['actuel'], v, f, r['src'], r['pg'], RAPPORTS[r['rap']], rep]
    return '| ' + ' | '.join(cellule(c) for c in cells) + ' |'

def trier(liste):
    return sorted(liste, key=lambda r: (ORDRE_DOCS.index(r['doc']), r['l']))

def table(liste, depart=1):
    out = ['| ' + ' | '.join(ENTETE) + ' |', '|' + '---|' * len(ENTETE)]
    for k, r in enumerate(liste):
        out.append(ligne_table(depart + k, r))
    return out

def compte(liste):
    c = {v: 0 for v in VERDICTS}
    for r in liste:
        c[r['v']] += 1
    return c

prog = trier([r for r in D.E if r['doc'] not in ('RAA', 'RACB')])
ra = trier([r for r in D.E if r['doc'] in ('RAA', 'RACB')])
entieres = trier(D.W)
cp, cr = compte(prog), compte(ra)

L = []
A = L.append
A('# Table des corrections — lectures sur PDF de niveau 2 (lots 1 à 3) — v1')
A('')
A('Compilation par un compilateur neuf, qui n\'a écrit ni les documents du programme ni les rapports compilés. Aucun PDF (format de document portable) n\'a été lu ici : chaque ligne reprend ce qu\'un lecteur neuf a vérifié sur PDF empreinté, page citée (R7). Une limitation d\'un papier n\'est pas un trou du champ (R8).')
A('')
A('- **Sources** : les 24 rapports de `docs/sources/lecture-pdf-niveau2/` (4 du lot 1, 12 du lot 2, 8 du lot 3), chacun vérifié contre son fichier compagnon `.sha256` avant lecture : 24 sur 24 conformes.')
A('- **Extraits exacts** : le « texte actuel » est recopié du document cité (25 mots au plus) ; la « formulation de remplacement » et les passages cités dans la colonne « verdict » (entre guillemets) sont tirés des rapports par programme, mot pour mot. Le script `scripts/verifier_corrections.py` contrôle les uns et les autres (voir son journal).')
A('- **Verdicts** : « corrigé » (le lecteur corrige, avec ou sans formulation de remplacement) ; « introuvable » (chiffre, venue ou attribution absents du PDF lu) ; « confirmé avec réserve » (le lecteur confirme, mais limite ou nuance la portée, le chiffre, la condition ou la pertinence, ou propose une formulation). Une affirmation confirmée sans réserve n\'apparaît pas ; leur nombre par rapport est donné en section 6.')
A('- **Règle de classement** appliquée par le compilateur : « sans réserve » quand la précision du lecteur est seulement descriptive et conforme, un complément d\'identité (auteurs, affiliations, version, venue, date), une vérification partielle d\'un usage propre au programme (« sur le vérifiable ») ou un rappel purement R8 (« pour cette source seulement ») ; « avec réserve » dans les autres cas de confirmation qualifiée. Une ligne de rapport qui donne deux verdicts à deux parties d\'une même affirmation compte pour deux.')
A('- **Portée** : outre les quatre documents désignés par la consigne (état de l\'art v1, état de l\'art vérifié de niveau 1, programme v2, rapport papier C du niveau 1), la table reprend les autres documents que les lecteurs corrigent explicitement : décision N-005/N-006 (l. 74, 80), note de la porte GC (l. 35, même affirmation qu\'en N-005 l. 74), brief v2 (l. 133) et fichier de provenance du lot 2 (l. 10).')
A('- **Ordre** : par document (programme, état de l\'art v1, niveau 1, papier C, décision, porte GC, brief, provenance), puis par numéro de ligne. Deux rapports qui touchent la même ligne donnent deux lignes de table (section 4).')
A('- **Numéros de ligne** : ceux des fichiers tels qu\'ils sont sur disque à la compilation ; « repère dans le rapport » donne l\'item du lecteur et les lignes du rapport d\'où viennent les extraits.')
A('')
A('## 1. Documents du programme')
A('')
L.extend(table(prog))
A('')
A('Bilan de la section 1 : %d lignes — %d « corrigé », %d « introuvable », %d « confirmé avec réserve ».' % (len(prog), cp['corrigé'], cp['introuvable'], cp['confirmé avec réserve']))
A('')
A('## 2. Formulations proposées pour une ligne entière (documents du programme)')
A('')
A('Ces formulations regroupent plusieurs corrections de la section 1 ; elles sont données telles que les lecteurs les proposent, pour décision de Lazar. Celles des lignes 129 et 130 sont dites « facultatives » par le lecteur.')
A('')
L.extend(table(entieres))
A('')
A('## 3. Corrections des rapports de recherche affirmative')
A('')
A('Documents : `docs/sources/recherche-affirmative-20261006/rapport-papier-A-v1.md` et `rapport-papiers-C-B-v1.md`. Ces corrections portent sur les deux rapports de recherche affirmative, non sur un document du programme.')
A('')
L.extend(table(ra))
A('')
A('Bilan de la section 3 : %d lignes — %d « corrigé », %d « introuvable », %d « confirmé avec réserve ».' % (len(ra), cr['corrigé'], cr['introuvable'], cr['confirmé avec réserve']))
A('')
sys.stdout.write('')
SUITE = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'corrections-suite.md'), encoding='utf-8').read()
L.append(SUITE.rstrip('\n'))
A('')
A('## 6. Affirmations confirmées sans réserve (nombre par rapport)')
A('')
A('| rapport | confirmées sans réserve | remarque |')
A('|---|---|---|')
tot = 0
for cle, n, rem in D.SANS_RESERVE:
    tot += n
    A('| %s | %d | %s |' % (RAPPORTS[cle], n, cellule(rem) if rem else '—'))
A('| **total** | **%d** | — |' % tot)
A('')
nprog_c, nprog_i, nprog_r = cp['corrigé'], cp['introuvable'], cp['confirmé avec réserve']
nra_c, nra_i, nra_r = cr['corrigé'], cr['introuvable'], cr['confirmé avec réserve']
A('**Totaux.** Documents du programme : %d lignes (%d corrigé, %d introuvable, %d confirmé avec réserve) et %d formulations de ligne entière. Rapports de recherche affirmative : %d lignes (%d corrigé, %d introuvable, %d confirmé avec réserve). Confirmées sans réserve : %d.' % (len(prog), nprog_c, nprog_i, nprog_r, len(entieres), len(ra), nra_c, nra_i, nra_r, tot))
with open(sys.argv[1], 'w', encoding='utf-8') as fo:
    fo.write('\n'.join(L) + '\n')
print('programme', len(prog), cp, '| entières', len(entieres), '| recherche affirmative', len(ra), cr)
