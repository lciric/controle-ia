# -*- coding: utf-8 -*-
"""Extraction programmée des citations des rapports (aucune recopie à la main)."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from communs import RACINE, DOSSIER_RAPPORTS, DOCS, RAPPORTS, lire_lignes, norm

_cache = {}

def lignes_rapport(cle):
    if cle not in _cache:
        _cache[cle] = lire_lignes(DOSSIER_RAPPORTS + RAPPORTS[cle])
    return _cache[cle]

def lignes_doc(cle):
    k = 'DOC:' + cle
    if k not in _cache:
        _cache[k] = lire_lignes(RACINE + '/' + DOCS[cle])
    return _cache[k]

class ErreurExtraction(Exception):
    pass

def extrait(rap, spec):
    """spec = (ligne, début, fin) ; ligne peut être (a, b) pour un bloc de lignes joint par des espaces."""
    rl, debut, fin = spec
    L = lignes_rapport(rap)
    if isinstance(rl, tuple):
        a, b = rl
        s = ' '.join(L[a - 1:b])
    else:
        s = L[rl - 1]
    i = s.find(debut)
    if i < 0:
        raise ErreurExtraction('%s l. %s : début introuvable : %r' % (rap, rl, debut))
    if fin is None:
        return debut
    if fin == '$':
        return s[i:].rstrip()
    j = s.find(fin, i + len(debut) - 1 if len(debut) > 0 else i)
    if j < 0:
        raise ErreurExtraction('%s l. %s : fin introuvable après le début : %r' % (rap, rl, fin))
    return s[i:j + len(fin)]

def verifier_actuel(doc, l, actuel):
    L = lignes_doc(doc)
    zone = norm(' '.join(L[max(0, l - 3):l + 2]))
    return norm(actuel) in zone
