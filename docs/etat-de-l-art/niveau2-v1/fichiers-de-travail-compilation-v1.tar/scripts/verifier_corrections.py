# -*- coding: utf-8 -*-
"""Contrôle de corrections.md, indépendant du générateur.

Pour chaque ligne des tables à dix colonnes :
  1. le « texte actuel » figure dans le document cité, à la ligne citée ± 2 lignes ;
  2. la « formulation de remplacement » (si elle n'est pas « — ») figure mot pour mot dans le rapport cité ;
  3. chaque passage entre guillemets de premier niveau de la colonne « verdict » figure mot pour mot dans le rapport cité ;
  4. le verdict commence par « corrigé », « introuvable » ou « confirmé avec réserve ».
Seule tolérance : toute suite de blancs (y compris insécables) vaut une espace. Aucune autre.

Garde (R5) : un autotest sur un cas juste et sur des cas altérés est passé avant tout contrôle ;
s'il ne donne pas le résultat attendu, le script s'arrête (code 2) sans contrôler le fichier.

Usage : python3 -I verifier_corrections.py corrections.md [journal.txt]
Code de sortie : 0 si aucun échec, 1 s'il y a des échecs, 2 si l'autotest échoue.
"""
import sys, os, re

RACINE = '/home/user/controle-ia'
DOSSIER_RAPPORTS = RACINE + '/docs/sources/lecture-pdf-niveau2/'
VERDICTS = ('corrigé', 'introuvable', 'confirmé avec réserve')

def norm(t):
    return re.sub(r'\s+', ' ', t).strip()

_cache = {}
def lire(chemin):
    if chemin not in _cache:
        with open(chemin, encoding='utf-8') as f:
            _cache[chemin] = f.read()
    return _cache[chemin]

def segments(t):
    segs, prof, debut = [], 0, None
    for i, c in enumerate(t):
        if c == '«':
            if prof == 0:
                debut = i + 1
            prof += 1
        elif c == '»' and prof > 0:
            prof -= 1
            if prof == 0:
                segs.append(t[debut:i])
    if prof != 0:
        return None
    return segs

def controler_ligne(cells):
    """Renvoie une liste de (type de contrôle, réussi : bool, détail)."""
    res = []
    num, doc, ligne, actuel, verdict, formul, src, page, rapport, repere = cells
    # 1. texte actuel
    try:
        lignes = lire(RACINE + '/' + doc).split('\n')
        l = int(ligne)
        zone = norm(' '.join(lignes[max(0, l - 3):l + 2]))
        ok = norm(actuel) in zone and norm(actuel) != ''
        res.append(('texte actuel', ok, '%s l. %s' % (doc, ligne)))
    except Exception as ex:
        res.append(('texte actuel', False, 'document illisible : %s (%s)' % (doc, ex)))
    try:
        texte_rap = norm(lire(DOSSIER_RAPPORTS + rapport))
    except Exception as ex:
        res.append(('rapport', False, 'rapport illisible : %s (%s)' % (rapport, ex)))
        return res
    # 2. formulation
    if formul.strip() != '—':
        ok = norm(formul) != '' and norm(formul) in texte_rap
        res.append(('formulation', ok, '%s (#%s)' % (rapport, num)))
    # 3. et 4. verdict
    v = verdict.strip()
    mot = [k for k in VERDICTS if v == k or v.startswith(k + ' ')]
    res.append(('mot du verdict', bool(mot), v[:40]))
    reste = v[len(mot[0]):] if mot else v
    segs = segments(reste)
    if segs is None:
        res.append(('citation du verdict', False, 'guillemets non équilibrés (#%s)' % num))
    else:
        for s_ in segs:
            ok = norm(s_) != '' and norm(s_) in texte_rap
            res.append(('citation du verdict', ok, '%s (#%s) : %s' % (rapport, num, s_[:60])))
    return res

def lignes_tables(md):
    out = []
    for no, ligne in enumerate(md.split('\n'), 1):
        if not ligne.startswith('| '):
            continue
        cells = [c.strip() for c in ligne.strip().strip('|').split('|')]
        if len(cells) == 10 and cells[0].isdigit():
            out.append((no, cells))
        elif len(cells) == 10 and cells[0] not in ('#',) and not set(ligne) <= set('|-'):
            out.append((no, cells))  # ligne mal formée : sera contrôlée et échouera
    return out

def autotest():
    """Cas juste, puis cas altérés : chaque contrôle doit réussir sur le juste et échouer sur l'altéré."""
    doc = 'docs/etat-de-l-art-controle-ia-v1.md'
    rap = 'rapport-lot2-A1-bases-sequentielles-v1.md'
    act = 'attaques furtives sur systèmes cyber-physiques qui gardent chaque résidu sous le seuil, arXiv 2005.07821'
    form = 'détecteur à signe cumulé sans mémoire (CUSIGN) qui repère, en simulation sur un véhicule terrestre'
    cit = "l'article est un article de détection"
    juste = ['1', doc, '46', act, 'corrigé — « ' + cit + ' »', form, 's', 'p', rap, 'r']
    r = controler_ligne(juste)
    if not (r and all(ok for _, ok, _ in r) and len(r) == 4):
        return 'le cas juste ne passe pas : %r' % r
    # blancs différents (espace insécable, saut de ligne) : doivent passer
    juste2 = list(juste); juste2[5] = form.replace(' ', ' ', 3).replace('sur un', 'sur\n un')
    if not all(ok for _, ok, _ in controler_ligne(juste2)):
        return 'la tolérance aux blancs ne fonctionne pas'
    alteres = {
        'chiffre altéré dans la formulation': (5, form.replace('CUSIGN', 'CUSUM')),
        'mot altéré dans la formulation': (5, form.replace('terrestre', 'aérien')),
        'texte actuel altéré': (3, act.replace('2005.07821', '2005.07822')),
        'mauvaise ligne (hors ± 2)': (2, '52'),
        'citation du verdict altérée': (4, 'corrigé — « ' + cit.replace('détection', 'attaque') + ' »'),
        'mot du verdict inconnu': (4, 'confirmé — « ' + cit + ' »'),
        'apostrophe typographique au lieu de droite': (4, 'corrigé — « ' + cit.replace("'", '’') + ' »'),
    }
    for nom, (k, val) in alteres.items():
        c = list(juste); c[k] = val
        if all(ok for _, ok, _ in controler_ligne(c)):
            return 'cas altéré non détecté : ' + nom
    return None

def main():
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(2)
    journal = []
    def J(t):
        journal.append(t); print(t)
    e = autotest()
    if e:
        J('AUTOTEST ÉCHOUÉ : ' + e + ' — arrêt, aucun contrôle effectué.')
        if len(sys.argv) > 2:
            open(sys.argv[2], 'w', encoding='utf-8').write('\n'.join(journal) + '\n')
        sys.exit(2)
    J('Autotest (R5) : cas juste accepté, tolérance aux blancs acceptée, 7 cas altérés rejetés.')
    md = lire(os.path.abspath(sys.argv[1]))
    lignes = lignes_tables(md)
    compte = {}
    echecs = []
    for no, cells in lignes:
        for typ, ok, det in controler_ligne(cells):
            compte.setdefault(typ, [0, 0])
            compte[typ][0] += 1
            if not ok:
                compte[typ][1] += 1
                echecs.append('ligne %d du fichier — %s — %s' % (no, typ, det))
    J('Fichier contrôlé : %s' % sys.argv[1])
    J('Lignes de table contrôlées : %d' % len(lignes))
    tot, tot_e = 0, 0
    for typ in ('texte actuel', 'formulation', 'citation du verdict', 'mot du verdict', 'rapport'):
        if typ in compte:
            J('  %s : %d contrôles, %d échecs' % (typ, compte[typ][0], compte[typ][1]))
            tot += compte[typ][0]; tot_e += compte[typ][1]
    ta = compte.get('texte actuel', [0, 0]); fo = compte.get('formulation', [0, 0])
    J('Contrôles demandés par la consigne (textes actuels + formulations) : %d, échecs : %d' % (ta[0] + fo[0], ta[1] + fo[1]))
    J('Tous contrôles confondus : %d, échecs : %d' % (tot, tot_e))
    for x in echecs:
        J('ÉCHEC : ' + x)
    if len(sys.argv) > 2:
        open(sys.argv[2], 'w', encoding='utf-8').write('\n'.join(journal) + '\n')
    sys.exit(1 if echecs else 0)

if __name__ == '__main__':
    main()
