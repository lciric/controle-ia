# Consigne — compilation du niveau 2 de l'état de l'art (lots 1 à 3)

Tu es un compilateur neuf : tu n'as écrit ni les documents du programme, ni les rapports de lecture. Tu ne lis aucun PDF : tu compiles ce que des lecteurs neufs ont vérifié sur PDF, sans rien ajouter. Règles : R7 (aucun chiffre ni aucune affirmation sans source vérifiée, page citée) ; R8 (une limitation d'un papier n'est pas un trou du champ). Français, sans acronyme non développé.

## Entrées (lecture seule)
- Rapports de lecture, tous dans `/home/user/controle-ia/docs/sources/lecture-pdf-niveau2/` : `rapport-*.md` (lot 1 : `rapport-H2-voisins-v1.md`, `rapport-HC1-voisins-v1.md`, `rapport-GC-reseaux-v1.md`, `rapport-lemme-v1.md` ; lot 2 : `rapport-lot2-*.md`, douze ; lot 3 : `rapport-lot3-*.md`, huit). Vérifie l'empreinte de chacun contre son fichier compagnon `.sha256` avant de le lire ; si l'une diffère, arrête-toi et dis-le.
- Documents du programme que les rapports corrigent :
  - `/home/user/controle-ia/docs/etat-de-l-art-controle-ia-v1.md` (les lecteurs citent ses numéros de ligne) ;
  - `/home/user/controle-ia/docs/etat-de-l-art/etat-de-l-art-verifie-niveau1-v1.md` ;
  - `/home/user/controle-ia/docs/programme-controle-ia-v2.md` ;
  - `/home/user/controle-ia/docs/sources/lecture-pdf-niveau1/rapport-papierC-v1.md` (certains lecteurs le corrigent aussi).
- Décisions qui fixent la lecture du programme (contexte) : `/home/user/controle-ia/docs/decisions/decision-N-003-N-004-v1.md`, `decision-N-005-N-006-v1.md`, `decision-N-007-N-008-v1.md`, `decision-P-008-v1.md`.

## Ce que tu produis (dans `/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/synthese-niveau2/`)

### 1. `corrections.md` — table des corrections, une ligne par affirmation corrigée ou introuvable
Colonnes : `# | document | ligne | texte actuel (extrait exact du document, ≤ 25 mots) | verdict (corrigé / introuvable / confirmé avec réserve) | formulation de remplacement (recopiée mot pour mot du rapport ; sinon « — ») | source (arXiv et version) | page | rapport | repère dans le rapport`.
- Une affirmation confirmée sans réserve n'y figure pas ; donne seulement leur nombre par rapport, en fin de fichier.
- Si deux rapports touchent la même ligne, deux lignes de table, et signale toute contradiction entre eux.
- Range les lignes par document puis par numéro de ligne.

### 2. `anteriorite.md` — table par énoncé revendiqué
Énoncés : H1, H2, L (lemme d'additivité), T (théorème négatif), Tr (transposition jeton → action), H6, H8, HC1, HC2, HC2b, HC3, HC4, HC5, HC6, H3, H4′, H5, H7, statistique de population.
Pour chaque énoncé, une table : `source | verdict du lecteur (occupe en entier / occupe en partie / voisin / contre-indice / ne touche pas) | composantes faites | composantes non faites | pages | rapport`. Puis trois lignes au plus : ce qui reste revendicable d'après les lecteurs, et les désaccords entre lecteurs (par exemple un « occupe en partie » de la recherche affirmative ramené à « voisin » sur PDF).
Signale en tête de fichier, en gras, tout verdict « occupe en entier » et toute pièce que les décisions de Lazar listent comme « revendiquée » et qu'un lecteur trouve déjà publiée (par exemple, pour HC1, le verdict lu par la probabilité du jeton).

### 3. `chiffres-introuvables.md` — chiffres ou venues que les documents du programme affirment et qu'aucun PDF ne porte
Colonnes : `document | ligne | chiffre ou venue | ce que les lecteurs ont cherché | rapport`.

### 4. `reserves-R4.md` — incohérences internes et résultats « trop beaux » relevés dans les sources
Colonnes : `source | réserve | conséquence pour l'usage du chiffre | rapport`.

### 5. Contrôle par script
Écris un script (Python lancé avec `python3 -I`, dans un sous-dossier `scripts/` de ton dossier) qui vérifie que chaque « formulation de remplacement » et chaque « texte actuel » de `corrections.md` figurent mot pour mot (aux blancs près) dans le rapport cité, pour la première, et dans le document cité à la ligne citée (± 2 lignes), pour le second. Teste-le d'abord sur un cas juste et un cas altéré (R5). Donne le nombre de contrôles et d'échecs ; corrige tout échec en recopiant exactement, sans élargir la tolérance.

## Ce que tu rends
- Dans ta réponse finale : les chemins, l'empreinte sha256 de chacun des quatre fichiers (écris aussi un fichier compagnon `.sha256` pour chacun), les nombres (corrections, introuvables, réserves, contrôles, échecs) et une synthèse de dix lignes au plus.
- NE MODIFIE RIEN sous `/home/user/controle-ia` : ni fichier, ni git.
