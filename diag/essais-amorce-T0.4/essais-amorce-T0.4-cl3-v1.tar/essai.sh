#!/usr/bin/env bash
# Essai local de la chaîne amorce → script d'instance, en mode jouet, contre une copie nue du dépôt.
#   essai.sh <nom> <commit> [motif_journal secondes]
# Avec un motif : dès que le journal de l'instance contient le motif, attendre N secondes, puis envoyer TERM au
# processus « timeout » de l'amorce, trouvé comme enfant de l'amorce (par identifiant de processus, R10) : même
# chemin que l'expiration du plafond (gestionnaire de timeout), sans réduire la durée figée.
set -uo pipefail
nom=$1; commit=$2; motif=${3:-}; attente=${4:-0}
ici=$(cd "$(dirname "$0")" && pwd)
d="$ici/$nom"
[ -e "$d" ] && { echo "$d existe (R12)"; exit 2; }
mkdir -p "$d/racine"
git clone -q --bare /home/user/controle-ia "$d/distant.git"
git -C /home/user/controle-ia show "$commit":scripts/amorce_instance_t04.sh > "$d/amorce.sh"
(
  cd "$d/racine" &&
  env -u CONTROLE_IA_GITHUB_TOKEN COMMIT="$commit" GH_TOKEN=jeton-factice HF_TOKEN=jeton-factice \
      DEPOT_URL="$d/distant.git" RACINE_AMORCE="$d/racine" MODE=jouet VENV_EXISTANT=/home/user/controle-ia/.venv \
      BRANCHE="calcul/essai-$nom" bash "$d/amorce.sh" > "$d/amorce.log" 2>&1
  echo "code amorce : $?" >> "$d/amorce.log"
) &
pid_amorce=$!
if [ -n "$motif" ]; then
  for _ in $(seq 1 600); do
    grep -q -- "$motif" "$d/racine/t04/journal.txt" 2>/dev/null && break
    sleep 0.5
  done
  sleep "$attente"
  # le sous-shell ( … ) a pour enfant bash amorce.sh, qui a pour enfant timeout
  pid_bash=$(ps -o pid= --ppid "$pid_amorce" | head -1 | tr -d ' ')
  pid_timeout=$(ps -o pid= --ppid "$pid_bash" | head -1 | tr -d ' ')
  echo "TERM au timeout de l'amorce : PID $pid_timeout ($(ps -o comm= -p "$pid_timeout"))" | tee -a "$d/essai.log"
  date -u +%FT%TZ >> "$d/essai.log"
  kill -TERM "$pid_timeout"
fi
wait "$pid_amorce"
echo "--- amorce.log"; cat "$d/amorce.log"
echo "--- branche distante"
git -C "$d/distant.git" log --oneline "calcul/essai-$nom" 2>&1 | head -10
git -C "$d/distant.git" ls-tree -r --name-only "calcul/essai-$nom" -- runs diag traces 2>/dev/null | grep -E "(arret|resume|comparaison|traces/)" | head -40
