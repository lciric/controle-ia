# Essais locaux de la chaîne amorce → script d'instance (T0.4), au commit 92e2f995e581cb82ad801daff3f12ce19b28dc9b

Le 2026-10-04, sur le processeur de la session (sans carte graphique ni modèle réel), en mode jouet, contre une copie nue
du dépôt (`git clone --bare`). Jetons factices ; aucun accès réseau.

Les scripts sont ceux du commit, sans modification, sauf l'essai `delai-run` : il utilise un commit d'essai qui réduit
le délai externe de chaque run à 5 secondes (`commit-essai-delai.diff`).

`essai.sh` lance l'amorce. Avec un motif, il attend que le journal de l'instance le contienne, puis il attend N secondes. Il envoie
alors TERM au processus `timeout` de l'amorce. Ce processus est trouvé comme petit-enfant du sous-processus de l'essai,
et le signal passe par son identifiant de processus (R10). Le gestionnaire de `timeout` est le même qu'à l'expiration
du plafond de 345 minutes. Seul le déclencheur diffère : un signal externe au lieu de l'alarme.

| essai | déclencheur | attendu | observé |
|---|---|---|---|
| `sain` | aucun | 176 tests, runs A et B, comparaison identique, traces scellées et poussées, code 0 | conforme |
| `plafond-tests` | TERM 20 s après l'import de torch (pendant les tests) | arrêt consigné « tests (plafond de l'amorce) », traces de l'instance et de l'amorce poussées, code 124 | conforme |
| `plafond-runA` | TERM 4 s après le début du run A | TERM transmis au run par son identifiant de processus, `arret.json` scellé (« signal TERM reçu »), résultats partiels, traces et poussée, code 124 | conforme |
| `plafond-runB` | TERM 4 s après le début du run B | run A poussé dès sa fin ; run B arrêté et consigné comme ci-dessus, code 124 | conforme |
| `delai-run` | délai externe du run réduit à 5 s | `arret.json` du run A, arrêt consigné et poussé, l'amorce rend 1 sans repli | conforme |

Après les essais, aucun processus `python` ni `timeout` ne restait (`ps`).
Non essayés :
- le KILL de l'amorce (code 137), cinq minutes après un TERM resté sans effet ;
- le comportement des conteneurs de location à la sortie de l'amorce.
