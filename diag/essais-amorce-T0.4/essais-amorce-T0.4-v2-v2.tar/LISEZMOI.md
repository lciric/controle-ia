# Essais locaux de la chaîne amorce → script d'instance (T0.4, version 2), au commit dc7aa7fcd6b5b0c676ec7365d2a194a3c1924efc

Le 2026-10-05, de 13:39 à 13:48 UTC, sur le processeur de la session, sans carte graphique ni modèle réel. Mode jouet ;
dépôt nu local (`git clone --bare` d'un clone `--no-hardlinks` du dépôt) ; jetons factices ; aucun accès réseau.

Le script `essais_amorce_v2b.sh` est celui des essais de la v1 (`diag/essais-amorce-T0.4/essais-amorce-T0.4-cl4-v1.tar`,
lui-même repris de la contre-lecture 4), avec quatre changements :
- commit essayé : `dc7aa7f` (code cité par le préenregistrement v2, après la contre-lecture 1 ; scripts identiques à ceux de `47d3c61`) ;
- dossier des essais : `essais/` ;
- branche par défaut attendue : `calcul/t04-validation-v2` (nouveau défaut du script d'instance) ;
- branche de relancement : `calcul/t04-validation-v2-relance`.
Le scénario `tests-ko-corrige` de la v1 est sans objet et n'est pas lancé. Trois groupes en parallèle :
`groupe1.txt`, `groupe2.txt`, `groupe3.txt`.

Les amorces et scripts d'instance sont ceux du commit, sans modification, avec les mêmes exceptions que dans la v1 :
- `kill-137` : délai de KILL de 4 s au lieu de 5 min, et dépôt distant qui met 15 s à accepter une poussée ;
- `plafond-entre-runs` et `plafond-apres-runB` : poussées ralenties de 5 s (crochet du dépôt nu) ;
- `tests-ko` : commit d'essai qui ajoute un test en échec ;
- `mise-en-place-ko` et `plafond-mise-en-place` : environnement Python d'essai, en échec ou lent.

Le TERM « de plafond » est envoyé au processus `timeout` de l'amorce, trouvé par son identifiant de processus (R10).
C'est le même gestionnaire qu'à l'expiration des 345 minutes.

| essai | attendu | observé |
|---|---|---|
| `sain` | 192 tests, A et B, contrôle positif conforme, comparaison identique, traces scellées et poussées, code 0 | conforme |
| `tests-ko` | « tests en échec : arrêt », arrêt consigné, traces (sorties des tests) scellées et poussées, code 1 | conforme |
| `mise-en-place-ko` | filet de sortie : « ARRÊT pendant mise en place (sortie imprévue, code 3) », traces poussées, code 3 | conforme |
| `plafond-mise-en-place` | TERM pendant la mise en place : arrêt consigné ; deux dossiers de traces nés dans la même seconde (`t04-20261005-133948-F7DR`, `t04-plafond-20261005-133948-HJmo`), noms distincts, tous deux conformes ; code 124 | conforme |
| `plafond-runB` | TERM pendant B : `arret.json` de B (motif « délai externe du run ou plafond de l'amorce »), A déjà poussé, code 124 | conforme |
| `plafond-entre-runs` | TERM pendant la poussée de A : « ARRÊT pendant entre les runs (A complet) », code 124 | conforme |
| `plafond-apres-runB` | TERM pendant la poussée finale : « ARRÊT pendant fin (A et B complets) », code 124 | conforme |
| `kill-137` | TERM pendant A, poussée bloquée, KILL : arrêt de A consigné, traces de l'amorce poussées, code 137 | conforme |
| `relance` (a à d) | (a) branche par défaut `calcul/t04-validation-v2`, plafond pendant les tests, 124 ; (b) même instance : refus, 1 ; (c) instance neuve sans BRANCHE : poussée refusée ; (d) instance neuve, `BRANCHE=calcul/t04-validation-v2-relance` : A et B complets, poussés, 0 | conforme |

Dans chaque essai, les fichiers d'empreintes des traces sont vérifiés (`sha256sum -c`), et aucun processus ne reste.

Les essais préalables au commit `6556b4e` (mode `sonde` avec une fausse carte, mode jouet) sont dans l'archive
précédente, `essais-amorce-T0.4-v2-v1.tar` (commit `47d3c61`).

Non essayé : le comportement des conteneurs de location à la sortie de l'amorce (vu sur les instances réelles :
le conteneur relance l'amorce, qui refuse de tourner deux fois ; seule la session de pilotage arrête l'instance).
