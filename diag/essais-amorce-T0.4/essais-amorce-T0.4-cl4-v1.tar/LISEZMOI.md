# Essais locaux de la chaîne amorce → script d'instance (T0.4), au commit 3a7b5e0523864f386c7ef528b663dbae83e046dd

Le 2026-10-04, de 15:54 à 16:00 UTC, sur le processeur de la session, sans carte graphique ni modèle réel. Mode jouet ;
dépôt nu local (`git clone --bare` d'un clone `--no-hardlinks` du dépôt) ; jetons factices ; aucun accès réseau.

Le script `essais_amorce.sh` reprend le script s06 de la contre-lecture 4
(`prereg/contre-lectures/T0.4-contre-lecture-4-verifications-v1.tar`), au commit 3a7b5e0. Seul le scénario devenu
sans objet après la correction de Q-1 (`tests-ko-corrige`) n'a pas été lancé. Trois groupes en parallèle :
`groupe1.txt`, `groupe2.txt`, `groupe3.txt`.

Les amorces et scripts d'instance sont ceux du commit, sans modification, avec quatre exceptions :
- `kill-137` : délai de KILL de 4 s au lieu de 5 min, et dépôt distant qui met 15 s à accepter une poussée ;
- `plafond-entre-runs` et `plafond-apres-runB` : poussées ralenties de 5 s (crochet du dépôt nu) ;
- `tests-ko` : commit d'essai qui ajoute un test en échec ;
- `mise-en-place-ko` et `plafond-mise-en-place` : environnement Python d'essai, en échec ou lent.

Le TERM « de plafond » est envoyé au processus `timeout` de l'amorce, trouvé par son identifiant de processus (R10).
C'est le même gestionnaire qu'à l'expiration des 345 minutes.

| essai | attendu | observé |
|---|---|---|
| `sain` | 178 tests, A et B, comparaison identique, traces scellées et poussées, code 0 | conforme |
| `tests-ko` | « tests en échec : arrêt », arrêt consigné, traces (sorties des tests) scellées et poussées, code 1 (Q-1) | conforme |
| `mise-en-place-ko` | filet de sortie : « ARRÊT pendant mise en place (sortie imprévue, code 3) », traces poussées, code 3 (Q-4) | conforme |
| `plafond-mise-en-place` | TERM pendant la mise en place : arrêt consigné ; deux dossiers de traces nés dans la même seconde, noms distincts, tous deux conformes (Q-6) ; code 124 | conforme |
| `plafond-runB` | TERM pendant B : `arret.json` de B (motif « délai externe du run ou plafond de l'amorce »), A déjà poussé, code 124 | conforme |
| `plafond-entre-runs` | TERM pendant la poussée de A : « ARRÊT pendant entre les runs (A complet) », code 124 (Q-3) | conforme |
| `plafond-apres-runB` | TERM pendant la poussée finale : « ARRÊT pendant fin (A et B complets) », code 124 (Q-3) | conforme |
| `kill-137` | TERM pendant A, poussée bloquée, KILL : arrêt de A consigné, traces de l'amorce poussées, code 137 | conforme |
| `relance` (a à d) | (a) plafond pendant les tests, 124 ; (b) même instance : refus, 1 ; (c) instance neuve sans BRANCHE : poussée refusée ; (d) instance neuve, `BRANCHE=calcul/t04-validation-relance` : A et B complets, poussés, 0 | conforme |

Dans chaque essai, les fichiers d'empreintes des traces sont vérifiés (`sha256sum -c`), et aucun processus ne reste.
Non essayé : le comportement des conteneurs de location à la sortie de l'amorce.
