#!/usr/bin/env bash
# s06 (M-7, M-9) : essais de la chaîne amorce → script d'instance au commit 2457743 (version 3, repère au noyau de production), mode jouet, contre un dépôt nu local,
# jetons factices, sans réseau. Usage : bash s06_essais_amorce.sh <espace> [scénario…]
# <espace> contient copie-head/ (clone du dépôt, lecture seule). Les essais vont dans <espace>/essais-s06/<scénario>/.
# Le TERM « de plafond » est envoyé au processus `timeout` de l'amorce, trouvé comme petit-enfant du sous-shell de l'essai et
# vérifié par son nom, par identifiant de processus (R10). Même gestionnaire que l'alarme des 345 minutes.
# Sorties de la contre-lecture 4 : sorties/s06_essais_amorce.txt (huit premiers scénarios), s06_essais_amorce_tests_ko.txt,
# s06_essais_amorce_tests_ko_corrige.txt, et sorties/s06_journaux/ (journaux et contenu des branches poussées).
set -uo pipefail
ESP=$1; shift
COMMIT=2457743bbb92a492a9a3a97a92bee81921b4e43a
SRC=$ESP/copie-head
VENV=/home/user/controle-ia/.venv
E=$ESP/essais
mkdir -p "$E"
export PYTHONDONTWRITEBYTECODE=1

preparer() {   # preparer <nom> [dépôt distant existant]
    d=$E/$1
    [ -e "$d" ] && { echo "$d existe (R12)"; return 2; }
    mkdir -p "$d/racine"
    if [ -n "${2:-}" ]; then distant=$2; else distant=$d/distant.git; git clone -q --bare "$SRC" "$distant"; fi
    git -C "$SRC" show "$COMMIT":scripts/amorce_instance_t04.sh > "$d/amorce.sh"
}

lancer_amorce() {   # lancer_amorce <racine> <venv> <branche ou vide> : en arrière-plan, PID du sous-shell dans pid_amorce
    local racine=$1 venv=$2 branche=$3
    (
        cd "$racine" &&
        env -u CONTROLE_IA_GITHUB_TOKEN -u VAST_API_KEY -u BRANCHE COMMIT="$COMMIT" GH_TOKEN=jeton-factice HF_TOKEN=jeton-factice \
            DEPOT_URL="$distant" RACINE_AMORCE="$racine" MODE=jouet VENV_EXISTANT="$venv" ${branche:+BRANCHE="$branche"} \
            bash "$d/amorce.sh" >> "$d/amorce.log" 2>&1
        echo "code amorce : $?" >> "$d/amorce.log"
    ) &
    pid_amorce=$!
}

attendre_motif() {   # attendre_motif <fichier> <motif> : jusqu'à 300 s
    for _ in $(seq 1 600); do grep -q -- "$2" "$1" 2>/dev/null && return 0; sleep 0.5; done
    echo "motif « $2 » non vu" | tee -a "$d/essai.log"; return 1
}

attendre_fichier() {   # attendre_fichier <fichier> : jusqu'à 300 s
    for _ in $(seq 1 600); do [ -e "$1" ] && return 0; sleep 0.5; done
    echo "fichier $1 non vu" | tee -a "$d/essai.log"; return 1
}

term_au_timeout() {   # TERM au `timeout` de l'amorce, par identifiant de processus
    local pid_bash pid_timeout
    pid_bash=$(ps -o pid= --ppid "$pid_amorce" | head -1 | tr -d ' ')
    pid_timeout=$(ps -o pid= --ppid "$pid_bash" | head -1 | tr -d ' ')
    if [ "$(ps -o comm= -p "$pid_timeout")" != timeout ]; then
        echo "processus $pid_timeout n'est pas timeout ($(ps -o comm= -p "$pid_timeout")) : pas de signal" | tee -a "$d/essai.log"
        return 1
    fi
    echo "$(date -u +%T.%N | cut -c1-12) TERM au timeout de l'amorce, PID $pid_timeout" | tee -a "$d/essai.log"
    kill -TERM "$pid_timeout"
}

bilan() {   # bilan <branche distante>
    wait "$pid_amorce"
    echo "--- amorce.log (début et fin)"; head -3 "$d/amorce.log"; echo "…"; grep -E "AMORCE|code amorce|ARRÊT|TERM|poussée|run [AB]|tests|refus|existe" "$d/amorce.log" | tail -25
    echo "--- branches distantes"; git -C "$distant" branch --list 'calcul/*' -v | cut -c1-140
    if [ -n "${1:-}" ]; then
        echo "--- $1 : fichiers de résultats et de traces"
        git -C "$distant" ls-tree -r --name-only "$1" -- runs diag traces 2>/dev/null \
            | grep -E "(arret|resume\.json$|comparaison|traces/)" | grep -v -E "^(runs|diag)/20261004-1[0-4]" | head -40
        echo "--- $1 : journaux de commit (5 derniers)"; git -C "$distant" log --format='%s' -5 "$1" | cut -c1-120
        for t in $(git -C "$distant" ls-tree -d --name-only "$1" traces/ 2>/dev/null); do
            echo "--- $t/empreintes.sha256 vérifié :"
            tmp=$(mktemp -d); git -C "$distant" archive "$1" "$t" | tar -x -C "$tmp"
            (cd "$tmp/$t" && sha256sum -c --quiet empreintes.sha256 && echo "    conforme") 2>&1 | head -5; rm -rf "$tmp"
        done
    fi
    echo "--- processus restants sous $d :"
    ps -eo pid,ppid,etimes,args | grep -F -- "$d" | grep -v -E "grep|s06_essais" || echo "    aucun"
}

scenario() {
    local nom=$1
    echo; echo "================ $nom ($(date -u +%T))"
    case "$nom" in
    sain)
        preparer sain || return
        lancer_amorce "$d/racine" "$VENV" calcul/essai-sain
        bilan calcul/essai-sain ;;
    plafond-mise-en-place)
        # environnement Python « lent » : son activation dure 30 s (marqueur posé au début)
        preparer "$nom" || return
        mkdir -p "$d/venv-lent/bin"
        printf '. %s/bin/activate\ntouch %s/marqueur-activation\nsleep 30\n' "$VENV" "$d" > "$d/venv-lent/bin/activate"
        lancer_amorce "$d/racine" "$d/venv-lent" calcul/essai-mep
        attendre_fichier "$d/marqueur-activation" && sleep 2 && term_au_timeout
        bilan calcul/essai-mep ;;
    mise-en-place-ko)
        # activation de l'environnement Python en échec (équivalent : pip ou import de torch en échec)
        preparer "$nom" || return
        mkdir -p "$d/venv-ko/bin"; printf 'echo "activation impossible" >&2\nreturn 3\n' > "$d/venv-ko/bin/activate"
        lancer_amorce "$d/racine" "$d/venv-ko" calcul/essai-mep-ko
        bilan calcul/essai-mep-ko ;;
    plafond-entre-runs)
        # poussées ralenties de 5 s (crochet pre-receive) : le TERM tombe pendant la poussée du run A
        preparer "$nom" || return
        printf '#!/bin/sh\nsleep 5\n' > "$distant/hooks/pre-receive"; chmod +x "$distant/hooks/pre-receive"
        lancer_amorce "$d/racine" "$VENV" calcul/essai-entre-runs
        attendre_motif "$d/racine/t04/journal.txt" "run A terminé" && term_au_timeout
        bilan calcul/essai-entre-runs ;;
    plafond-apres-runB)
        # poussées ralenties de 5 s : le TERM tombe pendant la poussée finale, les deux runs étant complets
        preparer "$nom" || return
        printf '#!/bin/sh\nsleep 5\n' > "$distant/hooks/pre-receive"; chmod +x "$distant/hooks/pre-receive"
        lancer_amorce "$d/racine" "$VENV" calcul/essai-apres-B
        attendre_motif "$d/racine/t04/journal.txt" "fin : A=" && sleep 1 && term_au_timeout
        bilan calcul/essai-apres-B ;;
    plafond-runB)
        preparer "$nom" || return
        lancer_amorce "$d/racine" "$VENV" calcul/essai-runB
        attendre_motif "$d/racine/t04/journal.txt" "run B (rejeu" && sleep 3 && term_au_timeout
        bilan calcul/essai-runB ;;
    kill-137)
        # amorce d'essai : KILL 4 s après le TERM (au lieu de 5 min) ; le dépôt distant met 15 s à accepter une poussée
        # (crochet pre-receive) : la poussée de sur_term dépasse le délai de KILL
        preparer "$nom" || return
        sed -i 's/--kill-after=5m 345m/--kill-after=4s 345m/' "$d/amorce.sh"; grep -c -- "--kill-after=4s" "$d/amorce.sh"
        printf '#!/bin/sh\nsleep 15\n' > "$distant/hooks/pre-receive"; chmod +x "$distant/hooks/pre-receive"
        lancer_amorce "$d/racine" "$VENV" calcul/essai-kill
        attendre_motif "$d/racine/t04/journal.txt" "run A :" && sleep 3 && term_au_timeout
        bilan calcul/essai-kill ;;
    relance)
        # (a) premier essai, branche par défaut, arrêté au plafond pendant les tests ; (b) instance déjà utilisée ;
        # (c) relancement sur instance neuve, même dépôt distant, sans BRANCHE : poussée refusée ;
        # (d) relancement sur instance neuve, BRANCHE=calcul/t04-validation-v3-relance : à son terme, poussée acceptée
        preparer relance-a || return
        local distant_commun=$distant
        lancer_amorce "$d/racine" "$VENV" ""
        attendre_motif "$d/racine/t04/journal.txt" "torch" && sleep 5 && term_au_timeout
        bilan calcul/t04-validation-v3
        echo "---- (b) même instance, seconde amorce"
        lancer_amorce "$d/racine" "$VENV" ""
        bilan ""
        echo "---- (c) instance neuve, sans BRANCHE"
        preparer relance-c "$distant_commun" || return
        lancer_amorce "$d/racine" "$VENV" ""
        attendre_motif "$d/racine/t04/journal.txt" "torch" && sleep 5 && term_au_timeout
        bilan calcul/t04-validation-v3
        echo "---- (d) instance neuve, BRANCHE=calcul/t04-validation-v3-relance"
        preparer relance-d "$distant_commun" || return
        lancer_amorce "$d/racine" "$VENV" calcul/t04-validation-v3-relance
        bilan calcul/t04-validation-v3-relance ;;
    tests-ko)
        # commit d'essai sur le dépôt nu local : 92e2f99 plus un test qui échoue ; l'amorce reste celle de 92e2f99
        preparer "$nom" || return
        git clone -q "$distant" "$d/travail-essai" && git -C "$d/travail-essai" checkout -q "$COMMIT" &&
        printf 'def test_echec_essai():\n    assert False, "échec volontaire (essai)"\n' > "$d/travail-essai/tests/test_echec_essai.py" &&
        git -C "$d/travail-essai" add tests/test_echec_essai.py &&
        git -C "$d/travail-essai" -c user.email=t@x.invalid -c user.name=t -c commit.gpgsign=false commit -qm "essai : test en échec" &&
        git -C "$d/travail-essai" push -q origin HEAD:refs/heads/essai-tests-ko
        local c2; c2=$(git -C "$d/travail-essai" rev-parse HEAD)
        COMMIT=$c2 lancer_amorce "$d/racine" "$VENV" calcul/essai-tests-ko
        bilan calcul/essai-tests-ko ;;
    tests-ko-corrige)
        # même essai, avec la ligne 103 du script d'instance corrigée (`tail -n 5` au lieu de `tail -5`) dans le commit d'essai
        preparer "$nom" || return
        git clone -q "$distant" "$d/travail-essai" && git -C "$d/travail-essai" checkout -q "$COMMIT" &&
        printf 'def test_echec_essai():\n    assert False, "échec volontaire (essai)"\n' > "$d/travail-essai/tests/test_echec_essai.py" &&
        sed -i 's/    tail -5 "\$TRAVAIL\/tests.txt" "\$TRAVAIL\/tests.err"/    tail -n 5 "$TRAVAIL\/tests.txt" "$TRAVAIL\/tests.err"/' \
            "$d/travail-essai/scripts/validation_t04_instance.sh" &&
        git -C "$d/travail-essai" diff --stat &&
        git -C "$d/travail-essai" add -A &&
        git -C "$d/travail-essai" -c user.email=t@x.invalid -c user.name=t -c commit.gpgsign=false commit -qm "essai : test en échec, tail -n 5" &&
        git -C "$d/travail-essai" push -q origin HEAD:refs/heads/essai-tests-ko-corrige
        git -C "$d/travail-essai" show HEAD -- scripts/validation_t04_instance.sh | grep -E "^[-+] " 
        local c3; c3=$(git -C "$d/travail-essai" rev-parse HEAD)
        COMMIT=$c3 lancer_amorce "$d/racine" "$VENV" calcul/essai-tests-ko-corrige
        bilan calcul/essai-tests-ko-corrige ;;
    *) echo "scénario inconnu : $nom" ;;
    esac
}

for s in "${@:-sain plafond-mise-en-place mise-en-place-ko plafond-entre-runs plafond-apres-runB plafond-runB kill-137 relance tests-ko tests-ko-corrige}"; do
    for x in $s; do scenario "$x"; done
done
