import shutil, subprocess, sys, pathlib
racine = pathlib.Path("/home/user/controle-ia")
base = pathlib.Path(sys.argv[1])
V = "src/controle_ia/harnais/validation_reelle.py"
E = "src/controle_ia/harnais/episode.py"
MUT = {
 "N01-garde-sur-le-maximum": (E, '''    return rapport["ecarts_q99" if rapport.get("statistique", "max") == "q99" else "ecarts"][cle]''',
                                 '''    return rapport["ecarts"][cle]'''),
 "N02-controle-negatif-sur-le-maximum": (E, '''            m = min(float("-inf") if v[stat] != v[stat] else v[stat] for v in zone.values())''',
                                            '''            m = min(float("-inf") if v["max"] != v["max"] else v["max"] for v in zone.values())'''),
 "N03-lecture-sur-le-maximum": (V, '''        x = bilan["ecart_q99_max"] if bilan.get("statistique", "max") == "q99" else bilan["ecart_max"]''',
                                   '''        x = bilan["ecart_max"]'''),
 "N04-chemin-non-joue": (V, '''        phase_stricte("chemin", "controle_positif_chemin", "controle-positif-chemin")\n''', ""),
 "N05-chemin-sans-D1": (V, '''                                          echeance=echeance, decalage_positions=cp["decalage_positions"])''',
                           '''                                          echeance=echeance, decalage_positions=cp["decalage_positions"] if nom == "logique" else 0)'''),
 "N06-comparaison-sans-chemin": (V, '''PHASES_COMPAREES = ("logique", "chemin", "production")''', '''PHASES_COMPAREES = ("logique", "production")'''),
 "N07-q99-non-exige": (V, '''    if prod_["statistique"] != "q99":''', '''    if False:'''),
 "N08-statistique-non-transmise": (V, '''decalage_positions=decalage_positions, statistique=c.get("statistique", "max"))''',
                                     '''decalage_positions=decalage_positions)'''),
 "N09-chemin-en-double": (V, '''    if config["chemin"]["dtype"] != "float32" or config["chemin"]["statistique"] != "max":''',
                              '''    if config["chemin"]["statistique"] != "max":'''),
 "N10-noyau-libre": (V, '''    if prod_["noyau_attention"] != chem["noyau_attention"] or (config["modele"] != "jouet"
                                                              and prod_["noyau_attention"] == "defaut"):''',
                         '''    if False:'''),
}
TESTS = ["tests/test_validation_reelle.py", "tests/test_harnais_lots.py", "tests/test_harnais.py"]
for nom, (f, old, new) in MUT.items():
    d = base / nom
    shutil.copytree(racine / "src", d / "src"); shutil.copytree(racine / "tests", d / "tests")
    for x in ("pyproject.toml", "pytest.ini", "setup.cfg"):
        if (racine / x).exists(): shutil.copy(racine / x, d / x)
    t = (d / f).read_text(encoding="utf-8"); assert t.count(old) == 1, nom
    (d / f).write_text(t.replace(old, new), encoding="utf-8")
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "-x", *TESTS], cwd=d,
                       env={"PYTHONPATH": str(d / "src"), "PATH": "/usr/bin:/bin"}, capture_output=True, text=True)
    der = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-200:]
    echec = [l for l in r.stdout.splitlines() if l.startswith("FAILED")][:1]
    print(f"{nom}: {'VUE' if r.returncode else 'NON VUE'} — {der} {echec}", flush=True)
    shutil.rmtree(d)
