# Mutations de l'auteur — T0.4, version 3

Mutations ciblées du code de la version 3, faites par l'auteur (pas par un contre-lecteur), pour vérifier que la suite
de tests voit chaque changement de la v3. Chaque mutation remplace une seule chaîne du code, dans une copie de `src/` et
de `tests/` ; la suite des trois fichiers de tests du harnais (`test_validation_reelle.py`, `test_harnais_lots.py`,
`test_harnais.py`) est lancée avec arrêt au premier échec. « VUE » : au moins un test échoue.

- `62c74c6/` : dix mutations (N01 à N10) au code `62c74c6`, le 2026-10-06 vers 09:03-09:11 UTC ; toutes vues.
- `2457743/` : les mêmes dix, plus N11 (repère de précision calculé hors du noyau de production), au code cité par
  le préenregistrement v3, `2457743`, le 2026-10-06 vers 09:36-09:50 UTC ; toutes vues.

| mutation | ce qu'elle casse | test qui la voit |
|---|---|---|
| N01 | la garde de production lit le maximum, pas le 99e centile | `test_statistique_q99_garde_et_controle_negatif` |
| N02 | le contrôle négatif lit le maximum, pas la grandeur de sa phase | `test_statistique_q99_garde_et_controle_negatif` |
| N03 | la lecture de la production lit le maximum | `test_lecture_de_la_production_sur_le_99e_centile` |
| N04 | la phase de chemin n'est pas jouée | `test_repetition_complete_puis_rejeu_entre_runs` |
| N05 | le contrôle positif du chemin n'injecte pas D1 | `test_repetition_complete_puis_rejeu_entre_runs` |
| N06 | la comparaison des runs ignore le chemin | `test_repetition_complete_puis_rejeu_entre_runs` |
| N07 | la configuration n'exige plus le 99e centile en production | `test_configuration_v3_refusee` |
| N08 | la statistique de la phase n'est pas transmise à la génération | `test_phase_chemin_de_bout_en_bout` |
| N09 | la configuration accepte un chemin hors simple précision | `test_configuration_v3_refusee` |
| N10 | la configuration laisse le noyau de production libre | `test_configuration_v3_refusee` |
| N11 | le repère tourne hors du noyau de production | `test_repere_au_noyau_de_production` |

Fichiers : `muter.py` (script, lancé depuis la racine du dépôt au commit nommé, avec un dossier de travail en argument)
et `sortie.txt` (sa sortie) dans chaque dossier.
