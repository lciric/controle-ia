# Mutations ciblées — T0.4, version 3, au code b6ab5d1 (après la contre-lecture 1)

Le 2026-10-06 vers 10:36-10:50 UTC. Chaque mutation remplace une seule chaîne du code, dans une copie de `src/` et de
`tests/` ; les quatre fichiers de tests du harnais (`test_validation_reelle.py`, `test_harnais_lots.py`,
`test_harnais.py`, `test_harnais_formats.py`) sont lancés avec arrêt au premier échec. « VUE » : au moins un test
échoue. Le témoin (aucune mutation) doit passer.

- N01 à N11 : mutations de l'auteur, reprises de `T0.4-v3-mutations-auteur-v1.tar` (codes `62c74c6` et `2457743`).
- CL-1 à CL-9 (et CL-1b) : mutations du contre-lecteur 1 (`prereg/contre-lectures/T0.4-v3-contre-lecture-1-verifications-v1.tar`,
  `verifications/12-mutations-contre-lecteur.py`), reprises ; CL-5 et CL-8 adaptées au code corrigé (même sens). Au code
  `2457743`, sept passaient la suite (CL-1b, CL-2, CL-3, CL-4, CL-5, CL-6, CL-8) ; CL-1 et CL-9 étaient vues par hasard.
- N12 à N14 : nouvelles, pour les corrections X-2 (contrôle négatif de la production sur la zone générée seule) et X-10
  (panne de mémoire du débit non consignée ; toute panne du débit consignée).

Résultat : témoin conforme (78 tests réussis) ; 24 mutations sur 24 vues. Fichiers : `b6ab5d1/muter.py` (lancé avec la
racine du dépôt au commit `b6ab5d1` et un dossier de travail) et `b6ab5d1/sortie.txt` (sa sortie).
