"""Mutations ciblées du code de la v3 de T0.4 après la contre-lecture 1 : celles de l'auteur (N01 à N11, reprises),
celles du contre-lecteur (CL-1 à CL-9, reprises et adaptées au code corrigé) et trois nouvelles (N12 à N14, pour les
corrections X-2 et X-10). Chaque mutation remplace une seule chaîne dans une copie de src/ et tests/ ; les quatre
fichiers de tests du harnais sont lancés avec arrêt au premier échec. « VUE » : au moins un test échoue.
Usage : python muter.py <racine du dépôt> <dossier de travail>"""
import shutil, subprocess, sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
racine, base = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
V = "src/controle_ia/harnais/validation_reelle.py"
E = "src/controle_ia/harnais/episode.py"
A = "src/controle_ia/harnais/activations.py"
MUT = {
 "T00-temoin-sans-mutation": (V, 'PHASES_COMPAREES = ("logique", "chemin", "production")', 'PHASES_COMPAREES = ("logique", "chemin", "production")'),
 # auteur (N01 à N11)
 "N01-garde-sur-le-maximum": (E, '''    return rapport["ecarts_q99" if rapport.get("statistique", "max") == "q99" else "ecarts"][cle]''', '''    return rapport["ecarts"][cle]'''),
 "N02-controle-negatif-sur-le-maximum": (E, '''            m = min(float("-inf") if v[stat] != v[stat] else v[stat] for v in zone.values())''', '''            m = min(float("-inf") if v["max"] != v["max"] else v["max"] for v in zone.values())'''),
 "N03-lecture-sur-le-maximum": (V, '''        x = bilan["ecart_q99_max"] if bilan.get("statistique", "max") == "q99" else bilan["ecart_max"]''', '''        x = bilan["ecart_max"]'''),
 "N04-chemin-non-joue": (V, '''        phase_stricte("chemin", "controle_positif_chemin", "controle-positif-chemin")\n''', ""),
 "N05-chemin-sans-D1": (V, '''                                          echeance=echeance, decalage_positions=cp["decalage_positions"])''', '''                                          echeance=echeance, decalage_positions=cp["decalage_positions"] if nom == "logique" else 0)'''),
 "N06-comparaison-sans-chemin": (V, '''PHASES_COMPAREES = ("logique", "chemin", "production")''', '''PHASES_COMPAREES = ("logique", "production")'''),
 "N07-q99-non-exige": (V, '''    if prod_["statistique"] != "q99":''', '''    if False:'''),
 "N08-statistique-non-transmise": (V, '''decalage_positions=decalage_positions, statistique=c.get("statistique", "max"))''', '''decalage_positions=decalage_positions)'''),
 "N09-chemin-en-double": (V, '''    if config["chemin"]["dtype"] != "float32" or config["chemin"]["statistique"] != "max":''', '''    if config["chemin"]["statistique"] != "max":'''),
 "N10-noyau-libre": (V, '''    if prod_["noyau_attention"] != chem["noyau_attention"] or (config["modele"] != "jouet"
                                                              and prod_["noyau_attention"] == "defaut"):''', '''    if False:'''),
 "N11-repere-hors-du-noyau": (V, '''        with noyau(prod["noyau_attention"]):          # repère au noyau de production, comme ce qu'il situe (version 3)
            repere = repere_precision(modele, references, couches)''', '''        repere = repere_precision(modele, references, couches)'''),
 # contre-lecteur (CL-1 à CL-9), adaptées
 "CL-1-quantile-095-dans-la-garde": (E, 'rapport["ecarts_q99"][cle] = ecart_equivalence(ag, acts[i], quantile=0.99)', 'rapport["ecarts_q99"][cle] = ecart_equivalence(ag, acts[i], quantile=0.95)'),
 "CL-1b-quantile-098-dans-la-garde": (E, 'rapport["ecarts_q99"][cle] = ecart_equivalence(ag, acts[i], quantile=0.99)', 'rapport["ecarts_q99"][cle] = ecart_equivalence(ag, acts[i], quantile=0.98)'),
 "CL-2-ecart_q99_max-calcule-sur-le-maximum": (V, '"ecart_q99_max": _maximum(ecarts_q99),', '"ecart_q99_max": _maximum(ecarts),'),
 "CL-3-couverture-du-chemin-non-lue": (V, 'elif phase in ("logique", "chemin") and not (', 'elif phase in ("logique",) and not ('),
 "CL-4-audit-P9-sans-le-chemin": (V, '    declenche = []\n    for phase in PHASES_COMPAREES:', '    declenche = []\n    for phase in ("logique", "production"):'),
 "CL-5-controle-negatif-q99-a-la-mediane": (A, '"q99": float(np.quantile(e_action, 0.99)),', '"q99": float(np.quantile(e_action, 0.5)),'),
 "CL-6-gardes-du-chemin-avant-son-controle-positif": (V, '        phase = nom_pc\n        temps()\n        c_pc = dict(c, T=cp["T"])', '        if nom == "chemin":\n            appliquer_gardes(sorties, resume[nom]["equivalence"], nom, cn)\n        phase = nom_pc\n        temps()\n        c_pc = dict(c, T=cp["T"])'),
 "CL-7-controle-positif-du-chemin-au-seuil-de-logique": (V, '"bilan": bilan_controle_positif(sorties_pc, c_pc, cp),', '"bilan": bilan_controle_positif(sorties_pc, dict(c_pc, tolerance=config["logique"]["tolerance"]), cp),'),
 "CL-8-debit-hors-du-noyau-de-production": (V, '                with noyau(prod["noyau_attention"]):                 # noyau de production (version 3)', '                with contextlib.nullcontext():                 # noyau de production (version 3)'),
 "CL-9-chemin-lu-sur-le-99e-centile": (V, 'x = bilan["ecart_q99_max"] if bilan.get("statistique", "max") == "q99" else bilan["ecart_max"]', 'x = bilan["ecart_q99_max"] if phase != "logique" else bilan["ecart_max"]'),
 # nouvelles (corrections X-2 et X-10)
 "N12-controle-negatif-q99-sur-la-zone-seule": (A, '"q99": float(np.quantile(e_action, 0.99)),', '"q99": float(np.quantile(e, 0.99)),'),
 "N13-panne-de-memoire-du-debit-non-consignee": (V, '            except torch.cuda.OutOfMemoryError as e:', '            except ZeroDivisionError as e:'),
 "N14-toute-panne-du-debit-consignee": (V, '            except torch.cuda.OutOfMemoryError as e:', '            except Exception as e:'),
}
TESTS = ["tests/test_validation_reelle.py", "tests/test_harnais_lots.py", "tests/test_harnais.py", "tests/test_harnais_formats.py"]
for nom, (f, old, new) in MUT.items():                        # toutes les chaînes doivent exister une fois
    assert (racine / f).read_text(encoding="utf-8").count(old) == 1, nom
def un(nom):
    f, old, new = MUT[nom]
    d = base / nom
    shutil.copytree(racine / "src", d / "src", ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copytree(racine / "tests", d / "tests", ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy(racine / "pyproject.toml", d / "pyproject.toml")
    t = (d / f).read_text(encoding="utf-8")
    (d / f).write_text(t.replace(old, new), encoding="utf-8")
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "-x", *TESTS], cwd=d,
                       env={"PYTHONPATH": str(d / "src"), "PATH": "/usr/bin:/bin"}, capture_output=True, text=True)
    der = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-200:]
    echec = [l for l in r.stdout.splitlines() if l.startswith("FAILED")][:1]
    shutil.rmtree(d)
    return f"{nom}: {'VUE' if r.returncode else 'NON VUE'} — {der} {echec}"
with ThreadPoolExecutor(max_workers=4) as ex:
    for ligne in ex.map(un, list(MUT)):
        print(ligne, flush=True)
