"""Contre-lecture T0.3 — v01 : formes closes du brouillon (aucune simulation, aucune graine).
Recalcule indépendamment (scipy) puis compare au code (calibrage.py)."""
import math, sys
import numpy as np
from scipy import stats, optimize
sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.simulation_t03 import calibrage as cal
from controle_ia.simulation_t03.lois import facteur_variance_ar1

a = 0.05
za = stats.norm.isf(a)
print("== P1.2 / P1.3 : Phibar(z_a - B/sqrt(n0)) ==")
for n0 in (50, 100, 200, 500, 1000):
    row = [stats.norm.sf(za - B / math.sqrt(n0)) for B in (10, 20, 30)]
    row_code = [cal.puissance_somme(a, n0, B) for B in (10, 20, 30)]
    assert np.allclose(row, row_code, rtol=1e-12)
    print(n0, " ".join(f"{p:.4f}" for p in row))

print("\n== P2.1 : c_200 et puissance du max ==")
n = 200
c = stats.norm.ppf((1 - a) ** (1 / n))
print("c_200 (ppf direct) =", f"{c:.6f}", " code :", f"{cal.seuil_max_exact(a, n):.6f}")
for m in (1, 2, 5, 10, 20, 50, 100, 200):
    row = []
    for B in (10, 20, 30):
        p = 1 - stats.norm.cdf(c) ** (n - m) * stats.norm.cdf(c - B / m) ** m
        pc = cal.puissance_max(a, n, B, m)
        assert abs(p - pc) < 1e-12, (m, B, p, pc)
        row.append(pc)
    print(f"m={m:3d}", " ".join(f"{p:.4f} (1-p={1-p:.2e})" for p in row))
# décroissance en m (grille fine) et plancher
for B in (10, 20, 30):
    ps = [cal.puissance_max(a, n, B, m) for m in range(1, n + 1)]
    print(f"B={B}: décroissance stricte sur m=1..200 : {all(x > y for x, y in zip(ps, ps[1:]))} ; plancher m=200 : {ps[-1]:.5f} ; "
          f"approx note a+(1-a)phi(c)B : {a + (1-a)*stats.norm.pdf(c)*B:.5f}")

print("\n== P3 : rho*, s*, P3.3 ==")
rho, s = cal.rho_optimal(200, a, "unilateral")
print(f"rho* = {rho:.6f}, s* = {s:.4f}")
# vérif indépendante : minimisation sur grille fine
def front(r):
    h = math.log(1 / a)
    f = lambda S: (math.log(2) - 0.5 * math.log(1 + r*r*200) + r*r*S*S/(2*(1 + r*r*200))
                   + stats.norm.logcdf(r*S/math.sqrt(1 + r*r*200))) - h
    return optimize.brentq(f, 0, 1e4, xtol=1e-12)
grid = np.linspace(0.15, 0.22, 7001)
fr = np.array([front(r) for r in grid])
print(f"grille : rho* ≈ {grid[fr.argmin()]:.5f}, s* ≈ {fr.min():.4f}")
for B in (15, 25, 35):
    print(f"B={B}: P(E+_200 >= 20) = {stats.norm.sf((s - B)/math.sqrt(200)):.4f} ; code {cal.borne_terminale(a, 200, B, rho):.4f}")
rb, sb = cal.rho_optimal(200, a, "bilateral")
print(f"bilatéral : rho* = {rb:.6f}, s* = {sb:.4f}")

print("\n== facteur de variance AR(1) : formule close vs somme directe ==")
for phi in (-0.5, -0.25, 0.2, 0.25, 0.5, 0.59, 0.725, 0.9):
    for nn in (200, 300):
        h = np.arange(1, nn)
        direct = 1 + 2 * np.sum((1 - h / nn) * phi ** h)
        assert math.isclose(direct, facteur_variance_ar1(phi, nn), rel_tol=1e-12)
print("formule = somme directe (rel 1e-12) pour 8 valeurs de phi, n = 200 et 300")

print("\n== P6.3 / P6.4 / P6.5 ==")
for phi in (-0.5, -0.25, 0.25, 0.5):
    print(f"phi={phi:+.2f}: v={facteur_variance_ar1(phi,200):.5f}  somme = {cal.rejet_somme_sous_variance(a, facteur_variance_ar1(phi, 200)):.5f}")
for cc in (0.2, 0.4):
    print(f"c={cc}: somme = {cal.rejet_somme_sous_variance(a, 1 + 4*cc):.4f}")
v0 = facteur_variance_ar1(0.5, 300)
for p1 in (0.59, 0.725, 0.9):
    r = facteur_variance_ar1(p1, 300) / v0
    print(f"phi1={p1}: v1/v0={r:.5f}  somme = {cal.rejet_somme_sous_variance(a, r):.5f}  (écart-type relatif {math.sqrt(r):.3f})")

print("\n== P8.4 ==")
print("rang conforme K=1000 :", cal.rang_conforme(1000, a), " taux :", f"{cal.taux_conforme(1000, a):.5f}")
