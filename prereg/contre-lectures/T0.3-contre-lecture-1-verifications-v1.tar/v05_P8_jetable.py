"""Contre-lecture T0.3 — v05 : marges de P8.2 / P8.3 sur tailles JETABLES (T = 190, 210 ; N = 1).
Taux de fausses alarmes de Ville (e unilatéral, ρ* de l'horizon). Graine SeedSequence(141421), R = 60 000."""
import math, sys
import numpy as np
sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.simulation_t03 import lots as L, calibrage as cal
from controle_ia.simulation_t03.lois import tirer

alpha = 0.05
h = math.log(20)
ss = np.random.SeedSequence(141421)
gr = iter(ss.spawn(64))
R = 60_000
borne_P83 = alpha + 4 * math.sqrt(alpha * (1 - alpha) / 20000)
print(f"P8.3 conforme si p̂ > {borne_P83:.4f} (R = 20 000) ; contraire si p̂ < {alpha - 4*math.sqrt(alpha*(1-alpha)/20000):.4f}")
for T in (190, 210):
    rho = cal.rho_optimal(T, alpha, "unilateral")[0]
    for nom, loi, su in (("gauss", {"type": "iid", "marginale": "gauss", "N": 1, "T": T}, 1.0),
                         ("sigma0.8", {"type": "iid", "marginale": "gauss", "N": 1, "T": T}, 0.8),
                         ("sigma0.9", {"type": "iid", "marginale": "gauss", "N": 1, "T": T}, 0.9),
                         ("ar0.2", {"type": "ar1", "phi": 0.2, "marginale": "gauss", "N": 1, "T": T}, 1.0),
                         ("tau0.05", {"type": "effet_episode", "tau": 0.05, "N": 1, "T": T}, 1.0)):
        g = np.random.default_rng(next(gr))
        k = 0
        for _ in range(R // 20_000):
            X = tirer(g, 20_000, loi) / su
            k += int((L.serie_e(L.ordre(X), rho, "unilateral").max(axis=1) >= h).sum())
        p = k / R
        print(f"T={T} {nom:9s}: taux Ville {p:.4f} ± {math.sqrt(p*(1-p)/R):.4f}")
