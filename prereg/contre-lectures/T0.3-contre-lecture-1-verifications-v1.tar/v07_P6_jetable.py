"""Contre-lecture T0.3 — v07 : parties heuristiques de P6 sur tailles JETABLES (1 x 190 ; 5 x 38).
e unilatéral (Ville) sous copule AR(1) et équicorrélation ; autocorrélation sous marginale Exp(1) − 1 ;
max sous copule (Slepian). Seuils MC sous P0 iid de même forme. Graine SeedSequence(577215), R = 20 000, R_cal = 40 000."""
import math, sys
import numpy as np
sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.simulation_t03 import lots as L, calibrage as cal
from controle_ia.simulation_t03.lois import tirer

alpha, h = 0.05, math.log(20)
ss = np.random.SeedSequence(577215)
gr = iter(ss.spawn(64))

def taux(loi, rho, seuils, R=20_000):
    g = np.random.default_rng(next(gr))
    X = tirer(g, R, loi)
    out = {"e_ville": (L.lot_e_max(X, rho, "unilateral") >= h).mean()}
    for k, f in (("max", L.lot_max), ("autocorr", L.lot_autocorr), ("autocorr_abs", lambda Z: L.lot_autocorr(Z, True))):
        if k in seuils:
            out[k] = (f(X) >= seuils[k]).mean()
    return out

for marg in ("gauss", "exp"):
    T = 190
    rho = cal.rho_optimal(T, alpha, "unilateral")[0]
    g = np.random.default_rng(next(gr))
    X0 = tirer(g, 40_000, {"type": "iid", "marginale": marg, "N": 1, "T": T})
    seuils = {"max": cal.seuil_mc(L.lot_max(X0), alpha), "autocorr": cal.seuil_mc(L.lot_autocorr(X0), alpha),
              "autocorr_abs": cal.seuil_mc(L.lot_autocorr(X0, True), alpha)}
    p0 = taux({"type": "iid", "marginale": marg, "N": 1, "T": T}, rho, seuils)
    print(f"{marg} 1x{T} P0 : " + ", ".join(f"{k}={v:.4f}" for k, v in p0.items()))
    for phi in (-0.5, -0.25, 0.25, 0.5):
        p = taux({"type": "ar1", "phi": phi, "marginale": marg, "N": 1, "T": T}, rho, seuils)
        print(f"   phi={phi:+.2f} : " + ", ".join(f"{k}={v:.4f}" for k, v in p.items()))
N, T = 5, 38
rho = cal.rho_optimal(N * T, alpha, "unilateral")[0]
g = np.random.default_rng(next(gr))
X0 = tirer(g, 40_000, {"type": "iid", "marginale": "gauss", "N": N, "T": T})
seuils = {"max": cal.seuil_mc(L.lot_max(X0), alpha)}
print(f"gauss 5x38 P0 : " + ", ".join(f"{k}={v:.4f}" for k, v in taux({"type": "iid", "marginale": "gauss", "N": N, "T": T}, rho, seuils).items()))
for c in (0.2, 0.4):
    print(f"   equi c={c} : " + ", ".join(f"{k}={v:.4f}" for k, v in taux({"type": "equicorrelation", "c": c, "N": N, "T": T}, rho, seuils).items()))
