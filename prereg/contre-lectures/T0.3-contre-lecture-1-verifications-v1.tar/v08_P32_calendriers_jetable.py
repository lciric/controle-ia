"""Contre-lecture T0.3 — v08 : ampleur de l'écart entre calendriers (début / uniforme / fin) pour le
processus e unilatéral de Ville, sur configuration JETABLE n0 = 180 (1 x 180 et 5 x 36), B rééchelonné
B·√(180/200) pour garder B/√n0 de la grille ; m ∈ {1, 10, 50}. Nombres aléatoires communs.
Graine SeedSequence(662607), R = 10 000. Écart-type apparié de la différence (même épisodes)."""
import math, sys
import numpy as np
sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.simulation_t03 import lots as L, calibrage as cal, attaques as att

alpha, h = 0.05, math.log(20)
ss = np.random.SeedSequence(662607)
gr = iter(ss.spawn(64))
n0 = 180
rho = cal.rho_optimal(n0, alpha, "unilateral")[0]
for N, T in ((1, 180), (5, 36)):
    for B0 in (15, 25, 35):
        B = B0 * math.sqrt(n0 / 200)
        g = np.random.default_rng(next(gr))
        R = 10_000
        y = L.ordre(g.standard_normal((R, N, T)))
        lignes = []
        for m in (1, 10, 50):
            al = {}
            for s in ("debut", "uniforme", "fin"):
                P = att.positions(s, m, N, T, R, g)
                x = att.appliquer_decalages(y, P, att.decalages("egaux", m, B, R, g))
                al[s] = L.serie_e(x, rho, "unilateral").max(axis=1) >= h
            d = al["debut"].astype(float) - al["fin"].astype(float)
            se_app = d.std(ddof=1) / math.sqrt(R)
            pd, pf = al["debut"].mean(), al["fin"].mean()
            se_ind = math.sqrt(pd*(1-pd)/R + pf*(1-pf)/R)
            lignes.append(f"m={m:2d}: début {pd:.3f} unif {al['uniforme'].mean():.3f} fin {pf:.3f} "
                          f"(z apparié {(pd-pf)/se_app:5.1f} ; z indépendant {(pd-pf)/se_ind:5.1f})")
        print(f"{N}x{T} B={B:.2f} (≡ {B0} à n0=200) :: " + " | ".join(lignes))
