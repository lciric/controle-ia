"""Contre-lecture T0.3 — v09 : P7.2 et P7.3 sur tailles JETABLES (T = 180, 220), arrangements dominés.
Graine SeedSequence(299792), R = 10 000 ; seuils MC de Page et glissante_10 sous P0 (R_cal = 40 000)."""
import math, sys
import numpy as np
sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.simulation_t03 import lots as L, calibrage as cal, attaques as att

alpha, h = 0.05, math.log(20)
ss = np.random.SeedSequence(299792)
gr = iter(ss.spawn(16))
for T in (180, 220):
    rb = cal.rho_optimal(T, alpha, "bilateral")[0]
    ru = cal.rho_optimal(T, alpha, "unilateral")[0]
    g = np.random.default_rng(next(gr))
    X0 = g.standard_normal((40_000, 1, T))
    sp, sg = cal.seuil_mc(L.lot_page(X0), alpha), cal.seuil_mc(L.lot_glissante(X0, 10), alpha)
    g = np.random.default_rng(next(gr))
    y = g.standard_normal((10_000, T))
    mY = L.serie_e(y, ru, "unilateral").max(axis=1)
    for nom, x in (("tri_croissant", att.tri_croissant(y)), ("top_10_fin", att.top_r_a_la_fin(y, 10)),
                   ("top_20_fin", att.top_r_a_la_fin(y, 20))):
        Xb = L.depuis_ordre(x, 1, T)
        eb = (L.lot_e_max(Xb, rb, "bilateral") >= h).mean()
        eu = L.lot_e_max(Xb, ru, "unilateral")
        dom = bool(np.all(np.cumsum(x, axis=1) <= np.cumsum(y, axis=1) + 1e-9 * T))
        incl = int(((eu >= h) & ~(mY >= h)).sum())
        print(f"T={T} {nom:13s}: e_bilat_ville {eb:.4f} ; e_unilat_ville {(eu >= h).mean():.4f} (honnête {(mY >= h).mean():.4f}, "
              f"violations d'inclusion {incl}) ; page {(L.lot_page(Xb) >= sp).mean():.4f} ; glissante_10 "
              f"{(L.lot_glissante(Xb, 10) >= sg).mean():.4f} ; sommes partielles dominées : {dom}")
