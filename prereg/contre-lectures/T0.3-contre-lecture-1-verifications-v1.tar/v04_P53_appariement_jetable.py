"""Contre-lecture T0.3 — v04 : appariement adaptatif de P5.3 sur tailles JETABLES (T = 150, 250).
Complétude (tolérances du brouillon), signe de l'écart résiduel, taux d'alarme de la statistique
globale après appariement contre P0 (seuil MC). 6 000 échanges comme la grille.
Graine SeedSequence(161803), R = 4 000 par cas, R_cal = R0 = 40 000."""
import math, sys, time
import numpy as np
sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.simulation_t03 import lots as L, calibrage as cal, attaques as att

alpha = 0.05
ss = np.random.SeedSequence(161803)
gr = iter(ss.spawn(32))
for T in (150, 250):
    g = np.random.default_rng(next(gr))
    cal_v = {"autocorr": [], "suites": []}
    p0_v = {"autocorr": [], "suites": []}
    for _ in range(4):
        Xb = g.standard_normal((10_000, 1, T))
        cal_v["autocorr"].append(L.lot_autocorr(Xb)); cal_v["suites"].append(L.lot_suites(Xb))
        Xb = g.standard_normal((10_000, 1, T))
        p0_v["autocorr"].append(L.lot_autocorr(Xb)); p0_v["suites"].append(L.lot_suites(Xb))
    seuils = {k: cal.seuil_mc(np.concatenate(v), alpha) for k, v in cal_v.items()}
    p0 = {k: float((np.concatenate(p0_v[k]) >= seuils[k]).mean()) for k in seuils}
    for cible, tol in (("autocorr", 0.005), ("suites", 2)):
        g = np.random.default_rng(next(gr))
        R = 4000
        y = g.standard_normal((R, T))
        x0, debut = att.bloc_top_r(y, 5, g)
        t0 = time.time()
        xa, ecart = att.apparier(x0, debut, 5, cible, g, 6000)
        dt = time.time() - t0
        Z = xa - xa.mean(axis=1, keepdims=True)
        if cible == "autocorr":
            rel = ecart / (Z * Z).sum(axis=1)
            hors = np.abs(rel) > tol
            desc = (f"écart relatif : médiane |·| {np.median(np.abs(rel)):.2e}, q99 {np.quantile(np.abs(rel), 0.99):.2e}, "
                    f"moyenne signée {rel.mean():+.2e}")
            stat0 = L.lot_autocorr(L.depuis_ordre(x0, 1, T))
            stat = L.lot_autocorr(L.depuis_ordre(xa, 1, T))
        else:
            hors = np.abs(ecart) > tol
            vals, cnt = np.unique(ecart, return_counts=True)
            desc = "écart (changements) : " + ", ".join(f"{int(v)}:{c}" for v, c in zip(vals, cnt) if c > R * 0.002)
            stat0 = L.lot_suites(L.depuis_ordre(x0, 1, T))
            stat = L.lot_suites(L.depuis_ordre(xa, 1, T))
        p_avant = (stat0 >= seuils[cible]).mean()
        p = (stat >= seuils[cible]).mean()
        se = math.sqrt(max(p*(1-p), 1/R)/R + p0[cible]*(1-p0[cible])/40000)
        print(f"T={T} {cible}: {dt:.1f} s ; hors tolérance {hors.mean():.4f} ; {desc}")
        print(f"   taux d'alarme : avant appariement {p_avant:.3f} ; après {p:.4f} ; P0 {p0[cible]:.4f} ; z = {(p-p0[cible])/se:+.2f}")
