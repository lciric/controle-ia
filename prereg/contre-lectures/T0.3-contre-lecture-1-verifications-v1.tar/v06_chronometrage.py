"""Contre-lecture T0.3 — v06 : chronométrage sur données jetables (T = 190 / 38 / 19 / 950, graine 99991),
pour estimer la durée d'un run et d'une réplication (5 × R) face à la garde des 6 heures. Aucun taux calculé."""
import math, sys, time
import numpy as np
sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.simulation_t03 import blocs as B, lots as L, attaques as att

g = np.random.default_rng(np.random.SeedSequence(99991))
grille_min = {"alpha": 0.05, "tailles": {}}
ctx = B.Contexte(grille_min, {}, "")
P1 = ["somme", "somme_bilat", "max", "glissante_5", "glissante_10", "balayage_multi", "page", "detecteur_e",
      "e_unilat", "e_bilat", "e_terminal", "autocorr", "autocorr_abs", "suites"]
PN = P1 + ["co_elevation_2", "co_elevation_3", "co_elevation_N", "correlation_agents"]

def chrono(N, T, stats, R=20_000):
    X = g.standard_normal((R, N, T))
    t = time.time(); B.calculer(X, stats, ctx); return time.time() - t

t1 = chrono(1, 190, P1); t5 = chrono(5, 38, PN); t10 = chrono(10, 19, PN)
print(f"panneau complet, 20 000 épisodes : 1x190 {t1:.1f} s ; 5x38 {t5:.1f} s ; 10x19 {t10:.1f} s")
print(f"=> calibrage (R_cal + R0 = 200 000) des 3 configurations riches ≈ {10*(t1+t5+t10)/60:.1f} min ; à 5 × R ≈ {50*(t1+t5+t10)/60:.1f} min")
tp = chrono(1, 950, ["somme", "max", "e_unilat", "page"])
print(f"1x950 (somme, max, e_unilat, page), 20 000 épisodes : {tp:.1f} s")
# P1a : coût d'une cellule (4 statistiques) sur 20 000 épisodes, n0 = 190
y = g.standard_normal((20_000, 190))
t = time.time()
P = att.positions("aleatoire", 10, 1, 190, 20_000, g)
X = L.depuis_ordre(att.appliquer_decalages(y, P, att.decalages("egaux", 10, 10.0, 20_000, g)), 1, 190)
B.calculer(X, ["somme", "e_terminal", "max", "e_unilat"], ctx)
tc = time.time() - t
import json
from controle_ia.simulation_t03.run_t03 import taches
n1a = sum(1 for x in taches(json.load(open("/home/user/controle-ia/prereg/T0.3-grille-v1.json"))) if x.startswith("P1a/") and not x.endswith("/Y"))
print(f"P1a : une cellule ≈ {tc:.2f} s ; {n1a} cellules (structure de la grille, taches()) ≈ {n1a*tc/60:.1f} min ; à 5 × R ≈ {5*n1a*tc/60:.1f} min")
