"""Contre-lecture T0.3 — v02 : P4.3, puissance du rebrassage total pour dispersion_agents.
(1) approximation du χ² non central invoquée par le brouillon (analytique) ;
(2) formule exacte : conditionnellement à la table de contingence n_ij (multi-hypergéométrique),
    la statistique est un χ²_3 non central de paramètre λ = T·Σ_i (μ̄_i − μ_i)² ; on moyenne
    ncx2.sf sur la loi EXACTE de la table (énumération vectorisée, aucune graine) ;
(3) validation par simulation directe UNIQUEMENT sur des tailles jetables T = 30 et T = 50
    (graine SeedSequence(31337), R = 200 000), jamais T = 40.
(4) puissance de la statistique de l'exploration (écart de moyennes rôles 3 − 1, queue basse), même méthode."""
import math
import numpy as np
from scipy import stats
from scipy.special import gammaln

mus = np.array([-0.5, 0.0, 0.5])
alpha = 0.05
seuil = stats.chi2.isf(alpha, 3)   # sous P0 la statistique est exactement χ²_3

def logC(n, k):
    return gammaln(n + 1) - gammaln(k + 1) - gammaln(n - k + 1)

def tables(T):
    """Toutes les tables 3x3 (lignes = agents d'arrivée, colonnes = agents d'origine), marges T,
    avec leur log-probabilité sous le rebrassage uniforme."""
    rows = []
    for a0 in range(T + 1):
        for a1 in range(T + 1 - a0):
            a2 = T - a0 - a1
            r0, r1, r2 = T - a0, T - a1, T - a2
            b0 = np.arange(0, min(r0, T) + 1)
            for b0v in b0:
                b1 = np.arange(0, min(r1, T - b0v) + 1)
                b2 = T - b0v - b1
                ok = (b2 >= 0) & (b2 <= r2)
                b1, b2 = b1[ok], b2[ok]
                n = b1.size
                rows.append(np.column_stack([np.full(n, a0), np.full(n, a1), np.full(n, a2),
                                             np.full(n, b0v), b1, b2]))
    A = np.concatenate(rows).astype(float)
    a0, a1, a2, b0, b1, b2 = A.T
    r0, r1, r2 = T - a0, T - a1, T - a2
    c0, c1, c2 = r0 - b0, r1 - b1, r2 - b2
    lp = (logC(T, a0) + logC(T, a1) + logC(T, a2) - logC(3 * T, T)
          + logC(r0, b0) + logC(r1, b1) + logC(r2, b2) - logC(2 * T, T))
    tab = np.stack([np.stack([a0, a1, a2], 1), np.stack([b0, b1, b2], 1), np.stack([c0, c1, c2], 1)], 1)
    return tab, lp

def puissance_exacte(T):
    tab, lp = tables(T)
    mubar = tab @ mus / T                       # (K, 3)
    lam = T * ((mubar - mus[None, :]) ** 2).sum(axis=1)
    w = np.exp(lp)
    return float(np.sum(w * stats.ncx2.sf(seuil, 3, lam))), float(w.sum())

def puissance_exploratoire(T):
    """Statistique de la contre-vérification : D = moyenne(agent 3) − moyenne(agent 1), alarme si
    D ≤ quantile 5 % sous P0 (P0 : D ~ N(1, 2/T)). Sous rebrassage : D | table ~ N(μ̄_2 − μ̄_0, 2/T)."""
    tab, lp = tables(T)
    mubar = tab @ mus / T
    t_low = 1.0 + stats.norm.ppf(alpha) * math.sqrt(2 / T)
    return float(np.sum(np.exp(lp) * stats.norm.cdf((t_low - (mubar[:, 2] - mubar[:, 0])) / math.sqrt(2 / T))))

print(f"seuil χ²_3 à 5 % : {seuil:.4f} ; critère « au moins 0,99 » à R = 20 000 : p̂ ≥ {0.99 - 4*math.sqrt(0.99*0.01/20000):.5f}")
for T in (30, 40, 50, 60):
    lam0 = T * np.sum(mus ** 2)
    pe, masse = puissance_exacte(T)
    print(f"T={T}: (1) χ² non central λ = {lam0:.0f} : {stats.ncx2.sf(seuil, 3, lam0):.4f} ; (2) exacte : {pe:.4f} "
          f"(masse {masse:.12f}) ; (4) stat. exploratoire (écart rôles, queue basse) : {puissance_exploratoire(T):.5f}")

print("\n(3) validation par simulation directe, tailles jetables seulement (T = 30, 50)")
ss = np.random.SeedSequence(31337)
for T, s in zip((30, 50), ss.spawn(2)):
    g = np.random.default_rng(s)
    R, k = 200_000, 0
    for _ in range(R // 20_000):
        Y = mus[None, :, None] + g.standard_normal((20_000, 3, T))
        flat = Y.reshape(20_000, 3 * T)
        X = np.take_along_axis(flat, np.argsort(g.random(flat.shape), axis=1), axis=1).reshape(20_000, 3, T)
        d = (T * (X.mean(axis=2) - mus[None, :]) ** 2).sum(axis=1)
        k += int((d >= seuil).sum())
    p = k / R
    print(f"T={T}: simulé {p:.4f} ± {math.sqrt(p*(1-p)/R):.4f} ; exacte {puissance_exacte(T)[0]:.4f}")
