"""Contre-lecture T0.3 — v03 : heuristique P3.4 sur configurations JETABLES (T ≠ 200).
Sabotage reporté (bloc des m dernières actions, δ = B/m), seuils Monte-Carlo sous P0 au même α,
détection « à temps » = première alarme à un indice < n0 − 1. Code du dépôt (lots, calibrage),
graine SeedSequence(271828), R_cal = 40 000, R = 10 000."""
import math, sys
import numpy as np
sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.simulation_t03 import lots as L, calibrage as cal, attaques as att

alpha = 0.05
ss = np.random.SeedSequence(271828)
graines = iter(ss.spawn(64))

def series(x, rho):
    return {"e_unilat_cal": L.serie_e(x, rho, "unilateral"), "page": L.serie_page(x, 0.5),
            "detecteur_e": L.serie_detecteur_e(x)}

for T, cas in ((180, [(13.5, 4), (13.5, 9), (13.5, 18), (22.5, 18), (12.0, 20)]),
               (250, [(15.0, 5), (15.0, 20), (25.0, 20)])):
    rho = cal.rho_optimal(T, alpha, "unilateral")[0]
    g = np.random.default_rng(next(graines))
    vals = {k: [] for k in ("e_unilat_cal", "page", "detecteur_e")}
    for _ in range(4):
        y = g.standard_normal((10_000, T))
        for k, s in series(y, rho).items():
            vals[k].append(s.max(axis=1))
    seuils = {k: cal.seuil_mc(np.concatenate(v), alpha) for k, v in vals.items()}
    print(f"T={T} (rho*={rho:.4f}) seuils MC : " + ", ".join(f"{k}={v:.3f}" for k, v in seuils.items()))
    for B, m in cas:
        g = np.random.default_rng(next(graines))
        R = 10_000
        y = g.standard_normal((R, T))
        P = att.positions("fin", m, 1, T, R, g)
        x = att.appliquer_decalages(y, P, att.decalages("egaux", m, B, R, g))
        res = {}
        for k, s in series(x, rho).items():
            f = L.premiere_alarme(s, seuils[k])
            res[k] = ((f >= 0) & (f < T - 1)).mean()
        se = lambda p: math.sqrt(max(p*(1-p), 1/R)/R)
        z = {k: (res[k] - res["e_unilat_cal"]) / math.sqrt(se(res[k])**2 + se(res["e_unilat_cal"])**2)
             for k in ("page", "detecteur_e")}
        print(f"  B={B:5.1f} m={m:2d} δ={B/m:.3f} : à temps e_cal={res['e_unilat_cal']:.3f} page={res['page']:.3f} "
              f"(z={z['page']:.1f}) detecteur_e={res['detecteur_e']:.3f} (z={z['detecteur_e']:.1f})")
