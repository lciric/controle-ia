"""Contre-lecture différentielle du pilote T0.5 — un déclencheur candidat sensible au désalignement de B :
σ̂²_δ / V̂[sA] < −s. Taux de fausse alerte (aligné) et de détection (B permuté), 64 tâches (stylisé)."""
import numpy as np

rng = np.random.default_rng(np.random.SeedSequence(20261011))


def simuler(n, parts):
    vb, vd, ve = parts
    b = rng.normal(0, np.sqrt(vb), n)
    d1, d2 = rng.normal(0, np.sqrt(vd), n), rng.normal(0, np.sqrt(vd), n)
    e1, e2, e3 = (rng.normal(0, np.sqrt(ve), n) for _ in range(3))
    return b + d1 + e1, b + d1 + e2, b + d2 + e3


def ratio(a, b, c):
    cov = lambda x, y: float(np.cov(x, y, ddof=1)[0, 1])  # noqa: E731
    return (cov(a, b) - cov(a, c)) / float(np.var(a, ddof=1))


for parts in ((0.3, 0.2, 0.5), (0.15, 0.15, 0.7), (0.1, 0.1, 0.8), (0.4, 0.3, 0.3)):
    al, mal = [], []
    for _ in range(4000):
        a, b, c = simuler(64, parts)
        al.append(ratio(a, b, c))
        mal.append(ratio(a, b[rng.permutation(64)], c))
    al, mal = np.array(al), np.array(mal)
    print(parts, " ; ".join(f"s={s}: fausse alerte {np.mean(al < -s):.3f}, détection {np.mean(mal < -s):.3f}"
                             for s in (0.1, 0.2)))
