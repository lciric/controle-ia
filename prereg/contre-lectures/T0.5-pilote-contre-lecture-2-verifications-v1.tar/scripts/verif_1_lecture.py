"""Contre-lecture différentielle du pilote T0.5 — vérifications par l'exécution (lecture seule du dépôt).

Lancer depuis le dépôt :  PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src .venv/bin/python -I <ce fichier>
(-I : le dossier du script n'entre pas dans le chemin ; PYTHONPATH est ignoré en mode isolé, d'où l'ajout explicite.)
"""
import sys

sys.path.insert(0, "/home/user/controle-ia/src")

import numpy as np

from controle_ia.environnements import analyse_pilote as ap
from controle_ia.environnements import lire_pilote as lp
from controle_ia.gardes import GardeArret

SS = np.random.SeedSequence(20261007)
rngs = {k: np.random.default_rng(s) for k, s in zip(
    ("identite", "desalignement", "regle48", "kappa", "vide"), SS.spawn(5))}


def titre(t):
    print("\n=== " + t + " ===")


def simuler(n, parts, rng):
    """Modèle stylisé du rapport 1 (annexe B) : sA = b + d1 + e1 ; sB = b + d1 + e2 ; sC = b + d2 + e3."""
    vb, vd, ve = parts
    b = rng.normal(0, np.sqrt(vb), n)
    d1, d2 = rng.normal(0, np.sqrt(vd), n), rng.normal(0, np.sqrt(vd), n)
    e1, e2, e3 = (rng.normal(0, np.sqrt(ve), n) for _ in range(3))
    return b + d1 + e1, b + d1 + e2, b + d2 + e3


# 1. Somme des composantes = (V̂[sA] + V̂[sB]) / 2, identiquement --------------------------------------------------
titre("1. identité : somme des composantes = (V[sA] + V[sB]) / 2")
r = rngs["identite"]
ecarts = []
for _ in range(200):
    a, b, c = (r.normal(0, r.uniform(0.5, 3), 64) for _ in range(3))      # notes quelconques, sans structure
    d = ap.decomposition_complete(a, b, c)
    ecarts.append(abs(d["composantes"]["totale"] - (np.var(a, ddof=1) + np.var(b, ddof=1)) / 2))
print("écart maximal sur 200 jeux quelconques :", max(ecarts))


# 2. Désalignement de B (erreur de clé) : quels déclencheurs « trop sale » voient-ils ? ------------------------------
titre("2. B désaligné (permuté) : déclencheurs et règle du plan B")


def juges_de(a, b, c):
    al = {"sA": a, "sB": b, "sC": c, "part_incompletes": 0.0, "part_A_B_identiques": 0.0, "tronquees": 0}
    return al


r = rngs["desalignement"]
for parts in ((0.3, 0.2, 0.5), (0.15, 0.15, 0.7), (0.4, 0.3, 0.3)):
    n_rep, sans_alerte, plan_b_sans_alerte, verite_plan_b, v_declenche = 300, 0, 0, 0, 0
    for _ in range(n_rep):
        a, b, c = simuler(64, parts, r)
        b = b[r.permutation(64)]                                           # artefact : clés de B désalignées
        al = juges_de(a, b, c)
        lj = lp.lecture_juge(al, r, tirages=200)
        audit = lp.declencheurs_audit({"part_valides": 0.9}, {"8B": {**lj, **al}}, {}, None, [0.3, 0.7])
        if not audit["trop_sale"]:
            sans_alerte += 1
            if lj["plan_b"] == "plan B":
                plan_b_sans_alerte += 1
        if any("V̂" in x for x in audit["trop_sale"]):
            v_declenche += 1
    print(f"parts vraies {parts} : aucun déclencheur « trop sale » dans {sans_alerte}/{n_rep} ; "
          f"plan B sans aucun déclencheur dans {plan_b_sans_alerte}/{n_rep} ; "
          f"déclencheur V̂[sA]/somme vu {v_declenche}/{n_rep}")

# même chose avec C désaligné
for parts in ((0.3, 0.2, 0.5),):
    n_rep, sans_alerte = 300, 0
    for _ in range(n_rep):
        a, b, c = simuler(64, parts, r)
        c = c[r.permutation(64)]
        al = juges_de(a, b, c)
        lj = lp.lecture_juge(al, r, tirages=200)
        audit = lp.declencheurs_audit({"part_valides": 0.9}, {"8B": {**lj, **al}}, {}, None, [0.3, 0.7])
        sans_alerte += not audit["trop_sale"]
    print(f"C désaligné, parts vraies {parts} : aucun déclencheur « trop sale » dans {sans_alerte}/{n_rep}")

# contrôle proposé : même contexte pour A et B (longueurs de contexte égales tâche par tâche) — trivial, non simulé.


# 3. Règle des 48 tâches complètes : plan B issu de la décomposition sous 48 tâches ----------------------------------
titre("3. moins de 48 tâches complètes, peu d'incomplètes : plan B conservé par le code")
r = rngs["regle48"]
for essai in range(200):
    a, b, c = simuler(64, (0.05, 0.05, 0.9), r)
    a[40:] = np.nan                       # 24 tâches sans note A (ensembles vides, par exemple) : 40 complètes
    al = {"sA": a, "sB": b, "sC": c, "part_incompletes": 0.0, "part_A_B_identiques": 0.0, "tronquees": 0}
    lj = lp.lecture_juge(al, np.random.default_rng(essai), tirages=300)
    if lj["plan_b"] == "plan B":
        p = lj["decomposition"]["parts_tronquees"]["juge"]
        print(f"essai {essai} : tâches complètes {lj['taches_completes']} (< 48), part des incomplètes 0, "
              f"part du juge {p:.3f}, borne {lj['intervalles']['bornes']['juge'][0]:.3f} → plan_b = {lj['plan_b']!r} "
              "(texte : « non concluant (nœud) sous 48 tâches complètes »)")
        juges = {"8B": lj, "3B": {"lecture": "x"}}
        fmt = {"part_valides": 0.9, "part_cout_lu": 0.9}
        pred = lp.predictions(fmt, juges, None, lp._familles_vides(), {"mediane_log10": 0.0}, None)
        print("   statut de P2 sur cette décomposition déclarée non concluante :", pred["P2"])
        break

# P2 confirmée sous 48 tâches
for essai in range(200):
    a, b, c = simuler(64, (0.3, 0.2, 0.5), r)
    a[30:] = np.nan
    al = {"sA": a, "sB": b, "sC": c, "part_incompletes": 0.0, "part_A_B_identiques": 0.0, "tronquees": 0}
    lj = lp.lecture_juge(al, np.random.default_rng(essai), tirages=200)
    pred = lp.predictions({"part_valides": 0.9, "part_cout_lu": 0.9}, {"8B": lj}, None, lp._familles_vides(),
                          {"mediane_log10": 0.0}, None)
    if pred["P2"] == "confirmée":
        print(f"30 tâches complètes : plan_b = {lj['plan_b']!r}, P2 = {pred['P2']!r} "
              f"(part {lj['decomposition']['parts_tronquees']['juge']:.3f})")
        break


# 4. Statut d'une prédiction réfutée par une clause quand l'autre grandeur est indéfinie ---------------------------
titre("4. statut : réfutation masquée par une grandeur indéfinie")
fam = {"controles_ensemble": {"valeur": 0.5}, "fecondes_ensemble": {"valeur": 0.2}}
juges = {"8B": {"decomposition": None}}
p6 = lp.predictions({"part_valides": 0.9, "part_cout_lu": 0.3}, juges, None, fam, {"mediane_log10": None}, None)["P6"]
print("P6 avec coût lu = 0,3 (< 0,6) et médiane indéfinie :", p6, "(texte : réfutée si lu < 0,6)")
kap = {"controls": {"kappa": 0.30}, "directions": {"kappa": None}}
p7 = lp.predictions({"part_valides": 0.9, "part_cout_lu": 0.9}, juges, None, fam, {"mediane_log10": 0.0}, kap)["P7"]
print("P7 avec kappa des contrôles = 0,30 (< 0,4) et kappa des directions indéfini :", p7,
      "(texte : réfutée si contrôles < 0,4)")


# 5. Format strict : « rien après » n'est pas vérifié ---------------------------------------------------------------
titre("5. format strict")
action = ("ACTION: ADD\nTITLE: t\nPROPOSAL: p\nCONTROLS: c\nCOST: 10\nPREDICTION: x")
print("action suivie d'un bavardage → format_strict =", lp.format_strict(action + "\n\nI hope this helps! Let me know."))
print("action précédée d'une ligne vide → format_strict =", lp.format_strict("\n" + action))


# 6. Un juge aux notes constantes : la lecture entière s'arrête ------------------------------------------------------
titre("6. juge aux notes constantes")
r = rngs["vide"]
a, b, c = simuler(64, (0.3, 0.2, 0.5), r)
const = np.full(64, 20.0)
al3 = {"sA": const, "sB": const.copy(), "sC": const.copy(), "part_incompletes": 0.0, "part_A_B_identiques": 1.0,
       "tronquees": 0}
try:
    lp.lecture_juge(al3, np.random.default_rng(1), tirages=50)
    print("lecture_juge : pas d'arrêt")
except GardeArret as e:
    print("lecture_juge s'arrête (GardeArret non rattrapée par `analyser`) :", e)
try:
    d = ap.difference_appariee((a, b, c), (const, const, const), 50, np.random.default_rng(2))
    print("difference_appariee :", d)
except GardeArret as e:
    print("difference_appariee : GardeArret", e)
except Exception as e:                    # noqa: BLE001
    print("difference_appariee : exception hors GardeArret (non rattrapée par `analyser`) :", type(e).__name__, e)


# 7. Kappa pondéré : contrôle sur une population connue ---------------------------------------------------------------
titre("7. kappa pondéré : estimation sans biais grossier sur une population connue")
r = rngs["kappa"]
N_oui, N_non = 300, 2700
juge = np.r_[np.ones(N_oui, bool), np.zeros(N_non, bool)]
ref = np.r_[r.random(N_oui) < 0.85, r.random(N_non) < 0.02]
vrai = ap.kappa_pondere(ref, juge, np.ones(len(ref)))["kappa"]
paires = [{"cle": f"p{i}", "tache": f"t{i % 64}", "famille": "controls", "oui_8b": bool(juge[i]), "ref": bool(ref[i])}
          for i in range(len(ref))]
est = []
for _ in range(400):
    ech = ap.tirer_paires(paires, r, 40)
    k = ap.kappa_pondere([p["ref"] for p in ech], [p["oui_8b"] for p in ech], [p["poids"] for p in ech])["kappa"]
    if k is not None:
        est.append(k)
print(f"kappa de population {vrai:.3f} ; moyenne des estimations pondérées {np.mean(est):.3f} ; "
      f"écart-type {np.std(est):.3f} (400 tirages de 2 × 40 paires)")
