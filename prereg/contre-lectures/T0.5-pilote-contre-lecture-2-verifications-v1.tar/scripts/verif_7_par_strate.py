"""Contre-lecture différentielle du pilote T0.5 — puissance du critère de kappa des directions (5 % de oui) avec 40 puis
80 paires par strate (stylisé, non opposable)."""
import sys

sys.path.insert(0, "/home/user/controle-ia/src")
import numpy as np

from controle_ia.environnements import analyse_pilote as ap

rng = np.random.default_rng(np.random.SeedSequence(20261010))


def population(n_paires, p_oui, kappa, n_taches):
    s, f = 1 - (1 - kappa) * (1 - p_oui), p_oui * (1 - kappa)
    n_oui = int(round(p_oui * n_paires))
    juge = np.r_[np.ones(n_oui, bool), np.zeros(n_paires - n_oui, bool)]
    ref = np.r_[rng.random(n_oui) < s, rng.random(n_paires - n_oui) < f]
    taches = rng.integers(0, n_taches, n_paires)
    return [{"cle": f"p{i}", "tache": f"t{taches[i]}", "famille": "x", "oui_8b": bool(juge[i]), "reference": bool(ref[i])}
            for i in range(n_paires)], ap.kappa_pondere(ref, juge, np.ones(n_paires))["kappa"]


for par_strate in (40, 80):
    for kappa in (0.6, 0.7, 0.8):
        pop, vrai = population(3000, 0.05, kappa, 64)
        ok = 0
        for _ in range(300):
            ech = ap.tirer_paires(pop, rng, par_strate)
            k = ap.kappa_pondere([p["reference"] for p in ech], [p["oui_8b"] for p in ech], [p["poids"] for p in ech])
            if k["kappa"] is None:
                continue
            iv = ap.intervalle_kappa_par_tache(ech, 400, rng)
            ok += iv["borne"] is not None and k["kappa"] >= 0.6 and iv["borne"][0] >= 0.4
        print(f"{par_strate} paires par strate, kappa de population {vrai:.3f} : P(retenue) = {ok / 300:.2f}")
