"""Contre-lecture différentielle du pilote T0.5 — ordres de grandeur (stylisés, non opposables) :
(a) puissance du critère de retenue sur le kappa pondéré, au plan réel du code (40 paires par strate, intervalle par
    tâche) ; (b) taux de décision de la règle du plan B, au code réel (`lecture_juge`), près des seuils.
"""
import sys

sys.path.insert(0, "/home/user/controle-ia/src")

import numpy as np

from controle_ia.environnements import analyse_pilote as ap
from controle_ia.environnements import lire_pilote as lp

SS = np.random.SeedSequence(20261008)
g_kappa, g_planb = (np.random.default_rng(s) for s in SS.spawn(2))
TIRAGES_IC = 400          # le code en fait 2 000 ; 400 suffisent pour l'ordre de grandeur
REPET = 300


def population(n_paires, p_oui, kappa, n_taches, rng):
    """Décisions du 8B (part p_oui) et étiquettes de référence de même marge, au kappa de population voulu."""
    s = 1 - (1 - kappa) * (1 - p_oui)        # P(réf. oui | 8B oui)
    f = p_oui * (1 - kappa)                   # P(réf. oui | 8B non)
    n_oui = int(round(p_oui * n_paires))
    juge = np.r_[np.ones(n_oui, bool), np.zeros(n_paires - n_oui, bool)]
    ref = np.r_[rng.random(n_oui) < s, rng.random(n_paires - n_oui) < f]
    taches = rng.integers(0, n_taches, n_paires)
    return [{"cle": f"p{i}", "tache": f"t{taches[i]}", "famille": "x", "oui_8b": bool(juge[i]), "reference": bool(ref[i])}
            for i in range(n_paires)], ap.kappa_pondere(ref, juge, np.ones(n_paires))["kappa"]


print("(a) P(kappa pondéré ≥ 0,6 et borne basse ≥ 0,4), 40 paires par strate (oui, non du 8B), intervalle par tâche")
print("famille (paires, part de oui) | kappa de population visé → réalisé | P(retenue) | écart-type de l'estimation")
for nom, n_paires, p_oui, n_taches in (("contrôles", 6000, 0.30, 64), ("directions fécondes", 3000, 0.10, 64),
                                       ("directions fécondes", 3000, 0.05, 64), ("directions stériles", 1200, 0.05, 32)):
    for kappa in (0.6, 0.7, 0.8):
        pop, vrai = population(n_paires, p_oui, kappa, n_taches, g_kappa)
        ok, est = 0, []
        for _ in range(REPET):
            ech = ap.tirer_paires(pop, g_kappa, 40)
            k = ap.kappa_pondere([p["reference"] for p in ech], [p["oui_8b"] for p in ech], [p["poids"] for p in ech])
            if k["kappa"] is None:
                continue
            est.append(k["kappa"])
            iv = ap.intervalle_kappa_par_tache(ech, TIRAGES_IC, g_kappa)
            if iv["borne"] is not None and k["kappa"] >= 0.6 and iv["borne"][0] >= 0.4:
                ok += 1
        print(f"{nom} ({n_paires}, {p_oui}) | {kappa} → {vrai:.3f} | {ok / REPET:.2f} | {np.std(est):.3f}")

print("\n(b) Règle du plan B au code réel (64 tâches complètes, aucune incomplète), modèle normal stylisé")
print("parts vraies (tâche, génération, juge) | P(plan B) | P(nœud) | P(rubrique gardée)")


def simuler(n, parts, rng):
    vb, vd, ve = parts
    b = rng.normal(0, np.sqrt(vb), n)
    d1, d2 = rng.normal(0, np.sqrt(vd), n), rng.normal(0, np.sqrt(vd), n)
    e1, e2, e3 = (rng.normal(0, np.sqrt(ve), n) for _ in range(3))
    return b + d1 + e1, b + d1 + e2, b + d2 + e3


for parts in ((0.25, 0.15, 0.6), (0.18, 0.12, 0.7), (0.12, 0.08, 0.8), (0.06, 0.04, 0.9)):
    compte = {"plan B": 0, "nœud": 0, "rubrique gardée": 0}
    for _ in range(REPET):
        a, b, c = simuler(64, parts, g_planb)
        al = {"sA": a, "sB": b, "sC": c, "part_incompletes": 0.0, "part_A_B_identiques": 0.0, "tronquees": 0}
        compte[lp.lecture_juge(al, g_planb, tirages=TIRAGES_IC)["plan_b"]] += 1
    print(f"{parts} | " + " | ".join(f"{compte[k] / REPET:.2f}" for k in ("plan B", "nœud", "rubrique gardée")))
