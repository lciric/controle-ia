"""Contre-lecture différentielle du pilote T0.5 — deux cas de bout en bout sur un run synthétique (aides des tests du
dépôt, dépôt git jetable dans le dossier de travail ; le vrai dépôt n'est pas touché) :
1. seul le coût est retenu : « aucune_famille_retenue » ;
2. arrêt pendant les notations décisives du 3B (fichier du 3B absent) : ce que lit `analyser`.
3. modules de lecture modifiés APRÈS la préparation de l'étiquetage : `analyser` ne le voit pas."""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, "/home/user/controle-ia/src")
sys.path.insert(0, "/home/user/controle-ia/tests")

import test_lire_pilote as T  # noqa: E402  (aides des tests : construire, _etiqueter, …)
from controle_ia.environnements import lire_pilote as lp  # noqa: E402

TRAVAIL = Path(__file__).resolve().parent.parent / "bout-en-bout"
if TRAVAIL.exists():
    shutil.rmtree(TRAVAIL)
TRAVAIL.mkdir()


def depot_neuf(nom):
    d = TRAVAIL / nom
    d.mkdir()
    for args in (["init", "-q", "-b", "main"], ["config", "user.email", "t@example.invalid"],
                 ["config", "user.name", "t"]):
        subprocess.run(["git", "-C", str(d), *args], check=True, capture_output=True)
    (d / "README").write_text("x\n")
    subprocess.run(["git", "-C", str(d), "add", "-A"], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(d), "commit", "-q", "-m", "init"], check=True, capture_output=True)
    return d


# 1. coût seul retenu ---------------------------------------------------------------------------------------------
taches_origine = T._taches


def taches_toutes_avec_reference(n, steriles):
    ts = taches_origine(n, steriles)
    for t in ts:
        t["cibles"]["compute"]["reference_gpu_hours"] = 100
    return ts


T._taches = taches_toutes_avec_reference
d1 = depot_neuf("cout-seul")
c = T.construire(d1)
T._taches = taches_origine
lp.preparer_etiquetage(d1, T.RUN, T.ANALYSE, c["prereg"], c["taches"], TRAVAIL / "travail-1")
T._etiqueter(TRAVAIL / "travail-1")                         # étiqueteur au hasard : aucune famille appariée fiable
lp.lire_etiquetage(d1, T.ANALYSE, TRAVAIL / "travail-1")
T.committer(d1)
L = lp.analyser(d1, T.RUN, T.ANALYSE, c["taches"])
print("1. retenue :", L["retenue"], "; aucune_famille_retenue :", L["aucune_famille_retenue"])

# 2. arrêt pendant les notations décisives du 3B --------------------------------------------------------------------
d2 = depot_neuf("arret-3B")
c = T.construire(d2, etapes=("decisives",))
for f in (d2 / "diag" / T.RUN).glob("notations-3B-decisives.json*"):
    f.unlink()                                               # le 3B n'a rien écrit : arrêt pendant son étape
T.committer(d2)
lp.preparer_etiquetage(d2, T.RUN, T.ANALYSE, c["prereg"], c["taches"], TRAVAIL / "travail-2")
T.committer(d2)
L = lp.analyser(d2, T.RUN, T.ANALYSE, c["taches"])
print("2. juges :", {j: (v.get("plan_b") or v.get("lecture")) for j, v in L["juges"].items()},
      "; P3 :", L["predictions"]["P3"], "; familles :", L["familles"], "; run partiel :", L["run_partiel"])

# 3. modules modifiés après la préparation ------------------------------------------------------------------------
d3 = depot_neuf("modules-apres")
c = T.construire(d3)
lp.preparer_etiquetage(d3, T.RUN, T.ANALYSE, c["prereg"], c["taches"], TRAVAIL / "travail-3")
T._etiqueter_selon_8b(d3, TRAVAIL / "travail-3", inverser=0.1)
lp.lire_etiquetage(d3, T.ANALYSE, TRAVAIL / "travail-3")
m = d3 / "src/controle_ia/environnements/analyse_pilote.py"
m.write_text(m.read_text(encoding="utf-8").replace("seuil_part: float = 0.8", "seuil_part: float = 0.5"),
             encoding="utf-8")                               # artefact : règle du plan B changée après la préparation
T.committer(d3)
r = subprocess.run(["git", "-C", str(d3), "diff", "--stat", "HEAD~1", "--", "src"], capture_output=True, text=True)
print("3. module modifié et commité après la préparation :", r.stdout.strip().splitlines()[-1])
try:
    lp.analyser(d3, T.RUN, T.ANALYSE, c["taches"])
    print("   `analyser` n'arrête pas (il ne compare pas les modules au commit cité ; le code exécuté est d'ailleurs "
          "celui de PYTHONPATH, sans garde d'import)")
except Exception as e:                                       # noqa: BLE001
    print("   `analyser` arrête :", type(e).__name__, e)
