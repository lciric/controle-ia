"""Contre-lecture différentielle du pilote T0.5 — le validateur `problemes()` sur une copie du brouillon 3 dont les
« À REMPLIR » sont remplis par des valeurs factices (copie dans le dossier de travail, dépôt intact)."""
import re
import sys
from pathlib import Path

sys.path.insert(0, "/home/user/controle-ia/src")

from controle_ia.prereg import problemes

ICI = Path(__file__).resolve().parent
texte = Path("/home/user/controle-ia/brouillons/T0.5-pilote-8B-v1-brouillon3.md").read_text(encoding="utf-8")
h = "e" * 64
rempli = texte.replace("`À REMPLIR`", "`" + h + "`").replace("À REMPLIR", "rempli")
rempli = rempli.replace("Contre-lecture 2 (différentiel du brouillon 1 au brouillon 3, code compris ; sous-agent neuf) : rempli.",
                        f"Contre-lecture 2 (différentiel ; sous-agent neuf) : brouillon relu `{'1' * 64}`, rapport `{'2' * 64}`.")
copie = ICI / "brouillon3-rempli-factice.md"
copie.write_text(rempli, encoding="utf-8")
print("problèmes relevés :", problemes(copie))
s = re.search(r"## Contre-lecture\n(.*?)\n## ", rempli, re.S).group(1)
print("empreintes complètes dans la section :", sorted(set(re.findall(r"\b[0-9a-f]{64}\b", s))))
print("la ligne de la contre-lecture 1 cite :", re.search(r"Traitement de la contre-lecture 1 \(([^)]*)\)", s).group(1))
