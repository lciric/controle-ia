"""Contre-lecture différentielle du pilote T0.5 — texte de l'annexe contre constantes du code ; clés de graines ;
constantes gelées du texte contre celles du code ; couverture et coût sur un petit cas calculé à la main."""
import re
import sys

sys.path.insert(0, "/home/user/controle-ia/src")

from controle_ia.environnements import lire_pilote as lp
from controle_ia.environnements.propositions import EnvironnementPropositions, Tache

B3 = "/home/user/controle-ia/brouillons/T0.5-pilote-8B-v1-brouillon3.md"
texte = open(B3, encoding="utf-8").read()

print("=== annexe : consigne d'étiquetage ===")
bloc = re.search(r"```\n(.*?)```", texte, re.S).group(1)
print("bloc de l'annexe == CONSIGNE_ETIQUETAGE :", bloc == lp.CONSIGNE_ETIQUETAGE)
inv = re.search(r"Invite fixe du sous-agent : « (.*?) »", texte).group(1)
print("invite de l'annexe == INVITE_ETIQUETEUR :", inv == lp.INVITE_ETIQUETEUR)

print("\n=== clés de graines : texte contre code ===")
cles_texte = re.findall(r"« (analyse/[^»]+) »", texte)
print("texte :", cles_texte)
print("code  :", lp.cles_analyse(["8B", "3B"]))
print("clés du code absentes du texte, mot pour mot :", sorted(set(lp.cles_analyse(["8B", "3B"])) - set(cles_texte)))

print("\n=== constantes gelées (texte, ligne « Constantes de lecture ») ===")
ligne = re.search(r"\*\*Constantes de lecture\*\*.*", texte).group(0)
print(ligne)
print(lp.constantes(), "SEUIL_INCOMPLETES =", lp.SEUIL_INCOMPLETES)
print("SEUIL_INCOMPLETES dans constantes() (comparées au manifeste) :", "SEUIL_INCOMPLETES" in lp.constantes())

print("\n=== couvertures : cas calculé à la main ===")
tache = {"identifiant": "T1", "questions": "Q?",
         "cibles": {"controls": [{"id": "C1", "description": "c1"}, {"id": "C2", "description": "c2"},
                                 {"id": "C3", "description": "c3"}],
                    "fruitful_directions": [{"id": "F1", "description": "f1"}, {"id": "F2", "description": "f2"}],
                    "sterile_directions": [{"id": "S1", "description": "s1"}],
                    "compute": {"reference_gpu_hours": 100, "basis": "reported"}}}


def action(k, cout):
    return f"ACTION: ADD\nTITLE: t{k}\nPROPOSAL: p{k}\nCONTROLS: c\nCOST: {cout}\nPREDICTION: x"


def fiche(k, n):
    textes = [action(i, 10 ** (i + 1)) for i in range(n)]
    env = EnvironnementPropositions(Tache("T1", "Q?"), 1, n)
    return {"episode": f"T1/e{k}", "tache": "T1", "bilan": env.bilan([(0, s, x) for s, x in enumerate(textes)])}


fiches = [fiche(0, 2), fiche(1, 2), fiche(2, 2)]
# e0 : prop 1 couvre C1 et S1 ; prop 2 couvre C2 et F1. e1 : rien. e2 : prop 1 couvre C1, C2, C3, F1, F2.
oui = {("T1/e0", 1, "C1"), ("T1/e0", 1, "S1"), ("T1/e0", 2, "C2"), ("T1/e0", 2, "F1"),
       ("T1/e2", 1, "C1"), ("T1/e2", 1, "C2"), ("T1/e2", 1, "C3"), ("T1/e2", 1, "F1"), ("T1/e2", 1, "F2")}
app = []
for f in fiches:
    for n in (1, 2):
        for fam in ("controls", "fruitful_directions", "sterile_directions"):
            for c in tache["cibles"][fam]:
                app.append({"cle": f"{f['episode']}/{n}/{c['id']}", "p_oui": 0.9 if (f["episode"], n, c["id"]) in oui
                            else 0.1})
fam = lp.couvertures(fiches, {"T1": tache}, app)
# attendu, contrôles par ensemble : e0 2/3, e1 0, e2 1 → moyenne 5/9 ; par proposition : e0 1, e1 0, e2 1/2 → 1/2
# fécondes : e0 1/2, e1 0, e2 1 → 1/2 ; stériles par proposition : e0 1/2, e1 0, e2 0 → 1/6
print({k: v for k, v in fam.items()})
print("attendu : contrôles/ensemble 0.5556 ; contrôles/proposition 0.5 ; fécondes 0.5 ; stériles 0.1667 ; "
      "part 0 ou 1 = 2/3")
cout = lp.mesures_cout(fiches, {"T1": tache})
print(cout, "attendu : log10(10/100) = −1 et log10(100/100) = 0 trois fois → médiane −0,5")
