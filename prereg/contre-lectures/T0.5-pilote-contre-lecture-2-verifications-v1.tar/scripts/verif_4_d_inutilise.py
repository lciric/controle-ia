"""Contre-lecture différentielle du pilote T0.5 — ce que rapporterait D (déjà noté une fois par chaque juge) s'il entrait
dans l'estimation de σ²_β (moyenne des trois covariances entre épisodes A, C, D), sans aucune notation de plus.
Modèle normal stylisé (rapport 1, annexe B) ; ordres de grandeur, non opposables."""
import numpy as np

SS = np.random.SeedSequence(20261009)
rng = np.random.default_rng(SS)


def cov(x, y):
    return float(np.cov(x, y, ddof=1)[0, 1])


def parts(a, b, c, d=None):
    eps = float(np.var(a - b, ddof=1) / 2)
    beta = cov(a, c) if d is None else (cov(a, c) + cov(a, d) + cov(c, d)) / 3
    delta = cov(a, b) - beta
    comp = [max(beta, 0), max(delta, 0), max(eps, 0)]
    tot = sum(comp)
    return comp[2] / tot if tot > 0 else np.nan


for vb, vd, ve in ((0.18, 0.12, 0.7), (0.06, 0.04, 0.9), (0.3, 0.2, 0.5)):
    p_code, p_avec_d = [], []
    for _ in range(4000):
        n = 64
        b = rng.normal(0, np.sqrt(vb), n)
        dA, dC, dD = (rng.normal(0, np.sqrt(vd), n) for _ in range(3))
        eA, eB, eC, eD = (rng.normal(0, np.sqrt(ve), n) for _ in range(4))
        sA, sB, sC, sD = b + dA + eA, b + dA + eB, b + dC + eC, b + dD + eD
        p_code.append(parts(sA, sB, sC))
        p_avec_d.append(parts(sA, sB, sC, sD))
    p_code, p_avec_d = np.array(p_code), np.array(p_avec_d)
    print(f"parts vraies {(vb, vd, ve)} : écart-type de la part du juge, code {np.nanstd(p_code):.3f} → avec D "
          f"{np.nanstd(p_avec_d):.3f} ; P(part > 0,8) {np.nanmean(p_code > 0.8):.2f} → {np.nanmean(p_avec_d > 0.8):.2f}")
