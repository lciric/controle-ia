"""Contre-lecture 3 — observation hors différence : préenregistrement hors du dépôt (mini-grille des tests, dépôt jetable)."""
import os, shutil, subprocess, sys, tempfile
from pathlib import Path
ARBRE = Path(sys.argv[1]); sys.path[:0] = [str(ARBRE / "src"), str(ARBRE / "tests")]
import test_simulation_t03 as T                                   # noqa: E402
from controle_ia.prereg import sceller_prereg                     # noqa: E402
from controle_ia.simulation_t03.run_t03 import executer           # noqa: E402
def git(r, *a): subprocess.run(["git", "-C", str(r), *a], check=True, capture_output=True)
base = Path(tempfile.mkdtemp(prefix="cl3-pre-", dir=os.environ["SCRATCH"])); d = base / "depot"; d.mkdir()
git(d, "init", "-q", "-b", "main"); git(d, "config", "user.email", "t@example.invalid"); git(d, "config", "user.name", "t")
(d / "README").write_text("x\n"); git(d, "add", "-A"); git(d, "commit", "-q", "-m", "init")
pp, gp = T._preparer(d)
dehors = base / "prereg-dehors.md"; dehors.write_text(pp.read_text()); sceller_prereg(dehors)
try:
    executer(d, dehors, gp, "20261004-160000-mini", verifier_import=False); print("passe (inattendu)")
except Exception as e:
    print("préenregistrement hors du dépôt :", type(e).__name__, "—", str(e)[:110])
print("dossier de run créé :", (d / "runs" / "20261004-160000-mini").exists())
shutil.rmtree(base); print("dépôt jetable effacé :", not base.exists())
