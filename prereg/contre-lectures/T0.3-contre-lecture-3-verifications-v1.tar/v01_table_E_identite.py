"""Contre-lecture 3 — point b : table E du brouillon 3 identique mot pour mot à lecture.LIGNES_E au commit d73ac46.
Aucun tirage, aucune grille : comparaison de chaînes seulement."""
import hashlib, sys
from pathlib import Path

ARBRE = Path(sys.argv[1])          # extraction `git archive d73ac46`
BROUILLON = Path(sys.argv[2])
sys.path.insert(0, str(ARBRE / "src"))
from controle_ia.simulation_t03 import lecture as LEC   # noqa: E402
from controle_ia.simulation_t03.run_t03 import tableau_md  # noqa: E402

print("lecture.py importé depuis :", LEC.__file__)
octets = BROUILLON.read_bytes()
print("brouillon :", BROUILLON.name, hashlib.sha256(octets).hexdigest())
lignes = octets.decode("utf-8").splitlines()
entete = "| Énoncé | Lecture prononcée si toutes les exigées sont confirmées | Exigées | Complémentaires |"
i = lignes.index(entete)
assert lignes[i + 1] == "|---|---|---|---|", lignes[i + 1]
texte_rows = []
k = i + 2
while k < len(lignes) and lignes[k].startswith("|"):
    texte_rows.append(lignes[k]); k += 1
print("lignes de la table E dans le texte :", len(texte_rows), "; dans LIGNES_E :", len(LEC.LIGNES_E))
# 1) rendu exact au format de tableau_md (celui du lanceur)
code_rows = [f"| {l['enonce']} | {l['lecture']} | {', '.join(l['exiges'])} | {', '.join(l['complementaires']) or '—'} |"
             for l in LEC.LIGNES_E]
ok = True
for n, (a, b) in enumerate(zip(texte_rows, code_rows), 1):
    if a != b:
        ok = False
        j = next(j for j in range(min(len(a), len(b))) if a[j] != b[j]) if any(x != y for x, y in zip(a, b)) else min(len(a), len(b))
        print(f"ligne {n} DIFFÉRENTE à l'indice {j} :\n  texte: …{a[max(0,j-40):j+40]!r}\n  code : …{b[max(0,j-40):j+40]!r}")
print("identité ligne à ligne (format de tableau_md) :", ok and len(texte_rows) == len(code_rows))
# 2) champ par champ, après découpage (aucun « | » ne doit figurer dans les cellules)
for n, (a, l) in enumerate(zip(texte_rows, LEC.LIGNES_E), 1):
    cells = a[2:-2].split(" | ")
    assert len(cells) == 4, (n, len(cells))
    assert cells[0] == l["enonce"] and cells[1] == l["lecture"], n
    assert cells[2].split(", ") == l["exiges"], n
    assert (cells[3] == "—" and not l["complementaires"]) or cells[3].split(", ") == l["complementaires"], n
    assert "|" not in l["enonce"] + l["lecture"], n
print("identité champ par champ (énoncé, lecture, exigées, complémentaires) : True")
print("exigées par ligne :", [len(l["exiges"]) for l in LEC.LIGNES_E],
      "; complémentaires :", [len(l["complementaires"]) for l in LEC.LIGNES_E])
# 3) même rendu par le lanceur (tableau_md) sur une lecture factice
fausse = {"predictions": {}, "audit_symetrie": {"bornes": [0.3, 3], "formes_closes": {"variance_z": 1.0, "n": 0},
                                                 "egalites": {"variance_z": 1.0, "n": 0}, "audit_declenche": False}}
md = tableau_md(fausse, [dict(l) for l in LEC.LIGNES_E], "x").splitlines()
rows_e = md[-6:]
print("en-tête de la table E de tableau_md :", md[-8])
print("6 lignes de la table E rendues par tableau_md présentes telles quelles dans le texte :", all(r in lignes for r in rows_e), rows_e == texte_rows)
