"""Contre-lecture 3 — empreintes de 64 caractères citées dans le brouillon 3 : chaque couple (chemin, empreinte)."""
import hashlib, re, sys
from pathlib import Path
R = Path("/home/user/controle-ia"); B = Path(sys.argv[1])
texte = B.read_text(encoding="utf-8")
for n, l in enumerate(texte.splitlines(), 1):
    for h in re.findall(r"\b[0-9a-f]{64}\b", l):
        chemins = re.findall(r"`([^`]+\.(?:md|json|tar|pdf|txt))`", l)
        verdicts = []
        for c in chemins:
            p = R / c
            if p.exists():
                verdicts.append((c, hashlib.sha256(p.read_bytes()).hexdigest() == h))
        print(f"l. {n} : {h[:12]}… → {verdicts if verdicts else 'aucun chemin sur la ligne'}")
