"""Contre-lecture 3 — point d : le brouillon 3, section « Contre-lecture 3 » remplie, passe-t-il prereg.problemes ?
Motifs de gabarit, marqueur, ligne du commit cité, empreinte de la grille, structure des tableaux.
Aucun tirage, aucune grille ouverte au-delà de son empreinte."""
import hashlib, re, sys
from pathlib import Path

ARBRE = Path(sys.argv[1]); BROUILLON = Path(sys.argv[2]); OUT = Path(sys.argv[3])
sys.path.insert(0, str(ARBRE / "src"))
from controle_ia import prereg as P                                # noqa: E402
from controle_ia.simulation_t03.run_t03 import COMMIT_CITE          # noqa: E402

texte = BROUILLON.read_text(encoding="utf-8")
print("prereg.py :", P.__file__)
print("1) problemes(brouillon 3 tel quel) :", P.problemes(BROUILLON))
print("   occurrences de « À REMPLIR » :", [(n + 1, l[:90]) for n, l in enumerate(texte.splitlines()) if P.MARQUEUR in l])
print("   occurrences de « REMPLIR » (toute casse) :", [n + 1 for n, l in enumerate(texte.splitlines()) if "remplir" in l.lower()])
print("2) motifs GABARIT <<[A-Z0-9_]+>> :", P.GABARIT.findall(texte))
print("   tout « << » ou « >> » :", [(n + 1, l[:80]) for n, l in enumerate(texte.splitlines()) if "<<" in l or ">>" in l])
print("   motif élargi <<...>> (toute casse, espaces, tirets) :", re.findall(r"<<[^<>\n]{1,60}>>", texte))
print("   guillemets ‹‹ ›› ou « » doublés :", re.findall(r"««|»»|‹‹|››", texte))
# 3) section Contre-lecture 3 remplie (texte quelconque, sans marqueur)
rempli = texte.replace("À REMPLIR après la contre-lecture 3.",
                       "Contre-lecteur : sous-agent neuf. Rapport : chemin et empreinte. Verdict : scellable en l'état.")
assert rempli != texte
OUT.write_text(rempli, encoding="utf-8")
print("3) problemes(brouillon 3, section Contre-lecture 3 remplie) :", P.problemes(OUT))
s = P.sections(rempli)
print("   sections trouvées :", list(s))
print("   sections exigées absentes :", [x for x in P.SECTIONS if x not in s])
# 4) ligne du commit cité, telle que la lit le lanceur
m = COMMIT_CITE.search(texte)
print("4) commit cité extrait par COMMIT_CITE :", m.group(1) if m else None)
print("   nombre de lignes « Commit du code d'analyse » :", texte.count("Commit du code d'analyse"))
# 5) empreinte de la grille v2 (fichier lu en octets pour son empreinte seulement)
g = Path("/home/user/controle-ia/prereg/T0.3-grille-v2.json")
sha = hashlib.sha256(g.read_bytes()).hexdigest()
print("5) sha256 grille v2 :", sha, "; citée dans le texte :", sha in texte)
print("   compagnon .sha256 :", Path(str(g) + ".sha256").read_text().split()[0] == sha)
# 6) structure des tableaux Markdown : nombre de cellules (pipes non échappés) par ligne vs en-tête
def ncell(l):
    l = l.strip()
    l = re.sub(r"\\\|", "", l)
    return l.count("|") - 1
bloc = []
defauts = []
for n, l in enumerate(texte.splitlines() + [""], 1):
    if l.lstrip().startswith("|"):
        bloc.append((n, l))
    else:
        if bloc:
            h = ncell(bloc[0][1])
            for (k, x) in bloc[2:]:
                if ncell(x) != h:
                    defauts.append((k, h, ncell(x), x[:120]))
        bloc = []
print("6) lignes de tableau dont le nombre de cellules diffère de l'en-tête :")
for d in defauts:
    print("   ligne", d[0], ": en-tête", d[1], "cellules, ligne", d[2], "cellules :", d[3])
