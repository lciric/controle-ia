"""Contre-lecture 3 — gardes nouvelles sur dépôt git jetable (aucune grille décisive, aucune entropie de la grille).
(1) ligne de commande : garde du code importé toujours active ; (2) --blocs rejeté ; (3) grille v3 et commit cité."""
import os, shutil, subprocess, sys, tempfile
from pathlib import Path

ARBRE = Path(sys.argv[1])                      # extraction git archive d73ac46
sys.path.insert(0, str(ARBRE / "src"))
from controle_ia.gardes import GardeArret                                   # noqa: E402
from controle_ia.simulation_t03.run_t03 import exiger_code_cite, exiger_code_importe_sous  # noqa: E402

def git(r, *a):
    return subprocess.run(["git", "-C", str(r), *a], check=True, capture_output=True, text=True).stdout.strip()

base = Path(tempfile.mkdtemp(prefix="cl3-", dir=os.environ.get("SCRATCH")))
d = base / "depot"; d.mkdir()
git(d, "init", "-q", "-b", "main"); git(d, "config", "user.email", "t@example.invalid"); git(d, "config", "user.name", "t")
(d / "src").mkdir(); (d / "src" / "x.py").write_text("X = 1\n")
(d / "prereg").mkdir(); (d / "prereg" / "grille-v2.json").write_text('{"jetable": 2}\n')
git(d, "add", "-A"); git(d, "commit", "-q", "-m", "A"); A = git(d, "rev-parse", "HEAD")
p = d / "p.md"; p.write_text(f"- Commit du code d'analyse : `{A}`.\n")
print("(3a) grille v2, commit A cité :", exiger_code_cite(d, p, d / "prereg" / "grille-v2.json")[:12], "→ passe")
(d / "prereg" / "grille-v3.json").write_text('{"jetable": 3}\n')
git(d, "add", "prereg/grille-v3.json"); git(d, "commit", "-q", "-m", "B (ajoute la grille v3 seulement)"); B = git(d, "rev-parse", "HEAD")
try:
    exiger_code_cite(d, p, d / "prereg" / "grille-v3.json"); print("(3b) grille v3, commit A cité : passe")
except GardeArret as e:
    print("(3b) grille v3, commit A cité : ARRÊT —", e)
p2 = d / "p2.md"; p2.write_text(f"- Commit du code d'analyse : `{B}`.\n")
print("(3c) grille v3, commit B cité :", exiger_code_cite(d, p2, d / "prereg" / "grille-v3.json")[:12], "→ passe")

env = dict(os.environ, PYTHONPATH=str(ARBRE / "src"), PYTHONDONTWRITEBYTECODE="1")
cmd = [sys.executable, "-m", "controle_ia.simulation_t03.run_t03"]
r = subprocess.run(cmd + ["--racine", str(d), "--prereg", str(p), "--grille", str(d / "prereg" / "grille-v2.json")],
                   cwd=base, env=env, capture_output=True, text=True)
print("(1) ligne de commande, --racine = dépôt jetable, code importé de l'extraction : code", r.returncode, "|", r.stderr.strip()[-160:])
r = subprocess.run(cmd + ["--racine", str(ARBRE), "--prereg", str(base / "absent.md"), "--grille", str(base / "absente.json")],
                   cwd=ARBRE, env=env, capture_output=True, text=True)
print("(1') ligne de commande, --racine = arbre qui héberge le code : code", r.returncode, "|", (r.stderr.strip() or r.stdout.strip())[-200:])
r = subprocess.run(cmd + ["--prereg", "x", "--grille", "y", "--blocs", "P2"], cwd=base, env=env, capture_output=True, text=True)
print("(2) --blocs à la ligne de commande : code", r.returncode, "|", r.stderr.strip().splitlines()[-1])
r = subprocess.run(cmd + ["--help"], cwd=base, env=env, capture_output=True, text=True)
print("(2') options exposées :", [l.strip().split()[0] for l in r.stdout.splitlines() if l.strip().startswith("--")])
# garde du code importé : sain / artefact / lien symbolique vers l'arbre
exiger_code_importe_sous(ARBRE); print("(4a) racine = arbre hôte : passe")
lien = base / "lien"; lien.symlink_to(ARBRE)
exiger_code_importe_sous(lien); print("(4b) racine = lien symbolique vers l'arbre hôte : passe")
try:
    exiger_code_importe_sous(d); print("(4c) racine = autre arbre : passe (INATTENDU)")
except GardeArret as e:
    print("(4c) racine = autre arbre : ARRÊT —", str(e)[:120])
shutil.rmtree(base)
print("dépôt jetable effacé :", not base.exists())
