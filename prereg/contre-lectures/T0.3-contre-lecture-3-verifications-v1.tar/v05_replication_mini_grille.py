"""Contre-lecture 3 — chemin de réplication de `executer` après le refus de `blocs` (d73ac46), de bout en bout,
sur la MINI-GRILLE des tests (non décisive : tailles, budgets et graines des tests), dans un dépôt git jetable.
Une cellule statistique de P2.1 est forcée « contraire » dans la lecture principale (artefact), pour qu'il y ait
quelque chose à répliquer."""
import json, os, shutil, subprocess, sys, tempfile
from pathlib import Path

ARBRE = Path(sys.argv[1])
sys.path[:0] = [str(ARBRE / "src"), str(ARBRE / "tests")]
import test_simulation_t03 as T                                         # noqa: E402  (aides des tests : mini-grille)
from conftest import committer                                          # noqa: E402
from controle_ia.gardes import GardeArret                                # noqa: E402
from controle_ia.manifeste import verifier_resultat                     # noqa: E402
from controle_ia.simulation_t03 import lecture as LEC                    # noqa: E402
from controle_ia.simulation_t03.run_t03 import executer                  # noqa: E402

def git(r, *a):
    subprocess.run(["git", "-C", str(r), *a], check=True, capture_output=True)

base = Path(tempfile.mkdtemp(prefix="cl3-rep-", dir=os.environ["SCRATCH"]))
d = base / "depot"; d.mkdir()
git(d, "init", "-q", "-b", "main"); git(d, "config", "user.email", "t@example.invalid"); git(d, "config", "user.name", "t")
(d / "README").write_text("x\n"); git(d, "add", "-A"); git(d, "commit", "-q", "-m", "init")
pp, gp = T._preparer(d)
grille = json.loads(gp.read_text())
print("mini-grille : entropie", grille["entropie"], "; facteur_R", grille["replication"]["facteur_R"])

vrai_lire = LEC.lire
def lire_force(resultats, alpha, p8):                                    # artefact : une cellule statistique contraire
    lec = vrai_lire(resultats, alpha, p8)
    x = lec["predictions"]["P2.1"]
    c = next(c for c in x["cellules"] if c["genre"] == "statistique")
    c["etat"] = "contraire"
    x["a_repliquer"] = [c["nom"] for c in x["cellules"] if c["etat"] == "contraire" and c["genre"] == "statistique"]
    x["verdict"] = LEC.verdict(x["cellules"])
    return lec
LEC.lire = lire_force
s1 = executer(d, pp, gp, "20261004-150000-mini", verifier_import=False)
LEC.lire = vrai_lire
committer(d)                                                            # arbre propre avant la réplication
p = verifier_resultat(d, s1["lecture"])["resultat"]["lecture"]
print("principale : à répliquer =", {k: x["a_repliquer"] for k, x in p["predictions"].items() if x["a_repliquer"]})

s2 = executer(d, pp, gp, "20261004-150001-mini-rep", replication_de="20261004-150000-mini", verifier_import=False)
committer(d)
corps = verifier_resultat(d, s2["lecture"])["resultat"]
m = json.loads((d / "runs" / "20261004-150001-mini-rep" / "manifeste.json").read_text())
print("réplication : blocs =", m["config"]["blocs"], "; replication_de =", m["config"]["replication_de"])
f = corps["lecture_finale"]["predictions"]["P2.1"]
print("lecture finale P2.1 : verdict", f["verdict"], "; a_repliquer", f["a_repliquer"], "; repliquees", f["repliquees"])
print("toutes les a_repliquer vides après fusion :", all(x["a_repliquer"] == [] for x in corps["lecture_finale"]["predictions"].values()))
print("prédictions de la lecture de réplication :", sorted(corps["lecture"]["predictions"])[:4], "…")
print("lecture.md finale existe :", (d / "diag" / "20261004-150001-mini-rep" / "lecture.md").exists())
# seconde réplication du même run principal : mêmes graines « /replication » → mêmes tirages (aucune pêche possible)
s3 = executer(d, pp, gp, "20261004-150002-mini-rep", replication_de="20261004-150000-mini", verifier_import=False)
b2 = json.loads((d / "diag" / "20261004-150001-mini-rep" / "bloc-P2.json").read_text())
b3 = json.loads((d / "diag" / "20261004-150002-mini-rep" / "bloc-P2.json").read_text())
print("seconde réplication : bloc P2 identique à la première :", b2.get("resultat", b2) == b3.get("resultat", b3))
try:
    executer(d, pp, gp, "20261004-150003-mini-rep", blocs=["P2"], replication_de="20261004-150000-mini", verifier_import=False)
except GardeArret as e:
    print("blocs fournis en réplication : ARRÊT —", e)
shutil.rmtree(base)
print("dépôt jetable effacé :", not base.exists())
