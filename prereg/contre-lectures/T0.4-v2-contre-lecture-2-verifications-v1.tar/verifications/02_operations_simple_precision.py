"""Contre-lecture 2 (reprise), point a : opérations encore calculées en simple (ou demi) précision dans le modèle
de la phase de logique, au code cité (dc7aa7f). Processeur, noyau « math ».

Indépendant du script du premier contre-lecteur : on passe par les fonctions mêmes du harnais (`generer_lot`, avec
remplissage à gauche et plusieurs passes de décodage, puis `passe_unique`), sur un jouet de type Llama configuré comme
Llama-3.1 pour ce qui touche le calcul : rotations de type « llama3 » (mise à l'échelle des fréquences), têtes
clé-valeur groupées, normalisation RMS de la bibliothèque. Un mode de répartition de PyTorch journalise chaque
opération élémentaire dont une sortie est en simple, demi ou bfloat16 précision ; pour les produits matriciels, on
relève la dimension sommée (K) ; on marque « réduction » toute opération qui somme sur un axe de taille > 1.

Variantes : (1) chargement de la phase de logique par `charger` (jouet, double précision : normalisations remplacées) ;
(2) témoin : même modèle en double précision, normalisations de la bibliothèque ; (3) modèle de production
(`charger` en bfloat16) : ses normalisations gardent-elles la méthode de la classe, la classe est-elle intacte ?
"""
import collections
import json
import sys

import torch
from torch.utils._python_dispatch import TorchDispatchMode
from torch.utils._pytree import tree_flatten

sys.path.insert(0, "src")
from transformers import LlamaConfig, LlamaForCausalLM                       # noqa: E402
from transformers.models.llama.modeling_llama import LlamaRMSNorm          # noqa: E402

ORIGINE_FORWARD = LlamaRMSNorm.forward                                     # avant tout import du harnais
from controle_ia.harnais import validation_reelle as V                     # noqa: E402
from controle_ia.harnais.episode import generer_lot                        # noqa: E402
from controle_ia.harnais.activations import passe_unique                   # noqa: E402
from controle_ia.harnais.modeles import normalisations_en_double, _rms_en_double   # noqa: E402
from controle_ia.manifeste import graines as G                             # noqa: E402

BAS = (torch.float32, torch.float16, torch.bfloat16)
PRODUITS = {"aten.mm.default", "aten.bmm.default", "aten.addmm.default", "aten.baddbmm.default",
            "aten.matmul.default", "aten.dot.default", "aten.mv.default"}
REDUCTIONS = ("sum", "mean", "var", "std", "softmax", "amax", "amin", "norm", "cumsum", "prod", "logsumexp")


class Journal(TorchDispatchMode):
    def __init__(self):
        super().__init__()
        self.ops = collections.Counter()
        self.reductions_bas = collections.Counter()

    def __torch_dispatch__(self, func, types, args=(), kwargs=None):
        out = func(*args, **(kwargs or {}))
        sorties = [t for t in tree_flatten(out)[0] if isinstance(t, torch.Tensor)]
        entrees = [t for t in tree_flatten((args, kwargs))[0] if isinstance(t, torch.Tensor)]
        if any(t.dtype in BAS for t in sorties) or any(t.dtype in BAS for t in entrees if t.is_floating_point()):
            nom = str(func)
            k = None
            if nom in PRODUITS:
                a = args[1] if nom in ("aten.addmm.default", "aten.baddbmm.default") else args[0]
                k = int(a.shape[-1])
            cle = (nom, tuple(str(t.dtype).replace("torch.", "") for t in entrees),
                   tuple(str(t.dtype).replace("torch.", "") for t in sorties), k)
            self.ops[cle] += 1
            reduction = (k is not None and k > 1) or any(r in nom.split(".")[1] for r in REDUCTIONS)
            if reduction and any(t.dtype in BAS for t in sorties):
                self.reductions_bas[cle] += 1
        return out


def jouet_llama31(dtype):
    cfg = LlamaConfig(vocab_size=200, hidden_size=64, intermediate_size=128, num_hidden_layers=4,
                      num_attention_heads=8, num_key_value_heads=2, max_position_embeddings=4096,
                      rope_theta=500000.0, rms_norm_eps=1e-5, tie_word_embeddings=False,
                      rope_scaling={"rope_type": "llama3", "factor": 8.0, "low_freq_factor": 1.0,
                                    "high_freq_factor": 4.0, "original_max_position_embeddings": 64},
                      bos_token_id=1, eos_token_id=2, pad_token_id=0)
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(7)
        m = LlamaForCausalLM(cfg)
    return m.to(dtype).eval()


def passes(modele):
    contextes = [[5, 6, 7, 8, 9, 10, 11], [12, 13, 14], [15, 16, 17, 18, 19]]
    res = {}
    with torch.no_grad(), V.noyau("math"):
        j = Journal()
        with j:
            nouveaux, plan = generer_lot(modele, contextes, 4, 1.0, [1, 2, 3], set(), 0)
        res["generation (préremplissage + 3 passes de décodage)"] = j
        j = Journal()
        with j:
            passe_unique(modele, contextes[0] + nouveaux[0], [0, 1, 2])
        res["passe_unique"] = j
    return res


def resumer(res):
    out = {}
    for etape, j in res.items():
        out[etape] = {
            "operations_en_precision_basse": [f"{n}x {op} entrees={e} sorties={s}" + (f" K={k}" if k is not None else "")
                                              for (op, e, s, k), n in sorted(j.ops.items(), key=str)],
            "reductions_en_precision_basse": [f"{n}x {op} sorties={s}" + (f" K={k}" if k is not None else "")
                                              for (op, e, s, k), n in sorted(j.reductions_bas.items(), key=str)]}
    return out


sortie = {"versions": {"torch": torch.__version__, "transformers": __import__("transformers").__version__}}

# (1) chargement de la phase de logique par le code cité (jouet de la répétition, double précision)
config = V.CONFIG_REPETITION
gr = G(V.taches(config), 12345)
m64, _ = V.charger(config, None, "float64", gr)
sortie["1_logique_charger_jouet_repetition"] = {"normalisations_en_double": m64.normalisations_en_double,
                                                **resumer(passes(m64))}
# (1bis) jouet « Llama-3.1 » en double précision, normalisations remplacées par la fonction citée
m = jouet_llama31(torch.float64)
n = normalisations_en_double(m)
sortie["1bis_logique_jouet_llama31"] = {"normalisations_en_double": n, "rope_type": m.config.rope_parameters["rope_type"],
                                        **resumer(passes(m))}
# (2) témoin : double précision, normalisations de la bibliothèque
t = jouet_llama31(torch.float64)
sortie["2_temoin_double_normalisations_bibliotheque"] = resumer(passes(t))
# (3) production : bfloat16 par `charger` ; normalisations de la classe, classe intacte
m16, _ = V.charger(config, None, "bfloat16", gr)
norms = [x for x in m16.modules() if type(x).__name__.endswith("RMSNorm")]
sortie["3_production_bfloat16"] = {
    "normalisations": len(norms),
    "avec_forward_d_instance": sum("forward" in x.__dict__ for x in norms),
    "attribut_normalisations_en_double": getattr(m16, "normalisations_en_double", None),
    "classe_intacte": LlamaRMSNorm.forward is ORIGINE_FORWARD and LlamaRMSNorm.forward is not _rms_en_double,
    "forward_logique_est_la_version_double": all(x.forward.__func__ is _rms_en_double for x in m64.modules()
                                                  if type(x).__name__.endswith("RMSNorm")),
}
print(json.dumps(sortie, indent=1, ensure_ascii=False))
