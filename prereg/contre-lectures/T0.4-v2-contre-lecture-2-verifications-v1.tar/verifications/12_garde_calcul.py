"""Contre-lecture 2 (reprise) : la commande `vastai create` de la procédure (brouillon 2, section 4), extraite telle
quelle, passe-t-elle la garde de calcul du dépôt (`.claude/hooks/garde_calcul.py`, arbre gelé) ? Variante corrigée
(W-1) et témoin sans GO_ID. Rien n'est exécuté d'autre que la garde. Depuis la racine du clone."""
import json
import subprocess
import sys
from pathlib import Path

proc = Path("brouillons/procedure-validation-T0.4-modele-reel-v3-brouillon2.md").read_text(encoding="utf-8")
bloc = proc.split("## 4.")[1].split("```")[1]
cas = {"procédure (brouillon 2)": bloc,
       "variante corrigée (W-1)": bloc.replace("instance <offre> ", "instance <offre> --raw ").replace("  --raw 2>&1", "  2>&1"),
       "témoin sans GO_ID": bloc.replace("GO_ID=GO-2026-10-04-08 ", "")}
for nom, cmd in cas.items():
    r = subprocess.run([sys.executable, ".claude/hooks/garde_calcul.py"], input=json.dumps({"tool_input": {"command": cmd}}),
                       capture_output=True, text=True)
    print(f"{nom} : code {r.returncode} ; {r.stderr.strip() or 'passe'}")
