#!/usr/bin/env bash
# Contre-lecture 2 (reprise), point d : la commande `vastai create` de la procédure v3 (brouillon 2, section 4),
# extraite telle quelle du brouillon et interprétée par bash, avec un faux `vastai` (07_faux_vastai.py : vrai
# analyseur, vraie commande, vraie sortie de vastai 1.8.3 ; réseau bloqué ; jetons factices ; aucune clé réelle).
# On relève : ce que vastai comprend (--raw ? arguments du conteneur ?), ce que la session verrait à l'écran, et si
# un jeton factice y paraît. Variante corrigée : --raw placé avant --args.
set -u
ICI="$(cd "$(dirname "$0")" && pwd)"
DEPOT="$ICI/../depot"
PY=/home/user/controle-ia/.venv/bin/python
PROC="$DEPOT/brouillons/procedure-validation-T0.4-modele-reel-v3-brouillon2.md"
TMP="$(mktemp -d "$ICI/07_tmp.XXXX")"
# bloc de code de la section 4 (entre le premier ``` après « ## 4. » et le suivant)
awk '/^## 4\./{s=1} s&&/^```/{n++; next} s&&n==1{print}' "$PROC" > "$TMP/commande-procedure.sh"
sed -i 's/<offre>/12345/' "$TMP/commande-procedure.sh"
# variante corrigée : --raw juste après l'offre, retiré de la fin
sed -e 's/vastai create instance 12345 /vastai create instance 12345 --raw /' -e 's/^  --raw 2>&1 |/  2>\&1 |/' \
    "$TMP/commande-procedure.sh" > "$TMP/commande-corrigee.sh"
echo "== commande extraite de la procédure (sha256 du brouillon : $(sha256sum "$PROC" | cut -c1-16)…)"
cat "$TMP/commande-procedure.sh"
echo "== différence de la variante corrigée"
diff "$TMP/commande-procedure.sh" "$TMP/commande-corrigee.sh"
for variante in procedure corrigee; do
  for cas in succes erreur_http; do
    trace="$TMP/trace-$variante-$cas.jsonl"
    : > "$trace"
    ecran=$(cd "$DEPOT" && env -i PATH=/usr/bin:/bin HOME="$TMP" FAUX_TRACE="$trace" FAUX_CAS="$cas" \
        COMMIT=dc7aa7fcd6b5b0c676ec7365d2a194a3c1924efc HF_TOKEN=FAUX_HF_0123456789 \
        CONTROLE_IA_GITHUB_TOKEN=FAUX_GH_0123456789 PY="$PY" FAUX_VASTAI="$ICI/07_faux_vastai.py" \
        bash -c 'vastai() { "$PY" "$FAUX_VASTAI" "$@"; }; source "$0"' "$TMP/commande-$variante.sh" 2>&1)
    fuite=non
    for j in FAUX_HF_0123456789 FAUX_GH_0123456789 FAUX_CLE_INSTANCE_0123456789 FAUX_CLE_VAST_0123456789 0123456789; do
      case "$ecran" in *"$j"*) fuite=OUI;; esac
    done
    echo "== variante $variante, cas $cas"
    echo "   écran de la session : $ecran"
    echo "   jeton factice à l'écran : $fuite"
    "$PY" - "$trace" <<'EOF'
import json, sys
for ligne in open(sys.argv[1], encoding="utf-8"):
    t = json.loads(ligne)
    a = t["args_conteneur"]
    print(f"   vastai a compris : commande={t['commande']} ; raw={t['raw']} ; id={t['id']} ; image={t['image']} ; "
          f"disque={t['disk']} ; entrypoint={t['entrypoint']} ; env={'jetons factices présents' if 'FAUX_HF' in (t['env'] or '') else t['env']!r}")
    print(f"   arguments du conteneur : {len(a)} : {[x if len(x) < 40 else x[:30] + '…(' + str(len(x)) + ' car.)' for x in a]}")
EOF
  done
done
echo "== sortie brute de vastai sans --raw (cas succès), pour mémoire, jetons factices masqués"
( cd "$DEPOT" && env -i PATH=/usr/bin:/bin HOME="$TMP" FAUX_TRACE=/dev/null FAUX_CAS=succes \
    "$PY" "$ICI/07_faux_vastai.py" create instance 12345 --image x --args -c true --raw 2>&1 ) | sed 's/FAUX_[A-Z_]*[0-9]*/<factice>/g'
rm -rf "$TMP"
