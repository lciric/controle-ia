"""Contre-lecture 2 (reprise), point e (R6) : chaque chiffre du jouet cité par le brouillon 2 est recalculé depuis
les résumés scellés (empreinte vérifiée), et comparé à la valeur écrite (arrondie comme dans le texte).
À lancer depuis la racine du clone."""
import hashlib
import json
from pathlib import Path


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def resultat(run, nom="resume"):
    p = Path("diag") / run / f"{nom}.json"
    assert sha(p) == Path(str(p) + ".sha256").read_text().split()[0], p
    return json.loads(p.read_text())["resultat"]


def manifeste(run):
    return json.loads((Path("runs") / run / "manifeste.json").read_text())


def verifie(libelle, valeur, ecrit, chiffres=2):
    arrondi = float(f"{valeur:.{chiffres - 1}e}") if isinstance(valeur, float) else valeur
    ok = arrondi == ecrit
    print(f"{'OK ' if ok else 'ECART'} | {libelle} : calculé {valeur!r} -> {arrondi!r} ; écrit {ecrit!r}")
    return ok


tout = []
A, B = "20261005-134001-repetition-jouet", "20261005-134019-repetition-jouet"
a, b = resultat(A), resultat(B)
for run, x in ((A, a), (B, b)):
    print(f"== {run} (commit du manifeste {manifeste(run)['commit'][:12]}, entropie "
          f"{next(iter(manifeste(run)['graines'].values()))['entropie']})")
    lo, pr, cp = x["logique"]["equivalence"], x["production"]["equivalence"], x["controle_positif"]
    tout += [verifie("logique, écart maximal", lo["ecart_max"], 1.0e-15),
             verifie("logique, contexte", lo["max_contexte"], 2.7e-16),
             verifie("logique, zone générée", lo["max_zone_generee"], 1.0e-15),
             verifie("logique, contrôle négatif (passent, comparables)",
                     (lo["controle_negatif"]["passent"], lo["controle_negatif"]["comparables"]), (12, 12)),
             verifie("logique, contrôle négatif minimum", lo["controle_negatif"]["min_des_maxima"], 1.49, 3),
             verifie("contrôle positif (vus, comparables)", (cp["bilan"]["vus"], cp["bilan"]["comparables"]), (8, 8)),
             verifie("contrôle positif, minimum des maxima", cp["bilan"]["min_des_maxima"], 1.9e-4),
             verifie("contrôle positif, maximum du contexte", cp["bilan"]["max_contexte"], 2.5e-16),
             verifie("production, écart maximal", pr["ecart_max"], 1.5e-3),
             verifie("production, contrôle négatif (passent, comparables)",
                     (pr["controle_negatif"]["passent"], pr["controle_negatif"]["comparables"]), (11, 11)),
             verifie("production, contrôle négatif minimum", pr["controle_negatif"]["min_des_maxima"], 1.60, 3),
             verifie("repère de précision, maximum", max(v["max"] for v in x["production"]["repere_precision"].values()),
                     8.7e-3)]
    print("   chargement :", x["chargement"], "; T du contrôle positif :", cp["T"],
          "; T de la logique (configuration) :", manifeste(run)["config"]["logique"]["T"])
    print("   lecture :", x["lecture"])
    print("   pic de mémoire du contrôle positif :", cp.get("memoire_max_go"), "; zéros de la zone générée (logique) :",
          {c: z["generee"] for c, z in lo["zeros"].items()})
    traj = sorted((Path("diag") / run).glob("controle-positif-episode-*-trajectoire.json"))
    print("   trajectoires du contrôle positif écrites :", [t.name for t in traj])
c = resultat(B, f"comparaison-{A}")
print("== comparaison B contre A : identique =", c["identique"], "; lecture =", c["lecture"], "; différences =",
      c["differences"])
tout.append(c["identique"] is True)

print("== minimum des maxima de D1 aux autres codes (autres entropies)")
for code, run, ecrit in (("47d3c61", "20261005-122652-repetition-jouet", 2.3e-4),
                         ("6556b4e", "20261005-121017-repetition-jouet", 2.2e-4)):
    x = resultat(run)
    tout.append(verifie(f"code {code} ({run}), commit du manifeste {manifeste(run)['commit'][:12]}",
                        x["controle_positif"]["bilan"]["min_des_maxima"], ecrit))
print("== bilan :", "tous conformes" if all(tout) else "ÉCARTS")
