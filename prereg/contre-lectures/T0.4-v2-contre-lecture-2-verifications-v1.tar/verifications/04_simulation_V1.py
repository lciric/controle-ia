"""Contre-lecture 2 (reprise), point a : la correction de V-1 supprime-t-elle l'effet d'une réduction en simple
précision dont l'ordre dépendrait de la forme du lot ? Simulation sur processeur, code cité, autre méthode que celle
de la contre-lecture 1 et du premier contre-lecteur.

Méthode : un mode de répartition de PyTorch intercepte, pendant les seules passes de décodage (séquence de longueur 1),
toute moyenne ou somme en simple précision sur le dernier axe et la recalcule dans un autre ordre (huit sommes
partielles, additionnées en ordre inverse), toujours en simple précision. C'est un modèle « pire cas » d'une réduction
dont l'ordre change avec la forme (8 lignes au décodage, L en passe unique) ; ce n'est pas l'ordre réel d'un noyau de
carte. On joue la phase de logique de la répétition jouet (`jouer_phase`, `bilan_phase`, entropie de la répétition du
code cité), puis le contrôle positif (`decalage_positions = 1`), dans quatre variantes :
  A. modèle de la phase de logique (`charger`, double précision, normalisations remplacées), sans perturbation ;
  B. idem, avec la perturbation ;
  C. témoin : même modèle en double précision, normalisations de la bibliothèque, sans perturbation ;
  D. témoin avec la perturbation (effet de V-1 attendu : zone générée vers 1e-8, contexte au niveau de la double).
"""
import json
import sys

import torch
from torch.utils._python_dispatch import TorchDispatchMode

sys.path.insert(0, "src")
from controle_ia.harnais import validation_reelle as V            # noqa: E402
from controle_ia.harnais.modeles import modele_jouet               # noqa: E402
from controle_ia.manifeste import graines as G                     # noqa: E402

ENTROPIE = 40909144449802645773112999181067619237                  # répétition jouet du code cité (runs/20261005-134001)
MOYENNES = {"aten.mean.dim", "aten.sum.dim_IntList"}


class OrdreAutreAuDecodage(TorchDispatchMode):
    def __init__(self):
        super().__init__()
        self.interceptees = 0

    def __torch_dispatch__(self, func, types, args=(), kwargs=None):
        kwargs = kwargs or {}
        x = args[0] if args else None
        if (str(func) in MOYENNES and isinstance(x, torch.Tensor) and x.dtype == torch.float32 and x.dim() == 3
                and x.shape[1] == 1 and list(args[1]) in ([-1], [x.dim() - 1]) and x.shape[-1] % 8 == 0):
            self.interceptees += 1
            parts = x.reshape(*x.shape[:-1], 8, x.shape[-1] // 8).sum(-1)       # 8 sommes partielles (simple)
            s = parts[..., 7]
            for k in range(6, -1, -1):                                         # ordre inverse
                s = s + parts[..., k]
            s = s.unsqueeze(-1)
            if str(func) == "aten.mean.dim":
                s = s / x.shape[-1]
            keep = args[2] if len(args) > 2 else kwargs.get("keepdim", False)
            return s if keep else s.squeeze(-1)
        return func(*args, **kwargs)


def jouer(modele, fmt, config, graines, perturbe):
    c, cn, cp = config["logique"], config["controle_negatif"], config["controle_positif"]
    couches = V.couches_par_defaut(modele.config.num_hidden_layers)
    mode = OrdreAutreAuDecodage()
    if perturbe:
        mode.__enter__()
    try:
        sorties, _ = V.jouer_phase(modele, fmt, c, graines, "logique", couches)
        c_pc = dict(c, T=cp["T"])
        sorties_pc, _ = V.jouer_phase(modele, fmt, c_pc, graines, "controle-positif", couches, decalage_positions=1)
    finally:
        if perturbe:
            mode.__exit__(None, None, None)
    b = V.bilan_phase(sorties, c, cn)
    bp = V.bilan_controle_positif(sorties_pc, c_pc, cp)
    return {"moyennes_interceptees": mode.interceptees,
            "P2_ecart_max": b["ecart_max"], "P2_max_contexte": b["max_contexte"], "P2_max_zone_generee": b["max_zone_generee"],
            "P2_actions": b["actions_comparees"], "P3": [b["controle_negatif"]["passent"], b["controle_negatif"]["comparables"]],
            "P2b_vus": [bp["vus"], bp["comparables"]], "P2b_min_des_maxima": bp["min_des_maxima"],
            "P2b_max_contexte": bp["max_contexte"],
            "empreintes_capture": [r["empreintes_capture"] for _, _, r in sorties if r["ecarts"]]}


config = V.CONFIG_REPETITION
graines = G(V.taches(config), ENTROPIE)
sortie = {}
for nom, temoin, perturbe in (("A_logique", False, False), ("B_logique_perturbee", False, True),
                              ("C_temoin_bibliotheque", True, False), ("D_temoin_perturbe", True, True)):
    if temoin:
        tok = V.tokeniseur_caracteres_chat()
        m = modele_jouet(V.graine_entiere(graines["modele-jouet"]), len(tok), **config["modele_jouet"])
        m = m.to(torch.float64).eval()
    else:
        m, tok = V.charger(config, None, "float64", graines)
    fmt, _ = V.format_du_modele(m, tok, config)
    with torch.no_grad():
        sortie[nom] = jouer(m, fmt, config, graines, perturbe)
sortie["B_identique_a_A_au_bit_pres"] = sortie["A_logique"]["empreintes_capture"] == sortie["B_logique_perturbee"]["empreintes_capture"]
for k in ("A_logique", "B_logique_perturbee", "C_temoin_bibliotheque", "D_temoin_perturbe"):
    sortie[k].pop("empreintes_capture")
print(json.dumps(sortie, indent=1, ensure_ascii=False))
