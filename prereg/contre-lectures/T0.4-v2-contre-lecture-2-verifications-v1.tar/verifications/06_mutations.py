"""Contre-lecture 2 (reprise), point b : mutations ciblées du code cité (dc7aa7f), chacune dans une copie minimale
(`src`, `tests`, `pyproject.toml`) de mon clone ; on lance les tests du harnais (`test_validation_reelle.py`,
`test_harnais_lots.py`, `test_harnais.py`) et l'on relève si la mutation est vue (au moins un test en échec).
Chaque mutation exige que son motif apparaisse exactement le nombre de fois attendu (sinon : erreur, pas de repli).
Lancement : depuis la racine du clone ; sorties dans verifications/06_mutations/."""
import json
import os
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

CLONE = Path.cwd()
SORTIE = Path(__file__).resolve().parent / "06_mutations"
TRAVAIL = Path(__file__).resolve().parent / "06_mutations_copies"
VR, MO, EP, AC = ("src/controle_ia/harnais/validation_reelle.py", "src/controle_ia/harnais/modeles.py",
                  "src/controle_ia/harnais/episode.py", "src/controle_ia/harnais/activations.py")

MUTATIONS = {
    # demandées
    "M01_sans_normalisations_charger_modele": [(MO, "        modele = modele.to(torch.float64).to(appareil)\n        normalisations_en_double(modele)\n",
                                                "        modele = modele.to(torch.float64).to(appareil)\n", 1)],
    "M02_sans_normalisations_charger_jouet": [(VR, "        if dtype == \"float64\":\n            normalisations_en_double(m)\n",
                                               "        if dtype == \"float64\":\n            pass\n", 1)],
    "M03_normalisation_variance_simple": [(MO, "    variance = x.pow(2).mean(-1, keepdim=True)\n    return self.weight",
                                           "    variance = x.to(torch.float32).pow(2).mean(-1, keepdim=True)\n    return self.weight", 1)],
    "M03b_normalisation_formule_bibliotheque": [(MO, "    variance = x.pow(2).mean(-1, keepdim=True)\n    return self.weight * (x * torch.rsqrt(variance + self.variance_epsilon))",
                                                 "    h = x.to(torch.float32)\n    variance = h.pow(2).mean(-1, keepdim=True)\n    return self.weight * (h * torch.rsqrt(variance + self.variance_epsilon)).to(x.dtype)", 1)],
    "M04_ordre_des_gardes_inverse": [(VR, "        phase = \"logique\"\n        appliquer_gardes(sorties, resume[\"logique\"][\"equivalence\"], \"logique\", cn)\n        phase = \"controle_positif\"\n        exiger_controle_positif(resume[\"controle_positif\"][\"bilan\"], cp, \"contrôle positif\")\n",
                                      "        phase = \"controle_positif\"\n        exiger_controle_positif(resume[\"controle_positif\"][\"bilan\"], cp, \"contrôle positif\")\n        phase = \"logique\"\n        appliquer_gardes(sorties, resume[\"logique\"][\"equivalence\"], \"logique\", cn)\n", 1)],
    "M05_trajectoires_du_controle_positif_non_ecrites": [(VR, "        for ep, _, _ in sorties_pc:\n            ecrire_resultat(racine, chemin_m, f\"controle-positif-{ep.identifiant}-trajectoire\", ep.en_dict())\n", "", 1)],
    "M06_pic_du_controle_positif_compare": [(VR, "if k not in (\"debit\", \"memoire_max_go\")}", "if k not in (\"debit\",)}", 1)],
    # complémentaires
    "M07_remplacement_sur_la_classe": [(MO, "            m.forward = types.MethodType(_rms_en_double, m)\n",
                                        "            type(m).forward = _rms_en_double\n", 1)],
    "M08_normalisations_aussi_en_production_jouet": [(VR, "        if dtype == \"float64\":\n            normalisations_en_double(m)\n",
                                                      "        normalisations_en_double(m)\n", 1),
                                                     (MO, "            if m.weight.dtype != torch.float64:\n", "            if False:\n", 1)],
    "M09_controle_positif_apres_les_gardes": [(VR, "        phase = \"controle_positif\"\n        temps()\n", "        appliquer_gardes(sorties, resume[\"logique\"][\"equivalence\"], \"logique\", cn)\n        phase = \"controle_positif\"\n        temps()\n", 1)],
    "M10_T_de_la_logique": [(VR, "        c_pc = dict(c, T=cp[\"T\"])\n", "        c_pc = dict(c)\n", 1)],
    "M11_graines_de_la_logique": [(VR, "jouer_phase(modele, fmt, c_pc, graines, \"controle-positif\", couches",
                                   "jouer_phase(modele, fmt, c_pc, graines, \"logique\", couches", 1)],
    "M12_ulp_de_simple_precision": [(AC, "    p[n, 0] = np.nextafter(p[n, 0], p.dtype.type(np.inf), dtype=p.dtype)",
                                     "    p[n, 0] = np.nextafter(np.float32(p[n, 0]), np.float32(np.inf))", 1)],
    "M13_max_contexte_lu_dans_la_zone_generee": [(VR, "            contextes += [p[\"contexte\"][\"max\"] for p in r[\"profils\"][cle].values() if p[\"contexte\"][\"jetons\"]]",
                                                  "            contextes += [p[\"generee\"][\"max\"] for p in r[\"profils\"][cle].values() if p[\"generee\"][\"jetons\"]]", 1)],
    "M14_pic_non_remis_a_zero_avant_le_controle_positif": [(VR, "        if torch.cuda.is_available():\n            torch.cuda.reset_peak_memory_stats()                     # pic propre au contrôle positif\n", "", 1)],
    "M15_nombre_de_normalisations_non_consigne": [(VR, ",\n                                \"normalisations_en_double\": getattr(modele, \"normalisations_en_double\", 0)}", "}", 1)],
    "M16_garde_au_moins_une_normalisation_retiree": [(MO, "    if n == 0:\n        raise GardeArret(\"aucune normalisation RMS dans le modèle : structure inattendue\")\n", "", 1)],
    "M17_garde_de_carte_75_Gio": [(VR, "    \"memoire_carte_min_gio\": 130,", "    \"memoire_carte_min_gio\": 75,", 1)],
    "M18_memoire_vive_64_Go": [(VR, "    \"memoire_vive_min_go\": 96,", "    \"memoire_vive_min_go\": 64,", 1)],
    "M19_comparaison_sans_le_chargement": [(VR, "    for cle in (\"reglages\", \"chargement\", \"format\"):", "    for cle in (\"reglages\", \"format\"):", 1)],
}
TESTS = ["tests/test_validation_reelle.py", "tests/test_harnais_lots.py", "tests/test_harnais.py"]


def preparer(nom, edits):
    d = TRAVAIL / nom
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    for x in ("src", "tests"):
        shutil.copytree(CLONE / x, d / x, ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy(CLONE / "pyproject.toml", d / "pyproject.toml")
    for fichier, avant, apres, n in edits:
        f = d / fichier
        t = f.read_text(encoding="utf-8")
        if t.count(avant) != n:
            raise SystemExit(f"{nom} : motif trouvé {t.count(avant)} fois au lieu de {n} dans {fichier}")
        f.write_text(t.replace(avant, apres), encoding="utf-8")
    return d


def lancer(nom):
    d = TRAVAIL / nom if nom != "M00_temoin_sans_mutation" else preparer(nom, [])
    env = dict(os.environ, PYTHONPATH="src", OMP_NUM_THREADS="2", MKL_NUM_THREADS="2")
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "-rf", *TESTS], cwd=d,
                       capture_output=True, text=True, env=env)
    (SORTIE / f"{nom}.pytest.txt").write_text(r.stdout + "\n--- stderr ---\n" + r.stderr, encoding="utf-8")
    lignes = [x for x in r.stdout.strip().splitlines() if x.strip()]
    echecs = sorted({x.split(" - ")[0].replace("FAILED ", "") for x in lignes if x.startswith("FAILED ")})
    return {"mutation": nom, "derniere_ligne": lignes[-1] if lignes else "", "vue": r.returncode != 0,
            "code": r.returncode, "tests_en_echec": echecs}


if __name__ == "__main__":
    SORTIE.mkdir(exist_ok=True)
    noms = ["M00_temoin_sans_mutation"]
    for nom, edits in MUTATIONS.items():
        preparer(nom, edits)
        noms.append(nom)
    with ThreadPoolExecutor(max_workers=2) as ex:
        resultats = list(ex.map(lancer, noms))
    (SORTIE / "resultats.json").write_text(json.dumps(resultats, indent=1, ensure_ascii=False), encoding="utf-8")
    for r in resultats:
        print(f"{r['mutation']:<52} {'VUE' if r['vue'] else 'non vue':<8} {r['derniere_ligne']}")
        for t in r["tests_en_echec"]:
            print(f"{'':<54}- {t}")
    shutil.rmtree(TRAVAIL)
