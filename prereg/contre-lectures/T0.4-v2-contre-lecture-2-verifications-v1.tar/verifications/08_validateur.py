"""Contre-lecture 2 (reprise), point f : `problemes()` de `controle_ia.prereg` (code cité) sur le brouillon 2, tel
quel, puis avec l'entrée « Contre-lecture 2 » remplie (deux empreintes factices distinctes) ; citations lues par le
lanceur (commit, révision, entropie) et par la procédure (`sed`/`git log`). Copies temporaires seulement.
À lancer depuis la racine du clone, PYTHONPATH=src."""
import re
import shutil
import tempfile
from pathlib import Path

from controle_ia import prereg
from controle_ia.harnais import validation_reelle as V

B2 = Path("brouillons/T0.4-validation-modele-reel-v2-brouillon2.md")
texte = B2.read_text(encoding="utf-8")
with tempfile.TemporaryDirectory() as d:
    tel_quel = Path(d) / "tel-quel.md"
    shutil.copy(B2, tel_quel)
    print("1. brouillon 2 tel quel :", prereg.problemes(tel_quel))
    rempli = Path(d) / "rempli.md"
    rempli.write_text(texte.replace(
        "- **Contre-lecture 2** (sous-agent neuf, différentiel `47d3c61..dc7aa7f` et passages modifiés) : À REMPLIR.",
        "- **Contre-lecture 2** (sous-agent neuf) : rapport `" + "a" * 64 + "`, vérifications `" + "b" * 64 + "`."),
        encoding="utf-8")
    print("2. entrée « Contre-lecture 2 » remplie (deux empreintes) :", prereg.problemes(rempli))
    une = Path(d) / "une.md"
    une.write_text(texte.replace(
        "- **Contre-lecture 2** (sous-agent neuf, différentiel `47d3c61..dc7aa7f` et passages modifiés) : À REMPLIR.",
        "- **Contre-lecture 2** (sous-agent neuf) : rapport `" + "a" * 64 + "`."), encoding="utf-8")
    print("3. témoin : entrée remplie d'une seule empreinte :", prereg.problemes(une))
print("4. citations :")
for nom, motif in (("commit", V.COMMIT_CITE), ("révision", V.REVISION_CITEE), ("entropie", V.ENTROPIE_CITEE)):
    trouves = motif.findall(texte)
    print(f"   {nom} : {trouves} ({len(trouves)} occurrence(s))")
print("   « Contre-lecture k » reconnues :", [m.group(1) for m in prereg.ENTREE.finditer(prereg.sections(texte)["Contre-lecture"])])
print("   marqueurs « À REMPLIR » dans le texte :", texte.count(prereg.MARQUEUR))
print("   tests attendus cités (P0, Seuil, en-tête) :", sorted(set(re.findall(r"(\d+) tests", texte))),
      "; configuration :", V.CONFIG_REELLE["tests_attendus"])
