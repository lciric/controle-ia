"""Contre-lecture 2 (reprise), point d : le brouillon 2 écrit (l. 123 et 341) que, sur processeur, les sommes des
produits matriciels « ne dépendent pas de la forme du lot », d'où une répétition jouet qui ne prédit pas la carte.
On teste, en double précision, sur ce processeur : une même ligne multipliée seule ou dans un lot de 8 (ou de L
lignes), par `torch.nn.functional.linear` (chemin des projections du modèle) ; et la contribution de la passe unique
contre la génération sur le modèle jouet (zéros exacts ou non). Processeur seulement."""
import json
import sys

import torch

sys.path.insert(0, "src")
torch.manual_seed(0)
torch.set_num_threads(1)
sortie = {"threads": torch.get_num_threads()}
for largeur, sorties in ((32, 32), (64, 128), (512, 512), (4096, 4096), (4096, 14336)):
    W = torch.randn(sorties, largeur, dtype=torch.float64)
    x = torch.randn(64, largeur, dtype=torch.float64)
    seule = torch.nn.functional.linear(x[:1], W)[0]
    res = {}
    for m in (2, 3, 4, 8, 16, 64):
        lot = torch.nn.functional.linear(x[:m], W)[0]
        res[f"lot de {m}"] = float((lot - seule).abs().max())
    sortie[f"linear {largeur}->{sorties}, ligne seule contre ligne 0 d'un lot"] = res
# même chose en simple précision (pour comparaison)
W = torch.randn(4096, 4096)
x = torch.randn(8, 4096)
sortie["simple précision 4096->4096, lot de 8 contre ligne seule"] = float(
    (torch.nn.functional.linear(x, W)[0] - torch.nn.functional.linear(x[:1], W)[0]).abs().max())
# moyenne sur le dernier axe (normalisation RMS) : invariance vue par la contre-lecture 1
h = torch.randn(64, 4096)
sortie["moyenne simple précision, ligne seule contre lot de 64"] = float(
    (h.pow(2).mean(-1)[0] - h[:1].pow(2).mean(-1)[0]).abs())
print(json.dumps(sortie, indent=1, ensure_ascii=False))
