#!/usr/bin/env bash
# Contre-lecture 2 (reprise) : empreintes citées par les brouillons 2, arbre gelé, scripts.
# Lancé depuis la racine du clone. Lecture seule.
set -u
cd "$(dirname "$0")/../depot"
echo "== tete du clone : $(git rev-parse HEAD)"
echo "== tete du depot de reference : $(git -C /home/user/controle-ia --no-optional-locks rev-parse HEAD)"
verifie() {  # chemin empreinte_attendue
  local obs; obs=$(sha256sum "$1" | cut -d' ' -f1)
  local comp=""; [ -f "$1.sha256" ] && comp=$(cut -d' ' -f1 "$1.sha256")
  local st="NON CONFORME"; [ "$obs" = "$2" ] && st="conforme"
  local stc="(pas de compagnon)"; [ -n "$comp" ] && { [ "$comp" = "$obs" ] && stc="compagnon conforme" || stc="COMPAGNON DIFFERENT"; }
  echo "$st | $stc | $1 | $obs"
}
echo "== brouillons relus"
verifie brouillons/T0.4-validation-modele-reel-v2-brouillon2.md 71b4c4113f4c98f856c2fd87f6c25ae497a661d73ce3781dbae9d7aeedefc059
verifie brouillons/procedure-validation-T0.4-modele-reel-v3-brouillon2.md 7e447c65efb04d1300ab8a69c451c74224b107b47e604375219f088182d1509e
echo "== brouillons 1 (cites par l'entree Contre-lecture 1)"
verifie brouillons/T0.4-validation-modele-reel-v2-brouillon1.md b50fb4fedc04dca870f640cc263f1a3318196a29ab9f195664194ee5a9a0636e
verifie brouillons/procedure-validation-T0.4-modele-reel-v3-brouillon1.md d95511b2b349993f710b9d06acbca1cd8639b8067b6526169eb88832ce4160a4
echo "== contre-lecture 1"
verifie prereg/contre-lectures/T0.4-v2-rapport-contre-lecture-1-v1.md d3fce4a7a8cc437f54e8cee507fcebee47c7c8ac99bd991cfda8def8294e2092
verifie prereg/contre-lectures/T0.4-v2-contre-lecture-1-verifications-v1.tar 67ba96aafe2a78f38b1800d3c8f121a768adf64faa17d54d86e821313a747ba6
echo "== documents cites en tete"
verifie prereg/T0.4-validation-modele-reel-v1.md 3d0589c80fe97b134b193a797881395ec710966867c47ca9e87506c187cb8c96
verifie docs/verdicts/verdict-T0.4-critere-1-G0-v1.md fb9919f9c4d7d73fd03bdcf65e03ef2492dd1951d4ffb10b43cd08d1e361f277
verifie docs/decisions/proposition-N-010-v1.md 06b4ff5627abd03c6708ea628b157d2c90d03b853be8d24a0d80e3b299bbe0ef
verifie docs/brief-claude-code-programme-complet-v2.md 9261932a11f29e8643175bc6e150d5455067f58a3cb1e57dca99e02cb17aa3b2
verifie docs/programme-controle-ia-v2.md 2fd63badb5afea48f48d3ca501ae3b027c4094a8b176508488a41a22e45aa18c
verifie livrables/premier-rendu-v1/devis-v1.md 16d71febf1491780ab1230ed1fb8e4d8b1bec47fbed202e0ef26ca666def04c2
verifie docs/notes/memoire-double-precision-T0.4-v1.md b013428ab8502a61a3ea19404ea3a6cdc64ea6a587010c45627e33f13ef29148
verifie docs/procedures/validation-T0.4-modele-reel-v2.md e8a596c35f4f5e57c102f247cd39feed7debed8860b47ed2cb12d9bbcd7eb634
echo "== transparence"
verifie diag/20261005-102042-validation-reelle/arret.json 4eb2d92069e270631bf3e4d25345b44191cbe419d71a4f06725659c32846aeed
verifie traces/t04-20261005-121227-nRet/sonde-memoire.json 85b186bd42ad8120ebc1c9974e853645677060c5e5e787714c142c788274a45a
verifie diag/20261005-121017-repetition-jouet/resume.json e2e4369bb6af1c250b6b12186dcba37574a60165da6befd01425c0ade8920ac1
verifie diag/20261005-121053-repetition-jouet/resume.json acb709d71f0982f0c12598cc85d61895ff7b494732bcdc1d7e24ebbe28d28a13
verifie diag/20261005-121053-repetition-jouet/comparaison-20261005-121017-repetition-jouet.json 6b43cc444b9786bf1c3b3efdb7e5a3b2cb03b52359e03828ed2dc8221e9a0f2b
verifie diag/20261005-122652-repetition-jouet/resume.json 0203d4607dad4c6364fa6e67bd3a4dd3e92526283eecc20d4a7443caa8abfa57
verifie diag/20261005-122708-repetition-jouet/resume.json 1d07215f6b72a2d2c2ec93e52086c07cea2c430fdadd959ab180bda802c1e5f1
verifie diag/20261005-122708-repetition-jouet/comparaison-20261005-122652-repetition-jouet.json fac3b1bf3f35e9670b0adc6b9e08a0aa2060dac6897057f6174783d75d33bf42
verifie diag/20261005-134001-repetition-jouet/resume.json 16a4b624061dc477e26f1d32e2d9191775645933f7b9b709f52821e5d1a8327a
verifie diag/20261005-134019-repetition-jouet/resume.json 6058c5c67d756bba75fdbf5d78bff4996f0cf38eab8a7d73a090137a4b183bac
verifie diag/20261005-134019-repetition-jouet/comparaison-20261005-134001-repetition-jouet.json cc0b509b9762c535c8dac2e26dfd6ed131c6937089cc04c07094947b73d9208a
verifie diag/essais-amorce-T0.4/essais-amorce-T0.4-v2-v2.tar cdd7807454915f3d5d6dd9ae8b93305b586db7750c47c2b437a73c8729adb90a
verifie diag/essais-amorce-T0.4/essais-amorce-T0.4-v2-v1.tar 5090e2eb1780c306ca084e00e6b2c922e009214d674c5e6958144c6c4c3442a8
echo "== scripts de l'instance (commit cite, tete, disque) et inchanges 47d3c61..dc7aa7f"
for f in scripts/validation_t04_instance.sh scripts/amorce_instance_t04.sh; do
  echo "$f : cite=$(git show dc7aa7f:$f | sha256sum | cut -c1-64) tete=$(git show HEAD:$f | sha256sum | cut -c1-64) disque=$(sha256sum $f | cut -c1-64)"
  git diff --quiet 47d3c61 dc7aa7f -- "$f" && echo "  inchange 47d3c61..dc7aa7f" || echo "  CHANGE 47d3c61..dc7aa7f"
done
echo "== arbre gele dc7aa7f..HEAD (exclusions du preenregistrement ; vide attendu)"
git diff --stat dc7aa7fcd6b5b0c676ec7365d2a194a3c1924efc HEAD -- . ':(exclude)prereg' ':(exclude)brouillons' \
  ':(exclude)registres' ':(exclude)docs' ':(exclude)diag' ':(exclude)runs' ':(exclude)donnees' ':(exclude)livrables' \
  ':(exclude)papiers' ':(exclude)traces' ':(exclude)CLAUDE.md'
echo "(fin)"
echo "== meme controle sur le depot de reference"
git -C /home/user/controle-ia --no-optional-locks diff --stat dc7aa7fcd6b5b0c676ec7365d2a194a3c1924efc HEAD -- . ':(exclude)prereg' ':(exclude)brouillons' \
  ':(exclude)registres' ':(exclude)docs' ':(exclude)diag' ':(exclude)runs' ':(exclude)donnees' ':(exclude)livrables' \
  ':(exclude)papiers' ':(exclude)traces' ':(exclude)CLAUDE.md'
echo "(fin)"
echo "== exclusions identiques a CHEMINS_GELES ?"
grep -n -A2 '^CHEMINS_GELES' src/controle_ia/harnais/validation_reelle.py
echo "== sha256sum -c des archives et dossiers de traces cites"
( cd traces/t04-20261005-121227-nRet && sha256sum -c empreintes.sha256 )
echo "== verifier-arbre"
PYTHONPATH=src python -m controle_ia.scellement verifier-arbre . 2>&1 | tail -3
echo "== empreintes de lancement"
( cd docs && sha256sum -c sha256sums-lancement-v2.txt )
