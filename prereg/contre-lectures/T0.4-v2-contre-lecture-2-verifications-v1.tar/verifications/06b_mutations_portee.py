"""Contre-lecture 2 (reprise), point b, complément : portée du remplacement des normalisations.
- M07b : remplacement sur la classe (comme M07), mais `test_normalisations_en_double` lancé seul : l'assertion
  « la classe n'est pas touchée » voit-elle la mutation sans l'aide des tests joués avant elle ?
- M08b : la production du jouet hérite des normalisations remplacées (la garde de type reste intacte) : un test
  voit-il que la production ne garde plus les calculs ordinaires de la bibliothèque ?
Même méthode que 06_mutations.py (copie minimale, motif exigé une fois). Depuis la racine du clone."""
import importlib.util
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ICI = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("mut", ICI / "06_mutations.py")
mut = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mut)
mut.TRAVAIL = ICI / "06b_copies"
VR, MO = mut.VR, mut.MO
cas = {
    "M07b_classe_test_seul": ([(MO, "            m.forward = types.MethodType(_rms_en_double, m)\n",
                                "            type(m).forward = _rms_en_double\n", 1)],
                              ["tests/test_validation_reelle.py::test_normalisations_en_double"]),
    "M07c_temoin_test_seul": ([], ["tests/test_validation_reelle.py::test_normalisations_en_double"]),
    "M08b_production_herite_des_normalisations": (
        [(VR, "        m = m.to(getattr(torch, dtype))\n        if dtype == \"float64\":\n            normalisations_en_double(m)\n",
          "        normalisations_en_double(m.to(torch.float64))\n        m = m.to(getattr(torch, dtype))\n", 1)],
        mut.TESTS),
}
resultats = []
for nom, (edits, tests) in cas.items():
    d = mut.preparer(nom, edits)
    env = dict(os.environ, PYTHONPATH="src", OMP_NUM_THREADS="2", MKL_NUM_THREADS="2")
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "-rf", *tests], cwd=d,
                       capture_output=True, text=True, env=env)
    (mut.SORTIE / f"{nom}.pytest.txt").write_text(r.stdout + "\n--- stderr ---\n" + r.stderr, encoding="utf-8")
    lignes = [x for x in r.stdout.strip().splitlines() if x.strip()]
    resultats.append({"mutation": nom, "vue": r.returncode != 0, "derniere_ligne": lignes[-1] if lignes else "",
                      "tests_en_echec": sorted({x.split(" - ")[0].replace("FAILED ", "") for x in lignes
                                                if x.startswith("FAILED ")})})
shutil.rmtree(mut.TRAVAIL)
(mut.SORTIE / "resultats-portee.json").write_text(json.dumps(resultats, indent=1, ensure_ascii=False), encoding="utf-8")
for r in resultats:
    print(f"{r['mutation']:<45} {'VUE' if r['vue'] else 'non vue':<8} {r['derniere_ligne']} {r['tests_en_echec']}")
