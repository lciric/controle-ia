"""Faux `vastai` pour la contre-lecture 2 (reprise), point d : le vrai analyseur d'arguments, la vraie commande
`create instance` et la vraie mise en forme de la sortie de vastai 1.8.3 (installé dans .venv), sans réseau.

- Réseau bloqué avant tout import (socket.connect, create_connection, requests) : l'import des commandes, qui
  interroge sinon le service pour les noms de cartes, échoue proprement et rend None.
- Seul l'appel HTTP de création est remplacé (`instances_api.create_instance_from_payload`) par une réponse factice
  selon FAUX_CAS : « succes » (réponse JSON du service, avec une fausse clé d'instance) ou « erreur_http » (HTTPError
  dont le message recopie la requête, jetons factices compris).
- Le résultat de l'analyse (raw, args passés au conteneur, env) est écrit dans le fichier FAUX_TRACE, pas à l'écran.
- Aucun jeton réel : le pilote lance ce script avec des jetons factices et sans VAST_API_KEY.
"""
import json
import os
import socket
import sys


def _bloque(*a, **k):
    raise OSError("réseau bloqué (contre-lecture)")


socket.socket.connect = _bloque
socket.create_connection = _bloque
import requests  # noqa: E402


def _requete_bloquee(*a, **k):
    raise requests.exceptions.ConnectionError("réseau bloqué (contre-lecture)")


requests.get = requests.post = requests.put = requests.request = _requete_bloquee
requests.Session.request = lambda self, *a, **k: _requete_bloquee()

import vastai.cli.main as M  # noqa: E402
from vastai.cli.commands import (instances, offers, machines, teams, keys, endpoints, billing, storage,  # noqa: E402,F401
                                 auth, misc, deployments, metrics, benchmarks, price_increase, repl, update, uninstall)
from vastai.api import instances as instances_api  # noqa: E402

# options globales, recopiées de vastai/cli/main.py (l. 135-143), --api-key sans valeur par défaut lue
p = M.parser
p.add_argument("--url", help="Server REST API URL", default="https://bloque.invalid")
p.add_argument("--retry", help="Retry limit", type=int, default=3)
p.add_argument("--explain", action="store_true")
p.add_argument("--raw", action="store_true", help="Output machine-readable json")
p.add_argument("--full", action="store_true")
p.add_argument("--curl", action="store_true")
p.add_argument("--api-key", type=str, required=False, default=None)
p.add_argument("--no-color", action="store_true")

args = p.parse_args(sys.argv[1:])
with open(os.environ["FAUX_TRACE"], "a", encoding="utf-8") as f:
    f.write(json.dumps({"commande": getattr(args, "func", None).__name__, "raw": args.raw, "args_conteneur": args.args,
                        "env": args.env, "entrypoint": args.entrypoint, "image": args.image, "disk": args.disk,
                        "id": args.id}, ensure_ascii=False) + "\n")

cas = os.environ.get("FAUX_CAS", "succes")


class _Reponse:
    status_code = 400

    def json(self):
        return {"msg": f"invalid request: {{'env': {args.env!r}}}"}


def _creation(client, id, json_blob):
    if cas == "erreur_http":
        raise requests.exceptions.HTTPError(response=_Reponse())
    return {"success": True, "new_contract": 99887766, "instance_api_key": "FAUX_CLE_INSTANCE_0123456789"}


instances_api.create_instance_from_payload = _creation
instances.get_client = lambda a: None
args.api_key = "FAUX_CLE_VAST_0123456789"
M.run_command(args)                                     # vraie sortie (JSON si --raw, sinon « Started. {…} »)
