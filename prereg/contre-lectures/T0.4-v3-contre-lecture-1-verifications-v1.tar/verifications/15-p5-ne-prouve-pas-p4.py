"""Contre-lecture R2 de la v3 de T0.4. Le contrôle négatif de la production (P5) lit le 99e centile de l'écart décalé
dans la ZONE GÉNÉRÉE seule ; la garde P4 lit le 99e centile de l'écart sur TOUTES les positions de l'action (contexte et
zone générée). Le maximum croît avec l'ensemble des positions ; le 99e centile non. Un désalignement confiné à la zone
générée peut donc laisser P5 conforme et P4 aveugle.

1. Démonstration avec les fonctions du code cité (activations.py au commit 2457743), sur des tableaux synthétiques.
2. Sur les longueurs réelles de la production de la v2 (arret.json scellé e3ca201e…) : pour chaque action comparée,
   nombre de positions de la zone générée et nombre minimal de positions au-dessus du seuil pour que le 99e centile
   (interpolation linéaire) le dépasse.

Usage : PYTHONPATH=<arbre>/src python 15-p5-ne-prouve-pas-p4.py <clone>
"""
import json
import sys
from pathlib import Path

import numpy as np

from controle_ia.harnais.activations import ecart_decale_zone_generee, ecart_equivalence

rng = np.random.default_rng(0)
W = 64


def action(lc, m):
    """Passe unique p (lc + m positions) ; génération saine g = p + bruit d'arrondi ≈ 1,5 % par jeton ; génération
    fautive g_def : la même, mais sa zone générée est décalée d'un jeton (g_n = p_{n-1} + bruit), désalignement
    confiné à la zone générée."""
    n = lc + m
    p = rng.standard_normal((n, W))
    g = p * (1 + 0.015 * rng.standard_normal((n, 1)))
    g_def = g.copy()
    g_def[lc:] = p[lc - 1:n - 1] * (1 + 0.015 * rng.standard_normal((m, 1)))
    return {7: g}, {7: g_def}, {7: p}


print("# 1. démonstration (seuil de production 0,2)")
print("#    P5 se calcule sur la génération SAINE du run (contrôle négatif) ; P4 est la garde qui devrait voir la")
print("#    génération FAUTIVE (zone générée décalée d'un jeton).")
for lc, m in ((300, 40), (1000, 40), (1000, 12), (2000, 15), (3000, 20)):
    g, g_def, p = action(lc, m)
    p4_sain = ecart_equivalence(g, p, quantile=0.99)[7]           # P4 sur la génération saine
    cn = ecart_decale_zone_generee(g, p, lc, 0.2)[7]              # P5 sur la génération saine
    p4_def = ecart_equivalence(g_def, p, quantile=0.99)[7]        # P4 sur la génération fautive
    mx_def = ecart_equivalence(g_def, p)[7]                       # maximum (garde de la v2) sur la fautive
    print(f"contexte {lc:5d}, zone générée {m:3d} ({100 * m / (lc + m):4.1f} %) : sain : P4 {p4_sain:.3f} "
          f"(conforme), P5 {cn['q99']:.3f} ({'passe' if cn['q99'] > 0.2 else 'échoue'}) | fautif : P4 {p4_def:.3f} -> "
          f"{'VU' if p4_def > 0.2 else 'NON VU'} (maximum {mx_def:.2f} -> {'VU' if mx_def > 0.2 else 'NON VU'})")

print("\n# 2. longueurs réelles de la production de la v2 (40 actions comparées)")
D = Path(sys.argv[1])
p = json.loads((D / "diag/20261005-144628-validation-reelle/arret.json").read_text())["resultat"]["partiel"]
lignes = []
for e in p["production"]["episodes"]:
    r = e["equivalence"]
    for cle in r["ecarts"]:
        n = r["positions_capturees"][cle]
        lc = r["longueurs_contexte"][cle]
        m = n - lc
        h = 0.99 * (n - 1)
        k = n - int(np.floor(h))          # positions au-dessus du seuil nécessaires (sans compter l'interpolation)
        lignes.append((m / n, e["episode"], cle, lc, m, n, k))
lignes.sort()
for frac, ep, cle, lc, m, n, k in lignes[:6]:
    print(f"{ep} ({cle}) : contexte {lc}, zone générée {m} ({100 * frac:.1f} %), positions {n} ; "
          f"il faut au moins {k} positions au-dessus du seuil ; marge {m - k}")
print(f"actions où la zone générée compte moins de positions que le nombre nécessaire : "
      f"{sum(1 for x in lignes if x[4] < x[6])} sur {len(lignes)}")
print(f"plus petite fraction de zone générée : {100 * lignes[0][0]:.2f} % ; plus grand contexte : "
      f"{max(x[3] for x in lignes)} ; plus petite zone générée : {min(x[4] for x in lignes)}")
