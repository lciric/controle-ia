"""1. problemes() du validateur (prereg.py au code cité) sur le brouillon 1 du préenregistrement v3.
2. Lignes de la table gelée de la v2 absentes de la table du brouillon v3 ; lignes « P4 contraire » et « P2b contraire »
   des deux versions.
Usage : PYTHONPATH=<arbre>/src python -I 16-validateur-et-table.py <clone>"""
import re
import sys
from pathlib import Path

from controle_ia.prereg import SECTIONS, problemes

D = Path(sys.argv[1])
v2 = (D / "prereg/T0.4-validation-modele-reel-v2.md").read_text(encoding="utf-8")
v3 = (D / "brouillons/T0.4-validation-modele-reel-v3-brouillon1.md").read_text(encoding="utf-8")
print("# 1. validateur")
print("sections exigées :", SECTIONS)
print("problemes(brouillon v3) :", problemes(D / "brouillons/T0.4-validation-modele-reel-v3-brouillon1.md"))


def table(texte):
    debut = texte.index("## Critères de lecture gelés")
    fin = texte.index("## Liste d'arrêt")
    return [l for l in texte[debut:fin].splitlines() if l.startswith("| ") and not l.startswith("| issue")]


t2, t3 = table(v2), table(v3)
print("\n# 2. tables : v2", len(t2), "lignes ; v3", len(t3), "lignes")
premiere = lambda l: l.split("|")[1].strip()            # noqa: E731
p3 = {premiere(l) for l in t3}
for l in t2:
    if premiere(l) not in p3:
        print("ligne v2 sans équivalent littéral en v3 :", premiere(l)[:160])
for motif in ("P4 contraire", "P2b contraire"):
    for nom, t in (("v2", t2), ("v3", t3)):
        for l in t:
            if premiere(l).startswith(motif):
                print(f"\n[{nom}] {l[:900]}")
print("\nP3 cité dans la condition de la ligne P4 contraire de la v3 :",
      bool(re.search(r"P3", [l for l in t3 if premiere(l).startswith("P4 contraire")][0])))
print("branche « sinon » (non concluant) dans la ligne P4 contraire de la v3 :",
      "non concluant" in [l for l in t3 if premiere(l).startswith("P4 contraire")][0])
print("« non atteint » lu par une ligne de la table v3 :", any("non atteint" in l for l in t3))
