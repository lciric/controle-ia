"""Rapport au repère ρ_ℓ (plus grand 99e centile par action de la production, toutes positions, à la couche ℓ, divisé
par le 99e centile du repère à la même couche), calculé comme le juge devra le faire, sur les répétitions jouet du code
cité et sur la v2 (noyaux par défaut). Usage : python -I 18-rho-jouet.py <clone>"""
import json, sys
from pathlib import Path
D = Path(sys.argv[1])
for run in ("20261006-092650-repetition-jouet", "20261006-091344-repetition-jouet"):
    r = json.loads((D / "diag" / run / "resume.json").read_text())["resultat"]
    rep = r["production"]["repere_precision"]
    best = {}
    for e in r["production"]["episodes"]:
        for cle, par_couche in e["equivalence"].get("ecarts_q99", {}).items():
            for c, v in par_couche.items():
                best[c] = max(best.get(c, 0.0), v)
    print(run, {c: f"ρ = {best[c] / rep[c]['q99']:.2f} ({best[c]:.2e} / {rep[c]['q99']:.2e})" for c in sorted(best)})
a = json.loads((D / "diag/20261005-144628-validation-reelle/arret.json").read_text())["resultat"]["partiel"]
rep = a["production"]["repere_precision"]
best = {}
for e in a["production"]["episodes"]:
    eq = e["equivalence"]
    for cle in eq["ecarts"]:
        for c, prof in eq["profils"][cle].items():
            best[c] = max(best.get(c, 0.0), prof["q99"])
print("v2 (modèle réel, noyaux par défaut)", {c: f"ρ = {best[c] / rep[c]['q99']:.2f}" for c in sorted(best, key=int)})
