"""Chiffres de la v1 cités par le brouillon v3 et par la note de mémoire au noyau « math » (seuil du chemin).
Usage : python -I 11-recalculs-v1.py <clone>"""
import json, sys
from pathlib import Path
import numpy as np
D = Path(sys.argv[1])
a = json.loads((D / "diag/20261005-102042-validation-reelle/arret.json").read_text())["resultat"]
p = a["partiel"]
print("phase", a["phase"], "; motif", a["motif"][:90])
lg = p["logique"]
eq = lg["equivalence"]
print("ecart_max", eq["ecart_max"], "contexte", eq["max_contexte"], "zone générée", eq["max_zone_generee"])
par_couche, q50 = {}, {}
for e in lg["episodes"]:
    r = e["equivalence"]
    for cle, prof in r["profils"].items():
        for c, v in prof.items():
            par_couche[c] = max(par_couche.get(c, 0), v["max"])
            q50.setdefault(c, []).append(v["q50"])
print("maxima par couche :", {c: f"{v:.3e}" for c, v in sorted(par_couche.items(), key=lambda x: int(x[0]))})
print("médiane des q50 par couche :", {c: f"{np.median(v):.2e}" for c, v in sorted(q50.items(), key=lambda x: int(x[0]))})
print("noyau", lg.get("noyau_attention"), "; dtype/chargement", p.get("chargement"))
print("pic mémoire logique", lg.get("memoire_max_go"), "Go ; plus long contexte rempli", lg["debit"].get("longueur_remplie_max"))
print("contrôle négatif", eq["controle_negatif"]["passent"], "/", eq["controle_negatif"]["comparables"],
      "min", eq["controle_negatif"]["min_des_maxima"])
print("tests", p.get("tests_instance", {}).get("derniere_ligne"))
print("réglages relus :", {k: v for k, v in p.get("reglages", {}).items() if k in ("tf32_matmul", "tf32_cudnn", "carte", "nom", "memoire_carte_gio")})
