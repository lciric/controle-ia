"""Contre-lecture R2 de la v3 de T0.4 : recalcul, depuis l'arret.json scellé du run A de la v2
(diag/20261005-144628-validation-reelle/arret.json, sha256 e3ca201e…), des chiffres que cite le brouillon 1 du
préenregistrement v3, et de la statistique de la v3 (99e centile par action et par couche, toutes positions) sur
les données de la v2.

Usage : python -I 09-recalculs-v2.py <clone>
"""
import json
import sys
from pathlib import Path

import numpy as np

D = Path(sys.argv[1])
arret = json.loads((D / "diag/20261005-144628-validation-reelle/arret.json").read_text())["resultat"]
p = arret["partiel"]
print("phase d'arrêt :", arret["phase"], "; durée :", round(arret["duree_s"], 1), "s")
print("motif (début) :", arret["motif"][:100])

# ---------------------------------------------------------------- repère de la v2
rep = p["production"]["repere_precision"]
print("\n# repère de précision (v2, noyaux par défaut)")
for c in ("7", "15", "23"):
    r = rep[c]
    print(f"couche {c}: jetons {r['jetons']} q50 {r['q50']:.4f} q99 {r['q99']:.4f} max {r['max']:.4f}")
q99_rep = {c: rep[c]["q99"] for c in rep}
print("deux fois le plus grand q99 du repère :", round(2 * max(q99_rep.values()), 4))

# ---------------------------------------------------------------- production : par action
eps = [e for e in p["production"]["episodes"] if e["equivalence"]["ecarts"]]
print("\n# production : épisodes échantillonnés :", [e["episode"] for e in eps])
actions = []
for e in eps:
    r = e["equivalence"]
    for cle in r["ecarts"]:
        for c in ("7", "15", "23"):
            pr = r["profils"][cle][c]
            actions.append({"episode": e["episode"], "action": cle, "couche": c,
                            "max_tout": r["ecarts"][cle][c], "q99_tout": pr["q99"], "max_profil": pr["max"],
                            "q99_ctx": pr["contexte"].get("q99"), "q99_gen": pr["generee"].get("q99"),
                            "max_ctx": pr["contexte"].get("max"), "max_gen": pr["generee"].get("max"),
                            "jetons": pr["jetons"], "remplissage": r["lignes"][cle]["remplissage"]})
n_act = len({(a["episode"], a["action"]) for a in actions})
print("actions comparées :", n_act)
# cohérence : maximum du profil (toutes positions) = écart de la garde de la v2
assert all(abs(a["max_tout"] - a["max_profil"]) == 0 for a in actions), "max profil ≠ écart"
print("contrôle : le maximum du profil (toutes positions) égale l'écart de la garde de la v2 pour les", len(actions),
      "couples (action, couche)")
mx = max(actions, key=lambda a: a["max_tout"])
print(f"P4 v2 (maximum) : {mx['max_tout']:.4f} ({mx['episode']}, action ({mx['action']}), couche {mx['couche']})")
print("actions au-dessus de 0,1 (maximum, une couche au moins) :",
      len({(a['episode'], a['action']) for a in actions if a['max_tout'] > 0.1}))
print("maximum de la zone générée :", round(max(a["max_gen"] for a in actions if a["max_gen"] is not None), 4))

print("\n# statistique de la v3 sur les données de la v2 : 99e centile par action et par couche, TOUTES positions")
print("# (champ « q99 » du profil, calculé par np.quantile sur toutes les positions capturées, comme")
print("#  ecart_equivalence(..., quantile=0.99) au code cité)")
for c in ("7", "15", "23"):
    sel = [a for a in actions if a["couche"] == c]
    m = max(sel, key=lambda a: a["q99_tout"])
    print(f"couche {c}: plus grand q99 (toutes positions) {m['q99_tout']:.4f} ({m['episode']}, ({m['action']}))"
          f" ; rapport au q99 du repère (ρ) {m['q99_tout'] / q99_rep[c]:.2f} ; min {min(a['q99_tout'] for a in sel):.4f}")
g = max(actions, key=lambda a: a["q99_tout"])
print(f"P4 de la v3 recalculé sur la v2 : {g['q99_tout']:.4f} (seuil 0,2) -> marge {0.2 / g['q99_tout']:.2f} fois")
print("couples (action, couche) au-dessus de 0,1 sur ce q99 :", sum(a['q99_tout'] > 0.1 for a in actions))

print("\n# 99e centile du CONTEXTE par action (ce que cite le brouillon)")
for c in ("7", "15", "23"):
    sel = [a for a in actions if a["couche"] == c and a["q99_ctx"] is not None]
    m = max(sel, key=lambda a: a["q99_ctx"])
    print(f"couche {c}: plus grand q99 de contexte {m['q99_ctx']:.4f} ({m['episode']}, ({m['action']})) ;"
          f" rapport au repère {m['q99_ctx'] / q99_rep[c]:.3f}")
ctx = [a["q99_ctx"] for a in actions if a["q99_ctx"] is not None]
print(f"étendue des q99 de contexte (toutes couches) : {min(ctx):.4f} à {max(ctx):.4f}")
ctx_nz = [a["q99_ctx"] for a in actions if a["q99_ctx"] is not None and a["remplissage"] > 0]
print(f"étendue sur les seules actions remplies : {min(ctx_nz):.4f} à {max(ctx_nz):.4f}")

# ---------------------------------------------------------------- autres chiffres cités de la v2
lg = p["logique"]["equivalence"]
print("\n# logique (P2)", f"{lg['ecart_max']:.3e}", "contexte", f"{lg['max_contexte']:.3e}", "zone générée",
      f"{lg['max_zone_generee']:.3e}")
print("P3 :", lg["controle_negatif"]["passent"], "sur", lg["controle_negatif"]["comparables"], "min",
      round(lg["controle_negatif"]["min_des_maxima"], 3))
cp = p["controle_positif"]["bilan"]
print("P2b :", cp["vus"], "vus sur", cp["comparables"], "; minimum des maxima", f"{cp['min_des_maxima']:.4e}",
      "; contexte", f"{cp['max_contexte']:.3e}")
# minima par couche du contrôle positif
par_couche = {}
for e in p["controle_positif"]["episodes"]:
    for cle, prof in e["profils"].items():
        if any(prof[c]["generee"]["jetons"] < 4 for c in prof):
            continue
        for c in prof:
            par_couche.setdefault(c, []).append(prof[c]["generee"]["max"])
print("P2b minima par couche :", {c: round(min(v), 4) for c, v in sorted(par_couche.items(), key=lambda x: int(x[0]))})
pe = p["production"]["equivalence"]
print("P5 :", pe["controle_negatif"]["passent"], "sur", pe["controle_negatif"]["comparables"], "min",
      round(pe["controle_negatif"]["min_des_maxima"], 3))
print("P1 : carte", p["reglages"].get("memoire_carte_gio"), "Gio ; normalisations en double",
      p["chargement"]["normalisations_en_double"], "; tests", p["tests_instance"]["derniere_ligne"])
print("pics de mémoire : logique", p["logique"]["memoire_max_go"], "Go ; contrôle positif",
      p["controle_positif"]["memoire_max_go"], "Go ; production", p["production"]["memoire_max_go"], "Go")
print("noyaux permis en production :", p["production"]["noyaux_permis"])
print("plus long contexte rempli : logique", p["logique"]["debit"].get("longueur_remplie_max"),
      "; production", p["production"]["debit"].get("longueur_remplie_max"))

# P5 en v3 (99e centile de l'écart décalé) : la v2 ne consigne que le maximum de l'écart décalé
z = eps[0]["equivalence"]["controle_negatif_zone_generee"]
print("\nclés du contrôle négatif par action dans la v2 :", sorted(next(iter(next(iter(z.values())).values())).keys()))
