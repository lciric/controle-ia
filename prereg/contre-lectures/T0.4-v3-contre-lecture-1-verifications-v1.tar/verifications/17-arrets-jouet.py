"""Contenu d'arret.json à deux arrêts possibles de la v3, sur modèle jouet (configuration réduite des tests) :
(a) C1 contraire (seuil du chemin 1e-12) ; (b) panne (MemoryError) pendant la phase de débit, descriptive.
Usage : PYTHONPATH=<arbre>/src:<arbre>/tests python -I 17-arrets-jouet.py <dossier de travail>"""
import json
import subprocess
import sys
from pathlib import Path

from controle_ia.gardes import GardeArret
from controle_ia.harnais import validation_reelle as V

PETITE = dict(V.CONFIG_REPETITION,
              production=dict(V.CONFIG_REPETITION["production"], episodes=4, T=2, max_nouveaux=8),
              debit={"tailles_lot": [1, 4], "longueur_contexte": 32, "max_nouveaux": 4})
base = Path(sys.argv[1])


def depot(nom):
    d = base / nom
    d.mkdir(parents=True)
    for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@example.invalid"], ["config", "user.name", "t"]):
        subprocess.run(["git", "-C", str(d), *a], check=True)
    (d / "README").write_text("x\n")
    subprocess.run(["git", "-C", str(d), "add", "-A"], check=True)
    subprocess.run(["git", "-C", str(d), "commit", "-q", "-m", "init"], check=True)
    return d


def montrer(d, run):
    a = json.loads((d / "diag" / run / "arret.json").read_text())["resultat"]
    print("phase :", a["phase"], "| motif :", a["motif"][:110])
    print("clés de partiel :", sorted(a["partiel"]))
    print("lecture_partielle :", a["partiel"]["lecture_partielle"])


print("# (a) C1 contraire")
d = depot("a")
cfg = dict(PETITE, chemin=dict(PETITE["chemin"], tolerance=1e-12))
try:
    V.executer(d, "20261006-120000-repetition-jouet", entropie=8, config=cfg, verifier_import=False)
    print("aucun arrêt (inattendu)")
except GardeArret as e:
    print("arrêt :", str(e)[:100])
montrer(d, "20261006-120000-repetition-jouet")

print("\n# (b) panne pendant la phase de débit (descriptive)")
d = depot("b")
vrai = V.generer_lot


def panne(*a, **k):
    raise MemoryError("artefact : mémoire de la carte épuisée pendant le débit")


V.generer_lot = panne              # seul le débit appelle V.generer_lot ; les phases jouent par episode.generer_lot
try:
    V.executer(d, "20261006-120100-repetition-jouet", entropie=8, config=PETITE, verifier_import=False)
    print("aucun arrêt (inattendu)")
except MemoryError as e:
    print("arrêt :", e)
finally:
    V.generer_lot = vrai
montrer(d, "20261006-120100-repetition-jouet")
print("résumé écrit ?", (d / "diag" / "20261006-120100-repetition-jouet" / "resume.json").exists())
