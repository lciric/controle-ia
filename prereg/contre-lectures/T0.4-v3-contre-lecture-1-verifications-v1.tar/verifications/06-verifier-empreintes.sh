#!/usr/bin/env bash
# Contre-lecture R2 de la v3 de T0.4 : recalcul de chaque empreinte citée par les deux brouillons.
# Usage : bash 06-verifier-empreintes.sh <clone>
set -uo pipefail
D=${1:?clone}
cd "$D" || exit 2
ok=0; ko=0
verifier() {  # objet, attendu, commande qui rend l'empreinte
    local objet=$1 attendu=$2 calc
    calc=$(eval "$3" 2>/dev/null | awk '{print $1}' | head -1)
    if [ "$calc" = "$attendu" ]; then statut=CONFORME; ok=$((ok+1)); else statut=DIFFERENT; ko=$((ko+1)); fi
    printf '%s | %s | %s | %s\n' "$objet" "$calc" "$attendu" "$statut"
    # compagnon .sha256 éventuel
    local f=${objet%% *}
    if [ -f "$f.sha256" ]; then
        local comp; comp=$(awk '{print $1}' "$f.sha256")
        [ "$comp" = "$calc" ] && echo "   compagnon $f.sha256 : égal" || echo "   compagnon $f.sha256 : DIFFERENT ($comp)"
    fi
}
echo "objet | sha256 recalculé | attendu (cité) | statut"
echo "--- préenregistrement v3, brouillon 1 ---"
verifier "prereg/T0.4-validation-modele-reel-v2.md" 886c8c07c6954a46c666b294c391523f0cdd3d03a5b99dae5079507503de3fb9 "sha256sum prereg/T0.4-validation-modele-reel-v2.md"
verifier "docs/verdicts/verdict-T0.4-critere-1-G0-v2.md" 98d53c70c09ff9b4c0eea4f7ae8779d6dfa10bb6401ca6ac4567283c6fac07cb "sha256sum docs/verdicts/verdict-T0.4-critere-1-G0-v2.md"
verifier "docs/decisions/proposition-N-011-v1.md" aed4bd6c9db802775071bb37ff2ca8939f4c81dc4a85e2fdd6a36f992a81b35b "sha256sum docs/decisions/proposition-N-011-v1.md"
verifier "scripts/validation_t04_instance.sh (au commit 2457743)" ae7050907c8062b015cf868569953906042e8b3fcf50441cd9ae745f79e2aefd "git show 2457743bbb92a492a9a3a97a92bee81921b4e43a:scripts/validation_t04_instance.sh | sha256sum"
verifier "scripts/validation_t04_instance.sh (au commit 62c74c6)" ae7050907c8062b015cf868569953906042e8b3fcf50441cd9ae745f79e2aefd "git show 62c74c6:scripts/validation_t04_instance.sh | sha256sum"
verifier "scripts/validation_t04_instance.sh (HEAD)" ae7050907c8062b015cf868569953906042e8b3fcf50441cd9ae745f79e2aefd "sha256sum scripts/validation_t04_instance.sh"
verifier "scripts/amorce_instance_t04.sh (au commit 2457743)" 6d34fb18a2e21c83cd5dbb4627f30195838c15edfc2eed581f0d1674b96c6f19 "git show 2457743bbb92a492a9a3a97a92bee81921b4e43a:scripts/amorce_instance_t04.sh | sha256sum"
verifier "scripts/amorce_instance_t04.sh (au commit 62c74c6)" 6d34fb18a2e21c83cd5dbb4627f30195838c15edfc2eed581f0d1674b96c6f19 "git show 62c74c6:scripts/amorce_instance_t04.sh | sha256sum"
verifier "scripts/amorce_instance_t04.sh (HEAD)" 6d34fb18a2e21c83cd5dbb4627f30195838c15edfc2eed581f0d1674b96c6f19 "sha256sum scripts/amorce_instance_t04.sh"
verifier "docs/brief-claude-code-programme-complet-v2.md" 9261932a11f29e8643175bc6e150d5455067f58a3cb1e57dca99e02cb17aa3b2 "sha256sum docs/brief-claude-code-programme-complet-v2.md"
verifier "docs/programme-controle-ia-v2.md" 2fd63badb5afea48f48d3ca501ae3b027c4094a8b176508488a41a22e45aa18c "sha256sum docs/programme-controle-ia-v2.md"
verifier "livrables/premier-rendu-v1/devis-v1.md" 16d71febf1491780ab1230ed1fb8e4d8b1bec47fbed202e0ef26ca666def04c2 "sha256sum livrables/premier-rendu-v1/devis-v1.md"
verifier "docs/notes/memoire-double-precision-T0.4-v1.md" b013428ab8502a61a3ea19404ea3a6cdc64ea6a587010c45627e33f13ef29148 "sha256sum docs/notes/memoire-double-precision-T0.4-v1.md"
verifier "docs/notes/memoire-noyau-math-T0.4-v3-v1.md" 89ae46ac4eac6c7dc7206bdd691e1a150aea915a7e3442a93df1802a93c823df "sha256sum docs/notes/memoire-noyau-math-T0.4-v3-v1.md"
verifier "diag/20261005-102042-validation-reelle/arret.json" 4eb2d92069e270631bf3e4d25345b44191cbe419d71a4f06725659c32846aeed "sha256sum diag/20261005-102042-validation-reelle/arret.json"
verifier "diag/20261005-144628-validation-reelle/arret.json" e3ca201edef75f50409e42848f5c4faee0c411dd4a169933751c08bb228c63e6 "sha256sum diag/20261005-144628-validation-reelle/arret.json"
verifier "docs/verdicts/verdict-T0.4-critere-1-G0-v2-recalculs.tar" 992d566632fdd1c034ca9b7f586cc20278b92fa80bf00be7a8985f974d464d25 "sha256sum docs/verdicts/verdict-T0.4-critere-1-G0-v2-recalculs.tar"
verifier "recalculs/04-localisation-production.sortie.txt (dans l'archive)" 107d7c8b1185c0ccda51d12e73ad0d14ca7e8e4ba20d9c4e5b70fc3300806867 "tar -xOf docs/verdicts/verdict-T0.4-critere-1-G0-v2-recalculs.tar recalculs/04-localisation-production.sortie.txt | sha256sum"
verifier "diag/20261006-091344-repetition-jouet/resume.json" 0dbcef66386ccc240b0d967362fa57574237f866e43c6fe1c25347449933c1eb "sha256sum diag/20261006-091344-repetition-jouet/resume.json"
verifier "diag/20261006-091354-repetition-jouet/resume.json" 4132002b895e462e7799d11a83ceb219b881e2809279767be77c75ea0e366d45 "sha256sum diag/20261006-091354-repetition-jouet/resume.json"
verifier "diag/20261006-091354-repetition-jouet/comparaison-20261006-091344-repetition-jouet.json" 027f93595230f59f6d0b9cad7efe7ec6750b219d2bfd656a7494c5f44a4f360c "sha256sum diag/20261006-091354-repetition-jouet/comparaison-20261006-091344-repetition-jouet.json"
verifier "diag/20261006-092650-repetition-jouet/resume.json" c9bf1c0d9dd516dad49d5f7a54bc31883aa8f56bce041f360bd896da5d0c2717 "sha256sum diag/20261006-092650-repetition-jouet/resume.json"
verifier "diag/20261006-092700-repetition-jouet/resume.json" dec0bfa09ecb272aec8868abc18f7476c1a3a680545133f971dd37de48a5b45a "sha256sum diag/20261006-092700-repetition-jouet/resume.json"
verifier "diag/20261006-092700-repetition-jouet/comparaison-20261006-092650-repetition-jouet.json" ace720e8e2b1b822bd2c4c7c0954565c707e9bf632ee77596f2313992cea9333 "sha256sum diag/20261006-092700-repetition-jouet/comparaison-20261006-092650-repetition-jouet.json"
verifier "prereg/contre-lectures/T0.4-v3-mutations-auteur-v1.tar" d7efdaa776e281d4d3b342f2a40d5aee295ed7ff587e685f6a1801628d1dee8e "sha256sum prereg/contre-lectures/T0.4-v3-mutations-auteur-v1.tar"
verifier "diag/essais-amorce-T0.4/essais-amorce-T0.4-v3-v1.tar" d35deb04eb03a0f5750889c66d5d9805a47b6d14927bd61fa0ca36e9bcb18c38 "sha256sum diag/essais-amorce-T0.4/essais-amorce-T0.4-v3-v1.tar"
verifier "diag/essais-amorce-T0.4/essais-amorce-T0.4-v3-v2.tar" aeeb02de42a8fa8597b9ee97bb4117b181233cebe8f7af40af04584b299dcb42 "sha256sum diag/essais-amorce-T0.4/essais-amorce-T0.4-v3-v2.tar"
echo "--- procédure v4, brouillon 1 ---"
verifier "docs/procedures/validation-T0.4-modele-reel-v3.md" a91a5838f0ec44bae5689ed935eda1b558fcda692d6314106761da5ac02bce4b "sha256sum docs/procedures/validation-T0.4-modele-reel-v3.md"
verifier "docs/procedures/surveiller-instance-t04-v1.sh" 5188c13c8f52746dcb5ba5aa52c6df0671eb9618411a6950299d080658eb526d "sha256sum docs/procedures/surveiller-instance-t04-v1.sh"
echo "--- commit cité ---"
echo "2457743bbb92a492a9a3a97a92bee81921b4e43a existe : $(git cat-file -t 2457743bbb92a492a9a3a97a92bee81921b4e43a 2>&1)"
echo "révision du modèle citée (0e9e39f2…) = révision de la v2 : $(grep -c '0e9e39f249a16976918f6564b8830bc894c89659' prereg/T0.4-validation-modele-reel-v2.md) occurrence(s) dans la v2"
echo "entropie v3 dans registres/decisions.md : $(grep -c '86918527404142130934456531865900787761' registres/decisions.md) occurrence(s)"
echo "BILAN : $ok conformes, $ko différents"
