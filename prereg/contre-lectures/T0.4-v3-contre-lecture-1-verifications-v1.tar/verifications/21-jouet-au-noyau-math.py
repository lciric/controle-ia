"""Transparence, ligne 363 : « sur processeur, en demi-précision et au noyau « math », génération et passe unique
coïncident au bit près ». Essai : configuration réduite des tests, chemin et production au noyau « math ».
Usage : PYTHONPATH=<arbre>/src python -I 21-jouet-au-noyau-math.py <dossier de travail>"""
import json, subprocess, sys
from pathlib import Path
from controle_ia.harnais import validation_reelle as V
PETITE = dict(V.CONFIG_REPETITION,
              production=dict(V.CONFIG_REPETITION["production"], episodes=4, T=2, max_nouveaux=8, noyau_attention="math"),
              chemin=dict(V.CONFIG_REPETITION["chemin"], noyau_attention="math"),
              debit={"tailles_lot": [1, 4], "longueur_contexte": 32, "max_nouveaux": 4})
d = Path(sys.argv[1]) / "math"
d.mkdir(parents=True)
for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@example.invalid"], ["config", "user.name", "t"]):
    subprocess.run(["git", "-C", str(d), *a], check=True)
(d / "README").write_text("x\n"); subprocess.run(["git", "-C", str(d), "add", "-A"], check=True)
subprocess.run(["git", "-C", str(d), "commit", "-q", "-m", "init"], check=True)
try:
    s = V.executer(d, "20261006-130000-repetition-jouet", entropie=8, config=PETITE, verifier_import=False)
    r = json.loads((d / "diag/20261006-130000-repetition-jouet/resume.json").read_text())["resultat"]
except Exception as e:
    print("arrêt :", type(e).__name__, str(e)[:200])
    r = json.loads((d / "diag/20261006-130000-repetition-jouet/arret.json").read_text())["resultat"]["partiel"]
for ph in ("chemin", "production"):
    b = r[ph]["equivalence"]
    print(ph, "noyau", r[ph].get("noyau_attention"), "| max", b["ecart_max"], "| q99max", b["ecart_q99_max"],
          "| zéros par couche (zone générée [nuls, total])", {c: z["generee"] for c, z in b["zeros"].items()})
print("lecture :", r.get("lecture") or r.get("lecture_partielle"))
