"""Chiffres du modèle jouet cités par le brouillon v3 (Pourquoi ces seuils ; Transparence), recalculés depuis les
résumés scellés des répétitions. Usage : python -I 13-recalculs-jouet.py <clone>"""
import json
import sys
from pathlib import Path

D = Path(sys.argv[1])


def lire_run(run):
    return json.loads((D / "diag" / run / "resume.json").read_text())["resultat"]


def resume_phase(r, phase):
    b = r[phase]["equivalence"]
    cn = b["controle_negatif"]
    return (f"{phase}: max {b['ecart_max']:.2e} ctx {b['max_contexte']:.2e} gen {b['max_zone_generee']:.2e} "
            f"q99max {b['ecart_q99_max']:.2e} | CN {cn['passent']}/{cn['comparables']} min {cn['min_des_maxima']:.3f} "
            f"stat {cn.get('statistique')} | couverture {b['couverture']} | noyau {r[phase].get('noyau_attention')}")


for run in ("20261006-092650-repetition-jouet", "20261006-092700-repetition-jouet",
            "20261006-091344-repetition-jouet", "20261006-091354-repetition-jouet"):
    r = lire_run(run)
    print("=====", run)
    print("lecture :", r["lecture"])
    for ph in ("logique", "chemin", "production"):
        print(resume_phase(r, ph))
    for cle in ("controle_positif", "controle_positif_chemin"):
        b = r[cle]["bilan"]
        print(f"{cle}: {b['vus']}/{b['comparables']} vus, tolérance {b['tolerance']}, min des maxima "
              f"{b['min_des_maxima']:.2e}, contexte {b['max_contexte']:.2e}, courtes {b['courtes']}")
    rep = r["production"]["repere_precision"]
    print("repère :", {c: (f"q99 {v['q99']:.2e}", f"max {v['max']:.2e}") for c, v in rep.items()})
    print("débit noyau :", r["debit"].get("noyau_attention"), "; chemin chargement :", r["chemin"].get("chargement"))
for a, b in (("20261006-092650-repetition-jouet", "20261006-092700-repetition-jouet"),
             ("20261006-091344-repetition-jouet", "20261006-091354-repetition-jouet")):
    c = json.loads((D / "diag" / b / f"comparaison-{a}.json").read_text())["resultat"]
    print(f"comparaison {b} / {a} : identique={c['identique']} lecture={c['lecture']} différences={c['differences']}")
