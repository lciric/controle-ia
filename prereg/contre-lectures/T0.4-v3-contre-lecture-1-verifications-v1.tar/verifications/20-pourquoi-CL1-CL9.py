"""Pourquoi CL-1 et CL-9 sont-elles vues ? Relance du seul test qui échoue, sur une copie mutée, et affichage de l'erreur.
Usage : python 20-pourquoi-CL1-CL9.py <arbre au commit cité> <dossier de travail>"""
import shutil, subprocess, sys
from pathlib import Path
racine, base = Path(sys.argv[1]), Path(sys.argv[2])
CAS = {
    "CL-1": ("src/controle_ia/harnais/episode.py",
             'rapport["ecarts_q99"][cle] = ecart_equivalence(ag, acts[i], quantile=0.99)',
             'rapport["ecarts_q99"][cle] = ecart_equivalence(ag, acts[i], quantile=0.95)',
             "tests/test_validation_reelle.py::test_p4_contraire_se_lit_au_vu_du_repere"),
    "CL-9": ("src/controle_ia/harnais/validation_reelle.py",
             'x = bilan["ecart_q99_max"] if bilan.get("statistique", "max") == "q99" else bilan["ecart_max"]',
             'x = bilan["ecart_q99_max"] if phase != "logique" else bilan["ecart_max"]',
             "tests/test_validation_reelle.py::test_lecture_couverture_controle_negatif_audit_et_nan"),
}
for nom, (f, old, new, test) in CAS.items():
    d = base / nom
    if d.exists():
        shutil.rmtree(d)
    for x in ("src", "tests"):
        shutil.copytree(racine / x, d / x, ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy(racine / "pyproject.toml", d)
    t = (d / f).read_text(encoding="utf-8"); assert t.count(old) == 1
    (d / f).write_text(t.replace(old, new), encoding="utf-8")
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", test], cwd=d,
                       env={"PYTHONPATH": str(d / "src"), "PATH": "/usr/bin:/bin", "HOME": str(d)},
                       capture_output=True, text=True)
    lignes = [l for l in r.stdout.splitlines() if l.startswith("E ") or "Failed" in l or "Error" in l]
    print(f"{nom} : {r.stdout.strip().splitlines()[-1]}")
    for l in lignes[:6]:
        print("   ", l[:200])
    shutil.rmtree(d)
