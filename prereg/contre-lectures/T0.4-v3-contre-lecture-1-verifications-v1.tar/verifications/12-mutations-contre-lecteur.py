"""Contre-lecture R2 de la v3 de T0.4 : mutations du contre-lecteur (aucune n'est dans la liste N01-N11 de l'auteur),
sur le différentiel dc7aa7f..2457743. Chaque mutation remplace une seule chaîne dans une copie jetable de src/ et
tests/ (et pyproject.toml) de l'arbre au commit cité ; puis les quatre fichiers de tests qui touchent le harnais sont
lancés avec arrêt au premier échec. « VUE » : au moins un test échoue.

Usage : python 12-mutations-contre-lecteur.py <arbre au commit cité> <dossier de travail> [noms…]
"""
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

racine = Path(sys.argv[1]).resolve()
base = Path(sys.argv[2]).resolve()
V = "src/controle_ia/harnais/validation_reelle.py"
E = "src/controle_ia/harnais/episode.py"
A = "src/controle_ia/harnais/activations.py"
MUT = {
    # témoin : aucune modification (la copie doit passer)
    "CL-0-temoin-sans-mutation": (V, 'PHASES_COMPAREES = ("logique", "chemin", "production")',
                                  'PHASES_COMPAREES = ("logique", "chemin", "production")'),
    # niveau du centile de la garde de production (0,99 -> 0,95) dans la génération des rapports
    "CL-1-quantile-095-dans-la-garde": (E,
        'rapport["ecarts_q99"][cle] = ecart_equivalence(ag, acts[i], quantile=0.99)',
        'rapport["ecarts_q99"][cle] = ecart_equivalence(ag, acts[i], quantile=0.95)'),
    # grandeur lue par la lecture de P4 : maximum au lieu du 99e centile, dans le bilan de phase
    "CL-2-ecart_q99_max-calcule-sur-le-maximum": (V,
        '"ecart_q99_max": _maximum(ecarts_q99),',
        '"ecart_q99_max": _maximum(ecarts),'),
    # couverture du chemin (C1) non lue : un chemin sans remplissage ni ligne finie avant les autres reste « conforme »
    "CL-3-couverture-du-chemin-non-lue": (V,
        'elif phase in ("logique", "chemin") and not (',
        'elif phase in ("logique",) and not ('),
    # audit de symétrie (P9) sans la phase de chemin
    "CL-4-audit-P9-sans-le-chemin": (V,
        '    declenche = []\n    for phase in PHASES_COMPAREES:',
        '    declenche = []\n    for phase in ("logique", "production"):'),
    # contrôle négatif de la production : « q99 » de l'écart décalé calculé à la médiane
    "CL-5-controle-negatif-q99-a-la-mediane": (A,
        'sortie[couche] = {"max": float(e.max()), "q99": float(np.quantile(e, 0.99)),',
        'sortie[couche] = {"max": float(e.max()), "q99": float(np.quantile(e, 0.5)),'),
    # niveau du centile de la garde de production (0,99 -> 0,98) : CL-1 est vue par hasard du jouet ?
    "CL-1b-quantile-098-dans-la-garde": (E,
        'rapport["ecarts_q99"][cle] = ecart_equivalence(ag, acts[i], quantile=0.99)',
        'rapport["ecarts_q99"][cle] = ecart_equivalence(ag, acts[i], quantile=0.98)'),
    # lecture : toute phase autre que la logique lue sur le 99e centile (le chemin aussi, au lieu du maximum)
    "CL-9-chemin-lu-sur-le-99e-centile": (V,
        'x = bilan["ecart_q99_max"] if bilan.get("statistique", "max") == "q99" else bilan["ecart_max"]',
        'x = bilan["ecart_q99_max"] if phase != "logique" else bilan["ecart_max"]'),
    # gardes du chemin appliquées avant son contrôle positif (le bilan du contrôle positif du chemin manquerait
    # dans arret.json si C1 ou C3 arrêtait le run)
    "CL-6-gardes-du-chemin-avant-son-controle-positif": (V,
        '        phase = nom_pc\n        temps()\n        c_pc = dict(c, T=cp["T"])',
        '        if nom == "chemin":\n            appliquer_gardes(sorties, resume[nom]["equivalence"], nom, cn)\n'
        '        phase = nom_pc\n        temps()\n        c_pc = dict(c, T=cp["T"])'),
    # témoin attendu VU : contrôle positif du chemin jugé au seuil de logique au lieu du seuil du chemin
    "CL-7-controle-positif-du-chemin-au-seuil-de-logique": (V,
        '"bilan": bilan_controle_positif(sorties_pc, c_pc, cp),',
        '"bilan": bilan_controle_positif(sorties_pc, dict(c_pc, tolerance=config["logique"]["tolerance"]), cp),'),
    # débit hors du noyau de production
    "CL-8-debit-hors-du-noyau-de-production": (V,
        '            with noyau(prod["noyau_attention"]):                     # noyau de production (version 3)',
        '            with contextlib.nullcontext():                     # noyau de production (version 3)'),
}
TESTS = ["tests/test_validation_reelle.py", "tests/test_harnais_lots.py", "tests/test_harnais.py",
         "tests/test_harnais_formats.py"]
noms = sys.argv[3:] or list(MUT)


def un(nom):
    f, old, new = MUT[nom]
    d = base / nom
    if d.exists():
        shutil.rmtree(d)
    shutil.copytree(racine / "src", d / "src", ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copytree(racine / "tests", d / "tests", ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy(racine / "pyproject.toml", d / "pyproject.toml")
    t = (d / f).read_text(encoding="utf-8")
    assert t.count(old) == 1, (nom, t.count(old))
    (d / f).write_text(t.replace(old, new), encoding="utf-8")
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "-x", *TESTS], cwd=d,
                       env={"PYTHONPATH": str(d / "src"), "PATH": "/usr/bin:/bin", "HOME": str(d)},
                       capture_output=True, text=True)
    der = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-300:]
    echec = [x for x in r.stdout.splitlines() if x.startswith("FAILED")][:1]
    shutil.rmtree(d)
    return f"{nom}: {'VUE' if r.returncode else 'NON VUE'} (code {r.returncode}) — {der} {echec}"


with ThreadPoolExecutor(max_workers=3) as ex:
    for ligne in ex.map(un, noms):
        print(ligne, flush=True)
