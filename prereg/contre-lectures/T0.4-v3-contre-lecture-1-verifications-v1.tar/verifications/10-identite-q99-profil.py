"""Le 99e centile de la garde v3 (equivalence.ecarts_q99) égale-t-il le champ q99 (toutes positions) du profil,
déjà consigné par le code de la v2 ? Vérifié sur les résumés scellés des répétitions jouet au code cité.
Usage : python -I 10-identite-q99-profil.py <clone>"""
import json, sys
from pathlib import Path
D = Path(sys.argv[1])
for run in ("20261006-092650-repetition-jouet", "20261006-092700-repetition-jouet"):
    r = json.loads((D / "diag" / run / "resume.json").read_text())["resultat"]
    n = egaux = 0
    for phase in ("logique", "chemin", "production"):
        for e in r[phase]["episodes"]:
            eq = e["equivalence"]
            for cle, par_couche in eq["ecarts_q99"].items():
                for c, v in par_couche.items():
                    n += 1
                    egaux += (v == eq["profils"][cle][c]["q99"])
    print(f"{run} : {egaux} égalités exactes sur {n} couples (action, couche) — ecarts_q99 == profils[..]['q99']")
# rapports exacts au repère cités par le brouillon (v2)
a = json.loads((D / "diag/20261005-144628-validation-reelle/arret.json").read_text())["resultat"]["partiel"]
rep = a["production"]["repere_precision"]
best = {}
for e in a["production"]["episodes"]:
    eq = e["equivalence"]
    for cle in eq["ecarts"]:
        for c in ("7", "15", "23"):
            q = eq["profils"][cle][c]["contexte"].get("q99")
            if q is not None and q > best.get(c, -1):
                best[c] = q
for c in ("7", "15", "23"):
    print(f"couche {c}: q99 contexte max {best[c]:.6f} / q99 repère {rep[c]['q99']:.6f} = {best[c]/rep[c]['q99']:.4f}")
