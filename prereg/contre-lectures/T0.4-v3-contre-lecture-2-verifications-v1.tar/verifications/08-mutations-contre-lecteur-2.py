"""08 — Mutations du contre-lecteur 2 sur le différentiel 2457743..b6ab5d1 (nouvelles : distinctes de N01 à N14 de
l'auteur et de CL-1 à CL-9 du contre-lecteur 1). Chaque mutation remplace une seule chaîne (présente exactement une
fois) dans une copie jetable de src/, tests/ et pyproject.toml de l'arbre b6ab5d1 ; on lance les quatre fichiers de
tests du harnais (comme l'auteur), sans arrêt au premier échec. « VUE » : au moins un test échoue.
Usage : python 08-mutations-contre-lecteur-2.py <arbre b6ab5d1> <dossier jetable>"""
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

arbre, base = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
A = "src/controle_ia/harnais/activations.py"
V = "src/controle_ia/harnais/validation_reelle.py"
ORIG_CTX = "e_action = np.concatenate([ecarts_par_jeton(g[:longueur_contexte], p[:longueur_contexte]), e])"
MUT = {
    # X-2 : grandeur du contrôle négatif de la production
    "M1-q99-avec-la-premiere-position-generee": (A, ORIG_CTX,
        "e_action = np.concatenate([ecarts_par_jeton(g[:longueur_contexte], p[:longueur_contexte]), "
        "ecarts_par_jeton(g[longueur_contexte:], p[longueur_contexte - 1: g.shape[0] - 1])])"),
    "M2-contexte-decale-lui-aussi": (A, ORIG_CTX,
        "e_action = np.concatenate([ecarts_par_jeton(g[1:longueur_contexte], p[:longueur_contexte - 1]), e])"),
    "M3-interpolation-higher": (A, '"q99": float(np.quantile(e_action, 0.99)),',
        '"q99": float(np.quantile(e_action, 0.99, method="higher")),'),
    "M9-positions-comptees-sur-toute-l-action": (A, '"positions": int(e.size)}', '"positions": int(e_action.size)}'),
    # X-10 : débit
    "M4-debit-sans-break-apres-panne": (V,
        "                break                                                # lots plus grands : plus de mémoire encore\n",
        ""),
    "M5-panne-memoire-toujours-vraie": (V, '"panne_memoire": panne is not None,', '"panne_memoire": True,'),
    "M6-memoire-non-rendue-apres-panne": (V,
        "                if torch.cuda.is_available():\n                    torch.cuda.empty_cache()\n"
        "                mesures.append({\"taille_lot\": B, \"erreur\": panne})",
        "                mesures.append({\"taille_lot\": B, \"erreur\": panne})"),
    "M7-panne-consignee-puis-propagee": (V, '                panne = f"{type(e).__name__}: {str(e)[:300]}"\n',
        '                panne = f"{type(e).__name__}: {str(e)[:300]}"\n                raise\n'),
    "M8-mesure-ecrite-malgre-la-panne": (V, "            if panne is not None:\n", "            if False:\n"),
}
TESTS = ["tests/test_validation_reelle.py", "tests/test_harnais_lots.py", "tests/test_harnais.py",
         "tests/test_harnais_formats.py"]
for nom, (f, old, new) in MUT.items():
    n = (arbre / f).read_text(encoding="utf-8").count(old)
    assert n == 1, (nom, n)


def un(nom):
    d = base / nom
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    for x in ("src", "tests"):
        shutil.copytree(arbre / x, d / x, ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy2(arbre / "pyproject.toml", d / "pyproject.toml")
    if nom in MUT:
        f, old, new = MUT[nom]
        t = (d / f).read_text(encoding="utf-8")
        (d / f).write_text(t.replace(old, new, 1), encoding="utf-8")
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", *TESTS], cwd=d,
                       capture_output=True, text=True, env={"PYTHONPATH": str(d / "src"), "PATH": "/usr/bin:/bin",
                                                             "HOME": str(d)})
    lignes = r.stdout.strip().splitlines()
    echecs = [x for x in lignes if x.startswith("FAILED")]
    shutil.rmtree(d)
    return f"{nom}: {'VUE' if r.returncode != 0 else 'NON VUE'} — {lignes[-1] if lignes else r.stderr[-300:]} {echecs}"


noms = ["T00-temoin-sans-mutation", *MUT]
with ThreadPoolExecutor(max_workers=4) as ex:
    for ligne in ex.map(un, noms):
        print(ligne, flush=True)
