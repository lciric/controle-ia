"""09 — Recalcul des chiffres du jouet cités par le brouillon 2 (Transparence ; « Pourquoi ces seuils » ; Seuil) depuis
les résumés scellés des répétitions. Lecture seule. Usage : python -I 09-recalculs-jouet.py <racine du clone>"""
import json
import sys
from pathlib import Path

racine = Path(sys.argv[1])


def charger(run):
    return json.loads((racine / "diag" / run / "resume.json").read_text())["resultat"]


def manifeste(run):
    return json.loads((racine / "runs" / run / "manifeste.json").read_text())


def mx(xs):
    return max(xs) if xs else None


def resumer(run):
    r = charger(run)
    m = manifeste(run)
    print(f"== {run} : commit {m.get('commit', m.get('resultat', {}).get('commit'))} ; entropie {m.get('entropie')}")
    print("   lecture :", json.dumps(r["lecture"], ensure_ascii=False))
    for ph in ("logique", "chemin", "production"):
        eq = r[ph]["equivalence"]
        cn = eq["controle_negatif"]
        print(f"   {ph}: ecart_max {eq['ecart_max']:.2e} ; q99_max {eq['ecart_q99_max']:.2e} ; contexte {eq['max_contexte']:.2e} ;"
              f" zone générée {eq['max_zone_generee']:.2e} ; contrôle négatif {cn['passent']}/{cn['comparables']}"
              f" (courtes {cn['courtes']}), minimum {cn['min_des_maxima']:.3f}, statistique {cn['statistique']} ;"
              f" couverture {eq['couverture']} ; noyau {r[ph].get('noyau_attention')}")
    for pc in ("controle_positif", "controle_positif_chemin"):
        b = r[pc]["bilan"]
        print(f"   {pc}: {b['vus']}/{b['comparables']} vus (courtes {b['courtes']}), minimum des maxima {b['min_des_maxima']:.2e},"
              f" contexte {b['max_contexte']:.2e}, seuil {b.get('tolerance')}")
    prod = r["production"]
    rep = prod["repere_precision"]
    par_couche = {}
    for e in prod["episodes"]:
        for cle, pc_ in e["equivalence"].get("ecarts_q99", {}).items():
            for c, v in pc_.items():
                par_couche[c] = max(par_couche.get(c, 0.0), v)
    print("   repère q99 :", {c: f"{v['q99']:.2e}" for c, v in rep.items()}, "; maxima :",
          {c: f"{v['max']:.2e}" for c, v in rep.items()})
    print("   rho (plus grand q99 par action / q99 du repère) :",
          {c: round(par_couche[c] / rep[c]["q99"], 3) for c in sorted(par_couche, key=int)})
    nuls = sum(z["generee"][0] for z in prod["equivalence"]["zeros"].values())
    tot = sum(z["generee"][1] for z in prod["equivalence"]["zeros"].values())
    nulsc = sum(z["contexte"][0] for z in prod["equivalence"]["zeros"].values())
    totc = sum(z["contexte"][1] for z in prod["equivalence"]["zeros"].values())
    print(f"   production : zéros zone générée {nuls}/{tot}, contexte {nulsc}/{totc}")
    d = r.get("debit", {})
    print("   débit :", {k: d.get(k) for k in ("panne_memoire", "noyau_attention")},
          [(x.get("taille_lot"), "erreur" in x) for x in d.get("mesures", [])])
    return r


for run in ("20261006-103824-repetition-jouet", "20261006-103834-repetition-jouet",
            "20261006-092650-repetition-jouet", "20261006-092700-repetition-jouet",
            "20261006-091344-repetition-jouet", "20261006-091354-repetition-jouet"):
    resumer(run)
for b, a in (("20261006-103834-repetition-jouet", "20261006-103824-repetition-jouet"),
             ("20261006-092700-repetition-jouet", "20261006-092650-repetition-jouet"),
             ("20261006-091354-repetition-jouet", "20261006-091344-repetition-jouet")):
    c = json.loads((racine / "diag" / b / f"comparaison-{a}.json").read_text())["resultat"]
    print(f"comparaison {b} / {a} : identique {c['identique']}, lecture {c['lecture']}, différences {c['differences']}")
