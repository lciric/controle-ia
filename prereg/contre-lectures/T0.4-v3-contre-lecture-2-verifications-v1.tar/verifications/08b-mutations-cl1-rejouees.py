"""08b — Contre-épreuve : les sept mutations CL du contre-lecteur 1 non vues au code 2457743, rejouées par le contre-lecteur 2 au code b6ab5d1 (avec le harnais de 08) sur le différentiel 2457743..b6ab5d1 (nouvelles : distinctes de N01 à N14 de
l'auteur et de CL-1 à CL-9 du contre-lecteur 1). Chaque mutation remplace une seule chaîne (présente exactement une
fois) dans une copie jetable de src/, tests/ et pyproject.toml de l'arbre b6ab5d1 ; on lance les quatre fichiers de
tests du harnais (comme l'auteur), sans arrêt au premier échec. « VUE » : au moins un test échoue.
Usage : python 08-mutations-contre-lecteur-2.py <arbre b6ab5d1> <dossier jetable>"""
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

arbre, base = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
A = "src/controle_ia/harnais/activations.py"
V = "src/controle_ia/harnais/validation_reelle.py"
ORIG_CTX = "e_action = np.concatenate([ecarts_par_jeton(g[:longueur_contexte], p[:longueur_contexte]), e])"
E = "src/controle_ia/harnais/episode.py"
MUT = {
    # chaînes recopiées de prereg/contre-lectures/T0.4-v3-mutations-v2.tar (b6ab5d1/muter.py), sans exécuter ce script :
    # les sept mutations du contre-lecteur 1 qui passaient la suite au code 2457743
    "CL-1b-quantile-098-dans-la-garde": (E, 'rapport["ecarts_q99"][cle] = ecart_equivalence(ag, acts[i], quantile=0.99)', 'rapport["ecarts_q99"][cle] = ecart_equivalence(ag, acts[i], quantile=0.98)'),
    "CL-2-ecart_q99_max-calcule-sur-le-maximum": (V, '"ecart_q99_max": _maximum(ecarts_q99),', '"ecart_q99_max": _maximum(ecarts),'),
    "CL-3-couverture-du-chemin-non-lue": (V, 'elif phase in ("logique", "chemin") and not (', 'elif phase in ("logique",) and not ('),
    "CL-4-audit-P9-sans-le-chemin": (V, '    declenche = []\n    for phase in PHASES_COMPAREES:', '    declenche = []\n    for phase in ("logique", "production"):'),
    "CL-5-controle-negatif-q99-a-la-mediane": (A, '"q99": float(np.quantile(e_action, 0.99)),', '"q99": float(np.quantile(e_action, 0.5)),'),
    "CL-6-gardes-du-chemin-avant-son-controle-positif": (V, '        phase = nom_pc\n        temps()\n        c_pc = dict(c, T=cp["T"])', '        if nom == "chemin":\n            appliquer_gardes(sorties, resume[nom]["equivalence"], nom, cn)\n        phase = nom_pc\n        temps()\n        c_pc = dict(c, T=cp["T"])'),
    "CL-8-debit-hors-du-noyau-de-production": (V, '                with noyau(prod["noyau_attention"]):                 # noyau de production (version 3)', '                with contextlib.nullcontext():                 # noyau de production (version 3)'),
}
TESTS = ["tests/test_validation_reelle.py", "tests/test_harnais_lots.py", "tests/test_harnais.py",
         "tests/test_harnais_formats.py"]
for nom, (f, old, new) in MUT.items():
    n = (arbre / f).read_text(encoding="utf-8").count(old)
    assert n == 1, (nom, n)


def un(nom):
    d = base / nom
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    for x in ("src", "tests"):
        shutil.copytree(arbre / x, d / x, ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy2(arbre / "pyproject.toml", d / "pyproject.toml")
    if nom in MUT:
        f, old, new = MUT[nom]
        t = (d / f).read_text(encoding="utf-8")
        (d / f).write_text(t.replace(old, new, 1), encoding="utf-8")
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", *TESTS], cwd=d,
                       capture_output=True, text=True, env={"PYTHONPATH": str(d / "src"), "PATH": "/usr/bin:/bin",
                                                             "HOME": str(d)})
    lignes = r.stdout.strip().splitlines()
    echecs = [x for x in lignes if x.startswith("FAILED")]
    shutil.rmtree(d)
    return f"{nom}: {'VUE' if r.returncode != 0 else 'NON VUE'} — {lignes[-1] if lignes else r.stderr[-300:]} {echecs}"


noms = [*MUT]
with ThreadPoolExecutor(max_workers=4) as ex:
    for ligne in ex.map(un, noms):
        print(ligne, flush=True)
