"""14 — Deux points fins sur le 99e centile (numpy.quantile, interpolation linéaire, comme la garde).
(a) « Pourquoi ces seuils » : « un défaut confiné à la zone générée n'atteint la garde que si cette zone compte au moins
    k(n) = n − ⌊0,99 (n − 1)⌋ positions ». On cherche des n où k(n) − 1 positions décalées suffisent.
(b) Contrôle négatif du code b6ab5d1 (première position générée exclue : n − 1 valeurs dont m − 1 décalées) contre
    la garde décalée d'un jeton sur toute l'action (n valeurs : m décalées, dont s_lc pour la première position
    générée). On cherche, au voisinage de la frontière, des (lc, m) où les deux verdicts diffèrent, selon que s_lc est
    grand (cas courant) ou petit.
Valeurs schématiques : contexte 0,02 ; positions décalées 1,5 ; seuil 0,2. Usage : python -I 14-q99-frontiere.py"""
import numpy as np

TAU, PETIT, GRAND = 0.2, 0.02, 1.5


def q99(v):
    return float(np.quantile(np.asarray(v, dtype=np.float64), 0.99))


print("(a) k(n) − 1 positions décalées suffisent-elles ? (garde : n valeurs, dont L grandes)")
cas_a = []
for n in range(20, 3001):
    k = n - int(np.floor(0.99 * (n - 1)))
    v = [PETIT] * (n - (k - 1)) + [GRAND] * (k - 1)
    if q99(v) > TAU:
        cas_a.append((n, k, round(q99(v), 3)))
print(f"   n de 20 à 3000 : {len(cas_a)} valeurs de n où k(n) − 1 positions décalées donnent un 99e centile > {TAU}")
print("   exemples (n, k(n), 99e centile avec k(n) − 1 positions) :", cas_a[:3], "…", cas_a[-3:])
v = [PETIT] * 148 + [GRAND] * 2
print(f"   n = 150 : k = {150 - int(np.floor(0.99 * 149))} ; avec 2 positions décalées, 99e centile = {q99(v):.3f}")

print("(b) contrôle négatif du code (sans la première position générée) contre garde décalée sur toute l'action")
for nom, s_lc in (("s_lc grand (1,5)", GRAND), ("s_lc petit (0,02)", PETIT)):
    code_seul, garde_seule = [], []
    for lc in range(50, 2001, 7):
        for m in range(2, 40):
            code = q99([PETIT] * lc + [GRAND] * (m - 1))
            garde = q99([PETIT] * lc + [s_lc] + [GRAND] * (m - 1))
            if (code > TAU) and not (garde > TAU):
                code_seul.append((lc, m, round(code, 3), round(garde, 3)))
            if (garde > TAU) and not (code > TAU):
                garde_seule.append((lc, m, round(code, 3), round(garde, 3)))
    print(f"   {nom} : P5 passe mais la garde ne verrait pas : {len(code_seul)} cas {code_seul[:2]} ;"
          f" la garde verrait mais P5 échoue : {len(garde_seule)} cas {garde_seule[:2]}")
