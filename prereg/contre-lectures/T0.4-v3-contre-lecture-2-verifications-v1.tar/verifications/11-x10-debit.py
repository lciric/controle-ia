"""11 — X-10 : comportement du débit au code b6ab5d1, sur le jouet (processeur), configuration PETITE des tests.
S1 : panne de mémoire au premier lot ; S2 : panne au second lot dans A, avec un tableau local à la fonction en panne
(mémoire rendue ?), puis run B (rejeu) sans panne : comparaison ; S3 : vrai signal TERM pendant le débit ;
S4 : erreur de mémoire non typée (RuntimeError « CUDA error: out of memory »).
Usage : PYTHONPATH=<arbre b6ab5d1>/src python 11-x10-debit.py <dossier jetable>"""
import json
import os
import signal
import subprocess
import sys
import weakref
from pathlib import Path

import torch

from controle_ia.gardes import GardeArret
from controle_ia.harnais import validation_reelle as V

PETITE = dict(V.CONFIG_REPETITION,
              production=dict(V.CONFIG_REPETITION["production"], episodes=4, T=2, max_nouveaux=8),
              debit={"tailles_lot": [1, 4], "longueur_contexte": 32, "max_nouveaux": 4})
base = Path(sys.argv[1])
vrai_generer = V.generer_lot


def depot(nom):
    d = base / nom
    d.mkdir(parents=True)
    for args in (["init", "-q", "-b", "main"], ["config", "user.email", "t@example.invalid"], ["config", "user.name", "t"]):
        subprocess.run(["git", "-C", str(d), *args], check=True)
    (d / "README").write_text("x\n")
    committer(d)
    return d


def committer(d):
    subprocess.run(["git", "-C", str(d), "add", "-A"], check=True)
    subprocess.run(["git", "-C", str(d), "commit", "-q", "-m", "etape"], check=True)


def lire_json(d, run, nom):
    p = d / "diag" / run / f"{nom}.json"
    return json.loads(p.read_text())["resultat"] if p.exists() else None


def executer(d, run, generer, **kw):
    V.generer_lot = generer
    try:
        return V.executer(d, run, config=PETITE, verifier_import=False, **kw), None
    except BaseException as e:            # on rapporte tout, y compris ce qui ne serait pas une Exception
        return None, e
    finally:
        V.generer_lot = vrai_generer


# S1 : panne au premier lot
def panne_lot1(modele, transcriptions, *a, **kw):
    raise torch.cuda.OutOfMemoryError("CUDA out of memory (essai S1)")


d1 = depot("s1")
s, e = executer(d1, "20261006-130000-repetition-jouet", panne_lot1, entropie=41)
r = lire_json(d1, "20261006-130000-repetition-jouet", "resume")
print("S1 exception :", repr(e))
print("S1 résumé écrit :", r is not None, "; débit :", json.dumps(r["debit"], ensure_ascii=False) if r else None)
print("S1 lecture égale à une lecture saine (toutes conformes, audit non déclenché) :",
      r is not None and all(v in ("conforme", "non déclenché", "sans objet") for v in r["lecture"].values()))

# S2 : panne au second lot, tableau local de 200 Mo dans la fonction en panne ; mémoire rendue avant la suite ?
refs, etats = [], []
vrai_memoire = V.memoire_max_go


def memoire_espion():
    etats.append([x() is None for x in refs])
    return vrai_memoire()


def panne_lot4(modele, transcriptions, *a, **kw):
    if len(transcriptions) >= 4:
        gros = torch.empty(50_000_000)                         # 200 Mo, local au cadre qui lève
        refs.append(weakref.ref(gros))
        raise torch.cuda.OutOfMemoryError("CUDA out of memory (essai S2)")
    return vrai_generer(modele, transcriptions, *a, **kw)


d2 = depot("s2")
V.memoire_max_go = memoire_espion
s, e = executer(d2, "20261006-130100-repetition-jouet", panne_lot4, entropie=43)
V.memoire_max_go = vrai_memoire
ra = lire_json(d2, "20261006-130100-repetition-jouet", "resume")
print("S2 exception :", repr(e), "; débit A :", json.dumps(ra["debit"]["mesures"], ensure_ascii=False)[:300],
      "; panne_memoire", ra["debit"]["panne_memoire"])
print("S2 tableau local de la fonction en panne libéré au relevé de mémoire qui suit la boucle du débit :", etats[-1])
committer(d2)
s, e = executer(d2, "20261006-130200-repetition-jouet", vrai_generer, rejeu_de="20261006-130100-repetition-jouet")
rb = lire_json(d2, "20261006-130200-repetition-jouet", "resume")
comp = lire_json(d2, "20261006-130200-repetition-jouet", "comparaison-20261006-130100-repetition-jouet")
print("S2 run B : exception", repr(e), "; panne_memoire B", rb["debit"]["panne_memoire"], "; lectures A == B :",
      ra["lecture"] == rb["lecture"], "; comparaison :", comp and {k: comp[k] for k in ("identique", "lecture", "differences")})

# S3 : vrai signal TERM pendant le débit, gestionnaire du lanceur installé
ancien = signal.signal(signal.SIGTERM, V._signal_term)


def term(modele, transcriptions, *a, **kw):
    os.kill(os.getpid(), signal.SIGTERM)
    return vrai_generer(modele, transcriptions, *a, **kw)


d3 = depot("s3")
s, e = executer(d3, "20261006-130300-repetition-jouet", term, entropie=47)
signal.signal(signal.SIGTERM, ancien)
arr = lire_json(d3, "20261006-130300-repetition-jouet", "arret")
print("S3 exception :", repr(e)[:120], "; arret.json phase", arr and arr["phase"], "; motif", arr and arr["motif"][:80],
      "; résumé écrit :", lire_json(d3, "20261006-130300-repetition-jouet", "resume") is not None)


# S4 : erreur de mémoire non typée (comme cuBLAS ou le pilote peuvent en lever)
def runtime(modele, transcriptions, *a, **kw):
    if len(transcriptions) >= 4:
        raise RuntimeError("CUDA error: out of memory (essai S4, non typée)")
    return vrai_generer(modele, transcriptions, *a, **kw)


d4 = depot("s4")
s, e = executer(d4, "20261006-130400-repetition-jouet", runtime, entropie=53)
arr = lire_json(d4, "20261006-130400-repetition-jouet", "arret")
print("S4 exception :", repr(e)[:120], "; arret.json phase", arr and arr["phase"], "; résumé écrit :",
      lire_json(d4, "20261006-130400-repetition-jouet", "resume") is not None,
      "; lecture_partielle toutes conformes :",
      arr is not None and all(v in ("conforme", "non déclenché", "sans objet") for v in arr["partiel"]["lecture_partielle"].values()))
