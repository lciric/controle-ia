"""07 — X-2 : le 99e centile du contrôle négatif de la production (code b6ab5d1) est-il la grandeur que lirait la
garde de production sous un décalage d'un jeton de la zone générée ?

On espionne `ecart_decale_zone_generee` pendant des runs jouets complets (code b6ab5d1, arbre détaché) et, pour chaque
action comparée et chaque couche, on recalcule avec la fonction même de la garde (`ecart_equivalence`, quantile 0,99) :
  A. la garde appliquée à une passe unique décalée d'un jeton dans la zone générée, première position générée exclue
     (contexte non décalé, puis g_n contre p_{n-1} pour n >= lc+1) : doit égaler le « q99 » du code au bit près ;
  B. la même garde, première position générée comprise (g_lc contre p_{lc-1}) : ce que lirait la garde sur
     toutes les positions de l'action sous ce décalage.
On rapporte les écarts entre le code et B, et les cas où le verdict au seuil de la phase changerait.
Usage : PYTHONPATH=<arbre b6ab5d1>/src python 07-x2-grandeur-exacte.py <dossier jetable>
"""
import subprocess
import sys
from pathlib import Path

import numpy as np

from controle_ia.harnais import episode as E
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais.activations import ecart_equivalence, ecarts_par_jeton

releves = []
vrai = E.ecart_decale_zone_generee


def espion(ag, p, lc, tol):
    sortie = vrai(ag, p, lc, tol)
    if sortie is not None:
        for c, z in sortie.items():
            g, pc = ag[c], p[c]
            n = g.shape[0]
            # A : garde sur (contexte non décalé + zone générée décalée, première position générée exclue)
            g_a = np.concatenate([g[:lc], g[lc + 1:n]])
            p_a = np.concatenate([pc[:lc], pc[lc:n - 1]])
            qa = ecart_equivalence({c: g_a}, {c: p_a}, quantile=0.99)[c]
            # B : garde sur toutes les positions, passe unique décalée d'un jeton dans la zone générée
            p_b = np.concatenate([pc[:lc], pc[lc - 1:n - 1]])
            qb = ecart_equivalence({c: g}, {c: p_b}, quantile=0.99)[c]
            mb = ecart_equivalence({c: g}, {c: p_b})[c]
            s_lc = float(ecarts_par_jeton(g[lc:lc + 1], pc[lc - 1:lc])[0])
            releves.append({"tol": tol, "couche": c, "n": n, "lc": lc, "q99_code": z["q99"], "A": qa, "B": qb,
                            "max_code": z["max"], "max_B": mb, "s_lc": s_lc})
    return sortie


E.ecart_decale_zone_generee = espion


def depot_jetable(racine: Path) -> Path:
    racine.mkdir(parents=True, exist_ok=False)
    for args in (["init", "-q", "-b", "main"], ["config", "user.email", "t@example.invalid"],
                 ["config", "user.name", "t"]):
        subprocess.run(["git", "-C", str(racine), *args], check=True)
    (racine / "README").write_text("x\n")
    subprocess.run(["git", "-C", str(racine), "add", "-A"], check=True)
    subprocess.run(["git", "-C", str(racine), "commit", "-q", "-m", "init"], check=True)
    return racine


base = Path(sys.argv[1])
for k, (nom, config, entropie) in enumerate([("CONFIG_REPETITION", V.CONFIG_REPETITION, 101),
                                             ("CONFIG_REPETITION", V.CONFIG_REPETITION, 202),
                                             ("CONFIG_REPETITION", V.CONFIG_REPETITION, 303)]):
    d = depot_jetable(base / f"depot-{k}")
    debut = len(releves)
    s = V.executer(d, f"20261006-1200{k:02d}-repetition-jouet", entropie=entropie, config=config,
                   verifier_import=False)
    prod = [r for r in releves[debut:] if r["tol"] == config["production"]["tolerance"]]
    tous = releves[debut:]
    print(f"== run {k} ({nom}, entropie {entropie}) : lecture production_controle_negatif = "
          f"{s['lecture']['production_controle_negatif']}, production_equivalence = {s['lecture']['production_equivalence']}")
    print(f"   appels relevés (toutes phases, contrôles positifs compris) : {len(tous)} couples (action, couche)")
    print(f"   A == q99 du code, au bit près : {sum(r['A'] == r['q99_code'] for r in tous)} / {len(tous)}")
    print(f"   max du code == max de la zone décalée (B, sans le contexte) : contrôle via max_B >= max_code : "
          f"{sum(r['max_B'] >= r['max_code'] for r in tous)} / {len(tous)}")
    print(f"   production (seuil {config['production']['tolerance']}) : {len(prod)} couples ; B != code : "
          f"{sum(r['B'] != r['q99_code'] for r in prod)} ; B < code : {sum(r['B'] < r['q99_code'] for r in prod)} ; "
          f"verdict différent (> seuil) : {sum((r['B'] > r['tol']) != (r['q99_code'] > r['tol']) for r in prod)}")
    if prod:
        ecarts = [abs(r['B'] - r['q99_code']) / max(r['q99_code'], 1e-30) for r in prod]
        print(f"   écart relatif max |B − code| / code : {max(ecarts):.3e} ; s_lc min / médiane : "
              f"{min(r['s_lc'] for r in prod):.3f} / {float(np.median([r['s_lc'] for r in prod])):.3f} ; "
              f"q99 code min : {min(r['q99_code'] for r in prod):.3f}")
        print(f"   n (positions de l'action) min / max : {min(r['n'] for r in prod)} / {max(r['n'] for r in prod)} ; "
              f"part de la zone générée min : {min((r['n'] - r['lc']) / r['n'] for r in prod):.3f}")
print(f"TOTAL : A == code dans {sum(r['A'] == r['q99_code'] for r in releves)} / {len(releves)} couples")
