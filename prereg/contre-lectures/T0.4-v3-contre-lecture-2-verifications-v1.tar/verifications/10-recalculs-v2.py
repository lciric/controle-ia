"""10 — Chiffres de la v2 cités par les passages nouveaux du brouillon 2 (X-1, X-2, X-8), recalculés depuis l'arret.json
scellé du run A de la v2 (e3ca201e…). Lecture seule. Usage : python -I 10-recalculs-v2.py <racine du clone>"""
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

racine = Path(sys.argv[1])
chemin = racine / "diag/20261005-144628-validation-reelle/arret.json"
print("arret.json sha256", hashlib.sha256(chemin.read_bytes()).hexdigest())
a = json.loads(chemin.read_text())["resultat"]
p = a["partiel"]
print("phase", a["phase"], "; durée", round(a["duree_s"], 1), "s ; motif", a["motif"][:90])
for ph in ("logique", "controle_positif", "production"):
    d = p.get(ph, {}).get("debit", {})
    print(f"{ph}: longueur_remplie_max = {d.get('longueur_remplie_max')} ; pic {p.get(ph, {}).get('memoire_max_go')} Go")
prod = p["production"]
# X-1 : q99 toutes positions par action (champ q99 des profils) ; par couche
par_couche, fractions, k_marges = {}, [], []
for e in prod["episodes"]:
    eq = e["equivalence"]
    for cle, profil in eq["profils"].items():
        n, lc = eq["positions_capturees"][cle], eq["longueurs_contexte"][cle]
        m = n - lc
        fractions.append(m / n)
        # garde (n positions) : k(n) = n − ⌊0,99 (n − 1)⌋ ; contrôle négatif du code b6ab5d1 : n − 1 positions dont
        # m − 1 décalées : k(n − 1)
        k_garde = n - int(np.floor(0.99 * (n - 1)))
        k_cn = (n - 1) - int(np.floor(0.99 * (n - 2)))
        k_marges.append((m - k_garde, (m - 1) - k_cn, e["episode"], cle, n, lc))
        for c, pr in profil.items():
            par_couche[c] = max(par_couche.get(c, 0.0), pr["q99"])
print("q99 toutes positions, plus grand par couche :", {c: round(v, 4) for c, v in sorted(par_couche.items(), key=lambda x: int(x[0]))})
print("part de la zone générée : min", round(min(fractions), 4), "max", round(max(fractions), 4), "sur", len(fractions), "actions")
k_marges.sort()
print("marge (positions générées − k(n)) pour la garde, puis pour le contrôle négatif du code cité (n−1 positions, m−1 décalées) :")
for x in k_marges[:5]:
    print("  ", x)
# contrôle négatif de la v2 (sur le maximum, seuil 0,1) : au_dessus / positions par action et couche
bas = []
for e in prod["episodes"]:
    for cle, zone in e["equivalence"]["controle_negatif_zone_generee"].items():
        if zone is None:
            continue
        for c, z in zone.items():
            bas.append((z["au_dessus"] / z["positions"], z["au_dessus"], z["positions"], e["episode"], cle, c))
bas.sort()
print("v2, contrôle négatif : part des positions décalées au-dessus de 0,1 (seuil v2), les 5 plus basses :", bas[:5])
print("v2, contrôle négatif : couples (action, couche) où toutes les positions décalées dépassent 0,1 :",
      sum(1 for x in bas if x[1] == x[2]), "sur", len(bas))
