#!/usr/bin/env bash
# 05 — vérification des empreintes citées par les brouillons 2 (préenregistrement v3, procédure v4).
# Lecture seule : clone du contre-lecteur (HEAD 6aae1e1) et archives extraites dans ESPACE/extraits.
set -u
ESPACE=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/cl-v3-2
D="$ESPACE/depot"
X="$ESPACE/extraits"
cd "$D" || exit 2
ok=0; ko=0
verif() {  # objet  chemin-ou-commande  attendu  [nouveau|repris]
  local nom="$1" calc="$2" att="$3" etat="$4"
  if [ "$calc" = "$att" ]; then s="conforme"; ok=$((ok+1)); else s="DIFFÉRENT"; ko=$((ko+1)); fi
  printf '%s | %s | %s | %s | %s\n' "$etat" "$nom" "$calc" "$att" "$s"
}
f() { sha256sum "$1" 2>/dev/null | cut -d' ' -f1; }
g() { git show "$1":"$2" 2>/dev/null | sha256sum | cut -d' ' -f1; }
compagnon() {  # vérifie aussi le compagnon .sha256 s'il existe
  local p="$1"; if [ -f "$p.sha256" ]; then
    local c; c=$(cut -d' ' -f1 "$p.sha256")
    if [ "$c" = "$(f "$p")" ]; then echo "  compagnon $p.sha256 : égal au recalcul"; else echo "  compagnon $p.sha256 : DIFFÉRENT ($c)"; ko=$((ko+1)); fi
  else echo "  compagnon $p.sha256 : absent"; fi
}
echo "# 05 — empreintes citées par les brouillons 2 ; $(date -u) ; clone HEAD $(git rev-parse HEAD)"
echo "état | objet | recalculé | attendu | statut"
# --- nouvelles ou modifiées dans les brouillons 2
verif "brouillons/T0.4-validation-modele-reel-v3-brouillon2.md" "$(f brouillons/T0.4-validation-modele-reel-v3-brouillon2.md)" 593c8818639e746b05bc37bddb33daecb5b662e9612adb1b80830da33616b393 nouveau
verif "brouillons/procedure-validation-T0.4-modele-reel-v4-brouillon2.md" "$(f brouillons/procedure-validation-T0.4-modele-reel-v4-brouillon2.md)" c24a60cfc0846d03e6cd2940404399b1418b94a3297eec2203a4a2791fd1e74f nouveau
verif "docs/notes/memoire-noyau-math-T0.4-v3-v2.md" "$(f docs/notes/memoire-noyau-math-T0.4-v3-v2.md)" 2e4e9683aaa8ea42d5f8bddb2fa26489a44485252b3fe1d461397e5beaf8d32b nouveau
compagnon docs/notes/memoire-noyau-math-T0.4-v3-v2.md
verif "diag/T0.4-v3-recalculs/q99_production_v2_v1.py" "$(f diag/T0.4-v3-recalculs/q99_production_v2_v1.py)" fa4ce30a604d48abbb0cfa18e80f0a9f0043480b789f2a1d0718ccf5f0e4b869 nouveau
compagnon diag/T0.4-v3-recalculs/q99_production_v2_v1.py
verif "diag/T0.4-v3-recalculs/q99_production_v2_v1.sortie.txt" "$(f diag/T0.4-v3-recalculs/q99_production_v2_v1.sortie.txt)" 911721ab456a073666948347641fe462b743d08feae41716ca57e80e9ebe5c4e nouveau
compagnon diag/T0.4-v3-recalculs/q99_production_v2_v1.sortie.txt
verif "archive CL1 : verifications/09-recalculs-v2.sortie.txt" "$(f "$X/cl1-verifications/verifications/09-recalculs-v2.sortie.txt")" c5905416cef38133c8dc1be1c11ef8ebbba0e5260d668e71583496dfdb511b28 nouveau
verif "archive CL1 : verifications/15-p5-ne-prouve-pas-p4.sortie.txt" "$(f "$X/cl1-verifications/verifications/15-p5-ne-prouve-pas-p4.sortie.txt")" 1c89a348e9bab3fac6b695fb02ee5fdf94d317412b7bfe31cbf3a249b2f5fff1 nouveau
verif "archive CL1 : verifications/18-rho-jouet.sortie.txt" "$(f "$X/cl1-verifications/verifications/18-rho-jouet.sortie.txt")" 0868f6f6463f549b4c7e4404c4a7b96dc8cad08a815786eec15813e0e99aa71f nouveau
verif "diag/20261006-103824-repetition-jouet/resume.json" "$(f diag/20261006-103824-repetition-jouet/resume.json)" f54e68653d861349a1c4d0e3cc23845c13e108cf3c070e6bf9efeae889e5da23 nouveau
compagnon diag/20261006-103824-repetition-jouet/resume.json
verif "diag/20261006-103834-repetition-jouet/resume.json" "$(f diag/20261006-103834-repetition-jouet/resume.json)" 3e9cd2f77d61520402c11e31c65c056e8de551cc2a94263085375976b25c7d7a nouveau
compagnon diag/20261006-103834-repetition-jouet/resume.json
verif "diag/20261006-103834-…/comparaison-20261006-103824-repetition-jouet.json" "$(f diag/20261006-103834-repetition-jouet/comparaison-20261006-103824-repetition-jouet.json)" 1b00baa6ed52950ae9f6212a15cf0d7ea64aa9fe0b53b760e367f0ddc050647b nouveau
compagnon diag/20261006-103834-repetition-jouet/comparaison-20261006-103824-repetition-jouet.json
verif "prereg/contre-lectures/T0.4-v3-mutations-v2.tar" "$(f prereg/contre-lectures/T0.4-v3-mutations-v2.tar)" 12c4e9b7a80ce086b74b7e5f40fbf9f51c3eb3a9890d0eb117a510fd0ae50001 nouveau
compagnon prereg/contre-lectures/T0.4-v3-mutations-v2.tar
verif "diag/essais-amorce-T0.4/essais-amorce-T0.4-v3-v3.tar" "$(f diag/essais-amorce-T0.4/essais-amorce-T0.4-v3-v3.tar)" 6650f86c4d739da14e721019f35b474f03fc4d5da40eaa0c0ad7e42155491aed nouveau
compagnon diag/essais-amorce-T0.4/essais-amorce-T0.4-v3-v3.tar
verif "prereg/contre-lectures/T0.4-v3-rapport-contre-lecture-1-v1.md" "$(f prereg/contre-lectures/T0.4-v3-rapport-contre-lecture-1-v1.md)" 6f7f8e0ae2132a42a9d41301c9f0eb4ce190e508877458dd54496ac230cd0ed4 nouveau
compagnon prereg/contre-lectures/T0.4-v3-rapport-contre-lecture-1-v1.md
verif "prereg/contre-lectures/T0.4-v3-contre-lecture-1-verifications-v1.tar" "$(f prereg/contre-lectures/T0.4-v3-contre-lecture-1-verifications-v1.tar)" 644b722b1314512ff2e16defd9a3f3b1e4023397ba6d167982a21982dabee66e nouveau
compagnon prereg/contre-lectures/T0.4-v3-contre-lecture-1-verifications-v1.tar
verif "brouillons/T0.4-validation-modele-reel-v3-brouillon1.md (cité dans « Contre-lecture 1 »)" "$(f brouillons/T0.4-validation-modele-reel-v3-brouillon1.md)" 25b93538d56b773126b8e70d70b34f563620df37ff0a8eeb50b32be7f9a56b26 nouveau
verif "brouillons/procedure-validation-T0.4-modele-reel-v4-brouillon1.md (cité dans « Contre-lecture 1 »)" "$(f brouillons/procedure-validation-T0.4-modele-reel-v4-brouillon1.md)" 56c0246532e07eb0480e00019c2a496803262d02a773020c16365e301bf2a745 nouveau
# --- scripts de l'instance : au commit cité b6ab5d1 (nouveau commit cité), à 62c74c6, à 2457743 et à HEAD
for c in b6ab5d15e76972a70e7ffc90cce4dbe280d03061 62c74c6 2457743 HEAD; do
  verif "scripts/validation_t04_instance.sh @ $c" "$(g "$c" scripts/validation_t04_instance.sh)" ae7050907c8062b015cf868569953906042e8b3fcf50441cd9ae745f79e2aefd "nouveau commit"
  verif "scripts/amorce_instance_t04.sh @ $c" "$(g "$c" scripts/amorce_instance_t04.sh)" 6d34fb18a2e21c83cd5dbb4627f30195838c15edfc2eed581f0d1674b96c6f19 "nouveau commit"
done
# --- reprises du brouillon 1 (revérifiées)
verif "prereg/T0.4-validation-modele-reel-v2.md" "$(f prereg/T0.4-validation-modele-reel-v2.md)" 886c8c07c6954a46c666b294c391523f0cdd3d03a5b99dae5079507503de3fb9 repris
verif "docs/verdicts/verdict-T0.4-critere-1-G0-v2.md" "$(f docs/verdicts/verdict-T0.4-critere-1-G0-v2.md)" 98d53c70c09ff9b4c0eea4f7ae8779d6dfa10bb6401ca6ac4567283c6fac07cb repris
verif "docs/decisions/proposition-N-011-v1.md" "$(f docs/decisions/proposition-N-011-v1.md)" aed4bd6c9db802775071bb37ff2ca8939f4c81dc4a85e2fdd6a36f992a81b35b repris
verif "docs/brief-claude-code-programme-complet-v2.md" "$(f docs/brief-claude-code-programme-complet-v2.md)" 9261932a11f29e8643175bc6e150d5455067f58a3cb1e57dca99e02cb17aa3b2 repris
verif "docs/programme-controle-ia-v2.md" "$(f docs/programme-controle-ia-v2.md)" 2fd63badb5afea48f48d3ca501ae3b027c4094a8b176508488a41a22e45aa18c repris
verif "livrables/premier-rendu-v1/devis-v1.md" "$(f livrables/premier-rendu-v1/devis-v1.md)" 16d71febf1491780ab1230ed1fb8e4d8b1bec47fbed202e0ef26ca666def04c2 repris
verif "docs/notes/memoire-double-precision-T0.4-v1.md" "$(f docs/notes/memoire-double-precision-T0.4-v1.md)" b013428ab8502a61a3ea19404ea3a6cdc64ea6a587010c45627e33f13ef29148 repris
verif "docs/notes/memoire-noyau-math-T0.4-v3-v1.md (préfixe 89ae46ac cité)" "$(f docs/notes/memoire-noyau-math-T0.4-v3-v1.md | cut -c1-8)" 89ae46ac repris
verif "diag/20261005-102042-validation-reelle/arret.json" "$(f diag/20261005-102042-validation-reelle/arret.json)" 4eb2d92069e270631bf3e4d25345b44191cbe419d71a4f06725659c32846aeed repris
verif "diag/20261005-144628-validation-reelle/arret.json" "$(f diag/20261005-144628-validation-reelle/arret.json)" e3ca201edef75f50409e42848f5c4faee0c411dd4a169933751c08bb228c63e6 repris
verif "docs/verdicts/verdict-T0.4-critere-1-G0-v2-recalculs.tar" "$(f docs/verdicts/verdict-T0.4-critere-1-G0-v2-recalculs.tar)" 992d566632fdd1c034ca9b7f586cc20278b92fa80bf00be7a8985f974d464d25 repris
verif "archive verdict v2 : recalculs/04-localisation-production.sortie.txt" "$(tar xOf docs/verdicts/verdict-T0.4-critere-1-G0-v2-recalculs.tar recalculs/04-localisation-production.sortie.txt | sha256sum | cut -d' ' -f1)" 107d7c8b1185c0ccda51d12e73ad0d14ca7e8e4ba20d9c4e5b70fc3300806867 repris
verif "diag/20261006-091344-repetition-jouet/resume.json" "$(f diag/20261006-091344-repetition-jouet/resume.json)" 0dbcef66386ccc240b0d967362fa57574237f866e43c6fe1c25347449933c1eb repris
verif "diag/20261006-091354-repetition-jouet/resume.json" "$(f diag/20261006-091354-repetition-jouet/resume.json)" 4132002b895e462e7799d11a83ceb219b881e2809279767be77c75ea0e366d45 repris
verif "diag/20261006-091354-…/comparaison-20261006-091344-repetition-jouet.json" "$(f diag/20261006-091354-repetition-jouet/comparaison-20261006-091344-repetition-jouet.json)" 027f93595230f59f6d0b9cad7efe7ec6750b219d2bfd656a7494c5f44a4f360c repris
verif "diag/20261006-092650-repetition-jouet/resume.json" "$(f diag/20261006-092650-repetition-jouet/resume.json)" c9bf1c0d9dd516dad49d5f7a54bc31883aa8f56bce041f360bd896da5d0c2717 repris
verif "diag/20261006-092700-repetition-jouet/resume.json" "$(f diag/20261006-092700-repetition-jouet/resume.json)" dec0bfa09ecb272aec8868abc18f7476c1a3a680545133f971dd37de48a5b45a repris
verif "diag/20261006-092700-…/comparaison-20261006-092650-repetition-jouet.json" "$(f diag/20261006-092700-repetition-jouet/comparaison-20261006-092650-repetition-jouet.json)" ace720e8e2b1b822bd2c4c7c0954565c707e9bf632ee77596f2313992cea9333 repris
verif "prereg/contre-lectures/T0.4-v3-mutations-auteur-v1.tar" "$(f prereg/contre-lectures/T0.4-v3-mutations-auteur-v1.tar)" d7efdaa776e281d4d3b342f2a40d5aee295ed7ff587e685f6a1801628d1dee8e repris
verif "diag/essais-amorce-T0.4/essais-amorce-T0.4-v3-v1.tar" "$(f diag/essais-amorce-T0.4/essais-amorce-T0.4-v3-v1.tar)" d35deb04eb03a0f5750889c66d5d9805a47b6d14927bd61fa0ca36e9bcb18c38 repris
verif "diag/essais-amorce-T0.4/essais-amorce-T0.4-v3-v2.tar" "$(f diag/essais-amorce-T0.4/essais-amorce-T0.4-v3-v2.tar)" aeeb02de42a8fa8597b9ee97bb4117b181233cebe8f7af40af04584b299dcb42 repris
verif "docs/procedures/validation-T0.4-modele-reel-v3.md (procédure)" "$(f docs/procedures/validation-T0.4-modele-reel-v3.md)" a91a5838f0ec44bae5689ed935eda1b558fcda692d6314106761da5ac02bce4b repris
verif "docs/procedures/surveiller-instance-t04-v1.sh (procédure)" "$(f docs/procedures/surveiller-instance-t04-v1.sh)" 5188c13c8f52746dcb5ba5aa52c6df0671eb9618411a6950299d080658eb526d repris
# --- identités de commit et de révision
echo "commit b6ab5d1 : $(git cat-file -t b6ab5d15e76972a70e7ffc90cce4dbe280d03061) ; 2457743 : $(git cat-file -t 2457743bbb92a492a9a3a97a92bee81921b4e43a)"
echo "révision 0e9e39f2… dans le prereg v2 : $(grep -c 0e9e39f249a16976918f6564b8830bc894c89659 prereg/T0.4-validation-modele-reel-v2.md) occurrence(s)"
echo "entropie 86918527404142130934456531865900787761 dans R-048 : $(grep -c 86918527404142130934456531865900787761 registres/decisions.md) ligne(s)"
echo "BILAN : $ok conformes, $ko différents"
