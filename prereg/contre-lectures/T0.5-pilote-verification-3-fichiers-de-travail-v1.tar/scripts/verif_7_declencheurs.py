"""Vérification 3 du pilote T0.5 — §7 : les déclencheurs de l'audit que les tests n'exercent pas (relevé du §5)
fonctionnent-ils ? Appels directs de `declencheurs_audit`, cas sain puis artefact, un déclencheur à la fois.

Lancer depuis la racine du dépôt : PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src .venv/bin/python <ce script>
"""
from controle_ia.environnements import lire_pilote as lp

sain_fmt = {"part_valides": 0.9}
d_sain = {"parts_tronquees": {"juge": 0.5}, "composantes": {"tache": 1.0}}
cas = {
    "part des actions valides = 1,00": (dict(fmt=sain_fmt), dict(fmt={"part_valides": 1.0})),
    "part illisible": (dict(juges={"8B": {"decomposition": d_sain}}),
                       dict(juges={"8B": {"decomposition": {"parts_tronquees": {"juge": float("nan")},
                                                            "composantes": {"tache": 1.0}}}})),
    "σ̂²_β ≤ 0 seul (part 0,5)": (dict(juges={"8B": {"decomposition": d_sain}}),
                                  dict(juges={"8B": {"decomposition": {"parts_tronquees": {"juge": 0.5},
                                                                       "composantes": {"tache": -0.2}}}})),
    "kappa > 0,95": (dict(kap={"controls": {"kappa": 0.7}}), dict(kap={"controls": {"kappa": 0.97}})),
    "couverture 0 ou 1 > 90 %": (dict(fam={"part_ensembles_controles_0_ou_1": 0.5}),
                                 dict(fam={"part_ensembles_controles_0_ou_1": 0.95})),
    "P(oui) toutes sous 0,05": (dict(p_oui=[0.02, 0.6]), dict(p_oui=[0.02, 0.01])),
}
for nom, (sain, artefact) in cas.items():
    sortie = []
    for x in (sain, artefact):
        a = lp.declencheurs_audit(x.get("fmt", sain_fmt), x.get("juges", {}), x.get("fam", {}), x.get("kap"),
                                  x.get("p_oui", [0.3, 0.7]))
        sortie.append(a["trop_propre"] + a["trop_sale"])
    print(f"{nom:32s} cas sain : {sortie[0]} ; artefact : {sortie[1]}")
