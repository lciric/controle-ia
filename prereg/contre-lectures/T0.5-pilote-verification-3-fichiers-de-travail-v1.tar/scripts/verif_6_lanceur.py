"""Vérification 3 du pilote T0.5 — §6 : ordre des étapes du lanceur (D-6) et échéance des notations (D-22), sur le code
réel en mode jouet, dans un dépôt jetable.

(a) Un arrêt pendant les notations de D doit laisser les notations décisives et l'appariement écrits.
(b) `noter_ensembles` : échéance contrôlée à chaque lot (cas sain : sans échéance ; artefact : échéance passée).

Lancer depuis la racine du dépôt : PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src .venv/bin/python <ce script> <dossier>
"""
import json
import shutil
import sys
from pathlib import Path

REEL = Path("/home/user/controle-ia")
sys.path.insert(0, str(REEL / "tests"))
from conftest import committer, git  # noqa: E402
from test_pilote_a import CIBLES_TEST, TACHES, _config_lanceur  # noqa: E402
from controle_ia.environnements import lancer_pilote_a as lanceur  # noqa: E402
from controle_ia.environnements import pilote_a as pa  # noqa: E402
from controle_ia.gardes import GardeArret  # noqa: E402

depot = Path(sys.argv[1]).resolve() / "lanceur"
if depot.exists():
    shutil.rmtree(depot)
depot.mkdir(parents=True)
git(depot, "init", "-q", "-b", "main")
git(depot, "config", "user.email", "test@example.invalid")
git(depot, "config", "user.name", "test")
f = depot / "taches.json"
f.write_text(json.dumps({"taches": [dict(t, cibles=CIBLES_TEST) for t in TACHES]}), encoding="utf-8")
from controle_ia.scellement import sceller  # noqa: E402
sceller(f)
committer(depot)

config = _config_lanceur()                                  # 2 épisodes par tâche ; e0 décisif (noté 2 fois), e1 : D
vrai_noter = lanceur.noter_ensembles
appels = []


def demandes(fiches, par_id, config, nom):                 # le modèle jouet ne forme pas d'ensemble : on en fournit
    return [{"cle": f"juge-{nom}/{x['episode']}/passe-{p}", "episode": x["episode"], "questions": "q",
             "ensemble": "PROPOSAL 1: x", "classification": None, "variante": "b0"}
            for x in fiches for p in range(lanceur.passes_de(x["episode"], config))]


def noter(m, fmt, dem, graines, *a, **k):
    descriptives = [d for d in dem if d["episode"].endswith("/e1")]
    appels.append(("descriptives" if descriptives else "decisives", len(dem)))
    if descriptives:
        raise GardeArret("arrêt simulé pendant les notations de D")
    return vrai_noter(m, fmt, dem, graines, *a, **k)


lanceur.demandes_de_notation = demandes
lanceur.noter_ensembles = noter
lanceur.paires_d_appariement = lambda fiches, par_id: [
    {"cle": "t/e0/1/C1", "proposition": "a dense baseline", "cible": "a dense baseline", "famille": "controls"}]
try:
    lanceur.executer(config, depot, "20261007-120000-ordre-jouet", None, str(f), autoriser_depot_sale=True)
except GardeArret as e:
    print("arrêt :", e)
diag = depot / "diag" / "20261007-120000-ordre-jouet"
print("appels de notation, dans l'ordre :", appels)
print("fichiers écrits :", sorted(p.name for p in diag.glob("*.json")))
arret = json.loads((diag / "arret.json").read_text(encoding="utf-8"))["resultat"]
print("étape consignée à l'arrêt :", arret["etape"], "; appariement écrit :", arret["partiel"].get("appariement_ecrit"))

print("\n(b) échéance des notations")
from test_pilote_a import FMT, _modele  # noqa: E402
dem = [{"cle": f"j{k}", "questions": "Why?", "ensemble": "PROPOSAL 1: x", "classification": None, "variante": "b0"}
       for k in range(3)]
s = pa.noter_ensembles(_modele(), FMT, dem, {"j0": 1, "j1": 2, "j2": 3}, lot=2, max_nouveaux=3, temperature=1.0)
print("sans échéance :", len(s), "notations")
try:
    pa.noter_ensembles(_modele(), FMT, dem, {"j0": 1, "j1": 2, "j2": 3}, lot=2, max_nouveaux=3, temperature=1.0,
                       echeance=0.0)
    print("échéance passée : PASSE (non vu)")
except GardeArret as e:
    print("échéance passée : arrêt :", e)
