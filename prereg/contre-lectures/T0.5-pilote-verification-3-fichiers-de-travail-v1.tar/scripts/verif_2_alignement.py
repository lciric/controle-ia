"""Vérification 3 du pilote T0.5 — §2 : alignement des notations (`notes_alignees`) sur la chaîne réelle du lanceur.

Les notations sont produites par le vrai code (`lancer_pilote_a.demandes_de_notation`, `pilote_a.noter_ensembles`, modèle
jouet), les fiches passent par l'aller-retour JSON d'`ecrire_resultat` (fichier UTF-8), puis la lecture recalcule les
empreintes (`empreintes_des_ensembles`) et contrôle l'alignement. Cas sain (textes non ASCII compris), puis artefacts.

Lancer depuis la racine du dépôt : PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src .venv/bin/python <ce script>
"""
import copy
import hashlib
import json
import tempfile
from pathlib import Path

from controle_ia.environnements import lancer_pilote_a as lanceur
from controle_ia.environnements import lire_pilote as lp
from controle_ia.environnements import pilote_a as pa
from controle_ia.environnements.propositions import EnvironnementPropositions, Tache
from controle_ia.gardes import GardeArret


def action(k, titre):
    return "\n".join([f"ACTION: ADD", f"TITLE: {titre} {k}", f"PROPOSAL: Run study {k} with a careful design.",
                      f"CONTROLS: baseline {k}; ablation {k}", "COST: 120", "PREDICTION: modest gains."])


TITRES = ["Étude ünïcode — « guillemets » “quotes” 🚀", "Plain title", "Ligne séparée\r\nCR LF", "Tab\tet espaces  "]
taches = [{"identifiant": f"2601.{k:05d}v1", "questions": f"Research question of task {k}?", "classification": None}
          for k in range(4)]
fiches = []
for i, t in enumerate(taches):
    for k in range(3):
        vide = (i == 1 and k == 1)                       # ensemble vide en e1 : C non noté
        textes = [] if vide else [action(1, TITRES[i]), action(2, TITRES[(i + k) % 4])]
        env = EnvironnementPropositions(Tache(t["identifiant"], t["questions"]), 1, max(len(textes), 1))
        fiches.append({"episode": f"{t['identifiant']}/e{k}", "tache": t["identifiant"],
                       "bilan": env.bilan([(0, s, x) for s, x in enumerate(textes)])})
print("ensembles non vides :", sum(1 for f in fiches if f["bilan"]["ensemble"].strip()), "sur", len(fiches))

config = {"episodes_notes_deux_fois": [0], "episodes_decisifs": [0, 1], "variante_juge": "b0"}
par_id = {t["identifiant"]: t for t in taches}
decisifs = {"0", "1"}
demandes = [d for d in lanceur.demandes_de_notation(fiches, par_id, config, "8B")
            if d["episode"].rsplit("/e", 1)[1] in decisifs]
modele, fmt = lanceur.charger_modele_et_format({"nom": "jouet"}, "jouet", 7)
graines = {d["cle"]: 1000 + i for i, d in enumerate(demandes)}
notations = pa.noter_ensembles(modele, fmt, demandes, graines, lot=4, max_nouveaux=4, temperature=1.0)
print("notations décisives produites :", len(notations))

# aller-retour JSON comme `ecrire_resultat` (indent=2, ensure_ascii=False, sort_keys=True, fichier UTF-8)
with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as d:
    f = Path(d) / "episodes.json"
    f.write_text(json.dumps({"resultat": {"fiches": fiches}}, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
                 encoding="utf-8")
    relues = json.loads(f.read_text(encoding="utf-8"))["resultat"]["fiches"]
    g = Path(d) / "notations.json"
    g.write_text(json.dumps({"resultat": {"notations": notations}}, indent=2, ensure_ascii=False, sort_keys=True)
                 + "\n", encoding="utf-8")
    notations_relues = json.loads(g.read_text(encoding="utf-8"))["resultat"]["notations"]

ensembles = lp.empreintes_des_ensembles(relues)
memes = all(n["ensemble_sha256"] == ensembles[n["cle"].split("/", 1)[1].rsplit("/passe-", 1)[0]]
            for n in notations_relues)
print("empreinte du lanceur = empreinte recalculée à la lecture, pour chaque notation :", memes)
ids = sorted(par_id)
al = lp.notes_alignees(notations_relues, "8B", ids, ensembles)
print("cas sain : notes_alignees passe ;", "réponses A, B, C :", al["reponses_ABC"])


def essai(nom, n):
    try:
        lp.notes_alignees(n, "8B", ids, ensembles)
        print(f"{nom:45s} -> PASSE (non vu)")
    except GardeArret as e:
        print(f"{nom:45s} -> arrêt : {e}")


n = copy.deepcopy(notations_relues)
c = [x for x in n if x["cle"].endswith("/e1/passe-0")]
c[0]["ensemble_sha256"], c[1]["ensemble_sha256"] = c[1]["ensemble_sha256"], c[0]["ensemble_sha256"]
essai("C permuté (empreintes échangées)", n)
n = copy.deepcopy(notations_relues)
x = dict(n[0], cle=n[0]["cle"].replace("/e0/", "/e2/"))
essai("notation en trop (e2 dans les décisives)", n + [x])
n = copy.deepcopy(notations_relues)
essai("notation d'un autre juge", [dict(y, cle=y["cle"].replace("juge-8B", "juge-3B")) for y in n])
n = copy.deepcopy(notations_relues)
vide = [y for y in fiches if not y["bilan"]["ensemble"].strip()][0]["episode"]
x = dict(n[0], cle=f"juge-8B/{vide}/passe-0", ensemble_sha256=hashlib.sha256(b"").hexdigest())
essai("notation d'un ensemble vide", n + [x])
# limite connue : l'empreinte ne porte que sur l'ensemble ; deux épisodes au même ensemble ne se distinguent pas
a = [y for y in notations_relues if y["cle"].endswith("/e0/passe-0")]
print("empreintes des ensembles toutes distinctes ici :", len(set(ensembles.values())) == len(ensembles))
