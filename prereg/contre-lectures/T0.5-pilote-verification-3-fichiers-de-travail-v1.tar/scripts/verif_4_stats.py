"""Vérification 3 du pilote T0.5 — §4 : statistiques de la lecture (code réel ; simulations stylisées, non opposables).

§4.1 kappa pondéré = kappa de Cohen sur les éléments répliqués (poids entiers) ; accords positif et négatif.
§4.2 difference_kappas : valeur ponctuelle recalculée à part ; couverture de l'intervalle apparié (simulation).
§4.3 intervalles_familles : même tirage pour toutes les mesures ; couverture (simulation).
§4.4 statut, predictions, lecture_juge : cas limites.

Lancer depuis la racine du dépôt : PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src .venv/bin/python <ce script>
"""
import numpy as np

from controle_ia.environnements import lire_pilote as lp
from controle_ia.environnements.analyse_pilote import kappa_cohen, kappa_pondere

graine = np.random.SeedSequence(20261007)
g1, g2, g3, g4 = (np.random.default_rng(s) for s in graine.spawn(4))

print("=== §4.1 kappa pondéré contre kappa de Cohen sur éléments répliqués")
ecart_max = 0.0
for _ in range(200):
    n = int(g1.integers(5, 40))
    r, j = g1.random(n) < 0.4, g1.random(n) < 0.5
    w = g1.integers(1, 6, n)
    k = kappa_pondere(r, j, w)
    rr, jj = np.repeat(r, w), np.repeat(j, w)
    try:
        ref = kappa_cohen(rr, jj)
    except Exception:
        ref = None
    if ref is None or k["kappa"] is None:
        assert ref is None and k["kappa"] is None
        continue
    a, b, c, d = (np.sum(rr & jj), np.sum(rr & ~jj), np.sum(~rr & jj), np.sum(~rr & ~jj))
    ecart_max = max(ecart_max, abs(k["kappa"] - ref), abs(k["accord_positif"] - 2 * a / (2 * a + b + c)),
                    abs(k["accord_negatif"] - 2 * d / (2 * d + b + c)))
print(f"écart maximal sur 200 cas : {ecart_max:.2e}")


def population(rng, n_taches, par_tache, p_oui, accord):
    """Éléments (déjà tirés, poids 1) : décision du 8B et étiquette ; l'étiquette suit la décision avec probabilité
    `accord`, sinon tirée au hasard ; un effet de tâche fait varier l'accord d'une tâche à l'autre."""
    el = []
    for t in range(n_taches):
        a_t = np.clip(accord + rng.normal(0, 0.05), 0, 1)
        for fam, p in p_oui.items():
            for _ in range(par_tache[fam]):
                oui = rng.random() < p
                ref = oui if rng.random() < a_t else (rng.random() < p)
                el.append({"tache": f"t{t:03d}", "famille": fam, "oui_8b": bool(oui),
                           "etiquette": "Yes" if ref else "No", "poids": 1.0})
    return el


print("\n=== §4.2 difference_kappas : ponctuel et couverture (64 tâches ; contrôles 30 % de oui, directions 10 %)")
p_oui = {"controls": 0.3, "fruitful_directions": 0.1, "sterile_directions": 0.1}
par_tache = {"controls": 3, "fruitful_directions": 2, "sterile_directions": 1}
grand = population(g2, 4000, par_tache, p_oui, accord=0.8)
vrai = lp._kappa([x for x in grand if x["famille"] != "controls"]) - lp._kappa(
    [x for x in grand if x["famille"] == "controls"])
couverts, ponctuel_ok, rep = 0, True, 120
for _ in range(rep):
    el = population(g2, 64, par_tache, p_oui, accord=0.8)
    r = lp.difference_kappas(el, np.random.default_rng(int(g2.integers(1 << 31))), tirages=400)
    kd = kappa_pondere([x["etiquette"] == "Yes" for x in el if x["famille"] != "controls"],
                       [x["oui_8b"] for x in el if x["famille"] != "controls"],
                       [1.0 for x in el if x["famille"] != "controls"])["kappa"]
    kc = kappa_pondere([x["etiquette"] == "Yes" for x in el if x["famille"] == "controls"],
                       [x["oui_8b"] for x in el if x["famille"] == "controls"],
                       [1.0 for x in el if x["famille"] == "controls"])["kappa"]
    ponctuel_ok &= abs(r["difference"] - (kd - kc)) < 1e-12
    couverts += r["borne"] is not None and r["borne"][0] <= vrai <= r["borne"][1]
print(f"différence vraie ≈ {vrai:.3f} ; ponctuel recalculé à part identique : {ponctuel_ok} ; "
      f"couverture de l'intervalle à 95 % : {couverts}/{rep}")

print("\n=== §4.3 intervalles_familles : même tirage pour toutes les mesures ; couverture")
par = {k: {} for k in lp.MESURES_FAMILLES}
for t in range(64):
    v = float(g3.beta(2, 5))
    for k in ("controles_ensemble", "controles_proposition"):
        par[k][f"t{t:02d}"] = v                         # deux mesures identiques par tâche
    par["fecondes_ensemble"][f"t{t:02d}"] = float(g3.beta(1, 6))
    if t < 20:
        par["steriles_proposition"][f"t{t:02d}"] = float(g3.beta(1, 3))
iv = lp.intervalles_familles(par, np.random.default_rng(1), tirages=500)
print("mesures identiques → intervalles identiques :", iv["controles_ensemble"] == iv["controles_proposition"])
print("stériles (20 tâches sur 64) : tirages écartés", iv["steriles_proposition"]["ecartes"],
      "; borne", [round(x, 3) for x in iv["steriles_proposition"]["borne"]])
couverts = 0
for _ in range(300):
    p = {k: {} for k in lp.MESURES_FAMILLES}
    for t in range(64):
        p["controles_ensemble"][f"t{t:02d}"] = float(g4.beta(2, 5))     # moyenne vraie 2/7
    r = lp.intervalles_familles(p, np.random.default_rng(int(g4.integers(1 << 31))), tirages=400)
    couverts += r["controles_ensemble"]["borne"][0] <= 2 / 7 <= r["controles_ensemble"]["borne"][1]
print(f"couverture de la moyenne vraie (2/7), 64 tâches : {couverts}/300 ; mesures sans tâche :",
      {k: v for k, v in r.items() if v is None})

print("\n=== §4.4 statut et prédictions : cas limites")
print("statut([None], [None]) :", lp.statut([None], [None]), "; statut([], []) :", lp.statut([], []),
      "; statut([True], [True]) :", lp.statut([True], [True]))
fmt = {"part_valides": 0.9, "part_cout_lu": 0.9}
fam = {"controles_ensemble": {"valeur": 0.4}, "fecondes_ensemble": {"valeur": 0.2}}
j_nan = {"8B": {"decomposition": {"parts_tronquees": {"juge": float("nan")}}, "decomposition_concluante": False},
         "3B": {}}
print("P2 sur une part illisible :", lp.predictions(fmt, j_nan, None, fam, {"mediane_log10": 0.0}, None, None)["P2"])
diff_47 = {"taches": 47, "borne": [0.1, 0.3]}
diff_48 = {"taches": 48, "borne": [0.1, 0.3]}
j = {"8B": {"decomposition": {"parts_tronquees": {"juge": 0.5}}, "decomposition_concluante": True}, "3B": {}}
print("P3 à 47 et 48 tâches communes :", lp.predictions(fmt, j, diff_47, fam, {"mediane_log10": 0.0}, None, None)["P3"],
      lp.predictions(fmt, j, diff_48, fam, {"mediane_log10": 0.0}, None, None)["P3"])
kap = {"controls": {"kappa": 0.5}, "directions": {"kappa": 0.7}}
print("P7, directions > contrôles, intervalle de la différence absent :",
      lp.predictions(fmt, j, diff_48, fam, {"mediane_log10": 0.0}, kap, {"borne": None})["P7"])

print("\n=== §4.4 lecture_juge : 60 tâches, part du juge vraie ≈ 0,9, incomplétude 0,25 ; puis 0")
rng = np.random.default_rng(5)
base = rng.normal(0, 0.5, 60)
al = {"sA": base + rng.normal(0, 1.5, 60), "sB": base + rng.normal(0, 1.5, 60), "sC": rng.normal(0, 0.5, 60) + base,
      "part_incompletes": 0.25, "part_A_B_identiques": 0.0, "tronquees": 0}
r = lp.lecture_juge(al, np.random.default_rng(1), tirages=300)
print("incomplétude 0,25 :", r["plan_b"], "; concluante :", r["decomposition_concluante"],
      "; part :", round(r["decomposition"]["parts_tronquees"]["juge"], 3))
r = lp.lecture_juge(dict(al, part_incompletes=0.0), np.random.default_rng(1), tirages=300)
print("incomplétude 0 :", r["plan_b"], "; borne basse :", round(r["intervalles"]["bornes"]["juge"][0], 3))
