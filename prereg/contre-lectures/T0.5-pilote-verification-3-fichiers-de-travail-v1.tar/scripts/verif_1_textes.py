"""Vérification 3 du pilote T0.5 — §1 : texte du brouillon 4 contre le code (lecture seule du dépôt).

Lancer depuis la racine du dépôt : PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src .venv/bin/python <ce script>
"""
import json
import re
import shutil
import sys
import tempfile
from pathlib import Path

RACINE = Path("/home/user/controle-ia")
B4 = RACINE / "brouillons/T0.5-pilote-8B-v1-brouillon4.md"
CONFIG = RACINE / "brouillons/T0.5-pilote-config-v1-brouillon1.json"

from controle_ia.environnements import lire_pilote as lp  # noqa: E402
from controle_ia import prereg  # noqa: E402

texte = B4.read_text(encoding="utf-8")


def titre(t):
    print(f"\n=== {t}")


titre("§1.1 annexe = CONSIGNE_ETIQUETAGE, invite fixe = INVITE_ETIQUETEUR")
bloc = re.search(r"```\n(.*?)```", texte.split("## Annexe")[1], re.S).group(1)
print("annexe identique à la constante :", bloc == lp.CONSIGNE_ETIQUETAGE)
invite = re.search(r"Invite fixe du sous-agent : « (.*?) »", texte).group(1)
print("invite identique :", invite == lp.INVITE_ETIQUETEUR)

titre("§1.2 clés de graines du texte (mot pour mot) = cles_analyse(['8B', '3B'])")
ligne = [x for x in texte.splitlines() if "chaque graine dérive du nom exact" in x][0]
cles_texte = re.findall(r"« (analyse/[^»]+?) »", ligne)
cles_code = lp.cles_analyse(["8B", "3B"])
print("texte :", cles_texte)
print("mêmes clés :", sorted(cles_texte) == sorted(cles_code), "; même ordre :", cles_texte == cles_code)

titre("§1.3 table clé → valeur du texte contre la configuration (brouillon 1)")
cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
ligne = [x for x in texte.splitlines() if x.startswith("- **Configuration** (clé → valeur")][0]
paires = re.findall(r"`?([A-Za-z_]+)`? = ([^;]+?)(?= ;|\. Le lanceur| ; `noyau)", ligne)
ecarts = []
for k, v in paires:
    v = v.strip()
    attendu = cfg.get(k, "ABSENTE")
    lu = re.sub(r"(\d)[  ](\d)", r"\1\2", v)            # « 3 072 » → 3072
    lu = re.sub(r"(\d),(\d)(?!\d* *[,\]])", r"\1.\2", lu) if not lu.startswith("[") else lu   # « 1,0 » → 1.0
    try:
        lu = json.loads(lu)
    except json.JSONDecodeError:
        pass
    if lu != attendu:
        ecarts.append((k, v, attendu))
print(f"{len(paires)} clés lues dans le texte ; écarts : {ecarts}")
absentes = sorted(set(cfg) - {k for k, _ in paires} - {"noyau_attention", "duree_max_s"})
print("clés de la configuration absentes de la table :", absentes)

titre("§1.4 constantes() : liste du texte contre le code")
print(sorted(lp.constantes()))

titre("§1.5 validateur problemes() sur le brouillon 4 (lecture seule) puis sur une copie remplie")
print("brouillon 4 :", prereg.problemes(B4))
with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as d:
    copie = Path(d) / "b4-rempli.md"
    rempli = texte.replace("`À REMPLIR`", "`" + "1" * 40 + "`").replace("À REMPLIR", "rempli " + "c" * 64)
    copie.write_text(rempli, encoding="utf-8")
    print("copie remplie :", prereg.problemes(copie))
    # artefact : la contre-lecture 1 perd une empreinte
    artefact = rempli.replace("b20b9139b20fd0c5c1b22dd28efcd830a2d420bf2a4c1d86a411db8d15bfe887", "b20b9139…")
    copie.write_text(artefact, encoding="utf-8")
    print("copie, contre-lecture 1 sans empreinte du brouillon :", prereg.problemes(copie))

titre("§1.6 format strict : « blancs de tête tolérés » (texte) — essais")
action = "ACTION: ADD\nTITLE: t\nPROPOSAL: p\nCONTROLS: c\nCOST: 1\nPREDICTION: x"
for nom, x in (("sain", action), ("lignes vides en tête", "\n\n" + action), ("espace en tête", " " + action),
               ("tabulation en tête", "\t" + action), ("ajout après PREDICTION", action + "\nI hope this helps!")):
    print(f"{nom:30s} format_strict = {lp.format_strict(x)}")

titre("§1.7 réserve d'épisodes D : où le texte l'écrit-il ?")
for i, l in enumerate(texte.splitlines(), 1):
    if "réserve d'épisodes" in l or ("même commit" in l and "noyau" in l):
        print(f"l. {i} : {l[:160]}")
corps = texte.split("## Contre-lecture")[0]
print("dans le corps (avant « Contre-lecture ») :", "réserve d'épisodes" in corps or "même commit, même configuration" in corps)
