"""Vérification 3 du pilote T0.5 — §3 : les gardes rejouées à chaque étape refusent-elles une étape saine ?

Dépôt jetable bâti par `tests/test_lire_pilote.construire` (modules de lecture copiés du dépôt réel, commités) dans
le dossier de ce script. Les trois étapes passent par la ligne de commande (`lire_pilote._main`), depuis la racine du
dépôt jetable avec des chemins relatifs, comme en production ; entre les étapes : commits de résultats, d'un fichier
de registre et d'un module hors de `MODULES_LECTURE`. Puis : engagement recalculé dans deux processus aux graines de
hachage différentes ; artefact : un module commun de `MODULES_LECTURE` modifié pour une autre tâche.

Lancer depuis la racine du dépôt réel : PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src .venv/bin/python <ce script> <dossier>
"""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

REEL = Path("/home/user/controle-ia")
sys.path.insert(0, str(REEL / "tests"))
import test_lire_pilote as T  # noqa: E402
from conftest import committer, git  # noqa: E402
from controle_ia.environnements import lire_pilote as lp  # noqa: E402
from controle_ia.gardes import GardeArret  # noqa: E402

lp.exiger_code_importe_sous = lambda racine: None    # code importé du dépôt réel (comme la fixture des tests)

base = Path(sys.argv[1]).resolve()
depot, travail = base / "depot", base / "travail"
for d in (depot, travail):
    if d.exists():
        shutil.rmtree(d)
depot.mkdir(parents=True)
travail.mkdir()
git(depot, "init", "-q", "-b", "main")
git(depot, "config", "user.email", "test@example.invalid")
git(depot, "config", "user.name", "test")
(depot / "README").write_text("x\n")
committer(depot)

d = T.construire(depot, n=50)
os.chdir(depot)
rel_prereg = str(Path(d["prereg"]).relative_to(depot))


def cli(*args):
    try:
        return lp._main(list(args))
    except GardeArret as e:
        print("ARRÊT :", e)
        return 1


print("préparation :", cli("preparer-etiquetage", "--run-pilote", T.RUN, "--run-analyse", T.ANALYSE,
                           "--prereg", rel_prereg, "--taches", "taches.json", "--travail", str(travail)) == 0)
committer(depot)
(depot / "registres").mkdir()
(depot / "registres" / "etat.md").write_text("état\n")
(depot / "src" / "controle_ia" / "autre_tache.py").write_text("x = 1\n")
committer(depot)
T._etiqueter_selon_8b(depot, d, travail, inverser=0.1)
print("lecture de l'étiquetage :", cli("lire-etiquetage", "--run-pilote", T.RUN, "--run-analyse", T.ANALYSE,
                                       "--taches", "taches.json", "--travail", str(travail)) == 0)
committer(depot)

# engagement recalculé dans deux processus neufs (graines de hachage différentes) : identique à celui scellé
code = (f"import sys, json; sys.path.insert(0, {str(REEL / 'tests')!r});"
        "import test_lire_pilote as T; from controle_ia.environnements import lire_pilote as lp;"
        "from pathlib import Path; d = {'taches': Path('taches.json')};"
        "print(lp._engagement(T._elements(Path('.'), d)))")
scelle = json.loads((depot / "diag" / T.ANALYSE / "echantillon-etiquetage.json").read_text())["resultat"][
    "engagement_sha256"]
for h in ("0", "12345"):
    env = dict(os.environ, PYTHONHASHSEED=h, PYTHONDONTWRITEBYTECODE="1", PYTHONPATH=str(REEL / "src"))
    r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, env=env, cwd=depot)
    print(f"engagement recalculé (PYTHONHASHSEED={h}) = scellé :", r.stdout.strip() == scelle, r.stderr[-300:])

# artefact réaliste : un module commun de MODULES_LECTURE (manifeste.py) modifié et commité pour une autre tâche
m = depot / "src" / "controle_ia" / "manifeste.py"
sain = m.read_text(encoding="utf-8")
m.write_text(sain + "\n# correction faite pour une autre tâche\n", encoding="utf-8")
committer(depot)
print("analyse après une modification de manifeste.py pour une autre tâche :",
      cli("analyser", "--run-pilote", T.RUN, "--run-analyse", T.ANALYSE, "--taches", "taches.json") == 0)
# le fichier ramené à l'état du commit cité, sans commit : la garde passe (le commit courant consigné est HEAD)
subprocess.run(["git", "checkout", "HEAD~1", "--", "src/controle_ia/manifeste.py"],     # HEAD~1 : état cité
               check=True, capture_output=True)
print("analyse avec manifeste.py ramené à l'état cité, non commité :",
      cli("analyser", "--run-pilote", T.RUN, "--run-analyse", T.ANALYSE, "--taches", "taches.json") == 0)
lecture = json.loads((depot / "diag" / T.ANALYSE / "lecture.json").read_text())["resultat"]
head = subprocess.run(["git", "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip()
etat = subprocess.run(["git", "status", "--short"], capture_output=True, text=True).stdout.strip()
print("commit_courant consigné = HEAD :", lecture["commit_courant"] == head, "; arbre non propre :", etat)
