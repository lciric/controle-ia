"""Vérification 3 du pilote T0.5 — §5 : quelles gardes d'arrêt et quels déclencheurs de l'audit les deux suites de tests
exercent-elles ? Relevé des lignes exécutées (traçage limité aux modules relus) pendant
`pytest tests/test_lire_pilote.py tests/test_pilote_a.py`.

Lancer depuis la racine du dépôt : PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src .venv/bin/python <ce script> <basetemp>
"""
import re
import sys
from pathlib import Path

import pytest

RACINE = Path("/home/user/controle-ia")
CIBLES = {str(RACINE / "src/controle_ia/environnements" / f): set() for f in
          ("lire_pilote.py", "analyse_pilote.py", "pilote_a.py", "lancer_pilote_a.py", "juges.py")}


def locale(frame, evenement, arg):
    if evenement == "line":
        CIBLES[frame.f_code.co_filename].add(frame.f_lineno)
    return locale


def globale(frame, evenement, arg):
    if frame.f_code.co_filename in CIBLES:
        CIBLES[frame.f_code.co_filename].add(frame.f_lineno)
        return locale
    return None


sys.settrace(globale)
code = pytest.main(["-q", "-p", "no:cacheprovider", f"--basetemp={sys.argv[1]}", "tests/test_lire_pilote.py",
                    "tests/test_pilote_a.py"])
sys.settrace(None)
print("pytest :", code)

MOTIF = re.compile(r"raise GardeArret|(propre|sale)\.append\(|_exiger_echeance\(|return \"non concluant\"|"
                   r"regle = \"nœud\"|plan_b=\"plan B\" if")
for f, vues in CIBLES.items():
    lignes = Path(f).read_text(encoding="utf-8").splitlines()
    gardes = [(i, l.strip()) for i, l in enumerate(lignes, 1) if MOTIF.search(l)]
    jamais = [(i, l) for i, l in gardes if i not in vues]
    print(f"\n== {Path(f).name} : {len(gardes)} lignes de garde ou de déclencheur, {len(jamais)} jamais exécutées")
    for i, l in jamais:
        print(f"  l. {i} : {l[:120]}")
