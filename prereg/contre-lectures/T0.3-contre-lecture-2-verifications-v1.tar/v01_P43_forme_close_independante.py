"""Contre-lecture 2 de T0.3 — recalcul indépendant de la forme close de P4.3.

Voie indépendante du code relu (`calibrage.puissance_dispersion_rebrassage`) :
- loi des tables par tirage séquentiel : l'agent d'arrivée 1 reçoit T cases parmi 3T (loi
  multi-hypergéométrique de population (T, T, T)), puis l'agent 2 reçoit T cases parmi les 2T restantes
  (population (T − n11, T − n12, T − n13)), l'agent 3 reçoit le reste ; probabilités en entiers exacts
  (numérateurs entiers, dénominateur commun C(3T, T)·C(2T, T)), sans log-gamma ;
- les tables sont regroupées par la valeur exacte de 4T·λ (entier) ;
- χ²₃ non central par mélange de Poisson de χ² centraux à 3 + 2j degrés de liberté, série sommée
  ici (scipy.special.gammaincc pour la queue du χ² central), sans scipy.stats.ncx2.

Analytique à T = 40 (configuration décisive : aucun tirage). Validation Monte-Carlo uniquement sur des
tailles jetables (T = 15 et 25), graine SeedSequence(8675309), avec des seuils non standard pour exercer
l'argument `seuil` du code relu.
"""
import math
import sys
from collections import defaultdict
from fractions import Fraction
from math import comb

import numpy as np
from scipy import special, stats

sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.simulation_t03 import calibrage as cal  # noqa: E402

MUS = (-0.5, 0.0, 0.5)          # 2T·μ_i = (−T, 0, T)


def numerateurs_par_cle(T):
    """{4T·λ (entier) : numérateur entier} et dénominateur commun."""
    C = [[comb(n, k) for k in range(n + 1)] for n in range(T + 1)]
    out = defaultdict(int)
    for a in range(T + 1):                     # n11 : cases de l'agent d'origine 1 (μ = −0,5) reçues par l'agent 1
        for b in range(T + 1 - a):             # n12
            cc = T - a - b                     # n13
            w1 = C[T][a] * C[T][b] * C[T][cc]
            r0, r1, r2 = T - a, T - b, T - cc
            for d in range(min(r0, T) + 1):    # n21
                for e in range(min(r1, T - d) + 1):   # n22
                    f = T - d - e              # n23
                    if f < 0 or f > r2:
                        continue
                    w2 = C[r0][d] * C[r1][e] * C[r2][f]
                    g, h, i = r0 - d, r1 - e, r2 - f   # n31, n32, n33
                    # μ̄_i − μ_i = ((n_i3 − n_i1) − 2Tμ_i)/(2T) ; λ = T·Σ(…)² = Σ((n_i3 − n_i1) − 2Tμ_i)²/(4T)
                    cle = ((cc - a) + T) ** 2 + (f - d) ** 2 + ((i - g) - T) ** 2
                    out[cle] += w1 * w2
    return out, comb(3 * T, T) * comb(2 * T, T)


def sf_ncx2_poisson(x, k, lam, tol=1e-17):
    """P(χ²_k(λ) ≥ x) = Σ_j Poisson(j ; λ/2) · P(χ²_{k+2j} ≥ x)."""
    if lam == 0:
        return float(special.gammaincc(k / 2, x / 2))
    h = lam / 2.0
    j0 = int(h)
    total = 0.0
    for direction in (range(j0, j0 + 5000), range(j0 - 1, -1, -1)):
        for j in direction:
            w = math.exp(-h + j * math.log(h) - math.lgamma(j + 1))
            total += w * float(special.gammaincc((k + 2 * j) / 2, x / 2))
            if w < tol and j != j0:
                break
    return total


_CACHE = {}


def puissance(T, c):
    if T not in _CACHE:
        num, den = numerateurs_par_cle(T)
        assert sum(num.values()) == den, "masse des tables ≠ 1"
        _CACHE[T] = (num, den)
    num, den = _CACHE[T]
    return sum(float(Fraction(n, den)) * sf_ncx2_poisson(c, 3, cle / (4 * T)) for cle, n in num.items())


if __name__ == "__main__":
    c_exact = float(stats.chi2.isf(0.05, 3))
    print(f"seuil χ²₃ exact à 5 % : {c_exact:.6f}")
    print("T | indépendant | code relu | écart")
    for T in (10, 15, 20, 25, 30, 40, 50, 60):
        a = puissance(T, c_exact)
        b = cal.puissance_dispersion_rebrassage(T, MUS, 0.05)
        print(f"{T} | {a:.6f} | {b:.6f} | {a - b:+.2e}")
    print("\nArgument `seuil` du code relu (seuils non standard) :")
    for T, c in ((15, 7.5), (25, 8.2), (40, 7.70), (40, 7.95)):
        a = puissance(T, c)
        b = cal.puissance_dispersion_rebrassage(T, MUS, 0.05, c)
        print(f"T = {T}, c = {c} : indépendant {a:.6f}, code {b:.6f}, écart {a - b:+.2e}")
    # sensibilité au bruit du seuil Monte-Carlo du run (R_cal = 100 000) : analytique
    f = stats.chi2.pdf(c_exact, 3)
    sd_c = math.sqrt(0.05 * 0.95 / 100_000) / f
    print(f"\nÉcart-type du seuil Monte-Carlo (R_cal = 100 000) ≈ {sd_c:.4f} ; puissance à T = 40 pour c ± 2 écarts-types : "
          f"{puissance(40, c_exact - 2 * sd_c):.5f} / {puissance(40, c_exact + 2 * sd_c):.5f}")

    # Monte-Carlo sur tailles jetables seulement (T = 15 et 25), seuils non standard
    ss = np.random.SeedSequence(8675309)
    print("\nMonte-Carlo (tailles jetables), R = 200 000, graine SeedSequence(8675309) :")
    for (T, c), enfant in zip(((15, 7.5), (25, 8.2)), ss.spawn(2)):
        g = np.random.default_rng(enfant)
        R = 200_000
        Y = np.asarray(MUS)[None, :, None] + g.standard_normal((R, 3, T))
        x = Y.transpose(0, 2, 1).reshape(R, 3 * T)            # ordre « temps d'abord »
        x = np.take_along_axis(x, np.argsort(g.random(x.shape), axis=1), axis=1)   # rebrassage uniforme
        X = x.reshape(R, T, 3).transpose(0, 2, 1)
        D = (T * (X.mean(axis=2) - np.asarray(MUS)[None, :]) ** 2).sum(axis=1)
        p = float((D >= c).mean())
        p_th = puissance(T, c)
        se = math.sqrt(p_th * (1 - p_th) / R)
        print(f"T = {T}, c = {c} : simulé {p:.5f}, forme close {p_th:.5f}, z = {(p - p_th) / se:+.2f}")
