"""Contre-lecture 2 de T0.3 — P3.2 sur tailles jetables (n₀ = 190 et 210, jamais 200), graine SeedSequence(31415926).
Vérifie : (1) le couplage trajectoire par trajectoire (fin ⇒ début, fin ⇒ uniforme, à égalité près), donc
qu'une « fausse contrariété » est impossible ; (2) la marge de « au-dessus » (z de lecture.au_dessus) pour
chaque (B, m), B rééchelonné par √(n₀/200) pour garder B/√n₀ égal à celui de la grille.
Utilise les fonctions du code relu (positions, décalages, série e, ρ*)."""
import math
import sys

import numpy as np

sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.simulation_t03 import attaques as att  # noqa: E402
from controle_ia.simulation_t03 import calibrage as cal  # noqa: E402
from controle_ia.simulation_t03 import lecture as LEC  # noqa: E402
from controle_ia.simulation_t03 import lots as L  # noqa: E402

R = 10_000
h = math.log(20)
ss = np.random.SeedSequence(31415926)
zmin = {}
for n0, enfant in zip((190, 210), ss.spawn(2)):
    g = np.random.default_rng(enfant)
    rho = cal.rho_optimal(n0, 0.05, "unilateral")[0]
    y = g.standard_normal((R, n0))
    for B0 in (15, 25, 35):
        B = B0 * math.sqrt(n0 / 200)
        for m in (1, 10, 50):
            al, eg = {}, {}
            for s in ("debut", "uniforme", "fin"):
                P = att.positions(s, m, 1, n0, R, g)
                x = att.appliquer_decalages(y, P, att.decalages("egaux", m, B, R, g))
                mx = L.serie_e(x, rho, "unilateral").max(axis=1)
                al[s], eg[s] = mx >= h, np.abs(mx - h) <= 1e-9
            viol_d = int((al["fin"] & ~al["debut"]).sum())
            viol_u = int((al["fin"] & ~al["uniforme"]).sum())
            p = {s: float(al[s].mean()) for s in al}
            et_d, z_d = LEC.au_dessus(p["debut"], R, p["fin"], R)
            et_u, z_u = LEC.au_dessus(p["uniforme"], R, p["fin"], R)
            zmin[(n0, B0, m)] = (z_d, z_u)
            print(f"n0={n0} B={B:.2f} m={m:2d} : début {p['debut']:.4f} uniforme {p['uniforme']:.4f} fin {p['fin']:.4f} | "
                  f"début>fin {et_d} z={z_d:6.1f} ; uniforme>fin {et_u} z={z_u:6.1f} | fin sans début {viol_d}, fin sans uniforme {viol_u}")
zd = min(v[0] for v in zmin.values())
zu = min(v[1] for v in zmin.values())
print(f"z minimal (R = {R}) : début>fin {zd:.1f} ; uniforme>fin {zu:.1f} ; à R = 20 000 environ ×√2 : {zd*math.sqrt(2):.1f} / {zu*math.sqrt(2):.1f}")
