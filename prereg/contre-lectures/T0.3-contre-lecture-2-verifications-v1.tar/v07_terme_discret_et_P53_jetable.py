"""Contre-lecture 2 de T0.3 —
(1) Rem-16 : le test `test_garde_p0_saine_et_artefact` distingue-t-il la nouvelle borne du cas discret
    (terme 1/R_cal) de l'ancienne ? On évalue `garde_p0` à un taux situé entre les deux bornes.
(2) Rem-22 : tolérances resserrées de P5.3 (grille v2 : 10⁻⁴·ΣZ² et 1 changement) sur tailles jetables
    T = 190 et 210 (jamais 200), R = 2 000, 6 000 échanges, graine SeedSequence(16180339887).
"""
import math
import sys

import numpy as np

sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.simulation_t03 import attaques as att  # noqa: E402
from controle_ia.simulation_t03 import blocs as B  # noqa: E402

a, R0, Rc = 0.05, 100_000, 100_000
v = a * (1 - a)
ancienne = a + 4 * math.sqrt(v / R0)
nouvelle = a + 4 * math.sqrt(v / R0 + v / Rc)
k = int(round((ancienne + nouvelle) / 2 * R0))
res = {"cfg": "x", "garde": True, "R0": R0, "R_cal": Rc, "garde_exclus": [], "alarmes_p0": {"suites": k},
       "genres": {"suites": "mc_discret"}}
print(f"(1) bornes discrètes : ancienne {ancienne:.5f}, nouvelle {nouvelle:.5f} ; taux essayé {k / R0:.5f} -> "
      f"manquements avec le code relu : {B.garde_p0(res, a, 4.0)} (l'ancienne formule l'aurait signalé)")
print("    taux de l'artefact du test : 0,06000 (au-dessus des deux bornes : le test ne distingue pas les formules)")

ss = np.random.SeedSequence(16180339887)
for T, enfant in zip((190, 210), ss.spawn(2)):
    g = np.random.default_rng(enfant)
    y = g.standard_normal((2000, T))
    for cible in ("autocorr", "suites"):
        x0, debut = att.bloc_top_r(y, 5, g)
        xa, ecart = att.apparier(x0, debut, 5, cible, g, 6000)
        if cible == "autocorr":
            Z = xa - xa.mean(axis=1, keepdims=True)
            rel = np.abs(ecart) / (Z * Z).sum(axis=1)
            hors = rel > 1e-4
            print(f"(2) T = {T}, autocorr : hors tolérance {hors.mean():.4f} ; écart relatif q50 {np.quantile(rel, 0.5):.1e}, "
                  f"q99 {np.quantile(rel, 0.99):.1e}, max {rel.max():.1e}")
        else:
            hors = np.abs(ecart) > 1
            print(f"(2) T = {T}, suites : hors tolérance {hors.mean():.4f} ; écarts distincts {sorted(set(np.abs(ecart).astype(int).tolist()))}")
