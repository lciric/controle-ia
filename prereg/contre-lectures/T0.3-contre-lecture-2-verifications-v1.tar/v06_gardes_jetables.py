"""Contre-lecture 2 de T0.3 — cas limites des gardes nouvelles, sur un dépôt git jetable du bloc-notes
(le dépôt du programme n'est pas touché). Aucun tirage décisif.
1. garde du commit cité : cas sain ; src/ modifié ; tests/ modifié ; commit inconnu ; grille hors du dépôt ;
   préenregistrement avec apostrophe typographique ou espace insécable avant « : » ;
2. `exiger_multiensemble` : axe 2 (par agent) plus strict que l'axe 1 (épisode) ;
3. `fusionner` : branche « cellule trajectorielle absente de la lecture principale » ; cellule statistique
   contraire dont la réplication est « non concluant » ; docstring.
"""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np

sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.gardes import GardeArret  # noqa: E402
from controle_ia.simulation_t03 import blocs as B  # noqa: E402
from controle_ia.simulation_t03 import lecture as LEC  # noqa: E402
from controle_ia.simulation_t03.run_t03 import exiger_code_cite  # noqa: E402


def git(d, *a):
    return subprocess.run(["git", "-C", str(d), *a], check=True, capture_output=True, text=True).stdout.strip()


def essai(nom, f):
    try:
        r = f()
        print(f"{nom} : passe ({r[:12] if isinstance(r, str) else r})")
    except GardeArret as e:
        print(f"{nom} : GardeArret — {e}")
    except Exception as e:                      # noqa: BLE001
        print(f"{nom} : AUTRE EXCEPTION {type(e).__name__} — {e}")


base = Path(tempfile.mkdtemp(prefix="cl2-", dir="/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/t03/contre-lecture-2"))
d = base / "depot"
d.mkdir()
git(d, "init", "-q", "-b", "main")
git(d, "config", "user.email", "x@example.invalid")
git(d, "config", "user.name", "x")
(d / "src").mkdir()
(d / "tests").mkdir()
(d / "src" / "a.py").write_text("X = 1\n")
(d / "tests" / "t.py").write_text("Y = 1\n")
(d / "prereg").mkdir()
(d / "prereg" / "grille.json").write_text("{}\n")
git(d, "add", "-A")
git(d, "commit", "-q", "-m", "code")
c = git(d, "rev-parse", "HEAD")
pp = d / "prereg" / "p.md"
pp.write_text(f"- Commit du code d'analyse : `{c}`.\n")
git(d, "add", "-A")
git(d, "commit", "-q", "-m", "prereg")
gr = d / "prereg" / "grille.json"

essai("1a cas sain (prereg committé après le commit cité)", lambda: exiger_code_cite(d, pp, gr))
(d / "tests" / "t.py").write_text("Y = 2\n")
git(d, "commit", "-qam", "tests")
essai("1b tests/ modifié et committé", lambda: exiger_code_cite(d, pp, gr))
git(d, "revert", "--no-edit", "HEAD")
essai("1c après retour arrière (contenu identique au commit cité)", lambda: exiger_code_cite(d, pp, gr))
(d / "src" / "a.py").write_text("X = 3\n")
essai("1d src/ modifié NON committé (la garde compare des commits)", lambda: exiger_code_cite(d, pp, gr))
git(d, "checkout", "--", "src/a.py")
p2 = d / "p2.md"
p2.write_text("- Commit du code d'analyse : `" + "a" * 40 + "`.\n")
essai("1e commit cité inconnu", lambda: exiger_code_cite(d, p2, gr))
ext = base / "grille_hors_depot.json"
shutil.copy(gr, ext)
essai("1f grille hors du dépôt", lambda: exiger_code_cite(d, pp, ext))
p3 = d / "p3.md"
p3.write_text(f"- Commit du code d’analyse : `{c}`.\n")
essai("1g apostrophe typographique", lambda: exiger_code_cite(d, p3, gr))
p4 = d / "p4.md"
p4.write_text(f"- Commit du code d'analyse : `{c}`.\n")
essai("1h espace insécable avant « : »", lambda: exiger_code_cite(d, p4, gr))
p5 = d / "p5.md"
p5.write_text(f"- Commit du code d'analyse : `{c[:12]}`.\n")
essai("1i commit abrégé (12 caractères)", lambda: exiger_code_cite(d, p5, gr))

# 2. multi-ensemble : échange entre agents au même pas (préserve l'épisode, pas chaque agent)
g = np.random.default_rng(np.random.SeedSequence(4242))
Y = g.standard_normal((5, 3, 8))
X = Y.copy()
X[:, [0, 1], 0] = X[:, [1, 0], 0]
essai("2a échange entre agents, axe 1 sur l'ordre de lecture", lambda: B.exiger_multiensemble(
    Y.transpose(0, 2, 1).reshape(5, -1), X.transpose(0, 2, 1).reshape(5, -1), "essai"))
essai("2b même échange, axe 2 (par agent, garde de P4.3 intra-agent)", lambda: B.exiger_multiensemble(X, Y, "essai", axe=2))

# 3. fusion
principale = {"predictions": {"P5.1": {"verdict": "confirmée", "cellules": [
    {"nom": "bloc_r3", "etat": "conforme", "genre": "trajectoriel"}]},
    "P2.1": {"verdict": "réfutée", "cellules": [{"nom": "a", "etat": "contraire", "genre": "statistique"}],
             "a_repliquer": ["a"]}}}
rep = {"predictions": {"P5.1": {"cellules": [{"nom": "inconnue", "etat": "contraire", "genre": "trajectoriel"}]},
                       "P2.1": {"cellules": [{"nom": "a", "etat": "non concluant", "genre": "statistique"}]}}}
f = LEC.fusionner(principale, rep)
print("3a cellule trajectorielle contraire absente de la principale :", f["predictions"]["P5.1"]["verdict"],
      f["predictions"]["P5.1"]["a_auditer"])
print("3b statistique contraire, réplication non concluante :", f["predictions"]["P2.1"]["cellules"][0]["etat"],
      "; a_repliquer conservé tel quel :", f["predictions"]["P2.1"].get("a_repliquer"))
print("3c docstring de fusionner :", " ".join(LEC.fusionner.__doc__.split()))
shutil.rmtree(base)
