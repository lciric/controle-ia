"""Contre-lecture 2 de T0.3 — nombre de cellules et d'écarts réduits de l'audit, à partir du code et de la
grille v2, SANS exécuter la grille : la structure des résultats de chaque bloc est reconstruite à la main
d'après `blocs.py` (mêmes boucles, mêmes clés), avec des comptes FACTICES (aucun tirage, aucun taux).
La lecture gelée (`lecture.Lecteur`) est ensuite appliquée pour compter les cellules par genre et les
entrées des deux ensembles de l'audit de symétrie. Seules des formes closes analytiques sont évaluées
(ρ*, bornes, puissances) ; aucune ne dépend des comptes factices.
"""
import json
import sys
from collections import Counter

sys.path.insert(0, "/home/user/controle-ia/src")
from scipy import stats  # noqa: E402

from controle_ia.simulation_t03 import calibrage as cal  # noqa: E402
from controle_ia.simulation_t03 import lecture as LEC  # noqa: E402
from controle_ia.simulation_t03.blocs import nom_statistique  # noqa: E402

G = json.load(open("/home/user/controle-ia/prereg/T0.3-grille-v2.json", encoding="utf-8"))
R, R0, RP2 = 1000, 1000, 1000           # comptes factices : seuls les nombres de cellules comptent
A = 0.05


def calibrage():
    out = {}
    for cfg, spec in G["configs"].items():
        seuils = {a: 1.0 for a in spec["alarmes"]}
        if cfg == "hetero_3x40":
            seuils["dispersion_agents"] = float(stats.chi2.isf(A, 3))
        out[cfg] = {"cfg": cfg, "loi": spec["loi"], "R0": R0, "seuils": seuils,
                    "alarmes_p0": {a: 50 for a in spec["alarmes"]}}
    return out


def P1a():
    g = G["P1a"]
    groupes = []
    for N, T in g["configs"]:
        n0 = N * T
        for B in g["B"]:
            cel = []
            for schema in g["schemas"]:
                if N == 1 and schema in ("un_agent", "reparti"):
                    continue
                for m in g["m"]:
                    if m > n0 or (schema == "un_agent" and m > T):
                        continue
                    for genre in (["egaux", "dirichlet"] if schema == "aleatoire" else ["egaux"]):
                        cel.append({"schema": schema, "m": m, "genre": genre, "disc_somme": 0, "disc_eterm": 0,
                                    "ecart_max": 0.0})
            groupes.append({"N": N, "T": T, "n0": n0, "B": B, "R": R, "alarmes_ref_somme": 300,
                            "tolerance_ecart": 1e-9 * n0, "cellules": cel})
    return {"groupes": groupes}


def P1b():
    g = G["P1b"]
    return {"cellules": [{"N": N, "T": T, "n0": N * T, "B": B, "m": g["m"], "R": R, "alarmes_somme": 300}
                         for N, T in g["configs"] for B in g["B"]]}


def P2():
    g = G["P2"]
    N, T = g["config"]
    return {"cfg": f"gauss_{N}x{T}", "cellules": [{"B": B, "m": m, "n0": N * T, "R": RP2, "alarmes_max": 300}
                                                  for B in g["B"] for m in g["m"]]}


def P3():
    g = G["P3"]
    rho = cal.rho_optimal(200, A, "unilateral")[0]
    groupes = []
    for N, T in g["configs"]:
        for B in g["B"]:
            groupes.append({"N": N, "T": T, "n0": N * T, "B": B, "R": R, "rho": rho, "alarmes_terminal": 100,
                            "cellules": [{"m": m, "calendrier": s, "alarmes": 500} for m in g["m"] for s in g["calendriers"]],
                            "violations": {str(m): {"debut>uniforme": 0, "uniforme>fin": 0, "debut>aleatoire": 0,
                                                    "aleatoire>fin": 0, "fin>terminal": 0} for m in g["m"]}})
    return {"groupes": groupes}


def P34():
    g = G["P34"]
    return {"cfg": "gauss_1x200", "cellules": [{"B": B, "m": m, "n0": 200, "R": R,
                                                "comptes": {a: {"a_temps": 100, "d_ici_n0": 100} for a in g["alarmes"]}}
                                               for B in g["B"] for m in g["m"]]}


def P4():
    g = G["P4"]
    out = []
    sym = ["somme", "max", "e_terminal"]
    for N, T in g["configs"]:
        liste = G["configs"][f"gauss_{N}x{T}"]["alarmes"]
        arr_T1 = [a for a in g["arrangements_T1"] if N == 1 or a != "apparie_autocorr"]
        out.append({"N": N, "T": T, "n0": N * T, "R": R,
                    "T1": {a: {"valeurs_differentes": {s: 0 for s in sym}, "discordances": {s: 0 for s in sym}} for a in arr_T1},
                    "T2": {a: {al: 50 for al in liste} for a in g["arrangements_T2"]}})
    return {"configs": out}


def P5_temps():
    g = G["P5_temps"]
    noms = [f"bloc_r{r}" for r in g["r"]] + ["apparie_autocorr", "apparie_suites"]
    rr = {f"bloc_r{r}": r for r in g["r"]} | {"apparie_autocorr": 5, "apparie_suites": 5}
    return {"cfg": "gauss_1x200", "R": R, "n0": 200,
            "arrangements": {a: {"alarmes": {x: 100 for x in g["alarmes"]}, "viol_glissante": 0, "viol_page": 0,
                                 "borne_glissante": 0, "borne_sans_alarme": 0, "ecart_hors_tolerance": 0, "r": rr[a]}
                             for a in noms}}


def P5_agents():
    g = G["P5_agents"]
    N, T = g["config"]
    return {"cfg": f"gauss_{N}x{T}", "mc": g["mc"], "R": R, "n0": N * T,
            "alarmes": {x: 100 for x in g["alarmes"]}, "viol_co_elevation": 0}


def P6():
    return {"cellules": [{"nom": c["nom"], "role": c["role"], "cfg": c["cfg"], "loi": c["loi"], "R": R,
                          "alarmes": {x: 100 for x in c["alarmes"]}} for c in G["P6"]["cellules"]]}


def P7():
    g = G["P7"]
    return {"cfg": "gauss_1x200", "R": R, "n0": 200, "arrangements": {
        a: {"alarmes": {x: 100 for x in g["alarmes"]}, "viol_inclusion_haute": 0, "viol_inclusion_basse": 0,
            "viol_sommes_partielles": 0} for a in g["arrangements"]}}


def P8():
    g = G["P8"]
    c = g["conforme"]
    return {"reglages": [{"nom": s["nom"], "loi": s["loi"], "cfg": "x", "R": R, "alarmes": {x: 30 for x in g["alarmes"]},
                          "conforme": {"K": c["K"], "n_test": c["n_test"], "L": c["L"],
                                       "alarmes_par_tirage": {st: [20 + (l % 3) for l in range(c["L"])] for st in c["statistiques"]},
                                       "taux_theorique": cal.taux_conforme(c["K"], A)}} for s in g["reglages"]]}


resultats = {"calibrage": calibrage(), "P1a": P1a(), "P1b": P1b(), "P2": P2(), "P3": P3(), "P34": P34(), "P4": P4(),
             "P43": {"cfg": "hetero_3x40", "R": R, "alarmes_total": 900, "alarmes_intra_agent": 50},
             "P5_temps": P5_temps(), "P5_agents": P5_agents(), "P6": P6(), "P7": P7(), "P8": P8()}
lec = LEC.Lecteur(resultats, A)
sortie = lec.lire(G["P8"]["lecture"])
par_genre = Counter()
par_pred = {}
for k, x in sortie["predictions"].items():
    for c in x["cellules"]:
        par_genre[c["genre"]] += 1
    par_pred[k] = (x["n_cellules"], x["cellules"][0]["genre"])
print("cellules par genre :", dict(par_genre))
print("cellules par prédiction :", {k: v[0] for k, v in sorted(par_pred.items())})
a = sortie["audit_symetrie"]
print("audit, formes closes :", a["formes_closes"]["n"], "; égalités :", a["egalites"]["n"])
# détail des formes closes retenues dans l'audit, par prédiction
detail = Counter()
for k, x in sortie["predictions"].items():
    for c in x["cellules"]:
        if "p_th" in c and 0.01 <= c["p_th"] <= 0.99:
            detail[k] += 1
print("formes closes retenues dans [0,01 ; 0,99], par prédiction :", dict(sorted(detail.items())))
p43 = [c for c in sortie["predictions"]["P4.3"]["cellules"] if "p_th" in c][0]
print(f"P4.3 forme close au quantile χ²₃ exact (analytique, T = 40) : {p43['p_th']:.6f}")
prog = LEC.enonces_du_programme(sortie)
print("lignes de la table E :", len(prog), [len(l["exiges"]) for l in prog], [len(l["complementaires"]) for l in prog])
