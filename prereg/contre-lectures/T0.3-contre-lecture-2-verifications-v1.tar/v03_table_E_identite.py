"""Contre-lecture 2 de T0.3 — la table E du brouillon 2 est-elle identique, mot pour mot, à `lecture.LIGNES_E` ?
Compare énoncé, lecture, exigées et complémentaires, ligne par ligne, caractère par caractère."""
import difflib
import sys
from pathlib import Path

sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.simulation_t03.lecture import LIGNES_E  # noqa: E402

texte = Path("/home/user/controle-ia/brouillons/T0.3-simulation-lemme-theoreme-v1-brouillon2.md").read_text(encoding="utf-8")
debut = texte.index("| Énoncé | Lecture prononcée si toutes les exigées sont confirmées | Exigées | Complémentaires |")
lignes = texte[debut:].split("\n")
corps = []
for l in lignes[2:]:
    if not l.startswith("|"):
        break
    corps.append(l)
print("lignes de la table E dans le texte :", len(corps), "; dans le code :", len(LIGNES_E))
ok = True
for i, (l, ref) in enumerate(zip(corps, LIGNES_E), 1):
    cellules = [c.strip() for c in l.strip().strip("|").split(" | ")]
    if len(cellules) != 4:
        print(f"ligne {i} : {len(cellules)} colonnes"); ok = False; continue
    enonce, lecture, exiges, compl = cellules
    attendu = {"enonce": ref["enonce"], "lecture": ref["lecture"], "exiges": ", ".join(ref["exiges"]),
               "complementaires": ", ".join(ref["complementaires"]) or "—"}
    for nom, v in (("enonce", enonce), ("lecture", lecture), ("exiges", exiges), ("complementaires", compl)):
        if v != attendu[nom]:
            ok = False
            print(f"ligne {i}, {nom} : DIFFÉRENT")
            for d in difflib.ndiff([attendu[nom]], [v]):
                print("   ", d)
print("identité mot pour mot :", ok)
