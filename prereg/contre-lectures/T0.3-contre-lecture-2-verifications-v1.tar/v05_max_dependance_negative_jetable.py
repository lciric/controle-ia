"""Contre-lecture 2 de T0.3 — table E, ligne 3 : « le max reste à son taux ou en dessous (Slepian) » vaut-il
aussi sous dépendance négative ? Inégalité de Slepian : covariances ≤ 0 ⇒ P(max < c) ≤ produit des marginales,
donc taux du max ≥ taux iid. Taille jetable T = 190 (jamais 200), seuil iid exact c_190, copule AR(1)
gaussienne (le taux du max est le même pour toute marginale obtenue par transformation croissante).
Graine SeedSequence(27182818284)."""
import math
import sys

import numpy as np

sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.simulation_t03 import calibrage as cal  # noqa: E402
from controle_ia.simulation_t03.lois import tirer  # noqa: E402

T, R, morceau = 190, 1_000_000, 50_000
c = cal.seuil_max_exact(0.05, T)
ss = np.random.SeedSequence(27182818284)
for phi, enfant in zip((-0.5, -0.25, 0.0, 0.5), ss.spawn(4)):
    g = np.random.default_rng(enfant)
    k = 0
    for _ in range(R // morceau):
        X = tirer(g, morceau, {"type": "ar1", "phi": phi, "N": 1, "T": T} if phi != 0 else
                  {"type": "iid", "marginale": "gauss", "N": 1, "T": T})
        k += int((X.reshape(morceau, -1).max(axis=1) >= c).sum())
    p = k / R
    se = math.sqrt(0.05 * 0.95 / R)
    print(f"φ = {phi:+.2f} : taux du max {p:.5f} (iid exact : 0,05000) ; écart {(p - 0.05) / se:+.1f} écarts-types (R = {R})")
