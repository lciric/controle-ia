"""Bouchon du générateur (vérification c4) : mêmes arguments, même ordre et mêmes messages d'arrêt que
remplir_pilote_v1.py pour les gardes que vise le banc du scellement (arguments, R12, HEAD, arbre propre, GO, révocation,
colonne N-019, ligne R-…, rapports épinglés au commit) ; en cas sain, recopie le candidat relu (normalisé égal) et
écrit une configuration factice. Charge le normaliseur par son chemin, comme le vrai."""
import argparse, datetime, hashlib, importlib.util, json, re, subprocess, sys
from pathlib import Path

TACHES = "donnees/t05-pilote-v1/taches-pilote-60-v1.json"
def arret(msg):
    sys.exit(f"ARRÊT du remplissage du pilote : {msg}")
p = argparse.ArgumentParser()
for x in ("depot", "commit", "mode", "date", "entropie", "sortie_p", "sortie_c"):
    p.add_argument(x)
p.add_argument("--taches", required=True); p.add_argument("--rapports-etat", required=True)
p.add_argument("--rapports-relecture", required=True); p.add_argument("--candidat-relu", default=None)
p.add_argument("--go", default=None); p.add_argument("--registre", default=None)
a = p.parse_args(); D = Path(a.depot)
if not re.fullmatch(r"[0-9a-f]{40}", a.commit) or a.mode != "reel":
    arret("commit (40 hexadécimaux) ou mode (reel, candidat, jouet) invalide")
if not re.fullmatch(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2} UTC", a.date):
    arret("date attendue au format « AAAA-MM-JJ HH:MM UTC »")
if a.taches != TACHES:
    arret(f"--taches {a.taches!r} : seul {TACHES} est admis en modes reel et candidat (CH-07)")
if not re.fullmatch(r"GO-\d{4}-\d{2}-\d{2}-\d{2}", a.go or "") or not re.fullmatch(r"R-\d{3,4}", a.registre or ""):
    arret("mode reel : --go GO-AAAA-MM-JJ-NN et --registre R-NNN exigés (décision de Lazar sur N-019)")
e = Path(a.entropie).read_text(encoding="utf-8").strip()
if not e.isdigit() or not 0 < int(e) < 2 ** 128:
    arret(f"entropie de {a.entropie} hors de ]0 ; 2^128[")
for f in (a.sortie_p, a.sortie_c):
    if Path(f).exists():
        arret(f"{f} existe déjà (R12)")
def git(*args):
    r = subprocess.run(["git", "-C", str(D), *args], capture_output=True)
    if r.returncode != 0:
        arret(f"git {' '.join(args)} : {r.stderr.decode(errors='replace').strip()}")
    return r.stdout
au_commit = lambda c: git("show", f"{a.commit}:{c}")
def scelle_au_commit(c):
    sha = hashlib.sha256(au_commit(c)).hexdigest(); sceau = au_commit(c + ".sha256").decode("utf-8").split()
    if not sceau or sceau[0] != sha or sceau[1:] != [Path(c).name]:
        arret(f"{c} : sceau absent ou différent au commit")
    return sha
def paires(texte):
    s = []
    for x in texte.split(","):
        nom, _, sha = x.strip().partition("=")
        if not nom or not re.fullmatch(r"[0-9a-f]{64}", sha):
            arret(f"paire de rapport mal formée : {x!r}")
        s.append((nom, sha))
    return s
if git("rev-parse", "HEAD").decode().strip() != a.commit:
    arret("le commit cité n'est pas HEAD")
if git("status", "--porcelain", "--untracked-files=no").strip():
    arret("arbre suivi non propre")
lignes_go = au_commit("registres/go.md").decode("utf-8").split("\n")
cel = [[c.strip() for c in x.strip().strip("|").split("|")] for x in lignes_go if x.startswith(f"| {a.go} |")]
if len(cel) != 1 or len(cel[0]) != 8:
    arret(f"{a.go} : absent de registres/go.md, en double ou mal formé")
lignes_dec = au_commit("registres/decisions.md").decode("utf-8").split("\n")
n19 = [x for x in lignes_dec if x.startswith("| N-019 |")]
etat19 = n19[0].rsplit("|", 2)[-2].strip() if len(n19) == 1 else ""
if not re.fullmatch(rf"tranché \(a\) par Lazar : {re.escape(a.go)} \({re.escape(a.registre)}\)", etat19):
    arret(f"N-019 : colonne d'état ≠ « tranché (a) par Lazar : {a.go} ({a.registre}) »")
reg = [x for x in lignes_dec if x.startswith(f"| {a.registre} |")]
if len(reg) != 1 or a.go not in reg[0]:
    arret(f"{a.registre} : ligne absente, en double ou sans {a.go}")
for n, s in paires(a.rapports_etat) + paires(a.rapports_relecture):
    if scelle_au_commit(f"prereg/contre-lectures/{n}") != s:
        arret(f"rapport {n} : empreinte citée ≠ sceau au commit")
spec = importlib.util.spec_from_file_location("normaliser_pilote_v1", Path(__file__).resolve().parent / "normaliser_pilote_v1.py")
norm = importlib.util.module_from_spec(spec); spec.loader.exec_module(norm)
t = au_commit(a.candidat_relu).decode("utf-8")
with open(a.sortie_p, "x", encoding="utf-8") as f:
    f.write(t)
with open(a.sortie_c, "x", encoding="utf-8") as f:
    f.write(json.dumps({"bouchon": True, "commit": a.commit}) + "\n")
print(json.dumps({"normalise_sha256": hashlib.sha256(norm.normaliser(t).encode("utf-8")).hexdigest()}))
