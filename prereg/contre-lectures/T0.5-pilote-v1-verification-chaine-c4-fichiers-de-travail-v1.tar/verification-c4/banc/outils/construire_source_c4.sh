#!/usr/bin/env bash
# Dépôt source synthétique (vérification c4) pour jouer le banc du scellement figé c4. Lecture seule du dépôt réel
# (git show au commit C) et de la chaîne c4 ; écrit seulement sous $1 (neuf).
set -euo pipefail
DEST=$1
[ -e "$DEST" ] && { echo "$DEST existe déjà"; exit 2; }
REEL=/home/user/controle-ia-travail
C=3881fb7183a6448ace018b26efd5bfed247287df
SP=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad
CH=$SP/chaine-c4
PY=$SP/scellement-revalidation/venv-gpu-neuf/bin/python
ICI=$(cd "$(dirname "$0")" && pwd)
V=docs/procedures/pilote-T0.5-v1
mkdir -p "$DEST" && cd "$DEST" && git init -q -b main . && git config user.email essai@invalid && git config user.name essai \
    && git config commit.gpgsign false
printf '__pycache__/\n*.pyc\n' > .gitignore; printf '* -text\n' > .gitattributes
echo "# dépôt synthétique (vérification c4)" > README.md
mkdir -p src/controle_ia/harnais src/controle_ia/environnements registres donnees/t05-pilote-v1 brouillons prereg/contre-lectures "$V"
for f in __init__.py gardes.py scellement.py prereg.py; do git -C "$REEL" show "$C:src/controle_ia/$f" > "src/controle_ia/$f"; done
: > src/controle_ia/harnais/__init__.py
git -C "$REEL" show "$C:src/controle_ia/harnais/validation_reelle.py" | sed -n '/^CHEMINS_GELES = (/,/)$/p' > src/controle_ia/harnais/validation_reelle.py
echo "VERSION = 0" > src/controle_ia/environnements/lancer_pilote_a.py
printf '| Id | Date | Décision | État |\n|---|---|---|---|\n| N-019 | 2026-10-12 | pilote réduit (essai) | en attente du GO de Lazar |\n' > registres/decisions.md
printf '| GO | accordé | type | périmètre | plafond | échéance | par | référence |\n|---|---|---|---|---|---|---|---|\n' > registres/go.md
echo '{"taches": []}' > donnees/t05-pilote-v1/taches-pilote-60-v1.json
git add -A && git commit -qm "A0 : code initial"
echo "VERSION = 1" > src/controle_ia/environnements/lancer_pilote_a.py
git commit -qam "A1 : code relu" && A1=$(git rev-parse HEAD)
RELU=brouillons/T0.5-pilote-8B-v1-candidat3.md
git -C "$REEL" show "$C:$RELU" > "$RELU"; git -C "$REEL" show "$C:$RELU.sha256" > "$RELU.sha256"
for n in T0.5-pilote-v1-etat-des-lieux-essai-v1.md T0.5-pilote-v1-relecture-b8-essai-v1.md T0.5-pilote-v1-relecture-b8-verification-essai-v1.md; do
    echo "rapport factice $n" > "prereg/contre-lectures/$n"; (cd prereg/contre-lectures && sha256sum "$n" > "$n.sha256")
done
git -C "$REEL" show "$C:$V/repetition-jouet-pilote-v1.log" | sed "s/^commit du code répété : .*/commit du code répété : $A1/" > "$V/repetition-jouet-pilote-v1.log"
(cd "$V" && sha256sum repetition-jouet-pilote-v1.log > repetition-jouet-pilote-v1.log.sha256)
for s in deriver_taches_pilote_v1.py normaliser_pilote_v1.py controles_avant_depense_pilote_v1.sh lancer_pilote_v1.sh \
         sceller_pilote_v1.sh recuperation_pilote_v1.sh repetition_jouet_pilote_v1.sh repetition_finale_pilote_v1.sh \
         essais_lanceur_pilote_v1.sh essais_controles_pilote_v1.sh essais_generateur_pilote_v1.sh essais_scellement_pilote_v1.sh; do
    cp "$CH/$s" "$V/$s"
done
cp "$ICI/bouchon_remplir.py" "$V/remplir_pilote_v1.py"
sha() { sha256sum "$1" | cut -d' ' -f1; }
R1=$(sha prereg/contre-lectures/T0.5-pilote-v1-etat-des-lieux-essai-v1.md); R2=$(sha prereg/contre-lectures/T0.5-pilote-v1-relecture-b8-essai-v1.md)
R3=$(sha prereg/contre-lectures/T0.5-pilote-v1-relecture-b8-verification-essai-v1.md)
[ "$(sha "$RELU")" = "$(sed -n 's/^CANDIDAT_RELU=\([0-9a-f]\{64\}\).*/\1/p' "$V/controles_avant_depense_pilote_v1.sh")" ] || { echo "candidat ≠ épingle brute"; exit 2; }
[ "$("$PY" -I "$CH/normaliser_pilote_v1.py" "$RELU")" = "$(sed -n 's/^CANDIDAT_NORMALISE=\([0-9a-f]\{64\}\).*/\1/p' "$V/controles_avant_depense_pilote_v1.sh")" ] || { echo "normalisé ≠ épingle"; exit 2; }
cp "$V/controles_avant_depense_pilote_v1.sh" "$DEST/../ctl-c4-reel.sh"
sed -i -e "s|^RAPPORTS_ATTENDUS=\"[^\"]*\"|RAPPORTS_ATTENDUS=\"T0.5-pilote-v1-etat-des-lieux-essai-v1.md=$R1 T0.5-pilote-v1-relecture-b8-essai-v1.md=$R2 T0.5-pilote-v1-relecture-b8-verification-essai-v1.md=$R3\"|" \
       -e "s|^CODE_RELU=[0-9a-f]\{40\}|CODE_RELU=$A1|" \
       -e "s|^REPETITION_JOUET=[0-9a-f]\{64\}|REPETITION_JOUET=$(sha "$V/repetition-jouet-pilote-v1.log")|" \
       "$V/controles_avant_depense_pilote_v1.sh"
n=$(diff "$DEST/../ctl-c4-reel.sh" "$V/controles_avant_depense_pilote_v1.sh" | grep -c '^>' || true); rm -f "$DEST/../ctl-c4-reel.sh"
[ "$n" = 3 ] || { echo "épingles synthétiques : $n lignes changées au lieu de 3"; exit 2; }
(cd "$V" && for s in *.sh *.py; do sha256sum "$s" > "$s.sha256"; done)
git add -A && git commit -qm "C : préalables synthétiques (épingles synthétiques posées)"
echo "A1 $A1"; echo "C $(git rev-parse HEAD)"
PYTHONPATH=src "$PY" -B -m controle_ia.scellement verifier-arbre . | tail -1
