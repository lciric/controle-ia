# dépôt synthétique (vérification c4)
