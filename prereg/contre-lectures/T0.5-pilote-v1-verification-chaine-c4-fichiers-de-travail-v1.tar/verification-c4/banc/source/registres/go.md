| GO | accordé | type | périmètre | plafond | échéance | par | référence |
|---|---|---|---|---|---|---|---|
