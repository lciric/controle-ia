| Id | Date | Décision | État |
|---|---|---|---|
| N-019 | 2026-10-12 | pilote réduit (essai) | en attente du GO de Lazar |
