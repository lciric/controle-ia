# Vérification c4 : différentiel de la chaîne du pilote 8B de T0.5 (relue par c3 → figée au commit C)

Relecteur neuf (R2). Je n'ai écrit ni la chaîne, ni le candidat, ni les corrections. Lecture seule du dépôt de travail
(HEAD = C = `3881fb7183a6448ace018b26efd5bfed247287df`, `git status` vide avant et après) et des deux dossiers de chaîne
(`sha256sum -c` conforme avant et après). Je n'ai lancé aucune commande vastai. J'ai respecté D-20 (diag/ ni ouvert ni fouillé).
Tous mes essais ont tourné sous `verification-c4/`, sur un dépôt synthétique de 1,2 Mo.

## Verdict

1. Aucun constat bloquant. Les cinq changements font ce qu'annoncent UH-01, UH-02, UH-03, UH-04, UH-07 et UH-14, sans régression du scellement. Aucun chemin nouveau ne sort en code 0, ne laisse de reste, ou retire un autre fichier que les quatre du scellement.
2. Les six épingles des contrôles sont justes au commit C. Le banc du scellement passe 22 cas sur 22 et détecte les régressions qu'on lui présente (version c3 : 5 cas non conformes ; sans `git reset` : 2 ; sans piège ERR : 1).
3. Un constat majeur, préventif (WC-01) : la liste des rapports est close à C, et le scellement ne vérifie pas « rapports présents = rapports épinglés » (UH-06, non traité). Un rapport c4 versé avant S sous le nom `…-relecture-b8-verification-c4-…` laisserait passer un scellement en code 0, puis rendrait S inutilisable. Il y a aussi trois mineurs sur la sensibilité des bancs.

Le différentiel fourni (`differentiel-chaine-c3-c4.diff`, `30a6fc4a…`) est identique au différentiel que j'ai recalculé
(`verification-c4/diff-recalcule.diff`, `71e172a2…`) : seuls les cinq fichiers annoncés changent. La chaîne c4 est
égale octet pour octet aux copies versées à C, à leurs sceaux et au bloc-notes `pilote-v1/` (13 sur 13).

## Constats

### WC-01 — majeur (devient bloquant si un rapport de la famille est versé entre C et S) — rapports épinglés clos à C, non relus par le scellement
- **Objet** : `controles_avant_depense_pilote_v1.sh:213-215` (présents = attendus, motif `T0\.5-pilote-v1-(etat-des-lieux|relecture-b8)-[a-z0-9-]+-v1\.(md|json|tar)`). Côté scellement, `sceller_pilote_v1.sh:31-36` ne vérifie que la famille des épingles, et le générateur ne lit que les rapports épinglés.
- **Constat** : un fichier du motif versé après C et avant S (par exemple le rapport de cette vérification, nommé comme ceux de c2 et c3) passe le scellement. S est alors commité et poussé en code 0, puis les contrôles le refusent (KO « rapports présents ≠ attendus »). Le nom v1 du préenregistrement est perdu (R12). C'est UH-06, que c4 ne traite pas. Le même raisonnement vaut pour une ligne mal formée ajoutée à `registres/go.md` après C : la garde de calcul la refuse (contrôles, l. 319) et le scellement ne la relit pas.
- **Preuve** :
  - Sur le dépôt synthétique, j'ai ajouté `T0.5-pilote-v1-relecture-b8-verification-c4-resultats-v1.json` et son sceau, non épinglés, puis lancé le scellement c4 : « scellement : code 0 ; S 158daa64… poussé » (`banc/E-wc01/scellement.log`, `f6290297…`). Le bloc des l. 213-215 rejoué sur S donne « KO rapports présents « … verification-c4-resultats-v1.json … » ≠ attendus ».
  - Contrôle du motif : `…-relecture-b8-verification-c4-resultats-v1.json`, `…-fichiers-de-travail-v1.tar` et `…-rapport-v1.md` sont COMPTÉS ; `T0.5-pilote-v1-verification-c4-resultats-v1.json` est hors motif.
- **Action** : ne verser le rapport c4 qu'après S, ou sous un nom hors du motif (sans `etat-des-lieux-` ni `relecture-b8-` après `T0.5-pilote-v1-`). Sinon : nouvelles épingles, nouveau commit des préalables, bancs et répétition finale rejoués. Juste avant le scellement, exiger que `git diff --name-only C HEAD` ne contienne que les journaux des bancs et leurs sceaux sous `docs/procedures/pilote-T0.5-v1/`, sans ligne nouvelle dans `registres/go.md`. Sinon, rejouer la répétition finale à cette tête.

### WC-02 — mineur — banc du lanceur : le motif de P13 et P13b ne désigne pas la garde visée
- **Objet** : `essais_lanceur_pilote_v1.sh:208, 210` ; `lancer_pilote_v1.sh:62, 66, 69`.
- **Constat** : le message générique de la l. 69 (« registre des décisions : N-019 non tranchée par Lazar (forme exacte), ou relance non consignée ») est écrit à chaque échec du bloc, garde de l'instance comprise. Le motif `relance non consignée` (grep -F, sous-chaîne) est donc présent quelle que soit la garde qui refuse. Si la garde des trois mots (l. 61) disparaissait, P13b resterait CONFORME. P12* est discriminant en mode premier : la seule autre garde de N-019 (l. 114-115) a un autre message. P13d et P17* sont discriminants aussi : P17h se distingue de la garde de calcul.
- **Preuve** :
  - Journal réel `banc-lanceur-pilote-C.log` (`b2191c5a…`) : P13d (garde de l'instance) affiche lui aussi « … ou relance non consignée ».
  - Mutation du bloc des l. 49-69, sans la condition des trois mots, sur le registre de P13b : « code 2 ; motif « relance non consignée » PRÉSENT » ; sortie « relance : la ligne de la cause ne nomme pas… » (`sondes/p13/sortie-mutant.txt`, `ccf014e0…`).
- **Action** : pour P13 et P13b, comparer la ligne entière (`grep -qxF "relance non consignée"`, au moyen d'une variable distincte de MOTIF_CAS). Pour ce cycle, lire à l'œil ces deux cas dans le journal : la ligne Python « relance non consignée » y figure seule, avant le message générique. C'est le cas dans le journal réel.

### WC-03 — mineur — banc du scellement : le motif de S21 n'est pas propre au commit refusé
- **Objet** : `essais_scellement_pilote_v1.sh:162`.
- **Constat** : « échec avant le commit : fichiers créés retirés » est écrit par `fin()` à tout échec qui suit la l. 82. S21 ne prouve donc que le commit a été tenté que parce que S00-sain passe dans le même banc.
- **Preuve** : ce motif figure dans les journaux de S02, S08, S09 et S12 (`banc/E1/scellement-*.log`). S21 sort bien sur « arrêt du scellement (ligne 97) » dans mon rejeu comme dans le journal réel `banc-scellement-pilote-C.log` (`1037b007…`).
- **Action** : viser « arrêt du scellement (ligne 97) », ou mieux, faire écrire au crochet `git diff --cached --name-only` dans un fichier témoin, et exiger dans S21 les quatre fichiers dans ce témoin et un index propre après coup.

### WC-04 — mineur (cas rare) — `fin()` affiche « fichiers créés retirés » sans le vérifier
- **Objet** : `sceller_pilote_v1.sh:75-77`.
- **Constat** : si un verrou `.git/index.lock` reste après la mort de git, `git reset` échoue en silence (`|| true`). Les quatre fichiers restent indexés et ne sont pas retirés, et le message les dit pourtant retirés. Le scellement suivant s'arrête sur « arbre suivi non propre » : l'issue reste sûre, mais la lecture est fausse.
- **Preuve** : sonde `verification-c4/sondes/gitreset`, cas (d) : « code git reset 128 ; toujours indexé : non retiré par la boucle ». Cas sains : chemins absents et non suivis, code 0. Fichiers indexés : retirés de l'index, un autre fichier indexé et un non suivi intouchés.
- **Action** (version future, ou à déclarer) : après la boucle, vérifier que les quatre chemins ne sont ni sur disque ni dans l'index ; sinon, écrire « fichiers créés NON retirés : … ».

### WC-05 — information — piège ERR : portée exacte de la garantie de VH-04
- **Objet** : `sceller_pilote_v1.sh:15, 26, 71-82`.
- **Constat** :
  - Les sondes confirment que le piège ne se déclenche ni dans une boucle ni dans une liste `&&` ou `||` non finales, ni dans un test `[ "$(…)" … ]`. Il se déclenche, en code 2, sur une commande simple, une affectation `X=$(fonction)` en échec (pipefail hérité), une commande sur plusieurs lignes et un tube. `$LINENO` donne la première ligne de la commande : 43, 85 (l. 85-87) et 97 (document en ligne).
  - Limites, sans effet sur le code actuel :
    - (i) sans `set -E`, un échec dans une fonction appelée au niveau principal sort avec son propre code, sans message ; aucun appel de ce genre n'existe (`epingle` seulement dans `$(…)`, `fin` seulement comme piège EXIT) ;
    - (ii) une erreur de `set -u` avant la l. 82 sortirait en code 1 ; aucune variable de ce genre n'est atteignable ;
    - (iii) un échec non gardé dans `fin()` (`rm -f`, `rm -rf`) sortirait en code 1 et laisserait le dossier de travail (entropie) ; c'est pathologique et antérieur à c4.
  - La ligne VH-04 du candidat (l. 471) reste vraie pour le code figé.
- **Preuve** : `sondes/t1.sh` (`8d741107…`) : « [fonction] code 1 », les autres cas en code 2 ou en continuation. `sondes/t2.sh` (`70d7846d…`) : « [err + échec dans fin] code 1 ; restes : 1 ». `sondes/t3.sh` (`e626aa9a…`) : « [nonlie] code 1 ».
- **Action** : aucune pour ce cycle. Plus tard : `set -E`, ou une règle écrite « aucune fonction appelée au niveau principal ».

### WC-06 — information — après le commit, un arrêt à la l. 112 ne dit pas que S est poussé
- **Objet** : `sceller_pilote_v1.sh:111-113`.
- **Constat** : si `git fetch` échoue après une poussée réussie, la sortie se limite à « arrêt du scellement (ligne 112) », en code 2. Le numéro de ligne, nouveau, aide. Un nouveau lancement s'arrêterait sur « existe déjà (R12) ». Défaut antérieur, sans régression.
- **Action** : sur tout code 2, lire `git log -1` et `git ls-remote origin main` avant de conclure.

### WC-07 — information — six épingles justes au commit C
- **Preuve** :
  - `git show C:brouillons/T0.5-pilote-8B-v1-candidat3.md | sha256sum` donne `74a88671…f6152d1`, égal au sceau.
  - Normaliseur de C (`9e15211f…`) sur le candidat : `83056d15157ef9043daab5275e7d4665aa7e087bbb3b5a1556e7d9830cf9ed63`, avec Python 3.11 système et avec l'environnement neuf.
  - Les huit rapports : blob = épingle = sceau ; ce sont exactement les huit présents du motif à C.
  - `7b07300…` est un ancêtre de C et l'arbre gelé (CHEMINS_GELES de C) est identique (`git diff --quiet` en code 0).
  - Journal à C : `531f2d79…` = sceau. Le bloc PYREP des contrôles, rejoué sur ce journal avec CODE_RELU = `7b07300…`, donne le code 0, et les cinq « script répété » égalent les copies versées à C.
  - Seules les l. 22-27 changent. La fonction `epingle()` du scellement lit les six valeurs sans espace résiduel, et plus aucun « A_EPINGLER » ne reste dans les contrôles.

### WC-08 — information — UH-03 corrigé (banc des contrôles)
- **Preuve** : les épingles des copies `controles-A32/33/34.sh` du banc réel en cours (`banc-controles-pilote-C/`) égalent `git show C:<journal>` modifié comme chaque cas (`d4646cc6…`, `5e75622c…`, `c42bd3da…`). Chaque modification mord (une ligne `remplir_pilote_v1.py`). Avec `* -text` dans `.gitattributes`, aucune conversion n'a lieu. A32 à A34 sont CONFORMES dans le journal réel, chacun sur son KO visé.

### WC-09 — information — banc du scellement c4 éprouvé
- **Preuve** :
  - Banc c4 (copie `7ab36701…`) joué sur un dépôt synthétique construit depuis C (`outils/construire_source_c4.sh`, `ff11ac38…`). Le générateur y est remplacé par un bouchon aux mêmes messages (`outils/bouchon_remplir.py`, `c0569d5f…`). Résultat : 22 sur 22, code 0 (`banc/banc-c4-synthetique.log`, `cc85748a…`). Chaque cas sort sur le message de sa garde. S08 nomme le rapport retiré, ce qui en fait un motif discriminant. S15 et S18 ont maintenant deux messages distincts. S20 sort sur « (ligne 43) » avant le piège de sortie.
  - Mutants :
    - version c3 du scellement : S15, S18, S20, S21 et l'index non conformes, code 1 (`banc-M1-c3.log`, `6714220c…`) ;
    - sans `git reset` : S21 et l'index (`a9b006a2…`) ;
    - sans piège ERR : S20 en code 128 (`087b5b87…`).
  - La remise par poussée forcée sur chemin explicite marche, y compris après S03 et S20. Le décompte final et le code 1 fonctionnent. La garde « une ligne exactement » de `epingle_versee` arrête le banc (« montage impossible », code 2) si la sed ne mord pas.
  - Le journal réel au commit C (`banc-scellement-pilote-C.log`, `1037b007…`, vrai générateur) donne aussi 22 sur 22.

### WC-10 — information — divers
- Le mécanisme `MOTIF_CAS="…" cas …` est local à l'appel (bash hors mode POSIX). Aucune fuite : P12g et P17i sont CONFORMES dans le journal réel. Tous les motifs existent dans le lanceur.
- Les autres cas du lanceur (P06 à P11, P14, P15) restent jugés au seul code, et ce banc n'a ni décompte ni code de sortie. C'est hors du différentiel ; UH-04 ne visait que P12* et P17*.
- `chaine-c4/` contient un `__pycache__/normaliser_pilote_v1.cpython-311.pyc` (05:58:48), écrit par le banc du générateur qui tourne depuis cette copie. Les empreintes des treize scripts sont intactes. Il faudra l'exclure si cette copie est archivée.
- Le candidat 3 ne cite aucune empreinte des cinq scripts changés. Les empreintes c3 n'apparaissent à C que dans l'archive des fichiers de travail de c3, qui est historique.

## Pièces (sous `scratchpad/verification-c4/`)
| pièce | sha256 |
|---|---|
| diff-recalcule.diff | 71e172a2ba901c08fed9443745c5bcd4190bdcf5d3c0723296b703031a2a4928 |
| pyrep/sortie.txt | 5133a92cad3192af453fac6c1be8139bb878c11495f7d9a8530192e242478b91 |
| banc/banc-c4-synthetique.log | cc85748a1545ed88991cc5bbd310686a8e7f948e78b2506283f88466ef974749 |
| banc/banc-M1-c3.log | 6714220cc8b9f947e1e1b9b9fe526c077c5bc3c11662944d2f887e0aef2e1b87 |
| banc/banc-M2-sans-reset.log | a9b006a27cff1d87ab1c7bdda63d092a7ecb0e49e91b80983be144f843699623 |
| banc/banc-M3-sans-piege-err.log | 087b5b87ebb0b6e7b76bbac54c47bc4ed8abc0bf1eeba05b86bf1d8fda509edf |
| banc/E-wc01/scellement.log | f6290297b9d2be4d2413da254e8459cd63238a830581a4e736edf71d12420168 |
| banc/outils/construire_source_c4.sh | ff11ac385204a6a7b6eb4bd78a44dda50471a5e1b04793d85f6887f2a2d36ef2 |
| banc/outils/bouchon_remplir.py | c0569d5fc3feacb2a98543b3085d827bd020331bcb8066cc6d25aa962910561f |
| sondes/t1.sh, t2.sh, t3.sh | 8d741107…, 70d7846d…, e626aa9a… |
| sondes/p13/sortie-original.txt, sortie-mutant.txt | 364f6d7f…, ccf014e0… |

Réserves :
- Mon rejeu du banc du scellement remplace le générateur par un bouchon, comme c3. Le journal réel au commit C, avec le vrai générateur, le corrobore.
- Je n'ai pas joué le banc des contrôles ni la répétition finale, qui tournaient au commit C : je n'ai lu que leurs journaux, en cours.
