import re, sys
code = sys.argv[1]
lignes = open(sys.argv[2], encoding="utf-8").read().split("\n")
exigees = [f"commit du code répété : {code}", "FIN DE LA RÉPÉTITION",
           "récupération (passage-1-premier) : code 0 ; RÉCUPÉRATION : TOUS CONFORMES",
           "récupération (passage-4-relance) : code 0 ; RÉCUPÉRATION : TOUS CONFORMES",
           "récupération (artefact-premier-avec-episodes) : code 1 ; RÉCUPÉRATION : 1 CONTRÔLE(S) EN ÉCHEC",
           "récupération (artefact-notations-manquantes) : code 1 ; RÉCUPÉRATION : 1 CONTRÔLE(S) EN ÉCHEC"]
for e in exigees:
    assert e in lignes, f"ligne absente : {e}"
for p in ("passage 1-sain : code 0 ", "passage 2-artefact-branche-presente : code 2 ", "passage 3-premier-manque : code 1 ",
          "passage 4-relance : code 0 "):
    assert sum(l.startswith(p) for l in lignes) == 1, f"passage : {p}"
assert sum("RÉCUPÉRATION : TOUS CONFORMES" in l for l in lignes) == 2, "deux récupérations conformes attendues"
def ko_apres(etiquette, prefixe):
    i = lignes.index(etiquette)
    ko = [l for l in lignes[i + 1:i + 6] if l.startswith("    KO")]
    assert len(ko) == 1 and ko[0].startswith(prefixe), f"{etiquette} : KO {ko}"
ko_apres("récupération (artefact-premier-avec-episodes) : code 1 ; RÉCUPÉRATION : 1 CONTRÔLE(S) EN ÉCHEC",
         "    KO  0 calcul/t05-pilote-jouet-a-v1 porte un episodes.json")
ko_apres("récupération (artefact-notations-manquantes) : code 1 ; RÉCUPÉRATION : 1 CONTRÔLE(S) EN ÉCHEC",
         "    KO  4c fichiers d'un run complet")
# lignes « script répété » : une par script, empreinte de 64 caractères hexadécimaux, les cinq attendus exactement
# (vérification courte, VH-02, restes)
scripts = {}
for l in lignes:
    if l.startswith("script répété : "):
        m = re.fullmatch(r"script répété : ([a-z_]+_pilote_v1\.(?:py|sh)) ([0-9a-f]{64})", l)
        assert m, f"ligne « script répété » mal formée : {l[:90]}"
        assert m.group(1) not in scripts, f"script répété en double : {m.group(1)}"
        scripts[m.group(1)] = m.group(2)
cinq = {"deriver_taches_pilote_v1.py", "remplir_pilote_v1.py", "normaliser_pilote_v1.py", "recuperation_pilote_v1.sh",
        "repetition_jouet_pilote_v1.sh"}
assert set(scripts) == cinq, f"scripts répétés {sorted(scripts)} : les cinq attendus exactement"
for s in sorted(cinq):
    print(s, scripts[s])
