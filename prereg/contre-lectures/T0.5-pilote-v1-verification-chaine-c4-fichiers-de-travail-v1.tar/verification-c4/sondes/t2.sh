#!/usr/bin/env bash
set -euo pipefail
trap 'echo "arrêt du scellement (ligne $LINENO)"; exit 2' ERR
COMMITTE=0; TRAVAIL=""
fin() {
    local code=$?
    if [ "$code" != 0 ] && [ "$COMMITTE" = 0 ]; then
        [ "${ECHEC_DANS_FIN:-}" = 1 ] && rm -f /proc/version
        echo "échec avant le commit : fichiers créés retirés"
    fi
    [ -n "$TRAVAIL" ] && rm -rf "$TRAVAIL"
    [ "$code" = 0 ] || exit 2
}
trap fin EXIT
TRAVAIL=$(mktemp -d "$PWD/travail-XXXX")
case "${CAS:-}" in
  err) false ;;
  garde) [ 1 = 2 ] || { echo "message de garde"; exit 2; } ;;
  sain) : ;;
  committe) COMMITTE=1; false ;;
esac
echo "fin normale"
