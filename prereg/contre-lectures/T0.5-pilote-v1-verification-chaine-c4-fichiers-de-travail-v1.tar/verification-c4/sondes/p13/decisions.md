# Registre des décisions (essai)

| id | date | décision | fondement |
|---|---|---|---|
| R-143 | 2026-10-12 | N-019 tranché sous la délégation R-140 : option (a) ; révocable par Lazar. | essai |
| R-146 | 2026-10-12 | GO-2026-10-12-99 de Lazar sur N-019, option (a) (essai). | essai |

| id | ouvert le | objet | ce qu'il faut |
|---|---|---|---|
| N-019 | 2026-10-12 | nœud de la revalidation (essai) | tranché (a) par Lazar : GO-2026-10-12-99 (R-146) |
| R-151 | 2026-10-12 | Pilote : panne réseau de l'hôte (essai). | essai |
