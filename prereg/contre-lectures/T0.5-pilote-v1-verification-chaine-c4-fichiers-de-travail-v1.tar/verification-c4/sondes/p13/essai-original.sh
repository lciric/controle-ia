set -euo pipefail; DEPOT=.; MODE_LANCEMENT=relance; CAUSE=R-151; mkdir -p registres; cp decisions.md registres/
PREMIERE=$(python3 - registres/decisions.md "$MODE_LANCEMENT" "$CAUSE" <<'EOF'

import re, sys
lignes = open(sys.argv[1], encoding="utf-8").read().split("\n")
n19 = [x for x in lignes if x.startswith("| N-019 |")]
# forme exacte de la colonne d'état (relecture R2, CH-10) : aucun mot-clé cherché ; une révocation de la décision de
# Lazar est une ligne de type « révocation » de registres/go.md, relue plus bas (bloc GO19)
etat = n19[0].rsplit("|", 2)[-2].strip() if len(n19) == 1 else ""
if not re.fullmatch(r"tranché \(a\) par Lazar : GO-\d{4}-\d{2}-\d{2}-\d{2} \(R-\d{3,4}\)", etat):
    sys.exit("N-019")
if sys.argv[2] == "relance":
    r = [x for x in lignes if x.startswith(f"| {sys.argv[3]} |")]
    if len(r) != 1 or not all(m in r[0].lower() for m in ("relancement", "pilote", "infrastructure")):
        sys.exit("relance non consignée")
    # l'instance du premier lancement, arrêtée et gardée, est nommée par la ligne de la cause (CH-02)
    inst = re.findall(r"\binstance (\d{8})\b", r[0])
    if len(set(inst)) != 1:
        sys.exit("relance : la ligne de la cause ne nomme pas, une seule fois, l'instance du premier lancement")
    print(inst[0])
EOF
) || { echo "registre des décisions : N-019 non tranchée par Lazar (forme exacte), ou relance non consignée"; exit 2; }
echo "PREMIERE=$PREMIERE"
