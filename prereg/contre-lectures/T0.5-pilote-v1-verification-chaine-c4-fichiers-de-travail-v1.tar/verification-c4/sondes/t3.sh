#!/usr/bin/env bash
set -euo pipefail
trap 'echo "arrêt du scellement (ligne $LINENO)"; exit 2' ERR
case "${CAS:-}" in
  nonlie) echo "$VARIABLE_JAMAIS_POSEE" ;;
  avant_piege_sortie_puis_fin) fin() { local code=$?; echo "fin : code $code"; [ "$code" = 0 ] || exit 2; }; trap fin EXIT; echo "$VARIABLE_JAMAIS_POSEE" ;;
  heredoc_subst) cat > /dev/null <<FIN
$(false)
FIN
echo "après heredoc avec substitution en échec" ;;
esac
echo "fin normale"
