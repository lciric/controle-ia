#!/usr/bin/env bash
set -euo pipefail
trap 'echo "arrêt du scellement (ligne $LINENO)"; exit 2' ERR
CTL=${CTL:-/nonexistent}
epingle() { sed -n "s/^$1=\(.*\)/\1/p" "$CTL" | sed 's/[[:space:]]*$//'; }
case "${CAS:-}" in
  simple) false ;;
  subst) X=$(epingle FOO); echo "après subst X=[$X]" ;;
  boucle) for f in /nonexistent-a /nonexistent-b; do [ -e "$f" ] && { echo "$f existe"; exit 2; }; done; echo "après boucle && : continue" ;;
  liste) grep -q "zzz" /etc/hostname && { echo "trouvé"; exit 2; }; echo "après liste : continue" ;;
  fonction) f() { false; echo "après false dans f"; }; f; echo "après f" ;;
  test) [ "$(git -C /nonexistent rev-parse HEAD 2>/dev/null)" = "x" ] || { echo "message de garde"; exit 2; } ;;
  multi) ls /nonexistent \
      -l \
      -a ;;
  heredoc) cat /nonexistent - <<FIN
ligne 1
ligne 2
FIN
;;
  tube) false | cat ;;
esac
echo "fin normale"
