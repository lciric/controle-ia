"""Essai B3-2 : le verrou ne recoupe pas `conclusions_etablies` en fin de course. La liste `etablies` est partagée (même
objet) entre `D["etablies"]`, la sortie et l'appel à `exiger_verrou` ; une analyse fautive qui l'allonge promeut une
conclusion sans qu'aucune garde ne l'arrête (à comparer avec l'essai du module `a9_qui_touche_l_issue`, que
l'instantané de la lecture arrête)."""
import copy
import sys
from pathlib import Path

import pytest

BASE = Path(__file__).resolve().parent.parent / "base"
sys.path.insert(0, str(BASE))

import test_complements_p3_v1 as T  # noqa: E402
from test_complements_p3_v1 import P, _c, _cas, cp  # noqa: E402


@pytest.fixture(autouse=True)
def tirages_reduits(monkeypatch):
    monkeypatch.setattr(cp, "TIRAGES_AIRE", T.TIRAGES_TESTS)
    monkeypatch.setattr(cp, "TIRAGES_COUT", 2000)


def test_analyse_qui_allonge_les_conclusions_etablies_n_est_pas_arretee(monkeypatch):
    src, lec, s0 = _cas("aucun")                       # lecture : seule P3-P1 établie
    assert s0["conclusions_etablies"] == ["P3-P1"]
    vraie = cp.FONCTIONS["A9"]

    def a9_qui_promeut(e, D, graines_, p):
        D["etablies"].append(_c("P3-P3"))              # défaut simulé : promotion d'une conclusion non établie
        vraie(e, D, graines_, p)

    monkeypatch.setitem(cp.FONCTIONS, "A9", a9_qui_promeut)
    s = cp.analyser_addendum(src, copy.deepcopy(lec), T.G)   # aucune garde ne s'y oppose
    assert s["conclusions_etablies"] == ["P3-P1", _c("P3-P3")]
    assert s["issue_primaire"]["ligne"] == "aucune sonde générique au-dessus du plancher sur (i-a)"
    assert s["audit_symetrie_addendum"]["conclusions_etablies"] == 2
