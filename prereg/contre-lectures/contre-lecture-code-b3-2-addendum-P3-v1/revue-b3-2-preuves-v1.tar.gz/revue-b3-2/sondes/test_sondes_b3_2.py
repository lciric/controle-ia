"""Essais de la contre-lecture B3-2 (verrou et preuves), sur le module final non modifié (copie octet pour octet dans
`../base/`). Chaque essai reproduit un constat ou vérifie une propriété du verrou ; les aides de données sont celles des
tests du module (importées, jamais copiées)."""
import copy
import json
import sys
from pathlib import Path

import numpy as np
import pytest

BASE = Path(__file__).resolve().parent.parent / "base"
sys.path.insert(0, str(BASE))

import test_complements_p3_v1 as T  # noqa: E402
from test_complements_p3_v1 import P, _c, _cas, _controles, _desc, _issue, _reserves, cp, lp  # noqa: E402

from controle_ia.gardes import GardeArret  # noqa: E402


@pytest.fixture(autouse=True)
def tirages_reduits(monkeypatch):
    monkeypatch.setattr(cp, "TIRAGES_AIRE", T.TIRAGES_TESTS)
    monkeypatch.setattr(cp, "TIRAGES_COUT", 2000)


def test_empreintes_du_module_et_des_tests_essayes():
    import hashlib
    assert hashlib.sha256((BASE / "complements_p3_v1.py").read_bytes()).hexdigest() == (
        "daf954594456f8c268ebbf48b14326a183941c00c4cddb205b2e3382a875f4fa")
    assert hashlib.sha256((BASE / "test_complements_p3_v1.py").read_bytes()).hexdigest() == (
        "01b5faeaf1fe5ea38624b872948d46d5310bc67b6df3277ea1515e73fc057abc")


# ------------------------------------------------------------------------------------------------ verrou (preuves)

def test_verrou_aucune_sortie_hors_descriptif_sur_cible_non_etablie_tous_scenarios():
    """Propriété : sur chaque scénario des tests, chaque contrôle lu (non « sans objet ») vise une cible établie ; chaque
    réserve vise une cible établie ; l'issue primaire est la copie exacte ; la recommandation ne nomme que des cibles
    établies ; aucune chaîne « établie » n'apparaît hors de `conclusions_etablies` et de la recommandation."""
    for nom in sorted(T.SCENARIOS):
        _, lec, s = _cas(nom)
        etablies = set(s["conclusions_etablies"])
        assert s["issue_primaire"] == lec["issue"]
        for _, _, x in cp._entrees(s["analyses"]):
            for c in x["controles"]:
                if c["controle_contraire"] == "sans objet":
                    assert set(c) == {"test", "cible", "controle_contraire"}
                else:
                    assert c["cible"] in etablies
        assert all(r["cible"] in etablies for r in s["reserves_addendum"])
        assert all(x.split(" : ")[0] in etablies for x in s["recommandation_au_verdict_R13"]
                   if not x.startswith("aucune conclusion"))
        assert set(s["conclusions_etablies"]) == set(cp.conclusions_etablies(cp.lire_la_lecture(lec, P), P))


def test_verrou_conclusions_relatives_aux_drapeaux_bruts_de_la_lecture():
    """Le verrou est relatif aux drapeaux bruts de la lecture : `P3-P4[p]["conforme"]` forcé vrai alors que l'état de
    saboteur contre témoin est « non au-dessus » ; la garde 6 recalcule l'issue avec ce même drapeau et passe ; l'addendum
    tient `P3-P4/<p>` pour établie. Aucune garde ne recoupe `conforme` (ni `T<k>.etabli`) avec les états."""
    src, lec, _ = _cas("sain")
    lec["jeux"][P[0]]["saboteur-temoin"]["au_dessus_du_plancher"] = False
    lec["etats_des_jeux"] = lp.etats_des_jeux(lec["jeux"], lec["audit_R4"]["non_interpretables"])
    assert lec["etats_des_jeux"][P[0]]["saboteur-temoin"] == lp.NON_AU_DESSUS
    assert lec["P3-P4"][P[0]]["conforme"] is True                        # drapeau brut laissé vrai
    lec["issue"] = lp.issue(lec)
    s = cp.analyser_addendum(src, lec, T.G)
    assert _c("P3-P4") in s["conclusions_etablies"]
    assert lec["etats_des_jeux"][P[0]]["saboteur-temoin"] != lp.AU_DESSUS


# ------------------------------------------------------------------------------------------------ constats

def test_recommandation_dit_non_robuste_pour_une_reserve_non_lue():
    """Critères gelés : `reserve_<analyse>_non_lue` → « la conclusion reste établie ; le verdict cite qu'elle n'a pas été
    contrôlée ». La recommandation du module écrit pourtant « non robuste aux contrôles de l'addendum » pour une conclusion
    qui n'a que des réserves « non lues »."""
    _, _, s = _cas("a7_longueurs_constantes")
    r = _reserves(s, "", _c("P3-P3"))
    assert r and {x["nom"] for x in r} == {"reserve_A7_non_lue"}
    rec = [x for x in s["recommandation_au_verdict_R13"] if x.startswith(_c("P3-P3") + " :")]
    assert rec == [f"{_c('P3-P3')} : établie au sens de la lecture décisive, non robuste aux contrôles de l'addendum "
                   f"(réserves : reserve_A7_non_lue)"]


def test_recommandation_forme_du_cout_sans_sa_lecture_gelee():
    """Critères gelés : `reserve_A7_forme_du_cout` → « séparation non établie hors de cette forme du coût » ; la
    recommandation n'écrit que « non robuste aux contrôles de l'addendum » et le nom de la réserve."""
    _, _, s = _cas("a7_forme")
    rec = [x for x in s["recommandation_au_verdict_R13"] if x.startswith(_c("P3-P3") + " :")]
    assert rec and "reserve_A7_forme_du_cout" in rec[0] and "hors de cette forme" not in json.dumps(
        s["recommandation_au_verdict_R13"], ensure_ascii=False)


def test_entree_en_echec_efface_une_reserve_contraire_deja_calculee(monkeypatch):
    """Une `GardeArret` levée dans une entrée hors d'un `calcul`, après les contrôles (ici simulée dans la permutation du
    placebo de A1, appelée hors de `calcul`), remplace la réserve contraire déjà calculée (`reserve_A1_plancher_conjoint`,
    lecture « non robuste ») par `reserve_A1_non_lue` (lecture « non contrôlée ») ; le motif chiffré est perdu."""
    src, lec, s0 = _cas("a1_plancher")
    assert _reserves(s0, "reserve_A1_plancher_conjoint", _c("P3-P3"))
    vraie = lp._permuter_dans_les_taches

    def permutation_en_echec(condition, tache, rng):
        raise GardeArret("échec simulé après les contrôles")

    monkeypatch.setattr(cp.lp, "_permuter_dans_les_taches", permutation_en_echec)
    s = cp.analyser_addendum(src, copy.deepcopy(lec), T.G)
    monkeypatch.setattr(cp.lp, "_permuter_dans_les_taches", vraie)
    assert not _reserves(s, "reserve_A1_plancher_conjoint")
    assert {x["nom"] for x in _reserves(s, "", _c("P3-P3")) if x["analyse"] == "A1"} == {"reserve_A1_non_lue"}
    assert "saboteur-honnete" not in s["analyses"]["A1"][P[0]]["descriptif"]


def test_A8_saturation_sans_controle_quand_le_calcul_echoue_reste_couverte_par_debut():
    """Témoin du mutant L9 : A8 en échec pour la sonde à attention ; les deux contrôles sont « non lus » (début et
    saturation) ; le test du module ne vérifie que l'existence d'une réserve « non lue », que le seul contrôle du début
    suffit à donner."""
    src, lec, _ = _cas("sain")
    src["jetons"]["logits_1"][2:4] = np.nan
    s = cp.analyser_addendum(src, lec, T.G)
    tests = {x["test"] for x in _reserves(s, "reserve_A8_non_lue", _c("P3-P3", P[1]))}
    assert tests == {"A8 début de l'action", "A8 saturation de l'attention"}
