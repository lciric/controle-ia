"""s04 (M-4) : P0 au commit 92e2f99.
Usage : PYTHONPATH=<espace>/copie/src python s04_p0.py <espace>
(a) sorties réelles de pytest (version de l'environnement), sortie standard et sortie d'erreur séparées comme dans
    le script d'instance, lues par `tests_conformes` : tous réussis, sauté, désélectionné, inattendu réussi, attendu
    en échec, avertissement, erreur, échec, sous-tests, aucune collecte, ligne parasite (stdout, stderr) ;
(b) câblage du refus avant le manifeste dans `executer` en mode décisif (configuration réelle, mémoire vive
    exigée mise à 0 pour ce processeur) : sortie non conforme → arrêt « P0 », aucun dossier de run ; sortie conforme →
    le run passe P0, crée son manifeste et s'arrête plus loin (pas de carte)."""
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest as _pytest

from controle_ia.gardes import GardeArret
from controle_ia.harnais import validation_reelle as V
from controle_ia.prereg import problemes
from controle_ia.scellement import sceller

esp = Path(sys.argv[1])
print("pytest", _pytest.__version__)

CAS = {
    "tous_reussis": ("def test_a(): pass\ndef test_b(): pass\ndef test_c(): pass\n", [], 3),
    "saute": ("import pytest\ndef test_a(): pass\ndef test_b(): pass\n@pytest.mark.skip\ndef test_c(): pass\n", [], 2),
    "deselectionne": ("def test_a(): pass\ndef test_b(): pass\ndef test_c(): pass\n", ["-k", "not test_c"], 2),
    "inattendu_reussi": ("import pytest\ndef test_a(): pass\ndef test_b(): pass\n@pytest.mark.xfail\ndef test_c(): pass\n", [], 2),
    "attendu_en_echec": ("import pytest\ndef test_a(): pass\ndef test_b(): pass\n@pytest.mark.xfail\ndef test_c(): assert 0\n", [], 2),
    "avertissement": ("import warnings\ndef test_a(): warnings.warn('w')\ndef test_b(): pass\ndef test_c(): pass\n", [], 3),
    "echec": ("def test_a(): pass\ndef test_b(): pass\ndef test_c(): assert 0\n", [], 2),
    "erreur_fixture": ("import pytest\n@pytest.fixture\ndef f(): raise RuntimeError\ndef test_a(): pass\ndef test_b(): pass\ndef test_c(f): pass\n", [], 2),
    "sous_tests": ("def test_a(): pass\ndef test_b(): pass\ndef test_c(subtests):\n    with subtests.test(i=1): pass\n", [], 3),
    "aucune_collecte": ("x = 1\n", [], 0),
    "parasite_stdout": ("import atexit\natexit.register(lambda: print('fin de processus'))\ndef test_a(): pass\ndef test_b(): pass\ndef test_c(): pass\n", [], 3),
    "parasite_stderr": ("import atexit, sys\natexit.register(lambda: print('avertissement de fin', file=sys.stderr))\ndef test_a(): pass\ndef test_b(): pass\ndef test_c(): pass\n", [], 3),
}
print("(a) sorties réelles, lues par tests_conformes(sortie standard, attendus)")
for nom, (code, args, attendus) in CAS.items():
    d = Path(tempfile.mkdtemp())
    (d / "test_x.py").write_text(code)
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", *args], cwd=d,
                       capture_output=True, text=True)
    derniere = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else ""
    print(f"    {nom:18s} code {r.returncode} ; dernière ligne {derniere!r:62s} ; stderr {len(r.stderr):3d} o ; "
          f"conforme({attendus}) = {V.tests_conformes(r.stdout, attendus)}")

print("(a') formes de la dernière ligne")
for ligne in ("176 passed in 71.19s (0:01:11)", "176 passed in 5000.00s (1:23:20)", "176 passed in 40000.0s (11:06:40)",
              "176 passed, 1 warning in 5.00s", "176 passed, 12 warnings in 5.00s", "176 passed in 5.00s ",
              "176 passed in 5.00s\r", "======= 176 passed in 5.00s =======", "\x1b[32m176 passed\x1b[0m in 5.00s",
              "0176 passed in 5.00s", "176 passed, 1 warning, 1 subtests passed in 5.00s"):
    print(f"    {ligne!r:55s} -> {V.tests_conformes(ligne, 176)}")

print("(b) refus avant le manifeste en mode décisif")
d = Path(tempfile.mkdtemp())
for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"],
          ["config", "commit.gpgsign", "false"]):
    subprocess.run(["git", "-C", str(d), *a], check=True)
(d / ".gitignore").write_text("donnees/\n")
subprocess.run(["git", "-C", str(d), "add", "-A"], check=True)
subprocess.run(["git", "-C", str(d), "commit", "-qm", "i"], check=True)
commit = subprocess.run(["git", "-C", str(d), "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip()
(d / "prereg").mkdir()
p = d / "prereg" / "p.md"
corps = "\n\n".join(f"## {s}\n\ntexte" for s in ("Hypothèse", "Prédiction chiffrée et signe attendu", "Métrique", "Seuil",
                                                    "Plan d'analyse", "Critères de lecture gelés", "Liste d'arrêt"))
p.write_text(f"# p\n\n- Commit du code d'analyse : `{commit}`\n- Révision du modèle : "
             f"`0e9e39f249a16976918f6564b8830bc894c89659`\n- Entropie : `12345`\n\n{corps}\n\n## Contre-lecture\n\n"
             f"- **Contre-lecture 1** : brouillon `{'a' * 64}`, rapport `{'b' * 64}`.\n", encoding="utf-8")
assert problemes(p) == [], problemes(p)
sceller(p)
subprocess.run(["git", "-C", str(d), "add", "-A"], check=True)
subprocess.run(["git", "-C", str(d), "commit", "-qm", "prereg"], check=True)
dehors = Path(tempfile.mkdtemp())
cfg = dict(V.CONFIG_REELLE, memoire_vive_min_go=0)
for nom, sortie in (("saute", "....\n175 passed, 1 skipped in 71.19s (0:01:11)\n"),
                    ("ligne parasite", "....\n176 passed in 71.19s (0:01:11)\nfin\n"),
                    ("vide", ""),
                    ("conforme", "....\n176 passed in 71.19s (0:01:11)\n")):
    f = dehors / f"{nom}.txt"
    f.write_text(sortie)
    run = "20261004-310000-validation-reelle" if nom != "conforme" else "20261004-310100-validation-reelle"
    try:
        V.executer(d, run, revision="0e9e39f249a16976918f6564b8830bc894c89659", config=cfg, prereg=p,
                   sortie_tests=f, verifier_import=False)
        print(f"    {nom:15s} -> AUCUN ARRÊT")
    except GardeArret as e:
        print(f"    {nom:15s} -> ARRÊT : {str(e)[:100]}")
    print(f"    {'':15s}    dossier runs/ créé : {(d / 'runs').exists() and any((d / 'runs').iterdir())} ; "
          f"arret.json : {(d / 'diag' / run / 'arret.json').exists()}")
    if (d / "diag" / run / "arret.json").exists():
        a = json.loads((d / "diag" / run / "arret.json").read_text())["resultat"]
        print(f"    {'':15s}    phase {a['phase']} ; tests_instance {a['partiel'].get('tests_instance')} ; "
              f"lecture tests {a['partiel']['lecture_partielle']['tests_instance']}")
