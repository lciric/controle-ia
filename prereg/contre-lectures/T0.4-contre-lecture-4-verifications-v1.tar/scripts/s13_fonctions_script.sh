#!/usr/bin/env bash
# s13 (M-7) : fonctions `complet`, `lancer` et `sur_term` du script d'instance au commit 92e2f99, extraites telles quelles,
# exercées sous `set -euo pipefail` avec un run factice (exécutable « python » placé en tête du PATH).
# Usage : bash s13_fonctions_script.sh <espace>   (copie/ au commit 92e2f99)
set -u
ESP=$1
S=$ESP/copie/scripts/validation_t04_instance.sh
T=$(mktemp -d)
mkdir -p "$T/bin" "$T/depot/diag"
{ sed -n '/^complet()/p' "$S"; sed -n '/^lancer() {/,/^}/p' "$S"; sed -n '/^sur_term() {/,/^}/p' "$S"; } > "$T/fonctions.sh"
echo "fonctions extraites : $(grep -c '()' "$T/fonctions.sh") ($(grep -o '^[a-z_]*()' "$T/fonctions.sh" | tr '\n' ' '))"
# run factice : FAUX_MODE = resume_124 | arret_1 | long ; sur TERM, écrit arret.json et sort avec 1 (comme le lanceur)
cat > "$T/bin/python" <<'EOF'
#!/usr/bin/env bash
run=""; while [ $# -gt 0 ]; do [ "$1" = --run-id ] && run=$2; shift; done
mkdir -p "diag/$run"
trap 'echo "{}" > "diag/$run/arret.json"; echo "factice : TERM reçu, arret.json écrit" >&2; exit 1' TERM
echo $$ > "$FAUX_PID"
case "$FAUX_MODE" in
  resume_124) echo "{}" > "diag/$run/resume.json"; exit 124 ;;
  arret_1) echo "{}" > "diag/$run/arret.json"; exit 1 ;;
  long) for _ in $(seq 1 300); do sleep 0.1; done; echo "{}" > "diag/$run/resume.json"; exit 0 ;;
esac
EOF
chmod +x "$T/bin/python"
cat > "$T/harnais.sh" <<EOF
set -euo pipefail
cd "$T/depot"
export PATH="$T/bin:\$PATH" FAUX_PID="$T/pid-run"
TRAVAIL="$T"; JOURNAL="$T/journal.txt"; ETAPE="essai"; PID_RUN=""
journal() { printf '%s %s\n' "\$(date -u +%T)" "\$*" | tee -a "\$JOURNAL"; }
consigner_arret() { journal "consigner_arret : \$1"; }
. "$T/fonctions.sh"
trap sur_term TERM
DELAI=(timeout --signal=TERM --kill-after=3s 60s)
EOF
for mode in resume_124 arret_1; do
    bash -c ". $T/harnais.sh; export FAUX_MODE=$mode
        c=0; lancer run-X --run-id R-$mode || c=\$?
        if complet R-$mode; then echo \"($mode) lancer rend \$c ; complet : oui\"; else echo \"($mode) lancer rend \$c ; complet : non\"; fi
        if ! lancer run-Y --run-id R2-$mode; then echo \"($mode) forme du script (if ! lancer) : branche d'échec prise, le script continue (set -e sans effet)\"; fi"
done
echo "(long + TERM au script pendant wait) : TERM transmis au run par son PID, arret.json, sortie 124 sans attendre la fin du run"
bash -c ". $T/harnais.sh; export FAUX_MODE=long; ETAPE='run A'; lancer run-L --run-id R-long; echo 'NON ATTEINT'" &
pid_script=$!
for _ in $(seq 1 100); do [ -s "$T/pid-run" ] && break; sleep 0.1; done
sleep 0.5
debut=$(date +%s.%N)
kill -TERM "$pid_script"
wait "$pid_script"; code=$?
fin=$(date +%s.%N)
echo "    code du script : $code ; durée après TERM : $(echo "$fin - $debut" | bc) s (run factice : 30 s s'il n'est pas arrêté)"
echo "    arret.json du run : $([ -f "$T/depot/diag/R-long/arret.json" ] && echo présent || echo absent) ; resume.json : $([ -f "$T/depot/diag/R-long/resume.json" ] && echo présent || echo absent)"
p=$(cat "$T/pid-run"); echo "    processus du run factice ($p) encore vivant : $(ps -p "$p" >/dev/null 2>&1 && echo OUI || echo non)"
echo "(TERM au seul script pendant une commande au premier plan, aucun run en cours : le piège attend la fin de la commande ;"
echo " dans la chaîne réelle, timeout envoie aussi TERM au groupe, la commande au premier plan meurt aussitôt)"
bash -c ". $T/harnais.sh; ETAPE='entre deux runs'; sleep 5; echo 'NON ATTEINT'" &
pid_script=$!; sleep 1; kill -TERM "$pid_script"; wait "$pid_script"; echo "    code du script : $?"
echo "--- journal"; cat "$T/journal.txt"
rm -rf "$T"
