#!/usr/bin/env bash
# s12 : commandes de la procédure (brouillon 4), sans rien lancer ni contacter.
# (a) argument « --args -c … » développé localement puis exécuté par bash -c dans un dossier jetable (« /root » remplacé) :
#     amorce reconstruite identique à l'octet près à celle du commit ; longueur de l'argument ;
# (b) garde de calcul (copie de .claude/hooks/garde_calcul.py et de registres/go.md, au HEAD relu) : commande de lancement
#     et commande de relancement (-e BRANCHE=…) acceptées avec GO-2026-10-04-08, bloquées sans GO ;
# (c) contrôles de la section 2 avec COMMIT = HEAD relu (candidat) : empreintes des scripts, pathspec vide ;
# (d) jetons factices : ce que reçoit la commande `vastai` (fonction d'essai qui affiche ses arguments, masqués).
# Usage : bash s12_procedure.sh <espace>
set -u
ESP=$1; C=92e2f995e581cb82ad801daff3f12ce19b28dc9b; D=$(mktemp -d)
cd "$ESP/copie-head" || exit 1
ATTENDU=$(git show "$C":scripts/amorce_instance_t04.sh | sha256sum | cut -d' ' -f1)
ARG="echo $(git show "$C":scripts/amorce_instance_t04.sh | base64 -w0) | base64 -d > $D/amorce.sh && sha256sum $D/amorce.sh"
echo "(a) longueur de l'argument -c : ${#ARG} caractères"
OBTENU=$(bash -c "$ARG" | cut -d' ' -f1)
echo "    empreinte reconstruite $OBTENU ; attendue $ATTENDU ; identique : $([ "$OBTENU" = "$ATTENDU" ] && echo oui || echo NON)"
for variante in "" " -e BRANCHE=calcul/t04-validation-relance"; do
COMMANDE="GO_ID=GO-2026-10-04-08 vastai create instance 123456 --image python:3.11-bookworm --disk 80 --env \"-e COMMIT=\$COMMIT -e HF_TOKEN=\$HF_TOKEN -e GH_TOKEN=\$CONTROLE_IA_GITHUB_TOKEN$variante\" --entrypoint bash --args -c \"echo \$(git show \"\$COMMIT\":scripts/amorce_instance_t04.sh | base64 -w0) | base64 -d > /root/amorce.sh && bash /root/amorce.sh\""
python3 - "$COMMANDE" "$ESP/copie-head/.claude/hooks/garde_calcul.py" "${variante:-lancement}" <<'EOF'
import json, subprocess, sys
for nom, cmd in (("avec GO", sys.argv[1]), ("sans GO", sys.argv[1].replace("GO_ID=GO-2026-10-04-08 ", ""))):
    r = subprocess.run([sys.executable, sys.argv[2]], input=json.dumps({"tool_input": {"command": cmd}}), text=True,
                       capture_output=True)
    print(f"(b) {sys.argv[3].strip():45s} {nom} : code {r.returncode} "
          f"({'acceptée' if r.returncode == 0 else 'bloquée'}) {r.stderr.strip()[:80]}")
EOF
done
echo "(c) contrôles de la section 2, COMMIT = HEAD relu ($(git rev-parse --short HEAD))"
COMMIT=$(git rev-parse HEAD)
git show "$COMMIT":scripts/amorce_instance_t04.sh | sha256sum | sed 's/^/    amorce : /'
git show "$COMMIT":scripts/validation_t04_instance.sh | sha256sum | sed 's/^/    script : /'
S=$(git diff --stat 92e2f995e581cb82ad801daff3f12ce19b28dc9b "$COMMIT" -- . ':(exclude)prereg' ':(exclude)brouillons' \
  ':(exclude)registres' ':(exclude)docs' ':(exclude)diag' ':(exclude)runs' ':(exclude)donnees' ':(exclude)livrables' \
  ':(exclude)papiers' ':(exclude)traces' ':(exclude)CLAUDE.md')
echo "    pathspec : $([ -z "$S" ] && echo vide || echo "$S")"
echo "(d) arguments reçus par vastai (fonction d'essai), jetons factices, valeurs des jetons masquées"
vastai() { local a; for a in "$@"; do a=${a//jeton-hf-factice/«HF»}; a=${a//jeton-gh-factice/«GH»}; printf '    [%s]\n' "${a:0:110}"; done; }
(
  HF_TOKEN=jeton-hf-factice CONTROLE_IA_GITHUB_TOKEN=jeton-gh-factice COMMIT=$COMMIT
  GO_ID=GO-2026-10-04-08 vastai create instance 123456 --image python:3.11-bookworm --disk 80 \
    --env "-e COMMIT=$COMMIT -e HF_TOKEN=$HF_TOKEN -e GH_TOKEN=$CONTROLE_IA_GITHUB_TOKEN" \
    --entrypoint bash --args -c "echo $(git show "$COMMIT":scripts/amorce_instance_t04.sh | base64 -w0) | base64 -d > /root/amorce.sh && bash /root/amorce.sh"
)
rm -rf "$D"
