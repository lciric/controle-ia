"""s10 : mutations du code au commit 92e2f99, une à la fois, sur une copie jetable ; pour chacune, la suite entière
(python -m pytest -q -p no:cacheprovider). Une mutation « survivante » (176 passed) = défaut que la suite ne voit pas.
Usage : python s10_mutations.py <espace>   (lance l'interpréteur de /home/user/controle-ia/.venv)"""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

esp = Path(sys.argv[1])
PY = "/home/user/controle-ia/.venv/bin/python"
VR = "src/controle_ia/harnais/validation_reelle.py"
EP = "src/controle_ia/harnais/episode.py"
PR = "src/controle_ia/prereg.py"

MUTATIONS = {
    "témoin (aucune mutation, copie sans .git)": [],
    "M-1 gardes de production juste après le bilan (ordre de 9aaf4a5)": [
        (VR, '                                "episodes_equivalence": {ep.identifiant: r for ep, _, r in sorties if r["ecarts"]}}\n',
         '                                "episodes_equivalence": {ep.identifiant: r for ep, _, r in sorties if r["ecarts"]}}\n'
         '        appliquer_gardes(sorties, resume["production"]["equivalence"], "production", cn)\n'),
        (VR, '        # au vu du repère (lecture gelée), et le run s\'arrête ensuite\n        appliquer_gardes(sorties, resume["production"]["equivalence"], "production", cn)\n',
         '        # au vu du repère (lecture gelée), et le run s\'arrête ensuite\n')],
    "M-2 rapport « diffus » remis à 10": [(VR, "max(mc, mg) <= 3 * min(mc, mg)", "max(mc, mg) <= 10 * min(mc, mg)")],
    "M-3 positions sans retrait du remplissage (défaut D2 de la contre-lecture 3)": [
        (EP, "positions = (masque.cumsum(dim=1) - 1).clamp(min=0)", "positions = torch.arange(L).expand(B, L).clone()")],
    "M-3 décalage constant de +7 sur toutes les positions": [
        (EP, "positions = (masque.cumsum(dim=1) - 1).clamp(min=0)", "positions = (masque.cumsum(dim=1) - 1).clamp(min=0) + 7")],
    "M-4 refus de P0 avant le manifeste supprimé": [
        (VR, "    if decisif and not tests_conformes(tests, config.get(\"tests_attendus\")):\n",
         "    if False and decisif and not tests_conformes(tests, config.get(\"tests_attendus\")):\n")],
    "M-4 champ « reussis » remis à l'ancienne règle": [
        (VR, '"reussis": tests_conformes(tests, config.get("tests_attendus"))}',
         '"reussis": bool(re.search(r"\\d+ passed", derniere)) and not re.search(r"failed|error", derniere)}')],
    "M-5 chemins gelés de 9aaf4a5": [
        (VR, 'CHEMINS_GELES = (".", ":(exclude)prereg", ":(exclude)brouillons", ":(exclude)registres", ":(exclude)docs",\n'
             '                 ":(exclude)diag", ":(exclude)runs", ":(exclude)donnees", ":(exclude)livrables", ":(exclude)papiers",\n'
             '                 ":(exclude)traces", ":(exclude)CLAUDE.md")',
         'CHEMINS_GELES = ("src", "tests", "scripts", "requirements-cpu.txt", "requirements-gpu.txt", "pyproject.toml")')],
    "M-5 chemins gelés sans « src » (exclusion ajoutée)": [
        (VR, '":(exclude)traces", ":(exclude)CLAUDE.md")', '":(exclude)traces", ":(exclude)CLAUDE.md", ":(exclude)src")')],
    "M-6 règle par entrée supprimée (une seule règle sur la section)": [
        (PR, "            if len(set(EMPREINTE.findall(cl[e.start():fin]))) < 2:", "            if False:")],
    "M-8 empreintes du rejeu non gardées": [
        (VR, '                              "empreintes": emp, "empreintes_logits": r["empreintes_logits"],\n'
             '                              "empreintes_capture": r["empreintes_capture"]})',
         '                              })')],
    "M-10 NaN selon l'ordre des couches (code de 9aaf4a5)": [
        (EP, '            m = min(float("-inf") if v["max"] != v["max"] else v["max"] for v in zone.values())\n'
             '            minimum = min(minimum, m)',
         '            m = min(v["max"] for v in zone.values())\n'
             '            minimum = min(minimum, m) if m == m else float("-inf")')],
    "M-10 échecs sans l'épisode": [(EP, "echecs.append(f\"{r.get('episode', '?')}:{cle}\")", "echecs.append(cle)")],
    "M-11 plafond lu à la racine seulement": [
        (VR, "        for k in range(len(parties), -1, -1):", "        for k in range(0, -1, -1):")],
    "M-11 premier plafond lu au lieu du minimum": [
        (VR, "            plafond = int(v) / 1e9 if plafond is None else min(plafond, int(v) / 1e9)",
         "            plafond = int(v) / 1e9 if plafond is None else plafond")],
    "M-11 plafond v2 ignoré": [(VR, '        if controleurs == "":', '        if False:')],
}


racine = esp / "copie"

for nom, patchs in MUTATIONS.items():
    t = Path(tempfile.mkdtemp())
    copie = t / "c"
    shutil.copytree(racine, copie, ignore=shutil.ignore_patterns(".git", "donnees", "__pycache__"))
    if True:
        appliquee = True
        for fichier, avant, apres in patchs:
            f = copie / fichier
            s = f.read_text(encoding="utf-8")
            if avant not in s:
                print(f"[{nom}] motif introuvable dans {fichier} : mutation non appliquée")
                appliquee = False
                break
            f.write_text(s.replace(avant, apres, 1), encoding="utf-8")
    if not appliquee:
        continue
    env = dict(os.environ, PYTHONPATH="src", PYTHONDONTWRITEBYTECODE="1")
    r = subprocess.run([PY, "-m", "pytest", "-q", "-p", "no:cacheprovider", "-x", "--no-header", "-rf"], cwd=copie,
                       env=env, capture_output=True, text=True)
    derniere = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else ""
    echecs = [l for l in r.stdout.splitlines() if l.startswith("FAILED")]
    statut = ("témoin vert" if not patchs and r.returncode == 0 else "SURVIT (suite verte)" if r.returncode == 0 else "vue")
    print(f"[{nom}] {statut} : {derniere} {echecs[:2]}")
    shutil.rmtree(t)
