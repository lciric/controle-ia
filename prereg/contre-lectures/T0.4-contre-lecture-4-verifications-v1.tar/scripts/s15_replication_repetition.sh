#!/usr/bin/env bash
# s15 (R4, reprise de r14 de la contre-lecture 3) : réplication indépendante de la répétition jouet citée par le brouillon 5
# (run 20261004-143851-repetition-jouet, résumé d629e06d…, commit 92e2f99), même entropie, sur une copie jetable du HEAD
# relu ; puis `comparer_runs` (A = run cité, B = réplication) et comparaison des bilans d'équivalence.
# Usage : bash s15_replication_repetition.sh <espace>   (copie-head/ = clone du dépôt au HEAD relu ; sortie des tests de s01)
set -u
ESP=$1; D=$ESP/copie-s15
[ -e "$D" ] && { echo "$D existe (R12)"; exit 2; }
git clone -q "$ESP/copie-head" "$D"; cd "$D" || exit 1
git config user.email t@x.invalid; git config user.name t; git config commit.gpgsign false
echo "HEAD $(git rev-parse --short HEAD) ; diff de l'arbre gelé avec 92e2f99 : [$(git diff --stat 92e2f995e581cb82ad801daff3f12ce19b28dc9b HEAD -- . ':(exclude)prereg' ':(exclude)brouillons' ':(exclude)registres' ':(exclude)docs' ':(exclude)diag' ':(exclude)runs' ':(exclude)donnees' ':(exclude)livrables' ':(exclude)papiers' ':(exclude)traces' ':(exclude)CLAUDE.md')]"
export PYTHONDONTWRITEBYTECODE=1
. /home/user/controle-ia/.venv/bin/activate
A=20261004-143851-repetition-jouet
E=$(python -c "import json;m=json.load(open('runs/$A/manifeste.json'));print(next(iter(m['graines'].values()))['entropie'])")
echo "entropie du run cité : $E"
B=20261004-235959-repetition-jouet
PYTHONPATH=src python -m controle_ia.harnais.validation_reelle --repetition-jouet --entropie "$E" --run-id "$B" \
    --sortie-tests "$ESP/scripts/sorties/s01_suite_tests.stdout.txt" > /dev/null
git add -A runs diag >/dev/null; git commit -qm "s15" >/dev/null
PYTHONPATH=src python - "$A" "$B" <<'EOF'
import json, sys
from controle_ia.harnais import validation_reelle as V
A, B = sys.argv[1:]
c = V.comparer_runs(".", A, B)
print("comparer_runs (A = run cité, B = réplication) :", c["identique"], c["lecture"], c["differences"])
a = json.load(open(f"diag/{A}/resume.json"))["resultat"]
b = json.load(open(f"diag/{B}/resume.json"))["resultat"]
diff = [(ph, k) for ph in ("logique", "production") for k in a[ph]["equivalence"] if a[ph]["equivalence"][k] != b[ph]["equivalence"][k]]
print("bilans d'équivalence différents :", diff or "aucun")
print("lecture de la réplication :", b["lecture"])
EOF
cd "$ESP" && rm -rf "$D"
