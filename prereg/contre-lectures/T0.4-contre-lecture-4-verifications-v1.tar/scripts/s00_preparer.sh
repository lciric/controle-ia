#!/usr/bin/env bash
# s00 : prépare l'espace de travail des vérifications de la contre-lecture 4 (lecture seule du dépôt).
#   copie/       clone du dépôt au commit cité 92e2f99 (code, tests, scripts)
#   copie-head/  clone du dépôt au HEAD relu 89ef2f0 (brouillons, répétitions, essais de l'auteur)
# --no-hardlinks : un clone local partage sinon les fichiers d objets du dépôt (liens physiques), et git en rafraîchit la date.
# Usage : bash s00_preparer.sh <espace> [dépôt source, défaut /home/user/controle-ia]
# Puis, pour les scripts Python : PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=<espace>/copie/src \
#   /home/user/controle-ia/.venv/bin/python <espace>/scripts/sNN_….py <espace>
set -eu
ESP=$1; SRC=${2:-/home/user/controle-ia}
for d in copie copie-head; do [ -e "$ESP/$d" ] && { echo "$ESP/$d existe (R12)"; exit 2; }; done
git clone -q --no-hardlinks "$SRC" "$ESP/copie" && git -C "$ESP/copie" -c advice.detachedHead=false checkout -q 92e2f995e581cb82ad801daff3f12ce19b28dc9b
git clone -q --no-hardlinks "$SRC" "$ESP/copie-head" && git -C "$ESP/copie-head" -c advice.detachedHead=false checkout -q 89ef2f085daf757aa55fa1ad22ec9cba22f014f6
git -C "$ESP/copie" rev-parse HEAD; git -C "$ESP/copie-head" rev-parse HEAD
