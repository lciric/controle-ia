"""s02 (M-1, N-10, M-8) : ordre des gardes de production au commit 92e2f99, de bout en bout (répétition jouet,
V.executer, dépôt jetable). Usage : PYTHONPATH=<espace>/copie/src python s02_m1_gardes_production.py
(a) P4 contraire : tolérance de production abaissée à 1e-6 (le jouet donne 2,3e-3) ;
(b) P5 contraire : tolérance de production portée à 10 (écarts décalés ≈ 1,5 < 10 : contrôle négatif aveugle) ;
(c) N-10 : relecture du disque en échec pour l'épisode 1 (artefact), tolérance normale ;
(d) (a) et (c) à la fois : P8 et P4 contraires ;
(e) P2 contraire (logique, tolérance 1e-12) : arrêt avant la production."""
import json
import subprocess
import tempfile
from pathlib import Path

from controle_ia.gardes import GardeArret
from controle_ia.harnais import politique as P
from controle_ia.harnais import validation_reelle as V


def depot():
    d = Path(tempfile.mkdtemp())
    for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"],
              ["config", "commit.gpgsign", "false"]):
        subprocess.run(["git", "-C", str(d), *a], check=True)
    (d / "README").write_text("x\n")
    (d / ".gitignore").write_text("donnees/\n")
    subprocess.run(["git", "-C", str(d), "add", "-A"], check=True)
    subprocess.run(["git", "-C", str(d), "commit", "-qm", "i"], check=True)
    return d


def essai(nom, cfg, run, relecture_ko=False):
    d = depot()
    vrai = P.relire_et_controler

    def relecture(npz, pol, ep, *a, **k):
        if ep.identifiant == "episode-1":
            raise GardeArret("episode-1 : calcul en ligne ≠ recalcul hors ligne (artefact)")
        return vrai(npz, pol, ep, *a, **k)
    if relecture_ko:
        P.relire_et_controler = relecture
    try:
        V.executer(d, run, entropie=12345, config=cfg, verifier_import=False)
        print(f"({nom}) AUCUN ARRÊT")
        return
    except GardeArret as e:
        motif = str(e)
    finally:
        P.relire_et_controler = vrai
    a = json.loads((d / "diag" / run / "arret.json").read_text())["resultat"]
    p = a["partiel"].get("production", {})
    print(f"({nom}) arrêt : {motif[:110]}…")
    print(f"    phase : {a['phase']} ; débit atteint : {'debit' in a['partiel']}")
    print(f"    clés de la production dans arret.json : {sorted(p)}")
    for k in ("equivalence", "stockage", "rejeu_en_processus", "repere_precision", "empreinte_poids", "episodes"):
        print(f"      {k:20s} présent : {k in p}")
    if "rejeu_en_processus" in p:
        r0 = p["rejeu_en_processus"][0]
        print(f"    rejeu, clés par épisode : {sorted(r0)} ; logits par action : {len(r0['empreintes_logits'])} ; "
              f"identiques : {[r['identique'] for r in p['rejeu_en_processus']]}")
    if "repere_precision" in p:
        print(f"    repère (max par couche) : {[round(v['max'], 5) for v in p['repere_precision'].values()]}")
    if "equivalence" in p:
        e = p["equivalence"]
        print(f"    écart max {e['ecart_max']:.3g} ; contrôle négatif {e['controle_negatif']['passent']}/"
              f"{e['controle_negatif']['comparables']} ; échecs nommés {e['controle_negatif']['echecs'][:3]}")
    print(f"    lecture partielle : {a['partiel']['lecture_partielle']}")
    print(f"    fichiers diag : {sorted(x.name for x in (d / 'diag' / run).iterdir())}")


R = V.CONFIG_REPETITION
essai("a P4", dict(R, production=dict(R["production"], tolerance=1e-6)), "20261004-300000-repetition-jouet")
essai("b P5", dict(R, production=dict(R["production"], tolerance=10.0)), "20261004-300100-repetition-jouet")
essai("c N-10", R, "20261004-300200-repetition-jouet", relecture_ko=True)
essai("d P8+P4", dict(R, production=dict(R["production"], tolerance=1e-6)), "20261004-300300-repetition-jouet",
      relecture_ko=True)
essai("e P2", dict(R, logique=dict(R["logique"], tolerance=1e-12)), "20261004-300400-repetition-jouet")
