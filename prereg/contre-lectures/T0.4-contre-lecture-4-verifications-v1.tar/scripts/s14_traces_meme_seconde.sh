#!/usr/bin/env bash
# s14 : fonction `traces` du script d'instance (commit 92e2f99), extraite telle quelle, appelée deux fois dans la même
# seconde (cas d'un TERM du plafond pendant `traces "fin"`) : le dossier est réutilisé (mkdir -p) et le fichier
# d'empreintes se liste lui-même. Usage : bash s14_traces_meme_seconde.sh <espace>
set -u
ESP=$1
S=$ESP/copie/scripts/validation_t04_instance.sh
T=$(mktemp -d)
git init -q -b main "$T/depot"
git -C "$T/depot" config user.email t@x.invalid; git -C "$T/depot" config user.name t; git -C "$T/depot" config commit.gpgsign false
echo journal > "$T/journal.txt"; echo "176 passed" > "$T/tests.txt"
sed -n '/^traces() {/,/^}/p' "$S" > "$T/traces.sh"
cd "$T/depot" || exit 1
date() { if [ "${1:-}" = -u ]; then command date -u +20261004-151831; else command date "$@"; fi; }   # seconde figée
JOURNAL="$T/journal.txt"; TRAVAIL="$T"
. "$T/traces.sh"
traces "fin"
echo "ajout au journal" >> "$T/journal.txt"
traces "arrêt pendant fin (plafond de l'amorce)"
d=traces/t04-20261004-151831
echo "--- contenu de $d/empreintes.sha256"; cat "$d/empreintes.sha256"
echo "--- sha256sum -c dans $d"; (cd "$d" && sha256sum -c empreintes.sha256)
echo "code de la vérification : $?"
rm -rf "$T"
