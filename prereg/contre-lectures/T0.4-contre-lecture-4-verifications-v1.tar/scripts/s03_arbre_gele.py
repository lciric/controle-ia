"""s03 (M-5) : sémantique réelle de CHEMINS_GELES (pathspec git par exclusion) au commit 92e2f99.
Usage : PYTHONPATH=<espace>/copie/src python s03_arbre_gele.py <espace>
Un dépôt jetable reproduit l'arborescence ; après le « commit cité », chaque modification est committée seule, puis
lue par (1) `git diff --quiet C HEAD -- *CHEMINS_GELES` (forme commune à exiger_code_cite, exiger_rejeu_compatible et
comparer_runs), (2) `exiger_code_cite`, (3) la commande de la procédure (`git diff --stat C COMMIT -- …`), avant retour
à l'état cité. Enfin : (4) le dépôt réel (copie) de 92e2f99 à HEAD ; (5) les trois fonctions, sur un run A et un run B
réels du jouet, quand un fichier gelé change entre A et B."""
import json
import shlex
import subprocess
import sys
import tempfile
from pathlib import Path

from controle_ia.gardes import GardeArret
from controle_ia.harnais import validation_reelle as V

esp = Path(sys.argv[1])


def git(d, *a, ok=True):
    r = subprocess.run(["git", "-C", str(d), *a], capture_output=True, text=True)
    if ok and r.returncode not in (0, 1):
        raise RuntimeError(r.stderr)
    return r


d = Path(tempfile.mkdtemp())
for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"],
          ["config", "commit.gpgsign", "false"]):
    git(d, *a)
fichiers = ["src/controle_ia/x.py", "tests/test_x.py", "scripts/s.sh", "requirements-cpu.txt", "requirements-gpu.txt",
            "requirements-pilotage.txt", "pyproject.toml", ".gitignore", ".gitattributes", ".claude/settings.json",
            ".claude/hooks/garde_calcul.py", "CLAUDE.md", "docs/a.md", "prereg/p.md", "brouillons/b.md",
            "registres/etat.md", "diag/r/x.json", "runs/r/m.json", "livrables/l.md", "papiers/A/a.md", "traces/t.txt"]
for f in fichiers:
    (d / f).parent.mkdir(parents=True, exist_ok=True)
    (d / f).write_text("v0\n")
git(d, "add", "-A")
git(d, "commit", "-qm", "cite")
C = git(d, "rev-parse", "HEAD").stdout.strip()
(d / "prereg" / "p.md").write_text(f"- Commit du code d'analyse : `{C}`\n")
git(d, "add", "-A")
git(d, "commit", "-qm", "prereg")
base = git(d, "rev-parse", "HEAD").stdout.strip()
PROC = ("-- . ':(exclude)prereg' ':(exclude)brouillons' ':(exclude)registres' ':(exclude)docs' ':(exclude)diag' "
        "':(exclude)runs' ':(exclude)donnees' ':(exclude)livrables' ':(exclude)papiers' ':(exclude)traces' "
        "':(exclude)CLAUDE.md'")
print("CHEMINS_GELES =", V.CHEMINS_GELES)
print("pathspec de la procédure identique :", shlex.split(PROC)[1:] == list(V.CHEMINS_GELES))

CAS = [
    ("modifier", ".gitignore"), ("modifier", ".gitattributes"), ("modifier", "pyproject.toml"),
    ("ajouter", "conftest.py"), ("ajouter", "pytest.ini"), ("ajouter", "setup.cfg"), ("ajouter", "tox.ini"),
    ("ajouter", "sitecustomize.py"), ("ajouter", "README.md"),
    ("modifier", ".claude/hooks/garde_calcul.py"), ("modifier", ".claude/settings.json"),
    ("ajouter", ".claude/settings.local.json"), ("modifier", "requirements-pilotage.txt"),
    ("modifier", "src/controle_ia/x.py"), ("modifier", "tests/test_x.py"), ("chmod", "scripts/s.sh"),
    ("ajouter", "src/docs/x.py"), ("ajouter", "src/controle_ia/prereg/x.py"), ("ajouter", "tests/runs/test_y.py"),
    ("ajouter", "src/CLAUDE.md"), ("ajouter", "src/traces/x.py"), ("ajouter", "prereg.py"), ("ajouter", "docs.txt"),
    ("ajouter", "Docs/x.md"), ("ajouter", "CLAUDE.md.bak"), ("deplacer", "src/controle_ia/x.py->docs/x.py"),
    ("ajouter", ".github/workflows/ci.yml"),
    ("modifier", "docs/a.md"), ("modifier", "prereg/p2.md"), ("modifier", "brouillons/b.md"),
    ("modifier", "registres/etat.md"), ("modifier", "diag/r/x.json"), ("modifier", "runs/r/m.json"),
    ("modifier", "livrables/l.md"), ("modifier", "papiers/A/a.md"), ("modifier", "traces/t.txt"),
    ("modifier", "CLAUDE.md"), ("ajouter", "donnees/x.npz"),
]
print(f"{'cas':48s} {'diff --quiet':14s} {'exiger_code_cite':22s} procédure (--stat)")
for op, f in CAS:
    if op == "deplacer":
        a, b = f.split("->")
        (d / b).parent.mkdir(parents=True, exist_ok=True)
        git(d, "mv", a, b)
    elif op == "chmod":
        (d / f).chmod(0o755)
    else:
        (d / f).parent.mkdir(parents=True, exist_ok=True)
        (d / f).write_text("v1\n")
    git(d, "add", "-A", "-f")
    git(d, "commit", "-qm", f"{op} {f}")
    q = git(d, "diff", "--quiet", C, "HEAD", "--", *V.CHEMINS_GELES).returncode
    try:
        V.exiger_code_cite(d, d / "prereg" / "p.md")
        g = "passe"
    except GardeArret as e:
        g = "ARRÊT"
    stat = subprocess.run(f"git -C {d} diff --stat {C} HEAD {PROC}", shell=True, capture_output=True, text=True).stdout
    print(f"{op + ' ' + f:48s} {('différent' if q == 1 else 'identique'):14s} {g:22s} "
          f"{'vide' if not stat.strip() else stat.strip().splitlines()[-1]}")
    git(d, "reset", "-q", "--hard", base)
    subprocess.run(["git", "-C", str(d), "clean", "-qfdx"], check=True)

print("(4) dépôt réel : git diff --stat 92e2f99 HEAD -- <pathspec de la procédure>")
r = subprocess.run(f"git -C {esp / 'copie-head'} diff --stat 92e2f995e581cb82ad801daff3f12ce19b28dc9b HEAD {PROC}",
                   shell=True, capture_output=True, text=True)
print("    sortie :", repr(r.stdout), "code", r.returncode, r.stderr.strip())
r = subprocess.run(f"git -C {esp / 'copie-head'} diff --stat 92e2f995e581cb82ad801daff3f12ce19b28dc9b HEAD | tail -1",
                   shell=True, capture_output=True, text=True)
print("    (sans pathspec :", r.stdout.strip(), ")")

print("(5) exiger_rejeu_compatible et comparer_runs sur des runs jouets, .gitignore modifié entre A et B")
PETITE = dict(V.CONFIG_REPETITION, logique=dict(V.CONFIG_REPETITION["logique"], episodes=2, T=2, max_nouveaux=6,
                                                   taille_lot=2, episodes_equivalence=[1]),
              production=dict(V.CONFIG_REPETITION["production"], episodes=2, T=2, max_nouveaux=6, taille_lot=2,
                              episodes_equivalence=[1]),
              politique=dict(V.CONFIG_REPETITION["politique"], episodes_par_jeton=[1]),
              debit={"tailles_lot": [1, 2], "longueur_contexte": 32, "max_nouveaux": 4},
              controle_negatif={"positions_min": 1, "actions_min": 1, "fraction_min": 0.5})
e = Path(tempfile.mkdtemp())
for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"],
          ["config", "commit.gpgsign", "false"]):
    git(e, *a)
(e / ".gitignore").write_text("donnees/\n")
(e / "README").write_text("x\n")
git(e, "add", "-A"); git(e, "commit", "-qm", "i")
A, B = "20261004-320000-repetition-jouet", "20261004-320100-repetition-jouet"
try:
    V.executer(e, A, entropie=5, config=PETITE, verifier_import=False)
    print("    run A : complet")
except GardeArret as x:
    print("    run A : ARRÊT", str(x)[:80])
git(e, "add", "-A"); git(e, "commit", "-qm", "run A")
(e / ".gitignore").write_text("donnees/\n*.tmp\n")
git(e, "add", "-A"); git(e, "commit", "-qm", "gitignore")
try:
    V.exiger_rejeu_compatible(e, A, dict(PETITE, revision=None))
    print("    exiger_rejeu_compatible : passe")
except GardeArret as x:
    print("    exiger_rejeu_compatible : ARRÊT —", x)
V.executer(e, B, entropie=5, config=PETITE, verifier_import=False)      # B lancé sans --rejeu-de
try:
    c = V.comparer_runs(e, A, B)
    print("    comparer_runs : passe —", c["lecture"])
except GardeArret as x:
    print("    comparer_runs : ARRÊT —", x)
