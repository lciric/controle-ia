"""s05 (M-6) : validateur `problemes` de `prereg.py` au commit 92e2f99, règle « deux empreintes par entrée ».
Usage : PYTHONPATH=<espace>/copie/src python s05_validateur.py <espace>
(a) préenregistrements scellés et brouillon 5 tels quels ;
(b) l'entrée « Contre-lecture 4 … À REMPLIR » du brouillon 5 remplacée par des annonces sans report (r04 rejoué) ;
(c) formulations légitimes (faux refus ?) ;
(d) formes d'entrée que l'expression ENTREE ne reconnaît pas (faux négatifs ?) ;
(e) marqueur d'attente ailleurs dans le texte."""
import sys
import tempfile
from pathlib import Path

from controle_ia.prereg import ENTREE, problemes, sections

esp = Path(sys.argv[1])
b5 = esp / "copie-head" / "brouillons" / "T0.4-validation-modele-reel-v1-brouillon5.md"
src = b5.read_text(encoding="utf-8")
ligne = ("- **Contre-lecture 4** du différentiel `9aaf4a5..92e2f99` et des passages modifiés : À REMPLIR "
         "(brouillon relu, rapport, traitement).")
assert ligne in src, "ligne d'attente introuvable"
H1, H2, H3 = "1" * 64, "2" * 64, "3" * 64


def essai(rempl, texte=None):
    p = Path(tempfile.mkdtemp()) / "p.md"
    p.write_text((texte if texte is not None else src).replace(ligne, rempl), encoding="utf-8")
    return problemes(p) or "ACCEPTÉ"


print("(a) tels quels")
for f in sorted((esp / "copie-head" / "prereg").glob("*.md")):
    print(f"    {f.name}: {problemes(f) or 'ACCEPTÉ'}")
print(f"    brouillon 5 : {problemes(b5)}")
cl = sections(src)["Contre-lecture"]
print("    entrées reconnues dans le brouillon 5 :", [m.group(0).strip() for m in ENTREE.finditer(cl)])

print("(b) annonces sans report (r04 de la contre-lecture 3, rejoué sur la contre-lecture 4)")
for t in ("en cours.", "prévue avant le lancement.", "TODO.", "à relire.", "A faire.", "non encore faite.",
          "rapport à joindre.", "à faire.", "à remplir (minuscules).",
          "(sous-agent neuf) : faite ; verdict scellable ; remarques intégrées."):
    print(f"    {('- **Contre-lecture 4** : ' + t)!r:95s} -> {essai('- **Contre-lecture 4** : ' + t)}")

print("(c) formulations légitimes")
bon = (f"- **Contre-lecture 4** (quatrième sous-agent neuf, 2026-10-04) :\n"
       f"  - brouillon relu : `brouillons/…-brouillon5.md`, sha256 `{H1}` ;\n"
       f"  - rapport : `prereg/contre-lectures/T0.4-rapport-contre-lecture-4-v1.md`, sha256 `{H2}` ;\n"
       f"  - verdict : scellable ; rien à reporter dans le code ; zip à venir après le verdict.\n"
       f"- **Traitement des remarques de la contre-lecture 4** : Q-1 corrigée à faire en v2.")
print(f"    entrée complète (2 empreintes, mots d'attente dans le texte) -> {essai(bon)}")
print(f"    une seule empreinte -> {essai(f'- **Contre-lecture 4** : brouillon `{H1}`, rapport à venir.')}")
print(f"    la même empreinte deux fois -> {essai(f'- **Contre-lecture 4** : brouillon `{H1}`, rapport `{H1}`.')}")
print(f"    deux empreintes quelconques (celles de la contre-lecture 3 recopiées) -> "
      f"{essai('- **Contre-lecture 4** : voir `35df41184a7f2b4eb89e1377980bc03f0b842afff2ec69f78f6a8cb8908b0838` et `80d0e05d671c5df1a4601fdf8d69a3ffc6b6e88a3d365d8e91feab787bd5199b`.')}")
suite = (f"- **Contre-lecture 4** : brouillon `{H1}`, rapport `{H2}` ; la ligne\n"
         f"Contre-lecture 3 a vu juste sur M-1 (ligne de texte renvoyée à la ligne).")
print(f"    ligne de continuation qui commence par « Contre-lecture 3 » -> {essai(suite)}")
traitement = (f"- **Contre-lecture 4** : brouillon `{H1}`, rapport `{H2}`.\n"
              f"- **Contre-lecture 4, traitement** : remarques acceptées.")
print(f"    sous-entrée « Contre-lecture 4, traitement » -> {essai(traitement)}")

print("(d) formes d'entrée non reconnues : l'entrée sans empreinte est avalée par la contre-lecture 3")
for t in ("* **Contre-lecture 4** : faite.", "1. **Contre-lecture 4** : faite.", "- **Contre-Lecture 4** : faite.",
          "- __Contre-lecture 4__ : faite.", "- **Contre-lecture n° 4** : faite.", "- **Contre‑lecture 4** : faite.",
          "- **Quatrième contre-lecture** : faite.", "- **Contre-lecture  4** : faite."):
    print(f"    {t!r:45s} -> {essai(t)}")

print("(e) marqueur d'attente ailleurs")
complet = src.replace(ligne, bon)
print(f"    contre-lecture 4 remplie, marqueur laissé dans la Transparence -> "
      f"{essai(bon, complet.replace('- Les ordres de grandeur', '- À REMPLIR : note. Les ordres de grandeur'))}")
print(f"    contre-lecture 4 remplie, le mot cité dans une phrase (« le marqueur À REMPLIR ») -> "
      f"{essai(bon, complet.replace('Il ne lit pas le sens des phrases.', 'Il ne lit pas le sens des phrases (marqueur « À REMPLIR »).'))}")
