"""s11 : table de lecture gelée du brouillon 5 contre `lire` (commit 92e2f99), sur des résumés synthétiques, une ligne
de la table par cas. Usage : PYTHONPATH=<espace>/copie/src python s11_table_lire.py"""
import copy

from controle_ia.harnais import validation_reelle as V

C = V.CONFIG_REELLE


def bilan(tol, ecart, ctx, gen, comparables=12, passent=12, remplies=3, finies=2, positions=40, lignes=(1, 6),
          zeros_gen=(1, 40)):
    return {"tolerance": tol, "ecart_max": ecart, "max_contexte": ctx, "max_zone_generee": gen,
            "controle_negatif": {"comparables": comparables, "passent": passent,
                                 "fraction": passent / comparables if comparables else None},
            "couverture": {"actions_remplies": remplies, "actions_finies_avant": finies,
                           "positions_generees_comparees": positions, "lignes_echantillon": list(lignes)},
            "zeros": {"7": {"contexte": [0, 10], "generee": list(zeros_gen)},
                      "15": {"contexte": [0, 10], "generee": list(zeros_gen)}},
            "sondes_audit": {"tableaux_distincts": True, "ulp_vu": True}}


SAIN = {"format": {"verifie": True},
        "tests_instance": {"derniere_ligne": "176 passed in 71.19s (0:01:11)"},
        "logique": {"equivalence": bilan(1e-4, 2e-6, 1e-7, 2e-6)},
        "production": {"equivalence": bilan(0.1, 1e-2, 5e-3, 1e-2, lignes=(1, 6)),
                       "rejeu_en_processus": [{"identique": True}] * 8}}


def cas(nom, modif):
    r = copy.deepcopy(SAIN)
    modif(r)
    lec = V.lire(r, C)
    cles = ("tests_instance", "format", "logique_equivalence", "logique_controle_negatif", "production_equivalence",
            "production_controle_negatif", "rejeu_en_processus", "audit_symetrie")
    print(f"{nom}\n    " + " ; ".join(f"{k}={lec[k]}" for k in cles))


def pose(chemin, valeur):
    def f(r):
        d = r
        for k in chemin[:-1]:
            d = d[k]
        d[chemin[-1]] = valeur
    return f


cas("ligne 1 : tout conforme", lambda r: None)
cas("P0 : 175 passed, 1 skipped", pose(("tests_instance", "derniere_ligne"), "175 passed, 1 skipped in 70.0s (0:01:10)"))
cas("P0 : avertissements admis", pose(("tests_instance", "derniere_ligne"), "176 passed, 3 warnings in 70.0s (0:01:10)"))
cas("P2 contraire, concentré dans la zone générée (D1 : 1,4e-7 / 6,0e-4)",
    pose(("logique", "equivalence"), bilan(1e-4, 6e-4, 1.4e-7, 6e-4)))
cas("P2 diffus, rapport 2,4 (5e-5 / 1,2e-4) : précision probable",
    pose(("logique", "equivalence"), bilan(1e-4, 1.2e-4, 5e-5, 1.2e-4)))
cas("P2 rapport 3,5 (4e-5 / 1,4e-4) : contraire", pose(("logique", "equivalence"), bilan(1e-4, 1.4e-4, 4e-5, 1.4e-4)))
cas("P2 diffus mais écart 2e-2 > 1e-2 : contraire", pose(("logique", "equivalence"), bilan(1e-4, 2e-2, 1e-2, 2e-2)))
cas("P2 écart NaN (illisible) : contraire", pose(("logique", "equivalence"), bilan(1e-4, float("nan"), None, None)))
cas("P2 couverture : aucune action remplie", pose(("logique", "equivalence"), bilan(1e-4, 2e-6, 1e-7, 2e-6, remplies=0)))
cas("P2 couverture : échantillon en tête de lot seulement", pose(("logique", "equivalence"),
                                                                bilan(1e-4, 2e-6, 1e-7, 2e-6, lignes=(0,))))
cas("P3 non concluant : 9 actions comparables", pose(("logique", "equivalence"), bilan(1e-4, 2e-6, 1e-7, 2e-6, 9, 9)))
cas("P3 contraire : 11 sur 12 (91,7 %)", pose(("logique", "equivalence"), bilan(1e-4, 2e-6, 1e-7, 2e-6, 12, 11)))
cas("P3 à la limite : 19 sur 20 (95 %)", pose(("logique", "equivalence"), bilan(1e-4, 2e-6, 1e-7, 2e-6, 20, 19)))
cas("P4 contraire : 0,2 (la règle « diffus » ne vaut qu'en logique)",
    pose(("production", "equivalence"), bilan(0.1, 0.2, 0.15, 0.2)))
cas("P5 contraire : 0 sur 12", pose(("production", "equivalence"), bilan(0.1, 1e-2, 5e-3, 1e-2, 12, 0)))
cas("P6 contraire : un épisode rejoué différent",
    pose(("production", "rejeu_en_processus"), [{"identique": True}] * 7 + [{"identique": False}]))
cas("P6 : liste vide", pose(("production", "rejeu_en_processus"), []))
cas("P9 déclenché : aucun écart non nul dans la zone générée (logique)",
    pose(("logique", "equivalence"), bilan(1e-4, 0.0, 0.0, 0.0, zeros_gen=(40, 40))))
cas("production non atteinte (arrêt en logique)", lambda r: r.pop("production"))
