#!/usr/bin/env bash
# s01 : suite de tests au commit cité, commande exacte du script d'instance (sortie standard et sortie d'erreur séparées),
# puis lecture de P0 par `tests_conformes` (176 attendus). Usage : bash s01_suite_tests.sh <espace>  (copie/ au commit 92e2f99)
set -u
ESP=$1; S=$ESP/scripts/sorties
cd "$ESP/copie" || exit 1
echo "commit : $(git rev-parse HEAD)"
export PYTHONDONTWRITEBYTECODE=1
. /home/user/controle-ia/.venv/bin/activate
debut=$(date +%s)
PYTHONPATH=src python -m pytest -q -p no:cacheprovider > "$S/s01_suite_tests.stdout.txt" 2> "$S/s01_suite_tests.stderr.txt"
echo "code de sortie de pytest : $? ; durée $(( $(date +%s) - debut )) s"
echo "dernière ligne : $(tail -1 "$S/s01_suite_tests.stdout.txt")"
echo "sortie d'erreur : $(wc -c < "$S/s01_suite_tests.stderr.txt") octets"
PYTHONPATH=src python -c "
import sys; from controle_ia.harnais.validation_reelle import tests_conformes, CONFIG_REELLE
print('tests_conformes(sortie, %d) =' % CONFIG_REELLE['tests_attendus'], tests_conformes(open(sys.argv[1]).read(), CONFIG_REELLE['tests_attendus']))
" "$S/s01_suite_tests.stdout.txt"
