#!/usr/bin/env bash
# s08 : concordance texte / code du brouillon 5 au commit 92e2f99 : citations (expressions du lanceur et `sed` du script
# d'instance), configuration réelle, couches, empreintes des documents et des scripts, GO, chiffres de la répétition.
# Usage : bash s08_concordance.sh <espace>   (copie/ au commit 92e2f99, copie-head/ au HEAD relu)
set -uo pipefail
ESP=$1
B5=$ESP/copie-head/brouillons/T0.4-validation-modele-reel-v1-brouillon5.md
cd "$ESP/copie" || exit 1
export PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src
PY=/home/user/controle-ia/.venv/bin/python
echo "== empreinte du brouillon 5 : $(sha256sum "$B5" | cut -c1-64)"
echo "== citations lues par le lanceur (COMMIT_CITE, REVISION_CITEE, ENTROPIE_CITEE) et par le sed du script"
$PY - "$B5" <<'PY'
import sys, math
from pathlib import Path
from controle_ia.harnais import validation_reelle as V
t = Path(sys.argv[1]).read_text(encoding="utf-8")
for nom, rx in (("commit", V.COMMIT_CITE), ("révision", V.REVISION_CITEE), ("entropie", V.ENTROPIE_CITEE)):
    m = rx.findall(t)
    print(f"   {nom:9s}: {m}")
e = int(V.ENTROPIE_CITEE.search(t).group(1)); print(f"   entropie : {e.bit_length()} bits")
PY
R=$(sed -n 's/.*Révision du modèle : `\([0-9a-f]\{40\}\)`.*/\1/p' "$B5" | head -1)
echo "   sed du script : $R"
echo "== scripts au commit cité (empreintes citées l. 14-15)"
for s in validation_t04_instance.sh amorce_instance_t04.sh; do
    echo "   $s : $(git show 92e2f995e581cb82ad801daff3f12ce19b28dc9b:scripts/$s | sha256sum | cut -c1-64)"
done
grep -o '`[0-9a-f]\{64\}`' "$B5" | sed -n '1,2p' | sed 's/^/   cité : /'
echo "== configuration réelle"
$PY <<'PY'
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais.activations import couches_par_defaut
c = V.CONFIG_REELLE
print("   logique   :", {k: c["logique"][k] for k in ("episodes", "N", "T", "max_nouveaux", "taille_lot", "tolerance", "episodes_equivalence", "noyau_attention", "dtype")})
print("   production:", {k: c["production"][k] for k in ("episodes", "N", "T", "max_nouveaux", "taille_lot", "tolerance", "episodes_equivalence", "lots_rejeu_en_processus", "dtype")})
print("   débit     :", c["debit"], "; politique : par jeton", c["politique"]["episodes_par_jeton"], "; sondes", len(c["politique"]["sondes"]))
print("   contrôle négatif :", c["controle_negatif"], "; carte ≥", c["memoire_carte_min_gio"], "Gio ; vive ≥", c["memoire_vive_min_go"], "Go")
print("   tests attendus :", c["tests_attendus"], "; limite interne :", c["limite_s"], "s =", c["limite_s"] / 3600, "h ; gabarit :", c["variables_gabarit"], "; ouverture :", c["format"]["texte_attendu_ouverture"])
print("   couches de 32 :", couches_par_defaut(32), "; modèle :", c["modele"], "; attention :", c["attention"])
PY
echo "== délais des scripts"
grep -n "timeout --signal\|DELAI=" scripts/validation_t04_instance.sh scripts/amorce_instance_t04.sh
echo "== documents qui font foi (copie-head)"
cd "$ESP/copie-head" || exit 1
sha256sum docs/brief-claude-code-programme-complet-v2.md docs/programme-controle-ia-v2.md livrables/premier-rendu-v1/devis-v1.md
for h in 9261932a11f29e8643175bc6e150d5455067f58a3cb1e57dca99e02cb17aa3b2 2fd63badb5afea48f48d3ca501ae3b027c4094a8b176508488a41a22e45aa18c 16d71febf1491780ab1230ed1fb8e4d8b1bec47fbed202e0ef26ca666def04c2; do
    grep -c "$h" "$B5" | sed "s/^/   cité dans le brouillon ($h) : /" | cut -c1-60
done
echo "== GO"
grep -n "GO-2026-10-04-08" registres/go.md | cut -c1-200
echo "== toutes les empreintes de 64 caractères citées dans le brouillon 5, contre les fichiers du dépôt"
grep -o '[0-9a-f]\{64\}' "$B5" | sort -u > /tmp/s08-cites.$$
git ls-files -z | xargs -0 sha256sum 2>/dev/null | awk '{print $1, $2}' > /tmp/s08-depot.$$
while read -r h; do
    f=$(grep "^$h " /tmp/s08-depot.$$ | head -1 | cut -d' ' -f2-)
    echo "   ${h:0:16}… -> ${f:-(aucun fichier du dépôt à HEAD)}"
done < /tmp/s08-cites.$$
rm -f /tmp/s08-cites.$$ /tmp/s08-depot.$$
