"""s07 (M-11) : plafonds_cgroup et exiger_memoire_vive au commit 92e2f99.
Usage : PYTHONPATH=<espace>/copie/src python s07_cgroup.py
(a) ce conteneur (hiérarchie hybride : v1 avec contrôleur memory, plus « 0::/ ») ;
(b) fausses arborescences : v2 avec espace de noms (Docker), v2 sans espace de noms, v1 monté à la racine du
    conteneur, v1 co-monté, valeurs « max » et « illimité », ligne mal formée."""
import tempfile
from pathlib import Path

from controle_ia.harnais import validation_reelle as V

print("(a) ce conteneur")
print("    /proc/self/cgroup :", Path("/proc/self/cgroup").read_text().strip().replace("\n", " | "))
for f in V.plafonds_cgroup():
    p = Path(f)
    print(f"    {f} -> {p.read_text().strip() if p.exists() else 'absent'}")
print("    exiger_memoire_vive(1) :", V.exiger_memoire_vive(1))


def arbre(cgroup: str, fichiers: dict) -> tuple[str, str]:
    d = Path(tempfile.mkdtemp())
    (d / "cgroup").write_text(cgroup)
    for rel, val in fichiers.items():
        (d / "fs" / rel).parent.mkdir(parents=True, exist_ok=True)
        (d / "fs" / rel).write_text(val + "\n")
    (d / "meminfo").write_text("MemTotal:       250000000 kB\n")      # 256 Go d'hôte
    return str(d / "cgroup"), str(d / "fs"), str(d / "meminfo")


CAS = {
    "v2, espace de noms (Docker) : 0::/, plafond 100 Go": ("0::/\n", {"memory.max": "100000000000"}),
    "v2, sans espace de noms, plafond sur l'ancêtre (40 Go), « max » sur le groupe":
        ("0::/system.slice/docker-abc.scope\n", {"system.slice/docker-abc.scope/memory.max": "max",
                                                  "system.slice/memory.max": "40000000000"}),
    "v2, groupe plus serré que l'ancêtre (30 Go < 40 Go)":
        ("0::/a/b\n", {"a/b/memory.max": "30000000000", "a/memory.max": "40000000000"}),
    "v2, ancêtre plus serré que le groupe (40 Go < 50 Go) : le minimum, pas le premier lu":
        ("0::/a/b\n", {"a/b/memory.max": "50000000000", "a/memory.max": "40000000000"}),
    "v1, groupe du conteneur monté à la racine (chemin d'hôte /docker/abc), 96 Go":
        ("4:memory:/docker/abc\n", {"memory/memory.limit_in_bytes": "96000000000"}),
    "v1 co-monté (cpu,memory), 50 Go": ("4:cpu,memory:/x\n", {"memory/x/memory.limit_in_bytes": "50000000000"}),
    "v1 illimité partout": ("4:memory:/x\n", {"memory/x/memory.limit_in_bytes": "9223372036854771712",
                                             "memory/memory.limit_in_bytes": "9223372036854771712"}),
    "hybride (comme ici) : v1 à 14,3 Go, v2 « 0::/ » sans fichier":
        ("4:memory:/p/q\n0::/\n", {"memory/p/q/memory.limit_in_bytes": "14345035776"}),
    "ligne mal formée et contrôleur « name=systemd » seuls": ("n'importe quoi\n1:name=systemd:/x\n", {}),
}
print("(b) fausses arborescences (MemTotal 256 Go)")
for nom, (cg, fs) in CAS.items():
    c, r, m = arbre(cg, fs)
    fichiers = V.plafonds_cgroup(c, r)
    res = V.exiger_memoire_vive(1, m, fichiers)
    print(f"    {nom}\n        candidats {len(fichiers)} ; résultat {res}")
