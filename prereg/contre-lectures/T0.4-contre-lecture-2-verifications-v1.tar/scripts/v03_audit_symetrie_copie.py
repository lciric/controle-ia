"""V03 : l'audit gelé de P9 (sondes : tableaux distincts, perturbation d'un ulp vue) sur son artefact cible.
Artefact : les captures de génération sont remplacées par une COPIE des activations de la passe unique (comparaison
de la passe unique avec elle-même, par copie). De bout en bout par V.executer, configuration de répétition jouet."""
import json, subprocess, tempfile
from pathlib import Path
from controle_ia.harnais import episode as E
from controle_ia.harnais import validation_reelle as V

def depot():
    d = Path(tempfile.mkdtemp())
    for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"]):
        subprocess.run(["git", "-C", str(d), *a], check=True)
    (d / "README").write_text("x\n")
    subprocess.run(["git", "-C", str(d), "add", "-A"], check=True)
    subprocess.run(["git", "-C", str(d), "commit", "-qm", "init"], check=True)
    return d

def copie_de_la_passe(f):
    def g(ag, ap, *a, **k):
        return f({c: ap[c][: x.shape[0]].copy() for c, x in ag.items()}, ap, *a, **k)
    return g
vrais = {n: getattr(E, n) for n in ("ecart_equivalence", "ecart_decale_zone_generee", "profil_ecarts", "sonde_de_comparaison")}
for n, f in vrais.items():
    setattr(E, n, copie_de_la_passe(f))
d = depot()
try:
    s = V.executer(d, "20261004-210000-repetition-jouet", entropie=12345, config=V.CONFIG_REPETITION, verifier_import=False)
finally:
    for n, f in vrais.items():
        setattr(E, n, f)
r = json.loads((d / s["resume"]).read_text())["resultat"]
for ph in ("logique", "production"):
    b = r[ph]["equivalence"]
    print(ph, ": écart maximal", b["ecart_max"], "; zéros (contexte, zone générée)", b["zeros"], "; sondes", b["sondes_audit"],
          "; contrôle négatif min", round(b["controle_negatif"]["min_des_maxima"], 3))
print("lecture :", json.dumps(r["lecture"], ensure_ascii=False, indent=1))
