"""Complément d'exp1b : quelles positions de la zone générée ont un écart décalé ≤ 0,1 en demi-précision (jouet) ?
On relit les captures (crochets) et la passe unique ; jetons concernés et longueur de l'action."""
import numpy as np
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais import episode as E
from controle_ia.harnais.activations import couches_par_defaut, ecarts_par_jeton
from controle_ia.manifeste import graines as G

cfg = V.CONFIG_REPETITION
V.regler_determinisme(1, "cpu")
gr = G(V.taches(cfg), entropie=12345)
c = cfg["production"]
m, tok = V.charger(cfg, None, c["dtype"], gr)
fmt, _ = V.format_du_modele(m, tok, cfg)
couches = couches_par_defaut(m.config.num_hidden_layers)
vrai = E.relire_crochets_lot
capt = {}
def espion(brut, k, lc, plan, n):
    r = vrai(brut, k, lc, plan, n); capt.setdefault("liste", []).append((lc, r)); return r
E.relire_crochets_lot = espion
sorties, plan = V.jouer_phase(m, fmt, c, gr, "production", couches)
E.relire_crochets_lot = vrai
for ep, acts, r in sorties:
    for tr in ep.transcriptions:
        for a in tr.actions:
            cle = f"{a.agent},{a.pas}"
            if cle not in r["longueurs_contexte"]:
                continue
            lc = r["longueurs_contexte"][cle]
            # reconstitue la capture depuis le rapport : on recalcule l'écart décalé à partir des activations de la passe
            # unique et des captures relues (via l'espion, dans l'ordre des appels)
for (lc, ag) in capt["liste"]:
    pass
# appariement : on rejoue la correspondance (b, i, t) → capture par l'ordre des appels
ordre = []
for t in range(c["T"]):
    for i in range(c["N"]):
        for j, lot in enumerate(plan):
            for b, k in enumerate(lot):
                if k in c["episodes_equivalence"]:
                    ordre.append((k, i, t))
# l'ordre réel des appels : lot par lot, puis (t, i), puis lignes
ordre = [(k, i, t) for lot in plan for t in range(c["T"]) for i in range(c["N"]) for k in lot if k in c["episodes_equivalence"]]
par_ep = {int(ep.identifiant.split("-")[1]): (ep, acts) for ep, acts, _ in sorties}
for (k, i, t), (lc, ag) in zip(ordre, capt["liste"]):
    ep, acts = par_ep[k]
    tr = ep.transcriptions[i]
    for couche in couches:
        g, p = ag[couche], acts[i][couche]
        if g.shape[0] <= lc + 1:
            continue
        e = ecarts_par_jeton(g[lc + 1:], p[lc: g.shape[0] - 1])
        for j in np.where(e <= c["tolerance"])[0]:
            n = lc + 1 + j
            print(f"épisode {k}, action ({i}, {t}), couche {couche} : position {n} (zone générée de {g.shape[0] - lc} positions) ;"
                  f" écart décalé {e[j]:.4f} ; jetons {tok.decode([tr.ids[n - 1]])!r} → {tok.decode([tr.ids[n]])!r}")
