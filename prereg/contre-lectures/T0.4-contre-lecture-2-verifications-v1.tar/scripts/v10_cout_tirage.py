"""V10 : coût, sur le processeur central (un fil, comme regler_determinisme), du travail fait à chaque passe de décodage
par generer_lot pour un lot de 8 : softmax + tirage multinomial sur 128 256 jetons, et empreinte sha256 des logits
(empreinte_logits=True). Mesure sur cette machine (pas l'instance) : ordre de grandeur pour le budget."""
import hashlib, time
import torch
torch.set_num_threads(1)
V, B, R = 128256, 8, 200
logits = torch.randn(B, V) * 3
gens = [torch.Generator().manual_seed(i) for i in range(B)]
t0 = time.perf_counter()
for _ in range(R):
    for r in range(B):
        torch.multinomial(torch.softmax(logits[r] / 1.0, dim=-1), 1, generator=gens[r])
t1 = time.perf_counter()
for _ in range(R):
    for r in range(B):
        hashlib.sha256(logits[r].contiguous().numpy().tobytes()).hexdigest()
t2 = time.perf_counter()
print(f"par passe (lot de 8) : tirage {1e3 * (t1 - t0) / R:.1f} ms ; empreinte des logits {1e3 * (t2 - t1) / R:.1f} ms")
