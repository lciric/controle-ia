"""V02 : chargement du point de contrôle bfloat16 puis conversion en simple précision (charger_modele, phase de logique)
contre chargement direct en simple précision ; paramètres, tampons (inv_freq de RoPE, type llama3) et passe unique.
Modèle jouet de type Llama 3.1 (rope llama3, theta 500 000), enregistré en bfloat16, hors ligne."""
import tempfile
from pathlib import Path
import numpy as np, torch
from transformers import AutoModelForCausalLM, LlamaConfig, LlamaForCausalLM
from controle_ia.harnais.activations import passe_unique, ecarts_par_jeton

torch.manual_seed(0)
cfg = LlamaConfig(vocab_size=300, hidden_size=64, intermediate_size=128, num_hidden_layers=4, num_attention_heads=4,
                  num_key_value_heads=2, rope_theta=500000.0, max_position_embeddings=131072,
                  rope_scaling={"factor": 8.0, "low_freq_factor": 1.0, "high_freq_factor": 4.0,
                                "original_max_position_embeddings": 8192, "rope_type": "llama3"},
                  tie_word_embeddings=False)
m = LlamaForCausalLM(cfg).to(torch.bfloat16)
d = Path(tempfile.mkdtemp())
m.save_pretrained(d)
a = AutoModelForCausalLM.from_pretrained(d, dtype=torch.bfloat16, attn_implementation="sdpa").to("cpu").to(torch.float32).eval()
b = AutoModelForCausalLM.from_pretrained(d, dtype=torch.float32, attn_implementation="sdpa").eval()
pa, pb = dict(a.named_parameters()), dict(b.named_parameters())
print("paramètres identiques :", all(torch.equal(pa[k], pb[k]) for k in pa), f"({len(pa)})")
ba, bb = dict(a.named_buffers()), dict(b.named_buffers())
for k in sorted(set(ba) | set(bb)):
    x, y = ba.get(k), bb.get(k)
    print(f"tampon {k}: types {getattr(x, 'dtype', None)} / {getattr(y, 'dtype', None)}, identiques : "
          f"{x is not None and y is not None and torch.equal(x.float(), y.float())}")
ids = list(np.random.default_rng(0).integers(5, 290, size=400))
ca, cb = passe_unique(a, ids, [0, 1, 2, 3]), passe_unique(b, ids, [0, 1, 2, 3])
print("passe unique identique au bit près :", {c: bool(np.array_equal(ca[c], cb[c])) for c in ca},
      "écart max :", {c: float(ecarts_par_jeton(ca[c], cb[c]).max()) for c in ca})
# chargement bf16 puis conversion : inv_freq a-t-il transité par bfloat16 ?
c16 = AutoModelForCausalLM.from_pretrained(d, dtype=torch.bfloat16, attn_implementation="sdpa")
print("inv_freq du modèle chargé en bfloat16 :", {k: str(v.dtype) for k, v in c16.named_buffers()})
