"""Rejeu d'exp9 (contre-lecture 1) contre le code ad48125 : zone générée constante des deux côtés, contexte intact ;
nouveau contrôle (ecart_decale_zone_generee + exiger_gardes) sur une vraie action jouée en demi-précision."""
import numpy as np, torch
from controle_ia.harnais import episode as E
from controle_ia.harnais.activations import ecart_equivalence, ecart_decale_zone_generee
from controle_ia.harnais.formats import FormatChat
from controle_ia.harnais.modeles import modele_jouet, regler_determinisme, tokeniseur_caracteres_chat
from controle_ia.gardes import GardeArret

regler_determinisme(1)
tok = tokeniseur_caracteres_chat(); FIN = tok.convert_tokens_to_ids("<|im_end|>")
fmt = FormatChat(tok, fins={FIN, tok.eos_token_id})
m = modele_jouet(11, len(tok), couches=4, largeur=32, tetes=4, tetes_cle_valeur=2, intermediaire=64).to(torch.bfloat16)
liste = []
vrai = E.relire_crochets_lot
def capt(brut, k, lc, plan, n):
    r = vrai(brut, k, lc, plan, n); liste.append((lc, r)); return r
E.relire_crochets_lot = capt
(ep, acts, rap), = E.jouer_episodes(m, fmt, E.EnvironnementJouet(), ["e0"], 1, 2, [{(0, 0): 5, (0, 1): 6}], [0, 1, 2],
                                    max_nouveaux=16, echantillon_equivalence={(0, 0, 0), (0, 0, 1)}, tolerance_equivalence=0.1,
                                    garde="differee")
E.relire_crochets_lot = vrai
print("sain, action (0, 1) :", {c: round(v["max"], 3) for c, v in rap["controle_negatif_zone_generee"]["0,1"].items()})
lc, ag = liste[1]
n_gen = ag[0].shape[0] - lc
g = {c: a.copy() for c, a in ag.items()}; p = {c: a.copy() for c, a in acts[0].items()}
for c in g:
    v = p[c][lc].copy()
    g[c][lc:] = v; p[c][lc:lc + n_gen] = v
ancien = ecart_equivalence(g, p, decalage=1)
zone = ecart_decale_zone_generee(g, p, lc, 0.1)
rapport = {"tolerance": 0.1, "ecarts": {"0,1": ecart_equivalence(g, p)}, "controle_negatif_zone_generee": {"0,1": zone}}
try:
    E.exiger_gardes(rapport, "0,1", "artefact zone générée constante")
    verdict = "PASSE (non détecté)"
except GardeArret as e:
    verdict = f"arrêt : {str(e)[:100]}"
print(f"{n_gen} positions générées sur {ag[0].shape[0]} ; ancienne statistique (toutes positions) : "
      f"{ {c: round(x, 2) for c, x in ancien.items()} } ; nouvelle (zone générée) : { {c: v['max'] for c, v in zone.items()} } → {verdict}")
