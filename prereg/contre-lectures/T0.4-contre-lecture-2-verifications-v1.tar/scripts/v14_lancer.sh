#!/usr/bin/env bash
# V14 : relance la répétition jouet à l'entropie du run 20261004-121435-repetition-jouet (code identique à ad48125),
# puis compare au résumé scellé de l'auteur (v14_replication_repetition.py).
W="$1"; rm -rf "$W/v14"; git clone -q "$W/copie" "$W/v14"; cd "$W/v14"; git diff --stat ad48125 HEAD -- src tests
. /home/user/controle-ia/.venv/bin/activate
E=$(python -c "import json;m=json.load(open('runs/20261004-121435-repetition-jouet/manifeste.json'));print(next(iter(m['graines'].values()))['entropie'])")
PYTHONPATH=src python -m controle_ia.harnais.validation_reelle --repetition-jouet --entropie $E --run-id 20261004-235900-repetition-jouet > /dev/null
PYTHONPATH=src python "$W/scripts/v14_replication_repetition.py"
