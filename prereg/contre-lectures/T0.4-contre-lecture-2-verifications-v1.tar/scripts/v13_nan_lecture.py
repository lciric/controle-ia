"""V13 : un écart non numérique (NaN, par exemple un débordement dans une activation) : la garde (exiger_equivalence,
« not e <= tol ») arrête, mais bilan_phase (max Python) et lire (« > tol ») peuvent l'ignorer. Rapport synthétique."""
import math
from controle_ia.gardes import GardeArret
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais.episode import Episode

ep = Episode("episode-1", 1, 1, [])
rapport = {"tolerance": 1e-4, "ecarts": {"0,0": {7: 2e-7, 15: float("nan"), 23: 3e-7}},
           "controle_negatif_zone_generee": {"0,0": {7: {"max": 1.2, "au_dessus": 5, "positions": 5},
                                                     15: {"max": float("nan"), "au_dessus": 0, "positions": 5},
                                                     23: {"max": 1.1, "au_dessus": 5, "positions": 5}}},
           "profils": {"0,0": {c: {"jetons": 9, "contexte": {"jetons": 4, "nuls": 0}, "generee": {"jetons": 5, "nuls": 0}}
                               for c in (7, 15, 23)}},
           "sondes": {"0,0": {"tableaux_distincts": True, "ulp_vu": True}}}
sorties = [(ep, {}, rapport)]
plan = [[0, 1]]
bilan = V.bilan_phase(sorties, plan, {"jetons_remplissage": 3, "lignes_finies_avant": 1}, {"tolerance": 1e-4})
print("bilan : écart maximal", bilan["ecart_max"], "; minimum des maxima", bilan["controle_negatif"]["min_des_maxima"])
print("lire :", {k: v for k, v in V.lire({"format": {"verifie": True}, "logique": {"equivalence": bilan}}, V.CONFIG_REELLE).items()
                 if k.startswith("logique")})
try:
    V.appliquer_gardes(sorties, "logique"); print("garde : passe")
except GardeArret as e:
    print("garde : arrêt —", str(e)[:120])
print("max([2e-7, nan, 3e-7]) =", max([2e-7, float('nan'), 3e-7]), "; max([nan, 2e-7]) =", max([float('nan'), 2e-7]))
