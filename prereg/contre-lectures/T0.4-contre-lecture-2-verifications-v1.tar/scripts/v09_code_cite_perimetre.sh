#!/usr/bin/env bash
# V09 : périmètre de la garde « code au commit cité » (exiger_code_cite, et exiger_rejeu_compatible) : src/ et tests/
# seulement. Dans une copie jetable : on modifie et committe le script d'instance, l'amorce et requirements-gpu.txt
# (torch changé), puis on appelle la garde avec un préenregistrement qui cite le commit d'origine.
set -euo pipefail
W="$1"; rm -rf "$W/v09"; git clone -q "$W/copie" "$W/v09"; cd "$W/v09"
C=$(git rev-parse HEAD)
printf -- '- Commit du code d'"'"'analyse : `%s`\n' "$C" > "$W/v09-prereg.md"
echo 'echo modifié' >> scripts/validation_t04_instance.sh
echo 'echo modifié' >> scripts/amorce_instance_t04.sh
sed -i 's/^torch==2.14.1/torch==2.15.0/' requirements-cpu.txt
git -c user.email=t@x.invalid -c user.name=t commit -qam "scripts et dépendances modifiés"
git diff --stat "$C" HEAD
. /home/user/controle-ia/.venv/bin/activate
PYTHONPATH=src python -c "
from pathlib import Path
from controle_ia.harnais.validation_reelle import exiger_code_cite
print('exiger_code_cite →', exiger_code_cite(Path('.'), Path('$W/v09-prereg.md')), ': passe malgré scripts et dépendances modifiés')
"
