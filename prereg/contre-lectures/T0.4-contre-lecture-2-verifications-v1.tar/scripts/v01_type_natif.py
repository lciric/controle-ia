"""V01 : la garde du type natif (charger_modele → type_natif(AutoConfig…)) sur une configuration au format de
Llama-3.1-8B-Instruct (clé « torch_dtype »: « bfloat16 »), avec transformers 5.18, hors ligne."""
import json, tempfile
from pathlib import Path
from transformers import AutoConfig
from controle_ia.harnais.modeles import type_natif

cfg = {"architectures": ["LlamaForCausalLM"], "model_type": "llama", "hidden_size": 64, "intermediate_size": 128,
       "num_attention_heads": 4, "num_hidden_layers": 2, "num_key_value_heads": 2, "vocab_size": 300,
       "rope_theta": 500000.0, "max_position_embeddings": 131072,
       "rope_scaling": {"factor": 8.0, "low_freq_factor": 1.0, "high_freq_factor": 4.0,
                        "original_max_position_embeddings": 8192, "rope_type": "llama3"},
       "bos_token_id": 128000, "eos_token_id": [128001, 128008, 128009], "tie_word_embeddings": False}
for cle, valeur in (("torch_dtype", "bfloat16"), ("dtype", "bfloat16"), ("torch_dtype", "float32"), (None, None)):
    d = Path(tempfile.mkdtemp())
    c = dict(cfg)
    if cle:
        c[cle] = valeur
    (d / "config.json").write_text(json.dumps(c))
    conf = AutoConfig.from_pretrained(d)
    print(f"config.json avec {cle}={valeur!r} : hasattr(dtype)={hasattr(conf, 'dtype')}, conf.dtype={getattr(conf, 'dtype', None)!r}, "
          f"type_natif → {type_natif(conf)!r}")
