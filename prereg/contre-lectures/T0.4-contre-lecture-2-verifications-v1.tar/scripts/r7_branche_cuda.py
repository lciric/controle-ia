"""Rejeu d'exp7 (contre-lecture 1) contre le code ad48125 : branche « cuda » de regler_determinisme simulée sur processeur
(fonctions de torch.cuda remplacées) ; réglages nouveaux (réduction en précision réduite bf16/fp16, pilote) ; artefact
CUBLAS_WORKSPACE_CONFIG=':0:0' refusé ; avertissements émis."""
import os, warnings
import torch
from controle_ia.gardes import GardeArret
from controle_ia.harnais import modeles as M

torch.cuda.is_available = lambda: True
torch.cuda.get_device_name = lambda i=0: "carte simulée"
torch.cuda.get_device_capability = lambda i=0: (8, 0)
torch.backends.cudnn.version = lambda: 91000
os.environ.pop("CUBLAS_WORKSPACE_CONFIG", None)
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter("always")
    r = M.regler_determinisme(1, "cuda")
print("réglages :", {k: v for k, v in r.items() if k not in ("torch", "numpy")})
print("drapeaux :", "tf32", torch.backends.cuda.matmul.allow_tf32, "; bf16 réduit", torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction,
      "; fp16 réduit", torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction)
print("avertissements :", [str(x.message)[:100] for x in w])
os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":0:0"
try:
    M.regler_determinisme(1, "cuda"); print("artefact :0:0 : PASSE (non détecté)")
except GardeArret as e:
    print("artefact :0:0 : arrêt :", e)
