"""V14 : réplication indépendante de la répétition jouet citée (run 20261004-121435-repetition-jouet, résumé scellé
5f2bcd30…) au commit ad48125, même entropie, sur cette machine : parties déterministes comparées (empreintes par
épisode, captures, profils, npz, poids, lecture, bilans hors durées)."""
import json, sys
a = json.load(open("diag/20261004-121435-repetition-jouet/resume.json"))["resultat"]
b = json.load(open("diag/20261004-235900-repetition-jouet/resume.json"))["resultat"]
diff = []
for ph in ("logique", "production"):
    for ea, eb in zip(a[ph]["episodes"], b[ph]["episodes"]):
        for k in ("empreintes",):
            if ea[k] != eb[k]: diff.append((ph, ea["episode"], k))
        for k in ("empreintes_capture", "profils", "controle_negatif_zone_generee", "ecarts"):
            if ea["equivalence"].get(k) != eb["equivalence"].get(k): diff.append((ph, ea["episode"], k))
        if ea.get("tableaux_sha256") != eb.get("tableaux_sha256"): diff.append((ph, ea["episode"], "npz"))
    for k in ("couverture", "zeros", "controle_negatif", "ecart_max"):
        if a[ph]["equivalence"][k] != b[ph]["equivalence"][k]: diff.append((ph, "bilan", k))
for k in ("empreinte_poids", "repere_precision", "rejeu_en_processus"):
    if a["production"][k] != b["production"][k]: diff.append(("production", k))
if a["lecture"] != b["lecture"]: diff.append(("lecture",))
print("différences avec le résumé scellé de l'auteur :", diff or "aucune")
