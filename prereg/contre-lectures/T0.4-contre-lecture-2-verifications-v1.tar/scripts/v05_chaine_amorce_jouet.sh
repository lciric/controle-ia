#!/usr/bin/env bash
# V05 : chaîne amorce → script d'instance en mode jouet, contre un dépôt nu de l'espace de travail (aucune poussée vers
# le dépôt du programme). Usage : bash v05_chaine_amorce_jouet.sh <espace de travail contenant copie/>
set -u
W="$1"; rm -rf "$W/v05"; mkdir -p "$W/v05"; cd "$W/v05"
git clone -q --bare "$W/copie" depot.git
COMMIT=$(git -C depot.git rev-parse HEAD); echo "COMMIT=$COMMIT"
cp "$W/copie/scripts/amorce_instance_t04.sh" amorce.sh; sha256sum amorce.sh
env COMMIT="$COMMIT" GH_TOKEN=factice HF_TOKEN=factice DEPOT_URL="file://$W/v05/depot.git" RACINE_AMORCE="$W/v05" \
    MODE=jouet VENV_EXISTANT=/home/user/controle-ia/.venv bash amorce.sh > amorce.log 2>&1
echo "code amorce : $?"; tail -40 amorce.log
