"""V12 : métadonnées publiques du dépôt du modèle à la révision citée (aucun fichier téléchargé) : ce que lira
empreintes_fichiers_modele (rfilename, lfs.sha256, blob_id) ; date de dernière modification ; branche principale."""
from huggingface_hub import HfApi
rev = "0e9e39f249a16976918f6564b8830bc894c89659"
info = HfApi().model_info("meta-llama/Llama-3.1-8B-Instruct", revision=rev, files_metadata=True)
print("sha :", info.sha)
for x in info.siblings:
    print(f"  {x.rfilename:45s} lfs={'oui sha256=' + x.lfs.sha256[:16] + '…' if x.lfs else 'non'} blob_id={str(x.blob_id)[:12]} taille={x.size}")
i = HfApi().model_info("meta-llama/Llama-3.1-8B-Instruct", revision=rev)
j = HfApi().model_info("meta-llama/Llama-3.1-8B-Instruct")
print("révision citée : sha", i.sha, "; last_modified", i.last_modified)
print("branche principale aujourd hui : sha", j.sha, "; last_modified", j.last_modified)
