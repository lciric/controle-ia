#!/usr/bin/env bash
# Rejeu tel quel d'exp2, exp11 et exp13 de la contre-lecture 1 (chemins de relecture inchangés) contre ad48125.
W="$1"; cd "$W/copie" && . /home/user/controle-ia/.venv/bin/activate
for e in exp2_arrets_precoces exp11_lignes_non_initiales exp13_npz_horodatage; do
  echo "== $e"; PYTHONPATH=src python "$W/cl1/scripts/$e.py" 2>&1 | grep -v "^\[transformers\]" | tail -8
done
