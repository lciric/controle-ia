"""Rejeu d'exp4 (contre-lecture 1) contre le code ad48125. Exp. 4 : la « limite de durée » n'est vérifiée qu'aux frontières de phase. Mini-dépôt jetable ;
configuration de répétition jouet avec une phase de logique allongée et une limite de 1 s."""
import json, subprocess, tempfile, time
from pathlib import Path
from controle_ia.gardes import GardeArret
from controle_ia.harnais import validation_reelle as V

d = Path(tempfile.mkdtemp())
for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"]):
    subprocess.run(["git", "-C", str(d), *a], check=True)
(d / "README").write_text("x\n"); (d / ".gitignore").write_text("donnees/\n")
subprocess.run(["git", "-C", str(d), "add", "-A"], check=True); subprocess.run(["git", "-C", str(d), "commit", "-qm", "i"], check=True)
cfg = dict(V.CONFIG_REPETITION, logique=dict(V.CONFIG_REPETITION["logique"], episodes=4, T=4, max_nouveaux=64), limite_s=4)
t0 = time.perf_counter()
try:
    V.executer(d, "20261004-200000-repetition-jouet", entropie=3, config=cfg, verifier_import=False)
except GardeArret as e:
    duree = time.perf_counter() - t0
    arret = json.loads((d / "diag/20261004-200000-repetition-jouet/arret.json").read_text())["resultat"]
    print(f"limite_s = 4 ; arrêt après {duree:.1f} s, phase consignée « {arret['phase']} » ; motif : {arret['motif']}")
    print("phase de logique terminée malgré le dépassement :", "logique" in arret["partiel"], "; lecture partielle :", {k: v for k, v in arret["partiel"]["lecture_partielle"].items() if v != "non atteint"})
