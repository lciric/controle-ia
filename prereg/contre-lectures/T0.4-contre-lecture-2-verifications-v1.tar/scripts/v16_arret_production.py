"""V16 : arrêt pendant la production avant les gardes d'équivalence de fin de phase. Artefact P8 : la relecture du
disque échoue pour l'épisode 1 (garde levée dans la boucle d'écriture). arret.json contient-il les profils de la
production (écarts, contrôle négatif) ? Configuration de répétition jouet, dépôt jetable."""
import json, subprocess, tempfile
from pathlib import Path
from controle_ia.gardes import GardeArret
from controle_ia.harnais import politique as P
from controle_ia.harnais import validation_reelle as V

d = Path(tempfile.mkdtemp())
for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"]):
    subprocess.run(["git", "-C", str(d), *a], check=True)
(d / "README").write_text("x\n"); (d / ".gitignore").write_text("donnees/\n")
subprocess.run(["git", "-C", str(d), "add", "-A"], check=True); subprocess.run(["git", "-C", str(d), "commit", "-qm", "i"], check=True)
vrai = P.relire_et_controler
def relecture(npz, pol, ep, *a, **k):
    if ep.identifiant == "episode-1":
        raise GardeArret("episode-1, activations par jeton relues : calcul en ligne ≠ recalcul hors ligne (artefact)")
    return vrai(npz, pol, ep, *a, **k)
P.relire_et_controler = relecture
try:
    V.executer(d, "20261004-233000-repetition-jouet", entropie=12345, config=V.CONFIG_REPETITION, verifier_import=False)
except GardeArret as e:
    print("arrêt :", str(e)[:90])
finally:
    P.relire_et_controler = vrai
a = json.loads((d / "diag/20261004-233000-repetition-jouet/arret.json").read_text())["resultat"]
print("phase :", a["phase"], "; clés du résumé partiel :", sorted(a["partiel"]))
print("profils de production dans arret.json :", "production" in a["partiel"])
print("lecture partielle (production) :", {k: v for k, v in a["partiel"]["lecture_partielle"].items() if k.startswith("production")})
