"""V15 : garde de la date d'en-tête (format_du_modele, « texte_attendu_ouverture »), absente de la suite de tests.
Gabarit jouet avec en-tête daté : (a) gabarit qui lit date_string (cas sain) ; (b) gabarit qui l'ignore et prend la
date du jour (artefact) ; (c) configuration de répétition (texte attendu None : garde jamais exercée)."""
from controle_ia.gardes import GardeArret
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais.modeles import modele_jouet, tokeniseur_caracteres_chat

LIT = ("{% if not date_string is defined %}{% set date_string = strftime_now('%d %b %Y') %}{% endif %}"
       "<|im_start|>system\nToday Date: {{ date_string }}\n{{ messages[0]['content'] }}<|im_end|>\n"
       "{% for m in messages[1:] %}<|im_start|>{{ m['role'] }}\n{{ m['content'] }}<|im_end|>\n{% endfor %}"
       "{% if add_generation_prompt %}<|im_start|>assistant\n{% endif %}")
IGNORE = LIT.replace("{{ date_string }}", "{{ strftime_now('%d %b %Y') }}")
cfg = dict(V.CONFIG_REPETITION, format=dict(V.CONFIG_REELLE["format"]))      # texte attendu « Today Date: 26 Jul 2024 »
for nom, gabarit in (("gabarit qui lit date_string", LIT), ("gabarit qui l'ignore (artefact)", IGNORE)):
    tok = tokeniseur_caracteres_chat(); tok.chat_template = gabarit
    m = modele_jouet(1, len(tok), couches=2, largeur=32, tetes=4, tetes_cle_valeur=2, intermediaire=64)
    try:
        fmt, d = V.format_du_modele(m, tok, cfg)
        print(f"{nom} : garde passe ; ouverture « {d['ouverture'].splitlines()[1]} »")
    except GardeArret as e:
        print(f"{nom} : arrêt — {e}")
print("configuration de répétition : texte attendu =", V.CONFIG_REPETITION["format"]["texte_attendu_ouverture"])
