#!/usr/bin/env bash
# V07 : MemTotal (/proc/meminfo) contre la limite du cgroup, dans cet environnement ; garde exiger_memoire_vive(64).
grep MemTotal /proc/meminfo
for f in /sys/fs/cgroup/memory.max /sys/fs/cgroup/memory/memory.limit_in_bytes; do [ -r $f ] && echo "$f : $(cat $f)"; done
cd "$1/copie" && . /home/user/controle-ia/.venv/bin/activate && PYTHONPATH=src python -c "
from controle_ia.harnais.validation_reelle import exiger_memoire_vive
try: print(exiger_memoire_vive(64))
except Exception as e: print('arrêt :', e)"
