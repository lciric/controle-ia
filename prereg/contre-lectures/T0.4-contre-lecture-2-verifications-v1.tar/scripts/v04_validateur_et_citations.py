"""V04 : (a) le validateur de préenregistrement (prereg.problemes / sceller_prereg) sur le brouillon 2 tel quel, dont la
section « Contre-lecture » annonce la contre-lecture 2 « à faire » ; (b) citations lues par le lanceur (commit, révision,
entropie) et par le script d'instance (sed) sur le même texte. Copie temporaire ; rien n'est scellé dans le dépôt."""
import re, shutil, subprocess, tempfile, sys
from pathlib import Path
from controle_ia.prereg import problemes, sections, EMPREINTE
from controle_ia.harnais.validation_reelle import COMMIT_CITE, REVISION_CITEE, ENTROPIE_CITEE

src = Path(sys.argv[1])
d = Path(tempfile.mkdtemp()); p = d / "T0.4-validation-modele-reel-v1.md"; shutil.copy(src, p)
print("problemes() sur le brouillon 2 :", problemes(p))
cl = sections(p.read_text(encoding="utf-8"))["Contre-lecture"]
print("empreintes distinctes dans « Contre-lecture » :", len(set(EMPREINTE.findall(cl))), "; « À REMPLIR » présent :", "À REMPLIR" in cl,
      "; « à faire » présent :", "à faire" in cl)
t = p.read_text(encoding="utf-8")
print("commit cité :", COMMIT_CITE.search(t).group(1), "; révision citée :", REVISION_CITEE.search(t).group(1),
      "; entropie citée :", ENTROPIE_CITEE.search(t).group(1))
print("occurrences : commit", len(COMMIT_CITE.findall(t)), "révision", len(REVISION_CITEE.findall(t)), "entropie", len(ENTROPIE_CITEE.findall(t)))
r = subprocess.run(["bash", "-c", "sed -n 's/.*Révision du modèle : `\\([0-9a-f]\\{40\\}\\)`.*/\\1/p' \"$1\" | head -1", "_", str(p)],
                   capture_output=True, text=True)
print("révision lue par le sed du script d'instance :", r.stdout.strip() or "(rien)", r.stderr.strip())
