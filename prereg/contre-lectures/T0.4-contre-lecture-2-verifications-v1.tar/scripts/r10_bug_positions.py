"""Rejeu d'exp10 (contre-lecture 1) contre le code ad48125, de bout en bout par V.executer (configuration de
répétition jouet, dépôt jetable) : défaut plausible injecté (positions des jetons décodés décalées de +1).
Vérifie : arrêt en fin de phase de logique (gardes différées), toutes les fautes nommées, arret.json avec les profils
complets, lecture partielle ; profils par zone (contexte / zone générée) ; bande de la table de lecture où tombe
l'écart maximal. Puis la phase de production seule avec le même défaut (seuil 0,1)."""
import inspect, json, subprocess, tempfile, textwrap
from pathlib import Path
from controle_ia.gardes import GardeArret
from controle_ia.harnais import episode as E
from controle_ia.harnais import validation_reelle as V

def depot():
    d = Path(tempfile.mkdtemp())
    for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"]):
        subprocess.run(["git", "-C", str(d), *a], check=True)
    (d / "README").write_text("x\n")
    subprocess.run(["git", "-C", str(d), "add", "-A"], check=True)
    subprocess.run(["git", "-C", str(d), "commit", "-qm", "init"], check=True)
    return d

code = inspect.getsource(E.generer_lot).replace("suivante = positions[:, -1:] + 1", "suivante = positions[:, -1:] + 2")
assert "+ 2" in code
espace = dict(E.__dict__); exec(textwrap.dedent(code), espace)
vrai = E.generer_lot
E.generer_lot = espace["generer_lot"]
d = depot()
try:
    V.executer(d, "20261004-200000-repetition-jouet", entropie=12345, config=V.CONFIG_REPETITION, verifier_import=False)
    print("défaut NON détecté")
except GardeArret as e:
    print("arrêt :", str(e)[:160], "…")
finally:
    E.generer_lot = vrai
a = json.loads((d / "diag" / "20261004-200000-repetition-jouet" / "arret.json").read_text())["resultat"]
print("phase :", a["phase"], "; lecture partielle :", a["partiel"]["lecture_partielle"])
b = a["partiel"]["logique"]["equivalence"]
print("écart maximal :", f"{b['ecart_max']:.3g}", "; contrôle négatif :", b["controle_negatif"], "; couverture :", b["couverture"])
ctx = max(p["contexte"]["max"] for e in a["partiel"]["logique"]["episodes"] for d_ in e["equivalence"]["profils"].values()
          for p in d_.values() if p["contexte"].get("jetons"))
gen = max(p["generee"]["max"] for e in a["partiel"]["logique"]["episodes"] for d_ in e["equivalence"]["profils"].values()
          for p in d_.values() if p["generee"].get("jetons"))
print(f"maximum par zone : contexte {ctx:.3g} ; zone générée {gen:.3g}")
bande = ("> 1e-2 : « logique du harnais non validée »" if b["ecart_max"] > 1e-2 else
         "]1e-4, 1e-2] : « non concluant : précision probable (noyau, réglage), pas logique »" if b["ecart_max"] > 1e-4 else "≤ 1e-4")
print("ligne de la table de lecture gelée :", bande)
fautes = str(a["motif"]).count("activations de génération")
print("fautes d'équivalence nommées dans le motif :", fautes, "; actions comparées :", b["actions_comparees"])
# production seule, même défaut, seuil 0,1
E.generer_lot = espace["generer_lot"]
try:
    import numpy as np
    from controle_ia.manifeste import graines as G
    from controle_ia.harnais.activations import couches_par_defaut
    cfg = V.CONFIG_REPETITION; c = cfg["production"]
    V.regler_determinisme(1, "cpu")
    gr = G(V.taches(cfg), entropie=12345)
    m, tok = V.charger(cfg, None, c["dtype"], gr)
    fmt, _ = V.format_du_modele(m, tok, cfg)
    sorties, plan = V.jouer_phase(m, fmt, c, gr, "production", couches_par_defaut(m.config.num_hidden_layers))
    bp = V.bilan_phase(sorties, plan, {}, c)
    try:
        V.appliquer_gardes(sorties, "production"); vu = "NON détecté"
    except GardeArret:
        vu = "détecté"
    print(f"production (bfloat16, 0,1) : écart maximal {bp['ecart_max']:.3g} → défaut {vu}")
finally:
    E.generer_lot = vrai
