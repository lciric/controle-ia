"""V04b : le validateur durci (deux empreintes dans « Contre-lecture ») n'invalide pas le préenregistrement déjà scellé
de T0.3 (aucune régression) ; le gabarit reste refusé."""
from pathlib import Path
from controle_ia.prereg import problemes
for p in sorted(Path("prereg").glob("*.md")):
    print(p.name, "→", problemes(p))
