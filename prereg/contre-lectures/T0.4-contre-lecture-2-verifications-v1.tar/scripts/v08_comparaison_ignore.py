"""V08 : ce que comparer_runs (P7) ne compare pas. Deux runs jouets identiques (rejeu), puis le résumé de B est altéré
à la relecture (monkeypatch de verifier_resultat, comme le test du dépôt) sur des champs hors comparaison :
carte et pilote (réglages), implémentation d'attention et type des poids (chargement), repère de précision,
empreinte du gabarit et ouverture, sortie des tests de l'instance, couverture de la logique."""
import json, subprocess, tempfile
from pathlib import Path
from controle_ia.harnais import validation_reelle as V

def git(d, *a):
    subprocess.run(["git", "-C", str(d), *a], check=True, capture_output=True)
d = Path(tempfile.mkdtemp())
git(d, "init", "-q", "-b", "main"); git(d, "config", "user.email", "t@x.invalid"); git(d, "config", "user.name", "t")
(d / "README").write_text("x\n"); git(d, "add", "-A"); git(d, "commit", "-qm", "init")
PETITE = dict(V.CONFIG_REPETITION, logique=dict(V.CONFIG_REPETITION["logique"], T=2, max_nouveaux=8),
              production=dict(V.CONFIG_REPETITION["production"], episodes=4, T=2, max_nouveaux=8),
              debit={"tailles_lot": [1, 4], "longueur_contexte": 32, "max_nouveaux": 4})
V.executer(d, "20261004-230000-repetition-jouet", entropie=77, config=PETITE, verifier_import=False)
git(d, "add", "-A"); git(d, "commit", "-qm", "A")
V.executer(d, "20261004-230100-repetition-jouet", config=PETITE, rejeu_de="20261004-230000-repetition-jouet", verifier_import=False)
git(d, "add", "-A"); git(d, "commit", "-qm", "B")
vrai = V.verifier_resultat
def altere(racine, chemin):
    corps = vrai(racine, chemin)
    if "230100" in str(chemin) and str(chemin).endswith("resume.json"):
        r = corps["resultat"]
        r["reglages"]["carte"] = "autre carte"; r["reglages"]["pilote"] = "999.99"
        r["chargement"]["attention"] = "eager"; r["chargement"]["type_des_poids"] = "torch.float16"
        r["production"]["repere_precision"]["0"]["max"] = 0.5
        r["format"]["gabarit_sha256"] = "f" * 64; r["format"]["ouverture"] = "autre ouverture"
        r["logique"]["equivalence"]["couverture"]["jetons_remplissage"] = 0
        r["logique"]["equivalence"]["zeros"]["generee"] = [1, 1]
    return corps
V.verifier_resultat = altere
try:
    # nom de comparaison neuf (R12) : on appelle la fonction de comparaison sur un troisième identifiant fictif n'est pas
    # possible ; on la rappelle donc en interceptant l'écriture
    import controle_ia.harnais.validation_reelle as M
    ecrit = {}
    vrai_ecrire = M.ecrire_resultat
    M.ecrire_resultat = lambda racine, man, nom, contenu: ecrit.setdefault(nom, contenu)
    c = V.comparer_runs(d, "20261004-230000-repetition-jouet", "20261004-230100-repetition-jouet")
finally:
    V.verifier_resultat = vrai
    M.ecrire_resultat = vrai_ecrire
print("comparaison après altération de champs hors comparaison :", {k: c[k] for k in ("identique", "lecture", "differences")})
