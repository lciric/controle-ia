"""Rejeu d'exp1b (contre-lecture 1) contre le code ad48125 : où tombe le maximum de l'écart décalé, ancienne
statistique (toutes positions) contre nouvelle (zone générée sans sa première position) ; positions de la zone
générée sous la tolérance ; minimum des maxima. Configuration de répétition jouet, entropie 12345, aucun fichier écrit."""
import numpy as np
from collections import Counter
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais import episode as E
from controle_ia.harnais.activations import couches_par_defaut, ecarts_par_jeton
from controle_ia.manifeste import graines as G

cfg = V.CONFIG_REPETITION
V.regler_determinisme(1, "cpu")
gr = G(V.taches(cfg), entropie=12345)
for phase in ("logique", "production"):
    c = cfg[phase]
    m, tok = V.charger(cfg, None, c["dtype"], gr)
    fmt, _ = V.format_du_modele(m, tok, cfg)
    couches = couches_par_defaut(m.config.num_hidden_layers)
    vrai = E.relire_crochets_lot
    sorties, plan = V.jouer_phase(m, fmt, c, gr, phase, couches)
    lieux_ancien, sous_tau, total, maxima, courtes = Counter(), 0, 0, [], 0
    for ep, acts, r in sorties:
        for cle, ag in r["profils"].items():
            pass
        for cle, lc in r["longueurs_contexte"].items():
            i = int(cle.split(",")[0])
            zone = r["controle_negatif_zone_generee"][cle]
            if zone is None:
                courtes += 1
                continue
            for couche, v in zone.items():
                maxima.append(v["max"]); sous_tau += v["positions"] - v["au_dessus"]; total += v["positions"]
    print(f"===== {phase} ({c['dtype']}), tolérance {c['tolerance']}")
    print(f"  nouvelle statistique : actions × couches = {len(maxima)}, actions trop courtes = {courtes}, "
          f"minimum des maxima = {min(maxima):.4g}")
    print(f"  positions de la zone générée (sauf la première) dont l'écart décalé reste ≤ tolérance : {sous_tau} / {total}")
    print(f"  bilan_phase : {V.bilan_phase(sorties, plan, {}, c)['controle_negatif']}")
    del m
