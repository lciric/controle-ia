"""Rejeu d'exp3 (contre-lecture 1) contre le code ad48125 : écriture où les positions hors des empans d'action sont
mises à zéro ou décalées ; relire_et_controler reçoit maintenant la mémoire (acts). Plus deux artefacts nouveaux :
une seule valeur altérée d'un bit (dans un empan, sans changer le maximum ni les scores), et un agent absent du disque."""
import tempfile
from pathlib import Path
import numpy as np, torch
from controle_ia.gardes import GardeArret
from controle_ia.harnais import episode as E, politique as P
from controle_ia.harnais.formats import FormatChat
from controle_ia.harnais.modeles import modele_jouet, regler_determinisme, tokeniseur_caracteres_chat
from controle_ia.harnais.sondes import sonde_lineaire_aleatoire

regler_determinisme(1)
tok = tokeniseur_caracteres_chat(); FIN = tok.convert_tokens_to_ids("<|im_end|>")
fmt = FormatChat(tok, fins={FIN, tok.eos_token_id})
m = modele_jouet(11, len(tok), couches=4, largeur=32, tetes=4, tetes_cle_valeur=2, intermediaire=64).to(torch.bfloat16)
g = [{(i, t): 300 + 10 * i + t for t in range(3) for i in range(2)}]
(ep, acts, _), = E.jouer_episodes(m, fmt, E.EnvironnementJouet(), ["e0"], 2, 3, g, [0, 1, 2], max_nouveaux=12)
pol = {"episodes_par_jeton": [0], "vecteurs_par_action": ["max"], "sondes": []}
sondes = [sonde_lineaire_aleatoire(f"s{c}{a}", c, 32, a, np.random.default_rng(c * 7 + len(a))) for c in (0, 1, 2) for a in ("max", "attention")]
v, s = P.calculer_en_ligne(pol, ep, acts, [0, 1, 2], sondes)

def un_bit_dans_un_empan(a, hors):
    b = a.copy(); u = b.view(np.uint32)
    n = int(np.where(~hors)[0][0]); j = int(np.argmin(b[n]))          # valeur minimale de la colonne : le maximum ne bouge pas
    u[n, j] ^= np.uint32(1 << 16)                                      # un bit de la mantisse bfloat16
    return b
artefacts = (("contexte mis à zéro", lambda a, hors: np.where(hors[:, None], 0.0, a).astype(np.float32)),
             ("contexte décalé d'un jeton", lambda a, hors: np.where(hors[:, None], np.roll(a, 1, axis=0), a).astype(np.float32)),
             ("un bit d'une valeur non maximale dans un empan", un_bit_dans_un_empan))
for nom, transformer in artefacts:
    faux, hors_total = {}, 0
    for tr in ep.transcriptions:
        hors = np.ones(len(tr.ids), bool)
        for a in tr.actions:
            hors[a.debut:a.fin] = False
        hors_total += int(hors.sum())
        faux[tr.agent] = {c: (transformer(x, hors) if c == 0 or nom.startswith("contexte") else x.copy())
                          for c, x in acts[tr.agent].items()}
    d = Path(tempfile.mkdtemp())
    npz = P.ecrire_tableaux(d / "e0.npz", faux, v, s, "bfloat16-bits")
    v2, s2 = P.calculer_en_ligne(pol, ep, faux, [0, 1, 2], sondes)
    memes = all(np.array_equal(v[k], v2[k]) for k in v) and all(np.array_equal(s[k], s2[k]) for k in s)
    try:
        P.relire_et_controler(npz, pol, ep, [0, 1, 2], sondes, v, s, True, "bfloat16-bits", acts)
        verdict = "PASSE (non détecté)"
    except GardeArret as e:
        verdict = f"arrêt : {str(e)[:90]}"
    print(f"artefact « {nom} » : vecteurs et scores inchangés ? {memes} ; relire_et_controler → {verdict}")
# agent manquant sur le disque
faux = {0: acts[0]}
npz = P.ecrire_tableaux(Path(tempfile.mkdtemp()) / "e0.npz", faux, v, s, "bfloat16-bits")
try:
    P.relire_et_controler(npz, pol, ep, [0, 1, 2], sondes, v, s, True, "bfloat16-bits", acts)
    print("artefact « agent 1 absent du disque » : PASSE (non détecté)")
except GardeArret as e:
    print(f"artefact « agent 1 absent du disque » : arrêt : {str(e)[:90]}")
