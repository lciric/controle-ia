"""Rejeu d'exp8 (contre-lecture 1) contre le code ad48125 : run B lancé avec --rejeu-de mais une autre révision ;
puis run B lancé sur un run A arrêté (arret.json, sans résumé) : calcul fait ou refusé avant ?"""
import subprocess, tempfile, time
from pathlib import Path
from controle_ia.gardes import GardeArret
from controle_ia.harnais import validation_reelle as V

d = Path(tempfile.mkdtemp())
for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"]):
    subprocess.run(["git", "-C", str(d), *a], check=True)
(d / "README").write_text("x\n"); (d / ".gitignore").write_text("donnees/\n")
git = lambda: (subprocess.run(["git", "-C", str(d), "add", "-A"], check=True), subprocess.run(["git", "-C", str(d), "commit", "-qm", "e"], check=True))
git()
cfg = V.CONFIG_REPETITION
V.executer(d, "20261004-210000-repetition-jouet", revision="a" * 40, entropie=9, config=cfg, verifier_import=False)
git()
t0 = time.perf_counter()
try:
    V.executer(d, "20261004-210100-repetition-jouet", revision="b" * 40, config=cfg,
               rejeu_de="20261004-210000-repetition-jouet", verifier_import=False)
except GardeArret as e:
    print(f"run B (autre révision) : arrêt après {time.perf_counter() - t0:.2f} s : {e}")
print("run B créé ?", (d / "runs/20261004-210100-repetition-jouet").exists())
# run A arrêté (limite de durée), puis run B en rejeu de ce run
court = dict(cfg, limite_s=-1)
try:
    V.executer(d, "20261004-210200-repetition-jouet", entropie=9, config=court, verifier_import=False)
except GardeArret as e:
    print("run A' arrêté :", str(e)[:60])
git()
t0 = time.perf_counter()
try:
    V.executer(d, "20261004-210300-repetition-jouet", config=court, rejeu_de="20261004-210200-repetition-jouet", verifier_import=False)
except Exception as e:
    print(f"run B' (rejeu d'un run arrêté) : {type(e).__name__} après {time.perf_counter() - t0:.2f} s : {str(e)[:100]}")
print("fichiers de diag de B' :", sorted(p.name for p in (d / "diag/20261004-210300-repetition-jouet").iterdir() if p.suffix == ".json"))
