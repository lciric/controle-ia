"""V11 : couverture de P2 (lire) mesurée sur tout le lot, pas sur les lignes comparées. Répétition jouet (logique), entropie
12345 : pour chaque action comparée, remplissage de SA ligne et fin anticipée de SA ligne ; puis contre-exemple construit :
échantillon sur une ligne jamais remplie ni finie avant les autres, couverture du lot pourtant « satisfaite »."""
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais import episode as E
from controle_ia.harnais.activations import couches_par_defaut
from controle_ia.manifeste import graines as G

cfg = V.CONFIG_REPETITION
V.regler_determinisme(1, "cpu")
gr = G(V.taches(cfg), entropie=12345)
c = cfg["logique"]
m, tok = V.charger(cfg, None, c["dtype"], gr)
fmt, _ = V.format_du_modele(m, tok, cfg)
couches = couches_par_defaut(m.config.num_hidden_layers)
vrai = E.generer_lot
appels = []
def espion(modele, contextes, *a, **k):
    nv, plan = vrai(modele, contextes, *a, **k)
    appels.append((plan["remplissage"], [len(x) for x in nv], plan["passes_decodage"]))
    return nv, plan
def jouer(c_):
    appels.clear()
    E.generer_lot = espion
    try:
        chrono = {}
        sorties, plan = V.jouer_phase(m, fmt, c_, gr, "logique", couches, chrono=chrono)
    finally:
        E.generer_lot = vrai
    return sorties, plan, chrono
for ech in ([1, 2], None):
    c_ = dict(c, episodes_equivalence=ech) if ech else c
    sorties, plan, chrono = jouer(c_)
    lot = plan[0]
    if ech is None:
        # contre-exemple : la ligne la plus longue à chaque appel (jamais remplie, jamais finie avant) existe-t-elle ?
        jamais = [b for b in range(len(lot)) if all(r[b] == 0 and n[b] == max(n) for r, n, _ in appels)]
        print("lignes jamais remplies ni finies avant les autres :", jamais)
        if not jamais:
            jamais = [min(range(len(lot)), key=lambda b: sum(r[b] > 0 or n[b] < max(n) for r, n, _ in appels))]
        c_ = dict(c, episodes_equivalence=[lot[jamais[0]]])
        sorties, plan, chrono = jouer(c_)
    comp = [lot.index(k) for k in c_["episodes_equivalence"]]
    par_ligne = {b: {"actions": len(appels), "remplie": sum(r[b] > 0 for r, _, _ in appels),
                     "finie_avant": sum(n[b] < max(n) for _, n, _ in appels)} for b in comp}
    bilan = V.bilan_phase(sorties, plan, chrono, c_)
    lecture = V.lire({"format": {"verifie": True}, "logique": {"equivalence": bilan}}, cfg)["logique_equivalence"]
    print(f"échantillon {c_['episodes_equivalence']} (lignes {comp}) : couverture du lot {bilan['couverture']} ; "
          f"par ligne comparée {par_ligne} ; lecture P2 : {lecture}")
