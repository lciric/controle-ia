#!/usr/bin/env bash
# v15 (R4) : réplication indépendante de la répétition jouet citée par le brouillon 6 (run 20261004-155447-repetition-jouet,
# résumé 6af77a2b…, commit 3a7b5e0), même entropie, sur une copie jetable du HEAD relu (arbre gelé identique au commit
# cité) ; puis `comparer_runs` (A = run cité, B = réplication) et comparaison des bilans d'équivalence.
# Usage : bash v15_replication_repetition.sh <espace>   (copie-head/ = clone du dépôt au HEAD relu ; sortie des tests de v01)
set -u
ESP=$1; D=$ESP/copie-v15
[ -e "$D" ] && { echo "$D existe (R12)"; exit 2; }
git clone -q --no-hardlinks "$ESP/copie-head" "$D"; cd "$D" || exit 1
git config user.email t@x.invalid; git config user.name t; git config commit.gpgsign false
echo "HEAD $(git rev-parse --short HEAD) ; diff de l'arbre gelé avec 3a7b5e0 : [$(git diff --stat 3a7b5e0523864f386c7ef528b663dbae83e046dd HEAD -- . ':(exclude)prereg' ':(exclude)brouillons' ':(exclude)registres' ':(exclude)docs' ':(exclude)diag' ':(exclude)runs' ':(exclude)donnees' ':(exclude)livrables' ':(exclude)papiers' ':(exclude)traces' ':(exclude)CLAUDE.md')]"
export PYTHONDONTWRITEBYTECODE=1
. /home/user/controle-ia/.venv/bin/activate
A=20261004-155447-repetition-jouet
E=$(python -c "import json;m=json.load(open('runs/$A/manifeste.json'));print(next(iter(m['graines'].values()))['entropie'])")
echo "entropie du run cité : $E"
B=20261004-235959-repetition-jouet
PYTHONPATH=src python -m controle_ia.harnais.validation_reelle --repetition-jouet --entropie "$E" --run-id "$B" \
    --sortie-tests "$ESP/scripts/sorties/v01_suite_tests.stdout.txt" > /dev/null
git add -A runs diag >/dev/null; git commit -qm "v15" >/dev/null
PYTHONPATH=src python - "$A" "$B" <<'PY'
import json, sys
from controle_ia.harnais import validation_reelle as V
A, B = sys.argv[1:]
c = V.comparer_runs(".", A, B)
print("comparer_runs (A = run cité, B = réplication) :", c["identique"], c["lecture"], c["differences"])
a = json.load(open(f"diag/{A}/resume.json"))["resultat"]
b = json.load(open(f"diag/{B}/resume.json"))["resultat"]
diff = [(ph, k) for ph in ("logique", "production") for k in a[ph]["equivalence"] if a[ph]["equivalence"][k] != b[ph]["equivalence"][k]]
print("bilans d'équivalence différents :", diff or "aucun")
print("lecture de la réplication :", b["lecture"])
PY
cd "$ESP" && rm -rf "$D"
