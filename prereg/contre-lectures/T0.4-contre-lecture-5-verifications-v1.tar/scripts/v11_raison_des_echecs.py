"""v11 (Q-2) : les quatre tests nouveaux échouent-ils pour la bonne raison ? Pour chacune des cinq mutations survivantes de
la contre-lecture 4 (et pour le refus de P0 déplacé après le manifeste), le test ciblé seul, au commit 3a7b5e0, avec
les lignes « E » de pytest (assertion fautive et valeurs). Témoin : le même test sans mutation.
Usage : python v11_raison_des_echecs.py <espace>   (interpréteur de /home/user/controle-ia/.venv)"""
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

esp = Path(sys.argv[1])
PY = "/home/user/controle-ia/.venv/bin/python"
VR = "src/controle_ia/harnais/validation_reelle.py"
T = "tests/test_validation_reelle.py::"
P0_AVANT = ('    if decisif and not tests_conformes(tests, config.get("tests_attendus")):\n'
            '        raise GardeArret(f"P0 : la sortie des tests de l\'instance ne finit pas par exactement {config.get(\'tests_attendus\')} "\n'
            '                         "tests réussis : aucun run")\n')
CAS = [
    ("rapport « diffus » remis à 10", T + "test_lecture_couverture_controle_negatif_audit_et_nan",
     [(VR, "max(mc, mg) <= 3 * min(mc, mg)", "max(mc, mg) <= 10 * min(mc, mg)")]),
    ("refus de P0 avant le manifeste supprimé", T + "test_p0_refus_avant_le_manifeste_en_mode_decisif",
     [(VR, "    if decisif and not tests_conformes(tests, config.get(\"tests_attendus\")):\n",
       "    if False and decisif and not tests_conformes(tests, config.get(\"tests_attendus\")):\n")]),
    ("refus de P0 déplacé après la création du manifeste", T + "test_p0_refus_avant_le_manifeste_en_mode_decisif",
     [(VR, P0_AVANT, ""), (VR, '    donnees = racine / "donnees" / run_id\n',
                           '    if decisif and not tests_conformes(tests, config.get("tests_attendus")):\n'
                           '        raise GardeArret("P0 : sortie non conforme : aucun run")\n'
                           '    donnees = racine / "donnees" / run_id\n')]),
    ("champ « reussis » remis à l'ancienne règle", T + "test_sortie_des_tests_scellee_et_lue",
     [(VR, '"reussis": tests_conformes(tests, config.get("tests_attendus"))}',
       '"reussis": bool(re.search(r"\\d+ passed", derniere)) and not re.search(r"failed|error", derniere)}')]),
    ("premier plafond lu au lieu du minimum", T + "test_plafonds_v2_et_minimum_des_ancetres",
     [(VR, "            plafond = int(v) / 1e9 if plafond is None else min(plafond, int(v) / 1e9)",
       "            plafond = int(v) / 1e9 if plafond is None else plafond")]),
    ("plafond v2 ignoré", T + "test_plafonds_v2_et_minimum_des_ancetres", [(VR, '        if controleurs == "":', '        if False:')]),
]

for nom, test, patchs in [("témoin (aucune mutation)", T + "test_p0_refus_avant_le_manifeste_en_mode_decisif " + T
                           + "test_plafonds_v2_et_minimum_des_ancetres " + T + "test_sortie_des_tests_scellee_et_lue " + T
                           + "test_lecture_couverture_controle_negatif_audit_et_nan", [])] + CAS:
    t = Path(tempfile.mkdtemp(dir=esp))
    copie = t / "c"
    shutil.copytree(esp / "copie", copie, ignore=shutil.ignore_patterns(".git", "donnees", "__pycache__"))
    for fichier, avant, apres in patchs:
        f = copie / fichier
        s = f.read_text(encoding="utf-8")
        assert avant in s, (nom, avant[:60])
        f.write_text(s.replace(avant, apres, 1), encoding="utf-8")
    env = dict(os.environ, PYTHONPATH="src", PYTHONDONTWRITEBYTECODE="1")
    r = subprocess.run([PY, "-m", "pytest", "-q", "-p", "no:cacheprovider", "--no-header", "--tb=short", *test.split()],
                       cwd=copie, env=env, capture_output=True, text=True)
    lignes = r.stdout.splitlines()
    print(f"== {nom} : {lignes[-1] if lignes else ''}")
    vues = [l for l in lignes if re.match(r"^(E |tests/test_validation_reelle\.py:\d+: )", l)]
    for l in vues[:8]:
        print("   ", l[:220])
    shutil.rmtree(t)
