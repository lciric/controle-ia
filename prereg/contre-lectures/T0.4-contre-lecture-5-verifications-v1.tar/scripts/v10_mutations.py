"""v10 : mutations du code au commit 3a7b5e0, une à la fois, sur une copie jetable ; pour chacune, la suite entière
(python -m pytest -q -p no:cacheprovider -x). Une mutation « survivante » (178 passed) = défaut que la suite ne voit pas.
Partie A : les quinze mutations de s10 (contre-lecture 4), motifs adaptés au commit cité ; les cinq survivantes de la
contre-lecture 4 doivent être vues. Partie B : sondes nouvelles autour du différentiel et des gardes que le brouillon 6
dit éprouvées (P0, plafonds, règle « diffus », arbre gelé, rejeu, comparaison).
Usage : python v10_mutations.py <espace> [travailleurs, défaut 3]   (interpréteur de /home/user/controle-ia/.venv)"""
import os
import shutil
import subprocess
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

esp = Path(sys.argv[1])
TRAVAILLEURS = int(sys.argv[2]) if len(sys.argv) > 2 else 3
PY = "/home/user/controle-ia/.venv/bin/python"
VR = "src/controle_ia/harnais/validation_reelle.py"
EP = "src/controle_ia/harnais/episode.py"
PR = "src/controle_ia/prereg.py"

P0_AVANT = ('    if decisif and not tests_conformes(tests, config.get("tests_attendus")):\n'
            '        raise GardeArret(f"P0 : la sortie des tests de l\'instance ne finit pas par exactement {config.get(\'tests_attendus\')} "\n'
            '                         "tests réussis : aucun run")\n')

MUTATIONS = {
    "A0 témoin (aucune mutation, copie sans .git)": [],
    "A1 M-1 gardes de production juste après le bilan (ordre de 9aaf4a5)": [
        (VR, '                                "episodes_equivalence": {ep.identifiant: r for ep, _, r in sorties if r["ecarts"]}}\n',
         '                                "episodes_equivalence": {ep.identifiant: r for ep, _, r in sorties if r["ecarts"]}}\n'
         '        appliquer_gardes(sorties, resume["production"]["equivalence"], "production", cn)\n'),
        (VR, '        # au vu du repère (lecture gelée), et le run s\'arrête ensuite\n        appliquer_gardes(sorties, resume["production"]["equivalence"], "production", cn)\n',
         '        # au vu du repère (lecture gelée), et le run s\'arrête ensuite\n')],
    "A2 M-2 rapport « diffus » remis à 10 (survivante de la contre-lecture 4)": [
        (VR, "max(mc, mg) <= 3 * min(mc, mg)", "max(mc, mg) <= 10 * min(mc, mg)")],
    "A3 M-3 positions sans retrait du remplissage (défaut D2)": [
        (EP, "positions = (masque.cumsum(dim=1) - 1).clamp(min=0)", "positions = torch.arange(L).expand(B, L).clone()")],
    "A4 M-3 décalage constant de +7 sur toutes les positions": [
        (EP, "positions = (masque.cumsum(dim=1) - 1).clamp(min=0)", "positions = (masque.cumsum(dim=1) - 1).clamp(min=0) + 7")],
    "A5 M-4 refus de P0 avant le manifeste supprimé (survivante de la contre-lecture 4)": [
        (VR, "    if decisif and not tests_conformes(tests, config.get(\"tests_attendus\")):\n",
         "    if False and decisif and not tests_conformes(tests, config.get(\"tests_attendus\")):\n")],
    "A6 M-4 champ « reussis » remis à l'ancienne règle (survivante de la contre-lecture 4)": [
        (VR, '"reussis": tests_conformes(tests, config.get("tests_attendus"))}',
         '"reussis": bool(re.search(r"\\d+ passed", derniere)) and not re.search(r"failed|error", derniere)}')],
    "A7 M-5 chemins gelés de 9aaf4a5": [
        (VR, 'CHEMINS_GELES = (".", ":(exclude)prereg", ":(exclude)brouillons", ":(exclude)registres", ":(exclude)docs",\n'
             '                 ":(exclude)diag", ":(exclude)runs", ":(exclude)donnees", ":(exclude)livrables", ":(exclude)papiers",\n'
             '                 ":(exclude)traces", ":(exclude)CLAUDE.md")',
         'CHEMINS_GELES = ("src", "tests", "scripts", "requirements-cpu.txt", "requirements-gpu.txt", "pyproject.toml")')],
    "A8 M-5 chemins gelés sans « src » (exclusion ajoutée)": [
        (VR, '":(exclude)traces", ":(exclude)CLAUDE.md")', '":(exclude)traces", ":(exclude)CLAUDE.md", ":(exclude)src")')],
    "A9 M-6 règle par entrée supprimée (une seule règle sur la section)": [
        (PR, "            if len(set(EMPREINTE.findall(cl[e.start():fin]))) < 2:", "            if False:")],
    "A10 M-8 empreintes du rejeu non gardées": [
        (VR, '                              "empreintes": emp, "empreintes_logits": r["empreintes_logits"],\n'
             '                              "empreintes_capture": r["empreintes_capture"]})',
         '                              })')],
    "A11 M-10 NaN selon l'ordre des couches (code de 9aaf4a5)": [
        (EP, '            m = min(float("-inf") if v["max"] != v["max"] else v["max"] for v in zone.values())\n'
             '            minimum = min(minimum, m)',
         '            m = min(v["max"] for v in zone.values())\n'
             '            minimum = min(minimum, m) if m == m else float("-inf")')],
    "A12 M-10 échecs sans l'épisode": [(EP, "echecs.append(f\"{r.get('episode', '?')}:{cle}\")", "echecs.append(cle)")],
    "A13 M-11 plafond lu à la racine seulement": [
        (VR, "        for k in range(len(parties), -1, -1):", "        for k in range(0, -1, -1):")],
    "A14 M-11 premier plafond lu au lieu du minimum (survivante de la contre-lecture 4)": [
        (VR, "            plafond = int(v) / 1e9 if plafond is None else min(plafond, int(v) / 1e9)",
         "            plafond = int(v) / 1e9 if plafond is None else plafond")],
    "A15 M-11 plafond v2 ignoré (survivante de la contre-lecture 4)": [(VR, '        if controleurs == "":', '        if False:')],
    # ---- partie B : sondes nouvelles
    "B1 refus de P0 déplacé après la création du manifeste": [
        (VR, P0_AVANT, ""),
        (VR, '    donnees = racine / "donnees" / run_id\n',
         '    if decisif and not tests_conformes(tests, config.get("tests_attendus")):\n'
         '        raise GardeArret("P0 : sortie non conforme : aucun run")\n'
         '    donnees = racine / "donnees" / run_id\n')],
    "B2 P0 : expression sans ancre de fin": [
        (VR, r'TESTS_REUSSIS = re.compile(r"^(\d+) passed(, \d+ warnings?)? in [0-9.]+s( \(\d+:\d{2}:\d{2}\))?$")',
         r'TESTS_REUSSIS = re.compile(r"^(\d+) passed(, \d+ warnings?)? in [0-9.]+s( \(\d+:\d{2}:\d{2}\))?")')],
    "B3 P0 : première ligne lue au lieu de la dernière": [
        (VR, "    m = TESTS_REUSSIS.match(sortie.strip().splitlines()[-1])",
         "    m = TESTS_REUSSIS.match(sortie.strip().splitlines()[0])")],
    "B4 nombre de tests attendus 178 → 177": [
        (VR, '"tests_attendus": 178,', '"tests_attendus": 177,')],
    "B5 mémoire effective = MemTotal seul (plafonds ignorés)": [
        (VR, "    effective = min(total, plafond) if plafond is not None else total", "    effective = total")],
    "B6 plafond v1 : contrôleur « memory » seul (liste « cpu,memory » ignorée)": [
        (VR, '        elif "memory" in controleurs.split(","):', '        elif controleurs == "memory":')],
    "B7 règle « diffus » : plancher 1e-5 abaissé à 1e-6": [
        (VR, "and mc >= 1e-5 and mg >= 1e-5 and", "and mc >= 1e-6 and mg >= 1e-6 and")],
    "B8 chemins gelés sans « scripts » (exclusion ajoutée)": [
        (VR, '":(exclude)traces", ":(exclude)CLAUDE.md")', '":(exclude)traces", ":(exclude)CLAUDE.md", ":(exclude)scripts")')],
    "B9 rejeu : résumé du run A non vérifié": [
        (VR, '        verifier_resultat(racine, racine / "diag" / rejeu_de / "resume.json")\n', '        pass\n')],
    "B10 comparaison : réglages et carte non comparés": [
        (VR, '    for cle in ("reglages", "chargement", "format"):', '    for cle in ("chargement", "format"):')],
}


def un_essai(item):
    nom, patchs = item
    t = Path(tempfile.mkdtemp(dir=esp))
    copie = t / "c"
    shutil.copytree(esp / "copie", copie, ignore=shutil.ignore_patterns(".git", "donnees", "__pycache__"))
    for fichier, avant, apres in patchs:
        f = copie / fichier
        s = f.read_text(encoding="utf-8")
        if avant not in s:
            shutil.rmtree(t)
            return f"[{nom}] MOTIF INTROUVABLE dans {fichier} : mutation non appliquée"
        f.write_text(s.replace(avant, apres, 1), encoding="utf-8")
    env = dict(os.environ, PYTHONPATH="src", PYTHONDONTWRITEBYTECODE="1")
    r = subprocess.run([PY, "-m", "pytest", "-q", "-p", "no:cacheprovider", "-x", "--no-header", "-rf"], cwd=copie,
                       env=env, capture_output=True, text=True)
    derniere = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else ""
    echecs = [l for l in r.stdout.splitlines() if l.startswith("FAILED")]
    statut = ("témoin vert" if not patchs and r.returncode == 0 else "SURVIT (suite verte)" if r.returncode == 0 else "vue")
    shutil.rmtree(t)
    return f"[{nom}] {statut} : {derniere} {[e[:150] for e in echecs[:2]]}"


with ThreadPoolExecutor(TRAVAILLEURS) as ex:
    for ligne in ex.map(un_essai, MUTATIONS.items()):
        print(ligne, flush=True)
