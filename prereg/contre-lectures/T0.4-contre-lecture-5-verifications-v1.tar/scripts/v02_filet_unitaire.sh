#!/usr/bin/env bash
# v02 : filet de sortie (sur_sortie, piège EXIT) et ses interactions, sur les fonctions extraites TELLES QUELLES du
# script d'instance au commit cité (de `journal()` et de `pousser()` à `trap sur_sortie EXIT`), sous `set -euo pipefail`,
# dans un dépôt d'essai dont le distant est un dépôt nu local. Chaque cas ajoute quelques lignes après les fonctions.
# Le TERM « du plafond » est envoyé au groupe de processus du script (setsid ; identifiant de groupe, R10), comme le fait
# `timeout` à son groupe. Aucune commande réseau ; aucun jeton.
# Usage : bash v02_filet_unitaire.sh <espace>   (copie/ au commit 3a7b5e0)
set -u
ESP=$1
S=$ESP/copie/scripts/validation_t04_instance.sh
BASE=$(mktemp -d "$ESP/essais-v02-XXXX")
F=$BASE/fonctions.sh
{ sed -n '/^journal() {/p' "$S"; sed -n '/^pousser() {/,/^trap sur_sortie EXIT/p' "$S"; } > "$F"
echo "fonctions extraites de $(git -C "$ESP/copie" rev-parse --short HEAD) : $(grep -o '^[a-z_]*()' "$F" | tr '\n' ' ')"
echo "pièges : $(grep -c '^trap ' "$F") ($(grep '^trap ' "$F" | tr '\n' ';'))"

preparer() {   # preparer <nom> : dépôt nu, clone de travail sur la branche calcul/essai ; variable d
    d=$(mktemp -d "$BASE/$1-XXXX")
    git init -q --bare "$d/distant.git"
    git clone -q "$d/distant.git" "$d/depot" 2>/dev/null
    (
        cd "$d/depot" && git config user.email t@x.invalid && git config user.name t && git config commit.gpgsign false &&
        mkdir -p runs diag && touch runs/.gitkeep diag/.gitkeep && git add -A && git commit -qm init &&
        git push -q origin HEAD:refs/heads/main && git checkout -q -b calcul/essai
    )
    echo "journal de départ" > "$d/journal.txt"; echo "178 passed in 1.00s" > "$d/tests.txt"; : > "$d/tests.err"
    {
        echo 'set -euo pipefail'
        echo "TRAVAIL='$d'; JOURNAL='$d/journal.txt'; BRANCHE=calcul/essai"
        echo "cd '$d/depot'"
        cat "$F"
    } > "$d/script.sh"
}

bilan() {   # bilan <code>
    local code=$1 t
    echo "    code de sortie : $code"
    echo "    lignes « ARRÊT » : $(grep -c 'ARRÊT' "$d/journal.txt") ; « sortie imprévue » : $(grep -c 'sortie imprévue' "$d/journal.txt") ; « TERM reçu » : $(grep -c 'TERM reçu' "$d/journal.txt")"
    grep -E 'ARRÊT|imprévue|TERM|poussée' "$d/journal.txt" | sed 's/^[0-9TZ:-]* /    | /'
    echo "    distant calcul/essai : $(git -C "$d/distant.git" log --format=%s -1 calcul/essai 2>/dev/null || echo 'aucune branche')"
    for t in $(git -C "$d/distant.git" ls-tree -d --name-only calcul/essai traces/ 2>/dev/null); do
        local x; x=$(mktemp -d "$BASE/x-XXXX"); git -C "$d/distant.git" archive calcul/essai "$t" | tar -x -C "$x"
        echo "    $t : $(cd "$x/$t" && ls | tr '\n' ' ') ; sha256sum -c : $(cd "$x/$t" && sha256sum -c --quiet empreintes.sha256 >/dev/null 2>&1 && echo conforme || echo ÉCHEC)"
        rm -rf "$x"
    done
    echo "    non suivis dans le dépôt de travail : $(git -C "$d/depot" status --porcelain | tr '\n' ' ')"
}

lancer_groupe() {   # lance le script dans son propre groupe de processus ; pid (= groupe) dans pid_s
    setsid bash "$d/script.sh" >> "$d/sortie.txt" 2>&1 &
    pid_s=$!
}
attendre() {   # attendre <fichier> <motif>
    for _ in $(seq 1 200); do grep -q -- "$2" "$1" 2>/dev/null && return 0; sleep 0.1; done; echo "    motif « $2 » non vu"; return 1
}
lent() {   # dépôt distant lent : chaque poussée attend $1 s (crochet pre-receive) ; receive-pack (et son crochet) tourne
    # dans sa propre session (setsid), hors du groupe du script, comme le serveur d'un distant réel : le TERM du groupe
    # n'atteint que le côté client de la poussée
    printf '#!/bin/sh\nsleep %s\n' "$1" > "$d/distant.git/hooks/pre-receive"; chmod +x "$d/distant.git/hooks/pre-receive"
    git -C "$d/depot" config remote.origin.receivepack "setsid git-receive-pack"
}

echo; echo "== U1 sortie normale (code 0) : le filet ne fait rien"
preparer u1; echo 'ETAPE="fin (A et B complets)"; journal "fin"' >> "$d/script.sh"
bash "$d/script.sh" > "$d/sortie.txt" 2>&1; bilan $?

echo; echo "== U2 commande en échec sous set -e (mise en place) : filet, une consignation, code conservé"
preparer u2; echo 'ETAPE="mise en place"; ( exit 3 ); echo NON ATTEINT' >> "$d/script.sh"
bash "$d/script.sh" > "$d/sortie.txt" 2>&1; bilan $?

echo; echo "== U3 commande absente (code 127) dans un tube sous pipefail (cas de nvidia-smi absent)"
preparer u3; echo 'ETAPE="mise en place"; commande_absente_xyz --query | tee -a "$JOURNAL"; echo NON ATTEINT' >> "$d/script.sh"
bash "$d/script.sh" > "$d/sortie.txt" 2>&1; bilan $?

echo; echo "== U4 variable non définie (set -u) : le filet s'exécute"
preparer u4; echo 'ETAPE="tests"; echo "$VARIABLE_ABSENTE_XYZ"; echo NON ATTEINT' >> "$d/script.sh"
bash "$d/script.sh" > "$d/sortie.txt" 2>&1; bilan $?

echo; echo "== U5 sortie explicite après consigner_arret (chemin « tests en échec ») : une seule consignation"
preparer u5; echo 'ETAPE="tests"; journal "tests en échec : arrêt"; consigner_arret "tests"; exit 1' >> "$d/script.sh"
bash "$d/script.sh" > "$d/sortie.txt" 2>&1; bilan $?

echo; echo "== U6 sortie explicite SANS consigner_arret (chemin « révision introuvable ») : filet, étape courante « tests »"
preparer u6; echo 'ETAPE="tests"; journal "révision introuvable dans prereg : arrêt"; exit 1' >> "$d/script.sh"
bash "$d/script.sh" > "$d/sortie.txt" 2>&1; bilan $?

echo; echo "== U7 TERM du plafond pendant un run (sur_term) : une consignation, code 124, filet sans effet"
preparer u7
cat >> "$d/script.sh" <<EOF
ETAPE="run A"; sleep 30 & PID_RUN=\$!; touch "$d/pret"; wait "\$PID_RUN"; echo NON ATTEINT
EOF
lancer_groupe; for _ in $(seq 1 100); do [ -e "$d/pret" ] && break; sleep 0.1; done; sleep 0.3
kill -TERM -- "-$pid_s"; wait "$pid_s"; bilan $?

echo; echo "== U8 TERM pendant la poussée d'une consignation explicite (tests en échec) : la poussée tuée est refaite par sur_term"
preparer u8; lent 3
echo 'ETAPE="tests"; journal "tests en échec : arrêt"; consigner_arret "tests"; exit 1' >> "$d/script.sh"
lancer_groupe; attendre "$d/journal.txt" "ARRÊT pendant tests" && sleep 0.5
kill -TERM -- "-$pid_s"; wait "$pid_s"; bilan $?

echo; echo "== U9 TERM pendant la poussée du filet : ignoré (trap '' TERM, hérité par git push), code d'origine conservé"
preparer u9; lent 3
echo 'ETAPE="mise en place"; ( exit 3 )' >> "$d/script.sh"
lancer_groupe; attendre "$d/journal.txt" "ARRÊT pendant mise en place" && sleep 0.5
kill -TERM -- "-$pid_s"; wait "$pid_s"; bilan $?

echo; echo "== U10 poussée refusée pendant le filet : « poussée impossible », code d'origine conservé"
preparer u10; printf '#!/bin/sh\nexit 1\n' > "$d/distant.git/hooks/pre-receive"; chmod +x "$d/distant.git/hooks/pre-receive"
echo 'ETAPE="mise en place"; ( exit 3 )' >> "$d/script.sh"
bash "$d/script.sh" > "$d/sortie.txt" 2>&1; bilan $?

echo; echo "== U11 erreur de git pendant le filet (verrou d'index laissé) : le filet continue, code conservé, aucune boucle"
preparer u11; echo 'ETAPE="mise en place"; touch .git/index.lock; ( exit 3 )' >> "$d/script.sh"
bash "$d/script.sh" > "$d/sortie.txt" 2>&1; bilan $?
echo "    sortie d'erreur du script (extrait) :"; grep -i -E "lock|fatal" "$d/sortie.txt" | head -3 | sed 's/^/    | /'

echo; echo "== U12 poussée finale en échec (dernière ligne du script, sans « || ») : filet après « fin »"
preparer u12; printf '#!/bin/sh\nexit 1\n' > "$d/distant.git/hooks/pre-receive"; chmod +x "$d/distant.git/hooks/pre-receive"
echo 'ETAPE="fin (A et B complets)"; journal "fin : A=a B=b"; traces "fin"; pousser; journal "branche $BRANCHE poussée"' >> "$d/script.sh"
bash "$d/script.sh" > "$d/sortie.txt" 2>&1; c=$?; bilan $c
echo "    dossiers de traces dans le dépôt de travail : $(ls "$d/depot/traces" | tr '\n' ' ')"
for t in "$d"/depot/traces/*; do echo "      $(basename "$t") : $(cd "$t" && sha256sum -c --quiet empreintes.sha256 >/dev/null 2>&1 && echo conforme || echo ÉCHEC)"; done

echo; echo "== U13 deux versements dans la même seconde (date figée) : deux dossiers distincts, chacun conforme (Q-6)"
preparer u13
cat >> "$d/script.sh" <<'EOF'
date() { if [ "${1:-}" = -u ] && [ "${2:-}" = +%Y%m%d-%H%M%S ]; then echo 20261004-151831; else command date "$@"; fi; }
ETAPE="fin (A et B complets)"; traces "fin"; echo "ajout" >> "$JOURNAL"; traces "arrêt pendant fin"; traces "troisième"
ls traces
EOF
bash "$d/script.sh" > "$d/sortie.txt" 2>&1; echo "    code : $?"
for t in "$d"/depot/traces/*; do echo "    $(basename "$t") : $(cd "$t" && ls | tr '\n' ' ') ; sha256sum -c : $(cd "$t" && sha256sum -c --quiet empreintes.sha256 >/dev/null 2>&1 && echo conforme || echo ÉCHEC) ; empreintes.sha256 se liste : $(grep -c 'empreintes.sha256' "$t/empreintes.sha256")"; done
echo "    commits : $(git -C "$d/depot" log --format=%s -3 | tr '\n' '|')"

echo; echo "== U14 mktemp en échec dans le filet (cas forcé : « traces » est un fichier) : où vont les copies ?"
echo "   (cp est remplacé par une fonction qui note ses arguments : rien n'est écrit hors de l'essai)"
preparer u14
cat >> "$d/script.sh" <<EOF
cp() { echo "cp \$*" >> "$d/cp.log"; }
echo "fichier" > traces
ETAPE="fin (A et B complets)"; traces "fin"
EOF
bash "$d/script.sh" > "$d/sortie.txt" 2>&1; bilan $?
echo "    appels de cp (destination) :"; sed 's/^/    | /' "$d/cp.log" 2>/dev/null | head -12
echo "    fichier empreintes.sha256 à la racine du dépôt de travail : $([ -f "$d/depot/empreintes.sha256" ] && echo "OUI ($(wc -l < "$d/depot/empreintes.sha256") lignes)" || echo non)"
echo "    erreurs (extrait) :"; grep -E "mktemp|mkdir|pathspec" "$d/sortie.txt" | head -4 | sed 's/^/    | /'

echo; echo "== U15 commande tuée par KILL (mémoire épuisée, par exemple) : code 137 conservé par le filet"
preparer u15; echo 'ETAPE="mise en place"; sh -c "kill -KILL \$\$" | tee -a "$JOURNAL"' >> "$d/script.sh"
bash "$d/script.sh" > "$d/sortie.txt" 2>&1; bilan $?

echo; echo "== U16 consignation explicite interrompue par une erreur (verrou d'index) : CONSIGNE est déjà posé, le filet ne reprend pas"
preparer u16; echo 'ETAPE="tests"; journal "tests en échec : arrêt"; touch .git/index.lock; consigner_arret "tests"; exit 1' >> "$d/script.sh"
bash "$d/script.sh" > "$d/sortie.txt" 2>&1; bilan $?

echo; echo "== processus restants sous $BASE :"
ps -eo pid,args | grep -F -- "$BASE" | grep -v -E "grep|v02_filet" || echo "    aucun"
