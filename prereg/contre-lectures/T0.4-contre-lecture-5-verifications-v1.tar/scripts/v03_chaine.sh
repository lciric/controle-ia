#!/usr/bin/env bash
# v03 : chaîne amorce → script d'instance au commit cité 3a7b5e0, amorce et script sans modification, contre un dépôt nu
# local, jetons factices. Échecs de mise en place (Q-4), tests en échec (Q-1), poussée finale refusée (filet et Q-6),
# échecs d'avant le clonage, TERM pendant une consignation explicite et pendant le filet.
# Isolement : configuration git globale minimale (comme sur l'instance : ni signature des commits, ni négociation de
# poussée) ; mandataires réseau morts (127.0.0.1:9), PIP_NO_INDEX, HF_HUB_OFFLINE : aucune sortie possible vers le réseau.
# Le TERM « de plafond » est envoyé au processus `timeout` de l'amorce, trouvé par son identifiant (R10).
# Usage : bash v03_chaine.sh <espace> [scénario…]   (<espace>/copie-head : clone du dépôt au HEAD relu)
set -uo pipefail
ESP=$1; shift
COMMIT=3a7b5e0523864f386c7ef528b663dbae83e046dd
SRC=$ESP/copie-head
VENV=/home/user/controle-ia/.venv
E=$ESP/essais-v03
mkdir -p "$E"
export PYTHONDONTWRITEBYTECODE=1
CONF=$E/gitconfig-instance; printf '[init]\n\tdefaultBranch = main\n[advice]\n\tdetachedHead = false\n' > "$CONF"
CONF_SETSID=$E/gitconfig-receive-pack-hors-groupe
{ cat "$CONF"; printf '[remote "origin"]\n\treceivepack = setsid git-receive-pack\n'; } > "$CONF_SETSID"
MORT=http://127.0.0.1:9

preparer() {   # preparer <nom> : dépôt nu propre à l'essai, amorce extraite du commit ; variables d, distant
    d=$E/$1
    [ -e "$d" ] && { echo "$d existe (R12)"; return 2; }
    mkdir -p "$d/racine"
    distant=$d/distant.git
    GIT_CONFIG_GLOBAL=$CONF git clone -q --bare --no-hardlinks "$SRC" "$distant"
    git -C "$SRC" show "$COMMIT":scripts/amorce_instance_t04.sh > "$d/amorce.sh"
}

commit_essai() {   # commit_essai <branche> <commande de modification> : commit d'essai sur le distant ; variable c_essai
    local w=$d/travail-essai
    GIT_CONFIG_GLOBAL=$CONF git clone -q "$distant" "$w" && git -C "$w" checkout -q "$COMMIT" && (cd "$w" && eval "$2") &&
    git -C "$w" add -A && GIT_CONFIG_GLOBAL=$CONF git -C "$w" -c user.email=t@x.invalid -c user.name=t commit -qm "essai : $1" &&
    GIT_CONFIG_GLOBAL=$CONF git -C "$w" push -q origin "HEAD:refs/heads/$1"
    c_essai=$(git -C "$w" rev-parse HEAD)
    echo "commit d'essai $c_essai : $(git -C "$w" show --stat --format=%s HEAD | head -3 | tr '\n' ' ')"
}

lancer_amorce() {   # lancer_amorce <commit> <mode> <venv ou vide> <branche> [config git] [PATH ajouté] : en arrière-plan
    local commit=$1 mode=$2 venv=$3 branche=$4 conf=${5:-$CONF} ajout=${6:-}
    (
        cd "$d/racine" &&
        env -u GH_TOKEN -u HF_TOKEN -u CONTROLE_IA_GITHUB_TOKEN -u VAST_API_KEY -u BRANCHE -u VENV_EXISTANT \
            -u NO_PROXY -u no_proxy \
            HTTPS_PROXY=$MORT HTTP_PROXY=$MORT https_proxy=$MORT http_proxy=$MORT ALL_PROXY=$MORT all_proxy=$MORT \
            HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PIP_NO_INDEX=1 PIP_DISABLE_PIP_VERSION_CHECK=1 \
            GIT_CONFIG_GLOBAL="$conf" GIT_CONFIG_NOSYSTEM=1 PATH="${ajout:+$ajout:}$PATH" \
            COMMIT="$commit" GH_TOKEN=jeton-factice HF_TOKEN=jeton-factice DEPOT_URL="${DEPOT_URL_ESSAI:-$distant}" \
            RACINE_AMORCE="$d/racine" MODE="$mode" ${venv:+VENV_EXISTANT="$venv"} BRANCHE="$branche" \
            bash "$d/amorce.sh" >> "$d/amorce.log" 2>&1
        echo "code amorce : $?" >> "$d/amorce.log"
    ) &
    pid_amorce=$!
}

attendre_motif() {   # attendre_motif <fichier> <motif> : jusqu'à 300 s
    for _ in $(seq 1 600); do grep -q -- "$2" "$1" 2>/dev/null && return 0; sleep 0.5; done
    echo "motif « $2 » non vu"; return 1
}

term_au_timeout() {   # TERM au `timeout` de l'amorce, par identifiant de processus
    local pid_bash pid_timeout
    pid_bash=$(ps -o pid= --ppid "$pid_amorce" | head -1 | tr -d ' ')
    pid_timeout=$(ps -o pid= --ppid "$pid_bash" | head -1 | tr -d ' ')
    if [ "$(ps -o comm= -p "$pid_timeout")" != timeout ]; then
        echo "processus $pid_timeout n'est pas timeout : pas de signal"; return 1
    fi
    echo "$(date -u +%T.%N | cut -c1-12) TERM au timeout de l'amorce, PID $pid_timeout"
    kill -TERM "$pid_timeout"
}

bilan() {   # bilan <branche distante>
    wait "$pid_amorce"
    local J=$d/racine/t04/journal.txt
    echo "--- amorce : $(grep -E '^AMORCE .*(fin, code|:)' "$d/amorce.log" | tail -2 | tr '\n' '|')"
    grep -E '^code amorce' "$d/amorce.log"
    if [ -f "$J" ]; then
        echo "--- journal de l'instance (lignes utiles)"
        grep -E 'ARRÊT|imprévue|TERM|poussée|tests|révision|run [AB]|fin' "$J" | sed 's/^[0-9TZ:-]* /  | /' | tail -14
        echo "--- consignations : « ARRÊT » $(grep -c 'ARRÊT' "$J") ; « sortie imprévue (code » $(grep -c '^[^ ]* sortie imprévue' "$J")"
    else
        echo "--- aucun journal de l'instance (le script d'instance n'a pas tourné)"
    fi
    echo "--- erreurs du script (sortie de l'amorce, extrait) :"
    grep -v -E '^(AMORCE|code amorce|-----|[0-9]{4}-[0-9]{2}-[0-9]{2}T)' "$d/amorce.log" | grep -v -E '^\s*$|passed|"' | head -4 | sed 's/^/  | /'
    echo "--- branches calcul/* du distant : $(git -C "$distant" branch --list 'calcul/*' --format='%(refname:short) « %(contents:subject) »' | tr '\n' ' ')"
    if [ -n "${1:-}" ] && git -C "$distant" rev-parse -q --verify "refs/heads/$1" >/dev/null; then
        echo "--- $1 : commits (6 derniers) : $(git -C "$distant" log --format='%s' -6 "$1" | cut -c1-90 | tr '\n' '|')"
        echo "--- $1 : résultats : $(git -C "$distant" ls-tree -r --name-only "$1" -- runs diag | grep -E 'arret|resume\.json$|comparaison-.*json$' | grep -v -E '^(runs|diag)/20261004-1[0-5]' | tr '\n' ' ')"
        for t in $(git -C "$distant" ls-tree -d --name-only "$1" traces/ 2>/dev/null); do
            local x; x=$(mktemp -d "$E/x-XXXX"); git -C "$distant" archive "$1" "$t" | tar -x -C "$x"
            echo "    $t : $(cd "$x/$t" && ls | tr '\n' ' ') ; sha256sum -c : $(cd "$x/$t" && sha256sum -c --quiet empreintes.sha256 >/dev/null 2>&1 && echo conforme || echo ÉCHEC)"
            rm -rf "$x"
        done
    fi
    echo "--- processus restants sous $d : $(ps -eo pid,args | grep -F -- "$d/" | grep -v -E 'grep|v03_chaine' | wc -l)"
}

faux_venv() {   # faux_venv <comportement à « import torch »> : environnement Python d'essai ; variable venv_faux
    venv_faux=$d/venv-faux
    mkdir -p "$venv_faux/bin" "$venv_faux/faux-bin"
    printf '. %s/bin/activate\nexport PATH="%s/faux-bin:$PATH"\n' "$VENV" "$venv_faux" > "$venv_faux/bin/activate"
    printf '#!/usr/bin/env bash\ncase "$*" in *"import torch"*) %s ;; esac\nexec %s/bin/python "$@"\n' "$1" "$VENV" > "$venv_faux/faux-bin/python"
    chmod +x "$venv_faux/faux-bin/python"
}

faux_nvidia() {   # nvidia-smi d'essai (mode reel sans carte) ; variable bin_nvidia
    bin_nvidia=$d/bin-nvidia; mkdir -p "$bin_nvidia"
    printf '#!/bin/sh\necho "name, driver_version, memory.total [MiB]"\necho "NVIDIA A100-SXM4-80GB (essai), 580.00, 81920 MiB"\n' > "$bin_nvidia/nvidia-smi"
    chmod +x "$bin_nvidia/nvidia-smi"
}

scenario() {
    local nom=$1
    echo; echo "================ $nom ($(date -u +%T))"
    case "$nom" in
    nvidia-smi-absent)
        # mode reel, aucune carte : nvidia-smi absent du PATH (il l'est sur cette machine)
        preparer "$nom" || return
        command -v nvidia-smi >/dev/null && { echo "nvidia-smi présent : essai sans objet"; return; }
        lancer_amorce "$COMMIT" reel "$VENV" calcul/essai-nvidia
        bilan calcul/essai-nvidia ;;
    pip-en-echec)
        # aucun VENV_EXISTANT : python3.11 -m venv, puis pip sans index (PIP_NO_INDEX) : échec de pip, sans réseau
        preparer "$nom" || return
        lancer_amorce "$COMMIT" jouet "" calcul/essai-pip
        bilan calcul/essai-pip
        echo "--- message de pip (sortie de l'amorce) : $(grep -m1 -E 'ERROR|error' "$d/amorce.log" | cut -c1-150)" ;;
    import-torch-en-echec)
        preparer "$nom" || return
        faux_venv 'echo "ModuleNotFoundError: No module named torch (essai)" >&2; exit 1'
        lancer_amorce "$COMMIT" jouet "$venv_faux" calcul/essai-torch
        bilan calcul/essai-torch ;;
    import-torch-tue)
        # le processus d'import est tué par KILL (comme par le tueur de mémoire du noyau) : code 137
        preparer "$nom" || return
        faux_venv 'kill -KILL $$'
        lancer_amorce "$COMMIT" jouet "$venv_faux" calcul/essai-torch-tue
        bilan calcul/essai-torch-tue ;;
    revision-introuvable)
        # mode reel, nvidia-smi d'essai ; commit d'essai = commit cité + préenregistrement sans la ligne de révision
        preparer "$nom" || return
        faux_nvidia
        commit_essai essai-revision "mkdir -p prereg && grep -v '^- Révision du modèle' '$SRC/brouillons/T0.4-validation-modele-reel-v1-brouillon6.md' > prereg/T0.4-validation-modele-reel-v1.md"
        lancer_amorce "$c_essai" reel "$VENV" calcul/essai-revision "$CONF" "$bin_nvidia"
        bilan calcul/essai-revision ;;
    prereg-absent)
        # mode reel au commit cité lui-même : aucun préenregistrement dans l'arbre (le sed du script échoue)
        preparer "$nom" || return
        faux_nvidia
        lancer_amorce "$COMMIT" reel "$VENV" calcul/essai-prereg-absent "$CONF" "$bin_nvidia"
        bilan calcul/essai-prereg-absent ;;
    tests-ko)
        preparer "$nom" || return
        commit_essai essai-tests-ko "printf 'def test_echec_essai():\n    assert False, \"échec volontaire (essai)\"\n' > tests/test_echec_essai.py"
        lancer_amorce "$c_essai" jouet "$VENV" calcul/essai-tests-ko
        bilan calcul/essai-tests-ko
        echo "--- dernières lignes de tests.txt poussé : $(git -C "$distant" show "calcul/essai-tests-ko:$(git -C "$distant" ls-tree -r --name-only calcul/essai-tests-ko traces/ | grep 'tests.txt$' | head -1)" | tail -n 2 | tr '\n' '|')" ;;
    poussee-finale-refusee)
        # crochet du distant : refuse une poussée dont le sommet est le commit des traces de fin ; accepte les autres
        preparer "$nom" || return
        cat > "$distant/hooks/pre-receive" <<'EOF'
#!/bin/sh
while read ancien nouveau ref; do
    case "$(git log -1 --format=%s "$nouveau")" in
        "T0.4 — traces de l'instance (fin)"*) echo "refus d'essai : poussée finale refusée" >&2; exit 1 ;;
    esac
done
exit 0
EOF
        chmod +x "$distant/hooks/pre-receive"
        lancer_amorce "$COMMIT" jouet "$VENV" calcul/essai-finale
        bilan calcul/essai-finale
        echo "--- dossiers de traces sur l'instance : $(ls "$d/racine/t04/controle-ia/traces" | tr '\n' ' ')" ;;
    poussees-refusees-apres-A)
        # crochet du distant : accepte la première poussée (run A), refuse toutes les suivantes
        preparer "$nom" || return
        printf '#!/bin/sh\nif [ -e premiere-poussee-faite ]; then echo "refus d essai" >&2; exit 1; fi\ntouch premiere-poussee-faite\n' > "$distant/hooks/pre-receive"
        chmod +x "$distant/hooks/pre-receive"
        lancer_amorce "$COMMIT" jouet "$VENV" calcul/essai-apres-A
        bilan calcul/essai-apres-A
        echo "--- sur l'instance seulement : $(git -C "$d/racine/t04/controle-ia" log --format=%s -3 | cut -c1-80 | tr '\n' '|')" ;;
    avant-clonage)
        preparer "$nom-a" || return
        echo "---- (a) dépôt distant introuvable"
        DEPOT_URL_ESSAI=$d/absent.git lancer_amorce "$COMMIT" jouet "$VENV" calcul/essai-a
        bilan calcul/essai-a
        echo "---- (b) commit introuvable"
        preparer "$nom-b" || return
        lancer_amorce 0123456789abcdef0123456789abcdef01234567 jouet "$VENV" calcul/essai-b
        bilan calcul/essai-b
        echo "---- (c) script d'instance seul, dossier de travail déjà présent (R12)"
        preparer "$nom-c" || return
        mkdir -p "$d/t04/controle-ia"
        git -C "$SRC" show "$COMMIT":scripts/validation_t04_instance.sh > "$d/instance.sh"
        env -u GH_TOKEN -u HF_TOKEN COMMIT=$COMMIT MODE=jouet TRAVAIL="$d/t04" DEPOT_URL="$distant" GIT_CONFIG_GLOBAL=$CONF \
            bash "$d/instance.sh" > "$d/instance.log" 2>&1; echo "code du script : $?"
        sed 's/^/  | /' "$d/instance.log"
        echo "---- (d) script d'instance seul, clonage impossible (piège pas encore posé)"
        env -u GH_TOKEN -u HF_TOKEN COMMIT=$COMMIT MODE=jouet TRAVAIL="$d/t04-d" DEPOT_URL="$d/absent.git" GIT_CONFIG_GLOBAL=$CONF \
            bash "$d/instance.sh" > "$d/instance-d.log" 2>&1; echo "code du script : $?"
        sed 's/^/  | /' "$d/instance-d.log"
        echo "  branches calcul/* du distant : $(git -C "$distant" branch --list 'calcul/*' | wc -l)" ;;
    term-pendant-tests-ko)
        # TERM du plafond pendant la poussée de la consignation explicite des tests en échec (poussées ralenties de 3 s)
        preparer "$nom" || return
        commit_essai essai-tests-ko "printf 'def test_echec_essai():\n    assert False\n' > tests/test_echec_essai.py"
        printf '#!/bin/sh\nsleep 3\n' > "$distant/hooks/pre-receive"; chmod +x "$distant/hooks/pre-receive"
        lancer_amorce "$c_essai" jouet "$VENV" calcul/essai-term-tests
        attendre_motif "$d/racine/t04/journal.txt" "ARRÊT pendant tests" && sleep 1 && term_au_timeout
        bilan calcul/essai-term-tests ;;
    term-pendant-tests-ko-hors-groupe)
        # même essai, receive-pack hors du groupe du script (comme un serveur distant) : la première poussée, dont le client
        # est tué par le TERM, peut aboutir côté serveur ; on regarde la poussée de sur_term, puis celle de l'amorce
        preparer "$nom" || return
        commit_essai essai-tests-ko "printf 'def test_echec_essai():\n    assert False\n' > tests/test_echec_essai.py"
        printf '#!/bin/sh\nsleep 3\n' > "$distant/hooks/pre-receive"; chmod +x "$distant/hooks/pre-receive"
        lancer_amorce "$c_essai" jouet "$VENV" calcul/essai-term-tests-hg "$CONF_SETSID"
        attendre_motif "$d/racine/t04/journal.txt" "ARRÊT pendant tests" && sleep 1 && term_au_timeout
        bilan calcul/essai-term-tests-hg
        echo "--- messages de poussée (sortie de l'amorce) : $(grep -E 'rejected|cannot lock|poussée impossible' "$d/amorce.log" | cut -c1-100 | tr '\n' '|')" ;;
    term-pendant-filet)
        # environnement Python en échec (code 3) ; poussées ralenties de 5 s, receive-pack hors du groupe du script (comme un
        # serveur distant) ; TERM pendant la poussée du filet : ignoré, la poussée aboutit, le code 3 est conservé
        preparer "$nom" || return
        mkdir -p "$d/venv-ko/bin"; printf 'echo "activation impossible (essai)" >&2\nreturn 3\n' > "$d/venv-ko/bin/activate"
        printf '#!/bin/sh\nsleep 5\n' > "$distant/hooks/pre-receive"; chmod +x "$distant/hooks/pre-receive"
        lancer_amorce "$COMMIT" jouet "$d/venv-ko" calcul/essai-term-filet "$CONF_SETSID"
        attendre_motif "$d/racine/t04/journal.txt" "ARRÊT pendant mise en place" && sleep 1 && term_au_timeout
        bilan calcul/essai-term-filet ;;
    *) echo "scénario inconnu : $nom" ;;
    esac
}

for s in "${@:-nvidia-smi-absent pip-en-echec import-torch-en-echec import-torch-tue avant-clonage term-pendant-filet revision-introuvable prereg-absent tests-ko poussee-finale-refusee poussees-refusees-apres-A term-pendant-tests-ko}"; do
    for x in $s; do scenario "$x"; done
done
