"""v05 (Q-5) : validateur `problemes` de `prereg.py` au commit 3a7b5e0, sur le brouillon 6.
Usage : PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=<espace>/copie/src python v05_validateur.py <espace>
(a) brouillon 6 tel quel : seul le marqueur d'attente doit être refusé ; entrées reconnues ; empreintes par entrée ;
(b) entrée de la contre-lecture 5 remplie dans la forme reconnue (deux empreintes distinctes) : accepté ;
(c) entrée remplie avec une seule empreinte, ou sans report : refusé ;
(d) la phrase du texte « tiret et astérisques permis ; il ne reconnaît pas d'autre forme d'entrée » contre l'expression ;
(e) le texte scellé ne doit pas contenir le marqueur en toutes lettres, même cité."""
import re
import sys
import tempfile
from pathlib import Path

from controle_ia.prereg import ENTREE, EMPREINTE, MARQUEUR, problemes, sections

esp = Path(sys.argv[1])
b6 = esp / "copie-head" / "brouillons" / "T0.4-validation-modele-reel-v1-brouillon6.md"
src = b6.read_text(encoding="utf-8")
ligne = ("- **Contre-lecture 5** du différentiel `92e2f99..3a7b5e0` et des passages modifiés : À REMPLIR "
         "(brouillon relu, rapport, traitement).")
assert ligne in src, "ligne d'attente introuvable"
H1, H2 = "1" * 64, "2" * 64


def essai(rempl):
    p = Path(tempfile.mkdtemp()) / "p.md"
    p.write_text(src.replace(ligne, rempl), encoding="utf-8")
    return problemes(p) or "ACCEPTÉ"


print("(a) brouillon 6 tel quel")
print(f"    problemes : {problemes(b6)}")
print(f"    occurrences du marqueur dans le texte : {src.count(MARQUEUR)} (ligne {[i + 1 for i, l in enumerate(src.splitlines()) if MARQUEUR in l]})")
cl = sections(src)["Contre-lecture"]
entrees = list(ENTREE.finditer(cl))
print("    entrées reconnues :", [m.group(0).strip() for m in entrees])
for k, e in enumerate(entrees):
    fin = entrees[k + 1].start() if k + 1 < len(entrees) else len(cl)
    print(f"    contre-lecture {e.group(1)} : {len(set(EMPREINTE.findall(cl[e.start():fin])))} empreintes distinctes dans l'entrée")
print("    expression ENTREE :", ENTREE.pattern)

print("(b) entrée de la contre-lecture 5 remplie, forme reconnue, deux empreintes distinctes")
bon = (f"- **Contre-lecture 5** (cinquième sous-agent neuf, 2026-10-04), sur le différentiel `92e2f99..3a7b5e0` :\n"
       f"  - brouillons relus : `brouillons/T0.4-validation-modele-reel-v1-brouillon6.md`, sha256 `{H1}` ;\n"
       f"  - rapport : `prereg/contre-lectures/T0.4-rapport-contre-lecture-5-v1.md`, sha256 `{H2}` ;\n"
       f"  - verdict : scellable après corrections de texte.")
print(f"    -> {essai(bon)}")
print("(c) refus attendus")
print(f"    une seule empreinte -> {essai(f'- **Contre-lecture 5** : brouillon `{H1}`, rapport à venir.')}")
print(f"    sans empreinte -> {essai('- **Contre-lecture 5** : faite, verdict scellable.')}")
print(f"    même empreinte deux fois -> {essai(f'- **Contre-lecture 5** : `{H1}` et `{H1}`.')}")
print("(d) formes d'entrée et phrase du texte")
for forme in ("- **Contre-lecture 5** :", "**Contre-lecture 5** :", "- Contre-lecture 5 :", "Contre-lecture 5 :",
              "  - **Contre-lecture 5** :", "* **Contre-lecture 5** :", "1. **Contre-lecture 5** :", "- __Contre-lecture 5__ :",
              "- Contre-Lecture 5 :", "- Contre-lecture n° 5 :", "- Cinquième contre-lecture :"):
    r = essai(forme + " faite, sans empreinte.")
    vu = "reconnue (refus faute d'empreintes)" if r != "ACCEPTÉ" else "NON reconnue (acceptée sans empreinte)"
    print(f"    {forme!r:34s} -> {vu}")
print("(e) le marqueur cité dans une entrée remplie (avec deux empreintes) :")
print(f"    -> {essai(bon + ' Le marqueur « ' + MARQUEUR + ' » a été retiré.')}")
