#!/usr/bin/env bash
# v00 : prépare l'espace de travail de la contre-lecture 5 (lecture seule du dépôt source).
#   copie/       clone au commit cité 3a7b5e0 (code, tests, scripts)
#   copie-head/  clone au HEAD relu 9949afb (brouillons, répétitions, essais de l'auteur)
# --no-hardlinks : un clone local partage sinon les fichiers d'objets du dépôt (liens physiques) et git en rafraîchit la date.
# Usage : bash v00_preparer.sh <espace> [dépôt source, défaut /home/user/controle-ia]
set -eu
ESP=$1; SRC=${2:-/home/user/controle-ia}
for d in copie copie-head; do [ -e "$ESP/$d" ] && { echo "$ESP/$d existe (R12)"; exit 2; }; done
git clone -q --no-hardlinks "$SRC" "$ESP/copie" && git -C "$ESP/copie" -c advice.detachedHead=false checkout -q 3a7b5e0523864f386c7ef528b663dbae83e046dd
git clone -q --no-hardlinks "$SRC" "$ESP/copie-head" && git -C "$ESP/copie-head" -c advice.detachedHead=false checkout -q 9949afb7904b25e64e6eddc51f86cba68e18868c
git -C "$ESP/copie" rev-parse HEAD; git -C "$ESP/copie-head" rev-parse HEAD
