#!/usr/bin/env bash
# v01 : suite de tests au commit cité, commande exacte du script d'instance (sortie standard et sortie d'erreur séparées),
# puis lecture de P0 par `tests_conformes` (178 attendus). Usage : bash v01_suite_tests.sh <espace>  (copie/ au commit 3a7b5e0)
set -u
ESP=$1; S=$ESP/scripts/sorties
cd "$ESP/copie" || exit 1
echo "commit : $(git rev-parse HEAD)"
export PYTHONDONTWRITEBYTECODE=1
. /home/user/controle-ia/.venv/bin/activate
debut=$(date +%s)
PYTHONPATH=src python -m pytest -q -p no:cacheprovider > "$S/v01_suite_tests.stdout.txt" 2> "$S/v01_suite_tests.stderr.txt"
echo "code de sortie de pytest : $? ; durée $(( $(date +%s) - debut )) s"
echo "dernière ligne : $(tail -n 1 "$S/v01_suite_tests.stdout.txt")"
echo "sortie d'erreur : $(wc -c < "$S/v01_suite_tests.stderr.txt") octets"
echo "tests collectés : $(PYTHONPATH=src python -m pytest -q -p no:cacheprovider --collect-only 2>/dev/null | tail -n 1)"
PYTHONPATH=src python -c "
import sys; from controle_ia.harnais.validation_reelle import tests_conformes, CONFIG_REELLE
print('tests_conformes(sortie, %d) =' % CONFIG_REELLE['tests_attendus'], tests_conformes(open(sys.argv[1]).read(), CONFIG_REELLE['tests_attendus']))
" "$S/v01_suite_tests.stdout.txt"
echo "état de la copie après la suite (aucun fichier créé attendu) :"; git status --porcelain --ignored | head
