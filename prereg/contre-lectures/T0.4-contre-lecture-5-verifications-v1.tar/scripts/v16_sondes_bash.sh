#!/usr/bin/env bash
# v16 : comportements de bash (5.2) sur lesquels reposent le filet de sortie et les traces : cd "", set -u et piège EXIT,
# absence de récursion du piège EXIT, erreur set -e dans le piège, commande tuée par KILL, trap '' TERM hérité.
# Usage : bash v16_sondes_bash.sh <espace>   (l'espace n'est pas utilisé ; versions affichées)
bash --version | head -1; tail --version | head -1; mktemp --version | head -1
echo "1) cd \"\" :"; bash -c 'cd /tmp && cd "" ; echo "  code $? ; pwd $(pwd)"'
echo "2) set -u, variable absente, piège EXIT :"; bash -c 'set -euo pipefail; trap '\''echo "  piège EXIT, code $?"'\'' EXIT; echo "$ABSENTE_XYZ"; echo NON ATTEINT' 2>&1; echo "  code final $?"
echo "3) exit dans le piège EXIT (récursion ?) :"; bash -c 'set -euo pipefail; n=0; f(){ local c=$?; n=$((n+1)); echo "  piège n=$n code=$c"; false || true; exit "$c"; }; trap f EXIT; false'; echo "  code final $?"
echo "4) erreur set -e DANS le piège EXIT hors contexte ignoré (le code d'origine est perdu) :"; bash -c 'set -euo pipefail; f(){ local c=$?; echo "  piège code=$c"; false; echo "  après false (atteint ?)"; exit "$c"; }; trap f EXIT; ( exit 3 )'; echo "  code final $?"
echo "5) commande tuée par KILL sous set -e :"; bash -c 'set -euo pipefail; trap '\''echo "  piège EXIT, code $?"'\'' EXIT; sh -c "kill -KILL \$\$"; echo NON' 2>&1; echo "  code final $?"
echo "6) trap vide TERM hérité par un enfant :"; bash -c 'trap "" TERM; sh -c "kill -TERM \$\$; echo \"  enfant vivant après TERM\""'
echo "7) tail -5 à deux fichiers (forme abrégée, Q-1) puis tail -n 5 :"; T=$(mktemp -d); echo a > "$T/x"; echo b > "$T/y"
tail -5 "$T/x" "$T/y" >/dev/null 2>&1; echo "  tail -5 : code $?"; tail -n 5 "$T/x" "$T/y" >/dev/null 2>&1; echo "  tail -n 5 : code $?"; rm -rf "$T"
