#!/usr/bin/env bash
# v13 : décompte des scénarios et des lancements de l'amorce dans l'archive d'essais de l'auteur au commit cité
# (diag/essais-amorce-T0.4/essais-amorce-T0.4-cl4-v1.tar), contre « Dix scénarios » (brouillon 6, l. 274) et R-036.
# Usage : bash v13_comptes_essais.sh <espace>   (copie-head/ au HEAD relu)
set -u
ESP=$1; A=$ESP/copie-head/diag/essais-amorce-T0.4/essais-amorce-T0.4-cl4-v1.tar
echo "archive : $(sha256sum "$A" | cut -c1-64) ; compagnon : $(cut -c1-64 "$A.sha256")"
T=$(mktemp -d "$ESP/v13-XXXX"); tar -xf "$A" -C "$T"
echo "scénarios lancés (titres « ================ » des trois groupes) : $(cat "$T"/groupe*.txt | grep -c '^================')"
cat "$T"/groupe*.txt | grep '^================' | sed 's/^/  /'
echo "lignes du tableau du LISEZMOI : $(grep -c '^| `' "$T/LISEZMOI.md")"
echo "lancements de l'amorce (lignes « AMORCE … : commit ») : $(cat "$T"/*/amorce.log | grep -c '^AMORCE .*: commit')"
echo "dossiers de traces nés dans la même seconde, même préfixe, dans les essais de l'auteur :"
cat "$T"/groupe*.txt | grep -o 'traces/t04-[0-9-]*-[A-Za-z0-9]*/' | sort -u | sed -E 's|traces/(t04-[0-9]{8}-[0-9]{6})-.*|\1|' | sort | uniq -d | sed 's/^/  /'
echo "  (aucune ligne ci-dessus : aucun cas de même préfixe et même seconde chez l'auteur)"
echo "brouillon 6 : $(grep -o 'Dix scénarios[^:]*' "$ESP/copie-head/brouillons/T0.4-validation-modele-reel-v1-brouillon6.md")"
echo "R-036 : $(grep -o 'dix scénarios[^)]*' "$ESP/copie-head/registres/decisions.md")"
rm -rf "$T"
