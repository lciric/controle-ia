#!/usr/bin/env bash
# v08 : concordance texte / code du brouillon 6 au commit 3a7b5e0 : citations (expressions du lanceur et `sed` du script
# d'instance), configuration réelle, empreintes des scripts et des documents, toutes les empreintes citées, GO,
# chiffres de la répétition jouet, arbre gelé entre 92e2f99, 3a7b5e0 et HEAD, différentiel des textes.
# Usage : bash v08_concordance.sh <espace>   (copie/ au commit 3a7b5e0, copie-head/ au HEAD relu 9949afb)
set -uo pipefail
ESP=$1
H=$ESP/copie-head
B6=$H/brouillons/T0.4-validation-modele-reel-v1-brouillon6.md
B5=$H/brouillons/T0.4-validation-modele-reel-v1-brouillon5.md
P5=$H/brouillons/procedure-validation-T0.4-modele-reel-v1-brouillon5.md
P4=$H/brouillons/procedure-validation-T0.4-modele-reel-v1-brouillon4.md
cd "$ESP/copie" || exit 1
export PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src
PY=/home/user/controle-ia/.venv/bin/python
echo "== empreintes des textes relus"
sha256sum "$B6" "$B5" "$P5" "$P4" | sed "s|$H/||"
echo "== citations lues par le lanceur (COMMIT_CITE, REVISION_CITEE, ENTROPIE_CITEE) et par le sed du script d'instance"
$PY - "$B6" <<'PY'
import sys
from pathlib import Path
from controle_ia.harnais import validation_reelle as V
t = Path(sys.argv[1]).read_text(encoding="utf-8")
for nom, rx in (("commit", V.COMMIT_CITE), ("révision", V.REVISION_CITEE), ("entropie", V.ENTROPIE_CITEE)):
    print(f"   {nom:9s}: {rx.findall(t)}")
e = int(V.ENTROPIE_CITEE.search(t).group(1)); print(f"   entropie : {e.bit_length()} bits")
PY
sed_script=$(git show 3a7b5e0:scripts/validation_t04_instance.sh | grep -o "sed -n 's/.*Révision du modèle.*\" | head -1" | head -1)
echo "   sed du script (ligne lue au commit) : $sed_script"
R=$(sed -n 's/.*Révision du modèle : `\([0-9a-f]\{40\}\)`.*/\1/p' "$B6" | head -1); echo "   valeur extraite : $R"
echo "   lignes du brouillon qui contiennent « Révision du modèle : » : $(grep -c 'Révision du modèle : ' "$B6")"
echo "== commit cité : existe, et arbre gelé identique de 3a7b5e0 à HEAD (pathspec du lanceur)"
git cat-file -t 3a7b5e0523864f386c7ef528b663dbae83e046dd
$PY - <<'PY'
import subprocess
from controle_ia.harnais.validation_reelle import CHEMINS_GELES
h = "/".join(__import__("os").environ.get("X", "").split()) or None
for a, b in (("92e2f995e581cb82ad801daff3f12ce19b28dc9b", "3a7b5e0523864f386c7ef528b663dbae83e046dd"),
             ("3a7b5e0523864f386c7ef528b663dbae83e046dd", "9949afb7904b25e64e6eddc51f86cba68e18868c")):
    r = subprocess.run(["git", "diff", "--stat", a, b, "--", *CHEMINS_GELES], capture_output=True, text=True)
    print(f"   arbre gelé {a[:7]}..{b[:7]} : " + (r.stdout.strip().splitlines()[-1] if r.stdout.strip() else "identique"))
    if r.stdout.strip():
        for l in r.stdout.strip().splitlines()[:-1]:
            print("      ", l.strip())
PY
echo "== scripts au commit cité (empreintes citées l. 14-15)"
for s in validation_t04_instance.sh amorce_instance_t04.sh; do
    echo "   $s : $(git show 3a7b5e0523864f386c7ef528b663dbae83e046dd:scripts/$s | sha256sum | cut -c1-64)"
done
grep -n -o '`[0-9a-f]\{64\}`' "$B6" | sed -n '1,2p' | sed 's/^/   cité, ligne /'
echo "== configuration réelle au commit cité"
$PY <<'PY'
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais.activations import couches_par_defaut
c = V.CONFIG_REELLE
print("   logique   :", {k: c["logique"][k] for k in ("episodes", "N", "T", "max_nouveaux", "taille_lot", "tolerance", "episodes_equivalence", "noyau_attention", "dtype")})
print("   production:", {k: c["production"][k] for k in ("episodes", "N", "T", "max_nouveaux", "taille_lot", "tolerance", "episodes_equivalence", "lots_rejeu_en_processus", "dtype")})
print("   débit     :", c["debit"], "; par jeton", c["politique"]["episodes_par_jeton"], "; sondes", len(c["politique"]["sondes"]))
print("   contrôle négatif :", c["controle_negatif"], "; carte ≥", c["memoire_carte_min_gio"], "Gio ; vive ≥", c["memoire_vive_min_go"], "Go")
print("   tests attendus :", c["tests_attendus"], "; limite interne :", c["limite_s"], "s ; gabarit :", c["variables_gabarit"], "; ouverture :", c["format"]["texte_attendu_ouverture"])
print("   couches de 32 :", couches_par_defaut(32), "; modèle :", c["modele"])
PY
echo "== délais des scripts"
git show 3a7b5e0:scripts/validation_t04_instance.sh | grep -n "DELAI=("
git show 3a7b5e0:scripts/amorce_instance_t04.sh | grep -n "timeout --signal"
echo "== documents qui font foi, GO"
cd "$H" || exit 1
for f in docs/brief-claude-code-programme-complet-v2.md docs/programme-controle-ia-v2.md livrables/premier-rendu-v1/devis-v1.md; do
    h=$(sha256sum "$f" | cut -c1-64); echo "   $f : $h ; cité : $(grep -c "$h" "$B6")"
done
grep -n "GO-2026-10-04-08" registres/go.md | head -2 | cut -c1-160
echo "== toutes les empreintes de 64 caractères citées dans le brouillon 6, contre les fichiers du dépôt à HEAD"
T=$(mktemp -d "$ESP/v08-XXXX")
grep -o '[0-9a-f]\{64\}' "$B6" | sort -u > "$T/cites"
git ls-files -z | xargs -0 sha256sum 2>/dev/null | awk '{print $1, $2}' > "$T/depot"
n=0; manque=0
while read -r h; do
    f=$(grep "^$h " "$T/depot" | head -1 | cut -d' ' -f2-); n=$((n+1)); [ -z "$f" ] && manque=$((manque+1))
    echo "   ${h:0:16}… -> ${f:-(aucun fichier du dépôt à HEAD)}"
done < "$T/cites"
echo "   $n empreintes distinctes ; sans fichier : $manque"
rm -rf "$T"
echo "== répétition jouet citée : résumés, comparaison, chiffres"
for f in diag/20261004-155447-repetition-jouet/resume.json diag/20261004-155505-repetition-jouet/resume.json \
         diag/20261004-155505-repetition-jouet/comparaison-20261004-155447-repetition-jouet.json; do
    echo "   $f : $(sha256sum "$f" | cut -c1-16)… ; compagnon : $(cut -c1-16 "$f.sha256")… $( [ "$(sha256sum "$f" | cut -c1-64)" = "$(cut -c1-64 "$f.sha256")" ] && echo conforme || echo ÉCART)"
done
$PY - <<'PY'
import json
r = json.load(open("diag/20261004-155447-repetition-jouet/resume.json"))["resultat"]
for ph in ("logique", "production"):
    e = r[ph]["equivalence"]; cn = e["controle_negatif"]
    print(f"   {ph} : écart max {e['ecart_max']:.3g} ; contexte {e['max_contexte']:.3g} ; zone générée {e['max_zone_generee']:.3g} ; contrôle négatif {cn.get('passent')}/{cn.get('comparables')} , minimum {cn['min_des_maxima']:.3g}")
rp = r["production"]["repere_precision"]
print("   repère de précision, maximum :", f"{max(v['max'] for v in rp.values()):.3g}", "; par couche :", {k: round(v["max"], 5) for k, v in rp.items()})
print("   lecture :", r["lecture"])
print("   tests de l'instance :", r.get("tests_instance"))
c = json.load(open("diag/20261004-155505-repetition-jouet/comparaison-20261004-155447-repetition-jouet.json"))["resultat"]
print("   comparaison : identique", c["identique"], "; différences", c["differences"], "; lecture", c["lecture"])
for run in ("20261004-155447-repetition-jouet", "20261004-155505-repetition-jouet"):
    m = json.load(open(f"runs/{run}/manifeste.json"))
    g = next(iter(m["graines"].values()))
    print(f"   manifeste {run} : commit {m['commit'][:12]} ; entropie {g['entropie']} ; décisif {m.get('decisif')}")
PY
echo "== différentiels des textes (lignes changées)"
echo "   brouillon 5 → 6 : $(diff "$B5" "$B6" | grep -c '^[<>]') lignes ; procédure 4 → 5 : $(diff "$P4" "$P5" | grep -c '^[<>]') lignes"
