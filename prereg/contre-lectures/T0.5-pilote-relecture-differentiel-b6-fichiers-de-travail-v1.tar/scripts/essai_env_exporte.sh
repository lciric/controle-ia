#!/usr/bin/env bash
# Contrôle mécanique de Y-1 / X-1 : la suite du script de l'instance, lancée avec les variables que l'instance
# exporte (relancement compris), doit passer entière. À lancer depuis la racine du dépôt.
set -u
W=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-pilote-b6
export PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src
for cas in "BRANCHE=calcul/t05-pilote-reel-v2" "PREREG_ABSENT=1" \
           "BRANCHE=calcul/t05-revalidation-reel-v2 ETUDE=pilote MODE=reel COMMIT=0000000000000000000000000000000000000000 HF_TOKEN=x GH_TOKEN=y TRAVAIL=/nonexistent DEPOT_URL=/nonexistent PREREG=x.md CONFIG=x.json TACHES=x.json ENTRAINEMENT=x.json EVALUATION=x.json TESTS_ATTENDUS=3 VENV_EXISTANT=/nonexistent HOME=/nonexistent"; do
    echo "=== cas : $cas"
    env $cas .venv/bin/python -m pytest -q -p no:cacheprovider --basetemp=$W/pytest-tmp-env tests/test_script_instance_t05.py 2>&1 | tail -3
done
