"""Relecture du différentiel du brouillon 6 (V-1) : une panne (réseau simulé) au chargement du juge 3B, après
l'écriture des épisodes. Quelle étape `arret.json` consigne-t-il, et les épisodes sont-ils écrits ? Code du dépôt,
sans mutation ; dépôt jetable (fixture `depot`)."""
import sys

import pytest

sys.path.insert(0, "/home/user/controle-ia/tests")
import test_pilote_a as t  # noqa: E402
from conftest import committer  # noqa: E402
from controle_ia.environnements import lancer_pilote_a as lp  # noqa: E402
from controle_ia.manifeste import verifier_resultat  # noqa: E402


def test_panne_au_chargement_du_juge_3b(depot, monkeypatch):
    vrai = lp.charger_modele_et_format

    def charger(spec, mode, graine):
        if spec.get("nom") == "jouet-3B":
            raise OSError("réseau simulé : téléchargement du juge 3B impossible")
        return vrai(spec, mode, graine)
    monkeypatch.setattr(lp, "charger_modele_et_format", charger)
    f, _ = t._taches_scellees(depot)
    committer(depot)
    run = "20261007-120000-pilote-jouet"
    with pytest.raises(OSError, match="réseau simulé"):
        lp.executer(t._config_lanceur(), depot, run, None, str(f))
    d = depot / "diag" / run
    arret = verifier_resultat(depot, d / "arret.json")["resultat"]
    print("\nFICHIERS ÉCRITS :", sorted(x.name for x in d.glob("*.json")))
    print("ÉTAPE CONSIGNÉE :", repr(arret["etape"]), "; épisodes écrits :", arret["partiel"].get("episodes_ecrits"),
          "; motif :", arret["motif"])
    assert (d / "episodes.json").exists() and arret["etape"] == "épisodes"
