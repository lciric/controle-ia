#!/usr/bin/env bash
# Relecture du différentiel du brouillon 6 (V) : la comparaison de la section 2 (premier champ du sceau) laisse passer
# un sceau qui nomme un autre fichier, ou de deux lignes, que le script de l'instance arrête ensuite (module de
# scellement, X-3). Variante proposée, en une ligne : le sceau entier doit égaler « <empreinte>  <nom de base> ».
set -u
W="$1"; rm -rf "$W"; mkdir -p "$W"; cd "$W" || exit 1
export GIT_AUTHOR_NAME=t GIT_AUTHOR_EMAIL=t@invalid GIT_COMMITTER_NAME=t GIT_COMMITTER_EMAIL=t@invalid
git init -q -b main d && cd d && mkdir -p donnees/run
echo '{"taches": []}' > donnees/run/a.json; cp donnees/run/a.json donnees/run/b.json
(cd donnees/run && sha256sum a.json > a.json.sha256)
(cd donnees/run && sha256sum b.json > b.json.sha256)
git add -A && git commit -qm sain
procedure() { [ "$(git show "$COMMIT:$T" | sha256sum | cut -d' ' -f1)" = "$(git show "$COMMIT:$T.sha256" | cut -d' ' -f1)" ]; echo -n "procédure : $? ; "; }
variante() { [ "$(git show "$COMMIT:$T.sha256")" = "$(git show "$COMMIT:$T" | sha256sum | cut -d' ' -f1)  $(basename "$T")" ]; echo "variante : $?"; }
module() { (cd donnees/run && PYTHONPATH=/home/user/controle-ia/src /home/user/controle-ia/.venv/bin/python -I -c "
import sys; sys.path.insert(0, '/home/user/controle-ia/src')
from controle_ia.scellement import verifier; from controle_ia.gardes import GardeArret
try: verifier('$(basename "$T")'); print('  module : OK')
except GardeArret as e: print('  module : ARRÊT', e)"); }
T=donnees/run/b.json
COMMIT=$(git rev-parse HEAD); echo "(a) cas sain :"; procedure; variante; module
(cd donnees/run && sha256sum a.json > b.json.sha256); git add -A; git commit -qm autre-nom
COMMIT=$(git rev-parse HEAD); echo "(b) sceau de b.json qui nomme a.json (même contenu) :"; procedure; variante; module
(cd donnees/run && { sha256sum b.json; sha256sum a.json; } > b.json.sha256); git add -A; git commit -qm deux-lignes
COMMIT=$(git rev-parse HEAD); echo "(c) sceau de deux lignes :"; procedure; variante; module
