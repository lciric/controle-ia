#!/usr/bin/env bash
# Relecture du différentiel du brouillon 6 (V) : le test ajouté pour Y-1 (test_environnement_de_l_instance_sans_effet)
# attrape-t-il un retour à l'ancien environnement de _lancer (tout os.environ sauf GIT_* et PYTHON*) ? Copie des tests,
# du script et des trois modules dans le dossier de l'essai ; le dépôt n'est pas touché.
set -u
DEPOT=/home/user/controle-ia
W="$1"; rm -rf "$W"; mkdir -p "$W/tests" "$W/scripts" "$W/src/controle_ia"
cp "$DEPOT/tests/test_script_instance_t05.py" "$DEPOT/tests/conftest.py" "$W/tests/"
cp "$DEPOT/scripts/pilote_t05_instance.sh" "$W/scripts/"
for m in __init__.py gardes.py scellement.py; do cp "$DEPOT/src/controle_ia/$m" "$W/src/controle_ia/"; done
lancer() { (cd "$W/tests" && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$W/src" "$DEPOT/.venv/bin/python" -m pytest -q \
    -p no:cacheprovider --basetemp="$W/pytest-tmp" --rootdir="$W/tests" "$@" 2>&1 | tail -1); }
echo "témoin : $(lancer test_script_instance_t05.py)"
"$DEPOT/.venv/bin/python" -I - "$W/tests/test_script_instance_t05.py" <<'PY'
import sys, pathlib
p = pathlib.Path(sys.argv[1]); t = p.read_text(encoding="utf-8")
neuf = "    env = {k: os.environ[k] for k in ENV_DE_BASE if k in os.environ}\n"
ancien = '    env = {k: v for k, v in os.environ.items() if not k.startswith(("GIT_", "PYTHON"))}\n'
assert t.count(neuf) == 1
p.write_text(t.replace(neuf, ancien), encoding="utf-8")
PY
echo "mutation (ancien environnement de _lancer) : $(lancer 'test_script_instance_t05.py::test_environnement_de_l_instance_sans_effet')"
echo "mutation, suite entière sans variable exportée : $(lancer test_script_instance_t05.py)"
