#!/usr/bin/env bash
# Relecture du différentiel du brouillon 6 (V-7) : la commande de lecture de la procédure (section 6), telle qu'écrite,
# depuis la racine du dépôt, sans PYTHONPATH=src, puis avec ; seule l'aide est demandée (rien n'est lu ni écrit).
cd /home/user/controle-ia || exit 1
echo "sans PYTHONPATH : $(env -u PYTHONPATH PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m controle_ia.environnements.lire_pilote --help 2>&1 | tail -1)"
echo "avec PYTHONPATH=src : $(PYTHONPATH=src PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m controle_ia.environnements.lire_pilote --help 2>&1 | head -1)"
for e in preparer-etiquetage refaire-lot lire-etiquetage analyser; do
    echo "$e : $(PYTHONPATH=src PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m controle_ia.environnements.lire_pilote $e --help 2>&1 | head -1)"
done
