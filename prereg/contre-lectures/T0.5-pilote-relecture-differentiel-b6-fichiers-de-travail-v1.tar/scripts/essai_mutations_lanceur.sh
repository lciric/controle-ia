#!/usr/bin/env bash
# Relecture du différentiel du brouillon 6 (V) : mutations textuelles d'une COPIE du lanceur du pilote (le dépôt n'est
# pas touché), pour éprouver (1) le test de l'ordre des étapes (Y-5) et (2) le test de la borne de duree_max_s (Y-7).
#   M1 : appariement avant les notations décisives (mutation de la relecture précédente, Y-5) ;
#   M2 : appariement après les notations descriptives de D ;
#   M3 : garde de durée stricte (< au lieu de <=) ;
#   M4 : garde de durée déplacée après le chargement des tâches (le test de la borne passe-t-il encore ?).
# Témoin : la copie sans mutation.
set -u
DEPOT=/home/user/controle-ia
W="$1"; rm -rf "$W"; mkdir -p "$W/base/tests" "$W/base/docs/sources"
cp -r "$DEPOT/docs/sources/invites-2606.08892-v1" "$W/base/docs/sources/"; cp -r "$DEPOT/src" "$W/base/src"
find "$W/base/src" -name __pycache__ -prune -exec rm -rf {} +
cp "$DEPOT/tests/test_pilote_a.py" "$DEPOT/tests/conftest.py" "$W/base/tests/"
L=src/controle_ia/environnements/lancer_pilote_a.py
lancer() {   # $1 copie, $2 test
    (cd "$1/tests" && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$1/src" "$DEPOT/.venv/bin/python" -m pytest -q \
        -p no:cacheprovider --basetemp="$1/pytest-tmp" --rootdir="$1/tests" "test_pilote_a.py::$2" 2>&1 | tail -1)
}
muter() {    # $1 nom, $2 programme python appliqué au lanceur de la copie
    cp -r "$W/base" "$W/$1"
    "$DEPOT/.venv/bin/python" -I -c "$2" "$W/$1/$L" || { echo "$1 : mutation non appliquée"; return 1; }
    diff "$W/base/$L" "$W/$1/$L" | sed "s/^/  [$1] /"
}
muter M1 '
import sys, pathlib
p = pathlib.Path(sys.argv[1]); t = p.read_text(encoding="utf-8")
assert t.count("    noter(\"decisives\")\n") == 1 and t.count("    noter(\"descriptives\")\n") == 1
t = t.replace("    noter(\"decisives\")\n", "", 1)
t = t.replace("    noter(\"descriptives\")\n", "    noter(\"decisives\")\n    noter(\"descriptives\")\n", 1)
p.write_text(t, encoding="utf-8")'
muter M2 '
import sys, pathlib
p = pathlib.Path(sys.argv[1]); t = p.read_text(encoding="utf-8")
assert t.count("    noter(\"descriptives\")\n") == 1 and t.count("    noter(\"decisives\")\n") == 1
t = t.replace("    noter(\"descriptives\")\n", "", 1)
t = t.replace("    noter(\"decisives\")\n", "    noter(\"decisives\")\n    noter(\"descriptives\")\n", 1)
p.write_text(t, encoding="utf-8")'
muter M3 '
import sys, pathlib
p = pathlib.Path(sys.argv[1]); t = p.read_text(encoding="utf-8")
assert t.count("not 0 < duree <= DUREE_MAX_S") == 1
p.write_text(t.replace("not 0 < duree <= DUREE_MAX_S", "not 0 < duree < DUREE_MAX_S"), encoding="utf-8")'
muter M4 '
import sys, pathlib, re
p = pathlib.Path(sys.argv[1]); t = p.read_text(encoding="utf-8")
garde = re.search(r"    duree = config\[\"duree_max_s\"\]\n(?:.*\n){4}", t).group(0)
assert "GardeArret" in garde and t.count("    taches = charger_taches(chemin_taches)\n") == 1
t = t.replace(garde, "", 1).replace("    taches = charger_taches(chemin_taches)\n",
                                    "    taches = charger_taches(chemin_taches)\n" + garde, 1)
p.write_text(t, encoding="utf-8")'
echo "=== témoin (sans mutation)"
echo "  ordre : $(lancer "$W/base" test_lanceur_ordre_des_etapes_arret_pendant_d)"
echo "  borne : $(lancer "$W/base" test_lanceur_duree_a_la_borne_acceptee)"
echo "  gardes : $(lancer "$W/base" test_lanceur_noyau_et_duree_valides_avant_le_manifeste)"
echo "=== M1 (appariement avant les décisives) : ordre : $(lancer "$W/M1" test_lanceur_ordre_des_etapes_arret_pendant_d)"
echo "=== M2 (appariement après D) : ordre : $(lancer "$W/M2" test_lanceur_ordre_des_etapes_arret_pendant_d)"
echo "=== M3 (garde stricte) : borne : $(lancer "$W/M3" test_lanceur_duree_a_la_borne_acceptee)"
echo "=== M4 (garde après les tâches) : borne : $(lancer "$W/M4" test_lanceur_duree_a_la_borne_acceptee)"
echo "    M4 : gardes paramétrées : $(lancer "$W/M4" test_lanceur_noyau_et_duree_valides_avant_le_manifeste)"
