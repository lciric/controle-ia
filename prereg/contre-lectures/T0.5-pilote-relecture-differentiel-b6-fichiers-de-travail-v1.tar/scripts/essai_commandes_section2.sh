#!/usr/bin/env bash
# Relecture du différentiel du brouillon 6 (V) : commandes de la section 2 de la procédure, brouillon 3, rejouées
# telles quelles sur un dépôt jetable et un dépôt distant local nu (le dépôt du programme n'est pas touché).
set -u
W="$1"; rm -rf "$W"; mkdir -p "$W"; cd "$W" || exit 1
export GIT_AUTHOR_NAME=t GIT_AUTHOR_EMAIL=t@invalid GIT_COMMITTER_NAME=t GIT_COMMITTER_EMAIL=t@invalid
git init -q --bare distant.git
git init -q -b main d && cd d
printf '* -text\n' > .gitattributes
printf 'donnees/\n' > .gitignore
mkdir -p prereg scripts donnees/run
echo 'echo amorce' > scripts/amorce_instance_t05.sh
echo '{"taches": []}' > donnees/run/taches-evaluation.json
(cd donnees/run && sha256sum taches-evaluation.json > taches-evaluation.json.sha256)
echo '{"taches": [1]}' > donnees/run/taches-entrainement.json
(cd donnees/run && sha256sum taches-entrainement.json > taches-entrainement.json.sha256)
git add .gitattributes .gitignore scripts && git add -f donnees/run/taches-evaluation.json donnees/run/taches-evaluation.json.sha256
echo prereg > prereg/T0.5-pilote-8B-v1.md; git add prereg/T0.5-pilote-8B-v1.md; git commit -qm code
echo x > prereg/T0.5-pilote-8B-v1.md.sha256; git add prereg/T0.5-pilote-8B-v1.md.sha256; git commit -qm scellement
git remote add origin ../distant.git; git push -q origin main
COMMIT=$(git log --diff-filter=A -1 --format=%H -- prereg/T0.5-pilote-8B-v1.md.sha256)
echo "COMMIT de scellement : $(git log -1 --format=%s "$COMMIT")"
echo "empreinte de l'amorce (blob au commit) : $(git show "$COMMIT":scripts/amorce_instance_t05.sh | sha256sum | cut -c1-16)… ; sur disque : $(sha256sum scripts/amorce_instance_t05.sh | cut -c1-16)…"
controle() {   # les deux lignes de la procédure, telles quelles
    T=$1
    git cat-file -e "$COMMIT:$T" && git cat-file -e "$COMMIT:$T.sha256"; local a=$?
    [ "$(git show "$COMMIT:$T" | sha256sum | cut -d' ' -f1)" = "$(git show "$COMMIT:$T.sha256" | cut -d' ' -f1)" ]; local b=$?
    echo "  présence : code $a ; sceau : code $b"
}
echo "(a) cas sain, tâches et sceau ajoutés de force au commit :"; controle donnees/run/taches-evaluation.json 2>/dev/null
echo "(b) tâches présentes sur disque, ajoutées de force APRÈS le commit de scellement :"
git add -f donnees/run/taches-entrainement.json donnees/run/taches-entrainement.json.sha256; git commit -qm apres
controle donnees/run/taches-entrainement.json 2>/dev/null
echo "(c) chemin absent de l'arbre :"; controle donnees/run/absent.json 2>/dev/null
echo "(d) contenu altéré au commit (sceau ancien) :"
git checkout -q "$COMMIT" 2>/dev/null; echo '{"taches": [2]}' > donnees/run/taches-evaluation.json
git add -f donnees/run/taches-evaluation.json; git commit -qm altere; COMMIT=$(git rev-parse HEAD)
controle donnees/run/taches-evaluation.json 2>/dev/null
echo "(e) sceau qui nomme un autre fichier de même contenu (la session ne lit que l'empreinte ; le script de l'instance, par le module, arrête) :"
git checkout -q main; cp donnees/run/taches-entrainement.json donnees/run/copie.json
(cd donnees/run && sha256sum taches-entrainement.json > copie.json.sha256); git add -f donnees/run/copie.json donnees/run/copie.json.sha256
git commit -qm copie; COMMIT=$(git rev-parse HEAD); controle donnees/run/copie.json 2>/dev/null
echo "(f) git ls-remote --exit-code :"
git ls-remote --exit-code origin refs/heads/calcul/t05-pilote-reel-v1 >/dev/null 2>&1; echo "  branche absente : code $?"
git push -q origin main:refs/heads/calcul/t05-pilote-reel-v1
git ls-remote --exit-code origin refs/heads/calcul/t05-pilote-reel-v1 >/dev/null 2>&1; echo "  branche présente : code $?"
git push -q origin main:refs/heads/x/calcul/t05-pilote-reel-v2
git ls-remote --exit-code origin refs/heads/calcul/t05-pilote-reel-v2 >/dev/null 2>&1; echo "  seule x/calcul/…-v2 présente, nom complet demandé : code $?"
git remote set-url origin ../injoignable.git
git ls-remote --exit-code origin refs/heads/calcul/t05-pilote-reel-v2 >/dev/null 2>&1; echo "  dépôt injoignable : code $?"
