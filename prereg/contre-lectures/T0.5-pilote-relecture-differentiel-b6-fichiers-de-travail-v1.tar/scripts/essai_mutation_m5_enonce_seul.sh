#!/usr/bin/env bash
# Relecture du différentiel du brouillon 6 (V) : M5. Dans une COPIE du lanceur (le dépôt n'est pas touché), la base
# « énoncé seul » de l'appariement est jouée AVANT les notations décisives ; les paires des propositions restent à leur
# place. Le test de l'ordre des étapes (Y-5) l'attrape-t-il ?
set -u
DEPOT=/home/user/controle-ia
W="$1"; rm -rf "$W"; mkdir -p "$W/tests" "$W/docs/sources"
cp -r "$DEPOT/docs/sources/invites-2606.08892-v1" "$W/docs/sources/"; cp -r "$DEPOT/src" "$W/src"
find "$W/src" -name __pycache__ -prune -exec rm -rf {} +
cp "$DEPOT/tests/test_pilote_a.py" "$DEPOT/tests/conftest.py" "$W/tests/"
L="$W/src/controle_ia/environnements/lancer_pilote_a.py"
"$DEPOT/.venv/bin/python" -I - "$L" <<'PY'
import sys, pathlib
p = pathlib.Path(sys.argv[1]); t = p.read_text(encoding="utf-8")
avant = '    noter("decisives")\n'
assert t.count(avant) == 1
t = t.replace(avant, (
    '    _j0 = next(j for j in config["juges"] if j["sert_a_l_appariement"])\n'
    '    _m0, _f0 = modeles_juges[_j0["nom"]]\n'
    '    _enonce = apparier(_m0, _f0, paires_enonce_seul(list(par_id.values())), config["lot_appariement"],\n'
    '                       jetons=jetons_jouet(_f0.tok) if config["mode"] == "jouet" else None, echeance=echeance)\n'
    + avant), 1)
ancien = ('            enonce = apparier(m_j, fmt_j, paires_enonce_seul(list(par_id.values())), config["lot_appariement"],\n'
          '                              jetons=jetons, echeance=echeance)\n')
assert t.count(ancien) == 1
t = t.replace(ancien, "            enonce = _enonce\n", 1)
p.write_text(t, encoding="utf-8")
PY
diff "$DEPOT/src/controle_ia/environnements/lancer_pilote_a.py" "$L" | sed 's/^/  [M5] /'
cd "$W/tests" && echo "M5 : ordre : $(PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$W/src" "$DEPOT/.venv/bin/python" -m pytest -q \
    -p no:cacheprovider --basetemp="$W/pytest-tmp" --rootdir="$W/tests" \
    "test_pilote_a.py::test_lanceur_ordre_des_etapes_arret_pendant_d" 2>&1 | tail -1)"
