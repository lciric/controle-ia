"""Relecture du différentiel du brouillon 6 (C) : l'expression de la garde de durée du lanceur du pilote, relue sur le
fichier du dépôt (l. 258) et appliquée à des valeurs limites ; la formule gelée au plafond."""
import math
import re
from pathlib import Path

src = Path("/home/user/controle-ia/src/controle_ia/environnements/lancer_pilote_a.py").read_text(encoding="utf-8")
ligne = next(l for l in src.splitlines() if "not 0 < duree <= DUREE_MAX_S" in l)
expr = re.search(r"if (.*):\s*$", ligne).group(1)
DUREE_MAX_S = 15_000
for duree in (600, 14_999.5, 15_000, 15_000.0, 15_001, 16_200, 0, -1, True, "À REMPLIR", float("nan"), float("inf")):
    print(f"{duree!r:>12} -> {'ARRÊT' if eval(expr) else 'passe'}")
formule = lambda d: min(15_000, math.ceil((1.2 * d + 7_200) / 60) * 60)
for d in (3_000, 6_000, 6_500, 6_501, 7_800):
    print(f"d = {d} s -> duree_max_s = {formule(d)} s ({formule(d) / 60:g} min)")
print("surveillance :", 6 * 3600 - 3_900, "s ; reste hors du run :", 6 * 3600 - 3_900 - 15_000, "s")
