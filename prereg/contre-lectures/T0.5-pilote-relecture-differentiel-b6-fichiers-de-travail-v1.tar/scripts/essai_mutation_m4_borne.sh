#!/usr/bin/env bash
# Relecture du différentiel du brouillon 6 (V) : M4 corrigée. La garde de durée (4 lignes : duree = …, if, raise et sa
# suite) est déplacée juste après le chargement des tâches, dans une COPIE du lanceur (le dépôt n'est pas touché).
# Question : le test de la borne (cas sain, 15 000 s) passe-t-il encore, et pour quelle raison ?
set -u
DEPOT=/home/user/controle-ia
W="$1"; rm -rf "$W"; mkdir -p "$W/tests" "$W/docs/sources"
cp -r "$DEPOT/docs/sources/invites-2606.08892-v1" "$W/docs/sources/"; cp -r "$DEPOT/src" "$W/src"
find "$W/src" -name __pycache__ -prune -exec rm -rf {} +
cp "$DEPOT/tests/test_pilote_a.py" "$DEPOT/tests/conftest.py" "$W/tests/"
L="$W/src/controle_ia/environnements/lancer_pilote_a.py"
"$DEPOT/.venv/bin/python" -I - "$L" <<'PY'
import sys, pathlib
p = pathlib.Path(sys.argv[1]); lignes = p.read_text(encoding="utf-8").splitlines(keepends=True)
i = next(k for k, l in enumerate(lignes) if l == '    duree = config["duree_max_s"]\n')
garde = lignes[i:i + 4]
assert garde[1].lstrip().startswith("if isinstance(duree") and "GardeArret" in garde[2] and garde[3].lstrip().startswith('f"')
del lignes[i:i + 4]
j = next(k for k, l in enumerate(lignes) if l == "    taches = charger_taches(chemin_taches)\n")
lignes[j + 1:j + 1] = garde
p.write_text("".join(lignes), encoding="utf-8")
PY
diff "$DEPOT/src/controle_ia/environnements/lancer_pilote_a.py" "$L" | sed 's/^/  [M4] /'
cd "$W/tests" || exit 1
for t in test_lanceur_duree_a_la_borne_acceptee test_lanceur_noyau_et_duree_valides_avant_le_manifeste; do
    echo "M4 : $t : $(PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$W/src" "$DEPOT/.venv/bin/python" -m pytest -q -p no:cacheprovider \
        --basetemp="$W/pytest-tmp" --rootdir="$W/tests" "test_pilote_a.py::$t" 2>&1 | tail -1)"
done
# l'exception que reçoit le test de la borne, sur le code du dépôt (témoin) et sur M4
for src in "$DEPOT/src" "$W/src"; do
    PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$src" "$DEPOT/.venv/bin/python" - "$W/tests" <<'PY'
import sys, subprocess, tempfile, pathlib
sys.path.insert(0, sys.argv[1])
import test_pilote_a as t
from controle_ia.environnements import lancer_pilote_a as lp
d = pathlib.Path(tempfile.mkdtemp())
for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@invalid"], ["config", "user.name", "t"]):
    subprocess.run(["git", "-C", str(d), *a], check=True)
(d / "README").write_text("x\n"); subprocess.run(["git", "-C", str(d), "add", "-A"], check=True)
subprocess.run(["git", "-C", str(d), "commit", "-qm", "init"], check=True)
try:
    lp.executer(dict(t._config_lanceur(), duree_max_s=15_000), d, "20261006-170011-x", None, "inexistant.json")
except Exception as e:
    print(f"  {lp.__file__.split('/src/')[0][-40:]} : {type(e).__name__}: {e}")
PY
done
