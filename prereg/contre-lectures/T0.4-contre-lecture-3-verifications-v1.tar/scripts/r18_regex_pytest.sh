#!/usr/bin/env bash
# r18 : expression régulière TESTS_REUSSIS (P0) au commit 9aaf4a5, contre des sorties réelles de pytest 9.1.1 (-q), comme
# sur l'instance (sortie et erreurs dans le même fichier, dernière ligne lue par `executer`), et lecture par `lire`.
# Cas : sain, avertissement, sauté, désélectionné, attendu en échec, inattendu réussi, erreur, sous-tests, sortie parasite
# écrite à la fin du processus (atexit), et nombre différent de 170 (ici : petite suite, tests_attendus ajusté).
set -u
W="$1"; D="$W/r18"; rm -rf "$D"; mkdir -p "$D"; cd "$D"
. /home/user/controle-ia/.venv/bin/activate
cas() {   # $1 = nom ; $2 = contenu du fichier de test ; $3 = options pytest supplémentaires
    rm -rf t; mkdir t; printf '%b' "$2" > t/test_x.py
    eval "python -m pytest -q -p no:cacheprovider $3 t" > "sortie-$1.txt" 2>&1
    PYTHONPATH="$W/copie/src" python - "$1" "sortie-$1.txt" <<'EOF'
import sys, re
from controle_ia.harnais import validation_reelle as V
texte = open(sys.argv[2], encoding="utf-8").read()
derniere = texte.strip().splitlines()[-1] if texte.strip() else ""
m = V.TESTS_REUSSIS.match(derniere)
n = int(m.group(1)) if m else None
lecture = V.lire({"tests_instance": {"derniere_ligne": derniere}}, dict(V.CONFIG_REELLE, tests_attendus=n or 3))
ancien = bool(re.search(r"\d+ passed", derniere)) and not re.search(r"failed|error", derniere)
print(f"{sys.argv[1]:22s} | dernière ligne : {derniere!r:62s} | lire : {lecture['tests_instance']:9s} | champ « reussis » : {ancien}")
EOF
}
OK='def test_a():\n    pass\ndef test_b():\n    pass\ndef test_c():\n    pass\n'
cas sain "$OK" ""
cas avertissement "import warnings\ndef test_a():\n    pass\ndef test_b():\n    pass\ndef test_w():\n    warnings.warn(UserWarning('x'))\n" ""
cas saute "import pytest\n$OK\n@pytest.mark.skip\ndef test_s():\n    pass\n" ""
cas deselectionne "$OK" "--deselect t/test_x.py::test_c"
cas attendu_echec "import pytest\n$OK\n@pytest.mark.xfail\ndef test_f():\n    assert False\n" ""
cas inattendu_reussi "import pytest\n$OK\n@pytest.mark.xfail\ndef test_f():\n    pass\n" ""
cas erreur "import pytest\n$OK\n@pytest.fixture\ndef f():\n    raise RuntimeError\ndef test_e(f):\n    pass\n" ""
cas sous_tests "def test_a():\n    pass\ndef test_b():\n    pass\ndef test_st(subtests):\n    with subtests.test('x'):\n        pass\n" ""
cas sortie_parasite "import atexit, sys\natexit.register(lambda: print('[W] avertissement de fin de processus', file=sys.stderr))\n$OK" ""
