"""Complément d'exp8 : run A arrêté pendant la phase de débit (panne simulée : generer_lot de la phase de débit lève),
donc sans resume.json ; puis run B en rejeu de A : exiger_rejeu_compatible ne vérifie pas que A est complet."""
import subprocess, tempfile, time
from pathlib import Path
from controle_ia.harnais import validation_reelle as V

d = Path(tempfile.mkdtemp())
for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"]):
    subprocess.run(["git", "-C", str(d), *a], check=True)
(d / "README").write_text("x\n"); (d / ".gitignore").write_text("donnees/\n")
git = lambda: (subprocess.run(["git", "-C", str(d), "add", "-A"], check=True), subprocess.run(["git", "-C", str(d), "commit", "-qm", "e"], check=True))
git()
cfg = V.CONFIG_REPETITION
vrai = V.generer_lot
def panne(*a, **k):
    raise RuntimeError("panne simulée (mémoire) pendant le débit")
V.generer_lot = panne
try:
    V.executer(d, "20261004-210400-repetition-jouet", entropie=9, config=cfg, verifier_import=False)
except Exception as e:
    print("run A :", type(e).__name__, str(e)[:60])
finally:
    V.generer_lot = vrai
git()
t0 = time.perf_counter()
try:
    V.executer(d, "20261004-210500-repetition-jouet", config=cfg, rejeu_de="20261004-210400-repetition-jouet", verifier_import=False)
except Exception as e:
    print(f"run B : {type(e).__name__} après {time.perf_counter() - t0:.1f} s (run complet) : {str(e)[:110]}")
B = d / "diag/20261004-210500-repetition-jouet"; print("run B créé :", (d / "runs/20261004-210500-repetition-jouet").exists(), "; fichiers de diag de B :", sorted(p.name for p in B.iterdir() if p.suffix == ".json") if B.exists() else "aucun")
