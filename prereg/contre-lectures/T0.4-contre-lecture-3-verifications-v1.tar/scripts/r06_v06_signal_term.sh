#!/usr/bin/env bash
# V06 : délai externe (timeout --signal=TERM) sur la répétition jouet lancée par la ligne de commande, dans une copie
# propre ; sorties hors du dépôt ; chaque essai committé avant le suivant (garde d'arbre propre).
W="$1"; rm -rf "$W/v06" "$W/v06-sorties"; git -c advice.detachedHead=false clone -q "$W/copie" "$W/v06"; mkdir -p "$W/v06-sorties"; cd "$W/v06" && git -c advice.detachedHead=false checkout -q 9aaf4a55dd334993ff50e92699fb5fb516a0a51b
. /home/user/controle-ia/.venv/bin/activate
for delai in 4 9 11 13; do
  id=20261004-2201$(printf %02d $delai)-repetition-jouet
  PYTHONPATH=src timeout --signal=TERM --kill-after=30s ${delai}s python -m controle_ia.harnais.validation_reelle \
      --repetition-jouet --run-id $id > /dev/null 2> "$W/v06-sorties/err-$delai.txt"
  echo "délai ${delai}s : code $?"; tail -1 "$W/v06-sorties/err-$delai.txt"
  python -c "
import json, sys; from pathlib import Path
p = Path('diag') / '$id' / 'arret.json'
a = json.loads(p.read_text())['resultat'] if p.exists() else None
print('  arret.json :', None if a is None else (a['phase'], a['motif'][:60], sorted(a['partiel'])))"
  git add -A && git -c user.email=t@x.invalid -c user.name=t commit -qm "essai TERM $delai s"
done
# constat : pour chaque essai, résumé scellé présent ? (un TERM arrivé après l'écriture du résumé donne le code 124 sans arret.json)
for delai in 4 9 11 13; do
  id=20261004-2201$(printf %02d $delai)-repetition-jouet
  python -c "
import json; from pathlib import Path
p = Path('diag') / '$id' / 'resume.json'
print('  $id : resume.json', ('présent, duree_s = %.1f s' % json.loads(p.read_text())['resultat']['duree_s']) if p.exists() else 'absent')"
done
