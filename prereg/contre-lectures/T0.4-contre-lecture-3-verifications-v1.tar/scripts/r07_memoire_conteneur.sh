#!/usr/bin/env bash
# r07 : garde de mémoire vive (exiger_memoire_vive, commit 9aaf4a5) dans ce conteneur : groupe de contrôle du processus
# (/proc/self/cgroup), plafond de ce groupe et de ses ancêtres, et ce que la garde rend (elle lit la racine).
# Usage : bash r07_memoire_conteneur.sh <espace de travail contenant copie/>
W="$1"
echo "/proc/self/cgroup :"; cat /proc/self/cgroup
echo "memory.max à la racine :"; cat /sys/fs/cgroup/memory.max 2>&1
echo "v1 (racine) :"; cat /sys/fs/cgroup/memory/memory.limit_in_bytes 2>&1
P=$(grep ":memory:" /proc/self/cgroup | cut -d: -f3)
echo "groupe mémoire du processus : $P"
d="$P"; while [ -n "$d" ] && [ "$d" != "/" ]; do f=/sys/fs/cgroup/memory$d/memory.limit_in_bytes; printf '%s : ' "$f"; cat "$f" 2>&1; d=$(dirname "$d"); done
cd "$W/copie" && . /home/user/controle-ia/.venv/bin/activate && PYTHONPATH=src python -c "
from controle_ia.harnais import validation_reelle as V
print('exiger_memoire_vive(1) ici :', V.exiger_memoire_vive(1))"
