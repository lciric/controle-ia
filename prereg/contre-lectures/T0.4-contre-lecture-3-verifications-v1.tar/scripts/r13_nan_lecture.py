"""r13 (rejeu adapté de V13, contre-lecture 2) : valeurs illisibles (NaN) au commit 9aaf4a5.
(a) écart NaN à la couche du milieu : bilan, lecture et garde ;
(b) contrôle négatif : NaN à une couche, valeur finie à une autre ; l'ordre des couches change-t-il l'issue ?"""
import math
from controle_ia.gardes import GardeArret
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais.episode import Episode, bilan_controle_negatif

NAN = float("nan")
cn = V.CONFIG_REELLE["controle_negatif"]

def rapport(ecarts, zones, n=1):
    prof = lambda m: {"jetons": 9, "max": m, "contexte": {"jetons": 4, "max": 1e-7, "nuls": 0},
                      "generee": {"jetons": 5, "max": m, "nuls": 0}}
    cles = [f"0,{t}" for t in range(n)]
    return {"tolerance": 1e-4,
            "ecarts": {k: dict(ecarts) for k in cles},
            "controle_negatif_zone_generee": {k: {c: dict(v) for c, v in zones.items()} for k in cles},
            "profils": {k: {c: prof(e) for c, e in ecarts.items()} for k in cles},
            "longueurs_contexte": {k: 4 for k in cles}, "positions_capturees": {k: 9 for k in cles},
            "lignes": {k: {"ligne": 1, "taille_lot": 8, "remplissage": 3, "finie_avant": True} for k in cles},
            "sondes": {k: {"tableaux_distincts": True, "ulp_vu": True} for k in cles}}

z = lambda m: {"max": m, "au_dessus": 5, "positions": 5}
# (a)
r = rapport({7: 2e-7, 15: NAN, 23: 3e-7}, {7: z(1.2), 15: z(1.3), 23: z(1.1)}, n=12)
sorties = [(Episode("episode-1", 1, 12, []), {}, r)]
b = V.bilan_phase(sorties, {"tolerance": 1e-4}, cn)
print("(a) bilan : ecart_max", b["ecart_max"], "; ecart_non_fini", b["ecart_non_fini"], "; max_zone_generee", b["max_zone_generee"])
l = V.lire({"format": {"verifie": True}, "logique": {"equivalence": b}}, V.CONFIG_REELLE)
print("    lire :", l["logique_equivalence"], "/", l["logique_controle_negatif"])
try:
    V.appliquer_gardes(sorties, b, "logique", cn); print("    garde : passe")
except GardeArret as e:
    print("    garde : arrêt —", str(e)[:100])
# (b) une action, NaN au contrôle négatif d'une couche ; ordre des couches
for ordre in ((7, 15, 23), (15, 7, 23)):
    zones = {c: z(NAN if c == 15 else 1.2) for c in ordre}
    bc = bilan_controle_negatif([{"tolerance": 1e-4, "controle_negatif_zone_generee": {"0,0": zones}}], 4)
    print(f"(b) couches dans l'ordre {ordre}, NaN à la couche 15 : passent={bc['passent']} echecs={bc['echecs']} "
          f"min_des_maxima={bc['min_des_maxima']}")
print("min(1.2, nan) =", min(1.2, NAN), "; min(nan, 1.2) =", min(NAN, 1.2))
