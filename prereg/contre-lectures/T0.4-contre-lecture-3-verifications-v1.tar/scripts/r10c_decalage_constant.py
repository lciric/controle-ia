"""r10c : défaut de positions D2 généralisé, au commit 9aaf4a5. Les positions de génération reçoivent un décalage
constant Δ (prérempli et décodage cohérents), la passe unique reste juste. Les rotations de position étant relatives,
seul l'arrondi des angles en simple précision change. On mesure, phase de logique seule (simple précision, noyau math,
configuration de répétition jouet), l'écart maximal et les maxima par zone, puis la ligne de la table gelée que
`lire` applique. Δ = 0 est le cas sain."""
import inspect, textwrap
from controle_ia.harnais import episode as E
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais.activations import couches_par_defaut
from controle_ia.manifeste import graines as G

cfg = V.CONFIG_REPETITION
c, cn = cfg["logique"], cfg["controle_negatif"]
V.regler_determinisme(1, "cpu")
gr = G(V.taches(cfg), entropie=12345)
m, tok = V.charger(cfg, None, c["dtype"], gr)
print("modèle jouet :", type(m).__name__, "; rope :", getattr(m.config, "rope_parameters", None)
      or getattr(m.config, "rope_theta", None))
fmt, _ = V.format_du_modele(m, tok, cfg)
couches = couches_par_defaut(m.config.num_hidden_layers)
source = inspect.getsource(E.generer_lot)
vrai = E.generer_lot
for delta in (0, 2000, 20000, 200000):
    code = source.replace("positions = (masque.cumsum(dim=1) - 1).clamp(min=0)",
                          f"positions = (masque.cumsum(dim=1) - 1).clamp(min=0) + {delta}")
    espace = dict(E.__dict__); exec(textwrap.dedent(code), espace)
    E.generer_lot = espace["generer_lot"]
    try:
        sorties, plan = V.jouer_phase(m, fmt, c, gr, "logique", couches, chrono={})
    finally:
        E.generer_lot = vrai
    b = V.bilan_phase(sorties, c, cn)
    l = V.lire({"format": {"verifie": True}, "logique": {"equivalence": b}}, cfg)
    print(f"Δ = {delta:6d} : écart max {b['ecart_max']:.3g} ; contexte {b['max_contexte']:.3g} ; zone générée "
          f"{b['max_zone_generee']:.3g} ; rapport {b['max_zone_generee'] / b['max_contexte']:.2f} ; lecture P2 : "
          f"{l['logique_equivalence']}")
