"""r10 (rejeu adapté de r10/exp10, contre-lectures 1 et 2) au commit 9aaf4a5, de bout en bout par V.executer
(configuration de répétition jouet, dépôt jetable), avec deux défauts de positions injectés dans generer_lot :
  D1 (exp10) : positions des jetons décodés décalées de +1 ;
  D2 (nouveau) : positions qui ignorent le remplissage à gauche (arange sur la longueur remplie) ; décalage constant par
      ligne remplie, en prérempli comme en décodage. Les rotations de position (RoPE) étant relatives, le défaut n'a
      d'effet qu'au niveau de l'arrondi : la garde le voit-elle, et comment la lecture par zones le classe-t-elle ?
Pour chacun : arrêt ou non, écart maximal, maxima par zone, lecture partielle (P2), et ligne de la table gelée."""
import inspect, json, subprocess, tempfile, textwrap
from pathlib import Path
from controle_ia.gardes import GardeArret
from controle_ia.harnais import episode as E
from controle_ia.harnais import validation_reelle as V

def depot():
    d = Path(tempfile.mkdtemp())
    for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"]):
        subprocess.run(["git", "-C", str(d), *a], check=True)
    (d / "README").write_text("x\n"); (d / ".gitignore").write_text("donnees/\n")
    subprocess.run(["git", "-C", str(d), "add", "-A"], check=True)
    subprocess.run(["git", "-C", str(d), "commit", "-qm", "init"], check=True)
    return d

def table(b):
    x, mc, mg = b["ecart_max"], b["max_contexte"], b["max_zone_generee"]
    if x <= 1e-4:
        return "≤ 1e-4 : P2 conforme (si couverture)"
    if x <= 1e-2 and mc >= 1e-5 and mg >= 1e-5 and max(mc, mg) <= 10 * min(mc, mg):
        return "« P2 : écart ≤ 1e-2, diffus » → non concluant : précision probable, pas logique"
    return "« P2 contraire » → logique du harnais non validée"

source = inspect.getsource(E.generer_lot)
DEFAUTS = {
    "D1 décodage +1": source.replace("suivante = positions[:, -1:] + 1", "suivante = positions[:, -1:] + 2"),
    "D2 positions sans retrait du remplissage": source.replace(
        "positions = (masque.cumsum(dim=1) - 1).clamp(min=0)", "positions = torch.arange(L).expand(B, L).clone()"),
}
vrai = E.generer_lot

for nom, code in DEFAUTS.items():
    assert code != source, nom
    espace = dict(E.__dict__); exec(textwrap.dedent(code), espace)
    E.generer_lot = espace["generer_lot"]
    d = depot()
    run = "20261004-200000-repetition-jouet"
    try:
        V.executer(d, run, entropie=12345, config=V.CONFIG_REPETITION, verifier_import=False)
        issue = "AUCUN ARRÊT : run complet"
        corps = json.loads((d / "diag" / run / "resume.json").read_text())["resultat"]
        lecture, b = corps["lecture"], corps["logique"]["equivalence"]
    except GardeArret as e:
        issue = "arrêt : " + str(e)[:110] + " …"
        a = json.loads((d / "diag" / run / "arret.json").read_text())["resultat"]
        lecture, b = a["partiel"]["lecture_partielle"], a["partiel"]["logique"]["equivalence"]
    finally:
        E.generer_lot = vrai
    print(f"\n== {nom}\n   {issue}")
    print(f"   logique : écart max {b['ecart_max']:.3g} ; contexte {b['max_contexte']:.3g} ; zone générée "
          f"{b['max_zone_generee']:.3g} ; couverture {b['couverture']}")
    print(f"   lecture P2 : {lecture['logique_equivalence']} ; P3 : {lecture['logique_controle_negatif']} ; "
          f"audit : {lecture['audit_symetrie']}")
    print(f"   ligne de la table gelée : {table(b)}")
    if "production_equivalence" in lecture:
        print(f"   production : {lecture['production_equivalence']}")
