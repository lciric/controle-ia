#!/usr/bin/env bash
# r05 (rejeu adapté de V05, contre-lecture 2) : chaîne amorce → script d'instance au commit 9aaf4a5, en mode jouet, contre
# un dépôt nu de l'espace de travail (aucune poussée vers le dépôt du programme). Trois scénarios :
#   sain       : COMMIT = 9aaf4a5 ;
#   tests_ko   : COMMIT = 9aaf4a5 + un test qui échoue (traces poussées ?) ;
#   gitignore  : COMMIT = 9aaf4a5 + « donnees/ » retiré de .gitignore (fichier hors des chemins gelés) : le run B
#                trouve-t-il l'arbre non propre après le run A ?
# Usage : bash r05_chaine_amorce_jouet.sh <espace de travail contenant copie/>
set -u
W="$1"; C=9aaf4a55dd334993ff50e92699fb5fb516a0a51b
scenario() {   # $1 = nom ; $2 = commande de modification (vide : aucune)
    local S="$W/r05-$1"; rm -rf "$S"; mkdir -p "$S"; cd "$S"
    git clone -q --bare "$W/copie" depot.git
    local COMMIT="$C"
    if [ -n "$2" ]; then
        git -c advice.detachedHead=false clone -q depot.git prep; cd prep; git -c advice.detachedHead=false checkout -q "$C"
        eval "$2"; git add -A; git -c user.email=t@x.invalid -c user.name=t commit -qm "scénario $1"
        COMMIT=$(git rev-parse HEAD); git push -q origin "HEAD:refs/heads/scenario-$1"; cd "$S"
    fi
    git -C depot.git show "$COMMIT":scripts/amorce_instance_t04.sh > amorce.sh
    echo "=== scénario $1 : COMMIT=$COMMIT ; amorce $(sha256sum amorce.sh | cut -c1-16)…"
    env COMMIT="$COMMIT" GH_TOKEN=factice HF_TOKEN=factice DEPOT_URL="file://$S/depot.git" RACINE_AMORCE="$S" \
        MODE=jouet VENV_EXISTANT=/home/user/controle-ia/.venv bash amorce.sh > amorce.log 2>&1
    echo "code amorce : $?"
    grep -E "^AMORCE|tests :|tests en échec|ARRÊT|run A|run B|poussée|fin :" amorce.log | grep -v '^\s*"' | head -20
    echo "--- branche calcul/t04-validation dans le dépôt nu :"
    if git -C depot.git rev-parse -q --verify refs/heads/calcul/t04-validation >/dev/null; then
        git -C depot.git log --format='    %s' "$COMMIT"..calcul/t04-validation
        git -C depot.git ls-tree -r --name-only calcul/t04-validation | grep -E '^traces/' | sed 's/^/    /'
    else
        echo "    absente (rien de poussé)"
    fi
    for f in t04/run-B.err t04/run-A.err; do [ -s "$f" ] && { echo "--- $f :"; tail -3 "$f" | sed 's/^/    /'; }; done
    cd "$W"
}
scenario sain ""
scenario tests_ko "printf 'def test_echec_volontaire():\n    assert False\n' > tests/test_echec_volontaire.py"
scenario gitignore "sed -i '/^donnees\\//d' .gitignore"
