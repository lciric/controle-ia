"""r17 : branche « P4 contraire, P2 et P3 conformes » de la table gelée (« réserve et nœud, au vu du repère de
précision »). Au commit 9aaf4a5, les gardes de production s'appliquent juste après la génération (N-10) : que reste-t-il
pour lire cette branche ? Répétition jouet, de bout en bout par V.executer ; artefact : écart de demi-précision
au-dessus du seuil de production, obtenu en abaissant la tolérance de production à 1e-6 (le jouet donne 1,9e-3)."""
import json, subprocess, tempfile
from pathlib import Path
from controle_ia.gardes import GardeArret
from controle_ia.harnais import validation_reelle as V

d = Path(tempfile.mkdtemp())
for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"]):
    subprocess.run(["git", "-C", str(d), *a], check=True)
(d / "README").write_text("x\n"); (d / ".gitignore").write_text("donnees/\n")
subprocess.run(["git", "-C", str(d), "add", "-A"], check=True); subprocess.run(["git", "-C", str(d), "commit", "-qm", "i"], check=True)
cfg = dict(V.CONFIG_REPETITION, production=dict(V.CONFIG_REPETITION["production"], tolerance=1e-6))
run = "20261004-202000-repetition-jouet"
try:
    V.executer(d, run, entropie=12345, config=cfg, verifier_import=False)
    print("AUCUN ARRÊT")
except GardeArret as e:
    print("arrêt :", str(e)[:120], "…")
a = json.loads((d / "diag" / run / "arret.json").read_text())["resultat"]
p = a["partiel"].get("production", {})
print("phase :", a["phase"])
print("clés de la production dans arret.json :", sorted(p))
print("repère de précision présent :", "repere_precision" in p, "; rejeu dans le processus présent :", "rejeu_en_processus" in p,
      "; stockage présent :", "stockage" in p, "; débit (phase 3) présent :", "debit" in a["partiel"])
print("lecture partielle :", a["partiel"]["lecture_partielle"])
