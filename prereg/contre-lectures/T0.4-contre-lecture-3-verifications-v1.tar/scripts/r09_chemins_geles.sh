#!/usr/bin/env bash
# r09 (rejeu adapté de V09, contre-lecture 2) : périmètre de exiger_code_cite au commit 9aaf4a5 (CHEMINS_GELES).
# Pour chaque fichier : copie jetable, modification committée, appel de la garde avec un préenregistrement qui cite 9aaf4a5.
# Puis des fichiers hors du périmètre qui pèsent sur l'exécution sur l'instance : conftest.py et pytest.ini à la racine
# (lus par pytest avant pyproject.toml), .gitignore (propreté de l'arbre entre A et B).
set -uo pipefail
W="$1"
C=9aaf4a55dd334993ff50e92699fb5fb516a0a51b
printf -- '- Commit du code d'"'"'analyse : `%s`\n' "$C" > "$W/r09-prereg.md"
. /home/user/controle-ia/.venv/bin/activate
essai() {   # $1 = étiquette ; $2 = commande de modification (dans la copie)
    rm -rf "$W/r09"; git -c advice.detachedHead=false clone -q "$W/copie" "$W/r09"; cd "$W/r09"; git -c advice.detachedHead=false checkout -q "$C"
    eval "$2"
    git add -A; git -c user.email=t@x.invalid -c user.name=t commit -qm "modif $1" >/dev/null
    PYTHONPATH=src python - "$1" <<EOF
import sys
from pathlib import Path
from controle_ia.harnais.validation_reelle import exiger_code_cite
from controle_ia.gardes import GardeArret
try:
    exiger_code_cite(Path('.'), Path('$W/r09-prereg.md'))
    print(f"{sys.argv[1]:45s} -> la garde PASSE")
except GardeArret as e:
    print(f"{sys.argv[1]:45s} -> refus : {e}")
EOF
    cd "$W"
}
essai "src/ (module modifié)"            "echo '# x' >> src/controle_ia/harnais/episode.py"
essai "tests/ (test modifié)"             "echo '# x' >> tests/test_prereg.py"
essai "scripts/validation_t04_instance.sh" "echo 'echo x' >> scripts/validation_t04_instance.sh"
essai "scripts/amorce_instance_t04.sh"     "echo 'echo x' >> scripts/amorce_instance_t04.sh"
essai "requirements-cpu.txt (torch)"      "sed -i 's/^torch==2.14.1/torch==2.15.0/' requirements-cpu.txt"
essai "requirements-gpu.txt"              "echo 'nvidia-cudnn-cu12==9.0' >> requirements-gpu.txt"
essai "pyproject.toml"                    "echo '# x' >> pyproject.toml"
essai "conftest.py à la racine (nouveau)" "printf 'import pytest\n' > conftest.py"
essai "pytest.ini à la racine (nouveau)"  "printf '[pytest]\naddopts = -p no:warnings\n' > pytest.ini"
essai ".gitignore (donnees/ retiré)"      "sed -i '/^donnees\\//d' .gitignore"
essai "requirements-pilotage.txt"         "echo 'x==1' >> requirements-pilotage.txt"
# pytest lit-il un conftest.py ou un pytest.ini à la racine ? (preuve d'effet, dans une copie)
rm -rf "$W/r09"; git -c advice.detachedHead=false clone -q "$W/copie" "$W/r09"; cd "$W/r09"; git -c advice.detachedHead=false checkout -q "$C"
printf '[pytest]\nconsole_output_style = classic\n' > pytest.ini
printf 'def pytest_collection_modifyitems(config, items):\n    print("\\nCONFTEST RACINE LU,", len(items), "tests")\n' > conftest.py
PYTHONPATH=src python -m pytest -p no:cacheprovider --co -q 2>&1 | grep -E "CONFTEST|configfile|tests collected" | head -3
PYTHONPATH=src python -m pytest -p no:cacheprovider --co 2>&1 | grep -iE "configfile" | head -2
