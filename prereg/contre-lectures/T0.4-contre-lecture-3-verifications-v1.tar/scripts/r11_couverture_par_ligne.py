"""r11 (rejeu adapté de V11, contre-lecture 2) : couverture de P2 mesurée sur les actions comparées (code 9aaf4a5).
Répétition jouet (logique), entropie 12345 ; échantillon sur la ligne 3, jamais remplie à gauche (V11) : la couverture
doit maintenant manquer (« actions_remplies » = 0) et la lecture de P2 dire « non concluant »."""
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais import episode as E
from controle_ia.harnais.activations import couches_par_defaut
from controle_ia.manifeste import graines as G

cfg = V.CONFIG_REPETITION
cn = cfg["controle_negatif"]
V.regler_determinisme(1, "cpu")
gr = G(V.taches(cfg), entropie=12345)
c = cfg["logique"]
m, tok = V.charger(cfg, None, c["dtype"], gr)
fmt, _ = V.format_du_modele(m, tok, cfg)
couches = couches_par_defaut(m.config.num_hidden_layers)
for ech in ([1, 2], [3]):
    c_ = dict(c, episodes_equivalence=ech)
    sorties, plan = V.jouer_phase(m, fmt, c_, gr, "logique", couches, chrono={})
    bilan = V.bilan_phase(sorties, c_, cn)
    lecture = V.lire({"format": {"verifie": True}, "logique": {"equivalence": bilan}}, cfg)
    print(f"échantillon {ech} : couverture {bilan['couverture']} ; domaine {bilan['domaine']} ; "
          f"lecture P2 : {lecture['logique_equivalence']} ; P3 : {lecture['logique_controle_negatif']} "
          f"({bilan['controle_negatif']['comparables']} comparables)")
    print("   zéros par couche :", bilan["zeros"])
