#!/usr/bin/env bash
# r19 : commande de lancement de la procédure (brouillon 3), sans rien lancer.
# (a) l'argument « --args -c … » développé localement, puis exécuté comme sur l'instance (bash -c) dans un dossier
#     jetable : l'amorce reconstruite est-elle identique à l'octet près à celle du commit ? (« /root » remplacé)
# (b) la garde de calcul (.claude/hooks/garde_calcul.py) accepte-t-elle la commande, avec le registre go.md du dépôt ?
# (c) GNU timeout : formes « 155m », « 345m », « 5m » acceptées ; « 2h35m » refusée.
set -u
W="$1"; C=9aaf4a55dd334993ff50e92699fb5fb516a0a51b; D="$W/r19"; rm -rf "$D"; mkdir -p "$D"
cd "$W/copie"
ATTENDU=$(git show "$C":scripts/amorce_instance_t04.sh | sha256sum | cut -d' ' -f1)
ARG="echo $(git show "$C":scripts/amorce_instance_t04.sh | base64 -w0) | base64 -d > $D/amorce.sh && sha256sum $D/amorce.sh"
echo "(a) longueur de l'argument -c : ${#ARG} caractères"
bash -c "$ARG" | cut -d' ' -f1 | { read -r OBTENU; echo "    empreinte reconstruite $OBTENU ; attendue $ATTENDU ; identique : $([ "$OBTENU" = "$ATTENDU" ] && echo oui || echo NON)"; }
COMMANDE="GO_ID=GO-2026-10-04-08 vastai create instance 123456 --image python:3.11-bookworm --disk 80 --env \"-e COMMIT=\$COMMIT -e HF_TOKEN=\$HF_TOKEN -e GH_TOKEN=\$CONTROLE_IA_GITHUB_TOKEN\" --entrypoint bash --args -c \"echo \$(git show \"\$COMMIT\":scripts/amorce_instance_t04.sh | base64 -w0) | base64 -d > /root/amorce.sh && bash /root/amorce.sh\""
python3 - "$COMMANDE" <<'EOF'
import json, subprocess, sys
entree = json.dumps({"tool_input": {"command": sys.argv[1]}})
r = subprocess.run([sys.executable, "/home/user/controle-ia/.claude/hooks/garde_calcul.py"], input=entree, text=True,
                   capture_output=True)
print(f"(b) garde de calcul : code {r.returncode} ({'acceptée' if r.returncode == 0 else 'bloquée'}) {r.stderr.strip()}")
r = subprocess.run([sys.executable, "/home/user/controle-ia/.claude/hooks/garde_calcul.py"],
                   input=json.dumps({"tool_input": {"command": sys.argv[1].replace("GO_ID=GO-2026-10-04-08 ", "")}}),
                   text=True, capture_output=True)
print(f"    sans GO : code {r.returncode} ({r.stderr.strip()[:90]})")
EOF
for d in 155m 345m 5m 2h35m; do timeout "$d" true 2>/dev/null; c=$?; echo "(c) timeout $d true → code $c ($([ $c -eq 0 ] && echo acceptée || echo refusée))"; done
