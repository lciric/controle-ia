"""r1c (rejeu adapté de r1c, contre-lecture 2) au commit 9aaf4a5 : en demi-précision (jouet, répétition, entropie 12345),
positions de la zone générée dont l'écart décalé est ≤ 0,1 (rejeu du constat de N-14), puis bilan du contrôle négatif de
phase (`bilan_controle_negatif`) : actions comparables, courtes, échecs ; et effet du seuil de 4 comparaisons."""
import numpy as np
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais import episode as E
from controle_ia.harnais.activations import couches_par_defaut, ecarts_par_jeton

from controle_ia.manifeste import graines as G

cfg = V.CONFIG_REPETITION
cn = cfg["controle_negatif"]
V.regler_determinisme(1, "cpu")
gr = G(V.taches(cfg), entropie=12345)
c = cfg["production"]
m, tok = V.charger(cfg, None, c["dtype"], gr)
fmt, _ = V.format_du_modele(m, tok, cfg)
couches = couches_par_defaut(m.config.num_hidden_layers)
vrai = E.relire_crochets_lot
capt = []
def espion(brut, k, lc, plan, n):
    r = vrai(brut, k, lc, plan, n); capt.append((lc, r)); return r
E.relire_crochets_lot = espion
try:
    sorties, plan = V.jouer_phase(m, fmt, c, gr, "production", couches)
finally:
    E.relire_crochets_lot = vrai
ordre = [(k, i, t) for lot in plan for t in range(c["T"]) for i in range(c["N"]) for k in lot if k in c["episodes_equivalence"]]
par_ep = {int(ep.identifiant.split("-")[1]): (ep, acts) for ep, acts, _ in sorties}
sous = 0
for (k, i, t), (lc, ag) in zip(ordre, capt):
    ep, acts = par_ep[k]
    tr = ep.transcriptions[i]
    for couche in couches:
        g, p = ag[couche], acts[i][couche]
        if g.shape[0] <= lc + 1:
            continue
        e = ecarts_par_jeton(g[lc + 1:], p[lc: g.shape[0] - 1])
        for j in np.where(e <= c["tolerance"])[0]:
            sous += 1
            n = lc + 1 + j
            print(f"épisode {k}, action ({i}, {t}), couche {couche} : position {n} ({g.shape[0] - lc} positions générées "
                  f"relues) ; écart décalé {e[j]:.4f} ; {tok.decode([tr.ids[n - 1]])!r} → {tok.decode([tr.ids[n]])!r}")
print("positions sous 0,1 :", sous)
rapports = [r for _, _, r in sorties if r["ecarts"]]
for pm in (1, 2, 4, 8):
    b = E.bilan_controle_negatif(rapports, pm)
    print(f"positions_min = {pm} : comparables {b['comparables']}, passent {b['passent']}, courtes {b['courtes']}, "
          f"échecs {b['echecs']}, minimum des maxima {b['min_des_maxima']:.3f}")
