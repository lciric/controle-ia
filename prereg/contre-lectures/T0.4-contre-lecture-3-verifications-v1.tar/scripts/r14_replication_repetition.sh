#!/usr/bin/env bash
# r14 (rejeu adapté de V14, contre-lecture 2) : réplication indépendante de la répétition jouet citée
# (run 20261004-131905-repetition-jouet, résumé scellé 3bd25dde…, commit 9aaf4a5) sur cette machine, même entropie,
# depuis une copie à HEAD (chemins gelés identiques à 9aaf4a5) ; puis comparaison par `comparer_runs` (P7) et
# comparaison des bilans (couverture, zéros, contrôle négatif, domaine, écart maximal, maxima par zone).
set -u
W="$1"; rm -rf "$W/r14"; git -c advice.detachedHead=false clone -q /home/user/controle-ia "$W/r14"; cd "$W/r14"
echo "HEAD $(git rev-parse --short HEAD) ; diff des chemins gelés avec 9aaf4a5 :"
git diff --stat 9aaf4a5 HEAD -- src tests scripts requirements-cpu.txt requirements-gpu.txt pyproject.toml; echo "(vide)"
. /home/user/controle-ia/.venv/bin/activate
E=$(python -c "import json;m=json.load(open('runs/20261004-131905-repetition-jouet/manifeste.json'));print(next(iter(m['graines'].values()))['entropie'])")
B=20261004-235900-repetition-jouet
PYTHONPATH=src python -m controle_ia.harnais.validation_reelle --repetition-jouet --entropie "$E" --run-id "$B" > /dev/null
git add -A runs diag >/dev/null; git -c user.email=t@x.invalid -c user.name=t commit -qm "r14" >/dev/null
PYTHONPATH=src python - <<EOF
import json
from controle_ia.harnais import validation_reelle as V
c = V.comparer_runs(".", "20261004-131905-repetition-jouet", "$B")
print("comparer_runs (A = run cité, B = réplication) :", c["identique"], c["lecture"], c["differences"])
a = json.load(open("diag/20261004-131905-repetition-jouet/resume.json"))["resultat"]
b = json.load(open("diag/$B/resume.json"))["resultat"]
diff = [(ph, k) for ph in ("logique", "production") for k in a[ph]["equivalence"] if a[ph]["equivalence"][k] != b[ph]["equivalence"][k]]
print("bilans d'équivalence différents :", diff or "aucun")
EOF
