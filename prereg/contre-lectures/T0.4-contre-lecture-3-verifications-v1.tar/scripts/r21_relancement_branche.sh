#!/usr/bin/env bash
# r21 : relancement « à l'identique » sur une instance neuve (nouvelle racine d'amorce), contre le même dépôt distant que
# le premier essai (r05, scénario sain, branche calcul/t04-validation déjà poussée). La poussée passe-t-elle ?
# Puis : relancement sur la même « instance » (même racine d'amorce) : l'amorce repart-elle ?
set -u
W="$1"; S="$W/r05-sain"; C=9aaf4a55dd334993ff50e92699fb5fb516a0a51b
avant=$(git -C "$S/depot.git" rev-parse calcul/t04-validation)
rm -rf "$W/r21"; mkdir -p "$W/r21"
env COMMIT="$C" GH_TOKEN=factice HF_TOKEN=factice DEPOT_URL="file://$S/depot.git" RACINE_AMORCE="$W/r21" \
    MODE=jouet VENV_EXISTANT=/home/user/controle-ia/.venv bash "$S/amorce.sh" > "$W/r21/amorce.log" 2>&1
echo "instance neuve : code amorce $?"
grep -E "run A terminé|run B terminé|poussée|rejected|non-fast-forward|fin, code" "$W/r21/amorce.log" | head -8
apres=$(git -C "$S/depot.git" rev-parse calcul/t04-validation)
echo "branche distante inchangée : $([ "$avant" = "$apres" ] && echo oui || echo non)"
env COMMIT="$C" GH_TOKEN=factice HF_TOKEN=factice DEPOT_URL="file://$S/depot.git" RACINE_AMORCE="$S" \
    MODE=jouet VENV_EXISTANT=/home/user/controle-ia/.venv bash "$S/amorce.sh" > "$W/r21/amorce-meme-instance.log" 2>&1
echo "même instance : code amorce $? ; $(grep -m1 AMORCE "$W/r21/amorce-meme-instance.log" | tail -1) / $(grep -m1 "clonage" "$W/r21/amorce-meme-instance.log")"
