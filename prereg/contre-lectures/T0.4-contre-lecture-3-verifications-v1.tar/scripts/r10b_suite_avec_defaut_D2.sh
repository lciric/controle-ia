#!/usr/bin/env bash
# r10b : la suite de tests au commit 9aaf4a5 voit-elle le défaut D2 (positions qui ignorent le remplissage à gauche) ?
# Copie jetable, une ligne remplacée dans generer_lot, suite complète.
# Usage : bash r10b_suite_avec_defaut_D2.sh <espace de travail contenant copie/>
W="$1"; rm -rf "$W/d2"; git -c advice.detachedHead=false clone -q "$W/copie" "$W/d2"; cd "$W/d2"
git -c advice.detachedHead=false checkout -q 9aaf4a55dd334993ff50e92699fb5fb516a0a51b
python3 - <<'PY'
p = "src/controle_ia/harnais/episode.py"
s = open(p).read()
a = "positions = (masque.cumsum(dim=1) - 1).clamp(min=0)"
assert a in s
open(p, "w").write(s.replace(a, "positions = torch.arange(L).expand(B, L).clone()"))
PY
git diff --stat
. /home/user/controle-ia/.venv/bin/activate && PYTHONPATH=src python -m pytest -q -p no:cacheprovider 2>&1 | tail -3
