"""r08 (rejeu adapté de V08, contre-lecture 2) : ce que comparer_runs (P7) compare au commit 9aaf4a5.
Deux runs jouets identiques (A, puis B en rejeu), puis le résumé de B est altéré à la relecture (monkeypatch de
verifier_resultat), un champ à la fois ; on note si la comparaison le voit."""
import copy, json, subprocess, tempfile
from pathlib import Path
from controle_ia.harnais import validation_reelle as V

def git(d, *a):
    subprocess.run(["git", "-C", str(d), *a], check=True, capture_output=True)
d = Path(tempfile.mkdtemp())
git(d, "init", "-q", "-b", "main"); git(d, "config", "user.email", "t@x.invalid"); git(d, "config", "user.name", "t")
(d / "README").write_text("x\n"); git(d, "add", "-A"); git(d, "commit", "-qm", "init")
PETITE = dict(V.CONFIG_REPETITION,
              production=dict(V.CONFIG_REPETITION["production"], episodes=4, T=2, max_nouveaux=8),
              debit={"tailles_lot": [1, 4], "longueur_contexte": 32, "max_nouveaux": 4})
A, B = "20261004-230000-repetition-jouet", "20261004-230100-repetition-jouet"
V.executer(d, A, entropie=77, config=PETITE, verifier_import=False)
git(d, "add", "-A"); git(d, "commit", "-qm", "A")
V.executer(d, B, config=PETITE, rejeu_de=A, verifier_import=False)
git(d, "add", "-A"); git(d, "commit", "-qm", "B")

def alt_reglages(r): r["reglages"]["carte"] = "autre carte"; r["reglages"]["pilote"] = "999.99"
def alt_memoire_carte(r): r["reglages"]["memoire_carte_gio"] = 39.5
def alt_chargement(r): r["chargement"]["attention"] = "eager"
def alt_format(r): r["format"]["gabarit_sha256"] = "f" * 64
def alt_repere(r): r["production"]["repere_precision"]["0"]["max"] = 0.5
def alt_memoire_vive(r): r["memoire_vive_go"] = {"memtotal_go": 1.0, "plafond_conteneur_go": None, "effective_go": 1.0}
def alt_tests(r): r["tests_instance"] = {"derniere_ligne": "1 failed, 169 passed in 5.0s", "reussis": False}
def alt_commit_cite(r): r["commit_cite"] = "0" * 40
def alt_couverture(r): r["logique"]["equivalence"]["couverture"]["actions_remplies"] = 0
def alt_domaine(r): r["logique"]["equivalence"]["domaine"]["contexte_max"] = 99999
def alt_cn_bilan(r): r["production"]["equivalence"]["controle_negatif"]["fraction"] = 0.5
def alt_sondes_poids(r): r["production"]["sondes"][0]["empreinte"] = "0" * 64
def alt_plan(r): r["production"]["plan_lots"] = [[0], [1, 2, 3]]
def alt_lecture(r): r["lecture"]["logique_equivalence"] = "contraire"
def alt_logits_ep(r): r["logique"]["episodes"][1]["empreintes"]["logits"] = "0" * 64
ALTERATIONS = [alt_reglages, alt_memoire_carte, alt_chargement, alt_format, alt_repere, alt_memoire_vive, alt_tests,
               alt_commit_cite, alt_couverture, alt_domaine, alt_cn_bilan, alt_sondes_poids, alt_plan, alt_lecture,
               alt_logits_ep]

import controle_ia.harnais.validation_reelle as M
vrai, vrai_ecrire = V.verifier_resultat, M.ecrire_resultat
for alt in ALTERATIONS:
    def altere(racine, chemin, _alt=alt):
        corps = copy.deepcopy(vrai(racine, chemin))
        if B in str(chemin) and str(chemin).endswith("resume.json"):
            _alt(corps["resultat"])
        return corps
    V.verifier_resultat = altere
    M.ecrire_resultat = lambda racine, man, nom, contenu: None   # pas d'écriture (R12)
    try:
        c = V.comparer_runs(d, A, B)
    finally:
        V.verifier_resultat, M.ecrire_resultat = vrai, vrai_ecrire
    print(f"{alt.__name__:20s} -> identique={c['identique']!s:5s} lecture={c['lecture']:9s} motifs="
          f"{[x.get('motif') or x.get('empreinte') or x.get('equivalence') for x in c['differences']]}")
