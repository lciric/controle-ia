"""r9 (rejeu adapté d'exp9, contre-lectures 1 et 2) au commit 9aaf4a5, de bout en bout par V.executer (répétition jouet) :
artefact « garde aveugle » — dans la mesure du contrôle négatif, la zone générée est rendue constante des deux côtés.
Attendu : contrôle négatif de phase à 0 %, arrêt en fin de logique, lecture partielle P3 « contraire »."""
import json, subprocess, tempfile
from pathlib import Path
from controle_ia.gardes import GardeArret
from controle_ia.harnais import episode as E
from controle_ia.harnais import validation_reelle as V

d = Path(tempfile.mkdtemp())
for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"]):
    subprocess.run(["git", "-C", str(d), *a], check=True)
(d / "README").write_text("x\n"); (d / ".gitignore").write_text("donnees/\n")
subprocess.run(["git", "-C", str(d), "add", "-A"], check=True); subprocess.run(["git", "-C", str(d), "commit", "-qm", "i"], check=True)
vrai = E.ecart_decale_zone_generee
def aveugle(ag, ap, lc, tol):
    g = {c: a.copy() for c, a in ag.items()}; p = {c: a.copy() for c, a in ap.items()}
    for c in g:
        n = g[c].shape[0] - lc
        if n > 0:
            v = p[c][lc].copy(); g[c][lc:] = v; p[c][lc:lc + n] = v
    return vrai(g, p, lc, tol)
E.ecart_decale_zone_generee = aveugle
run = "20261004-201000-repetition-jouet"
try:
    V.executer(d, run, entropie=12345, config=V.CONFIG_REPETITION, verifier_import=False)
    print("AUCUN ARRÊT")
except GardeArret as e:
    print("arrêt :", str(e)[:200])
finally:
    E.ecart_decale_zone_generee = vrai
a = json.loads((d / "diag" / run / "arret.json").read_text())["resultat"]
b = a["partiel"]["logique"]["equivalence"]
print("phase :", a["phase"], "; contrôle négatif :", {k: b["controle_negatif"][k] for k in ("comparables", "passent", "fraction")})
print("lecture partielle :", {k: v for k, v in a["partiel"]["lecture_partielle"].items() if k.startswith("logique")})
