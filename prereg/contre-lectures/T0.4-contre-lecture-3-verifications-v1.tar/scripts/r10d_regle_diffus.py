"""r10d : la règle « diffus » de la lecture de P2 (code 9aaf4a5) peut-elle classer un défaut de logique en « précision » ?
Phase de logique seule (simple précision, noyau math), configuration de répétition jouet, entropie 12345.
  D3 : défaut de masque — le jeton de remplissage qui précède le contenu d'une ligne remplie n'est pas masqué (fuite d'un
       jeton ; les positions, tirées du masque, se décalent d'une unité : effet seul de la fuite).
  D1+bruit : défaut de décodage d'exp10 (positions décodées +1), avec un bruit relatif ε ajouté aux seules captures du
       contexte (plancher de bruit du prérempli au-dessus de celui du jouet, 1,4e-7) : à partir de quel ε la lecture
       bascule-t-elle de « contraire » à « précision probable » ?"""
import inspect, textwrap
import numpy as np
from controle_ia.harnais import episode as E
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais.activations import couches_par_defaut
from controle_ia.manifeste import graines as G

cfg = V.CONFIG_REPETITION
c, cn = cfg["logique"], cfg["controle_negatif"]
V.regler_determinisme(1, "cpu")
gr = G(V.taches(cfg), entropie=12345)
m, tok = V.charger(cfg, None, c["dtype"], gr)
fmt, _ = V.format_du_modele(m, tok, cfg)
couches = couches_par_defaut(m.config.num_hidden_layers)
source = inspect.getsource(E.generer_lot)
vrai_gen, vrai_relire = E.generer_lot, E.relire_crochets_lot

def jouer(code=None, eps=0.0):
    if code is not None:
        espace = dict(E.__dict__); exec(textwrap.dedent(code), espace)
        E.generer_lot = espace["generer_lot"]
    if eps:
        rng = np.random.default_rng(0)
        def relire(brut, k, lc, plan, n):
            s = vrai_relire(brut, k, lc, plan, n)
            for cle, a in s.items():
                a = a.copy()
                bruit = rng.standard_normal(a[:lc].shape).astype(np.float32)
                bruit *= (eps * np.linalg.norm(a[:lc], axis=1, keepdims=True) / np.linalg.norm(bruit, axis=1, keepdims=True))
                a[:lc] += bruit
                s[cle] = a
            return s
        E.relire_crochets_lot = relire
    try:
        sorties, plan = V.jouer_phase(m, fmt, c, gr, "logique", couches, chrono={})
    finally:
        E.generer_lot, E.relire_crochets_lot = vrai_gen, vrai_relire
    b = V.bilan_phase(sorties, c, cn)
    l = V.lire({"format": {"verifie": True}, "logique": {"equivalence": b}}, cfg)
    return b, l

D3 = source.replace("        masque[r, L - len(c):] = 1\n",
                    "        masque[r, L - len(c):] = 1\n        if L > len(c):\n            masque[r, L - len(c) - 1] = 1\n")
assert D3 != source
D1 = source.replace("suivante = positions[:, -1:] + 1", "suivante = positions[:, -1:] + 2")
for nom, code, eps in (("sain", None, 0.0), ("D3 fuite d'un jeton de remplissage", D3, 0.0),
                       ("D1 (exp10)", D1, 0.0), ("D1 + bruit du contexte ε = 2e-5", D1, 2e-5),
                       ("D1 + bruit du contexte ε = 6e-5", D1, 6e-5), ("D1 + bruit du contexte ε = 9e-5", D1, 9e-5),
                       ("sain + bruit du contexte ε = 9e-5", None, 9e-5)):
    b, l = jouer(code, eps)
    print(f"{nom:38s} : écart max {b['ecart_max']:.3g} ; contexte {b['max_contexte']:.3g} ; zone générée "
          f"{b['max_zone_generee']:.3g} ; lecture P2 : {l['logique_equivalence']}")
