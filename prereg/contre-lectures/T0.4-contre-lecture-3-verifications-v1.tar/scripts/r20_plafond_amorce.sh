#!/usr/bin/env bash
# r20 : plafond de l'amorce (timeout externe, 345 min) contre le délai par run (timeout interne, 155 min), à petite
# échelle : amorce 3 s, run 10 s, run réel de 6 s. Le script d'instance consigne-t-il l'arrêt ? Le run survit-il ?
# Usage : bash r20_plafond_amorce.sh <espace de travail>
W="$1"; D="$W/r20"; rm -rf "$D"; mkdir -p "$D"
cat > "$D/script_instance.sh" <<EOS
#!/usr/bin/env bash
set -euo pipefail
echo "script : début" >> $D/journal
consigner() { echo "script : consigner_arret (traces, poussée)" >> $D/journal; }
if ! timeout --signal=TERM --kill-after=2s 10s python3 -c "
import signal, sys, time
def h(s, f):
    open('$D/journal', 'a').write('python : TERM reçu, arret.json\n'); sys.exit(1)
signal.signal(signal.SIGTERM, h)
time.sleep(6)
open('$D/journal', 'a').write('python : run terminé normalement (après la fin de l amorce)\n')
"; then consigner; exit 1; fi
echo "script : run terminé, poussée" >> $D/journal
EOS
timeout --signal=TERM --kill-after=2s 3s bash "$D/script_instance.sh"
echo "amorce : fin, code $?" >> "$D/journal"
python3 -c "import time; time.sleep(5)"     # laisse au run orphelin le temps de finir
cat "$D/journal"
