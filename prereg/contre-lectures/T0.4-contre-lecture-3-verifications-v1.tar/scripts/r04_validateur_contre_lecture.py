"""r04 (suite de V04, contre-lecture 2 ; N-6) : validateur `problemes` au commit 9aaf4a5.
(a) le brouillon 4 tel quel ; (b) la ligne « Contre-lecture 3 … À REMPLIR » remplacée par des formulations qui
annoncent une relecture sans la reporter (faux négatifs ?) ; (c) des formulations légitimes après relecture (faux
positifs ?) ; (d) une contre-lecture 3 reportée sans aucune empreinte."""
import sys, tempfile
from pathlib import Path
from controle_ia.prereg import problemes

src = Path(sys.argv[1]).read_text(encoding="utf-8")
ligne = "- **Contre-lecture 3** des parties modifiées : À REMPLIR (brouillon relu, rapport, traitement)."
assert ligne in src
def essai(rempl):
    p = Path(tempfile.mkdtemp()) / "p.md"
    p.write_text(src.replace(ligne, rempl), encoding="utf-8")
    return problemes(p)
print("(a) brouillon 4 :", problemes(Path(sys.argv[1])))
print("(b) annonces sans report :")
for t in ("- **Contre-lecture 3** : en cours.", "- **Contre-lecture 3** : prévue avant le lancement.",
          "- **Contre-lecture 3** : TODO.", "- **Contre-lecture 3** : à relire.", "- **Contre-lecture 3** : A faire.",
          "- **Contre-lecture 3** : non encore faite.", "- **Contre-lecture 3** : rapport à joindre.",
          "- **Contre-lecture 3** : à faire."):
    print(f"    {t!r:60s} -> {essai(t) or 'ACCEPTÉ'}")
print("(c) formulations légitimes après relecture :")
for t in ("- **Contre-lecture 3** (sous-agent neuf) : rapport `" + "a" * 64 + "`, brouillon `" + "b" * 64 + "` ; aucune remarque bloquante, rien à reporter dans le code.",
          "- **Contre-lecture 3** : rapport `" + "a" * 64 + "`, brouillon `" + "b" * 64 + "` ; M-4 : correction à faire en v2 (accepté).",
          "- **Contre-lecture 3** : rapport `" + "a" * 64 + "`, brouillon `" + "b" * 64 + "` ; les zip de livrables sont à venir après le verdict."):
    print(f"    …{t[-60:]!r} -> {essai(t) or 'ACCEPTÉ'}")
print("(d) contre-lecture 3 reportée sans empreinte :")
t = "- **Contre-lecture 3** (sous-agent neuf) : faite ; verdict scellable ; remarques intégrées."
print(f"    {t!r} -> {essai(t) or 'ACCEPTÉ'}")
