"""Contre-lecture 2 : la simulation de V-1 (contre-lecture 1, script 06, partie d), refaite au code dc7aa7f.

Modèle jouet, processeur, double précision, configuration de répétition (4 couches, largeur 32) et jouet large
(8 couches, largeur 256). Pour imiter une réduction dont l'ordre dépend de la forme du lot (cas probable sur carte),
la variance de la normalisation est sommée dans un autre ordre aux seules passes de décodage (une position par ligne).
Cas :
  A  code tel quel (normalisations en double précision), sans simulation : référence ;
  B  code tel quel + ordre de sommation modifié au décodage, EN DOUBLE PRÉCISION (forme qu'aurait l'effet avec le code
     dc7aa7f : la variance réduite en double précision) ;
  C  témoin positif de la simulation : mêmes conditions, mais la normalisation remplacée calcule sa variance en SIMPLE
     précision (comme la bibliothèque), avec l'ordre modifié au décodage : l'effet de V-1 doit réapparaître ;
  D  mutation du code : `normalisations_en_double` neutralisée dans `charger` (jouet), et le correctif de classe de la
     contre-lecture 1 (simple précision, ordre modifié au décodage) : l'effet de V-1 doit réapparaître.
Mesure : par couche, maximum de l'écart sur le contexte et sur la zone générée, minimum des maxima de la zone générée.
"""
import json, sys
import torch
sys.path.insert(0, "src")
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais import modeles as M
from controle_ia.manifeste import graines as G
from controle_ia.harnais.activations import couches_par_defaut
import transformers.models.llama.modeling_llama as LL

torch.set_num_threads(1)
torch.use_deterministic_algorithms(True)


def jouer(config, entropie=12345):
    gr = G(V.taches(config), entropie)
    c = config["logique"]
    modele, tok = V.charger(config, None, c["dtype"], gr)
    fmt, _ = V.format_du_modele(modele, tok, config)
    couches = couches_par_defaut(modele.config.num_hidden_layers)
    sorties, _ = V.jouer_phase(modele, fmt, c, gr, "logique", couches)
    par = {}
    for ep, _, r in sorties:
        for cle, prof in r["profils"].items():
            for couche, p in prof.items():
                d = par.setdefault(str(couche), {"contexte": [], "generee": []})
                if p["contexte"]["jetons"]:
                    d["contexte"].append(p["contexte"]["max"])
                if p["generee"]["jetons"]:
                    d["generee"].append(p["generee"]["max"])
    out = {c_: {"max_contexte": f'{max(v["contexte"]):.2e}', "max_generee": f'{max(v["generee"]):.2e}',
                "min_des_max_generee": f'{min(v["generee"]):.2e}', "actions": len(v["generee"])} for c_, v in par.items()}
    out["normalisations_en_double"] = getattr(modele, "normalisations_en_double", 0)
    out["forward_d_instance"] = sum("forward" in m.__dict__ for m in modele.modules() if type(m).__name__.endswith("RMSNorm"))
    return out


def variance_autre_ordre(x):
    """Somme des carrés en 8 sommes partielles, additionnées en ordre inverse (même type que x)."""
    D = x.shape[-1]
    carres = x.pow(2)
    return carres.reshape(*carres.shape[:-1], 8, D // 8).sum(-1).flip(-1).cumsum(-1)[..., -1:] / D


def rms_double_ordre_decodage(self, x):                      # cas B : double précision partout
    variance = variance_autre_ordre(x) if x.shape[-2] == 1 else x.pow(2).mean(-1, keepdim=True)
    return self.weight * (x * torch.rsqrt(variance + self.variance_epsilon))


def rms_simple_ordre_decodage(self, x):                      # cas C et D : comme la bibliothèque (simple précision)
    t = x.dtype
    h = x.to(torch.float32)
    variance = variance_autre_ordre(h) if h.shape[-2] == 1 else h.pow(2).mean(-1, keepdim=True)
    h = h * torch.rsqrt(variance + self.variance_epsilon)
    return self.weight * h.to(t)


base = V.CONFIG_REPETITION
large = dict(base, modele_jouet={"couches": 8, "largeur": 256, "tetes": 8, "tetes_cle_valeur": 4, "intermediaire": 512})
sortie = {}
for nom, cfg in (("repetition", base), ("large", large)):
    sortie[f"A_{nom}_code_tel_quel"] = jouer(cfg)
    vrai = M._rms_en_double
    M._rms_en_double = rms_double_ordre_decodage             # lié par normalisations_en_double au chargement
    try:
        sortie[f"B_{nom}_double_ordre_modifie_au_decodage"] = jouer(cfg)
    finally:
        M._rms_en_double = vrai
    M._rms_en_double = rms_simple_ordre_decodage
    try:
        sortie[f"C_{nom}_temoin_simple_ordre_modifie_au_decodage"] = jouer(cfg)
    finally:
        M._rms_en_double = vrai
    vrai_nd, vrai_fw = V.normalisations_en_double, LL.LlamaRMSNorm.forward
    V.normalisations_en_double = lambda m: 0
    LL.LlamaRMSNorm.forward = rms_simple_ordre_decodage
    try:
        sortie[f"D_{nom}_mutation_sans_normalisations_en_double"] = jouer(cfg)
    finally:
        V.normalisations_en_double, LL.LlamaRMSNorm.forward = vrai_nd, vrai_fw
print(json.dumps(sortie, indent=1, ensure_ascii=False))
