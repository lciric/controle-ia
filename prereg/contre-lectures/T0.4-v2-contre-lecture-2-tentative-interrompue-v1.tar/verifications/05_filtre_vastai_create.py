"""Contre-lecture 2 : la commande `vastai create` de la procédure v3 (brouillon 2), section 4.

1. Réplique (argparse pur, sans importer vastai, sans réseau, sans jeton) des options de `create instance` lues dans
   le code installé (vastai 1.8.3 : cli/commands/instances.py l. 124-141, cli/main.py l. 138, cli/parser.py l. 325-341) :
   `--args` a nargs=argparse.REMAINDER (« must be last argument ») ; `--raw` est une option globale recopiée dans chaque
   sous-commande. On analyse la ligne de la procédure : où va `--raw` ?
2. Le filtre python de la procédure, appliqué à des sorties représentatives (jetons factices) : que montre-t-il ?
"""
import argparse, json, subprocess, sys

p = argparse.ArgumentParser(prog="vastai create instance")
p.add_argument("id", type=int)
p.add_argument("--image"); p.add_argument("--disk", type=float); p.add_argument("--env")
p.add_argument("--entrypoint"); p.add_argument("--args", nargs=argparse.REMAINDER)
p.add_argument("--raw", action="store_true", default=argparse.SUPPRESS)

argv_procedure = ["12345", "--image", "python:3.11-bookworm", "--disk", "80",
                  "--env", "-e COMMIT=c -e HF_TOKEN=FAUX_HF_123456 -e GH_TOKEN=FAUX_GH_123456",
                  "--entrypoint", "bash", "--args", "-c", "echo QkFTRTY0 | base64 -d > /root/amorce.sh && bash /root/amorce.sh",
                  "--raw"]
a = p.parse_args(argv_procedure)
print("1. ligne de la procédure (--raw après --args) :")
print("   raw vu par vastai :", getattr(a, "raw", False))
print("   args passés au conteneur :", a.args)
argv_corrige = argv_procedure[:1] + ["--raw"] + argv_procedure[1:-1]
b = p.parse_args(argv_corrige)
print("   correction (--raw avant --args) : raw =", getattr(b, "raw", False), "; args =", b.args)

FILTRE = '''import json, sys
t = sys.stdin.read()
try:
    d = json.loads(t)
    print("succès :", d.get("success"), "; identifiant :", d.get("new_contract"))
except Exception:
    print("réponse illisible (non affichée, elle peut contenir des jetons) ; vérifier par vastai show instances")'''

cas = {
    "sortie --raw (JSON), succès": json.dumps({"success": True, "new_contract": 99887766, "instance_api_key": "FAUX_CLE_INSTANCE_123456"}),
    "sortie sans --raw (ce que produit la ligne de la procédure)": "Started. " + str({"success": True, "new_contract": 99887766, "instance_api_key": "FAUX_CLE_INSTANCE_123456"}),
    "erreur qui recopie la requête": "failed with error 400: {'env': {'HF_TOKEN': 'FAUX_HF_123456'}, 'msg': 'invalid'}",
    "JSON d'échec avec message": json.dumps({"success": False, "error": "x", "msg": "env HF_TOKEN=FAUX_HF_123456"}),
    "JSON qui n'est pas un objet": json.dumps(["FAUX_HF_123456"]),
    "chaîne JSON": json.dumps("FAUX_HF_123456"),
    "sortie vide": "",
    "avertissement puis JSON": "Warning: FAUX_HF_123456\n" + json.dumps({"success": True, "new_contract": 1}),
}
print("2. filtre de la procédure :")
fuite = False
for nom, entree in cas.items():
    r = subprocess.run([sys.executable, "-c", FILTRE], input=entree, capture_output=True, text=True)
    sortie = r.stdout + r.stderr
    f = any(s in sortie for s in ("FAUX_HF_123456", "FAUX_GH_123456", "FAUX_CLE_INSTANCE_123456"))
    fuite |= f
    print(f"   - {nom} -> {sortie.strip()!r} ; code {r.returncode} ; jeton affiché : {f}")
print("   aucun jeton affiché dans tous les cas :", not fuite)
