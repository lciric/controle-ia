"""Contre-lecture 2 : quelles opérations calculent encore en simple (ou demi) précision dans le modèle de la phase de
logique (double précision, normalisations remplacées) ? Modèle jouet, processeur, noyau « math », code dc7aa7f.

On intercepte chaque opération élémentaire (aten) par un mode de répartition de PyTorch, pendant : un préremplissage
d'un lot de 3 lignes remplies à gauche (positions et masque explicites, comme `generer_lot`), une passe de décodage
avec cache, et une passe unique (comme `passe_unique`). On liste les opérations dont une sortie est en simple, demi ou
bfloat16 précision, avec leurs formes. Témoin : le même modèle en double précision sans le remplacement des
normalisations (chemin de la bibliothèque). Puis : le modèle de production (bfloat16) garde-t-il les normalisations de
la bibliothèque ?
"""
import collections, json, sys
import torch
from torch.utils._python_dispatch import TorchDispatchMode
from torch.utils._pytree import tree_flatten
sys.path.insert(0, "src")
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais.modeles import modele_jouet
from controle_ia.manifeste import graines as G

BAS = (torch.float32, torch.float16, torch.bfloat16)


class Journal(TorchDispatchMode):
    def __init__(self):
        super().__init__()
        self.ops = collections.Counter()

    def __torch_dispatch__(self, func, types, args=(), kwargs=None):
        out = func(*args, **(kwargs or {}))
        sorties = [t for t in tree_flatten(out)[0] if isinstance(t, torch.Tensor)]
        entrees = [t for t in tree_flatten((args, kwargs))[0] if isinstance(t, torch.Tensor)]
        if any(t.dtype in BAS for t in sorties):
            cle = (str(func), tuple(str(t.dtype).replace("torch.", "") for t in entrees),
                   tuple(f"{str(t.dtype).replace('torch.', '')}{list(t.shape)}" for t in sorties))
            self.ops[cle] += 1
        return out


def passes(modele):
    """Préremplissage (lot de 3, remplissage à gauche), une passe de décodage, une passe unique."""
    contextes = [[5, 6, 7, 8, 9, 10], [11, 12, 13], [14, 15, 16, 17]]
    B, L = len(contextes), max(map(len, contextes))
    ids = torch.zeros((B, L), dtype=torch.long)
    masque = torch.zeros((B, L), dtype=torch.long)
    for r, c in enumerate(contextes):
        ids[r, L - len(c):] = torch.tensor(c)
        masque[r, L - len(c):] = 1
    positions = (masque.cumsum(1) - 1).clamp(min=0)
    res = {}
    with torch.no_grad(), V.noyau("math"):
        j = Journal()
        with j:
            s = modele(input_ids=ids, attention_mask=masque, position_ids=positions, use_cache=True, logits_to_keep=1)
        res["prefill"] = j.ops
        j = Journal()
        masque2 = torch.cat([masque, torch.ones((B, 1), dtype=torch.long)], 1)
        with j:
            modele(input_ids=torch.tensor([[20], [21], [22]]), attention_mask=masque2, position_ids=positions[:, -1:] + 1,
                   past_key_values=s.past_key_values, use_cache=True, logits_to_keep=1)
        res["decodage"] = j.ops
        j = Journal()
        with j:
            modele(torch.tensor([[5, 6, 7, 8, 9, 10, 20]]), use_cache=False, logits_to_keep=1)
        res["passe_unique"] = j.ops
    return res


def resumer(res):
    return {etape: [f"{n}x {op} entrées={e} sorties={s}" for (op, e, s), n in sorted(ops.items())]
            for etape, ops in res.items()}


config = V.CONFIG_REPETITION
gr = G(V.taches(config), 12345)
sortie = {}
m64, _ = V.charger(config, None, "float64", gr)                      # chemin de la phase de logique (code cité)
sortie["logique_double_normalisations_remplacees"] = resumer(passes(m64))
temoin = modele_jouet(V.graine_entiere(gr["modele-jouet"]), 200, **config["modele_jouet"]).to(torch.float64).eval()
sortie["temoin_double_normalisations_bibliotheque"] = resumer(passes(temoin))
m16, _ = V.charger(config, None, "bfloat16", gr)                     # chemin de la phase de production
sortie["production_bfloat16"] = {
    "normalisations_avec_forward_d_instance": sum("forward" in m.__dict__ for m in m16.modules()
                                                  if type(m).__name__.endswith("RMSNorm")),
    "attribut_normalisations_en_double": getattr(m16, "normalisations_en_double", None),
    "operations_bas": {k: len(v) for k, v in resumer(passes(m16)).items()}}
print(json.dumps(sortie, indent=1, ensure_ascii=False))
