"""Contre-lecture 2 : recalcul des chiffres du jouet cités par le brouillon 2 (R6), depuis les résumés scellés.
À lancer depuis la racine du clone."""
import hashlib, json, sys
from pathlib import Path

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def compagnon(p):
    return Path(str(p) + ".sha256").read_text().split()[0]

runs = {"dc7aa7f": ("20261005-134001-repetition-jouet", "20261005-134019-repetition-jouet"),
        "47d3c61": ("20261005-122652-repetition-jouet", "20261005-122708-repetition-jouet"),
        "6556b4e": ("20261005-121017-repetition-jouet", "20261005-121053-repetition-jouet")}
cites = {"20261005-134001-repetition-jouet": "16a4b624061dc477e26f1d32e2d9191775645933f7b9b709f52821e5d1a8327a",
         "20261005-134019-repetition-jouet": "6058c5c67d756bba75fdbf5d78bff4996f0cf38eab8a7d73a090137a4b183bac",
         "20261005-122652-repetition-jouet": "0203d4607dad4c6364fa6e67bd3a4dd3e92526283eecc20d4a7443caa8abfa57",
         "20261005-122708-repetition-jouet": "1d07215f6b72a2d2c2ec93e52086c07cea2c430fdadd959ab180bda802c1e5f1",
         "20261005-121017-repetition-jouet": "e2e4369bb6af1c250b6b12186dcba37574a60165da6befd01425c0ade8920ac1",
         "20261005-121053-repetition-jouet": "acb709d71f0982f0c12598cc85d61895ff7b494732bcdc1d7e24ebbe28d28a13"}
comp_cites = {"dc7aa7f": "cc0b509b9762c535c8dac2e26dfd6ed131c6937089cc04c07094947b73d9208a",
              "47d3c61": "fac3b1bf3f35e9670b0adc6b9e08a0aa2060dac6897057f6174783d75d33bf42",
              "6556b4e": "6b43cc444b9786bf1c3b3efdb7e5a3b2cb03b52359e03828ed2dc8221e9a0f2b"}
for code, (a, b) in runs.items():
    print(f"== code {code} : {a} / {b}")
    for r in (a, b):
        p = Path("diag") / r / "resume.json"
        print(f"   {r} resume.json sha256 {sha(p)} ; compagnon {'OK' if sha(p) == compagnon(p) else 'DIFFERENT'} ;"
              f" cité {'OK' if sha(p) == cites[r] else 'DIFFERENT'}")
    pc = Path("diag") / b / f"comparaison-{a}.json"
    corps = json.loads(pc.read_text())
    print(f"   comparaison sha256 {sha(pc)} ; compagnon {'OK' if sha(pc) == compagnon(pc) else 'DIFFERENT'} ;"
          f" citée {'OK' if sha(pc) == comp_cites[code] else 'DIFFERENT'} ; identique={corps['resultat']['identique']}")
    for r in (a, b):
        x = json.loads((Path("diag") / r / "resume.json").read_text())["resultat"]
        lo, pr, cp = x["logique"]["equivalence"], x["production"]["equivalence"], x.get("controle_positif")
        print(f"   [{r}] commit manifeste : {json.loads((Path('runs') / r / 'manifeste.json').read_text()).get('commit', '?')[:12]}")
        print(f"     logique : ecart_max {lo['ecart_max']:.4e} ; contexte {lo['max_contexte']:.4e} ; zone générée {lo['max_zone_generee']:.4e} ;"
              f" CN {lo['controle_negatif']['passent']}/{lo['controle_negatif']['comparables']} min {lo['controle_negatif']['min_des_maxima']:.4f}")
        if cp:
            bl = cp["bilan"]
            print(f"     contrôle positif : T={cp['T']} ; vus {bl['vus']}/{bl['comparables']} (courtes {bl['courtes']}) ;"
                  f" min des maxima {bl['min_des_maxima']:.4e} ; max_contexte {bl.get('max_contexte')}")
            # minimum des maxima par couche, depuis les profils
            par_couche = {}
            for e in cp["episodes"]:
                for cle, prof in e["profils"].items():
                    for c, p in prof.items():
                        if p["generee"]["jetons"] >= 4:
                            par_couche.setdefault(c, []).append(p["generee"]["max"])
            print("     D1 par couche (min des maxima des actions comparables) :",
                  {c: f"{min(v):.3e}" for c, v in sorted(par_couche.items())})
            print("     nombre d'actions comparées (profils) :", sum(len(e["profils"]) for e in cp["episodes"]))
        print(f"     production : ecart_max {pr['ecart_max']:.4e} ; CN {pr['controle_negatif']['passent']}/{pr['controle_negatif']['comparables']}"
              f" min {pr['controle_negatif']['min_des_maxima']:.4f}")
        rp = x["production"]["repere_precision"]
        print("     repère de précision max :", f"{max(v['max'] for v in rp.values()):.4e}", {c: f"{v['max']:.3e}" for c, v in rp.items()})
        print("     zéros zone générée (logique) :", {c: z["generee"] for c, z in lo["zeros"].items()})
        print("     lecture :", x["lecture"])
