# Contre-lecture 2 (R2) — T0.4 validation sur modèle réel v2, brouillon 2 ; procédure v3, brouillon 2

État : EN COURS (rapport écrit au fil de l'eau ; bloc 1 fait : empreintes, suite, chiffres du jouet, simulation de V-1, filtre de `vastai create`).

## 1. Verdict
(à venir)

## 2. Empreintes vérifiées
Sorties brutes : `verifications/01-empreintes-arbre.txt`, `verifications/04_chiffres_jouet.sortie.txt`.
- `brouillons/T0.4-validation-modele-reel-v2-brouillon2.md` : 71b4c4113f4c98f856c2fd87f6c25ae497a661d73ce3781dbae9d7aeedefc059 — concorde.
- `brouillons/procedure-validation-T0.4-modele-reel-v3-brouillon2.md` : 7e447c65efb04d1300ab8a69c451c74224b107b47e604375219f088182d1509e — concorde.
- Contre-lecture 1 : rapport d3fce4a7…2092 et archive 67ba96aa…47ba6 — concordent avec leurs compagnons et avec le brouillon 2 ; `sha256sum -c` de l'archive : tout OK.
- Scripts au commit cité (`git show dc7aa7f:…`) et sur disque : `validation_t04_instance.sh` f143a0e9…5dca, `amorce_instance_t04.sh` 548c14c5…f9f4 — conformes ; inchangés entre 47d3c61 et dc7aa7f.
- Arbre gelé `dc7aa7f..dbddd11` (exclusions du préenregistrement, identiques à `CHEMINS_GELES`) : vide. `src` et `tests` identiques à dc7aa7f.
- Résumés et comparaisons des répétitions jouet (codes dc7aa7f, 47d3c61, 6556b4e) : les six résumés et les trois comparaisons égalent leur compagnon et l'empreinte citée.

## 3. Remarques (provisoires)
- Filtre de `vastai create` : `--raw` placé après `--args`, qui avale tout ce qui suit (vastai 1.8.3) ; aucun jeton affiché, mais l'identifiant ne sort jamais (détail à venir).

## 4. Suivi des remarques V-1 à V-15
(à venir)

## 5. Vérifié sans défaut (provisoire)
- Suite complète dans le clone : 192 réussis (97 s) — `verifications/03-suite-tests-clone.txt`.
- Chiffres du jouet au code cité : tous exacts (1,04e-15 ; 2,71e-16 ; 12/12, 1,487 ; 8/8, 1,93e-4 ; contexte 2,51e-16 ; 1,51e-3 ; 11/11, 1,596 ; 8,74e-3) ; D1 2,24e-4 (6556b4e) et 2,28e-4 (47d3c61).
- Simulation de V-1 refaite au code cité (`verifications/06_simulation_V1_dc7aa7f.*`) : l'effet disparaît (zone générée au niveau de la double précision), réapparaît avec un témoin en simple précision et avec la mutation qui neutralise `normalisations_en_double`.

## 6. Transparence
(à venir)
