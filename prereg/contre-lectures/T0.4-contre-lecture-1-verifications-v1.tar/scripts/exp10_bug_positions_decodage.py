"""Exp. 10 : défaut plausible injecté (positions des jetons décodés décalées de +1 par rapport au contexte) :
la garde de logique (simple précision, 1e-4) et celle de production (bfloat16, 0,1) le voient-elles ?"""
import torch
from controle_ia.harnais import episode as E
from controle_ia.harnais.formats import FormatChat
from controle_ia.harnais.modeles import modele_jouet, regler_determinisme, tokeniseur_caracteres_chat
from controle_ia.gardes import GardeArret

regler_determinisme(1)
tok = tokeniseur_caracteres_chat(); FIN = tok.convert_tokens_to_ids("<|im_end|>")
fmt = FormatChat(tok, fins={FIN, tok.eos_token_id})
vrai_cumsum = torch.Tensor.cumsum
src = E.generer_lot.__code__
import types, inspect, textwrap
code = inspect.getsource(E.generer_lot).replace("suivante = positions[:, -1:] + 1", "suivante = positions[:, -1:] + 2")
espace = dict(E.__dict__); exec(textwrap.dedent(code), espace)
for nom, dtype, tol in (("logique", torch.float32, 1e-4), ("production", torch.bfloat16, 0.1)):
    m = modele_jouet(11, len(tok), couches=4, largeur=32, tetes=4, tetes_cle_valeur=2, intermediaire=64).to(dtype)
    E.generer_lot, sauve = espace["generer_lot"], E.generer_lot
    try:
        s = E.jouer_episodes(m, fmt, E.EnvironnementJouet(), ["a", "b"], 2, 2, [{(i, t): 40 + 10 * b + 3 * i + t for t in range(2) for i in range(2)} for b in range(2)],
                             [0, 1, 2], max_nouveaux=16, echantillon_equivalence={(b, i, t) for b in range(2) for i in range(2) for t in range(2)},
                             tolerance_equivalence=tol)
        emax = max(max(d.values()) for _, _, r in s for d in r["ecarts"].values())
        print(f"{nom} ({dtype}, tolérance {tol}) : défaut NON détecté, écart max {emax:.3g}")
    except GardeArret as e:
        print(f"{nom} ({dtype}, tolérance {tol}) : défaut détecté — {str(e)[:110]}")
    finally:
        E.generer_lot = sauve
