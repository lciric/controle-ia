"""Exp. 3 : la garde de relecture (P8) contrôle-t-elle les activations par jeton hors des empans d'action ?
Artefact : écriture qui met à zéro (ou décale) les activations des positions de contexte (consigne,
observations, clôtures) ; les positions des actions restent justes. Fichiers écrits dans un dossier temporaire."""
import tempfile
from pathlib import Path
import numpy as np, torch
from controle_ia.harnais import episode as E, politique as P
from controle_ia.harnais.formats import FormatChat
from controle_ia.harnais.modeles import modele_jouet, regler_determinisme, tokeniseur_caracteres_chat
from controle_ia.harnais.sondes import sonde_lineaire_aleatoire

regler_determinisme(1)
tok = tokeniseur_caracteres_chat(); FIN = tok.convert_tokens_to_ids("<|im_end|>")
fmt = FormatChat(tok, fins={FIN, tok.eos_token_id})
m = modele_jouet(11, len(tok), couches=4, largeur=32, tetes=4, tetes_cle_valeur=2, intermediaire=64).to(torch.bfloat16)
g = [{(i, t): 300 + 10 * i + t for t in range(3) for i in range(2)}]
(ep, acts, _), = E.jouer_episodes(m, fmt, E.EnvironnementJouet(), ["e0"], 2, 3, g, [0, 1, 2], max_nouveaux=12)
pol = {"episodes_par_jeton": [0], "vecteurs_par_action": ["max"], "sondes": []}
sondes = [sonde_lineaire_aleatoire(f"s{c}{a}", c, 32, a, np.random.default_rng(c * 7 + len(a))) for c in (0, 1, 2) for a in ("max", "attention")]
v, s = P.calculer_en_ligne(pol, ep, acts, [0, 1, 2], sondes)
emp_memoire = E.empreinte_episode(ep, acts)["activations"]
for nom, transformer in (("contexte mis à zéro", lambda a, hors: np.where(hors[:, None], 0.0, a).astype(np.float32)),
                         ("contexte décalé d'un jeton", lambda a, hors: np.where(hors[:, None], np.roll(a, 1, axis=0), a).astype(np.float32))):
    faux = {}
    hors_total = 0
    for tr in ep.transcriptions:
        hors = np.ones(len(tr.ids), bool)
        for a in tr.actions:
            hors[a.debut:a.fin] = False
        hors_total += int(hors.sum())
        faux[tr.agent] = {c: transformer(x, hors) for c, x in acts[tr.agent].items()}
    d = Path(tempfile.mkdtemp())
    npz = P.ecrire_tableaux(d / "e0.npz", faux, v, s, "bfloat16-bits")
    P.relire_et_controler(npz, pol, ep, [0, 1, 2], sondes, v, s, True, "bfloat16-bits")
    total = sum(len(tr.ids) for tr in ep.transcriptions)
    with np.load(npz) as z:
        relu = {int(k.split('/')[1][5:]): {} for k in z.files if k.startswith('par_jeton/')}
        for k in z.files:
            if k.startswith('par_jeton/'):
                _, a_, c_ = k.split('/'); relu[int(a_[5:])][int(c_[6:])] = P.decoder(z[k], "bfloat16-bits")
    print(f"artefact « {nom} » : {hors_total}/{total} positions altérées sur disque ; relire_et_controler passe ; "
          f"empreinte des activations relues = empreinte en mémoire ? {E.empreinte_episode(ep, relu)['activations'] == emp_memoire}")
