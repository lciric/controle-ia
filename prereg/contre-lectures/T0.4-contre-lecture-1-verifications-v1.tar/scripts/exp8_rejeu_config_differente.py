"""Exp. 8 : run B lancé avec --rejeu-de mais une configuration différente (ici, la révision) : à quel moment
l'écart est-il vu, et laisse-t-il une trace scellée ? Mini-dépôt jetable, modèle jouet."""
import subprocess, tempfile, time
from pathlib import Path
from controle_ia.gardes import GardeArret
from controle_ia.harnais import validation_reelle as V

d = Path(tempfile.mkdtemp())
for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"]):
    subprocess.run(["git", "-C", str(d), *a], check=True)
(d / "README").write_text("x\n"); (d / ".gitignore").write_text("donnees/\n")
git = lambda: (subprocess.run(["git", "-C", str(d), "add", "-A"], check=True), subprocess.run(["git", "-C", str(d), "commit", "-qm", "e"], check=True))
git()
cfg = V.CONFIG_REPETITION
V.executer(d, "20261004-210000-repetition-jouet", revision="a" * 40, entropie=9, config=cfg, verifier_import=False)
git()
t0 = time.perf_counter()
try:
    V.executer(d, "20261004-210100-repetition-jouet", revision="b" * 40, config=cfg,
               rejeu_de="20261004-210000-repetition-jouet", verifier_import=False)
except GardeArret as e:
    print(f"run B : arrêt après {time.perf_counter() - t0:.1f} s (run complet) : {e}")
print("fichiers de diag du run B :", sorted(p.name for p in (d / "diag/20261004-210100-repetition-jouet").iterdir() if p.suffix == ".json"))
