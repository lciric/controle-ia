"""Exp. 14 : mêmes arguments que charger_modele (dtype=float32, attn_implementation='sdpa', sans device_map) sur un
petit modèle de type Llama enregistré en bfloat16 : où et dans quel type les poids sont-ils matérialisés ?"""
import tempfile, torch
from transformers import AutoModelForCausalLM
from controle_ia.harnais.modeles import modele_jouet
d = tempfile.mkdtemp()
modele_jouet(1, 140, couches=2, largeur=64, tetes=4, tetes_cle_valeur=2, intermediaire=128).to(torch.bfloat16).save_pretrained(d)
m = AutoModelForCausalLM.from_pretrained(d, dtype=torch.float32, attn_implementation="sdpa")
p = next(m.parameters())
n = sum(x.numel() for x in m.parameters())
print(f"appareil {p.device}, type {p.dtype}, implémentation d'attention {m.config._attn_implementation} ; "
      f"{n} paramètres = {sum(x.numel() * x.element_size() for x in m.parameters())} octets en mémoire du processeur central")
print("projection Llama-3.1-8B : 8 030 261 248 paramètres × 4 octets =", f"{8030261248 * 4 / 1e9:.2f} Go ({8030261248 * 4 / 2**30:.2f} Gio)")
