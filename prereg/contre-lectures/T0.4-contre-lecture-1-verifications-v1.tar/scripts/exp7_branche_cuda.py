"""Exp. 7 : branche « cuda » de regler_determinisme (jamais exercée par les tests) : cas sain et artefact
d'espace de travail cuBLAS, avec un processeur graphique simulé (aucun appel réel au pilote)."""
import os, torch
from unittest import mock
from controle_ia.gardes import GardeArret
from controle_ia.harnais.modeles import regler_determinisme

faux = dict(is_available=lambda: True, get_device_name=lambda i=0: "GPU simulé", get_device_capability=lambda i=0: (8, 0))
with mock.patch.multiple(torch.cuda, **faux):
    os.environ.pop("CUBLAS_WORKSPACE_CONFIG", None)
    try:
        r = regler_determinisme(1, "cuda")
        print("cas sain :", {k: r[k] for k in ("cublas_workspace", "tf32", "carte", "cuda")})
    except Exception as e:
        print("cas sain : ERREUR", type(e).__name__, e)
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":0:0"
    try:
        regler_determinisme(1, "cuda"); print("artefact : AUCUN ARRÊT")
    except GardeArret as e:
        print("artefact :", e)
print("réglages consignés : allow_bf16_reduced_precision_reduction absent du dictionnaire ;",
      "valeur courante =", torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction)
