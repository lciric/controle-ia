"""Exp. 1b : localisation du maximum de l'écart décalé et sensibilité par position dans la zone générée.
Configuration de répétition jouet (CONFIG_REPETITION), entropie 12345 ; aucun fichier écrit."""
import numpy as np
from collections import Counter
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais import episode as E
from controle_ia.harnais.activations import couches_par_defaut, ecarts_par_jeton
from controle_ia.manifeste import graines as G

cfg = V.CONFIG_REPETITION
V.regler_determinisme(1, "cpu")
gr = G(V.taches(cfg), entropie=12345)
vrai = E.relire_crochets_lot
for phase, dtype in (("logique", "float32"), ("production", "bfloat16")):
    c = cfg[phase]
    m, tok = V.charger(cfg, None, dtype, gr)
    fmt = V.format_du_modele(m, tok, cfg["variables_gabarit"])
    couches = couches_par_defaut(m.config.num_hidden_layers)
    env = E.EnvironnementJouet()
    E_ = c["episodes"]; B = c["taille_lot"]
    plan = [list(range(j, min(j + B, E_))) for j in range(0, E_, B)]
    lieux = Counter(); sous_tau = 0; gen_total = 0; valeurs_max = []
    for lot in plan:
        eq = list(range(E_)) if phase == "logique" else c["episodes_equivalence"]
        ech = {(b, i, p) for b, k in enumerate(lot) if k in eq for p in range(c["T"]) for i in range(c["N"])}
        if not ech:
            continue
        g = [{(i, p): V.graine_entiere(gr[f"{phase}/episode-{k}/action-{i}-{p}"]) for p in range(c["T"]) for i in range(c["N"])} for k in lot]
        liste = []
        def capt(brut, k, lc, plan_, n):
            r = vrai(brut, k, lc, plan_, n); liste.append((lc, r)); return r
        E.relire_crochets_lot = capt
        sort = E.jouer_episodes(m, fmt, env, [f"e{k}" for k in lot], c["N"], c["T"], g, couches, c["max_nouveaux"],
                                c["temperature"], ech, c["tolerance"])
        E.relire_crochets_lot = vrai
        ordre = [(b, i, t) for t in range(c["T"]) for i in range(c["N"]) for b in range(len(lot)) if (b, i, t) in ech]
        for (b, i, t), (lc, ag) in zip(ordre, liste):
            ep, acts, rap = sort[b]
            ouv = len(fmt.ouverture(env.consigne_privee(i), env.observation(i, 0, [])))
            for couche in couches:
                gg = ag[couche]; pp = acts[i][couche][: gg.shape[0]]
                d1 = ecarts_par_jeton(gg[1:], pp[:-1]); n_star = int(np.argmax(d1)) + 1
                valeurs_max.append(round(float(d1.max()), 3))
                lieux["ouverture commune (1er tour)" if n_star < ouv else ("action générée" if n_star >= lc else "contexte (tours suivants)")] += 1
                zone = d1[lc - 1:]                       # d'_n pour n >= lc (jetons générés relus)
                gen_total += zone.size; sous_tau += int(np.sum(zone <= c["tolerance"]))
    print(f"===== {phase} ({dtype}), tolérance {c['tolerance']}")
    print("  lieu du maximum de l'écart décalé (action × couche) :", dict(lieux))
    print("  valeurs du maximum les plus fréquentes :", Counter(valeurs_max).most_common(3))
    print(f"  positions générées où le décalage d'un jeton resterait ≤ tolérance : {sous_tau} / {gen_total}")
    del m
