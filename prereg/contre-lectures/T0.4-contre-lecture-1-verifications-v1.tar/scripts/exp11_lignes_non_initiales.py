"""Exp. 11 : échantillon d'équivalence sur des lignes qui ne sont pas en tête du lot (k ≠ b dans jouer_episodes),
cas que ni la phase de logique (toutes les lignes) ni la production (lignes 0 et 1) n'exercent."""
import torch
from controle_ia.harnais import episode as E
from controle_ia.harnais.formats import FormatChat
from controle_ia.harnais.modeles import modele_jouet, regler_determinisme, tokeniseur_caracteres_chat

regler_determinisme(1)
tok = tokeniseur_caracteres_chat(); FIN = tok.convert_tokens_to_ids("<|im_end|>")
fmt = FormatChat(tok, fins={FIN, tok.eos_token_id})
m = modele_jouet(11, len(tok), couches=4, largeur=32, tetes=4, tetes_cle_valeur=2, intermediaire=64)
B = 5
g = [{(i, t): 900 + 10 * b + 3 * i + t for t in range(3) for i in range(2)} for b in range(B)]
ech = {(b, i, t) for b in (1, 3) for i in range(2) for t in range(3)}
s = E.jouer_episodes(m, fmt, E.EnvironnementJouet(), [f"e{b}" for b in range(B)], 2, 3, g, [0, 1, 2], max_nouveaux=16,
                     echantillon_equivalence=ech, tolerance_equivalence=1e-4)
print("lignes 1 et 3 d'un lot de 5 : écart max", max(max(d.values()) for _, _, r in s for d in r["ecarts"].values()),
      "; actions comparées", sum(len(r["ecarts"]) for _, _, r in s))
