"""Exp. 5 : FormatChat sur un gabarit de type Llama 3.1 RECONSTITUÉ DE MÉMOIRE (non vérifié sur le fichier
officiel ; non opposable), avec le tokeniseur jouet par caractères muni des balises de Llama 3."""
from controle_ia.harnais.formats import FormatChat, verifier_format
from controle_ia.harnais.modeles import tokeniseur_caracteres
from controle_ia.harnais import validation_reelle as V

GABARIT = ("{{- bos_token }}"
           "{%- if not date_string is defined %}{%- set date_string = strftime_now('%d %b %Y') %}{%- endif %}"
           "{%- if messages[0]['role'] == 'system' %}{%- set system_message = messages[0]['content']|trim %}"
           "{%- set messages = messages[1:] %}{%- else %}{%- set system_message = '' %}{%- endif %}"
           "{{- '<|start_header_id|>system<|end_header_id|>\n\n' }}{{- 'Cutting Knowledge Date: December 2023\n' }}"
           "{{- 'Today Date: ' + date_string + '\n\n' }}{{- system_message }}{{- '<|eot_id|>' }}"
           "{%- for message in messages %}{{- '<|start_header_id|>' + message['role'] + '<|end_header_id|>\n\n' + message['content'] | trim + '<|eot_id|>' }}{%- endfor %}"
           "{%- if add_generation_prompt %}{{- '<|start_header_id|>assistant<|end_header_id|>\n\n' }}{%- endif %}")
tok = tokeniseur_caracteres()
tok.add_special_tokens({"additional_special_tokens": ["<|start_header_id|>", "<|end_header_id|>", "<|eot_id|>", "<|eom_id|>"]})
tok.chat_template = GABARIT
eot = tok.convert_tokens_to_ids("<|eot_id|>")
for variables in ({"date_string": "26 Jul 2024"}, {}):
    fmt = FormatChat(tok, fins={eot}, variables=variables)
    r = verifier_format(fmt, **V.CONFIG_REELLE["format"])
    debut = (V.CONFIG_REELLE["format"]["consigne"], V.CONFIG_REELLE["format"]["observations"][0])
    print(f"variables {variables} : garde de format {r['verifie']} ({r['jetons']} jetons) ; clôture = "
          f"{tok.convert_ids_to_tokens(fmt._pieces(debut)['cloture'])} ; en-tête : "
          f"{tok.decode(fmt.ouverture(*debut)).splitlines()[3]!r}")
# action générée commençant par un saut de ligne : la transcription n'est plus le rendu canonique (rognage du gabarit)
fmt = FormatChat(tok, fins={eot}, variables={"date_string": "26 Jul 2024"})
debut = ("Consigne.", "Obs.")
ids_action = tok("\nRéponse. ", add_special_tokens=False)["input_ids"] + [eot]
incr = fmt.ouverture(*debut) + ids_action + fmt.cloture(debut, ids_action)
canon = fmt.rendre([{"role": "system", "content": "Consigne."}, {"role": "user", "content": "Obs."},
                    {"role": "assistant", "content": tok.decode(ids_action[:-1])}], False)
print("action à blancs de bord : transcription incrémentale = rendu canonique ?", incr == canon, f"({len(incr)} contre {len(canon)} jetons)")
