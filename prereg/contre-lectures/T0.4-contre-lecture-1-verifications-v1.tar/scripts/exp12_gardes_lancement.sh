#!/usr/bin/env bash
# Exp. 12 : chemin décisif par la ligne de commande (préenregistrement scellé) et artefacts des gardes de lancement
# de validation_reelle, dans une copie jetable du dépôt (jamais dans /home/user/controle-ia).
set -u
ICI="$(cd "$(dirname "$0")" && pwd)"
C="$ICI/../copie-gardes"
rm -rf "$C"; git clone -q /home/user/controle-ia "$C"; cd "$C"
git config user.email "contre-lecteur@invalid"; git config user.name "contre-lecteur"
. /home/user/controle-ia/.venv/bin/activate; export PYTHONPATH=src
cp brouillons/T0.4-validation-modele-reel-v1-brouillon1.md prereg/T0.4-essai-contre-lecture-v1.md
python -c "from controle_ia.prereg import problemes, sceller_prereg as s; p='prereg/T0.4-essai-contre-lecture-v1.md'; print('problemes() :', problemes(p)); print('scellé tel quel :', s(p))"
git add -A; git commit -qm "essai jetable"
lancer() { python -m controle_ia.harnais.validation_reelle --repetition-jouet --prereg prereg/T0.4-essai-contre-lecture-v1.md --run-id "$1" 2>&1 | grep -v -i warning; }
echo "== cas sain"; lancer 20261004-220000-repetition-jouet | python -c "import sys,json; print('lecture', json.load(sys.stdin)['lecture'])"
git add -A; git commit -qm "résultats"
echo "== artefact 1 : modification non committée de src/"; echo "# x" >> src/controle_ia/harnais/sondes.py; lancer 20261004-220100-repetition-jouet | grep ARRÊT
echo "== artefact 2 : modification committée"; git commit -qam "modif"; lancer 20261004-220200-repetition-jouet | grep ARRÊT
echo "== artefact 3 : code importé d'une autre copie"; PYTHONPATH="$ICI/../copie/src" lancer 20261004-220300-repetition-jouet | grep ARRÊT
echo "arret.json écrits par ces trois arrêts :"; ls diag | grep -E "2201|2202|2203" || echo "aucun"
