"""Exp. 2 : relecture des crochets par lot quand les lignes s'arrêtent à des pas différents (fin de tour
sur-représentée par un biais du jeton de fin dans la tête de sortie du modèle jouet)."""
import numpy as np, torch
from collections import Counter
from controle_ia.harnais import episode as E
from controle_ia.harnais.formats import FormatChat
from controle_ia.harnais.modeles import modele_jouet, regler_determinisme, tokeniseur_caracteres_chat

regler_determinisme(1)
tok = tokeniseur_caracteres_chat()
FIN = tok.convert_tokens_to_ids("<|im_end|>")
fmt = FormatChat(tok, fins={FIN, tok.eos_token_id})
for dtype in (torch.float32, torch.bfloat16):
    for biais in (0.0, 2.0, 4.0):
        m = modele_jouet(11, len(tok), couches=4, largeur=32, tetes=4, tetes_cle_valeur=2, intermediaire=64)
        with torch.no_grad():
            m.lm_head.weight[FIN] += biais * m.model.norm.weight.sign() if biais else 0.0
        m = m.to(dtype)
        B, N, T = 6, 2, 3
        g = [{(i, t): 7000 + 100 * b + 10 * i + t for t in range(T) for i in range(N)} for b in range(B)]
        ech = {(b, i, t) for b in range(B) for i in range(N) for t in range(T)}
        tol = 1e-4 if dtype == torch.float32 else 0.1
        try:
            s = E.jouer_episodes(m, fmt, E.EnvironnementJouet(), [f"e{b}" for b in range(B)], N, T, g, [0, 1, 2],
                                 max_nouveaux=16, echantillon_equivalence=ech, tolerance_equivalence=tol)
            longueurs = Counter(len(a.ids) for ep, _, _ in s for tr in ep.transcriptions for a in tr.actions)
            fins = sum(a.ids[-1] == FIN for ep, _, _ in s for tr in ep.transcriptions for a in tr.actions)
            emax = max(max(d.values()) for _, _, r in s for d in r["ecarts"].values())
            print(f"{str(dtype):15s} biais {biais}: longueurs d'action {dict(sorted(longueurs.items()))} ; "
                  f"actions closes par la fin de tour {fins}/{B*N*T} ; écart max {emax:.2e} : garde passée")
        except Exception as e:
            print(f"{str(dtype):15s} biais {biais}: ARRÊT {type(e).__name__}: {e}")
