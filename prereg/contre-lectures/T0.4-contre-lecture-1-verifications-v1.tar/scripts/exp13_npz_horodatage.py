"""Exp. 13 : deux np.savez des mêmes tableaux, à deux secondes d'intervalle : même empreinte de fichier ?"""
import hashlib, tempfile, time
from pathlib import Path
import numpy as np
d = Path(tempfile.mkdtemp()); a = {"x": np.arange(10, dtype=np.uint16)}
np.savez(d / "a.npz", **a); time.sleep(2.1); np.savez(d / "b.npz", **a)
h = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()[:16]
print("empreintes :", h(d / "a.npz"), h(d / "b.npz"), "| identiques :", h(d / "a.npz") == h(d / "b.npz"))
