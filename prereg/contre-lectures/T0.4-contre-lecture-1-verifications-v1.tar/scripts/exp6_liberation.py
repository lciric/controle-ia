"""Exp. 6 : après `del modele, sorties` (validation_reelle, ligne 262), le modèle de la phase de logique est-il
réellement libéré sans ramasse-miettes (gc) ? Sinon, deux modèles coexistent en mémoire du processeur graphique."""
import gc, weakref
from controle_ia.harnais import validation_reelle as V
from controle_ia.harnais.activations import couches_par_defaut
from controle_ia.manifeste import graines as G

gc.disable()
cfg = V.CONFIG_REPETITION
V.regler_determinisme(1, "cpu")
gr = G(V.taches(cfg), entropie=1)
modele, tok = V.charger(cfg, None, "float32", gr)
fmt = V.format_du_modele(modele, tok, cfg["variables_gabarit"])
couches = couches_par_defaut(modele.config.num_hidden_layers)
sorties, plan = V.jouer_phase(modele, fmt, cfg["logique"], gr, "logique", couches, range(2), chrono={})
ref = weakref.ref(modele)
del modele, sorties
print("modèle encore vivant après del, sans gc :", ref() is not None)
gc.collect()
print("modèle encore vivant après gc.collect() :", ref() is not None)
