"""Exp. 9 : le contrôle négatif (P3/P5 : maximum sur toutes les positions de l'écart décalé) détecte-t-il une
garde aveugle dans la seule zone générée ? Artefact : activations constantes le long des positions générées
(génération ET passe unique), contexte intact — l'analogue, restreint à la zone générée, de l'artefact
« activations constantes » de tests/test_harnais_lots.py::test_controle_negatif_sain_et_aveugle."""
import numpy as np, torch
from controle_ia.harnais import episode as E
from controle_ia.harnais.activations import ecart_equivalence, exiger_controle_negatif, ecarts_par_jeton
from controle_ia.harnais.formats import FormatChat
from controle_ia.harnais.modeles import modele_jouet, regler_determinisme, tokeniseur_caracteres_chat
from controle_ia.gardes import GardeArret

regler_determinisme(1)
tok = tokeniseur_caracteres_chat(); FIN = tok.convert_tokens_to_ids("<|im_end|>")
fmt = FormatChat(tok, fins={FIN, tok.eos_token_id})
m = modele_jouet(11, len(tok), couches=4, largeur=32, tetes=4, tetes_cle_valeur=2, intermediaire=64).to(torch.bfloat16)
liste = []
vrai = E.relire_crochets_lot
def capt(brut, k, lc, plan, n):
    r = vrai(brut, k, lc, plan, n); liste.append((lc, r)); return r
E.relire_crochets_lot = capt
(ep, acts, _), = E.jouer_episodes(m, fmt, E.EnvironnementJouet(), ["e0"], 1, 2, [{(0, 0): 5, (0, 1): 6}], [0, 1, 2],
                                  max_nouveaux=16, echantillon_equivalence={(0, 0, 0), (0, 0, 1)}, tolerance_equivalence=0.1)
E.relire_crochets_lot = vrai
lc, ag = liste[1]                                    # action (agent 0, pas 1)
n_gen = ag[0].shape[0] - lc
g = {c: a.copy() for c, a in ag.items()}; p = {c: a.copy() for c, a in acts[0].items()}
for c in g:                                          # zone générée rendue constante, des deux côtés
    v = p[c][lc].copy()
    g[c][lc:] = v; p[c][lc:lc + n_gen] = v
dec = ecart_equivalence(g, p, decalage=1)
try:
    exiger_controle_negatif(dec, 0.1, "artefact zone générée")
    verdict = "PASSE (non détecté)"
except GardeArret:
    verdict = "arrêt (détecté)"
gen_seul = {c: float(ecarts_par_jeton(g[c][lc:], p[c][lc - 1:lc - 1 + n_gen]).max()) for c in g}
print(f"{n_gen} positions générées comparées sur {ag[0].shape[0]} ; contrôle négatif tel que défini : {verdict} ; "
      f"valeurs {{{', '.join(f'{c}: {x:.2f}' for c, x in dec.items())}}}")
print("même contrôle restreint aux positions générées (sauf la première) :",
      {c: round(float(ecarts_par_jeton(g[c][lc + 1:], p[c][lc:lc + n_gen - 1]).max()), 4) for c in g})
