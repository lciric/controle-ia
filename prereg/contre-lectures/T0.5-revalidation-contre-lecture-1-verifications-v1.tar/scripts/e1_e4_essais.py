"""Essais du contre-lecteur (R2) sur une copie du code (modèle jouet, processeur) ; rien n'est écrit dans le dépôt.

E1 : arrêt pendant le second bras (« math ») : que reste-t-il sur disque ? (« résultats partiels poussés »)
E2 : panne de mémoire signalée dans le bras « math » : le run finit-il, et comment se lit-il ?
E3 : gardes de citation (`exiger_citations`) et liste d'évaluation vide : cas sain et artefacts
E4 : l'échantillon d'équivalence est-il le même dans les deux bras ? (corrélation du non concluant de Rk-5)
"""
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import torch

sys.path.insert(0, sys.argv[1])            # copie/src
sys.path.insert(0, sys.argv[2])            # copie/tests (conftest)
from controle_ia.environnements import revalider_pilote_a as rv   # noqa: E402
from controle_ia.gardes import GardeArret                           # noqa: E402
from controle_ia.harnais.modeles import regler_determinisme         # noqa: E402
from controle_ia.scellement import sceller                          # noqa: E402

regler_determinisme(1)

CONFIG = {"N": 1, "T": 2, "episodes_par_tache": 1, "lot": 2, "max_nouveaux": 6, "temperature": 1.0,
          "couches": [0, 1, 2], "fraction_equivalence": 0.5, "statistique_equivalence": "q99",
          "tolerance_equivalence": 0.2, "positions_min_controle_negatif": 4, "actions_min_controle_negatif": 1,
          "fraction_min_controle_negatif": 0.95, "agent": {"nom": "agent-jouet"}, "mode": "jouet", "fils": 1,
          "bras": ["defaut", "math"], "nombre_taches": 4, "episodes_repere": [0, 2], "actions_min_comparees": 1,
          "part_min_contexte_couvert": 0.9, "memoire_carte_min_gio": 75, "duree_max_s": 600}


def git(r, *a):
    subprocess.run(["git", "-C", str(r), *a], check=True, capture_output=True)


def depot():
    d = Path(tempfile.mkdtemp(prefix="cl-reval-"))
    git(d, "init", "-q", "-b", "main")
    git(d, "config", "user.email", "t@example.invalid")
    git(d, "config", "user.name", "t")
    (d / "README").write_text("x\n")
    git(d, "add", "-A")
    git(d, "commit", "-q", "-m", "init")
    return d


def taches(prefixe, n):
    return [{"identifiant": f"{prefixe}.{k:05d}v1", "questions": f"Why do routers matter in setting {k}? " * (1 + k),
             "classification": {"theory_experiment": "mostly_experiments", "data_type": "real_only", "domains": []}}
            for k in range(n)]


def fichiers(d, entr, ev):
    ch = []
    for nom, t in (("entrainement", entr), ("evaluation", ev)):
        f = d / f"taches-{nom}.json"
        f.write_text(json.dumps({"taches": t}), encoding="utf-8")
        sceller(f)
        ch.append(str(f))
    git(d, "add", "-A")
    git(d, "commit", "-q", "-m", "x")
    return ch


print("=== E1 : arrêt (garde de durée simulée) pendant le bras « math »")
d = depot()
e, v = fichiers(d, taches("2601", 4), taches("2602", 2))
vrai = rv.jouer_pilote
appels = {"n": 0}


def jouer_qui_s_arrete(*a, **k):
    appels["n"] += 1
    if appels["n"] == 3:               # 1 : passage « defaut » ; 2 : rejeu « defaut » ; 3 : passage « math »
        raise GardeArret("limite de durée dépassée au pas 0, agent 0 (simulée)")
    return vrai(*a, **k)


rv.jouer_pilote = jouer_qui_s_arrete
try:
    rv.executer(CONFIG, d, "20261007-000000-e1", None, e, v, entropie_essai=11)
    print("aucun arrêt ?!")
except GardeArret as x:
    print("arrêt propagé :", x)
rv.jouer_pilote = vrai
diag = d / "diag" / "20261007-000000-e1"
print("fichiers dans diag/<run> :", sorted(p.name for p in diag.iterdir()))
arret = json.loads((diag / "arret.json").read_text())["resultat"]
print("contenu de arret.json :", json.dumps(arret, ensure_ascii=False))

print("\n=== E2 : panne de mémoire signalée dans le bras « math »")
d = depot()
e, v = fichiers(d, taches("2601", 4), taches("2602", 2))
appels["n"] = 0


def jouer_oom(*a, **k):
    appels["n"] += 1
    if appels["n"] == 3:
        raise torch.cuda.OutOfMemoryError("CUDA out of memory (simulée)")
    return vrai(*a, **k)


rv.jouer_pilote = jouer_oom
res = rv.executer(CONFIG, d, "20261007-000000-e2", None, e, v, entropie_essai=11)
rv.jouer_pilote = vrai
print("noyau retenu :", res["noyau_retenu"], "; lecture « math » :", res["lectures"]["math"])
print("lecture « defaut » :", {k: x for k, x in res["lectures"]["defaut"].items()})

print("\n=== E3 : gardes de citation (exiger_citations), non éprouvées par tests/test_revalider_pilote_a.py")
d = depot()
e, v = fichiers(d, taches("2601", 4), taches("2602", 2))
import hashlib  # noqa: E402
from controle_ia.manifeste import config_canonique  # noqa: E402

sha_c = hashlib.sha256(config_canonique(CONFIG)).hexdigest()
sha_t = hashlib.sha256(Path(e).read_bytes()).hexdigest()
p = d / "prereg.md"
p.write_text(f"- Entropie : `11`\n- Configuration de la revalidation (empreinte canonique) : `{sha_c}`\n"
             f"- Tâches d'entraînement : `{sha_t}`\n", encoding="utf-8")
print("cas sain :", rv.exiger_citations(p, CONFIG, sha_t))
for nom, cfg, st in (("config modifiée", dict(CONFIG, lot=4), sha_t), ("tâches autres", CONFIG, "0" * 64)):
    try:
        rv.exiger_citations(p, cfg, st)
        print(nom, ": PAS d'arrêt")
    except GardeArret as x:
        print(nom, ": arrêt :", x)
d2 = depot()
e2, v2 = fichiers(d2, taches("2601", 4), [])
try:
    print("liste d'évaluation VIDE acceptée sans arrêt :", [t["identifiant"] for t in rv.taches_d_entrainement(e2, v2, 4)])
except GardeArret as x:
    print("liste d'évaluation vide : arrêt :", x)
try:
    rv.taches_d_entrainement(e, v, 5)
    print("moins de n tâches : PAS d'arrêt")
except GardeArret as x:
    print("moins de n tâches : arrêt :", x)

print("\n=== E4 : échantillon d'équivalence identique dans les deux bras ?")
d = depot()
e, v = fichiers(d, taches("2601", 4), taches("2602", 2))
res = rv.executer(CONFIG, d, "20261007-000000-e4", None, e, v, entropie_essai=11)
ep = json.loads((d / "diag" / "20261007-000000-e4" / "episodes.json").read_text())["resultat"]
for b in ("defaut", "math"):
    print(b, [(f["episode"], f["equivalence"]["actions"]) for f in ep[b]])
print("mêmes actions comparées dans les deux bras :",
      [f["equivalence"]["actions"] for f in ep["defaut"]] == [f["equivalence"]["actions"] for f in ep["math"]])
print("lectures :", json.dumps({b: {k: x for k, x in l.items() if k.startswith("R")} for b, l in res["lectures"].items()},
                              ensure_ascii=False))
