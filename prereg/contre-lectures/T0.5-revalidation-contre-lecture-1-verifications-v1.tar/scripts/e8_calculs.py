"""E8 : deux calculs d'ordre de grandeur cités par le rapport (aucune donnée du dépôt lue).

(a) Mémoire du bras « math » au lot de 8, par la méthode de la note `docs/notes/memoire-noyau-math-T0.4-v3-v2.md`
    (l. 13-14 : en demi-précision, « math » calcule en simple précision et tient environ 3 matrices d'attention
    (lot, têtes, L, L) au pic ; 2,74 fois mesuré ; l. 19-20 et 31 : poids 16,1 Go, cache, activations denses).
    Contrôle : production de T0.4 v3 au noyau « math », L = 1 192 : pic mesuré 21,75 Go (verdict v3, l. 396).
(b) Fausse alarme du pilote : 0 dépassement sur n actions comparées de la revalidation ne borne pas le risque sur
    les ~96 actions gardées du pilote (contre-lecture 1 du pilote, l. 53).
"""
import math

LOT, TETES, COUCHES, TETES_KV, DIM_TETE = 8, 32, 32, 8, 128
POIDS = 16.1e9
CARTE = 79.15 * 2 ** 30          # A100 80 Go : mémoire vue par la bibliothèque (ordre de grandeur)


def pic(L, facteur=3.0, denses=4e9):
    matrices = facteur * LOT * TETES * L * L * 4
    cache = LOT * L * COUCHES * 2 * TETES_KV * DIM_TETE * 2
    return matrices + POIDS + cache + denses


print("(a) contrôle à L = 1 192 (T0.4 v3, mesuré 21,75 Go) :", round(pic(1192, denses=1e9) / 1e9, 1), "Go estimés")
for L in (3000, 3500, 4000, 4400, 4600, 5000, 5400):
    print(f"    L = {L} : {pic(L) / 1e9:6.1f} Go (facteur 3) ; {pic(L, 2.74) / 1e9:6.1f} Go (facteur 2,74) ;"
          f" carte ≈ {CARTE / 1e9:.1f} Go")
for f in (3.0, 2.74):
    a, b, c = f * LOT * TETES * 4, LOT * COUCHES * 2 * TETES_KV * DIM_TETE * 2, POIDS + 4e9 - CARTE
    print(f"    seuil de panne (facteur {f}) : L ≈ {(-b + math.sqrt(b * b - 4 * a * c)) / (2 * a):.0f} jetons")

print("(b) 0 dépassement sur n actions : borne supérieure à 95 % du taux par action (1 − 0,05^(1/n)),")
print("    et probabilité correspondante d'au moins un dépassement sur 96 actions gardées du pilote")
for n in (80, 160):
    p = 1 - 0.05 ** (1 / n)
    print(f"    n = {n} : p ≤ {p:.4f} ; P(≥ 1 sur 96) ≤ {1 - (1 - p) ** 96:.2f}")
for p in (0.001, 0.005, 0.01, 0.02):
    print(f"    si p = {p} : P(0 sur 80 dans la revalidation) = {(1 - p) ** 80:.2f} ; "
          f"P(≥ 1 sur 96 dans le pilote) = {1 - (1 - p) ** 96:.2f}")
