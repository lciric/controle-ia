"""E5 : audit R4 du brouillon (tous les écarts nuls) contre P9 de T0.4 v3 (zone générée) ;
E6 : contrôle négatif de la garde restreinte lu sur le maximum, et non sur la grandeur de la garde (99e centile) ;
E7 : probabilité qu'un tirage à 50 % manque toutes les actions longues (Rk-5 non concluant), même échantillon dans
les deux bras (E4)."""
import sys

import numpy as np

sys.path.insert(0, sys.argv[1])
from controle_ia.environnements import revalider_pilote_a as rv  # noqa: E402
from controle_ia.harnais.activations import ecart_decale_zone_generee, profil_ecarts  # noqa: E402

rng = np.random.default_rng(0)
CFG = {"tolerance_equivalence": 0.2, "actions_min_comparees": 1, "part_min_contexte_couvert": 0.9,
       "actions_min_controle_negatif": 1, "fraction_min_controle_negatif": 0.95}

print("=== E5 : zone générée recopiée de la passe unique (écarts nuls), contexte arrondi (écarts non nuls)")
lc, m, w = 300, 40, 64
p = rng.normal(size=(lc + m, w))
g = p.copy()
g[:lc] += 1e-2 * rng.normal(size=(lc, w))        # contexte : arrondi
# zone générée : g == p exactement (artefact : captures recopiées)
prof = profil_ecarts({7: g}, {7: p}, lc)[7]
print("zone générée : jetons", prof["generee"]["jetons"], "nuls", prof["generee"]["nuls"], "; contexte : nuls",
      prof["contexte"]["nuls"])
mesures = {"actions_comparees": 1, "q99_max": 0.02, "ecart_max": prof["max"], "contexte_max": lc,
           "contexte_max_joue": lc, "actions_remplies": 1}
lect = rv.lire_bras(mesures, {"lecture": "conforme"}, {"7": {"q99": 0.05}}, True, CFG)
print("ecart_max =", round(prof["max"], 4), "-> audit_R4_ecarts_tous_nuls =", lect["audit_R4_ecarts_tous_nuls"],
      "(P9 de T0.4 v3 se déclencherait : 0 écart non nul dans la zone générée)")

print("\n=== E6 : un seul jeton décalé au-dessus du seuil dans une zone générée de 300 positions")
lc, m = 4700, 300
p = rng.normal(size=(lc + m, w))
g = p.copy()
g[lc:] += 0.05 * np.abs(rng.normal(size=(m, w))) * np.linalg.norm(p[lc:], axis=1, keepdims=True) / np.sqrt(w)
cn = ecart_decale_zone_generee({7: g}, {7: p}, lc, 0.2)[7]
# l'écart décalé réel d'un jeton est d'ordre 1 partout ; ici on fabrique un cas où une seule position décalée dépasse
from controle_ia.harnais.activations import ecarts_par_jeton  # noqa: E402
e = ecarts_par_jeton(g[lc + 1:], p[lc:lc + m - 1])
print("écart décalé fabriqué : max", round(float(e.max()), 3), "; q99 de la zone décalée", round(float(np.quantile(e, 0.99)), 3),
      "; positions au-dessus de 0,2 :", int((e > 0.2).sum()), "sur", e.size)
e2 = np.full(m - 1, 0.05)
e2[17] = 0.9
print("cas fabriqué à la main : max", e2.max(), "> 0,2 (le contrôle négatif restreint passe) ; q99 =",
      round(float(np.quantile(e2, 0.99)), 3), "(la garde restreinte, lue sur le 99e centile, ne verrait pas ce décalage)")

print("\n=== E7 : P(Rk-5 non concluant) si k actions jouées seulement atteignent 90 % du plus long contexte")
for k in range(1, 9):
    print(f"k = {k} : 0,5^k = {0.5 ** k:.4f}  (même tirage dans les deux bras : nœud par le hasard du tirage)")
