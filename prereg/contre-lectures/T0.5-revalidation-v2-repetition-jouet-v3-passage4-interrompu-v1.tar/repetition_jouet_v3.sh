#!/usr/bin/env bash
# Répétition jouet de la chaîne de la revalidation, version 2 du préenregistrement (N-018) : le chemin du
# préenregistrement et la branche sont passés au script de l'instance par l'environnement (PREREG, BRANCHE), comme le
# fait lancer_revalidation_v4.sh. Dépôt jetable (les fichiers réels de la v1, préenregistrement et configuration, y sont
# retirés pour que la configuration jouet prenne leur chemin). Jetons factices. Quatre passages :
#   1. cas sain : PREREG=…-v2.md, BRANCHE=calcul/t05-revalidation-jouet-v2 ;
#   2. artefact : même branche, déjà présente → arrêt avant l'installation (code 2) ;
#   3. artefact : sans PREREG (défaut v1, absent du dépôt jetable) → arrêt avant l'installation (code 2) ;
#   4. relancement sain sous BRANCHE=calcul/t05-revalidation-jouet-v3, avec PREREG.
# Usage : repetition_jouet_v3.sh DEPOT RACINE
set -uo pipefail
DEPOT=$1; R=$2
S=$(cd "$(dirname "$0")" && pwd); F=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/scellement-revalidation
PY=${VENV_REPETITION:?VENV_REPETITION}/bin/python
P2=prereg/T0.5-revalidation-equivalence-pilote-v2.md; CFG=prereg/T0.5-revalidation-config-v1.json
[ -e "$R" ] && { echo "$R existe déjà (R12)"; exit 2; }
mkdir -p "$R"
git clone -q --no-local "$DEPOT" "$R/source" && git -C "$R/source" checkout -q -B main origin/main || exit 2
cd "$R/source"
git config user.email essai@invalid; git config user.name essai
git rm -q prereg/T0.5-revalidation-equivalence-pilote-v1.md prereg/T0.5-revalidation-equivalence-pilote-v1.md.sha256 \
    "$CFG" "$CFG.sha256" && git commit -qm "essai : fichiers réels de la v1 retirés du dépôt jetable" || exit 2
CODE=$(git rev-parse HEAD)
echo 20261010 > "$R/entropie.txt"
C=prereg/contre-lectures
"$PY" -I "$F/remplir_revalidation_v4.py" . "$CODE" "$R/entropie.txt" jouet "2026-10-10 (répétition jouet v3)" \
    "$C/T0.5-revalidation-repetition-jouet-v5.tar" racine-1-sain/t05/tests.txt "$P2" "$CFG" "$C/T0.5-revalidation-repetition-jouet-v5.tar" \
    "$C/T0.5-revalidation-verification-remplissage-1-v1.md" "$C/T0.5-revalidation-verification-remplissage-2-v1.md" \
    "$C/T0.5-revalidation-verification-remplissage-3-v1.md" > "$R/remplissage.json" || exit 2
PYTHONPATH=src "$PY" -m controle_ia.scellement sceller "$CFG" > /dev/null || exit 2
PYTHONPATH=src "$PY" -c "from controle_ia.prereg import sceller_prereg; sceller_prereg('$P2')" || exit 2
git add "$P2" "$P2.sha256" "$CFG" "$CFG.sha256" && git commit -qm "essai : préenregistrement jouet v2" || exit 2
ESSAI=$(git rev-parse HEAD); echo "$ESSAI" > "$R/commit-essai.txt"
git clone -q --bare "$R/source" "$R/distant.git" || exit 2
cd "$R"
passage() {   # $1 nom, $2 BRANCHE, $3 PREREG (vide : défaut)
    local n=$1 b=$2 p=$3 debut fin
    mkdir -p "$R/racine-$n"
    debut=$(date +%s)
    env -i PATH="$PATH" LANG=C.UTF-8 HOME="$R/racine-$n" COMMIT="$ESSAI" GH_TOKEN=factice HF_TOKEN=factice \
        ETUDE=revalidation MODE=jouet DEPOT_URL="$R/distant.git" RACINE_AMORCE="$R/racine-$n" \
        VENV_EXISTANT="$VENV_REPETITION" ${b:+BRANCHE=$b} ${p:+PREREG=$p} \
        bash "$R/source/scripts/amorce_instance_t05.sh" > "$R/amorce-$n.log" 2>&1
    local code=$?
    fin=$(date +%s)
    echo "passage $n : code $code ; durée totale $((fin-debut)) s"
}
passage 1-sain-v2 calcul/t05-revalidation-jouet-v2 "$P2"
passage 2-artefact-branche-presente calcul/t05-revalidation-jouet-v2 "$P2"
passage 3-artefact-sans-prereg calcul/t05-revalidation-jouet-v9 ""
passage 4-relancement-v3 calcul/t05-revalidation-jouet-v3 "$P2"
git -C "$R/distant.git" branch -a | sed 's/^/branche distante : /'
echo "FIN DE LA RÉPÉTITION"
