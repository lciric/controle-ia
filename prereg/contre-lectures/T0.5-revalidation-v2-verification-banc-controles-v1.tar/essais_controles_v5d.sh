#!/usr/bin/env bash
# Banc d'essai des contrôles avant dépense v5 (R5 ; relecture de la v2, L-03) : un cas sain et des artefacts, chacun
# joué contre le script entier, sur un dépôt jetable et un dépôt nu local. La copie jouée ne diffère du script que par
# l'adresse du dépôt et les trois épingles (candidat vérifié brut et normalisé, rapports attendus), celles du candidat
# de l'essai. Le scellement y est simulé : GO fictif sur N-018, N-018 tranché, R-135, rapport de vérification fictif.
# v5b : ligne de GO simulée à 8 colonnes (format du registre) ; sceaux d'artefacts réécrits à la main.
# v5c : préenregistrement altéré re-scellé de façon cohérente (sceau réécrit), pour éprouver chaque garde seule ;
#       lignes KO de chaque jeu recopiées dans le journal.
# v5d : la branche v2 de l'artefact A6 est retirée du dépôt nu après son jeu.
# Usage : essais_controles_v5b.sh DEPOT_SOURCE CANDIDAT_RELU CANDIDAT_VERIFIE RACINE_NEUVE
set -uo pipefail
SRC=$1; RELU=$2; VERIFIE=$3; R=$4
H=$(cd "$(dirname "$0")" && pwd)
PY=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/scellement-revalidation/venv-gpu-neuf/bin/python
P=prereg/T0.5-revalidation-equivalence-pilote-v2.md; P1=prereg/T0.5-revalidation-equivalence-pilote-v1.md
CL=prereg/contre-lectures; GO=GO-2026-10-11-99
VERIF=T0.5-revalidation-v2-verification-corrections-v1.md
RAPPORTS="T0.5-revalidation-v2-relecture-texte-v1.md T0.5-revalidation-v2-relecture-code-v1.md T0.5-revalidation-v2-relecture-chaine-v1.md T0.5-revalidation-v2-relecture-contre-verifications-v1.md T0.5-revalidation-v2-relecture-resultats-v1.json T0.5-revalidation-v2-relecture-fichiers-de-travail-v1.tar $VERIF"
[ -e "$R" ] && { echo "$R existe déjà (R12)"; exit 2; }
mkdir -p "$R" && cd "$R" || exit 2
git clone -q --no-local "$SRC" source && cd source || exit 2
git config user.email essai@invalid; git config user.name essai; git config commit.gpgsign false
# préalables simulés du scellement
python3 - <<EOF || exit 2
from pathlib import Path
d = Path("registres/decisions.md"); t = d.read_text(encoding="utf-8")
l = [x for x in t.split("\n") if x.startswith("| N-018 |")][0]
t = t.replace(l, l.rsplit("| en attente |", 1)[0] + "| tranché : option (a), $GO (essai) |")
t = t.rstrip("\n") + "\n| R-135 | 2026-10-11 | essai : corrections de la relecture de la v2 | R2 |\n"
d.write_text(t, encoding="utf-8")
g = Path("registres/go.md"); g.write_text(g.read_text(encoding="utf-8").rstrip("\n") + "\n| $GO | 2026-10-11 | revendication | N-018, option (a) (essai) | — | — | Lazar (essai) | R-136 (essai) |\n", encoding="utf-8")
Path("$CL/$VERIF").write_text("# rapport de vérification fictif (essai)\n", encoding="utf-8")
EOF
PYTHONPATH=src "$PY" -m controle_ia.scellement sceller "$CL/$VERIF" > /dev/null || exit 2
git add -A registres "$CL/$VERIF" "$CL/$VERIF.sha256" && git commit -qm "essai : préalables simulés du scellement de la v2" || exit 2
C1=$(git rev-parse HEAD)
arg_rapports=(); for n in $RAPPORTS; do arg_rapports+=(--rapport "$CL/$n"); done
"$PY" -I "$H/remplir_revalidation_v2_r2.py" . 6ec7434119781a3abebac789174101b9ed6ae087 reel "$(date -u '+%Y-%m-%d %H:%M UTC')" \
    "$R/v2-saine.md" --candidat-relu "$RELU" --candidat-verifie "$VERIFIE" --go "$GO" --registre R-135 "${arg_rapports[@]}" || exit 2
normaliser() { sed -E '3s/[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}/AAAA-MM-JJ HH:MM/; 8s/[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}/AAAA-MM-JJ HH:MM/' "$1" \
    | sed -E 's/^(- Version 2 \(N-018\) : .*) Pièces : .*$/\1 Pièces : (remplies au scellement)./' | sha256sum | cut -d' ' -f1; }
NV=$(normaliser "$VERIFIE"); NS=$(normaliser "$R/v2-saine.md")
echo "empreinte normalisée : candidat vérifié $NV ; v2 saine de l'essai $NS"
[ "$NV" = "$NS" ] || { echo "la v2 de l'essai ne se normalise pas en le candidat vérifié"; exit 2; }
git clone -q --bare . "$R/distant.git" || exit 2
sed -e "s|^DEPOT=.*|DEPOT=$R/distant.git|" -e "s|^CANDIDAT_VERIFIE=.*|CANDIDAT_VERIFIE=$(sha256sum "$VERIFIE" | cut -d' ' -f1)|" \
    -e "s|^CANDIDAT_NORMALISE=.*|CANDIDAT_NORMALISE=$NV|" -e "s|^RAPPORTS_ATTENDUS=.*|RAPPORTS_ATTENDUS=\"$RAPPORTS\"|" \
    "$H/controles_avant_depense_v5.sh" > "$R/controles-essai.sh"
diff "$H/controles_avant_depense_v5.sh" "$R/controles-essai.sh" | grep -c '^>' | sed 's/^/lignes changées dans la copie : /'
sceller_v2() { PYTHONPATH=src "$PY" -c "from controle_ia.prereg import sceller_prereg; sceller_prereg('$P')" >/dev/null; }
resceller() { local f; for f in "$@"; do (cd "$(dirname "$f")" && sha256sum "$(basename "$f")" > "$(basename "$f").sha256"); done; }   # sceau réécrit à la main (R12 refuse le module)
# $1 nom, $2 code attendu, $3 motif KO attendu (vide pour le cas sain), $4 modification (avant le commit), $5 après (optionnel)
jouer() {
    local nom=$1 attendu=$2 motif=$3 avant=$4 apres=${5:-}
    git checkout -q -B "art-$nom" "$C1" && cp "$R/v2-saine.md" "$P" && sceller_v2 || { echo "$nom : montage impossible"; return; }
    eval "$avant"
    git add -A . >/dev/null 2>&1; git commit -qm "essai : $nom" || { echo "$nom : commit impossible"; return; }
    local s; s=$(git rev-parse HEAD)
    git push -q "$R/distant.git" "art-$nom" >/dev/null 2>&1
    eval "$apres"
    bash "$R/controles-essai.sh" "$s" "$R/clone-$nom" > "$R/sortie-$nom.txt" 2>&1; local c=$?
    rm -rf "$R/clone-$nom"
    local verdict="CONFORME"
    [ "$c" = "$attendu" ] || verdict="NON CONFORME (code $c, attendu $attendu)"
    if [ -n "$motif" ] && ! grep -q "^KO .*$motif" "$R/sortie-$nom.txt"; then verdict="NON CONFORME (KO « $motif » absent)"; fi
    echo "$nom : code $c ; $(grep -c '^KO' "$R/sortie-$nom.txt") KO ; $verdict"
    grep '^KO' "$R/sortie-$nom.txt" | sed 's/^/    /' | cut -c1-200
}
jouer A0-sain 0 "" ":"
jouer A1-v1-alteree-rescellee 1 "v1 : sceau ou citation" "sed -i '1s/— v1/— v1 (altérée)/' $P1 && resceller $P1"
jouer A2-v1-alteree-sans-sceau 1 "v1 : sceau ou citation" "sed -i '1s/— v1/— v1 (altérée)/' $P1"
jouer A3-rapport-altere 1 "pièce T0.5-revalidation-v2-relecture-texte-v1.md" "echo x >> $CL/T0.5-revalidation-v2-relecture-texte-v1.md"
jouer A3b-rapport-altere-rescelle 1 "pièce T0.5-revalidation-v2-relecture-texte-v1.md" "echo x >> $CL/T0.5-revalidation-v2-relecture-texte-v1.md && resceller $CL/T0.5-revalidation-v2-relecture-texte-v1.md"
jouer A4-rapport-absent 1 "pièce T0.5-revalidation-v2-relecture-code-v1.md" "git rm -q $CL/T0.5-revalidation-v2-relecture-code-v1.md $CL/T0.5-revalidation-v2-relecture-code-v1.md.sha256"
jouer A5-rapport-non-cite 1 "rapports cités" "sed -i -E 's/ ; \`T0\.5-revalidation-v2-relecture-code-v1\.md\` \(\`[0-9a-f]{64}\`\)//' $P && resceller $P"
jouer A6-branche-v2-presente 1 "branche de résultats" ":" "git push -q $R/distant.git art-A6-branche-v2-presente:refs/heads/calcul/t05-revalidation-reel-v2"
git -C "$R/distant.git" branch -D calcul/t05-revalidation-reel-v2 >/dev/null   # chaque garde éprouvée seule (v5d)
jouer A7-corps-modifie 1 "candidat vérifié, normalisé\\|≠ candidat vérifié" "sed -i 's/R1_marge/R1_marge_modifiee/' $P; sed -i '0,/0,15/s/0,15/0,25/' $P && resceller $P"
jouer A8-code-ajoute 1 "arbre gelé modifié" "echo '# essai' >> src/controle_ia/__init__.py"
jouer A9-pieces-sans-go 1 "GO sur N-018" "sed -i -E 's/ ; décision de Lazar : GO-[0-9-]+ \(R-135\)\././' $P && resceller $P"
jouer A9b-partie-fixe-reecrite 1 "≠ candidat vérifié" "sed -i 's/relu avant le scellement par des sous-agents neufs/non relu/' $P && resceller $P"
jouer A10-entree-en-double 1 "entrée Version 2" "sed -i '10a - Version 2 (N-018) : contenu arbitraire. Pièces : rien.' $P && resceller $P"
jouer A11-go-absent 1 "GO sur N-018" "sed -i '/^| $GO |/d' registres/go.md"
jouer A12-n018-en-attente 1 "N-018 absent ou encore en attente" "sed -i -E 's/^(\| N-018 \|.*)\| tranché : [^|]*\|$/\1| en attente |/' registres/decisions.md"
jouer A13-suite-alteree 1 "sortie de la suite" "echo x >> docs/procedures/revalidation-T0.5-v2/suite-6ec7434-environnement-neuf-v1.txt"
jouer A14-entree-deplacee 1 "entrée Version 2" "python3 -c \"
from pathlib import Path
p = Path('$P'); l = p.read_text(encoding='utf-8').split(chr(10))
i = next(k for k, x in enumerate(l) if x.startswith('- Version 2 (N-018) : '))
e = l.pop(i); j = next(k for k, x in enumerate(l) if x.startswith('- Contrôle mécanique des corrections du brouillon 6'))
l.insert(j, e); p.write_text(chr(10).join(l), encoding='utf-8')\" && resceller $P"
jouer A15-r135-absent 1 "R-135 absent" "sed -i '/^| R-135 |/d' registres/decisions.md"
jouer A16-candidat-relu-faux 1 "candidat relu absent" "sed -i 's/candidat relu \`af09c78b/candidat relu \`bf09c78b/' $P && resceller $P"
jouer A17-branche-citee-autre 1 "PREREG ou BRANCHE" "sed -i '3s/calcul\/t05-revalidation-reel-v2/calcul\/t05-revalidation-reel-v3/' $P && resceller $P"
echo "FIN DU BANC"
