import os, subprocess, sys, tempfile, time, importlib.util
from pathlib import Path
sys.path.insert(0, "/home/user/controle-ia-travail/tests")
spec = importlib.util.spec_from_file_location("t03", "/home/user/controle-ia-travail/tests/test_simulation_t03.py")
t03 = importlib.util.module_from_spec(spec); spec.loader.exec_module(t03)
from controle_ia.simulation_t03 import run_t03 as R
from controle_ia.gardes import GardeArret
d = Path(tempfile.mkdtemp(dir=os.environ["TMPDIR_SONDE"]))
g = lambda *a: subprocess.run(["git", "-C", str(d), *a], check=True, capture_output=True)
g("init", "-q", "-b", "main"); g("config", "user.email", "t@x.invalid"); g("config", "user.name", "t"); g("config", "commit.gpgsign", "false")
(d / "README").write_text("x\n"); g("add", "-A"); g("commit", "-q", "-m", "init")
pp, gp = t03._preparer(d)
vrai = time.monotonic
t0 = None
B = R.B
orig = B.calibrer
def calibrer(ctx, cfg):
    t = vrai(); r = orig(ctx, cfg); print(f"calibrer {cfg}: {vrai()-t:.4f} s"); return r
B.calibrer = calibrer
try:
    R.executer(d, pp, gp, "20261004-140002-mini", limite_s=0.0, verifier_import=False)
    print("PAS D'ARRÊT")
except GardeArret as e:
    print("arrêt :", e)
