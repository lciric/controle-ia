import sys
sys.path.insert(0, "/home/user/controle-ia-travail/tests")
import numpy as np
import importlib.util
spec = importlib.util.spec_from_file_location("ts", "/home/user/controle-ia-travail/tests/test_sondes_v0.py")
ts = importlib.util.module_from_spec(spec); spec.loader.exec_module(ts)
fa, ev = ts.fa, ts.ev
for famille, agr in [("difference_moyennes", "max"), ("lineaire", "max"), ("perceptron", "max"), ("attention", "attention"), ("lineaire", "attention")]:
    s = fa.entrainer(famille, f"s-{famille}", 7, ts.ENTR[0], ts.ENTR[1], agr, graine=3, reglages=fa.Reglages(epoques=200))
    r = ts._comparer(s, ts.ENTR, ts.TEST)
    print(famille, agr, "aire", round(r["aire"], 4), "bas", round(r["bas"], 4), "seuil", round(r["plancher_quantile"], 4), "med", round(r["plancher_mediane"], 4))
entr, test = ts._donnees(5, etiquettes_aleatoires=True), ts._donnees(6, etiquettes_aleatoires=True)
for famille in ("difference_moyennes", "lineaire"):
    s = fa.entrainer(famille, "x", 7, entr[0], entr[1], "max", graine=3, reglages=fa.Reglages(epoques=100))
    r = ts._comparer(s, entr, test)
    print("aléatoire", famille, "bas", round(r["bas"], 4), "seuil", round(r["plancher_quantile"], 4))
s = fa.entrainer("mahalanobis", "m", 7, ts.ENTR[0], ts.ENTR[1], "max")
print("mahalanobis aire", ev.aire_sous_courbe(ev.scores_actions(s, ts.TEST[0]), ts.TEST[1]))
