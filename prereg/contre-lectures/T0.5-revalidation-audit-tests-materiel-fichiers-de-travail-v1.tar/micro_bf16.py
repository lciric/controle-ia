import os, sys, torch
torch.set_num_threads(1)
torch.manual_seed(0)
for K, N in ((32, 32), (32, 64), (64, 32), (32, 130)):
    lin = torch.nn.Linear(K, N, bias=False).to(torch.bfloat16)
    x = torch.randn(300, K).to(torch.bfloat16)
    res = {}
    for enabled in (True, False):
        torch.backends.mkldnn.enabled = enabled
        with torch.no_grad():
            full = lin(x)
            diffs = []
            for M in (1, 2, 4, 8, 17):
                part = lin(x[:M])
                diffs.append(int((part != full[:M]).sum()))
            # batched 3D (B, L, K) like model input vs 2D single
            b3 = lin(x[:200].view(4, 50, K))
            s = lin(x[50:100].view(1, 50, K))
            diffs.append(int((b3[1] != s[0]).sum()))
        res[enabled] = diffs
    print(f"K={K} N={N} mkldnn on: {res[True]}  off: {res[False]}")
torch.backends.mkldnn.enabled = True
# float32 for comparison
lin = torch.nn.Linear(32, 64, bias=False)
x = torch.randn(300, 32)
with torch.no_grad():
    full = lin(x)
    print("float32:", [int((lin(x[:M]) != full[:M]).sum()) for M in (1, 2, 4, 8, 17)])
