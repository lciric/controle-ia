import json, os, subprocess, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, "/home/user/controle-ia-travail/tests")
import importlib.util
spec = importlib.util.spec_from_file_location("trv", "/home/user/controle-ia-travail/tests/test_revalider_pilote_a.py")
# reproduit le test sans signal : mêmes fichiers, même configuration
from controle_ia.scellement import sceller
d = Path(tempfile.mkdtemp(dir=os.environ["TMPDIR_SONDE"]))
g = lambda *a: subprocess.run(["git", "-C", str(d), *a], check=True, capture_output=True)
g("init", "-q", "-b", "main"); g("config", "user.email", "t@x.invalid"); g("config", "user.name", "t"); g("config", "commit.gpgsign", "false")
(d / "README").write_text("x\n"); g("add", "-A"); g("commit", "-q", "-m", "init")
m = spec.loader.load_module() if False else None
CONFIG = {"N": 1, "T": 2, "episodes_par_tache": 1, "lot": 2, "max_nouveaux": 6, "temperature": 1.0,
          "couches": [0, 1, 2], "fraction_equivalence": 1.0, "statistique_equivalence": "q99",
          "tolerance_equivalence": 0.2, "positions_min_controle_negatif": 4, "actions_min_controle_negatif": 1,
          "fraction_min_controle_negatif": 0.95, "agent": {"nom": "agent-jouet"}, "mode": "jouet", "fils": 1,
          "bras": ["defaut", "math"], "nombre_taches": 4, "transcriptions_repere": 2, "actions_min_comparees": 4,
          "part_min_contexte_couvert": 0.9, "memoire_carte_min_gio": 75, "memoire_pic_max_gio": 70,
          "marge_q99": 0.15, "rho_max": 3, "duree_max_s": 600, "duree_max_bras_s": 300,
          "duree_max_episodes_pilote_s": 1e9, "chemin": {"T": 2, "tolerance": 1e-5},
          "controle_positif": {"T": 2, "decalage_positions": 1, "positions_min": 4, "actions_min": 1, "fraction_min": 0.95}}
def taches(prefixe, n, longueur=lambda k: 1 + k):
    return [{"identifiant": f"{prefixe}.{k:05d}v1", "questions": f"Why do routers matter in setting {k}? " * longueur(k),
             "classification": {"theory_experiment": "mostly_experiments", "data_type": "real_only", "domains": []}} for k in range(n)]
(d / "config.json").write_text(json.dumps(dict(CONFIG, T=4)), encoding="utf-8"); sceller(d / "config.json")
ch = []
for nom, t in (("entrainement", taches("2601", 4)), ("evaluation", taches("2602", 64, lambda k: 1))):
    f = d / f"taches-{nom}.json"; f.write_text(json.dumps({"taches": t}), encoding="utf-8"); sceller(f); ch.append(str(f))
g("add", "-A"); g("commit", "-q", "-m", "etape")
run = "20261007-000009-revalidation-term"
env = dict(os.environ, PYTHONPATH="/home/user/controle-ia-travail/src", PYTHONDONTWRITEBYTECODE="1")
t0 = time.monotonic()
p = subprocess.Popen([sys.executable, "-m", "controle_ia.environnements.revalider_pilote_a", "--config", "config.json",
                      "--entrainement", ch[0], "--evaluation", ch[1], "--run-id", run], cwd=d, env=env,
                     stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
sceau = d / "runs" / run / "manifeste.json.sha256"
while not sceau.exists() and p.poll() is None:
    time.sleep(0.05)
t1 = time.monotonic()
p.communicate()
t2 = time.monotonic()
print(f"démarrage→sceau {t1-t0:.1f} s ; sceau→fin {t2-t1:.1f} s ; code {p.returncode}")
