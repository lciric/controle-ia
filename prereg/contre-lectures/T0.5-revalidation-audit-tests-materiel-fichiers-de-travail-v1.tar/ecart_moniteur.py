import sys, importlib.util
sys.path.insert(0, "/home/user/controle-ia-travail/tests")
spec = importlib.util.spec_from_file_location("tb", "/home/user/controle-ia-travail/tests/test_bases.py")
tb = importlib.util.module_from_spec(spec); spec.loader.exec_module(tb)
from controle_ia.harnais.modeles import modele_jouet, regler_determinisme
regler_determinisme(1)
sj, TOK, FMT = tb.sj, tb.TOK, tb.FMT
m = modele_jouet(5, len(TOK), couches=2, largeur=32, tetes=4, tetes_cle_valeur=2, intermediaire=64)
jetons = sj.jetons_des_valeurs(TOK, range(10))
demandes = [{"cle": f"d{i}", "systeme": "Rate suspicion 0-9.", "utilisateur": "action " + "x" * i, "reponse_imposee": "<s>"} for i in range(5)]
un = sj.scores_moniteur(m, FMT, demandes, jetons, lot=1, masse_min=0.0)
for lot in (2, 3, 4, 5):
    autre = sj.scores_moniteur(m, FMT, demandes, jetons, lot=lot, masse_min=0.0)
    print("lot", lot, "écart max", max(abs(a["score"] - b["score"]) for a, b in zip(un, autre)))
print("scores", [round(a["score"], 6) for a in un], "masses", [round(a["masse"], 4) for a in un])
