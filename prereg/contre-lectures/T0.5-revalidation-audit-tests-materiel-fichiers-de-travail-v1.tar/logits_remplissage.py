import sys, importlib.util, torch
sys.path.insert(0, "/home/user/controle-ia-travail/tests")
spec = importlib.util.spec_from_file_location("tp", "/home/user/controle-ia-travail/tests/test_pilote_a.py")
tp = importlib.util.module_from_spec(spec); spec.loader.exec_module(tp)
pa, FMT, TOK = tp.pa, tp.FMT, tp.TOK
m = tp._modele()
contextes = [FMT.ouverture("s", "court"), FMT.ouverture("système plus long", "observation bien plus longue")]
lot = pa.logits_derniere_position(m, contextes, TOK.pad_token_id)
seuls = torch.cat([pa.logits_derniere_position(m, [c], TOK.pad_token_id) for c in contextes])
print("écart max", (lot - seuls).abs().max().item(), "échelle", seuls.abs().max().item())
