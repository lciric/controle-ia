"""Émulation de l'instance AVX2 (EPYC 7513) : écarts de la phase de production (statistique q99) ramenés à zéro,
profils compris (pire cas : aucun écart non nul dans la zone générée)."""
import os
import pytest


@pytest.fixture(autouse=True)
def _production_a_ecart_nul(monkeypatch):
    from controle_ia.harnais import validation_reelle as V
    reel = V.jouer_episodes
    profils_aussi = os.environ.get("ZERO_PROFILS") == "1"

    def jouer(*a, **k):
        sorties = reel(*a, **k)
        if k.get("statistique") == "q99":
            for _, _, r in sorties:
                for champ in ("ecarts", "ecarts_q99"):
                    r[champ] = {cle: {c: 0.0 for c in pc} for cle, pc in r[champ].items()}
                if profils_aussi:
                    for cle, pc in r["profils"].items():
                        for c, p in pc.items():
                            p.update(q50=0.0, q99=0.0, max=0.0, nuls=p["jetons"])
                            for z in ("contexte", "generee"):
                                if p[z].get("jetons"):
                                    p[z].update(q50=0.0, q99=0.0, max=0.0, nuls=p[z]["jetons"])
        return sorties
    monkeypatch.setattr(V, "jouer_episodes", jouer)
