import os, subprocess, sys, tempfile
from pathlib import Path
from controle_ia.harnais import validation_reelle as V
from controle_ia.gardes import GardeArret
PETITE = dict(V.CONFIG_REPETITION, production=dict(V.CONFIG_REPETITION["production"], episodes=4, T=2, max_nouveaux=8),
              debit={"tailles_lot": [1, 4], "longueur_contexte": 32, "max_nouveaux": 4})
stricte = dict(PETITE, production=dict(PETITE["production"], tolerance=1e-9))
reel = V.jouer_episodes
def jouer(*a, **k):
    s = reel(*a, **k)
    if k.get("statistique") == "q99":
        for _, _, r in s:
            for champ in ("ecarts", "ecarts_q99"):
                r[champ] = {cle: {c: 0.0 for c in pc} for cle, pc in r[champ].items()}
    return s
V.jouer_episodes = jouer
d = Path(tempfile.mkdtemp(dir=os.environ["TMPDIR_SONDE"]))
g = lambda *a: subprocess.run(["git", "-C", str(d), *a], check=True, capture_output=True)
g("init", "-q", "-b", "main"); g("config", "user.email", "t@x.invalid"); g("config", "user.name", "t"); g("config", "commit.gpgsign", "false")
(d / "README").write_text("x\n"); g("add", "-A"); g("commit", "-q", "-m", "init")
try:
    V.executer(d, "20261004-240000-repetition-jouet", entropie=11, config=stricte, verifier_import=False)
    print("PAS D'ARRÊT")
except GardeArret as e:
    print("ARRÊT :", str(e)[:600])
