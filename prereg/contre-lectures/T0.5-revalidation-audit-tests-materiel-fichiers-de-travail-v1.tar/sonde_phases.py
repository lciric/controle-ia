"""Joue la répétition jouet (config PETITE des tests) dans un dépôt jetable et imprime, par phase, les grandeurs
dont dépendent les tests : écart max, 99e centile max, zéros de la zone générée, contrôle négatif, lecture."""
import json, os, subprocess, sys, tempfile, time
from pathlib import Path
import torch
if os.environ.get("EMUL_SANS_MKLDNN") == "1":
    torch.backends.mkldnn.enabled = False
from controle_ia.harnais import validation_reelle as V
from controle_ia.gardes import GardeArret

PETITE = dict(V.CONFIG_REPETITION, production=dict(V.CONFIG_REPETITION["production"], episodes=4, T=2, max_nouveaux=8),
              debit={"tailles_lot": [1, 4], "longueur_contexte": 32, "max_nouveaux": 4})

def depot():
    d = Path(tempfile.mkdtemp(dir=os.environ.get("TMPDIR_SONDE")))
    g = lambda *a: subprocess.run(["git", "-C", str(d), *a], check=True, capture_output=True)
    g("init", "-q", "-b", "main"); g("config", "user.email", "t@x.invalid"); g("config", "user.name", "t")
    g("config", "commit.gpgsign", "false")
    (d / "README").write_text("x\n"); g("add", "-A"); g("commit", "-q", "-m", "init")
    return d

for ent in [int(x) for x in sys.argv[1:]]:
    d = depot(); t0 = time.time()
    try:
        s = V.executer(d, f"20261004-160000-repetition-jouet", entropie=ent, config=PETITE, verifier_import=False)
        r = json.loads((d / s["resume"]).read_text())["resultat"]; issue = "ok"
    except GardeArret as e:
        r = json.loads((d / "diag" / "20261004-160000-repetition-jouet" / "arret.json").read_text())["resultat"]
        issue = "ARRET " + str(e)[:120]; r = dict(r["partiel"], lecture=r["partiel"].get("lecture_partielle"))
    out = {"entropie": ent, "issue": issue, "s": round(time.time() - t0, 1)}
    for ph in ("logique", "chemin", "production"):
        if ph not in r: continue
        b = r[ph]["equivalence"]
        z = b["zeros"]
        out[ph] = {"max": b["ecart_max"], "q99max": b["ecart_q99_max"],
                   "gen_nuls/total": {c: v["generee"] for c, v in z.items()},
                   "cn": (b["controle_negatif"]["passent"], b["controle_negatif"]["comparables"])}
    for pc in ("controle_positif", "controle_positif_chemin"):
        if pc in r: out[pc] = (r[pc]["bilan"]["vus"], r[pc]["bilan"]["comparables"], r[pc]["bilan"]["min_des_maxima"])
    out["lecture"] = {k: v for k, v in (r.get("lecture") or {}).items() if v not in ("conforme", "sans objet", "non déclenché")}
    print(json.dumps(out, ensure_ascii=False), flush=True)
