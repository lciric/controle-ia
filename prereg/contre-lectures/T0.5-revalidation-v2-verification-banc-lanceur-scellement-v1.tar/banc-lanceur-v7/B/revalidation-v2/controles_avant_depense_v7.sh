#!/usr/bin/env bash
# faux contrôles : crée le dossier du clone, échoue si FAUX_KO est posé
mkdir -p "$2" && echo donnees > "$2/x"
if [ -n "${FAUX_KO:-}" ]; then echo "OK  essai"; echo "KO  essai : faute simulée"; echo "CONTRÔLES AVANT DÉPENSE : ÉCHEC"; exit 1; fi
echo "OK  essai"; echo "CONTRÔLES AVANT DÉPENSE : TOUS CONFORMES"
