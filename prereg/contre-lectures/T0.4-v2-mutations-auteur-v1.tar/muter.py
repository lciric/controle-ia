import shutil, subprocess, sys, pathlib
racine = pathlib.Path("/home/user/controle-ia")
base = pathlib.Path(sys.argv[1])
MUT = {
 "M02-ordre-des-gardes": ("src/controle_ia/harnais/validation_reelle.py",
   '''        phase = "logique"
        appliquer_gardes(sorties, resume["logique"]["equivalence"], "logique", cn)
        phase = "controle_positif"
        exiger_controle_positif(resume["controle_positif"]["bilan"], cp, "contrôle positif")''',
   '''        phase = "controle_positif"
        exiger_controle_positif(resume["controle_positif"]["bilan"], cp, "contrôle positif")
        phase = "logique"
        appliquer_gardes(sorties, resume["logique"]["equivalence"], "logique", cn)'''),
 "M13-T-de-la-logique": ("src/controle_ia/harnais/validation_reelle.py",
   '''        c_pc = dict(c, T=cp["T"])''', '''        c_pc = dict(c)'''),
 "M14-graines-de-la-logique": ("src/controle_ia/harnais/validation_reelle.py",
   '''jouer_phase(modele, fmt, c_pc, graines, "controle-positif", couches''', '''jouer_phase(modele, fmt, c_pc, graines, "logique", couches'''),
 "M20-ulp-simple": ("src/controle_ia/harnais/activations.py",
   '''    p[n, 0] = np.nextafter(p[n, 0], p.dtype.type(np.inf), dtype=p.dtype)''',
   '''    p[n, 0] = p[n, 0] + np.spacing(np.float32(p[n, 0]))'''),
 "M30-sans-normalisation-double-chargement": ("src/controle_ia/harnais/modeles.py",
   '''        modele = modele.to(torch.float64).to(appareil)
        normalisations_en_double(modele)''', '''        modele = modele.to(torch.float64).to(appareil)'''),
 "M31-sans-normalisation-double-jouet": ("src/controle_ia/harnais/validation_reelle.py",
   '''        if dtype == "float64":
            normalisations_en_double(m)''', '''        if dtype == "float64":
            pass'''),
 "M32-trajectoires-non-ecrites": ("src/controle_ia/harnais/validation_reelle.py",
   '''            ecrire_resultat(racine, chemin_m, f"controle-positif-{ep.identifiant}-trajectoire", ep.en_dict())''',
   '''            pass'''),
 "M33-normalisation-simple": ("src/controle_ia/harnais/modeles.py",
   '''    variance = x.pow(2).mean(-1, keepdim=True)
    return self.weight * (x * torch.rsqrt(variance + self.variance_epsilon))''',
   '''    h = x.to(torch.float32)
    variance = h.pow(2).mean(-1, keepdim=True)
    return self.weight * (h * torch.rsqrt(variance + self.variance_epsilon)).to(x.dtype)'''),
}
TESTS = ["tests/test_validation_reelle.py", "tests/test_harnais_lots.py"]
for nom, (f, old, new) in MUT.items():
    d = base / nom
    shutil.copytree(racine / "src", d / "src"); shutil.copytree(racine / "tests", d / "tests")
    for x in ("pyproject.toml", "pytest.ini", "setup.cfg"):
        if (racine / x).exists(): shutil.copy(racine / x, d / x)
    t = (d / f).read_text(encoding="utf-8"); assert t.count(old) == 1, nom
    (d / f).write_text(t.replace(old, new), encoding="utf-8")
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "-x", *TESTS], cwd=d,
                       env={"PYTHONPATH": str(d / "src"), "PATH": "/usr/bin:/bin"}, capture_output=True, text=True)
    der = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-200:]
    print(f"{nom}: {'VUE' if r.returncode else 'NON VUE'} — {der}", flush=True)
