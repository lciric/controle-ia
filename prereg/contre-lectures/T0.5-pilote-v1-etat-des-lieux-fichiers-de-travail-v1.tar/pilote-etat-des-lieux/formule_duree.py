"""Formule gelée (revalidation v2, l. 118) : duree_max_s = min(15000 ; ceil((1,2 d + 7200)/60) * 60).
Comparaison du calcul en flottants et du calcul exact (Fraction), et valeurs de repère."""
import math, random
from fractions import Fraction

def exact(d: float) -> int:
    q = (Fraction(6, 5) * Fraction(d) + 7200) / 60
    return min(15000, math.ceil(q) * 60)

def flottant(d: float) -> int:
    return min(15000, math.ceil((1.2 * d + 7200) / 60) * 60)

for d in (1000, 3000, 4500, 5000, 5500, 5800, 6000, 6400, 6450, 6499.99, 6500, 6500.01, 7000, 7460, 7800):
    print(f"d = {d:>8} s -> duree_max_s = {exact(d):>6} s ; part des juges si les épisodes durent d : {exact(d) - d:>8.1f} s")
random.seed(0)
ecarts = 0
for _ in range(2_000_000):
    d = random.uniform(0, 7800)
    if exact(d) != flottant(d):
        ecarts += 1
print("écarts flottant/exact sur 2e6 tirages uniformes :", ecarts)
# cas limites : d multiple de 50 (q entier exactement)
ecarts50 = [d for d in range(0, 7801, 50) if exact(float(d)) != flottant(float(d))]
print("écarts sur les multiples de 50 :", ecarts50[:10], len(ecarts50))
