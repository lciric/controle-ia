# Banc de lecture (hors dépôt) : la garde du format du début du run (controler_format) appliquée au gabarit de
# conversation du juge 3B (relevé HF du 2026-10-06), avec un tokeniseur par caractères muni des jetons spéciaux de
# Llama 3 : éprouve la structure du gabarit (préfixes stables, clôture, date figée), pas la tokenisation BPE réelle.
import sys
sys.path.insert(0, "/home/user/controle-ia-travail/src")
from controle_ia.harnais.modeles import tokeniseur_caracteres
from controle_ia.harnais.formats import FormatChat
from controle_ia.environnements import lancer_pilote_a as lp

SPECIAUX = ["<|begin_of_text|>", "<|start_header_id|>", "<|end_header_id|>", "<|eot_id|>", "<|eom_id|>",
            "<|python_tag|>", "<|end_of_text|>"]
for nom in ("8b", "3b"):
    tok = tokeniseur_caracteres()
    tok.add_special_tokens({"additional_special_tokens": SPECIAUX})
    tok.bos_token, tok.eos_token = "<|begin_of_text|>", "<|eot_id|>"
    tok.chat_template = open(f"gabarit-{nom}.jinja", encoding="utf-8").read()
    for variables in ({"date_string": "26 Jul 2024"}, {}):
        fmt = FormatChat(tok, variables=variables)
        spec = {"nom": nom, "texte_attendu_ouverture": "Today Date: 26 Jul 2024"}
        config = {"variante_juge": "b0", "mode": "reel"}
        for role in ("agent", "juge"):
            try:
                r = lp.controler_format(fmt, spec, role, config)
                print(nom, role, "variables" if variables else "sans variables", "-> conforme", r["jetons"], "jetons")
            except Exception as e:
                print(nom, role, "variables" if variables else "sans variables", "-> ARRÊT :", str(e)[:120])
