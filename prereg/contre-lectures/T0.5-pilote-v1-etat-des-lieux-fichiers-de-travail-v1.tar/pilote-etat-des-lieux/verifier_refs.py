"""Vérifie, au HEAD du dépôt, les chemins et empreintes cités par les brouillons du pilote (lecture seule)."""
import hashlib
import subprocess
import sys

DEPOT = "/home/user/controle-ia-travail"


def show(chemin, rev="HEAD"):
    r = subprocess.run(["git", "-C", DEPOT, "show", f"{rev}:{chemin}"], capture_output=True)
    return r.stdout if r.returncode == 0 else None


def sha(chemin, rev="HEAD"):
    b = show(chemin, rev)
    return hashlib.sha256(b).hexdigest() if b is not None else None


def suivi(chemin):
    r = subprocess.run(["git", "-C", DEPOT, "ls-files", "--error-unmatch", chemin], capture_output=True)
    return r.returncode == 0


# (chemin, préfixe attendu ou None, source de la citation)
REFS = [
    ("docs/brief-claude-code-programme-complet-v2.md", "9261932a", "b7 l.16"),
    ("docs/programme-controle-ia-v2.md", "2fd63bad", "b7 l.16"),
    ("docs/decisions/proposition-P-007-plan-G0-v1.md", "56b9182b", "b7 l.18"),
    ("diag/20261006-134235-t05-corpus/corpus.json", "57f0aa47", "b7 l.20, l.43"),
    ("runs/20261006-134235-t05-corpus/manifeste.json", "92612ab6", "b7 l.20"),
    ("docs/procedures/T0.5-selection-papiers-v1.md", "8f43dcae", "b7 l.20 (règle de sélection)"),
    ("docs/procedures/T0.5-extraction-v1.md", None, "b7 l.21 (À REMPLIR)"),
    ("docs/sources/invites-2606.08892-v1/index.json", None, "b7 l.22 (À REMPLIR)"),
    ("prereg/T0.4-validation-modele-reel-v3.md", "4f711cd3", "b7 l.23"),
    ("docs/verdicts/verdict-T0.4-critere-1-G0-v3.md", "63444faa", "b7 l.23"),
    ("prereg/contre-lectures/T0.5-pilote-rapport-contre-lecture-2-v1.md", "4e5d05bf", "b7 l.128, l.245"),
    ("prereg/contre-lectures/T0.5-pilote-contre-lecture-2-verifications-v1.tar", "29ac2d68", "b7 l.128 (sans dossier)"),
    ("prereg/contre-lectures/T0.5-pilote-verification-3-fichiers-de-travail-v1.tar", "62884015", "b7 l.131, l.246"),
    ("prereg/contre-lectures/T0.5-pilote-rapport-contre-lecture-1-v1.md", "9d8e3c81ca113e8d529aedd0b751c9595adcca4cf85334466d90aa9fcf921f9e", "b7 l.244"),
    ("prereg/contre-lectures/T0.5-pilote-rapport-verification-3-v1.md", "93904e2f508b7313fdfae0c7685a1d32361c9ab84cdf173a0902d829ea801fe3", "b7 l.246"),
    ("prereg/contre-lectures/T0.5-pilote-rapport-relecture-differentiel-b5-v1.md", "43f0df464806bd23f8f51ffab5d91714b85769b45d241fd11e3be9b5a238440a", "b7 l.247"),
    ("prereg/contre-lectures/T0.5-pilote-relecture-differentiel-b5-fichiers-de-travail-v1.tar", "7d7c64788953e11fc9371d7021678b0f7ce5e5b75fec722cf43910c20a3172a8", "b7 l.247"),
    ("prereg/contre-lectures/T0.5-revalidation-rapport-relecture-differentiel-b4-v1.md", "1bc632e81650bd03e4010c135da4d6da2f1e75a2cea985043cae8e4145376caf", "b7 l.248"),
    ("prereg/contre-lectures/T0.5-pilote-rapport-relecture-differentiel-b6-v1.md", "d676ba35ddc41a165614d432d7bdde8e31c0c23aadb349c51f6909fb42a02bae", "b7 l.249"),
    ("prereg/contre-lectures/T0.5-pilote-relecture-differentiel-b6-fichiers-de-travail-v1.tar", "621df5674bd508eff27b04e8f1fb94e9f94c7d027fe911ef1d12eeb8eb2938c1", "b7 l.249"),
    ("prereg/contre-lectures/T0.5-revalidation-rapport-relecture-differentiel-b5-v1.md", "8bbfe3877ba9be07d85904b4e6c5096125cdaf4ea0f71e1bf9e389e54be8f25f", "b7 l.250"),
    ("brouillons/T0.5-pilote-config-v1-brouillon1.json", None, "b7 l.10"),
    ("src/controle_ia/environnements/lire_pilote.py", None, "b7 l.11"),
    ("src/controle_ia/environnements/analyse_pilote.py", None, "b7 l.11"),
    ("src/controle_ia/harnais/validation_reelle.py", None, "b7 l.159"),
    ("scripts/amorce_instance_t05.sh", None, "b7 l.6"),
    ("scripts/pilote_t05_instance.sh", None, "b7 l.6"),
    ("donnees/20261007-082440-t05-extraction/taches-evaluation.json", None, "b7 l.12-13 (À REMPLIR)"),
    ("donnees/20261007-082440-t05-extraction/taches-evaluation.json.sha256", None, "sceau des tâches"),
    ("diag/20261007-082440-t05-extraction/bilan-extraction.json", None, "bilan de l'extraction (À REMPLIR)"),
    ("docs/procedures/validation-T0.4-modele-reel-v4.md", None, "proc l.3"),
    ("docs/procedures/surveiller-instance-t04-v1.sh", None, "proc l.145"),
    ("traces/t04-instance-54476244-20261006-121128/journal.txt", "2730b775", "proc l.140"),
    ("tests/test_script_instance_t05.py", None, "proc l.44"),
    ("registres/depenses.md", None, "proc l.37"),
    ("registres/etat.md", None, "proc l.129"),
    ("registres/arrets.md", None, "proc l.158"),
    ("requirements-gpu.txt", None, "script"),
    ("brouillons/T0.5-revalidation-equivalence-pilote-v1-brouillon6.md", None, "proc l.40 (périmé)"),
    ("prereg/T0.5-pilote-8B-v1.md", None, "proc l.3 (à venir)"),
    ("prereg/T0.5-pilote-config-v1.json", None, "b7 l.10 (à venir)"),
]

for chemin, attendu, source in REFS:
    e = sha(chemin)
    if e is None:
        etat = "ABSENT au HEAD"
    elif attendu is None:
        etat = f"présent, sha256 {e}"
    elif e.startswith(attendu):
        etat = f"conforme ({e})"
    else:
        etat = f"DIFFÉRENT : attendu {attendu}…, trouvé {e}"
    print(f"{chemin} [{source}] : {etat}")
