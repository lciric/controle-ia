"""Estimation grossière (non mesurée) de la durée des juges et de l'appariement du pilote, à partir du débit mesuré
de la revalidation v2 (agent 8B, lot de 8, A100 SXM4 + EPYC 7513 : 6 480 passes en 665,85 s, préremplissage compris)."""
lots_dec, lots_desc = 24, 8                       # par juge : 192 notations décisives (A, B, C), 64 descriptives (D)
paires = round(192 * 7.44 * 11.5) + 736           # propositions finales mesurées (7,44) × cibles (11,5) + énoncé seul
lots_app = -(-paires // 32)
scen = {  # passes par lot de juge, ms par passe 8B, ms par passe 3B, s par lot d'appariement, épisodes (s)
    "optimiste": (1500, 70, 50, 1.5, 5300),
    "central":   (2250, 85, 62, 2.0, 7000),
    "pessimiste": (3072, 100, 80, 3.0, 8090),
}
for nom, (passes, ms8, ms3, s_app, ep) in scen.items():
    l8 = 7 + passes * ms8 / 1000
    l3 = 3 + passes * ms3 / 1000
    dec = lots_dec * (l8 + l3)
    app = lots_app * s_app
    desc = lots_desc * (l8 + l3)
    charge = 200                                   # 8B : 120 s de téléchargement mesurés + chargement ; 3B préchargé
    essentiel = ep + charge + app + dec
    tout = essentiel + desc
    print(f"{nom:10s} lot 8B {l8:5.0f} s, lot 3B {l3:5.0f} s ; appariement {app:5.0f} s ({lots_app} lots, {paires} paires) ;"
          f" décisives {dec:6.0f} s ; descriptives {desc:5.0f} s ; essentiel {essentiel:6.0f} s ; tout {tout:6.0f} s ;"
          f" instance (+658 s de mise en place, +300 s) {(tout + 958) / 3600:4.1f} h")
