# Banc de lecture : coût processeur de l'échantillonnage par ligne de generer_lot (softmax + multinomial sur 128 256
# jetons, un fil), tel que le code du dépôt le fait à chaque pas de décodage.
import time, torch
torch.set_num_threads(1)
torch.use_deterministic_algorithms(True)
V, B, PAS = 128256, 8, 200
g = [torch.Generator(device="cpu").manual_seed(k) for k in range(B)]
logits = torch.randn(B, V, dtype=torch.bfloat16).to(torch.float32) * 3
t0 = time.perf_counter()
for _ in range(PAS):
    for r in range(B):
        j = int(torch.multinomial(torch.softmax(logits[r] / 1.0, dim=-1), 1, generator=g[r]))
dt = (time.perf_counter() - t0) / (PAS * B)
print(f"échantillonnage : {dt*1e3:.2f} ms par ligne et par pas ; lot de 8 : {dt*8*1e3:.1f} ms par pas")
