"""Sonde de relecture (angle code) : chargement hors ligne du juge 3B dans un cache réaliste.

Reproduit l'état du cache après `precharger_modele` sur l'instance : dossier de la révision avec les seuls fichiers des
motifs de préchargement (point de contrôle jouet, deux fragments de poids et leur index, tokeniseur), et la liste
d'arbre de la révision (`trees/<commit>.json`) telle que huggingface_hub l'écrit, avec les fichiers non téléchargés
du vrai dépôt (original/, README.md, LICENSE.txt…). Le réseau est coupé (socket.connect refusé). Puis
`charger_modele(..., hors_ligne=True)`. Variante : liste d'arbre absente (cas du test du dépôt).
Rien n'est écrit hors du dossier temporaire passé en argument.
"""
from __future__ import annotations

import json
import socket
import sys
from pathlib import Path

import torch

REV = "0cb88a4f764b7a12671c53f0838cd831a0843b95"
NOM = "meta-llama/Llama-3.2-3B-Instruct"
# fichiers du vrai dépôt à cette révision (traces/hf-revisions-20261006-1645/hf-Llama-3.2-3B-Instruct.json)
NON_TELECHARGES = [".gitattributes", "LICENSE.txt", "README.md", "USE_POLICY.md", "original/consolidated.00.pth",
                   "original/orig_params.json", "original/params.json", "original/tokenizer.model"]


def construire(racine: Path, avec_arbre: bool) -> Path:
    import controle_ia.harnais.modeles as M
    from huggingface_hub._tree_cache import TREE_CACHE_FORMAT_VERSION

    depot = racine / ("models--" + NOM.replace("/", "--"))
    snap = depot / "snapshots" / REV
    snap.mkdir(parents=True)
    tok = M.tokeniseur_caracteres_chat()
    m = M.modele_jouet(5, len(tok), couches=2, largeur=32, tetes=4, tetes_cle_valeur=2, intermediaire=64).to(
        torch.bfloat16)
    m.save_pretrained(snap, max_shard_size="40KB")
    tok.save_pretrained(snap)
    # ne garder que ce que les motifs de préchargement auraient téléchargé
    from huggingface_hub.utils import filter_repo_objects
    presents = sorted(str(p.relative_to(snap)) for p in snap.rglob("*") if p.is_file())
    gardes = set(filter_repo_objects(presents, allow_patterns=list(M.MOTIFS_PRECHARGEMENT)))
    for p in presents:
        if p not in gardes:
            (snap / p).unlink()
    restants = sorted(str(p.relative_to(snap)) for p in snap.rglob("*") if p.is_file())
    if avec_arbre:
        fichiers = {p: {"size": (snap / p).stat().st_size, "blob_id": "0" * 40} for p in restants}
        fichiers.update({p: {"size": 1, "blob_id": "1" * 40} for p in NON_TELECHARGES})
        (depot / "trees").mkdir()
        (depot / "trees" / f"{REV}.json").write_text(json.dumps({"format_version": TREE_CACHE_FORMAT_VERSION,
                                                                  "files": fichiers}), encoding="utf-8")
    (depot / "refs").mkdir()
    (depot / "refs" / "main").write_text(REV, encoding="utf-8")
    return snap, presents, restants


def main(dossier: str) -> int:
    import controle_ia.harnais.modeles as M

    tentatives = []

    def refuser(self, *a, **k):
        import traceback; tentatives.append(a); print("  TENTATIVE RESEAU", a); [print("    ", f.filename.split("site-packages/")[-1], f.lineno, f.name) for f in traceback.extract_stack(limit=60) if ("huggingface_hub" in f.filename or "transformers" in f.filename or "controle_ia" in f.filename)]
        raise OSError("réseau interdit dans cette sonde")
    socket.socket.connect = refuser
    socket.socket.connect_ex = refuser
    racine = Path(dossier)
    for avec_arbre in (True, False):
        r = racine / ("avec-arbre" if avec_arbre else "sans-arbre")
        snap, presents, restants = construire(r, avec_arbre)
        print(f"[{'avec' if avec_arbre else 'sans'} liste d'arbre] écrits par save_pretrained : {presents}")
        print(f"  gardés par MOTIFS_PRECHARGEMENT : {restants}")
        try:
            modele, tok = M.charger_modele(NOM, REV, "bfloat16", "cpu", hors_ligne=True, cache_dir=str(r))
            print(f"  chargement hors ligne : OK ({sum(p.numel() for p in modele.parameters())} paramètres, "
                  f"{len(tok)} jetons) ; tentatives réseau : {len(tentatives)}")
        except Exception as e:                       # noqa: BLE001
            print(f"  chargement hors ligne : ÉCHEC {type(e).__name__}: {str(e)[:400]}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
