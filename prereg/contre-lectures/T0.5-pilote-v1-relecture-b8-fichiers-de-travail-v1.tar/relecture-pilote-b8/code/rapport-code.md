# Relecture R2 du pilote 8B de T0.5, candidat 1 — angle « code »

- Relecteur : sous-agent neuf (n'a écrit ni le préenregistrement, ni le code, ni la chaîne de lancement), angle « code ».
- Date : 2026-10-12, vers 01:30-02:10 UTC.
- Dépôt : `/home/user/controle-ia-travail`, branche `main`, tête `942c65e365f809b7142b280b4adc1922ce3ab67c` (lecture seule ;
  `git status --short --ignored` identique avant et après mes essais ; aucun fichier créé dans le dépôt).
- Objet : différentiel `git diff e6ce058..HEAD -- src/ scripts/ tests/`, parties qui touchent le pilote (commits 41d8985,
  6297b8e, 89b647f, 3b8c049, **1f53a08**, **197e909** ; aucun changement de code entre 197e909 et 3ffab9f, ni entre 3ffab9f et
  la tête sur l'arbre gelé).
- Empreintes vérifiées : `brouillons/T0.5-pilote-8B-v1-candidat1.md` = `15a5cd3e…3b33150` ; `brouillons/T0.5-pilote-config-v1-candidat1.json`
  = `6979a00e…5c95da4434da2b8a`.
- Règles : aucune commande vastai ; aucune valeur de jeton affichée (seule la présence de `HF_TOKEN` a été testée) ;
  `episodes-defaut.json` et `chemin-defaut.json` non ouverts (leur taille seule a été lue par `stat`) ; aucun clone.

## Verdict

**Aucun constat bloquant, aucun majeur.** Le préchargement du 3B couvre exactement ce que le chargement hors ligne lit
(vérifié par un essai à blanc sur la vraie révision et par un chargement hors ligne dans un cache réaliste), l'ordre
« appariement d'abord » est en place et ses arrêts partiels sont lisibles, les poussées en trois tentatives se comportent
comme annoncé (y compris celle des vecteurs, que la suite n'éprouve pas). Neuf constats mineurs (dont trois lacunes de
tests au sens de R5, comblées ici par des sondes) et six informations, dont les marges de temps chiffrées.

## Méthode

- Lecture du différentiel et du code courant : `lancer_pilote_a.py`, `pilote_a.py`, `lire_pilote.py`, `harnais/modeles.py`,
  `harnais/episode.py` (génération), `gardes.py`, `manifeste.py`, `validation_reelle.py`, scripts de l'instance et de
  l'amorce, tests ; chaîne du bloc-notes (`controles_avant_depense_pilote_v1.sh`, `lancer_pilote_v1.sh`,
  `recuperation_pilote_v1.sh`, `repetition_jouet_pilote_v1.sh`) et plan versé.
- Lecture des bibliothèques installées (transformers 5.18.0, huggingface_hub 1.33.0) : `snapshot_download`,
  `_raise_if_incomplete_snapshot`, `list_repo_templates`, `cached_files`, registre des agents, `DynamicLayer.update`.
- Sondes (toutes sous `…/relecture-pilote-b8/code/`, sorties dans `sorties/`) :
  1. `sonde_hors_ligne*.py` : cache au format de huggingface_hub, réseau coupé, **liste d'arbre de la révision écrite comme
     le fait huggingface_hub, avec les fichiers non téléchargés du vrai dépôt** (`original/…`, `README.md`…), point de
     contrôle jouet en deux fragments, seuls les fichiers des motifs de préchargement gardés ; puis
     `charger_modele(..., hors_ligne=True)` ;
  2. essai à blanc (`dry_run=True`) de `snapshot_download` avec `MOTIFS_PRECHARGEMENT` sur la vraie révision du 3B
     (aucun poids téléchargé ; cache et `HF_HOME` temporaires, supprimés) ;
  3. `sonde_echec_prechargement.py` : échec du préchargement au niveau du lanceur (`executer`, mode jouet) ;
  4. `sonde_etat_partiel.py` : lecture (`preparer_etiquetage`, `analyser`) de l'état « épisodes seuls » ;
  5. `sonde_vecteurs/test_sonde_vecteurs.py` : le vrai script de l'instance (ETUDE=pilote, MODE=jouet), poussée des
     vecteurs refusée une fois, puis toujours.

## Réponses aux questions

### 1. Préchargement et chargement hors ligne

**Oui, le préchargement télécharge exactement ce que `charger_modele(..., hors_ligne=True)` lit.**

- Révision : la même spécification de juge sert aux deux appels (`lancer_pilote_a.py:242` et `:370-371`, `j["revision"]`),
  un commit de 40 caractères exigé par `exiger_modele_autorise` (`modeles.py:96-101`). `snapshot_download` saute alors la
  résolution de la révision et range les fichiers sous `snapshots/<commit>/` ; la garde `dossier.name != revision`
  (`modeles.py:123-124`) le vérifie.
- Cache : `cache_dir=None` des deux côtés ; huggingface_hub (`_snapshot_download.py`) et transformers (`utils/hub.py:482`)
  prennent tous deux `constants.HF_HUB_CACHE`, dans le même processus, sous le même `HOME`.
- Motifs : essai à blanc sur la vraie révision (`sorties/essai-a-blanc-prechargement-3B.txt`) :
  ```
  FICHIER config.json 878
  FICHIER generation_config.json 189
  FICHIER model-00001-of-00002.safetensors 4965799096
  FICHIER model-00002-of-00002.safetensors 1459729952
  FICHIER model.safetensors.index.json 20919
  FICHIER special_tokens_map.json 296
  FICHIER tokenizer.json 9085657
  FICHIER tokenizer_config.json 54528
  TOTAL 8 fichiers, 6434691515 octets
  ```
  `original/consolidated.00.pth` (poids d'origine) est bien écarté. Le gabarit de conversation du 3B est dans
  `tokenizer_config.json` (pas de `chat_template.jinja` dans le dépôt à cette révision : liste des fichiers de
  `traces/hf-revisions-20261006-1645/hf-Llama-3.2-3B-Instruct.json`).
- Chargement hors ligne dans un cache réaliste (`sorties/sonde_hors_ligne.txt`) : avec la liste d'arbre de la révision
  (qui nomme les fichiers non téléchargés), le chargement réussit ; le contrôle de complétude de huggingface_hub
  (`IncompleteSnapshotError`) n'est levé que dans `list_repo_templates`, qui l'attrape (`IncompleteSnapshotError` hérite de
  `LocalEntryNotFoundError`, `transformers/utils/hub.py:165-170`). Seule tentative réseau vue, dans un processus neuf : le
  registre des agents de huggingface_hub (`_detect_agent._fetch_registry`, délai de 3 s, au mieux, mis en cache dans le
  processus) ; sur l'instance il est lu dès le premier appel au dépôt de modèles, au chargement du 8B, avant les épisodes.
  Après l'écriture de `episodes.json`, le run n'a donc plus besoin du réseau.
- Juge qui est l'agent (le 8B) : ni préchargé (`lancer_pilote_a.py:240`), ni rechargé : `modele_du_juge` rend
  `(modele, fmt)` de l'agent (`:370`) ; sa spécification ne porte même pas de modèle ni de révision (configuration
  candidate) ; son format est contrôlé sur celui de l'agent (`:322`). Éprouvé par
  `test_lanceur_prechargement_avant_les_episodes_et_juges_hors_ligne` (`tests/test_pilote_a.py:445`) : deux chargements
  seulement, l'agent en ligne, le 3B hors ligne.
- Le 8B (agent) : chargé **en ligne** au début du run, après le manifeste, sous l'étape « chargement », avant le
  contrôle du format (`:317`) ; son téléchargement compte dans `duree_max_s` ; une panne y arrête avant `episodes.json`
  (relancement permis).
- Échec du préchargement : arrêt avant les épisodes, motif lisible (`sorties/sonde_echec_prechargement.txt`) :
  ```
  étape : préchargement des juges | motif : ConnexionImpossible: [Errno 101] Network is unreachable (simulée)
  fichiers : ['arret.json']
  étape : préchargement des juges | motif : GardeArret: meta-llama/Llama-3.2-3B-Instruct@0cb88a4f764b : préchargement incomplet (['config.json'] absents) (simulé)
  ```
  Ce chemin n'est éprouvé dans la suite qu'au niveau de la fonction (CO-05).

### 2. Ordre et arrêts

- Ordre du code (`lancer_pilote_a.py:325-416`) : contrôle du format → préchargement des juges → épisodes (écriture des
  vecteurs et de `episodes.json`) → **appariement par le 8B, propositions puis « énoncé seul », un seul fichier
  `appariements.json`** (`:374-390`) → chargement des juges (`:391-393`, le 3B hors ligne) → notations décisives, 8B puis 3B
  → notations descriptives, 8B puis 3B. Conforme à la section « Ordre des étapes » du candidat (lignes 142-150).
- `duree_max_s` : contrôlée à chaque pas des épisodes (`episode.py:207-209`), à chaque lot de l'appariement des
  propositions et de l'énoncé seul (`pilote_a.py:236-237`), à chaque lot des notations (`pilote_a.py:164-165`), avec le
  relevé du signal TERM. Non contrôlée (sans conséquence) : chargement du 8B, contrôle du format, préchargement, chargement
  du 3B, écritures ; leur durée est comptée dans l'échéance (départ `debut` après le manifeste). Écart entre l'échéance et
  le délai externe : 16 200 − 15 000 = 1 200 s, pour ≤ ~130 s de dernier lot d'un juge (estimation) : suffisant.
- Lisibilité des arrêts partiels par `lire_pilote.py` (lecture sur les fichiers présents, pas sur l'étiquette) :
  états éprouvés par la suite : « aucune » (pendant les épisodes), « decisives-8B », « decisives-3B », « descriptives »,
  plus les états de l'ordre ancien (« appariement », « 3B »). État nouveau de l'ordre SI-01 non construit par la suite :
  **« épisodes seuls »** (arrêt pendant l'appariement, ou panne pendant celui-ci) ; la sonde montre qu'il est lu
  correctement (`sorties/sonde_etat_partiel.txt`) :
  ```
  fichiers du run : ['arret.json', 'episodes.json']
  familles : non lisibles (arrêt avant la fin de l'appariement) : nœud
  juges : {'8B': 'notations décisives absentes (run partiel) : nœud', '3B': '… : nœud'}
  prédictions : {'P1': 'confirmée', 'P2': 'non concluant', 'P3': 'non concluant', …}
  ```
  Les notations descriptives ne sont pas lues par `analyser` : un arrêt pendant celles du 3B est sans effet sur la lecture.
  `CONFIG_ATTENDUE` est conforme à la configuration candidate (aucun écart).

### 3. Mémoire de la carte

- Au plus **deux modèles** à la fois : le 8B (agent et juge 8B, chargé au début, gardé jusqu'à la fin) et le 3B (chargé
  après l'appariement, gardé jusqu'à la fin). Poids : 8B ≈ 15,0 Gio, 3B ≈ 6,0 Gio (6 425 529 048 octets de fragments).
- Aucune libération explicite entre les étapes (ni `gc.collect()` ni `torch.cuda.empty_cache()` dans
  `lancer_pilote_a.py`, au contraire de `revalider_pilote_a.py:373-375`) ; `del modeles_juges` (`:417`) n'enlève que le
  dictionnaire, en fin de run. Les crochets de capture sont retirés après chaque lot (gestionnaire de contexte,
  `episode.py:222`), le juge 8B ne capture rien.
- Estimation (non mesurée) des notations : contextes ≤ ~10 000 jetons (H4 seule : 19 580 octets ; énoncé ≤ 6 786
  caractères ; ensemble ≤ 10 × 400 jetons) + 3 072 nouveaux, lots de 8 → cache des clés et valeurs ≤ ~12,7 Gio (8B,
  128 Kio par jeton) ou ~11,1 Gio (3B, 112 Kio par jeton) ; transitoires du préremplissage ~6-7 Gio. Pic ≈ 40-55 Gio avec
  la fragmentation, sur 79,4 Gio. Pic mesuré des épisodes à la revalidation : 24,02 Gio (`mesures-defaut.json`).
  Noyau d'attention par défaut (mémoire efficace), pas de matrice d'attention complète. Appariement : passe unique sans
  cache, lots de 32 contextes ≤ ~1 800 jetons : faible.
- Une panne de mémoire pendant les notations laisse `appariements.json` écrit (ordre SI-01) ; au chargement du 3B, elle
  coûte aussi les notations du 8B (CO-01).

### 4. Script de l'instance : poussées en trois tentatives

- Délai externe (`timeout … 270m` autour du seul processus Python, `pilote_t05_instance.sh:312`) : **aucun effet**, les
  poussées ont lieu après le run.
- Plafond de l'amorce (`timeout … 300m`, `amorce_instance_t05.sh:39`) et plafond de la surveillance (création + 17 700 s) :
  au plus 15 + 60 = 75 s d'attente par appel en échec complet ; fin d'un run complet : trois appels (`pousser`,
  `pousser_vecteurs`, `pousser`) → ≤ 225 s ; arrêt consigné (`consigner_arret`) : deux appels → ≤ 150 s, plus la durée des
  tentatives. Chiffrage avec les temps de la revalidation (création 22:46:03, ligne AMORCE 22:46:48, fin des tests
  22:57:01) et +91 s du nouveau test à attentes réelles : début du run ≈ création + 750 s ; fin par l'échéance interne ≈
  création + 15 900 s → marge ≈ 1 600-1 750 s ; fin par le délai externe (TERM ≈ création + 16 950 s) → marge ≈ 200-550 s
  en échec complet des poussées. Le TERM de l'amorce tombe vers création + 18 050 s (son délai part après le clonage,
  vers création + 50 s à la revalidation), **après** le plafond de la surveillance : son traitement (`sur_term`) n'est qu'un dernier recours ; dans sa fenêtre de 300 s avant KILL, les
  attentes prennent jusqu'à 150 s (CO-09).
- Journal : chaque refus est journalisé ; pour la branche, avec les lignes `fatal|error|remote` de git (cause du serveur
  comprise) ; pour les vecteurs, avec la seule dernière ligne (« error: failed to push some refs… »), qui perd la cause
  du serveur (CO-03, preuve par la sonde).
- Codes de sortie : `pousser` rend 0 ou 1 ; après le run, un échec de la première poussée est journalisé et le script
  continue ; un échec de la **dernière** poussée (`:342`) fait sortir en code 1 par `set -e`, sans ligne de synthèse
  (CO-08) ; `pousser_vecteurs` est toujours appelée avec `|| true` (le code n'en dépend jamais ; la récupération lit le
  journal). Codes de l'amorce inchangés (124/137 pour ses plafonds).
- Vecteurs : boucle identique à `pousser` ; **aucun test de la suite** (ni cas sain, ni artefact) ; la répétition jouet
  ne joue que la poussée réussie du premier coup. Sonde (`sorties/sonde_vecteurs.txt`, 2 réussis en 91,42 s) :
  ```
  vecteurs : poussée, tentative 1 refusée (error: failed to push some refs to '<tmp>/…/distant-0.git' )
  vecteurs poussés : branche donnees/t05/20261012-020734-t05-pilote-jouet, commit 9d417c33…, 4096 octets
  …
  vecteurs : poussée, tentative 3 refusée (error: failed to push some refs to '<tmp>/…/distant-0.git' )
  vecteurs : poussée impossible : restés sur l'instance
  ```
  Taille attendue des vecteurs : 180 épisodes × 10 actions × 3 couches × 4 096 × 2 octets ≈ 44 Mo, sous la limite de
  95 000 000 octets du script.

### 5. Tests (R5)

Commande (depuis le dépôt, en place), 2026-10-12 01:43:42 → 01:50:14 UTC, code 0 :

```
PYTHONPATH=src PYTHONDONTWRITEBYTECODE=1 /home/user/controle-ia/.venv/bin/python -m pytest -q -p no:cacheprovider \
  tests/test_pilote_a.py tests/test_lire_pilote.py tests/test_prechargement.py \
  "tests/test_script_instance_t05.py::test_poussees_apres_le_run_trois_tentatives"
........................................................................ [ 69%]
...............................                                          [100%]
103 passed in 389.24s (0:06:29)
```

Durées (`--durations`) : `test_poussees_apres_le_run_trois_tentatives` 90,90 s (attentes réelles de 15 et 60 s),
`test_poussee_initiale_cas_sain_et_depot_qui_refuse` 10,65 s. Tests collectés à la tête : 680 (= « Tests attendus :
`680` » du candidat).

| Garde ou comportement nouveau | Cas sain | Artefact |
|---|---|---|
| `precharger_modele` : liste blanche, révision figée, poids absents, autre révision | oui (`test_prechargement.py:71`) | oui (quatre) ; fichier essentiel absent : même branche, non isolé |
| `charger_modele(..., hors_ligne=True)` | oui (`:48`, sans réseau) | oui (`:59` : révision absente, poids retirés) ; cache sans liste d'arbre seulement (sonde : avec liste d'arbre, conforme) |
| `precharger_juges` | oui (`test_pilote_a.py:477`) | oui, au niveau de la fonction ; **pas au niveau du lanceur** (CO-05 ; sonde conforme) |
| ordre SI-01 | oui (`:372`, `:445`) | arrêt pendant les décisives (`:419`), pendant D (`:372`) ; **arrêt pendant l'appariement non éprouvé** (CO-04 ; sonde conforme) |
| lecture des états « decisives-8B », « decisives-3B » | oui (`test_lire_pilote.py:737`, `:748`) | — |
| `pousser` en trois tentatives | oui (refus passager) | oui (refus permanent) |
| `pousser_vecteurs` en trois tentatives | **non** | **non** (CO-02 ; sonde conforme) |
| invite de l'étiqueteur | oui (empreinte, bout en bout) | — |
| relevé du signal TERM aux points de contrôle (89b647f, 3b8c049) | oui | oui (avalé, converti, après le dernier contrôle) |

### 6. Arbre gelé

- Défini par `CHEMINS_GELES` (`src/controle_ia/harnais/validation_reelle.py:71-73`) : tout l'arbre sauf `prereg`,
  `brouillons`, `registres`, `docs`, `diag`, `runs`, `donnees`, `livrables`, `papiers`, `traces`, `CLAUDE.md`. Comparé
  commit à commit (`git diff --quiet <cité> HEAD`) par `exiger_code_cite` (`:214-227`), appelé par le lanceur sur
  l'instance (`lancer_pilote_a.py:290`) et par les contrôles avant dépense (lignes 55-61). L'arbre de travail est en plus
  exigé propre, fichiers non suivis compris, à la création du manifeste (`manifeste.py:79-83`, `gardes.py:100`).
- État : `git diff --quiet 3ffab9f HEAD -- <CHEMINS_GELES>` → code 0 ; empreintes des deux scripts égales au commit cité
  et à la tête (`59f49aab…`, `ab74ffa0…`), comme le candidat les cite.
- Couverture de ce que l'instance exécute ou lit :
  - amorce (incluse dans la commande de création, depuis S, empreinte citée et comparée par `lancer_pilote_v1.sh`),
    script de l'instance, `src/`, `tests/`, `requirements*.txt`, configuration de pytest : **dans l'arbre gelé** ;
  - configuration, tâches, préenregistrement : hors de l'arbre gelé, mais scellés et cités, comparés par le lanceur ;
  - **invites lues au run** (`docs/sources/invites-2606.08892-v1/` : H1-classification, H3, H4 ; `invites.py:15`) : hors
    de l'arbre gelé, protégées par leurs seuls sceaux et l'index scellé ; l'empreinte de l'index est citée par le candidat
    (ligne 26 : `adb4b8bc…`, égale au fichier aujourd'hui, dossier inchangé depuis e6ce058), mais ni le lanceur ni les
    contrôles ne la comparent (CO-07) ;
  - poids des modèles : révisions figées ; pas de contrôle des empreintes publiées dans le chemin du pilote
    (`empreintes_fichiers_modele` existe, non appelée) ;
  - hors de tout gel : versions transitives des dépendances, Python et pip de l'image (CO-11).

### 7. Pistes fragiles restantes

- Réseau : téléchargement du 8B au début du run et du 3B avant les épisodes (panne → arrêt avant `episodes.json`,
  relancement permis) ; rien après les épisodes ; poussées de fin (trois tentatives, puis résultats sur l'instance
  arrêtée) ; installation depuis PyPI avant les tests. Le préchargement réel n'a jamais tourné (seulement l'essai à blanc
  et le cache réaliste jouet).
- Matériel : mémoire et durée des juges jamais mesurées (réserve déclarée) ; génération des juges avec le cache dynamique
  de transformers, qui recopie tout le cache à chaque pas (`cache_utils.py`, `torch.cat`) : le pire cas des notations
  (lots de 8, jusqu'à 3 072 jetons) peut approcher le budget restant (≈ 15 000 − 7 584 − téléchargements − appariement)
  (CO-13) ; l'ordre SI-01 protège les familles, puis les décisives.
- Heure : échéance relative (`perf_counter`), identifiants de run en UTC ; dates des gabarits figées (`date_string` du
  8B et du 3B ; le gabarit du 3B prendrait sinon la date du jour par `strftime_now`), contrôlées au début du run.
- Versions : bibliothèques principales épinglées ; dépendances transitives flottantes (hf-xet 1.6.0 et 1.7.0, filelock
  4.0.10 et 4.1.0 dans deux environnements locaux construits des mêmes fichiers) ; aucun `pip freeze` dans les traces ;
  le chemin nouveau repose sur des détails internes de huggingface_hub 1.33.0 (liste d'arbre, `IncompleteSnapshotError`)
  et sur hf-xet (CO-11).
- Écritures non atomiques des résultats (`manifeste.py:137-138`), antérieures au différentiel (CO-15).

## Constats

| Id | Gravité | Objet |
|---|---|---|
| CO-01 | mineur | Le 3B est chargé avant les notations du 8B : sa panne coûte aussi celles du 8B |
| CO-02 | mineur | `pousser_vecteurs` en trois tentatives sans test (R5) |
| CO-03 | mineur | Cause d'un refus des vecteurs mal journalisée |
| CO-04 | mineur | État partiel « épisodes seuls » (arrêt pendant l'appariement) non éprouvé |
| CO-05 | mineur | Échec du préchargement non éprouvé au niveau du lanceur |
| CO-06 | mineur | Durée et révision du préchargement perdues dans un run complet |
| CO-07 | mineur | Invites lues au run hors de l'arbre gelé ; empreinte citée de l'index non comparée |
| CO-08 | mineur | Échec de la dernière poussée : code 1 sans ligne de synthèse |
| CO-09 | information | Marges de temps des poussées en trois tentatives |
| CO-10 | information | 91 s d'attentes réelles dans la suite exécutée sur l'instance |
| CO-11 | mineur | Versions transitives non consignées |
| CO-12 | information | Aucune libération de mémoire entre les étapes |
| CO-13 | information | Durées non mesurées : appariement et juges |
| CO-14 | information | Garde de complétude du préchargement plus faible que la bibliothèque ; format hors ligne non recontrôlé |
| CO-15 | information | Écriture non atomique d'un résultat (antérieure) |

### CO-01 — mineur — le 3B est chargé avant les notations décisives du 8B

- Fichier : `src/controle_ia/environnements/lancer_pilote_a.py:391-393` (puis `:397-416`).
- Preuve : `etat["etape"] = "chargement des juges"` puis `for j in config["juges"]: modele_du_juge(j)` charge le 3B
  avant `noter("decisives")`, qui commence par le 8B. Une panne au chargement du 3B (fichier manquant hors ligne,
  mémoire) arrête donc avant toute notation : les deux juges en nœud. Le candidat (table de lecture, ligne « arrêt au
  chargement du 3B ou pendant les notations décisives ») dit « le juge complet, s'il y en a un, est lu » : il n'y en aura
  aucun dans ce cas, alors que le 8B est déjà en mémoire.
- Action proposée : charger chaque juge à sa première notation (appel de `modele_du_juge(j)` dans `noter`, étape
  « chargement du juge 3B »), ce qui baisse aussi le pic de mémoire des notations du 8B ; ou garder le code et l'écrire
  dans la table (« une panne au chargement du 3B laisse les deux juges en nœud »). Probabilité faible (sondes du point 1).

### CO-02 — mineur — `pousser_vecteurs` en trois tentatives sans test (R5)

- Fichier : `scripts/pilote_t05_instance.sh:205-214` ; `tests/test_script_instance_t05.py` (aucun test de
  `pousser_vecteurs`) ; `repetition_jouet_pilote_v1.sh` (passage sain seulement).
- Preuve : `grep -rln "pousser_vecteurs\|donnees/t05/" tests/` → aucun fichier. Sonde
  `sonde_vecteurs/test_sonde_vecteurs.py` : cas sain (refus passager puis poussée) et artefact (trois refus, « restés sur
  l'instance ») conformes, `2 passed in 91.42s`.
- Action proposée : verser la sonde comme test ; pour ne pas payer ~90 s d'attente de plus sur l'instance, rendre
  l'attente de base réglable par une variable d'environnement (défaut 15 s) que les tests mettent à 0 ; sinon consigner la
  réserve.

### CO-03 — mineur — cause d'un refus des vecteurs mal journalisée

- Fichier : `scripts/pilote_t05_instance.sh:211`.
- Preuve : `journal "vecteurs : poussée, tentative $essai refusée ($(tail -n 1 "$TRAVAIL/poussee-vecteurs.err" | tr '\n' ' '))"` ;
  dans la sonde, le serveur répondait « remote: refus des vecteurs (essai) », le journal ne garde que « error: failed to
  push some refs to '…' ». Pour la branche, `pousser` (`:167`) garde les lignes `fatal|error|remote`.
- Action proposée : même extraction de la cause que `pousser` (utile pour un refus de taille par le dépôt distant).

### CO-04 — mineur — état « épisodes seuls » non éprouvé par la suite

- Fichier : `tests/test_lire_pilote.py:118-207` (`construire`), `src/controle_ia/environnements/lire_pilote.py:975-982`.
- Preuve : les états construits sont « aucune », « decisives-8B », « decisives-3B », « descriptives », « appariement » et
  « 3B » (ordre ancien, avec notations) ; l'état de l'ordre SI-01 où seuls `episodes.json` et `arret.json` existent n'en
  fait pas partie. Sonde `sonde_etat_partiel.py` : lecture conforme (familles en nœud, deux juges en nœud, P1 lu).
- Action proposée : ajouter l'état (par exemple `etapes="appariement-si01"`) et un test, ou citer la sonde en réserve.

### CO-05 — mineur — échec du préchargement non éprouvé au niveau du lanceur

- Fichier : `tests/test_pilote_a.py:477-497` (fonction seule) ; `lancer_pilote_a.py:325-327`.
- Preuve : aucun test n'appelle `executer` avec un préchargement en panne. Sonde `sonde_echec_prechargement.py` :
  `arret.json` seul, étape « préchargement des juges », motif lisible, pour une exception de bibliothèque et pour une
  `GardeArret`.
- Action proposée : verser la sonde comme test (quelques secondes, mode jouet).

### CO-06 — mineur — durée et révision du préchargement perdues dans un run complet

- Fichier : `lancer_pilote_a.py:327` (`etat["precharges"]`), `:347-352` (`episodes.json`), `:420-428` (résumé).
- Preuve : `grep -rn "precharges" src/` → seule l'affectation ; `etat` n'est écrit que dans `arret.json`. Le temps des
  téléchargements (8B au début, 3B ensuite) se fond dans `duree_s`, alors que la durée des juges est la réserve déclarée.
- Action proposée : verser `precharges` (et la durée du chargement de l'agent) dans les descriptifs de `episodes.json`.

### CO-07 — mineur — invites lues au run hors de l'arbre gelé

- Fichiers : `src/controle_ia/harnais/validation_reelle.py:71-73` (`:(exclude)docs`), `src/controle_ia/environnements/invites.py:15`,
  candidat ligne 26, `controles_avant_depense_pilote_v1.sh` (aucune comparaison de l'index).
- Preuve : `sha256sum docs/sources/invites-2606.08892-v1/index.json` → `adb4b8bc…` (égal à la citation) ;
  `git diff --quiet e6ce058 HEAD -- docs/sources/invites-2606.08892-v1/` → 0. Une modification cohérente des invites,
  de leurs sceaux et de l'index entre le commit du code et S passerait `exiger_invites` et `verifier-arbre`.
- Action proposée : dans les contrôles avant dépense, comparer l'empreinte de l'index à S à celle que cite le
  préenregistrement (ou, si le code est retouché, dans `exiger_citations_pilote`).

### CO-08 — mineur — échec de la dernière poussée sans ligne de synthèse

- Fichier : `scripts/pilote_t05_instance.sh:336-343`.
- Preuve : `pousser || journal "poussée du run impossible : résultats restés sur l'instance"` puis, après les traces,
  `pousser` nu : en échec, sortie en code 1 par `set -e`, dernière ligne « tentative 3 refusée » ; si la première
  poussée a échoué et la dernière réussi, le journal garde « résultats restés sur l'instance » alors qu'ils sont poussés.
  La surveillance lit « fin, code 1 » comme un arrêt.
- Action proposée : ligne finale explicite (« run complet ; poussée finale impossible : traces restées sur l'instance »)
  ou lecture écrite au plan (FIN code 1 : lire le journal avant toute conclusion).

### CO-09 — information — marges de temps des poussées en trois tentatives

- Fichiers : `scripts/pilote_t05_instance.sh:160-172`, `:205-214`, `:312` ; `scripts/amorce_instance_t05.sh:39` ; plan,
  étape 5 (plafond 17 700 s) ; `traces/t05-revalidation-v2-20261011-2246/lancement.txt` (création 1791758763 =
  2026-10-11T22:46:03Z) et `traces/t05-20261011-234411-9q7N/journal.txt`.
- Chiffrage : voir réponse 4 (≤ 225 s d'attente en fin de run complet, ≤ 150 s dans un arrêt consigné ; marge ≈ 1 600 s
  par l'échéance interne, ≈ 200-550 s par le délai externe en échec complet ; TERM de l'amorce après le plafond de la
  surveillance).
- Action : aucune ; à garder en tête si la mise en place s'allonge.

### CO-10 — information — 91 s d'attentes réelles dans la suite de l'instance

- Fichier : `tests/test_script_instance_t05.py:285` ; preuve : `90.90s call … test_poussees_apres_le_run_trois_tentatives`.
- Effet : ~1,5 min de carte payée et début du run retardé d'autant (compté dans CO-09). Voir l'action de CO-02.

### CO-11 — mineur — versions transitives non consignées

- Fichiers : `requirements-cpu.txt`, `requirements-gpu.txt`, `scripts/pilote_t05_instance.sh:266-272`,
  `src/controle_ia/manifeste.py:58-65`.
- Preuve : `pip list` du premier environnement : `hf-xet 1.6.0`, `filelock 4.0.10` ; environnement neuf du bloc-notes et
  `docs/procedures/revalidation-T0.5-v2/environnement-suite-6ec7434-v1.txt` : `hf-xet==1.7.0`, `filelock==4.1.0` ; le
  manifeste de la revalidation ne consigne que dix entrées (Python, plateforme et huit bibliothèques).
- Action proposée : écrire `pip freeze` dans les traces de l'instance (R9 : versions consignées), ou installer avec un
  fichier de contraintes tiré de l'environnement neuf où la suite a passé.

### CO-12 — information — aucune libération de mémoire entre les étapes

- Fichier : `lancer_pilote_a.py:353-417` (comparer `revalider_pilote_a.py:373-375`).
- Preuve : `grep -rn "empty_cache\|gc.collect" src/controle_ia/environnements/lancer_pilote_a.py` → rien. La
  revalidation a montré une fragmentation (« 7.33 GiB is reserved by PyTorch but unallocated », bras « math »).
- Action : facultative, `gc.collect(); torch.cuda.empty_cache()` après l'écriture des épisodes si le code est retouché.

### CO-13 — information — durées non mesurées : appariement et juges

- Appariement : 690 cibles sur 60 tâches (10 à 12 par tâche) ; au plus 180 × 10 × 11,5 = 20 700 paires plus 690 pour
  l'énoncé seul (énoncés de 4 108 caractères en moyenne), soit jusqu'à ~670 lots de 32 : de l'ordre de 5 à 15 minutes
  (estimation), plus que « quelques minutes » (candidat, ligne 150). Placé avant les notations, il retire ce temps au
  budget des décisives : arbitrage de SI-01.
- Juges : cache dynamique recopié à chaque pas (`transformers/cache_utils.py`, `torch.cat` dans `DynamicLayer.update`) ;
  pire cas des lots à 3 072 jetons ≈ 1,5-2 h pour l'ensemble des notations (estimation grossière), à comparer à
  ≈ 15 000 − 7 584 s moins les téléchargements et l'appariement. Réserve déjà déclarée.

### CO-14 — information — garde de complétude du préchargement ; format hors ligne

- Fichier : `src/controle_ia/harnais/modeles.py:120-122` ; `lancer_pilote_a.py:258-263`.
- Preuve : la garde exige trois fichiers et « au moins un » `.safetensors`, ni `generation_config.json` ni tous les
  fragments ; huggingface_hub 1.33.0 lève toutefois sur tout fichier non téléchargé et sur une copie partielle connue
  (`_raise_if_incomplete_snapshot`) : pas de trou en pratique. Le format du 3B chargé hors ligne n'est pas recontrôlé
  par `controler_format` (le contrôle a porté sur le tokeniseur chargé en ligne avant les épisodes) : mêmes fichiers, mêmes
  variables du gabarit, donc même résultat.
- Action : aucune.

### CO-15 — information — écriture non atomique d'un résultat (antérieure au différentiel)

- Fichier : `src/controle_ia/manifeste.py:137-138`.
- Preuve : `chemin.write_text(...)` puis `sceller(chemin)` ; un TERM entre les deux laisse un résultat sans sceau, que
  `charger_pilote` refuserait. Fenêtre de quelques millisecondes ; TERM seulement au délai externe ou au plafond.
- Action : aucune pour ce pilote.

## Fichiers de travail

Sous `/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-pilote-b8/code/` :
`pytest-sortie.txt` (sortie des tests demandés), `etat-avant.txt` et `etat-apres.txt` (état du dépôt),
`sonde_hors_ligne.py` (et ses variantes v2, v3 traçant la tentative réseau), `sonde_etat_partiel.py`,
`sonde_echec_prechargement.py`, `sonde_vecteurs/test_sonde_vecteurs.py`, et `sorties/` (sorties des sondes et de l'essai
à blanc). Dossiers temporaires supprimés ; aucune copie du dépôt.
