"""Sonde de relecture (angle code) : état partiel nouveau de l'ordre SI-01, non construit par les tests du dépôt.

Arrêt pendant l'appariement (ou pendant le chargement du 8B comme juge, ou panne de mémoire de l'appariement) dans
l'ordre du lanceur depuis 1f53a08 : episodes.json et arret.json seulement, aucun appariement ni aucune notation. Le run
synthétique est celui des tests (`construire` de tests/test_lire_pilote.py), dont on retient l'écriture des
notations. On lit ensuite par `preparer_etiquetage` puis `analyser`. Tout s'écrit dans un dépôt jetable sous le
dossier passé en argument.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

TESTS = Path("/home/user/controle-ia-travail/tests")
sys.path.insert(0, str(TESTS))

import conftest  # noqa: E402
import test_lire_pilote as tlp  # noqa: E402
from controle_ia.environnements import lire_pilote as lp  # noqa: E402


def depot_jetable(racine: Path) -> Path:
    racine.mkdir(parents=True)
    for args in (("init", "-q", "-b", "main"), ("config", "user.email", "t@example.invalid"),
                 ("config", "user.name", "t")):
        subprocess.run(["git", "-C", str(racine), *args], check=True, capture_output=True)
    (racine / "README").write_text("x\n")
    conftest.committer(racine)
    return racine


def main(dossier: str) -> int:
    lp.exiger_code_importe_sous = lambda racine: None          # comme la fixture autouse des tests de lecture
    vrai = tlp.ecrire_resultat

    def sans_notations(racine, chemin_m, nom, contenu, *a, **k):
        if nom.startswith("notations-"):
            return None
        return vrai(racine, chemin_m, nom, contenu, *a, **k)
    tlp.ecrire_resultat = sans_notations
    depot = depot_jetable(Path(dossier) / "depot")
    travail = Path(dossier) / "travail"
    travail.mkdir()
    d = tlp.construire(depot, etapes="3B")                     # notations retenues : épisodes + arrêt seulement
    tlp.ecrire_resultat = vrai
    presents = sorted(p.name for p in (depot / "diag" / tlp.RUN).glob("*.json"))
    print("fichiers du run :", presents)
    r = lp.preparer_etiquetage(depot, tlp.RUN, tlp.ANALYSE, d["prereg"], d["taches"], travail)
    print("lots à étiqueter :", r["lots"])
    conftest.committer(depot)
    lecture = lp.analyser(depot, tlp.RUN, tlp.ANALYSE, d["taches"])
    print("run_partiel :", lecture.get("run_partiel"))
    print("familles :", lecture.get("familles"))
    print("juges :", {j: v.get("lecture", v.get("plan_b")) for j, v in lecture["juges"].items()})
    print("prédictions :", lecture.get("predictions"))
    print("lecture suspendue :", lecture.get("lecture_suspendue"), "; audit :", lecture.get("audit_r4"))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
