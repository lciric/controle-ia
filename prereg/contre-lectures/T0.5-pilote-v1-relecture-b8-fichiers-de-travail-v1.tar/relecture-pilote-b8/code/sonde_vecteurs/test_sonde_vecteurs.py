"""Sonde de relecture (angle code) : poussée des vecteurs en trois tentatives (`pousser_vecteurs`, 197e909), que la
suite du dépôt n'éprouve pas. Le script de l'instance est exécuté tel quel (ETUDE=pilote, MODE=jouet) contre un dépôt
distant local, avec un `python` factice dont le « lanceur » écrit des vecteurs scellés sous donnees/<run>/ et un
arret.json, puis sort en code 1 (arrêt consigné : consigner_arret pousse la branche, puis les vecteurs).
Cas sain : la première poussée des vecteurs est refusée, la deuxième passe. Artefact : toutes sont refusées.
Réutilise les montages de tests/test_script_instance_t05.py (lecture seule) ; tout s'écrit sous tmp_path.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

sys.path.insert(0, "/home/user/controle-ia-travail/tests")

from test_script_instance_t05 import (_distant, _git, _journal, _lancer, _prereg_pilote,  # noqa: E402,F401
                                      bac)

PYTHON_PILOTE = """#!/usr/bin/env bash
if [ "$1" = "-m" ] && [ "$2" = "pytest" ]; then printf '%s\\n' "7 passed in 1.00s"; exit 0; fi
if [ "$1" = "-c" ]; then
    case "$2" in *"is_available() else 1"*) exit 0 ;; esac
    echo "torch factice"; exit 0
fi
run=""; prec=""
for a in "$@"; do [ "$prec" = "--run-id" ] && run="$a"; prec="$a"; done
mkdir -p "donnees/$run" "diag/$run"
head -c 4096 /dev/urandom > "donnees/$run/vecteurs-par-action.npz"
(cd "donnees/$run" && sha256sum vecteurs-par-action.npz > vecteurs-par-action.npz.sha256)
echo '{"factice": true}' > "diag/$run/arret.json"
echo "lanceur factice du pilote : vecteurs écrits, arrêt" >&2
exit 1
"""


def _preparer(bac) -> None:
    src = bac["source"]
    (src / "prereg" / "pilote.md").write_text(_prereg_pilote(), encoding="utf-8")
    _git(src, "add", "-A")
    _git(src, "commit", "-qm", "préenregistrement factice du pilote")
    (bac["venv"] / "bin" / "python").write_text(PYTHON_PILOTE, encoding="utf-8")


def _crochet(distant: Path, refuser_si: str) -> None:
    """pre-receive : compte les poussées vers refs/heads/donnees/* ; refuse selon `refuser_si` (n = rang)."""
    compteur = distant / "compteur-vecteurs"
    h = distant / "hooks" / "pre-receive"
    h.write_text("#!/usr/bin/env bash\nwhile read -r ancien nouveau ref; do\n"
                 "  case \"$ref\" in refs/heads/donnees/*)\n"
                 f"    n=$(cat '{compteur}' 2>/dev/null || echo 0); n=$((n + 1)); echo $n > '{compteur}'\n"
                 f"    if {refuser_si}; then echo 'refus des vecteurs (essai)' >&2; exit 1; fi ;;\n"
                 "  esac\ndone\nexit 0\n", encoding="utf-8")
    h.chmod(0o755)


PILOTE = {"ETUDE": "pilote", "PREREG": "prereg/pilote.md"}


def test_vecteurs_refus_passager_puis_poussee(bac):
    _preparer(bac)
    distant = _distant(bac)
    _crochet(distant, '[ "$n" = 1 ]')
    code, sortie = _lancer(bac, distant, env_sup=PILOTE)
    j = _journal(bac)
    print(j[-2500:])
    assert code == 1 and "ARRÊT pendant run" in j
    assert "vecteurs : poussée, tentative 1 refusée" in j and "vecteurs poussés : branche donnees/t05/" in j
    branches = subprocess.run(["git", "-C", str(distant), "branch", "--list", "donnees/t05/*"], capture_output=True,
                              text=True, check=True).stdout
    assert "donnees/t05/" in branches


def test_vecteurs_refus_permanent_restes_sur_l_instance(bac):
    _preparer(bac)
    distant = _distant(bac)
    _crochet(distant, '[ "$n" -ge 1 ]')
    code, sortie = _lancer(bac, distant, env_sup=PILOTE)
    j = _journal(bac)
    print(j[-2500:])
    assert code == 1 and "vecteurs : poussée, tentative 3 refusée" in j
    assert "vecteurs : poussée impossible : restés sur l'instance" in j
    assert "branche calcul/t05-pilote-jouet-v1 poussée" in j            # la branche de travail, elle, est poussée
