"""Sonde de relecture (angle code) : un échec du préchargement des juges, au niveau du lanceur (`executer`, mode jouet).

Le préchargement est remplacé par une panne de réseau (exception de bibliothèque, pas `GardeArret`), puis par une
`GardeArret` (préchargement incomplet). Attendu : `arret.json` scellé, étape « préchargement des juges », motif lisible,
aucun `episodes.json` (le relancement reste permis par le plan). Dépôt jetable sous le dossier passé en argument.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

TESTS = Path("/home/user/controle-ia-travail/tests")
sys.path.insert(0, str(TESTS))

import conftest  # noqa: E402
import test_pilote_a as tpa  # noqa: E402
from controle_ia.environnements import lancer_pilote_a as lp  # noqa: E402
from controle_ia.gardes import GardeArret  # noqa: E402


def depot_jetable(racine: Path) -> Path:
    racine.mkdir(parents=True)
    for args in (("init", "-q", "-b", "main"), ("config", "user.email", "t@example.invalid"),
                 ("config", "user.name", "t")):
        subprocess.run(["git", "-C", str(racine), *args], check=True, capture_output=True)
    (racine / "README").write_text("x\n")
    conftest.committer(racine)
    return racine


class ConnexionImpossible(OSError):
    pass


def main(dossier: str) -> int:
    for k, panne in enumerate((ConnexionImpossible("[Errno 101] Network is unreachable (simulée)"),
                               GardeArret("meta-llama/Llama-3.2-3B-Instruct@0cb88a4f764b : préchargement incomplet "
                                          "(['config.json'] absents) (simulé)"))):
        depot = depot_jetable(Path(dossier) / f"depot-{k}")

        def precharger(config, _p=panne):
            raise _p
        lp.precharger_juges = precharger
        f, _ = tpa._taches_scellees(depot)
        conftest.committer(depot)
        run = f"20261012-01000{k}-pilote-jouet"
        try:
            lp.executer(tpa._config_lanceur(), depot, run, None, str(f))
            print("AUCUN ARRÊT (inattendu)")
        except Exception as e:                       # noqa: BLE001
            print(f"[{type(panne).__name__}] exception propagée : {type(e).__name__}: {e}")
        d = depot / "diag" / run
        print("  fichiers :", sorted(p.name for p in d.glob("*.json")))
        r = json.loads((d / "arret.json").read_text(encoding="utf-8"))["resultat"]
        print("  étape :", r["etape"], "| motif :", r["motif"])
        print("  partiel :", sorted(r["partiel"]))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
