# Relecture R2 du candidat 1 du pilote 8B de T0.5 — angle « N-019 », en sceptique — v1

- **Relecteur** : sous-agent neuf. Il n'a écrit ni le préenregistrement du pilote, ni la décision N-019, ni le verdict de la revalidation.
- **Conditions** : lecture seule dans le dépôt de travail et dans `scratchpad/pilote-v1/`. Aucune commande Vast.ai, aucun jeton affiché, aucun commit, aucun clone. L'arbre est propre avant et après la relecture : aucun fichier du dépôt n'est plus récent que mon premier script.
- **Date** : 2026-10-12, de 02:00 à 02:25 UTC environ.
- **Dépôt** : `/home/user/controle-ia-travail`, branche `main`, tête `942c65e365f809b7142b280b4adc1922ce3ab67c`.
- **Objet relu** :
  - `brouillons/T0.5-pilote-8B-v1-candidat1.md` (`15a5cd3e457dd7b6db234bc08ce7378514ec217b8f8099dea426eb3743b33150`) ;
  - `brouillons/T0.5-pilote-config-v1-candidat1.json` (`6979a00ebef1e794f900e089df9b1658482f8600ce343cb81c95da4434da2b8a`) ;
  - la décision `docs/decisions/decision-N-019-v1.md` (`9058fa27e1a7dda88e3802e1b60a3e7b4bf89d1f52c973cb9812af06ca7f3038`).
  - Les sceaux de ces trois fichiers sont conformes, comme ceux du verdict, du fichier des 60 tâches, de l'état des lieux, du brouillon 8 et du plan.
- **Règle D-20** : je n'ai ouvert ni `episodes-defaut.json` ni `chemin-defaut.json`.
  - J'ai lu seulement des nombres et des drapeaux de `mesures-defaut.json`, `lecture-defaut.json`, `lecture-math.json`, `resume.json` et du manifeste. Leurs sceaux et leur rattachement au manifeste sont conformes (`verifier_resultat`).
  - Je n'ai affiché aucun texte de tâche : seulement des longueurs, des comptes, des identifiants comparés et deux étiquettes de classification.

## Verdict d'angle

1. **La réduction à 60 tâches change-t-elle une lecture gelée de la revalidation ? Oui** (confiance d'environ 75 %), dans l'usage qu'en fait N-019 : retenir le noyau « defaut ».
   - Le texte scellé définit R8 à 192 épisodes (`× 192 / 16`, l. 97). Le code cité le fait aussi : constante `EPISODES_PILOTE = 192`, l. 63 et 265.
   - Appliquer R8 à 180 épisodes change cette constante après la lecture du résultat.
   - Ce changement fait passer la règle de choix gelée du nœud, `(None, None)`, au noyau `('defaut', None)`.
2. **La décision devait-elle attendre Lazar ? Oui** (confiance d'environ 85 %).
   - Le texte gelé renvoie ce cas à une « proposition à Lazar » (l. 59 et 128).
   - Le brief classe « tout écart à un préenregistrement scellé » parmi les nœuds (l. 77).
   - R-140 n'admet qu'un écart « limité à l'exécution (aucun seuil, aucune lecture, aucune hypothèse changés) ».
   - L'état des lieux scellé, commandé par la session, l'avait déjà écrit : « Retenir « defaut », lever R8 ou changer la formule de durée change une lecture gelée, ce qui est hors de R-140 ». La décision n'y répond pas.
   - Attendre ne coûtait rien : le lancement attend de toute façon la recharge de Lazar.

La décision fixe elle-même la conséquence (l. 67-69 ; R-143) : une réponse fondée « oui » ramène le nœud à Lazar avant tout lancement. Je recommande en outre de **ne pas sceller le candidat avant son GO**.

**Sur le fond, l'option (a) reste défendable** :
- elle ne change ni seuil, ni domaine (même carte, même lot, même noyau), ni critère du pilote ;
- elle donne environ 506 s de plus aux juges.

C'est la forme de la décision qui est en cause, non son contenu. Je la recommanderais moi-même à Lazar.

## 1. Légitimité

**Texte de R-140** (`registres/decisions.md`, l. 277).
- Mot de Lazar : « reprends le travail en full autonomy pendant 12h en prenant les decisions qui font avancer au maximum les resultats avec des tests robusts, élimine les pistes fragiles ».
- Lecture retenue par la session :
  - « (1) les décisions « proposer avec recommandation » sont prises sans attendre 48 heures » ;
  - « (2) les nœuds d'exécution sont tranchés par la session dans le cadre déjà accordé : […] lancement du pilote de T0.5 une fois son préenregistrement contre-lu (R2) et scellé, écart à un préenregistrement scellé limité à l'exécution (aucun seuil, aucune lecture, aucune hypothèse changés) et contre-lu par des sous-agents neufs ».
- Exclusions : « Restent hors de la délégation : les règles gelées R1 à R14 ; le franchissement d'une porte (G0) ; toute modification d'hypothèse ou de revendication du programme (préparée en proposition seulement) ; […] ; la recharge du crédit ».
- La colonne des sources ajoute : « hiérarchie de décision de `CLAUDE.md`, lue au plus près de ses interdits ».

**N-019 a deux composantes, qui ne relèvent pas du même niveau.**
1. **La taille du pilote passe de 64 à 60 tâches.** C'est un « ajustement de périmètre à l'intérieur d'une phase » (brief, l. 67), donc une décision « proposer avec recommandation ». Le point (1) de R-140 la couvre, révocable, et elle est consignée (R-143).
   - P-007, retenue par Lazar, mentionne « 64 papiers » dans son calendrier (l. 30).
   - Aucun critère de G0 ne fixe la taille du pilote (brief, l. 190-201).
2. **La résolution du nœud de la revalidation.** La décision écrit : « Pour ce pilote, le bras « defaut » satisfait R1 à R8 et l'audit, avec marge : noyau « defaut » » (l. 41-42). Elle applique aussi la formule de `duree_max_s` de la ligne « conforme avec marge » de la table gelée.
   - Le verdict scellé et le code de lecture rendent pourtant le nœud.
   - C'est un « écart à un préenregistrement scellé » (brief, l. 77 : nœud, « tu t'arrêtes et tu attends le GO »).
   - L'écart change l'issue de la lecture : le point (2) de R-140 ne le couvre donc pas.
   - R1 est en tension : la métrique d'une expérience décisive est respécifiée après la lecture du résultat (manifeste `decisif` vrai, verdict l. 113). Or R1 fait partie des exclusions de la délégation.

**Les exclusions sont-elles respectées ?**

| exclusion de R-140 | respectée ? | motif |
|---|---|---|
| écart à un préenregistrement scellé hors exécution | **non** | constante de R8 changée (192 → 180), issue de `choisir_noyau` changée (section 2) |
| modification d'hypothèse ou de revendication du programme | oui | le pilote ne teste aucune hypothèse du programme (candidat, l. 32) ; aucune revendication touchée |
| porte (G0) | oui | aucun franchissement ; le pilote sert seulement les preuves du critère 2 (candidat, l. 171) |
| règles gelées R1 à R14 | **en tension** (R1) | métrique scellée respécifiée après lecture |

**Ce que dit la phrase du verdict.** La phrase est : « Ce verdict n'en propose ni n'en choisit aucune : la résolution du nœud revient à Lazar » (l. 35) ; voir aussi l. 318 : « Il ne propose aucune résolution du nœud ».
- **Elle n'interdit pas, à elle seule, de trancher sous délégation.** Elle est descriptive : le verdict « ne porte aucun jugement sur la suite » (l. 318), et son auteur n'a pas autorité sur la gouvernance.
- Elle reprend le texte gelé, qui, lui, lie : « **nœud** : rien ne tourne ; proposition à Lazar […] ; sinon, options à proposer » (préenregistrement, l. 128 ; verdict, l. 31).
- Une délégation pourrait couvrir ce geste si Lazar l'avait dit. R-140, telle que la session l'a écrite, ne le couvre pas.

**Quatre éléments aggravants.**
- **La décision ne dit pas sur quel point de R-140 elle s'appuie** : ni (1), ni (2) (décision, l. 3-6).
- **Elle ne répond pas à l'état des lieux** qu'elle verse dans le même commit `0413393`. Ce fichier est scellé : `prereg/contre-lectures/T0.5-pilote-v1-etat-des-lieux-resultats-v1.json`, `8ca0f843…`.
  - l. 873, résumé de l'angle « verdict » : « Retenir « defaut » malgré R8 change une lecture gelée : c'est une décision de Lazar, hors de la délégation R-140 » ;
  - l. 888, VR-02, majeur, vérifié : même phrase. Action proposée : « Rédiger le nœud au format de CLAUDE.md […] sans défaut ». La piste (C), « Réduire le pilote », y figure comme piste **à soumettre** ;
  - l. 1014, VR-16 : « Restent hors délégation : la décision sur l'issue « R8 seul », qui change une lecture gelée, et la recharge du crédit » ;
  - l. 1156, synthèse : « Dans la délégation R-140, le pilote ne peut être **ni scellé ni lancé** » ; et « Retenir « defaut » ou changer la formule de durée revient à changer une lecture gelée, ce que R-140 exclut » ;
  - l. 1158, bloquant 0 de la synthèse : « Retenir « defaut », lever R8 ou changer la formule de durée change une lecture gelée, ce qui est hors de R-140 ».
  - Ni la décision, ni R-143, ni R-144 ne citent ce bloquant. C'est une **divergence non résolue** : `CLAUDE.md` demande de l'écrire à Lazar.
- **Un précédent existe.** N-018 portait un écart bien plus petit : seul le commit cité changeait, sans seuil, sans lecture, sans graine. Il a reçu un GO explicite de type « revendication » : GO-2026-10-11-01 (`registres/go.md`, l. 23) ; R-139 (l. 276) : « Nœud de décision (écart à un préenregistrement scellé) : décision de Lazar ».
- **La confiance déclarée est d'environ 70 %** (décision, l. 38). Une décision de nœud prise avec 30 % de doute par la session elle-même relève d'autant plus de Lazar.

## 2. Lecture gelée

**R8 est défini sur un pilote de taille fixée, 192 épisodes, dans sa définition opératoire.**
- Préenregistrement scellé (`4ff2b075…`) :
  - l. 47, en mots : « durée projetée des épisodes du pilote ≤ 7 800 s » ;
  - l. 97, la métrique : « **Durée projetée (R8)** : (durée de génération + durée des passes uniques du bras) × 192 / 16 épisodes » ;
  - l. 190 : « RV-15 | Formule de la durée projetée gelée (R8) ».
- D'autres passages scellés portent la même taille : l. 95, « des 64 tâches d'évaluation » ; l. 103, « 5 % de 1 920 » ; l. 147, arrêt si « moins de 64 tâches d'évaluation ».
- Le plafond de 7 800 s, lui, ne dépend pas de la taille : 15 000 s moins 7 200 s laissées aux juges (l. 117).
- Code cité (`revalider_pilote_a.py`, `5c8d109d…`) :
  - l. 62-63 : `TACHES_PILOTE = 64` ; `EPISODES_PILOTE = 192          # 64 tâches × 3 épisodes (préenregistrement du pilote)` ;
  - l. 260-265 : `def duree_projetee_pilote(chrono: dict, episodes: int)`, docstring « (192 contre `episodes`) », `return (…) * EPISODES_PILOTE / episodes` ;
  - l. 526 : appel avec `len(ids_episodes)`, soit 16.

**`duree_projetee_pilote` prend-elle le nombre d'épisodes du pilote en paramètre ? Non.**
- Son paramètre `episodes` est le dénominateur, c'est-à-dire les 16 épisodes de la revalidation. Le pilote est la constante 192.
- La fonction gelée rend 8 089,62 s ; elle ne peut pas rendre 7 584,02 s.
- La décision la décrit autrement : « linéaire dans le nombre d'épisodes du pilote : (`generation_s` + `passe_unique_s`) × épisodes du pilote / 16 » (l. 21-22). C'est vrai de la formule mathématique, mais faux du code cité.

**Ce que fait le générateur** (`scratchpad/pilote-v1/remplir_pilote_v1.py`, version lue `2f791291…`, modifiée à 02:03 UTC, donc après le candidat ; les valeurs du candidat sont cohérentes avec ces lignes).
- Il n'appelle pas la fonction gelée ; il recalcule en ligne (l. 152) :
  `d = (chrono["generation_s"] + chrono["passe_unique_s"]) * TACHES_PILOTE * EPISODES_PAR_TACHE / 16`
- Puis il force la lecture scellée (l. 156-157) :
  `lec_retenue = dict(lec, R8_duree=True, conforme=True, conforme_avec_marge=True)   # R8 appliquée au pilote réduit`
  suivi de `choisir_noyau({"defaut": lec_retenue, …})`.

**Rejeu de la lecture gelée** (`relire_bras.py`). J'ai appelé la fonction gelée `lire_bras` sur les entrées scellées, en ne changeant que la durée projetée :
- à 192 épisodes, elle redonne **à l'identique** la lecture scellée ; `choisir_noyau` → `(None, None)` ;
- à 180 épisodes, **trois drapeaux seulement changent** : `R8_duree`, `conforme` et `conforme_avec_marge` passent de faux à vrai ; `choisir_noyau` → `('defaut', None)` ;
- le dictionnaire forcé du générateur est égal à ce rejeu.

**Appliquer R8 à 180 épisodes est un écart.**
- Il touche la métrique scellée (l. 97) et le code cité (l. 63, 265).
- Il est fait après la lecture du résultat, avec R8 pour motif déclaré (candidat, l. 251 : « N-019, motif : R8 »).
- Il change l'issue de la règle de choix gelée : du nœud au noyau retenu.

Trois formulations ne le disent pas :
- « R8 appliquée, telle quelle » et « aucun seuil, aucune formule, aucune lecture ne change » (décision, l. 31) ;
- « R8, appliquée telle quelle à ses 180 épisodes » et « formule gelée `duree_projetee_pilote` » (candidat, l. 19-20) ;
- « ne change pas : […] le code de lecture » (décision, l. 45-47), alors que le générateur doit le contourner.

La décision est aussi incohérente avec elle-même : elle écarte (d) parce qu'elle « change un critère ou une formule gelés : écart à un préenregistrement scellé, hors de la délégation » (l. 34), alors que (a) change la constante de cette même formule.

**Doute déclaré : une lecture charitable existe.** Le commentaire du code (« (préenregistrement du pilote) ») et les mots « le pilote » (l. 47, 126) permettent de lire 192 comme une donnée d'entrée prise au brouillon du pilote. Elle suivrait alors ce brouillon, encore non scellé. Je ne retiens pas cette lecture, pour trois raisons :
- le texte scellé écrit la valeur, pas un symbole ;
- la valeur a été changée après la lecture, pour passer le critère ;
- les lecteurs de l'état des lieux ont lu le texte comme moi.

L'existence de ce doute suffit d'ailleurs à renvoyer la question à Lazar.

## 3. Valeurs recalculées

Recalcul par `recalcul_r8.py`, avec le code cité importé de `src/` et `mesures-defaut.json` (`bdc78cb2…`, sceau et manifeste conformes).

| grandeur | valeur recalculée | décision N-019 | candidat |
|---|---|---|---|
| `generation_s` + `passe_unique_s` | 665,8512415573932 + 8,283867652527988 = 674,1351092099212 s | 674,1351 | — |
| d à 192 épisodes, `duree_projetee_pilote(chrono, 16)` | 8 089,6213105190545 s, égal au résultat scellé | 8 089,62 | 8 089,62 (l. 244) |
| d à 180 épisodes, (somme) × 180 / 16 | 7 584,019978611614 s | 7 584,02 | 7 584,02 (l. 20, 170) |
| marge de R8 à 180 | 215,98 s, soit 2,77 % | 216 s, 2,8 % | — |
| `duree_max_s` à 180 : min(15 000 ; ⌈(1,2 × d + 7 200)/60⌉ × 60) | 1,2 × d + 7 200 = 16 300,82 ; arrondi 16 320 ; **15 000 s** | 15 000 s | 15 000 (l. 20, 223 ; configuration) |
| `duree_max_s` à 192 | 16 907,55 ; arrondi 16 920 ; **15 000 s** | — | — |
| part laissée aux juges après les épisodes | 7 415,98 s à 180, contre 6 910,38 s à 192 | ≈ 7 416 s | — |
| plus grand nombre de tâches, à 3 épisodes, sous 7 800 s | **61** (183 épisodes : 7 710,42 s) ; 62 donnent 7 836,82 s | 60 | 60 |

- Configuration candidate : `noyau_attention` = « defaut », `duree_max_s` = 15000.
- Son empreinte canonique, `db3ad3ce…b714`, égale celle citée par le candidat (l. 10).
- Elle ne diffère du brouillon 1 que par ces deux clés.

## 4. Critères du pilote fixés pour 64 tâches

| critère (candidat) | à 64 | à 60 | ajusté ? | lecture |
|---|---|---|---|---|
| décomposition : au moins 48 tâches complètes (l. 66, 130, 166, 182) | 75 % | **80 %** | non | Conçu comme « 48 sur 64 » (contre-lecture 1, l. 421 : « Un minimum de tâches complètes, par exemple 48 sur 64 »). Il se resserre au moment où la durée des juges est le risque principal déclaré (l. 170). La décision le dit : « 12 de marge au lieu de 16 ». |
| au moins 16 tâches à directions stériles (l. 122) | 64 tâches en ont | 60 tâches en ont | non | largement tenu |
| référence de coût non nulle pour au moins 32 tâches (l. 123) | 61 | 58 | non | largement tenu |
| 80 paires par strate au plus (l. 104) | — | — | non | plafond ; le réservoir de paires baisse d'environ 6 % |
| taux d'erreur du plan B, couverture des intervalles (l. 133, 135) | simulés à 64 | non resimulés | annoté « (simulation ; le pilote en compte 60) » et « (simulation ; 60 ici) » | l'écart-type croît d'environ √(64/60) ≈ 1,03 ; ordres de grandeur non opposables, déclarés |
| puissance du kappa (l. 134) | simulée à 40 et 80 paires | inchangée | non | dépend des paires par strate, non du nombre de tâches |

**Le candidat n'a ajusté aucun seuil.** Il a seulement annoté les simulations, et il dit « aucun seuil, aucune prédiction ni aucune lecture n'en change » (l. 251).

**Un ajustement serait-il réservé à Lazar ?**
- Formellement, non : le brouillon n'est pas scellé, et le pilote ne teste aucune hypothèse du programme.
- Mais ce serait un changement de critère fait après le résultat de la revalidation, et la lecture du pilote fait office de juge R13 pour le critère 2 de G0 (l. 171).
- Ne pas ajuster est donc la bonne lecture (symétrie, R4). Si l'on veut ajuster, par exemple 45 sur 60, il faut le joindre à la proposition N-019 faite à Lazar.

## 5. Sélection

**La règle est aveugle au contenu.**
- « 60 premières dans l'ordre du tirage » veut dire les rangs de garde 0 à 59 de la permutation tirée par graine.
- La règle de sélection (`T0.5-selection-papiers-v1.md`, l. 50-57) est scellée avant le tirage.
- L'ordre du fichier d'évaluation est celui des rangs de garde 0 à 63. Je l'ai vérifié contre le corpus scellé (`57f0aa47…`, `verifier_resultat` conforme) : identifiants égaux, dans l'ordre. Aucun remplacement à l'extraction (`remplacements` vide).
- `deriver_taches_pilote_v1.py` ne fait que tronquer : empreinte, sceau, absence de remplacement et unicité des identifiants sont contrôlés.
- La même règle sert ailleurs dans le brouillon : « 16 premières tâches dans l'ordre du tirage » (l. 178).

**Le fichier dérivé égale la source tronquée** (`comparer_taches2.py`).
- 60 objets JSON égaux, rang par rang, aux 60 premiers de `resultat.taches` de la source.
- Empreinte canonique identique des deux côtés : `3027abd6b1e3ab16cea6e4e402d049226c91b472dcaac1a92bfda772ea7a4184`.
- Champ `source.sha256` = `76cdeace…` = empreinte réelle de la source ; fichier dérivé `287e8348…`, sceau conforme.

**Mais N n'est fixé par aucune règle écrite.**
- 61 tâches passeraient aussi R8 (7 710,42 s).
- N a été choisi après la lecture de R8, avec R8 pour motif.
- La session connaissait alors « leur ordre, la présence de directions stériles dans les 64 et les longueurs des énoncés » (candidat, l. 249).

**Les quatre tâches retirées ne sont pas quelconques.** C'est un effet du hasard du tirage, non un choix.
- Trois sont parmi les cinq énoncés les plus courts : rangs de longueur 2, 3 et 4 sur 64 ; longueurs 3 043, 3 049, 2 974 et 3 602 caractères.
- Les quatre sont « experiments_only » : 18 sur 64 au départ, 14 sur 60 ensuite.
- Moyenne des énoncés : de 4 048,9 à 4 107,7 caractères. 90e centile : de 4 902,8 à 4 961,8.
- Le plus long énoncé (6 786 caractères, rang 45) reste.
- Effet nul sur R8 : la projection vient des tâches d'entraînement.
- Ce n'est pas dit dans la section « Population » (l. 46-50).

## 6. Une option plus conforme au texte gelé

**Oui, dans la forme.** Il fallait proposer (a) à Lazar, au format de décision, avec recommandation, **sans défaut**, et préparer pendant ce temps tout ce qui n'en dépend pas : c'est ce que dit le texte gelé (l. 128 : « proposition à Lazar », « options à proposer »).
- Aucun délai n'en découlait : le lancement attend la recharge (R-143 ; `registres/etat.md`, l. 60 : crédit lu à 7,30 USD pour 7,68 exigés).
- L'état des lieux le recommandait (VR-02, VR-16 ; critique, « corrections au plan » 6 : « préciser le régime après 10:40 UTC : prolonger la délégation, ou autoriser le lancement »).

**Sur le fond, les options se comparent ainsi.**
- **(c)** est la seule option écrite par le texte gelé (« autre carte, autre lot : chacun un domaine nouveau, à revalider »).
  - La décision l'écarte parce que « ces options visent une équivalence manquante » (l. 18-19, 33), reprise de VR-02.
  - Le texte gelé ne les restreint pas à l'équivalence : une carte plus rapide répond directement à R8.
  - Le vrai motif de rejet est son coût, un nouveau run, et le crédit.
- **(b)**, deux épisodes par tâche, change aussi la constante de R8 (192 → 128) et, en plus, le code de lecture du pilote.
- **(d)** est hors délégation, de l'aveu de la décision.
- Les pistes (A), deux instances, et (B), un run allongé, de l'état des lieux demandent elles aussi Lazar.
- **(a) est l'écart de fond le plus petit** : une constante, aucun seuil, même domaine. C'est la bonne recommandation.

## Conclusions explicites

- **« La réduction à 60 tâches change-t-elle une lecture gelée de la revalidation ? » — Oui.**
  - R8 est défini à 192 épisodes par le texte scellé (l. 97) et par le code cité (l. 63, 265).
  - Pour retenir « defaut », N-019 l'applique à 180 épisodes, après lecture, avec R8 pour motif.
  - Ce changement fait passer la lecture gelée de `(None, None)`, le nœud, à `('defaut', None)`.
  - Le générateur doit contourner la fonction gelée et forcer trois drapeaux de la lecture scellée.
  - La réduction ne change ni seuil, ni domaine, ni critère du pilote. Elle change l'issue de la règle de choix, par sa métrique.
- **« La décision devait-elle attendre Lazar ? » — Oui.**
  - Le texte gelé (l. 59, 128) et le verdict (l. 35) attribuent la résolution à une proposition à Lazar.
  - Le brief (l. 77) fait d'un écart à un préenregistrement scellé un nœud.
  - R-140 exclut, par ses propres termes, un écart qui change une lecture, et exclut R1.
  - L'état des lieux scellé l'avait conclu (bloquant 0, VR-02, VR-16), sans réponse de la décision.
  - Le précédent N-018 a reçu un GO explicite.
  - Attendre ne coûtait rien.

## Constats

| id | gravité | objet | constat | preuve | action |
|---|---|---|---|---|---|
| NO-01 | majeur | lecture gelée de la revalidation | Appliquer R8 à 180 épisodes change la constante 192 de la métrique scellée, après lecture, et l'issue de `choisir_noyau` : nœud → « defaut ». Ce n'est pas « R8 telle quelle ». | préenregistrement l. 97 (« × 192 / 16 épisodes ») ; `revalider_pilote_a.py` l. 63, 260-265, 526 ; `relire_bras.py` : `lire_bras(192)` = lecture scellée, `choisir_noyau(192)` = (None, None) ; `lire_bras(180)` ne change que `R8_duree`, `conforme`, `conforme_avec_marge` ; `choisir_noyau(180)` = ('defaut', None) ; générateur l. 152, 156-157 | Ramener N-019 à Lazar, comme le prévoient la décision (l. 67-69) et R-143 ; ne pas sceller le candidat avant son GO ; dans la proposition, nommer l'écart (« constante 192 → 180 de la formule gelée de R8 ») |
| NO-02 | majeur | légitimité sous R-140 | La résolution du nœud est un écart à un préenregistrement scellé qui change une lecture : hors du point (2) de R-140 et contraire au texte gelé (« proposition à Lazar »). La décision ne dit pas sur quel point de R-140 elle s'appuie, ni ne répond à l'état des lieux, qui l'avait classée hors délégation. | `registres/decisions.md` l. 277 (R-140), l. 276 (R-139), l. 280 (R-143) ; brief l. 67, 71-77 ; préenregistrement l. 59, 128 ; verdict l. 31, 35, 318 ; état des lieux `8ca0f843…` l. 873, 888, 1014, 1156, 1158 ; `registres/go.md` l. 23 | Présenter N-019 en proposition (décision, enjeu, options (a), (b), (c), (d), recommandation (a), confiance, **sans défaut**) ; demander un GO de type « revendication », comme pour N-018 ; écrire à Lazar la divergence non résolue avec le bloquant 0 de l'état des lieux |
| NO-03 | majeur | garde-fou du lancement | « Rien n'est dépensé […] avant qu'il l'ait vue » (décision, l. 5-6) n'est pas tenu par la chaîne. Le lanceur exige une N-019 « tranché » avec « (a) », non révoquée, mais aucun GO de Lazar. La règle de crédit peut passer sans recharge si une offre conforme coûte au plus (crédit − 1,2)/6, soit environ 1,0 USD l'heure (7,30 USD à 01:20 UTC ; devis 0,80 à 1,30). Après 10:40 UTC, la décision survit à la délégation. La révocation n'est détectée que par motif de texte : « révoqu|révocation » et « n-019 » dans une ligne R-. | `lancer_pilote_v1.sh` (`6928e183…`) l. 22, 47-56, 104-111 ; `controles_avant_depense_pilote_v1.sh` (`bb6d88e9…`), aucun contrôle de GO pour N-019 ; état des lieux, `lectures[0]` constat 34 : « Le contrôle « GO de N-018 » du lanceur v7 disparaît » ; décision l. 63 ; `registres/etat.md` l. 60. Non vérifié : le prix des offres (aucune commande Vast.ai) | Exiger, dans les contrôles avant dépense et dans le lanceur, une ligne de `registres/go.md` accordée par Lazar et citant N-019 (comme VC-03 pour N-018), au lieu de l'absence de révocation |
| NO-04 | mineur | formulations inexactes | La décision et le candidat attribuent 7 584,02 s à la « formule gelée `duree_projetee_pilote` » appliquée « telle quelle ». La fonction gelée a 192 en dur et rend 8 089,62 s. Elle est aussi décrite comme linéaire « dans le nombre d'épisodes du pilote ». La décision dit enfin le code de lecture inchangé, alors que le générateur le contourne. | décision l. 21-22, 31, 45-47 ; candidat l. 19-20 ; `revalider_pilote_a.py` l. 260-265 | Écrire « formule de R8 avec 180 épisodes au lieu de la constante 192 (`EPISODES_PILOTE`) » ; dans le générateur, rejouer `lire_bras` (gelée) avec d à 180, au lieu de forcer les drapeaux : même résultat, mais explicite |
| NO-05 | mineur | choix de N | 60 n'est fixé par aucune règle écrite ; 61 passerait (7 710,42 s). N est choisi après R8, la session connaissant l'ordre, les longueurs et la présence de directions stériles. | `recalcul_r8.py` (tableau des tâches) ; candidat l. 249 ; décision l. 31 | Dans la proposition, écrire la règle de N et sa raison (marge voulue sur R8), ou déclarer 60 comme choix arrondi |
| NO-06 | information | composition des 4 tâches retirées | Rangs 60 à 63 : trois des cinq énoncés les plus courts, quatre « experiments_only » (18 sur 64 → 14 sur 60). Moyenne des énoncés de 4 048,9 à 4 107,7 caractères. C'est un hasard du tirage. Sans effet sur R8 ni sur RV-5 (6 786 caractères gardés, rang 45). | `ordre_tirage.py`, `comparer_taches2.py` (longueurs et comptes seulement) | Une ligne dans « Population » (l. 46-50), puisque la session connaissait les longueurs (R4) |
| NO-07 | mineur | seuil des 48 tâches complètes | Conçu « 48 sur 64 », il passe à 48 sur 60 (75 % → 80 %), non ajusté. Les seuils 16 et 32 restent largement tenus (60 et 58 tâches). Les simulations portent sur 64 tâches ; c'est déclaré. | contre-lecture 1, l. 421 ; candidat l. 66, 130, 133, 135, 166 ; `seuils_absolus.py` | Garder 48 et écrire la proportion (80 %) dans « Seuil » ; tout ajustement passe par la proposition à Lazar, puisque la lecture sert le critère 2 de G0 (l. 171) |
| NO-08 | mineur | rejet de (c) | « ces options visent une équivalence manquante » : le texte gelé ne restreint pas « autre carte, autre lot » à l'équivalence, et une carte plus rapide répond à R8. | préenregistrement l. 128 ; décision l. 18-19, 33 ; état des lieux l. 888 | Écarter (c) pour son coût, un nouveau run et le crédit, non pour sa portée |
| NO-09 | information | portée réelle de « R8 tenue » | `duree_max_s` vaut 15 000 s à 180 comme à 192 (16 320 et 16 920, plafonnés). Le seul effet opérationnel est environ 505,6 s de plus pour les juges, avec 4 tâches de moins. La marge de R8 (2,77 %) est du même ordre que l'écart moyen des énoncés (4 236,4 contre 4 107,7 caractères, environ 3 %), que la dépendance à l'hôte (verdict, limite 1) et qu'un écart de carte possible (le filtre du lanceur admet A100 PCIe, l. 32 ; R8 a été mesurée sur SXM4). | `recalcul_r8.py`, `longueurs_reval.py` ; verdict l. 63, 288 | Dire à Lazar que l'enjeu réel est le temps des juges (VR-03), et que « R8 tenue » est un passage formel du critère |
| NO-10 | information | conformité de la sélection | Fichier dérivé = source tronquée (objets égaux rang par rang ; empreinte canonique 3027abd6… des deux côtés ; `source.sha256` = 76cdeace… ; aucun remplacement) ; ordre = rangs de garde 0 à 59 du tirage, vérifiés contre le corpus scellé. | `comparer_taches2.py`, `ordre_tirage.py` | Aucune |
| NO-11 | information | valeurs | d(192) = 8 089,6213105190545 s (égal au résultat scellé) ; d(180) = 7 584,019978611614 s ; `duree_max_s` = 15 000 s ; configuration candidate conforme (« defaut », 15000, db3ad3ce… = valeur citée). | `recalcul_r8.py` | Aucune |

## Recalculs (commandes et sorties)

Les commandes sont lancées depuis la racine du dépôt, avec `PYTHONPATH=src PYTHONDONTWRITEBYTECODE=1 /home/user/controle-ia/.venv/bin/python <script>`. Les scripts qui lisent les fichiers de tâches tournent avec `-I`.

- `recalcul_r8.py` :
  - `signature duree_projetee_pilote : (chrono: 'dict', episodes: 'int')` ;
  - `EPISODES_PILOTE (constante du module) = 192` ;
  - `duree_projetee_pilote(chrono, 16) = 8089.6213105190545 ; egal scelle : True` ;
  - `d180 direct (gen+pu)*180/16 = 7584.019978611614` ;
  - `duree_max_s (180) : … ceil*60 = 16320 ; min = 15000` ;
  - `61 taches, 183 episodes : 7710.42 s <= 7800` ;
  - `62 taches, 186 episodes : 7836.82 s > 7800`.
- `relire_bras.py` :
  - `lire_bras(192) == lecture scellée : True` ;
  - `choisir_noyau(192) : (None, None)` ;
  - `clés qui changent … lire_bras(180) : {'conforme_avec_marge': (False, True), 'R8_duree': (False, True), 'conforme': (False, True)}` ;
  - `choisir_noyau(180) : ('defaut', None)` ;
  - `lecture forcée du générateur == lire_bras(180) : True`.
- `comparer_taches2.py` :
  - `tâches source : 64 ; dérivé : 60` ;
  - `dérivé == source[:60] (objets JSON) : True` ;
  - `sha256 canonique source[:60] : 3027abd6…` égale celle du dérivé ;
  - `remplacements : … longueur 0` ;
  - `longueur max (source, toutes) : 6786 au rang 45`.
- `ordre_tirage.py` :
  - `identifiants d'évaluation == rangs de garde 0 à 63, dans l'ordre : True` ;
  - `rangs (croissants, 0 = plus court) des 4 tâches retirées parmi 64 : [3, 4, 2, 23]` ;
  - `theory_experiment … 4 retirées : {'experiments_only': 4}`.
- `seuils_absolus.py` :
  - `60 tâches : à directions stériles 60 (seuil 16) ; référence non nulle … 58 (seuil 32) ; 48 complètes = 80.0% des tâches`.
- `longueurs_reval.py` :
  - `revalidation, 16 énoncés : … moyenne 4236.4` ;
  - `pilote, 60 énoncés : … moyenne 4107.7`.

## Fichiers de travail

Tous sont sous `/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-pilote-b8/n019/`. Leurs empreintes sha256 sont dans `empreintes-travail.sha256`, dans le même dossier.

- Scripts : `recalcul_r8.py`, `relire_bras.py`, `comparer_taches.py`, `comparer_taches2.py`, `structure_taches.py`, `ordre_tirage.py`, `seuils_absolus.py`, `longueurs_reval.py`.
- Sorties : `recalcul_r8-sortie.txt`, `relire_bras-sortie.txt`, `comparer_taches-sortie.txt` (sortie de `comparer_taches2.py`), `ordre_tirage-sortie.txt`, `seuils_absolus-sortie.txt`, `longueurs_reval-sortie.txt`.

## Limites et doutes

1. **Une lecture charitable de « 192 » existe** : une donnée prise au brouillon du pilote (section 2). Je ne la retiens pas, mais elle n'est pas absurde. Ma confiance sur la conclusion 1 est d'environ 75 %, et celle sur la conclusion 2 d'environ 85 %, parce que le doute même renvoie à Lazar.
2. **L'intention de Lazar derrière « full autonomy » est inconnaissable d'ici.** Je juge contre R-140 telle que la session l'a écrite et contre le brief, sans relecture par Lazar de cette lecture.
3. **Le générateur lu (`2f791291…`) date de 02:03 UTC, après le candidat (01:30 UTC).** Les lignes citées sont cohérentes avec les valeurs du candidat, mais je n'ai pas rejoué le générateur au commit 3ffab9f (lecture seule).
4. **Je n'ai consulté aucune offre**, puisqu'aucune commande Vast.ai n'est permise. Le lancement sans recharge (NO-03) est une possibilité de la règle du lanceur, pas une observation.
