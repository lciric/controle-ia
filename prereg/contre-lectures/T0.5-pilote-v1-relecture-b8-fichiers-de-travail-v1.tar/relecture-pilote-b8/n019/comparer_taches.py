"""Compare le fichier dérivé des 60 tâches à la source tronquée, sans afficher aucun texte (structure, nombres, empreintes)."""
import json, hashlib, sys
from pathlib import Path
D = Path("/home/user/controle-ia-travail")
src = D / "donnees/20261007-082440-t05-extraction/taches-evaluation.json"
der = D / "donnees/t05-pilote-v1/taches-pilote-60-v1.json"
for p in (src, der):
    print(p.name, hashlib.sha256(p.read_bytes()).hexdigest(), p.stat().st_size, "octets")
    s = p.with_name(p.name + ".sha256")
    print("  sceau :", s.exists(), (s.read_text().split()[0] == hashlib.sha256(p.read_bytes()).hexdigest()) if s.exists() else None)
S = json.loads(src.read_text(encoding="utf-8"))
T = json.loads(der.read_text(encoding="utf-8"))
def forme(x, prof=0):
    if isinstance(x, dict):
        return {k: forme(v, prof + 1) if prof < 1 else type(v).__name__ for k, v in x.items()}
    if isinstance(x, list):
        return f"list[{len(x)}]" + (f" de {type(x[0]).__name__}" if x else "")
    return type(x).__name__
print("type source :", type(S).__name__, "; type dérivé :", type(T).__name__)
if isinstance(S, dict):
    print("clés source :", {k: forme(v, 1) for k, v in S.items()})
if isinstance(T, dict):
    print("clés dérivé :", {k: forme(v, 1) for k, v in T.items()})
