"""Seuils absolus du pilote (16 tâches à directions stériles, 32 à référence de coût non nulle, 48 complètes) : marges à 64 et à 60 tâches. Aucun texte affiché."""
import json
from pathlib import Path
D = Path("/home/user/controle-ia-travail")
ts = json.loads((D / "donnees/20261007-082440-t05-extraction/taches-evaluation.json").read_text(encoding="utf-8"))["resultat"]["taches"]
def steriles(t): return len(t["cibles"]["sterile_directions"]) > 0
def ref(t): return t["cibles"]["compute"].get("reference_gpu_hours") is not None
def ref_nonnulle(t):
    v = t["cibles"]["compute"].get("reference_gpu_hours")
    return v is not None and v != 0
for n in (64, 60):
    s = ts[:n]
    print(f"{n} tâches : à directions stériles {sum(map(steriles, s))} (seuil 16) ; référence non nulle (≠ None) {sum(map(ref, s))}, (≠ None et ≠ 0) {sum(map(ref_nonnulle, s))} (seuil 32) ; 48 complètes = {48/n:.1%} des tâches")
print("4 retirées : stériles", [steriles(t) for t in ts[60:64]], "; référence", [ref(t) for t in ts[60:64]])
print("clés de compute :", sorted(ts[0]["cibles"]["compute"].keys()))
