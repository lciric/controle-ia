"""Égalité des objets JSON (60 premières tâches de la source contre le dérivé), sans afficher de texte de tâche."""
import json, hashlib
from pathlib import Path
D = Path("/home/user/controle-ia-travail")
src = D / "donnees/20261007-082440-t05-extraction/taches-evaluation.json"
der = D / "donnees/t05-pilote-v1/taches-pilote-60-v1.json"
S = json.loads(src.read_text(encoding="utf-8"))
T = json.loads(der.read_text(encoding="utf-8"))
ts = S["resultat"]["taches"]
td = T["taches"]
print("tâches source :", len(ts), "; dérivé :", len(td))
print("clés d'une tâche (source) :", sorted(ts[0].keys()))
print("clés d'une tâche (dérivé) :", sorted(td[0].keys()))
print("ensembles de clés identiques sur toutes les tâches :", all(sorted(a.keys()) == sorted(ts[0].keys()) for a in ts))
print("dérivé == source[:60] (objets JSON) :", td == ts[:60])
print("chaque tâche égale, rang par rang :", all(td[i] == ts[i] for i in range(60)))
canon = lambda x: json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
print("sha256 canonique source[:60] :", hashlib.sha256(canon(ts[:60])).hexdigest())
print("sha256 canonique dérivé       :", hashlib.sha256(canon(td)).hexdigest())
print("identifiants uniques (dérivé) :", len({t["identifiant"] for t in td}) == 60)
print("champ source du dérivé :", {k: (v if k != "chemin" else v) for k, v in T["source"].items()})
print("source.sha256 == empreinte réelle :", T["source"]["sha256"] == hashlib.sha256(src.read_bytes()).hexdigest())
print("règle du dérivé :", T["regle"])
r = S["resultat"]["remplacements"]
print("remplacements : type", type(r).__name__, "longueur", len(r))
if r:
    print("  clés d'un remplacement :", sorted(r[0].keys()) if isinstance(r[0], dict) else type(r[0]).__name__)
# longueurs des énoncés (nombres seulement)
def L(t):
    return len(t["questions"]) if "questions" in t else None
ls = [L(t) for t in ts]
print("longueur max (source, toutes) :", max(ls), "au rang", ls.index(max(ls)), "; rang < 60 :", ls.index(max(ls)) < 60)
print("longueur max (60 premières) :", max(ls[:60]), "; moyenne 60 premières :", round(sum(ls[:60]) / 60, 1),
      "; moyenne 64 :", round(sum(ls) / len(ls), 1))
print("longueurs des 4 tâches retirées (rangs 60-63) :", ls[60:64])
import numpy as np
print("q90 64 :", float(np.quantile(sorted(ls), 0.9)), "; q90 60 :", float(np.quantile(sorted(ls[:60]), 0.9)))
# l'ordre : y a-t-il une clé de rang / tirage dans les tâches ?
for k in ts[0].keys():
    v = ts[0][k]
    if isinstance(v, (int, float)) or k in ("rang", "rang_tirage", "ordre", "graine"):
        print("  clé numérique", k, [t[k] for t in ts][:64])
