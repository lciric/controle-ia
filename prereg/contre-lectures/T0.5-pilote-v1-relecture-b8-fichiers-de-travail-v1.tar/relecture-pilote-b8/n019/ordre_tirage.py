"""L'ordre du fichier d'évaluation est-il celui du rang de garde (tirage par graine) ? Aucun texte affiché."""
import json, hashlib, sys
from pathlib import Path
from collections import Counter
D = Path("/home/user/controle-ia-travail")
sys.path.insert(0, str(D / "src"))
from controle_ia.manifeste import verifier_resultat
corpus = D / "diag/20261006-134235-t05-corpus/corpus.json"
print("corpus sha256 :", hashlib.sha256(corpus.read_bytes()).hexdigest())
c = verifier_resultat(D, corpus)
gardes = sorted((f for f in c["resultat"]["fiches"] if f["statut"] == "gardé"), key=lambda f: f["rang_garde"])
ids_rang = [f"{f['id']}v{f['version']}" for f in gardes]
print("gardés :", len(gardes), "; rangs contigus :", [f["rang_garde"] for f in gardes] == list(range(len(gardes))))
S = json.loads((D / "donnees/20261007-082440-t05-extraction/taches-evaluation.json").read_text(encoding="utf-8"))
ts = S["resultat"]["taches"]
ids_eval = [t["identifiant"] for t in ts]
print("identifiants d'évaluation == rangs de garde 0 à 63, dans l'ordre :", ids_eval == ids_rang[:64])
print("60 premières == rangs 0 à 59 :", ids_eval[:60] == ids_rang[:60])
# longueurs : rang des 4 retirées parmi les 64
ls = [len(t["questions"]) for t in ts]
tri = sorted(ls)
print("rangs (croissants, 0 = plus court) des 4 tâches retirées parmi 64 :", [tri.index(x) for x in ls[60:64]])
print("min / médiane / max des 64 :", tri[0], (tri[31] + tri[32]) / 2, tri[-1])
# classification : comptes seulement (étiquettes courtes)
for champ in ("theory_experiment", "data_type"):
    vals = [t["classification"][champ] for t in ts]
    longs = max(len(v) for v in vals)
    if longs <= 40:
        print(champ, "64 :", dict(Counter(vals)), "; 4 retirées :", dict(Counter(vals[60:64])))
    else:
        print(champ, ": étiquettes longues, non affichées ; valeurs distinctes :", len(set(vals)))
# cibles : tailles seulement
for k in ("controls", "fruitful_directions", "sterile_directions"):
    n64 = [len(t["cibles"][k]) for t in ts]
    print(k, "nombre moyen 64 :", round(sum(n64) / 64, 2), "; 60 :", round(sum(n64[:60]) / 60, 2), "; 4 retirées :", n64[60:64])
