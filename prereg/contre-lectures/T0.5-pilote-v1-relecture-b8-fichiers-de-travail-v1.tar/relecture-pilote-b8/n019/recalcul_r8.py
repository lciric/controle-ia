"""Recalcul de R8 et de duree_max_s pour 192 et 180 épisodes du pilote, depuis mesures-defaut.json (nombres seulement)."""
import json, math, sys, hashlib
from fractions import Fraction
from pathlib import Path

DEPOT = Path("/home/user/controle-ia-travail")
sys.path.insert(0, str(DEPOT / "src"))
import controle_ia.environnements.revalider_pilote_a as rv
from controle_ia.manifeste import verifier_resultat

diag = DEPOT / "diag/20261011-225701-t05-revalidation-reel"
f = diag / "mesures-defaut.json"
print("sha256 mesures-defaut.json :", hashlib.sha256(f.read_bytes()).hexdigest())
try:
    print("verifier_resultat :", verifier_resultat(f))
except Exception as exc:
    print("verifier_resultat : ERREUR", type(exc).__name__, exc)
d = json.loads(f.read_text(encoding="utf-8"))
res = d["resultat"]
chrono = res["chrono"]
print("cles chrono :", sorted(chrono))
gen, pu = chrono["generation_s"], chrono.get("passe_unique_s", 0.0)
print("generation_s =", repr(gen), "; passe_unique_s =", repr(pu), "; somme =", repr(gen + pu))
print("duree_projetee_episodes_pilote_s scellee =", repr(res["duree_projetee_episodes_pilote_s"]))
print("EPISODES_PILOTE (constante du module) =", rv.EPISODES_PILOTE, "; TACHES_PILOTE =", rv.TACHES_PILOTE)
import inspect
print("signature duree_projetee_pilote :", inspect.signature(rv.duree_projetee_pilote))
d192 = rv.duree_projetee_pilote(chrono, 16)
print("duree_projetee_pilote(chrono, 16) =", repr(d192), "; egal scelle :", d192 == res["duree_projetee_episodes_pilote_s"])
# 180 episodes : la fonction ne prend pas le nombre d'episodes du pilote ; trois facons
d180_direct = (gen + pu) * 180 / 16
d180_ratio = d192 * 180 / 192
orig = rv.EPISODES_PILOTE
rv.EPISODES_PILOTE = 180          # en memoire seulement, dans ce processus
d180_patch = rv.duree_projetee_pilote(chrono, 16)
rv.EPISODES_PILOTE = orig
print("d180 direct (gen+pu)*180/16 =", repr(d180_direct))
print("d180 ratio d192*180/192    =", repr(d180_ratio))
print("d180 constante a 180       =", repr(d180_patch))
print("d180 <= 7800 :", d180_direct <= 7800, "; marge :", 7800 - d180_direct, "s ;", (7800 - d180_direct) / 7800 * 100, "%")
print("d192 <= 7800 :", d192 <= 7800, "; depassement :", d192 - 7800)
def duree_max(dd):
    return min(15000, math.ceil((1.2 * dd + 7200) / 60) * 60)
for nom, dd in (("192", d192), ("180", d180_direct)):
    brut = 1.2 * dd + 7200
    print(f"duree_max_s ({nom}) : 1,2*d+7200 = {brut!r} ; /60 = {brut/60!r} ; ceil*60 = {math.ceil(brut/60)*60} ; min = {duree_max(dd)}")
# seuil d'episodes maximal sous 7800 s
for n in range(150, 193):
    if (gen + pu) * n / 16 > 7800:
        print("premier nombre d'episodes au-dessus de 7800 s :", n, "->", (gen + pu) * n / 16)
        print("dernier sous 7800 s :", n - 1, "->", (gen + pu) * (n - 1) / 16)
        break
# en taches a 3 episodes
for t in range(50, 65):
    print(f"  {t} taches, {3*t} episodes : {(gen+pu)*3*t/16:.2f} s", "<= 7800" if (gen+pu)*3*t/16 <= 7800 else "> 7800")
# lecture complete par lire_bras avec duree projetee 180 (pour mesurer l'effet de la substitution)
lect = json.loads((diag / "lecture-defaut.json").read_text(encoding="utf-8"))["resultat"]["lecture"]
print("lecture scellee defaut :", {k: lect[k] for k in ("R8_duree", "conforme", "conforme_avec_marge")})
