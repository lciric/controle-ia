"""Longueurs (caractères) des 16 énoncés d'entraînement de la revalidation contre les 60 du pilote ; aucun texte affiché."""
import sys, statistics
from pathlib import Path
D = Path("/home/user/controle-ia-travail")
sys.path.insert(0, str(D / "src"))
from controle_ia.environnements.revalider_pilote_a import taches_d_entrainement
from controle_ia.environnements.pilote_a import charger_taches
ent = D / "donnees/20261007-082440-t05-extraction/taches-entrainement.json"
ev = D / "donnees/20261007-082440-t05-extraction/taches-evaluation.json"
choisies, dom = taches_d_entrainement(ent, ev, 16)
l16 = [len(t["questions"]) for t in choisies]
print("revalidation, 16 énoncés : min", min(l16), "max", max(l16), "moyenne", round(statistics.mean(l16), 1), "médiane", statistics.median(l16))
p60 = [len(t["questions"]) for t in charger_taches(D / "donnees/t05-pilote-v1/taches-pilote-60-v1.json")]
print("pilote, 60 énoncés : min", min(p60), "max", max(p60), "moyenne", round(statistics.mean(p60), 1), "médiane", statistics.median(p60),
      "; au-dessus du max de la revalidation (5 340) :", sum(x > max(l16) for x in p60))
print("domaine scellé :", dom)
