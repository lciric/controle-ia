"""Rejoue la lecture gelée `lire_bras` du bras « defaut » depuis les résultats scellés (nombres seulement), avec la durée
projetée scellée (192 épisodes) puis avec celle de 180 épisodes ; compare à `lecture-defaut.json`. N'ouvre ni
episodes-defaut.json ni chemin-defaut.json (D-20)."""
import json, sys
from pathlib import Path
D = Path("/home/user/controle-ia-travail")
sys.path.insert(0, str(D / "src"))
import controle_ia.environnements.revalider_pilote_a as rv
diag = D / "diag/20261011-225701-t05-revalidation-reel"
mes = json.loads((diag / "mesures-defaut.json").read_text(encoding="utf-8"))["resultat"]
lec = json.loads((diag / "lecture-defaut.json").read_text(encoding="utf-8"))["resultat"]
res = json.loads((diag / "resume.json").read_text(encoding="utf-8"))["resultat"]
math_ = json.loads((diag / "lecture-math.json").read_text(encoding="utf-8"))["resultat"]["lecture"]
man = json.loads((D / "runs/20261011-225701-t05-revalidation-reel/manifeste.json").read_text(encoding="utf-8"))
config = man["config"] if "config" in man else man.get("configuration")
print("clés config utiles :", {k: config[k] for k in ("tolerance_equivalence", "marge_q99", "duree_max_episodes_pilote_s", "memoire_pic_max_gio", "rho_max")})
chrono = mes["chrono"]
def lire(d):
    return rv.lire_bras(mes["mesures"], mes["controle_negatif"], lec["repere"], mes["rejeu_identique"], config,
                        zone_generee=lec["zone_generee"], audit=lec["audit"],
                        chemin=lec["chemin"]["lecture"] if lec.get("chemin") else None, bras="defaut",
                        memoire_pic_gio=mes["memoire_pic_gio"], duree_projetee_s=d)
d192 = rv.duree_projetee_pilote(chrono, 16)
l192 = lire(d192)
print("lire_bras(192) == lecture scellée :", l192 == lec["lecture"])
print("choisir_noyau(192) :", rv.choisir_noyau({"defaut": l192, "math": math_}), "; résumé scellé :", res["noyau_retenu"], res["proposition_au_noeud"])
d180 = (chrono["generation_s"] + chrono["passe_unique_s"]) * 180 / 16
l180 = lire(d180)
diff = {k: (lec["lecture"].get(k), l180.get(k)) for k in set(lec["lecture"]) | set(l180) if lec["lecture"].get(k) != l180.get(k)}
print("d180 =", d180, "; clés qui changent entre lecture scellée et lire_bras(180) :", diff)
print("choisir_noyau(180) :", rv.choisir_noyau({"defaut": l180, "math": math_}))
# la lecture fabriquée par le générateur (dict(lec, R8_duree=True, conforme=True, conforme_avec_marge=True))
gen = dict(lec["lecture"], R8_duree=True, conforme=True, conforme_avec_marge=True)
print("lecture forcée du générateur == lire_bras(180) :", gen == l180)
