"""Types et tailles des champs des tâches (aucun texte affiché)."""
import json
from pathlib import Path
from collections import Counter
D = Path("/home/user/controle-ia-travail")
S = json.loads((D / "donnees/20261007-082440-t05-extraction/taches-evaluation.json").read_text(encoding="utf-8"))
ts = S["resultat"]["taches"]
t0 = ts[0]
for k, v in t0.items():
    if isinstance(v, dict):
        print(k, "dict, clés :", sorted(v.keys()), "types :", {kk: type(vv).__name__ for kk, vv in v.items()})
    elif isinstance(v, list):
        print(k, f"list[{len(v)}]", "élément :", type(v[0]).__name__ if v else None,
              ("clés élément : " + str(sorted(v[0].keys()))) if v and isinstance(v[0], dict) else "")
    else:
        print(k, type(v).__name__)
