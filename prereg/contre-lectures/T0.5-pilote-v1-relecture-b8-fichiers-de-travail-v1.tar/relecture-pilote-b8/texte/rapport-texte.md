# Relecture R2 du pilote 8B de T0.5, candidat 1 : angle « texte »

- **Relecteur** : sous-agent neuf. Il n'a écrit ni le brouillon, ni le générateur, ni le code du pilote. Lecture seule dans le dépôt de travail et dans `pilote-v1/`.
- **Date** : 2026-10-12 (UTC).
- **Objet relu** :
  - `brouillons/T0.5-pilote-8B-v1-candidat1.md` (sha256 `15a5cd3e457dd7b6db234bc08ce7378514ec217b8f8099dea426eb3743b33150`, 394 lignes) ;
  - `brouillons/T0.5-pilote-config-v1-candidat1.json` (sha256 `6979a00ebef1e794f900e089df9b1658482f8600ce343cb81c95da4434da2b8a` ; empreinte canonique `db3ad3cebc3f0832e43514749b42c01b344ab4dca2997153d851814fe251b714`).
  - Dépôt `/home/user/controle-ia-travail`, tête `942c65e`. Commit du code cité : `3ffab9f`.
- **Règles tenues** :
  - aucune écriture dans le dépôt ni dans `pilote-v1/` ;
  - aucune commande vastai ; aucun jeton affiché ;
  - D-20 : `episodes-defaut.json` et `chemin-defaut.json` n'ont pas été ouverts. Ils sont présents dans mon clone, mais je n'y ai pas touché.
  - Des résultats de la revalidation (`resume.json`, `mesures-defaut.json`, `lecture-defaut.json`), seuls des nombres et des drapeaux ont été lus.
  - Pour les tâches, seuls des décomptes ont été calculés ; aucun texte n'a été affiché.
  - Un seul clone, créé sous ce dossier (`clone/`), puis supprimé à la fin.
- **Numéros de ligne** : ceux du candidat 1, sauf mention contraire. Les lignes du code renvoient au commit `3ffab9f`.

## Verdict

**Scellable après corrections.** Bilan : 0 bloquant, 2 majeurs (TX-01, TX-02), 14 mineurs, 2 informations.

Points conformes :
- le candidat est, octet pour octet, la sortie du générateur rejoué en mode « candidat » au commit `3ffab9f` ;
- les 44 empreintes de 64 caractères citées sont exactes (hors la paire factice de la relecture, attendue) ;
- la configuration et le fichier des 60 tâches sont conformes ;
- 680 tests sont collectés dans les deux environnements ;
- le corps du texte décrit l'ordre des étapes du code.

Corrections demandées :
- une définition gelée a disparu : la « cause d'infrastructure » qui décide d'un relancement (TX-01) ;
- le traitement de l'état des lieux n'est pas tracé, et plusieurs de ses constats sur le texte sont restés sans suite (TX-02) ;
- plusieurs énoncés sont devenus inexacts après le brouillon 8 : TX-03 à TX-11 et TX-13 à TX-17.

## Réponses aux questions

**1. R1 dans la forme à 60 tâches.** Les sept éléments sont présents :
- hypothèse : l. 30-50 ;
- prédictions chiffrées et signe : l. 52-70, de P1 à P7, avec clauses de confirmation et de réfutation ; P3 par son signe ;
- métrique : l. 72-111 ;
- seuil : l. 113-136 ;
- plan d'analyse : l. 138-171, avec 60 tâches et 180 épisodes ;
- critères de lecture gelés : l. 173-212 ;
- liste d'arrêt : l. 214-236.

Trois lacunes restent :
- la liste d'arrêt est incomplète (TX-04) ;
- deux lignes de lecture ne sont pas applicables telles quelles : le repli « math » (TX-06) et le run sans `arret.json` (TX-07) ;
- la règle de relancement renvoie à une définition qui n'existe plus (TX-01).

Aucun épisode du pilote n'a été joué (l. 251).

**2. Cohérence 60 tâches et 180 épisodes.**

Les mentions de 64 et de 192 sont légitimes partout : source à 64 tâches, verdict à 192 épisodes, simulations annotées « 60 ici » (l. 133, l. 135). Une exception : l. 168, « sur 64 tâches, l'écart-type… », n'est pas annotée (TX-14).

Code de lecture : les seuils sont des décomptes absolus, compatibles avec 60 tâches :
- `lire_pilote.py:55` `TACHES_COMPLETES_MIN = 48`, utilisé l. 339 (plan B) et l. 813 (P3) ;
- `:59` `TACHES_STERILES_MIN = 16` et `:61` `TACHES_REFERENCE_MIN = 32`, utilisés l. 1001-1010 ;
- `:50` `PAR_STRATE = 80` (« au plus », par strate) ;
- `:75` `CONFIG_ATTENDUE` : 3 épisodes par tâche, e0 noté deux fois, e0 et e1 décisifs.

Aucune trace de 64 ni de 192 dans `lire_pilote.py`, `analyse_pilote.py`, `lancer_pilote_a.py`, `pilote_a.py`, ni dans les deux scripts. Le seul « 64 » restant est la largeur du modèle jouet (`lancer_pilote_a.py:256`).

Décomptes sur le fichier dérivé, sans aucun texte affiché :
- 60 tâches sur 60 ont des directions stériles (il en faut au moins 16) ;
- 58 tâches sur 60 ont une référence de coût non nulle (il en faut au moins 32) ;
- l'énoncé le plus long, 6 786 caractères, est au rang 46 des 60 ; la longueur moyenne est de 4 107,7 caractères (N-019 : « 4 108 »).

« Lots de 60 » (l. 166) est la taille des lots d'étiquetage (`TAILLE_LOT_ETIQUETAGE`, `lire_pilote.py:51`), sans rapport avec les 60 tâches.

Effet de la réduction : la règle des 48 tâches complètes ne tolère plus que 12 tâches incomplètes, au lieu de 16. N-019 le dit ; le préenregistrement, non (TX-14).

**3. Nouvel ordre des étapes.**

Le corps du texte est conforme au code :
- l. 142-150 ;
- table des runs partiels, l. 185-189 ;
- « Calcul », l. 170 ;
- liste d'arrêt, l. 220-223.

Ordre dans `lancer_pilote_a.py` :
- l. 317 : chargement de l'agent ;
- l. 319-324 : contrôle du format ;
- l. 326-327 : préchargement ;
- l. 328-353 : épisodes, puis `episodes.json` ;
- l. 374-390 : appariement et base « énoncé seul », par le 8B, puis `appariements.json` ;
- l. 391-393 : chargement hors ligne du 3B ;
- l. 415 : notations décisives, 8B puis 3B ;
- l. 416 : notations de D.

Le test `tests/test_pilote_a.py:411` exige `["appariement", "enonce_seul", "decisives", "decisives", "descriptives"]`. Il passe : 102 tests réussis dans les trois fichiers du pilote, rejoués dans mon clone.

L'échéance est contrôlée à chaque lot (`pilote_a.py:165`, `:237`) et à chaque pas des épisodes (`harnais/episode.py:208`).

Restent décrits à l'ancien ordre (TX-03) :
- les lignes de traitement D-6 (l. 305), F-2 (l. 356), Y-5 (l. 371), V-1 (l. 384) et V-4 (l. 387) ;
- la docstring de tête de `lancer_pilote_a.py`, l. 3-8, dans un module de lecture gelé.

Une imprécision dans la liste d'arrêt : l. 222 dit « après les épisodes » pour le chargement hors ligne, alors qu'il vient après l'appariement (TX-16).

**4. Valeurs et empreintes.**

Empreintes : les 44 empreintes de 64 caractères ont été confrontées aux fichiers suivis (`git ls-files`, sha256). 42 désignent bien leur fichier : 36 rattachées au chemin cité juste avant, 6 identifiées par recherche (fichier des tâches, brouillons 1, 3, 4, 5 et 6). Restent deux cas attendus :
- l'empreinte canonique de la configuration (l. 10), recalculée par `config_canonique` : `db3ad3ce…b714`, égale ;
- la paire factice de la relecture R2 (l. 265).

Les cinq brouillons relus cités l. 255-260 sont bien les brouillons 1, 3, 4, 5 et 6.

Scripts au commit cité : amorce `59f49aab…de73`, script de l'instance `ab74ffa0…d7a2`, conformes.

Tâches :
- `taches-pilote-60-v1.json` a l'empreinte `287e8348…d5aa` ; il est suivi et présent aux commits `3ffab9f` et `942c65e` ;
- il est égal aux 60 premières tâches de la source `76cdeace…7e` (64 tâches, aucun remplacement).

Valeurs reprises du verdict, toutes conformes à `mesures-defaut.json`, `lecture-defaut.json` et `resume.json` :
- (665,8512 + 8,2839) × 180 / 16 = 7 584,02 s ;
- formule : min(15 000 ; ⌈(1,2 × 7 584,02 + 7 200) / 60⌉ × 60 = 16 320) = 15 000 s ;
- 8 089,62 s pour 192 épisodes ;
- R1 = 0,1354 ≤ 0,15 ;
- réserve RV-5 seule au résumé ; part sous 1 % = 0,0 ;
- mémoire de la carte : 79,44 Gio.

Mesures de l'instance 55458787, conformes aux traces :
- « 670 passed in 491.38s » ;
- ligne AMORCE à 22:46:48 ;
- fin des tests et début du run à 22:57:01, soit 613 s ;
- création à 22:46:03, soit 658 s jusqu'au début du run. La source de l'heure de création, `lancement.txt`, n'est pas citée (TX-15).

Tests attendus : `680` est conforme ; « 680 tests collected » dans les deux environnements, sans marque de saut dans `tests/`.

Le générateur, rejoué dans mon clone au commit `3ffab9f`, avec la date « 2026-10-12 01:29 UTC », l'entropie 1 et les mêmes paires de rapports, redonne le candidat et la configuration, octet pour octet (`cmp`).

Deux valeurs sont mal nommées ou mal attribuées :
- la formule de R8 à 180 épisodes (TX-11) ;
- la durée des juges (TX-08).

**5. Différentiel du brouillon 7 au brouillon 8** (`diff`, 115 lignes, enregistré dans `diff-b7-b8.txt`).

Aucun seuil, aucune prédiction et aucune constante numérique ne change. Côté code, seule l'invite de l'étiqueteur change dans `lire_pilote.py` depuis `e6ce058` (`git diff e6ce058 3ffab9f`) ; `analyse_pilote.py` est inchangé. La configuration ne change que par `noyau_attention` et `duree_max_s`.

Changements motivés :
- passage à 60 tâches (N-019) ;
- ordre des étapes (SI-01, motif écrit l. 150) ;
- préchargement (SI-02) ;
- ligne « Lancement » ;
- valeurs et réserves du verdict ;
- mesures de « Calcul » ;
- Transparence ;
- renvois au plan.

Changements non dits ou dits inexactement :
- les lignes de lecture des runs partiels changent : « arrêt pendant l'appariement » passe de « décomposition et plan B lisibles » à « juges non lisibles ». Pourtant, l. 251 affirme « aucune lecture n'en change » (TX-09) ;
- l'invite fixe de l'étiqueteur, constante gelée dont l'empreinte figure parmi les constantes de lecture (l. 166), est reformulée en annexe (l. 326). Ce changement n'est cité ni dans le résumé de la l. 3 ni à la l. 251 (TX-09) ;
- l'ajout « modèle non épinglé » (l. 105) n'a pas de source citée (TX-17).

**6. Transparence.** Elle est déclarée pour l'essentiel :
- T0.4 ;
- verdict et grandeurs ;
- D-20 ;
- R-132, R-133, N-018 ;
- état des lieux ;
- essai jouet de l'étiqueteur ;
- ordre et longueurs des tâches.

Elle omet deux choses (TX-10) :
- les nombres précis tirés des fiches de la revalidation que la session connaît désormais, par l'état des lieux (VR-03) : 7,44 propositions finales par épisode ; 227,5 jetons par action, dont 6,9 % au plafond de 400, une grandeur rapportée par CL-16 ; 8 619 caractères par ensemble final ; 11,5 cibles par tâche ;
- le fait que c'est un lecteur de l'état des lieux qui a ouvert `episodes-defaut.json`, pour des décomptes seulement.

Les décomptes structurels calculés par cette relecture (60 tâches sur 60 à directions stériles, 58 sur 60 à référence non nulle) parviennent maintenant à la session : à déclarer aussi.

**7. Ce qui manquerait à un sous-agent R13.**
- Une définition gelée des causes de relancement : infrastructure, déterministe, indéterminée (TX-01).
- Des lignes de traitement sans contradiction avec l'ordre en vigueur (TX-03).
- Une ligne de lecture pour un run sans `arret.json` ni `resume.json`, que le code refuse de lire (TX-07).
- Le seul repli réaliste en cas de garde déclenchée (TX-06).
- Le modèle des étiqueteurs, consigné (TX-17).
- Écrire que « juge complet » signifie : fichier `notations-<juge>-decisives.json` présent, puisque le code n'écrit ce fichier qu'à la fin de l'étape (`lancer_pilote_a.py:405-413` ; `lire_pilote.py:950-954`).
- Écrire que le cas « aucun juge complet » est plausible (TX-08) ; P2 et P3 y sont non concluants.

## Constats

### TX-01 — majeur — La définition de la « cause d'infrastructure » a disparu, alors qu'elle décide du relancement

- **Où** : candidat l. 22, l. 7, l. 150, l. 188, l. 189, l. 192, l. 374 (ligne Y-8) ; `docs/procedures/pilote-T0.5-v1/plan-lancement-pilote-v1.md`, l. 3 et l. 57-61.
- **Preuve** :
  - Le candidat, l. 22, dit du plan de lancement : « (remplace la procédure de lancement, brouillon 4 ; définit la cause d'infrastructure et le relancement unique, étapes 4 à 6) ».
  - Le plan, l. 57-59, dit seulement : « seulement pour une cause d'infrastructure consignée (ligne R-… qui dit « relancement », « pilote », « infrastructure »), `episodes.json` absent de la branche `-v1` ». `grep -n -i infrastructure` sur le plan ne trouve que ces lignes.
  - La définition opérante était dans la procédure, brouillon 4, l. 151-154 : « **cause d'infrastructure** : une limite externe due à l'infrastructure, jamais l'échéance interne `duree_max_s` (Y-8) : réseau ; instance perdue ; mise en place si lente que la surveillance arrête l'instance avant la fin du run ; dépôt distant injoignable au contrôle de la branche », avec ses pendants « cause déterministe » (panne de mémoire, tests en échec, garde violée, fichier cité absent, mise en place hors réseau) et « cause indéterminée » (aucun relancement ; nœud).
  - Le plan, l. 3, remplace cette procédure.
  - La ligne Y-8 du candidat (l. 374) renvoie encore à « la procédure (section 5) ».
  - Le lanceur, `lancer_pilote_v1.sh` l. 59, n'exige que la présence des trois mots dans une ligne R-… rédigée par la session.
- **Effet** : après un arrêt sans `episodes.json`, c'est la session qui qualifie la cause, au vu de l'incident, et cette qualification déclenche un second run payant et choisit le run lu. Le texte gelé doit la fixer d'avance. Cas ambigus aujourd'hui :
  - échéance interne pendant les épisodes ;
  - poussée initiale refusée (TX-04) ;
  - « réseau » contre « mise en place hors réseau » ;
  - contrôle négatif de fin de phase en échec.
- **Action** :
  - Recopier dans le corps du texte, au paragraphe « Préséance » (l. 192), les trois causes de la procédure b4 (l. 151-154). Y ajouter le préchargement (réseau : infrastructure) et trancher la poussée initiale refusée.
  - Corriger la l. 22 (« définit ») et la ligne Y-8.
  - À défaut, écrire la définition dans le plan et la citer par section.

### TX-02 — majeur — Le traitement de l'état des lieux n'est pas tracé ; des constats sur le texte restent sans suite ni refus motivé

- **Où** : l. 3 (« traitement à la section « Contre-lecture » ») ; l. 264.
- **Preuve** :
  - La l. 264 tient en une phrase : « Traitement dans le brouillon 8, dans le code (commit `1f53a08` : SI-01, SI-02) et dans la chaîne… ». Il n'y a aucune table, alors que chaque relecture précédente en a une (CL, D, F, Y, V).
  - L'état des lieux (`T0.5-pilote-v1-etat-des-lieux-resultats-v1.json`, `8ca0f843…`) compte 124 constats.
  - Constats qui touchent le texte, vérifiés non appliqués et non déclarés :
    - HR-03 (majeur) : réécrire les lignes de traitement de l'ancien ordre. Non fait (TX-03).
    - ML-11, HR-06, SI-13 : poussée initiale absente de la liste d'arrêt. Non fait (TX-04).
    - AR-19 (b) : population, « exclusions de l'extraction ». Non fait (TX-05).
    - VR-08, HR-10 : repli « noyau math ». Non fait (TX-06).
    - SI-10 : run sans `arret.json` illisible. Non déclaré (TX-07).
    - HR-09 : risque résiduel K-1. Absent (`grep -c "K-1"` donne 0).
    - HR-07 : format du 3B chargé hors ligne non recontrôlé. Non déclaré.
    - PL-22, VR-07 : aucune garde de carte dans le code, seul le filtre d'offre garde l'A100. Non déclaré.
    - Critique, manques[18] et corrections_au_plan[1] : épingler le modèle de l'étiqueteur. Seulement « limite déclarée » (TX-17).
    - RC-06 : archive citée sans dossier (l. 132). Non fait (TX-15).
- **Effet** :
  - Écart à la pratique R2 du dépôt : chaque remarque est acceptée, ou refusée avec sa raison.
  - Plusieurs énoncés contradictoires ou faux subsistent dans un texte appelé à être gelé.
- **Action** :
  - Ajouter, après la ligne de l'état des lieux, une table « Traitement de l'état des lieux » pour les constats qui touchent le préenregistrement : accepté, et où ; ou non adopté, et pourquoi.
  - Les constats de la chaîne peuvent renvoyer au plan.

### TX-03 — mineur — Les lignes de traitement et la docstring du lanceur décrivent l'ancien ordre

- **Où** : l. 305 (D-6), l. 356 (F-2), l. 371 (Y-5), l. 384 (V-1), l. 387 (V-4) ; `src/controle_ia/environnements/lancer_pilote_a.py:3-8`.
- **Preuve** :
  - Y-5, l. 371 : « exige « décisives, décisives, appariement, descriptives » ; la mutation du relecteur (appariement avant les notations décisives) le fait maintenant échouer ».
  - V-4, l. 387 : « « décisives, décisives, appariement, énoncé seul, descriptives » ».
  - D-6, l. 305 : « Ordre : épisodes, notations décisives, appariement, notations de D ».
  - Le test au commit cité, `tests/test_pilote_a.py:411`, exige `["appariement", "enonce_seul", "decisives", "decisives", "descriptives"]`.
  - La docstring du lanceur, l. 5-7 : « 2. notation des ensembles finaux par le juge 8B puis le juge 3B […] 3. appariement ».
  - `lancer_pilote_a.py` figure dans `MODULES_LECTURE` (`lire_pilote.py:82-85`). Il est donc gelé du scellement à la fin de la lecture.
- **Action** :
  - Annoter chaque ligne : « (ordre remplacé au brouillon 8 : SI-01 ; test : appariement, énoncé seul, décisives, décisives, descriptives) ». V-1 : « ligne fondue dans « arrêt au chargement du 3B ou pendant les notations décisives » ».
  - Corriger la docstring avant le commit cité, ou déclarer ce reste.

### TX-04 — mineur — La liste d'arrêt omet des arrêts du code et du script

- **Où** : l. 216 (« Avant l'installation ») et l. 218 (« Avant le manifeste »).
- **Preuve** :
  - `scripts/pilote_t05_instance.sh:147-157` : trois tentatives, puis « poussée initiale de la branche $BRANCHE refusée (…) : droit d'écriture du jeton ? arrêt avant l'installation » et `exit 2`. La l. 216 ne le nomme pas. C'est signalé trois fois par l'état des lieux (ML-11, HR-06, SI-13), et la revalidation v2 le listait.
  - Arrêts d'avant le manifeste présents dans le code mais absents de la l. 218 :
    - configuration incomplète : `exiger_config`, `CLES_LANCEMENT`, `lancer_pilote_a.py:269-272` ;
    - mode inconnu : l. 273-274 ;
    - run réel sans préenregistrement : l. 281-282 ;
    - identifiants de tâches en double, ou sceau du fichier des tâches non conforme : `pilote_a.py:47-58` ;
    - sceau de la configuration : `_main`, l. 446.
- **Action** : compléter la l. 216 par « ; poussée initiale de la branche refusée après trois tentatives (droit d'écriture du jeton) » et la l. 218 par ces arrêts.

### TX-05 — mineur — Population : les « exclusions de l'extraction » n'ont pas eu lieu

- **Où** : l. 48-50.
- **Preuve** :
  - Le texte dit : « les exclusions de l'extraction : « theory_only » confirmé, sorties invalides, contre-vérification échouée (bilan de l'extraction) ».
  - Le bilan `diag/20261007-082440-t05-extraction/bilan-extraction.json` (`7081907b…`) indique `exclus = {}` et `remplacements = []`. Ses 96 statuts valent tous « retenu ». On compte 64 tâches d'évaluation et 32 d'entraînement. Constat AR-19 (b), non appliqué.
- **Action** : écrire « les exclusions de l'extraction : aucune (bilan : `exclus` vide, aucun remplacement) ». Rattacher la phrase de la l. 50 à la seule conversion (29 papiers exclus sur 125).

### TX-06 — mineur — Repli « noyau math » impossible ; noyau dit « fixé par la revalidation »

- **Où** : l. 183, l. 136, l. 153, l. 155.
- **Preuve** :
  - L. 183 : « garde en ligne déclenchée | instrument non concluant ; nœud : noyau « math » au débit mesuré, ou revalidation au nouveau domaine ».
  - Le verdict, sections 1 et 3, établit que le bras « math » a fait une panne de mémoire (68,64 Gio alloués) à environ 5 040 jetons remplis au lot de 8 ; le pilote a des énoncés plus longs (6 786 caractères). Constats VR-08 et HR-10.
  - L. 136 (« au noyau que fixe la revalidation »), l. 153 (« au noyau fixé par la revalidation ») et l. 155 (« `noyau_attention` et `duree_max_s` : verdict de la revalidation ») contredisent le verdict (« aucun noyau n'est retenu ») et la l. 11 (« fixés par le verdict de la revalidation et la décision N-019 »).
- **Action** :
  - L. 183 : ne garder que « revalidation au nouveau domaine (autre lot ou autre carte) ».
  - L. 136, 153 et 155 : « fixé par N-019 sur les mesures scellées de la revalidation ».

### TX-07 — mineur — Un run partiel sans `arret.json` ni `resume.json` est illisible par le code ; le texte le dit lisible

- **Où** : l. 192 ; `src/controle_ia/environnements/lire_pilote.py:202-206` ; `scripts/pilote_t05_instance.sh:217-228`.
- **Preuve** :
  - La l. 192 dit : « les lignes « run partiel » se lisent sur les résultats scellés poussés, non sur l'étiquette de l'étape : `episodes.json` présent, format lisible ».
  - Le code lève `GardeArret(f"{run_pilote} : ni résumé ni arrêt consigné ; empreinte des tâches inconnue")` quand ni `resume.json` ni `arret.json` n'existent.
  - Or `consigner_arret` committe et pousse « résultats partiels committés (dont arret.json s'il existe) ». C'est le cas d'un lanceur tué par le KILL du délai externe, cinq minutes après le TERM (l. 309-312 du script ; Z-5). Constat SI-10.
- **Action** :
  - Ajouter une ligne : « run partiel sans `arret.json` ni `resume.json` : non lisible par le code (empreinte des tâches inconnue) ; nœud ».
  - Ou bien, avant le commit cité, écrire `taches_sha256` dans `episodes.json` et le lire en repli.

### TX-08 — mineur — Durées des juges et de l'appariement : estimations mal attribuées, cas « aucun juge complet » non dit

- **Où** : l. 150, l. 170. Même formulation dans `docs/decisions/decision-N-019-v1.md`, « Risques déclarés ».
- **Preuve** :
  - L. 150 : « l'appariement […] dure quelques minutes, tandis que la durée des notations n'a jamais été mesurée ». Or l'appariement n'a jamais été mesuré non plus. L'état des lieux l'estime à 5 à 10 minutes (SI-01, action) ou à 800 à 1 600 s, pour 537 lots de 32 (VR-03).
  - L. 170 : « les notations décisives des deux juges sont estimées, sans mesure, entre environ 5 400 et 15 100 s ». Dans l'état des lieux, cette fourchette porte sur « l'appariement et les notations décisives (cas central ≈ 9 300 s) » (`lectures[3].resume`). Pour les seules notations décisives, VR-03 donne 4 600 à 13 500 s (central ≈ 8 200).
  - Hypothèses de VR-03 (non mesurées), ramenées à 180 épisodes (facteur 0,9375) : appariement jusqu'à 1 500 s, notations décisives jusqu'à 12 656 s. Avec les épisodes à 7 584 s et environ 200 s de chargements, il reste environ 5 700 s, sous la seule part du 8B (environ 7 000 s à 100 ms par passe contre 80 pour le 3B). Dans le cas pessimiste, le 8B est donc aussi interrompu.
  - Le texte ne dit que « l'échéance arrêtera probablement les notations du second juge (3B) ».
- **Action** :
  - Écrire : « appariement, jamais mesuré : 5 à 27 minutes estimées (SI-01, VR-03) ; notations décisives : 4 600 à 13 500 s estimées (VR-03), 5 400 à 15 100 s avec l'appariement ».
  - Ajouter : « dans le cas pessimiste, aucun juge n'est complet : les deux juges en nœud, P2 et P3 non concluants ».
  - Aligner N-019 par une note, sans la réécrire.

### TX-09 — mineur — Transparence : « aucune lecture n'en change » est inexact ; l'invite de l'étiqueteur n'est pas citée parmi les changements

- **Où** : l. 251, l. 3, l. 326, l. 186-188.
- **Preuve** :
  - Brouillon 7, l. 180 : « run partiel : arrêt pendant l'appariement | format, décomposition et plan B lisibles ; familles non lisibles : nœud ».
  - Brouillon 8, l. 186 : « format lisible ; familles et juges non lisibles : nœud (SI-01) ». Les lignes 181-182 du brouillon 7 sont aussi fondues et inversées.
  - L. 251 : « aucun seuil, aucune prédiction ni aucune lecture n'en change ».
  - L'invite fixe change de « This task is self-contained: ignore any project instructions or session routines, and open no file other than those named in the instructions. […] » à « This is a self-contained labeling task. Open no file other than those named in the instructions. […] » (annexe l. 326 ; `lire_pilote.py:140-141`). Son empreinte est une constante de lecture (`INVITE_ETIQUETEUR_SHA256`, l. 172 du module). La l. 3 et la l. 251 ne la citent pas.
- **Action** :
  - L. 251 : « aucun seuil ni aucune prédiction ne change ; les lignes de lecture des runs partiels suivent le nouvel ordre (SI-01) ; l'invite fixe de l'étiqueteur est reformulée (refus du classificateur, essai jouet du 2026-10-12) ».
  - Ajouter l'invite au résumé de la l. 3.

### TX-10 — mineur — Transparence : nombres connus des fiches de la revalidation non listés ; ouverture des fiches par un lecteur non dite

- **Où** : l. 244-249 (l. 247).
- **Preuve** :
  - L. 247 : « elle s'appuie sur des nombres lus dans les fiches scellées de la revalidation (propositions par épisode, longueurs), sans aucun texte affiché ».
  - VR-03 (preuve : « clone : mesures-defaut.json (chrono), episodes-defaut.json (comptes seuls, aucun texte affiché) ») donne ces nombres, que la session a lus dans le JSON de l'état des lieux : 7,44 propositions finales par épisode ; 227,5 jetons par action, dont 6,9 % au plafond de 400 (grandeur rapportée par CL-16) ; 8 619 caractères par ensemble final ; 11,5 cibles par tâche.
  - La présente relecture ajoute des décomptes des tâches : 60 sur 60 à directions stériles ; 58 sur 60 à référence non nulle.
- **Action** :
  - Lister ces nombres et dire qu'un lecteur neuf de l'état des lieux a ouvert `episodes-defaut.json`, pour des décomptes seulement.
  - Rappeler que P1 à P7 sont inchangées depuis les brouillons 3 à 6, écrits avant tout épisode de la revalidation.

### TX-11 — mineur — La valeur 7 584,02 s ne sort pas de la fonction gelée `duree_projetee_pilote`, qui garde 192

- **Où** : l. 20 et l. 170 ; `src/controle_ia/environnements/revalider_pilote_a.py:63` et `:260-265` ; préenregistrement scellé de la revalidation, l. 97.
- **Preuve** :
  - L. 20 : « (180 épisodes, formule gelée `duree_projetee_pilote` aux mesures scellées du bras retenu …) : `7 584,02` s ».
  - Le code a `EPISODES_PILOTE = 192` et `return (chrono["generation_s"] + chrono.get("passe_unique_s", 0.0)) * EPISODES_PILOTE / episodes`. Appelée sur les mesures scellées, la fonction rend 8 089,62 s.
  - Le texte gelé de R8 dit « × 192 / 16 épisodes ».
  - La valeur 7 584,02 s vient du générateur : `d = (chrono["generation_s"] + chrono["passe_unique_s"]) * TACHES_PILOTE * EPISODES_PAR_TACHE / 16`.
  - Un lecteur qui rejoue la fonction citée obtiendra 8 089,62 s.
  - Je ne juge pas N-019. Je signale seulement l'écart entre le nom cité et le code.
- **Action** : écrire « (génération + passes uniques) × 180 / 16 = 674,1351 × 11,25 = 7 584,02 s : la formule de R8, avec les 180 épisodes du pilote réduit (N-019) au lieu de 192 ; la fonction `duree_projetee_pilote` du code cité garde 192 ».

### TX-12 — information — Projection par lots : R8 tient aussi, avec une marge plus mince

- **Où** : l. 19-20, l. 170 ; `src/controle_ia/environnements/pilote_a.py:67-70` et `:105-106`.
- **Preuve** :
  - Le plan joue les épisodes tâche par tâche, en morceaux contigus de 8.
  - 180 épisodes font 22 lots de 8 et 1 lot de 4 ; la revalidation a mesuré 2 lots pleins, soit 337,07 s par lot.
  - Si le dernier lot coûte autant qu'un lot plein, la projection vaut 23 × 337,07 = 7 752,55 s. Elle reste sous 7 800 s, mais avec une marge de 47 s au lieu de 216 s. Pour 192 épisodes (24 lots), les deux calculs coïncidaient.
- **Action** : facultative. Une phrase dans « Calcul ».

### TX-13 — mineur — « Seuls les marqueurs de remplissage remplis » est inexact ; le titre de la version scellée dit « brouillon 8 »

- **Où** : l. 1, l. 3, l. 4, l. 16-27, l. 265.
- **Preuve** :
  - Le différentiel du brouillon 8 au candidat montre, outre les « À REMPLIR » :
    - l. 4, la parenthèse « (… N-014 et le verdict de la revalidation) » devient « (… N-014, le verdict de la revalidation et N-019) » ;
    - l. 16, « (chemin et sha256 complets au scellement) » devient « (chemin et sha256 complets) » ;
    - l. 17-27, les empreintes abrégées (« 9261932a… », « 6fe36296… », etc.) sont remplacées par chemins et empreintes complètes ;
    - l. 265, ajout de « par des sous-agents neufs : rapports ».
  - Toutes ces valeurs sont exactes (voir la question 4).
  - Titre l. 1 : « — v1 — brouillon 8 ». Les préenregistrements scellés de T0.4 v3 et de la revalidation v2 n'ont pas « brouillon » dans leur titre.
- **Action** : l. 3, « seuls les marqueurs de remplissage remplis et les empreintes abrégées complétées » ; titre, « — v1 ». Cette correction change le texte normalisé : nouveau candidat.

### TX-14 — mineur — 60 tâches : une simulation non annotée ; marge de la règle des 48 tâches non déclarée

- **Où** : l. 167-169 (l. 168), l. 66, l. 130.
- **Preuve** :
  - L. 168 : « sur 64 tâches, l'écart-type de la part du juge vaut de 0,10 à 0,12 », sans « (simulation ; 60 ici) », contrairement aux l. 133 et 135.
  - N-019, option (a), inconvénient : « la décomposition des juges exige 48 tâches complètes sur 60 (12 de marge au lieu de 16) ». Le préenregistrement ne le dit pas.
- **Action** : annoter la l. 168, et écrire la marge réduite dans la « Justification des tailles ».

### TX-15 — mineur — Citations incomplètes au sens de R6

- **Où** : l. 170 (658 s), l. 132.
- **Preuve** :
  - L'heure de création (22:46:03 UTC, `creation 1791758763`) vient de `traces/t05-revalidation-v2-20261011-2246/lancement.txt` (sha256 `4c04c48514435e02cb440b7cb1d2247398d4d2f25bc56f5f03552754364cf55a`). Ce fichier n'est pas cité (`grep -c lancement.txt` donne 0). Les deux traces citées ne donnent que la ligne AMORCE et le début du run.
  - L. 132 : « scripts `T0.5-pilote-contre-lecture-2-verifications-v1.tar` (29ac2d68…) », sans dossier. Le fichier est sous `prereg/contre-lectures/`, sha256 `29ac2d68d22647d32382b724fb3f9baf6069f6c138476a0a611edc348f04657f` (RC-06).
- **Action** : citer `lancement.txt` avec son empreinte ; écrire le chemin complet de l'archive.

### TX-16 — mineur — Deux renvois imprécis

- **Où** : l. 222, l. 264.
- **Preuve** :
  - L. 222 : « chargement hors ligne de ces juges après les épisodes ». Le code le place après l'appariement (`lancer_pilote_a.py:374-393`).
  - L. 264 ne cite que `1f53a08`. Or `197e909` (invite de l'étiqueteur, poussées en trois tentatives) traite aussi l'état des lieux (R-144).
- **Action** : « après l'appariement » ; ajouter `197e909`.

### TX-17 — mineur — Le modèle des étiqueteurs n'est ni épinglé ni consigné

- **Où** : l. 105 ; `src/controle_ia/environnements/lire_pilote.py` (aucune mention de modèle : `grep -n -i modele` ne trouve que le texte de la consigne).
- **Preuve** :
  - La l. 105 dit « modèle non épinglé par ce texte : limite déclarée ».
  - La critique de l'état des lieux (manques[18] : « Or il entre dans la mesure du kappa » ; corrections_au_plan[1] : « Épingler aussi l'identifiant du modèle étiqueteur dans le préenregistrement ») demandait plus.
  - Le kappa (P7, retenue des familles) dépend des étiquettes.
- **Action** : écrire que l'identifiant du modèle de chaque sous-agent étiqueteur est consigné par lot, dans une ligne du registre ou à côté des empreintes des lots, et donné au juge R13. Ou bien déclarer la non-adoption avec sa raison.

### TX-18 — information — Vérifications conformes

| objet | vérification | résultat |
|---|---|---|
| reproductibilité du candidat | générateur copié, rejoué (`python -I -B`) dans le clone au commit `3ffab9f`, mode « candidat », date « 2026-10-12 01:29 UTC », entropie 1, mêmes paires de rapports | `cmp` : texte et configuration identiques ; sortie du générateur : `prereg_sha256` `15a5cd3e…3150`, `d_s` 7584.02, `duree_max_s` 15000, tests 680, normalisé `fcfb1085…b124` |
| empreintes citées | 44 empreintes de 64 caractères contre les fichiers suivis (`empreintes-citees.txt`) | 42 égales au fichier désigné ; l'empreinte canonique, vérifiée à part, est exacte ; reste la paire factice `000…` de la relecture, attendue |
| configuration | empreinte canonique (`config_canonique`) ; brouillon 1 avec les deux champs remplis | `db3ad3ce…b714` dans les deux cas ; mêmes clés, mêmes valeurs ; table de la l. 155 conforme clé par clé |
| tâches | sceau ; égalité aux 60 premières de la source ; source sans remplacement | conformes ; présentes aux commits `3ffab9f` et `942c65e` |
| motifs lus par le code | `COMMIT_CITE`, `ENTROPIE_CITEE`, `CONFIG_CITEE`, `TACHES_CITEES`, chemins lus par `sed` dans le script | tous trouvés sur le candidat |
| tests attendus | `pytest --collect-only` dans les deux environnements ; aucune marque de saut | 680 et 680 |
| tests du pilote | `test_pilote_a.py`, `test_lire_pilote.py`, `test_prechargement.py` au commit cité | 102 réussis en 292,70 s |
| noms cités | tests et fonctions cités dans le texte | tous présents |
| valeurs du verdict | `mesures-defaut.json`, `lecture-defaut.json`, `resume.json` | 7 584,02 s ; 15 000 s ; 8 089,62 s ; RV-5 ; part 0,0 ; R1 0,1354 ; 79,44 Gio |
| traces de l'instance 55458787 | `journal-5min.txt`, `journal.txt`, `lancement.txt` | 22:46:48, 22:57:01, 613 s, 658 s, « 670 passed in 491.38s » |
| GO cités | `registres/go.md`, l. 16 et l. 19 | GO-2026-10-06-02 porte bien « reste de la phase 0 sur A100 80 Go avec la garde d'équivalence en ligne » |
| code de lecture | `git diff e6ce058 3ffab9f` sur `lire_pilote.py` et `analyse_pilote.py` | seule l'invite de l'étiqueteur change ; aucun seuil |

## Fichiers de travail

Sous `/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-pilote-b8/texte/` :
- `diff-b7-b8.txt` et `diff-b7-b8-mots.txt` : différentiels du brouillon 7 au brouillon 8 ;
- `empreintes-citees.txt` : contrôle des empreintes citées ;
- `etat-des-lieux-constats.txt` : extraits de l'état des lieux ;
- `gen/` : copies du générateur et du normaliseur, égales aux originaux ;
- `sortie/` : candidat et configuration régénérés, entropie 1.

Le clone a été supprimé. Le dépôt n'a pas bougé : `git status` est vide et la tête reste `942c65e`. Les empreintes de ces fichiers sont données dans la sortie structurée.

Scripts de la chaîne lus, avec leur empreinte au moment de la relecture :
- `remplir_pilote_v1.py` : `f3c90e82f488e23fe7f8fc01aef661b8c0208e785f8aa83de8e6e076944dd922` ;
- `normaliser_pilote_v1.py` : `0347237c84f00803f15d1acc58c00c8024753ebdfbb820da7f3bbb3613d0b1bf` ;
- `lancer_pilote_v1.sh` : `6928e18354c1f0a5fa261b278e5013782bf786229a9d623684b5742af57c1e10`. Ce script a été modifié vers 01:36 UTC, pendant la relecture ; ses lignes 59, 101 et 110 ont été relues après cette modification.
