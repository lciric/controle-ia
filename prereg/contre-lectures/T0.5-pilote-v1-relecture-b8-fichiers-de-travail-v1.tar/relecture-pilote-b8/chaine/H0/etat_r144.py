"""Met à jour registres/etat.md après R-142 à R-144 (ligne de mise à jour, T0.5, nœuds, dépenses, instances).
Usage : etat_r144.py DEPOT HEURE_UTC(HH:MM) CREDIT HEURE_CREDIT"""
import sys
from pathlib import Path

D, HEURE, CREDIT, HEURE_CREDIT = Path(sys.argv[1]), sys.argv[2], sys.argv[3], sys.argv[4]
p = D / "registres" / "etat.md"
t = p.read_text(encoding="utf-8")
lignes = t.split("\n")

# 1. ligne de mise à jour
i = [k for k, x in enumerate(lignes) if x.startswith("Dernière mise à jour : ")]
assert len(i) == 1 and "2026-10-11 22:50 UTC" in lignes[i[0]]
lignes[i[0]] = (f"Dernière mise à jour : 2026-10-12 {HEURE} UTC, session 12, sous la délégation R-140 (jusqu'au 2026-10-12 "
                "10:40 UTC) : revalidation v2 finie, récupérée, fusionnée ; verdict R13 : nœud (R-142) ; N-019 tranché, "
                "option (a), sous la délégation (R-143) ; pilote : état des lieux, code et chaîne de lancement (R-144). "
                "Mise à jour précédente : 2026-10-11 22:50 UTC.")

# 2. ligne de T0.5 : la cellule « état » est réécrite, la note est gardée
i = [k for k, x in enumerate(lignes) if x.startswith("| T0.5 environnement (a) v0 | ")]
assert len(i) == 1
cellules = lignes[i[0]].split(" | ")
assert cellules[2] == "processeur puis GPU sur GO", cellules[2][:80]
cellules[1] = ("**revalidation v2 faite** (run `20261011-225701-t05-revalidation-reel`, instance 55458787, 1,06 h ; récupérée, "
               "fusionnée `ba0004d`) ; **verdict R13 : nœud** (bras « defaut » conforme sur toute l'équivalence sauf R8 : "
               "8 089,62 s pour 7 800 s ; bras « math » en panne de mémoire ; `docs/verdicts/verdict-T0.5-revalidation-v2.md` ; "
               "R-142) ; **N-019 tranché, option (a)**, sous la délégation (R-143) : pilote sur les 60 premières tâches "
               "d'évaluation (180 épisodes ; 7 584,02 s ≤ 7 800 s ; noyau « defaut » ; `duree_max_s` 15 000 s) ; **pilote en "
               "préparation** (R-144) : état des lieux par lecteurs neufs, code (appariement avant les juges, juges préchargés "
               "puis chargés hors ligne, invite de l'étiqueteur, poussées en trois tentatives), chaîne "
               "`docs/procedures/pilote-T0.5-v1/`, brouillon 8 ; reste : candidat rempli, relecture R2, répétitions, scellement, "
               "lancement à la recharge du crédit. Avant : revalidation v1 arrêtée avant le run (test sensible au processeur, "
               "R-132) ; N-018 (a) ; v2 scellée et lancée (R-141). **Extraction faite** (2026-10-10, R-124) : 96 papiers sur "
               "96 ; environnement (a) v0 assemblé : 64 tâches d'évaluation, 32 d'entraînement, aucun remplacement ni exclusion "
               "(`diag/20261007-082440-t05-extraction/bilan-extraction.json`)")
lignes[i[0]] = " | ".join(cellules)

t = "\n".join(lignes)

# 3. nœuds
ancre = "## GO et nœuds en attente\n"
assert t.count(ancre) == 1
t = t.replace(ancre, ancre + "- **N-019 tranché le 2026-10-12** sous la délégation R-140 (option (a) ; R-143 ; "
              "`docs/decisions/decision-N-019-v1.md`) : pilote réduit aux 60 premières tâches, noyau « defaut », "
              "`duree_max_s` 15 000 s ; soumis à Lazar, révocable par lui ; la relecture R2 du pilote pose la question de la "
              "lecture gelée.\n")
ancien = "- **N-018 : GO le 2026-10-11** vers 22:26 UTC (GO-2026-10-11-01, option (a) ; R-139) : version 2 de la revalidation de T0.5 à sceller puis lancer selon le plan v7."
assert t.count(ancien) == 1
t = t.replace(ancien, "- **N-018 : GO le 2026-10-11** vers 22:26 UTC (GO-2026-10-11-01, option (a) ; R-139) : version 2 de la "
              "revalidation de T0.5 scellée et lancée (R-141), finie, verdict R13 : nœud (R-142).")

# 4. dépenses
ancre = "## Dépenses\n"
assert t.count(ancre) == 1
t = t.replace(ancre, ancre + f"Au 2026-10-12 {HEURE_CREDIT} UTC : cumul de la phase 0 au plus ≈ 41,1 USD sur 150 (revalidation "
              f"v2 : ≈ 1,14 USD de marche, R-142) ; crédit Vast.ai lu à {CREDIT} USD, en baisse d'environ 0,05 USD de l'heure "
              "(disques des instances arrêtées 55292763 et 55458787). Pilote : crédit exigé par le lanceur ≥ 6 h × prix + "
              "1,2 USD (7,68 USD à 1,08 USD de l'heure) : **recharge demandée à Lazar** (R-143).\n\n")

# 5. instances
ancre = "## Instances de calcul actives\n"
assert t.count(ancre) == 1
t = t.replace(ancre, ancre + f"Au 2026-10-12 {HEURE_CREDIT} UTC (forme filtrée) : **aucune instance en marche** ; 55292763 et "
              "55458787 arrêtées (« exited », « stopped »), disques facturés jusqu'à leur destruction, proposée à Lazar.\n\n")
p.write_text(t, encoding="utf-8")
print("etat.md mis à jour")
