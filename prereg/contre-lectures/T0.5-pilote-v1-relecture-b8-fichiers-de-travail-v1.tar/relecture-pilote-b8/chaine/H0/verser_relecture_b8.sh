#!/usr/bin/env bash
# Verse les rapports de la relecture R2 du brouillon 8 du pilote : résultats du workflow (JSON) et fichiers de travail
# des relecteurs (archive tar déterministe, sans clone ni dépôt nu, sans fiche de la revalidation), après recherche des
# jetons (aucune valeur affichée). N'écrase rien (R12). Usage : verser_relecture_b8.sh RESULTATS.json DOSSIER_TRAVAIL
set -euo pipefail
R=$1; W=$2
BN=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad
D=/home/user/controle-ia-travail
C=$D/prereg/contre-lectures
J=$C/T0.5-pilote-v1-relecture-b8-resultats-v1.json
T=$C/T0.5-pilote-v1-relecture-b8-fichiers-de-travail-v1.tar
for f in "$J" "$T"; do [ -e "$f" ] && { echo "$f existe déjà (R12)"; exit 2; }; done
python3 -c "import json, sys; json.load(open(sys.argv[1]))" "$R"
# clones, dépôts nus et environnements exclus ; aucune fiche de la revalidation (D-20)
LISTE=$(mktemp)
(cd "$(dirname "$W")" && find "$(basename "$W")" -type f \
    -not -path '*/clone/*' -not -path '*/clone-*/*' -not -path '*/.git/*' -not -path '*.git/*' -not -path '*/distant*/*' \
    -not -path '*/__pycache__/*' -not -path '*/tmp-*/*' | sort) > "$LISTE"
if grep -E 'episodes-defaut\.json|chemin-defaut\.json' "$LISTE"; then echo "fiche de la revalidation dans l'archive (D-20)"; exit 2; fi
echo "fichiers archivés : $(wc -l < "$LISTE")"
(cd "$(dirname "$W")" && tar --sort=name --mtime='2026-10-12 00:00:00Z' --owner=0 --group=0 --numeric-owner \
    -cf "$BN/relecture-b8.tar" -T "$LISTE")
TAILLE=$(stat -c %s "$BN/relecture-b8.tar"); echo "archive : $TAILLE octets"
[ "$TAILLE" -le 50000000 ] || { echo "archive de plus de 50 Mo : un clone a échappé au filtre ?"; exit 2; }
python3 -I "$BN/outils/scanner_jetons.py" "$R" "$BN/relecture-b8.tar"
cp "$R" "$J"; cp "$BN/relecture-b8.tar" "$T"; rm -f "$BN/relecture-b8.tar" "$LISTE"
cd "$D" && PYTHONPATH=src /home/user/controle-ia/.venv/bin/python -m controle_ia.scellement sceller \
    "prereg/contre-lectures/$(basename "$J")" "prereg/contre-lectures/$(basename "$T")"
