"""Écrit R-142, R-143, R-144 et la ligne N-019 dans registres/decisions.md, la ligne de synthèse de registres/arrets.md.
Échoue si une ancre manque ou si une ligne existe déjà (R12 : on n'écrase rien)."""
import sys
from pathlib import Path

D = Path(sys.argv[1])
dec = D / "registres" / "decisions.md"
t = dec.read_text(encoding="utf-8")
for x in ("| R-142 |", "| R-143 |", "| R-144 |", "| N-019 |"):
    assert x not in t, f"{x} existe déjà"

R142 = ("| R-142 | 2026-10-12 | **Revalidation de T0.5, version 2 : run fini, récupéré, fusionné ; verdict R13 : nœud.** "
        "Instance 55458787 : fin de l'amorce le 2026-10-11 à 23:44:12 UTC, code 0 (sur l'instance, « 670 passed in 491.38s » ; "
        "run `20261011-225701-t05-revalidation-reel`) ; arrêtée par son identifiant à 23:49:30 UTC, relue « stopped » "
        "(`registres/arrets.md`) ; 1,06 heure, ≈ 1,14 USD de marche (`registres/depenses.md`). Récupération "
        "(`docs/procedures/revalidation-T0.5-v2/recuperation_revalidation_v2.sh`, commit S `8f74ada`) : tous conformes "
        "(`traces/t05-revalidation-v2-20261011-2246/recuperation.txt`, scellé) ; fusion de la branche "
        "`calcul/t05-revalidation-reel-v2` (tête `5b42860`) dans `main` : `ba0004d`. Verdict prononcé par un sous-agent neuf "
        "(R13), contre-vérifié par deux sceptiques neufs (95 et 72 constats recalculés depuis les résultats scellés, 0 écart, "
        "non réfuté), corrections mineures intégrées par un quatrième sous-agent neuf : "
        "`docs/verdicts/verdict-T0.5-revalidation-v2.md` (`f98b5684…`), fichiers de travail "
        "`docs/verdicts/verdict-T0.5-revalidation-v2-fichiers-de-travail.tar` (`f51751c5…`). **Nœud** : aucun noyau retenu. "
        "Bras « defaut » conforme sur toute l'équivalence (R1 : 99e centile maximal 0,1354 ≤ 0,15 ; contrôle négatif 160 sur "
        "160 ; mémoire 24,02 Gio ; audit, ρ ≤ 1,55), sauf R8 : durée projetée des épisodes du pilote 8 089,62 s pour un "
        "plafond gelé de 7 800 s ; bras « math » : panne de mémoire, non conforme. Aucune des deux propositions prêtes du "
        "texte gelé ne s'applique. Aucun champ de texte des fiches ouvert par l'auteur, les sceptiques ni le correcteur "
        "(en-tête du verdict ; D-20). Nœud tranché sous la délégation : N-019 (R-143). | Préenregistrement v2 "
        "(`4ff2b075…`) ; R13 ; plan de lancement v7. |")

R143 = ("| R-143 | 2026-10-12 | **N-019 tranché sous la délégation R-140 : option (a)** — décision "
        "`docs/decisions/decision-N-019-v1.md` (`9058fa27…`), confiance ≈ 70 %. Le pilote porte sur les **60 premières "
        "tâches d'évaluation dans l'ordre du tirage** (180 épisodes), recopiées à l'identique de "
        "`donnees/20261007-082440-t05-extraction/taches-evaluation.json` (`76cdeace…`, aucun remplacement) dans "
        "`donnees/t05-pilote-v1/taches-pilote-60-v1.json` (`287e8348…`, scellé, ajouté de force au suivi comme les "
        "sorties de l'extraction, N-014). R8 appliquée telle quelle à ce pilote : (665,8512 + 8,2839) × 180 / 16 = "
        "**7 584,02 s ≤ 7 800 s** ; noyau « defaut » ; `duree_max_s` par la formule gelée = **15 000 s**. Rien d'autre ne "
        "change : verdict scellé, R8, formule, seuils, prédictions, critères de lecture, code de lecture. Options écartées : "
        "(b) 64 tâches à deux épisodes (change une hypothèse du code de lecture), (c) nouvelle revalidation (vise une "
        "équivalence déjà établie ; crédit insuffisant), (d) relâcher R8 (écart à un préenregistrement scellé, hors de la "
        "délégation). Révocable par Lazar ; le verdict renvoyait la résolution du nœud à Lazar : la décision lui est "
        "soumise avec la demande de recharge, et le lancement attend de toute façon cette recharge (crédit Vast.ai lu à "
        "7,37 USD le 2026-10-12 vers 00:05 UTC, en baisse d'environ 0,05 USD de l'heure par les disques des instances "
        "arrêtées 55292763 et 55458787 ; règle du lanceur : crédit ≥ 6 h × prix + 1,2 USD, soit 7,68 USD à 1,08 USD de "
        "l'heure). Contrôle : la relecture R2 du préenregistrement du pilote pose la question « la réduction à 60 tâches "
        "change-t-elle une lecture gelée de la revalidation ? » ; une réponse fondée « oui » ramène le nœud à Lazar avant "
        "tout lancement. | Délégation R-140 ; verdict R13 (R-142) ; hiérarchie de décision de `CLAUDE.md`. |")

R144 = ("| R-144 | 2026-10-12 | **Pilote de T0.5 : état des lieux, code et chaîne de lancement** (routine, sous la "
        "délégation R-140 : pistes fragiles éliminées). État des lieux par cinq lecteurs neufs (texte et configuration, "
        "script de l'instance, leçons de la revalidation, dépendances au verdict, historique des relectures), une synthèse "
        "et une critique de complétude, sous-agents neufs : 124 constats (4 bloquants, 40 majeurs, 45 mineurs, 35 pour "
        "information), 17 pistes fragiles, 20 manques ; rapports `prereg/contre-lectures/T0.5-pilote-v1-etat-des-lieux-"
        "resultats-v1.json` et `…-fichiers-de-travail-v1.tar` (scellés ; le clone de lecture qui portait les fiches de la "
        "revalidation est exclu de l'archive et supprimé). Code (`1f53a08`, puis ce commit) : appariement avant les "
        "notations des juges (SI-01 : les familles, critère 2 de G0, ne dépendent plus de la durée des juges) ; poids du "
        "juge 3B téléchargés avant les épisodes et juges chargés hors ligne (SI-02 : plus de téléchargement après des "
        "heures de calcul) ; invite de l'étiqueteur réécrite sans formule de préséance sur les consignes (refusée par le "
        "classificateur de la session ; essai jouet conforme) ; poussées de fin de run et des vecteurs en trois tentatives "
        "à attente croissante, chaque refus journalisé. Chaîne du pilote sur le modèle de la v7 de la revalidation "
        "(`docs/procedures/pilote-T0.5-v1/`) : dérivation des tâches, générateur du texte (valeurs recalculées depuis les "
        "résultats scellés, aucun report à la main), normaliseur, contrôles avant dépense (suite complète au commit S, vrais "
        "tokeniseurs 8B et 3B), lanceur (processeur de l'offre limité à celui de la revalidation, AMD EPYC 7513 ; crédit "
        "≥ 6 h × prix + 1,2 USD ; fenêtre 23:30-00:00 UTC refusée ; base de la surveillance création − 3 900 s), "
        "scellement, récupération (branche des vecteurs), répétition jouet ; plan de lancement v1 (remplace la procédure "
        "brouillon 4). Brouillon 8 du préenregistrement (60 tâches, N-019 ; nouvel ordre des étapes ; risques de temps et "
        "de mémoire des juges déclarés). Suite : candidat rempli, relecture R2 par des sous-agents neufs, répétitions, "
        "scellement ; lancement à la recharge du crédit. | R2 ; R5 ; R12 ; délégation R-140. |")

ancre = "\n\n## Propositions avec recommandation (défaut sous 48 heures)"
assert t.count(ancre) == 1 and "| R-141 |" in t.split(ancre)[0].rsplit("\n", 1)[-1]
t = t.replace(ancre, "\n" + R142 + "\n" + R143 + "\n" + R144 + ancre)

N019 = ("| N-019 | 2026-10-12 | Revalidation de T0.5, v2 : **nœud** (verdict R13, R-142). Bras « defaut » conforme sur toute "
        "l'équivalence, sauf R8 : durée projetée des épisodes du pilote de 192 épisodes 8 089,62 s pour 7 800 s ; bras « math » "
        "en panne de mémoire ; aucune proposition prête. Options (décision `docs/decisions/decision-N-019-v1.md`) : (a) pilote "
        "réduit aux 60 premières tâches dans l'ordre du tirage (180 épisodes, 7 584,02 s) ; (b) 64 tâches à deux épisodes ; "
        "(c) nouvelle revalidation (autre lot ou autre carte) ; (d) relâcher R8 ou le plafond. | tranché le 2026-10-12 sous la "
        "délégation R-140 : option (a), `docs/decisions/decision-N-019-v1.md` (`9058fa27…`) ; noyau « defaut », "
        "`duree_max_s` 15 000 s ; soumis à Lazar, révocable par lui (R-143) |")
lignes = t.split("\n")
i = [k for k, x in enumerate(lignes) if x.startswith("| N-018 |")]
assert len(i) == 1
lignes.insert(i[0] + 1, N019)
t = "\n".join(lignes)
# garde du lanceur : aucune ligne R- ne doit contenir à la fois « révoque » et « N-019 »
assert not any("révoque" in x and "N-019" in x for x in t.split("\n") if x.startswith("| R-")), "faux « révoqué »"
n19 = [x for x in t.split("\n") if x.startswith("| N-019 |")]
assert len(n19) == 1 and "tranché" in n19[0].rsplit("|", 2)[-2] and "(a)" in n19[0].rsplit("|", 2)[-2]
dec.write_text(t, encoding="utf-8")

arr = D / "registres" / "arrets.md"
a = arr.read_text(encoding="utf-8")
ancien = ("Instances de calcul : 54183350 (arrêtée le 2026-10-04 à 18:12 UTC), 54285455 (arrêtée le 2026-10-05 à 08:31 UTC), "
          "54298522 (arrêtée le 2026-10-05 à 10:31 UTC), 54311651 (arrêtée le 2026-10-05 à 12:14 UTC), 54332340 (arrêtée le "
          "2026-10-05 à 14:55 UTC) et 54476244 (arrêtée le 2026-10-06 à 12:11 UTC), toutes par leur identifiant ; aucune autre.")
assert a.count(ancien) == 1
nouveau = ("Instances de calcul arrêtées par la session, toutes par leur identifiant : 54183350 (2026-10-04 18:12 UTC), "
           "54285455 (2026-10-05 08:31), 54298522 (2026-10-05 10:31), 54311651 (2026-10-05 12:14), 54332340 (2026-10-05 "
           "14:55), 54476244 (2026-10-06 12:11) — ces six n'existent plus sur le compte depuis le 2026-10-10 (R-125) — ; "
           "55292763 (2026-10-10 22:39 UTC) et 55458787 (2026-10-11 23:49 UTC), arrêtées, disques facturés jusqu'à leur "
           "destruction (proposée à Lazar). Aucune autre.")
arr.write_text(a.replace(ancien, nouveau), encoding="utf-8")
print("registres écrits : R-142, R-143, R-144, N-019, synthèse des arrêts")
