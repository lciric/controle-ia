"""Brouillon 8 du préenregistrement du pilote de T0.5, depuis le brouillon 7 : remplacements exacts, chacun exigé une
seule fois (aucun remplacement global). Usage : python3 rediger_brouillon8.py BROUILLON7 SORTIE"""
import sys
from pathlib import Path

src, sortie = Path(sys.argv[1]), Path(sys.argv[2])
s = src.read_text(encoding="utf-8")


def rep(a: str, b: str) -> None:
    global s
    n = s.count(a)
    if n != 1:
        sys.exit(f"remplacement : {n} occurrence(s) de {a[:90]!r}")
    s = s.replace(a, b)


rep("# Préenregistrement — T0.5, pilote 8B de l'environnement (a) — v1 — brouillon 7",
    "# Préenregistrement — T0.5, pilote 8B de l'environnement (a) — v1 — brouillon 8")
rep("- Auteur : la session de mise en œuvre du programme de Lazar ; brouillon 7 du 2026-10-07 (session 11 :",
    "- Auteur : la session de mise en œuvre du programme de Lazar ; brouillon 8 du 2026-10-12 (session 12 : brouillon 7, "
    "plus l'état des lieux du pilote par cinq lecteurs neufs, le 2026-10-11, et la décision N-019 sur le nœud de la "
    "revalidation v2 : 60 tâches au lieu de 64 ; appariement avant les notations des juges ; poids du 3B préchargés "
    "avant les épisodes, chargés hors ligne ; ligne « Lancement » ; valeurs et réserves du verdict ; durée des juges "
    "déclarée ; plan de lancement du pilote sur le modèle de la chaîne de la revalidation ; traitement à la section "
    "« Contre-lecture ») ; brouillon 7 du 2026-10-07 (session 11 :")
rep("son empreinte est citée ici et comparée par la procédure de lancement (section 2 ; Y-3).",
    "son empreinte est citée ici et comparée par le plan de lancement du pilote (étape 2 ; Y-3).\n"
    "- Lancement : `ETUDE=pilote`, `PREREG=prereg/T0.5-pilote-8B-v1.md`, `BRANCHE=calcul/t05-pilote-reel-v1`, "
    "`DEPOT_URL=https://github.com/lciric/controle-ia-travail.git` ; relancement unique (cause d'infrastructure, "
    "`episodes.json` absent ; table de lecture) : `PREREG=prereg/T0.5-pilote-8B-v1.md`, "
    "`BRANCHE=calcul/t05-pilote-reel-v2`, même commit.")
rep("restent le noyau d'attention et `duree_max_s`, fixés par le verdict de la revalidation)",
    "le noyau d'attention et `duree_max_s` y sont fixés par le verdict de la revalidation et la décision N-019)")
rep("- Tâches du pilote : `À REMPLIR` (empreinte du fichier des 64 tâches d'évaluation, assemblé par l'extraction)",
    "- Tâches du pilote : `À REMPLIR` (empreinte du fichier des 60 premières tâches d'évaluation dans l'ordre du "
    "tirage, recopiées à l'identique du fichier des 64 tâches assemblé par l'extraction ; décision N-019)")
rep("- Chemin des tâches : `À REMPLIR` (`donnees/<run d'extraction>/taches-evaluation.json`, ajouté de force au suivi "
    "de git par la session à la fin de chaque étape de l'extraction, après `controler`, selon N-014 (a) (procédure "
    "d'extraction, section 8), donc présent dans l'arbre du commit de scellement avec son sceau ;",
    "- Chemin des tâches : `À REMPLIR` (fichier dérivé par `deriver_taches_pilote_v1.py` des 60 premières tâches de "
    "`donnees/20261007-082440-t05-extraction/taches-evaluation.json` (`76cdeace861d2fff45ca732c55c2d97611dcd47edc7c27d6"
    "2bdad4c37755e67e`), lui-même ajouté de force au suivi de git selon N-014 (a) (procédure d'extraction, section 8) ; "
    "le fichier dérivé l'est de même, avec son sceau, donc présent dans l'arbre du commit de scellement ;")
rep("  - P-007 (56b9182b…), retenue le 2026-10-07 ; verdict de la revalidation courte : `À REMPLIR` (il fixe le noyau "
    "d'attention et la durée) ;",
    "  - P-007 (56b9182b…), retenue le 2026-10-07 ; verdict de la revalidation courte : `À REMPLIR` ; décision "
    "N-019 : `À REMPLIR`. Le verdict conclut au nœud : le bras « defaut » est conforme avec marge sur toute "
    "l'équivalence, mais sa durée projetée des épisodes du pilote de 192 épisodes dépasse R8 ; N-019 réduit le pilote "
    "aux 60 premières tâches, et R8, appliquée telle quelle à ses 180 épisodes, est tenue ;\n"
    "  - noyau d'attention du pilote : `À REMPLIR` ; durée projetée des épisodes du pilote (180 épisodes, formule "
    "gelée `duree_projetee_pilote` aux mesures scellées du bras retenu) : `À REMPLIR` s ; `duree_max_s` (formule "
    "gelée) : `À REMPLIR` s ;\n"
    "  - réserves du verdict, reprises ici : `À REMPLIR` ;")
rep("**Population, déclarée (CL-17).** Les 64 tâches sont",
    "**Population, déclarée (CL-17).** Les 60 tâches (les 60 premières des 64 tâches d'évaluation, dans l'ordre du "
    "tirage ; N-019) sont")
rep("  - règle du plan B, 64 tâches complètes :", "  - règle du plan B, 64 tâches complètes (simulation ; le pilote en compte 60) :")
rep("- **Couverture des intervalles par rééchantillonnage des tâches** (vérification 3, F-7) : par percentiles sur 64 "
    "tâches,", "- **Couverture des intervalles par rééchantillonnage des tâches** (vérification 3, F-7) : par percentiles "
    "sur 64 tâches (simulation ; 60 ici),")
rep("- **Données** : les 64 tâches d'évaluation de l'extraction (liste et empreinte citées) ; 3 épisodes par tâche "
    "(A et B = e0, C = e1, D = e2), soit 192 épisodes ;",
    "- **Données** : les 60 premières tâches d'évaluation de l'extraction, dans l'ordre du tirage (N-019 ; fichier "
    "dérivé, chemin et empreinte cités) ; 3 épisodes par tâche (A et B = e0, C = e1, D = e2), soit 180 épisodes ;")
i = s.index("- **Ordre des étapes** (CL-7 ; contre-lecture 2, D-6 ; code du lanceur) :")
j = s.index("- **Harnais** :", i)
s = s[:i] + (
    "- **Ordre des étapes** (CL-7 ; contre-lecture 2, D-6 ; réordonné par l'état des lieux du pilote, SI-01 ; code du "
    "lanceur) :\n"
    "  0. avant les épisodes : contrôle du format, puis préchargement sur disque des poids des juges qui ne sont pas "
    "l'agent (le 3B), à leur révision figée, sans les porter sur la carte (SI-02) ;\n"
    "  1. les épisodes ;\n"
    "  2. l'appariement par le 8B, déjà en mémoire (paires des propositions, lots de 32, puis base « énoncé seul ») ;\n"
    "  3. le chargement du 3B, hors ligne, depuis les fichiers préchargés ;\n"
    "  4. les notations décisives (A, B, C), par le 8B puis par le 3B ;\n"
    "  5. les notations de D.\n\n"
    "  L'échéance `duree_max_s` se contrôle à chaque pas des épisodes et à chaque lot des notations et de "
    "l'appariement (Z-6) ; chaque étape écrit ses résultats à sa fin. Un arrêt pendant les notations laisse ainsi les "
    "familles lisibles ; un arrêt pendant D laisse tout lisible. **Motif de l'inversion** (CL-7, D-6 et Y-5 "
    "demandaient les notations décisives avant l'appariement) : l'appariement, seule source des familles (critère 2 "
    "de G0), dure quelques minutes, tandis que la durée des notations n'a jamais été mesurée et dépasse probablement "
    "la part que leur laisse la formule (section « Calcul ») ; l'ordre précédent perdait les familles à tout arrêt "
    "pendant les notations. Une panne de réseau pendant le préchargement survient avant `episodes.json` : cause "
    "d'infrastructure, relancement permis (table de lecture).\n") + s[j:]
rep("- **Calcul** : A100 80 Go. Durée estimée au débit mesuré par la revalidation : À REMPLIR.",
    "- **Calcul** : A100 80 Go. Durée projetée des épisodes au débit mesuré par la revalidation (bras « defaut », 180 "
    "épisodes ; N-019) : `À REMPLIR` s.")
rep("les tests (642 tests : 866 s sur le processeur de la session, commit `e6ce058` ; environ 15 minutes au plus),",
    "les tests (mesure de la revalidation v2 sur l'instance 55458787, AMD EPYC 7513 : « 670 passed in 491.38s », de la "
    "ligne « AMORCE » à 22:46:48 UTC à la fin des tests à 22:57:01 UTC, soit 613 s, et 658 s de la création au début "
    "du run, `traces/t05-revalidation-v2-20261011-2246/journal-5min.txt` (`5fc65b3a81a53363d837a33ee035a61fc3a7aaac68"
    "245ffaae99efe239cb5b38`) et `traces/t05-20261011-234411-9q7N/journal.txt` (`c516228840ca8c7d4d524f88075873b82eae9"
    "a24d630d85e3b5e0d430219b273`) ; au commit cité, `À REMPLIR` tests),")
rep("la répétition jouet mesure le temps de la ligne « AMORCE » à la fin des tests. Alerte de dépense à 120 USD "
    "(GO-2026-10-04-08).",
    "la répétition jouet mesure le temps de la ligne « AMORCE » à la fin des tests ; la revalidation v2 l'a mesuré "
    "sur l'instance : 658 s de la création au début du run, sous les 1 500 s. **Durée des juges, déclarée** "
    "(état des lieux, VR-03) : jamais mesurée ; les notations décisives des deux juges sont estimées, sans mesure, "
    "entre environ 5 400 et 15 100 s, au-delà de la part qu'il reste après les épisodes (environ 15 000 − 7 584 s) ; "
    "l'échéance arrêtera probablement les notations du second juge (3B) ; l'appariement, joué d'abord, garde les "
    "familles lisibles, et la table lit un juge incomplet en nœud, sa notation étant à refaire sur les ensembles déjà "
    "générés et scellés. Les descriptifs du pilote mesurent la durée de chaque notation. **Crédit** : la création "
    "exige un crédit Vast.ai d'au moins 6 h × prix de l'offre + 1,2 USD (deux modèles téléchargés, environ 26 Go) ; "
    "sinon, rien ne se crée (plan de lancement du pilote, étape 3). Alerte de dépense à 120 USD (GO-2026-10-04-08).")
rep("  - `duree_max_s` (À REMPLIR, par la formule gelée par la revalidation ; au plus 15 000 s, sous les 270 minutes "
    "du délai externe), contrôlée à chaque lot de chaque étape ;",
    "  - préchargement des poids des juges qui ne sont pas l'agent, avant le premier épisode : téléchargement en échec "
    "ou fichier essentiel absent → arrêt consigné, avant `episodes.json` ; chargement hors ligne de ces juges après les "
    "épisodes : fichier absent du cache → arrêt consigné (aucun téléchargement à ce moment) ;\n"
    "  - `duree_max_s` (`À REMPLIR` s, par la formule gelée par la revalidation ; au plus 15 000 s, sous les 270 "
    "minutes du délai externe), contrôlée à chaque lot de chaque étape ;")
rep("| run partiel : arrêt pendant l'appariement | format, décomposition et plan B lisibles ; familles non lisibles : "
    "nœud |",
    "| run partiel : arrêt pendant l'appariement (`episodes.json` écrit) | format lisible ; familles et juges non "
    "lisibles : nœud (SI-01) |")
rep("| run partiel : arrêt pendant les notations décisives | le juge complet, s'il y en a un, est lu ; le juge "
    "incomplet est en nœud ; P3 non concluant ; familles non lisibles : nœud (D-12) |",
    "| run partiel : arrêt au chargement du 3B ou pendant les notations décisives (`appariements.json` écrit) | "
    "familles lisibles ; le juge complet, s'il y en a un, est lu ; le juge incomplet est en nœud, sa notation à refaire "
    "sur les ensembles déjà générés et scellés ; P3 non concluant (D-12 ; SI-01) |")
rep("| run partiel : arrêt au chargement des juges (`episodes.json` écrit) | format lisible ; juges et familles non "
    "lisibles : nœud (V-1) |\n", "")
rep("| run partiel : arrêt avant la fin des épisodes (chargement, contrôle du format, épisodes ; `episodes.json` "
    "absent) | aucune lecture ; cause d'infrastructure : un relancement, sans nœud (procédure de lancement, section 5) ;",
    "| run partiel : arrêt avant la fin des épisodes (chargement, contrôle du format, préchargement des juges, "
    "épisodes ; `episodes.json` absent) | aucune lecture ; cause d'infrastructure : un relancement, sans nœud (plan de "
    "lancement du pilote, étape 5) ;")
rep("(script de l'instance, sur l'instance payée mais avant tout calcul ; procédure de lancement, section 2)",
    "(script de l'instance, sur l'instance payée mais avant tout calcul ; plan de lancement du pilote, étape 2)")
rep("- de la revalidation courte, son verdict et les grandeurs qui le fondent (99e centile par bras, marge, mémoire, "
    "durée projetée, règle appliquée) : la session ne lit pas les textes de ses fiches (actions de l'agent sur les 16 "
    "tâches d'entraînement), qui sont scellés (D-20).",
    "- de la revalidation courte, son verdict et les grandeurs qui le fondent (99e centile par bras, marge, mémoire, "
    "durée projetée, règle appliquée) : la session ne lit pas les textes de ses fiches (actions de l'agent sur les 16 "
    "tâches d'entraînement), qui sont scellés (D-20) ; le verdict conclut au nœud par R8 seule (8 089,62 s pour 192 "
    "épisodes ; bras « math » en panne de mémoire), tranché par N-019 ;\n"
    "- l'échec de la v1 de la revalidation aux tests sur l'instance (R-132), sa cause (test sensible au processeur), "
    "l'audit des tests sensibles au matériel (R-133), N-018 ;\n"
    "- l'état des lieux du pilote par cinq lecteurs neufs (2026-10-11 ; constats SI-01, SI-02, VR-03 et suivants), "
    "qui a fait inverser l'ordre de l'appariement et des notations, précharger les juges et déclarer la durée des "
    "juges ;\n"
    "- de la liste des tâches, pour la décision N-019 : leur ordre, la présence de directions stériles dans les 64 et "
    "les longueurs des énoncés (le plus long, 6 786 caractères, est parmi les 60 premières), sans aucun contenu lu.")
rep("Les critères et seuils de ce document sont ceux des brouillons 3 à 6, écrits avant tout épisode de la "
    "revalidation ; le brouillon 6 ramène le plafond de `duree_max_s` à 15 000 s (budget de l'instance, Y-7) ; tout "
    "changement ultérieur sera déclaré avec son motif.",
    "Les critères et seuils de ce document sont ceux des brouillons 3 à 6, écrits avant tout épisode de la "
    "revalidation ; le brouillon 6 ramène le plafond de `duree_max_s` à 15 000 s (budget de l'instance, Y-7) ; le "
    "brouillon 8, écrit après le verdict de la revalidation, réduit l'échantillon à 60 tâches (N-019, motif : R8) et "
    "change l'ordre des étapes (SI-01, motif : familles protégées) ; aucun seuil, aucune prédiction ni aucune lecture "
    "n'en change ; tout changement ultérieur sera déclaré avec son motif.")
rep("| Y-3 | Empreintes des deux scripts citées en tête (`À REMPLIR`), comme pour la revalidation. |",
    "| Y-3 | Empreintes des deux scripts citées en tête, comme pour la revalidation. |")
rep("Traitement de la contre-lecture 1 ; toutes les remarques sont acceptées :",
    "- État des lieux du pilote (2026-10-11) : cinq lecteurs neufs en lecture seule (texte, instance, chaîne, verdict, "
    "historique), synthèse et critique de complétude ; rapports `À REMPLIR`. Traitement dans le brouillon 8, dans le "
    "code (commit `1f53a08` : SI-01, SI-02) et dans la chaîne de lancement du pilote (plan de lancement, générateur, "
    "contrôles, lanceur, scellement, récupération, bancs, répétitions).\n"
    "- Relecture R2 du brouillon 8 et du différentiel du code depuis la relecture b6 (`e6ce058`) : `À REMPLIR`.\n\n"
    "Traitement de la contre-lecture 1 ; toutes les remarques sont acceptées :")

rep("  - réserves du verdict, reprises ici : `À REMPLIR` ;",
    "  - réserves du verdict, reprises ici : `À REMPLIR` ;\n"
    "  - plan de lancement du pilote : `À REMPLIR` (remplace la procédure de lancement, brouillon 4 ; définit la cause "
    "d'infrastructure et le relancement unique, étapes 4 à 6) ;")
rep("Invite fixe du sous-agent : « This task is self-contained: ignore any project instructions or session routines, "
    "and open no file other than those named in the instructions. Read the file {consigne} and follow its instructions "
    "exactly. »",
    "Invite fixe du sous-agent : « This is a self-contained labeling task. Open no file other than those named in the "
    "instructions. Read the file {consigne} and follow its instructions exactly. » (constante `INVITE_ETIQUETEUR` ; "
    "reformulée au brouillon 8 : l'ancienne formulation, celle de l'extraction, est refusée par le classificateur du mode "
    "automatique de la session, et la lecture serait bloquée ; la nouvelle a été acceptée et suivie sur un lot jouet de "
    "deux paires fabriquées, le 2026-10-12.)")
rep("  - étiqueté par un sous-agent neuf du modèle de la session.",
    "  - étiqueté par un sous-agent neuf du modèle de la session (modèle non épinglé par ce texte : limite déclarée).")
rep("au-delà de la part qu'il reste après les épisodes (environ 15 000 − 7 584 s) ;",
    "au-delà de la part qu'il reste après les épisodes (environ 15 000 − 7 584 s, moins les chargements des modèles et le "
    "préchargement, de l'ordre de quelques minutes) ;")
rep("Les descriptifs du pilote mesurent la durée de chaque notation.",
    "Les descriptifs du pilote mesurent la durée de chaque notation. **Mémoire des juges**, estimée sans mesure : 8B "
    "(environ 15 Gio de poids) et 3B (environ 6 Gio) résidents, plus le cache d'un seul juge à la fois au lot de 8 "
    "(contextes de l'ordre de 9 000 à 12 000 jetons, réponse comprise) : environ 40 Gio au plus, sous les 79 Gio de la "
    "carte ; une panne de mémoire après `episodes.json` se lit comme un run partiel (table de lecture). **Hôte** : l'offre "
    "est limitée au processeur de l'hôte de la revalidation (AMD EPYC 7513), le seul sur lequel le débit des épisodes "
    "est mesuré (le tirage se fait sur le processeur, en un fil) ; sans offre conforme, le pilote attend.")
rep("- de la liste des tâches, pour la décision N-019 :",
    "- l'estimation de la durée des juges (état des lieux, VR-03) : elle s'appuie sur des nombres lus dans les fiches "
    "scellées de la revalidation (propositions par épisode, longueurs), sans aucun texte affiché ;\n"
    "- l'essai de l'invite de l'étiqueteur sur un lot jouet (deux paires fabriquées, sans lien avec les tâches) ;\n"
    "- de la liste des tâches, pour la décision N-019 :")

with open(sortie, "x", encoding="utf-8") as f:
    f.write(s)
print(f"{sortie} écrit ; marqueurs « À REMPLIR » : {s.count('À REMPLIR')}")
