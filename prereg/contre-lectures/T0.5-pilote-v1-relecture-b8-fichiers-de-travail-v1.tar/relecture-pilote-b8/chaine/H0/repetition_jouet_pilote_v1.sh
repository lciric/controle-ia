#!/usr/bin/env bash
# Répétition jouet de la chaîne de l'instance du pilote de T0.5 (ETUDE=pilote, MODE=jouet), au commit C du dépôt de
# travail (état des lieux, HR-04 et PL-14 : le chemin « pilote » n'a pas été joué depuis R-065, au script ancien).
# Dépôt jetable cloné de C, dépôt nu local en guise de dépôt distant, jetons factices, env -i. Le préenregistrement jouet
# est produit par le générateur du pilote en mode jouet (configuration réduite, quatre tâches dérivées de la source par
# deriver_taches_pilote_v1.py), puis scellé. Passages :
#   1. cas sain : BRANCHE=calcul/t05-pilote-jouet-v1 → code 0, résultats et traces poussés, vecteurs sur
#      donnees/t05/<run> (commit sans parent), empreinte égale à celle d'episodes.json ;
#   2. artefact : même branche, déjà présente → arrêt avant l'installation (code 2) ;
#   3. relancement sain : BRANCHE=calcul/t05-pilote-jouet-v2 → code 0.
# Puis la récupération du pilote (copie dont seule l'adresse du dépôt change) sur le passage 1. Temps mesuré de la ligne
# « AMORCE » à la fin des tests (risque Z-5).
# Usage : repetition_jouet_pilote_v1.sh C RACINE_NEUVE
set -uo pipefail
C=$1; R=$2
BN=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad
H=$BN/pilote-v1
PY=$BN/scellement-revalidation/venv-gpu-neuf/bin/python
VENV=$BN/scellement-revalidation/venv-gpu-neuf
D=/home/user/controle-ia-travail
P=prereg/T0.5-pilote-8B-v1.md; CFG=prereg/T0.5-pilote-config-v1.json; TJ=donnees/t05-pilote-v1/taches-pilote-jouet-4-v1.json
[ -e "$R" ] && { echo "$R existe déjà (R12)"; exit 2; }
mkdir -p "$R" && cd "$R" || exit 2
git clone -q --no-local "$D" source && cd source && git checkout -q "$C" && git checkout -q -B main || exit 2
git config user.email essai@invalid; git config user.name essai; git config commit.gpgsign false
"$PY" -I "$H/deriver_taches_pilote_v1.py" donnees/20261007-082440-t05-extraction/taches-evaluation.json \
    76cdeace861d2fff45ca732c55c2d97611dcd47edc7c27d62bdad4c37755e67e 4 "$TJ" > "$R/derivation.json" || exit 2
PYTHONPATH=src "$PY" -m controle_ia.scellement sceller "$TJ" > /dev/null || exit 2
git add -f "$TJ" "$TJ.sha256" && git commit -qm "essai : tâches jouet" || exit 2
N=$(PYTHONPATH=src "$PY" -m pytest --collect-only -q -p no:cacheprovider 2>/dev/null | sed -n 's/^\([0-9]*\) tests\{0,1\} collected.*/\1/p')
echo "tests collectés : $N"
echo 20261012 > "$R/entropie.txt"
TESTS_JOUET=$N "$PY" -I "$H/remplir_pilote_v1.py" . "$(git rev-parse HEAD)" jouet "2026-10-12 (répétition jouet)" "$R/entropie.txt" \
    "$P" "$CFG" --taches "$TJ" --rapports-etat "essai-etat=$(printf '0%.0s' {1..64})" \
    --rapports-relecture "essai-relecture=$(printf '0%.0s' {1..64})" > "$R/remplissage.json" || exit 2
PYTHONPATH=src "$PY" -m controle_ia.scellement sceller "$CFG" > /dev/null || exit 2
PYTHONPATH=src "$PY" -c "from controle_ia.prereg import sceller_prereg; sceller_prereg('$P')" || exit 2
git add "$P" "$P.sha256" "$CFG" "$CFG.sha256" && git commit -qm "essai : préenregistrement jouet du pilote" || exit 2
ESSAI=$(git rev-parse HEAD); echo "$ESSAI" > "$R/commit-essai.txt"
git clone -q --bare "$R/source" "$R/distant.git" || exit 2
cd "$R"
passage() {   # $1 nom, $2 BRANCHE
    local n=$1 b=$2 debut fin code
    mkdir -p "$R/racine-$n"
    debut=$(date +%s)
    env -i PATH="/usr/bin:/bin" LANG=C.UTF-8 HOME="$R/racine-$n" COMMIT="$ESSAI" GH_TOKEN=factice HF_TOKEN=factice \
        ETUDE=pilote MODE=jouet DEPOT_URL="$R/distant.git" RACINE_AMORCE="$R/racine-$n" VENV_EXISTANT="$VENV" \
        PREREG="$P" BRANCHE="$b" bash "$R/source/scripts/amorce_instance_t05.sh" > "$R/amorce-$n.log" 2>&1
    code=$?
    fin=$(date +%s)
    echo "passage $n : code $code ; durée totale $((fin - debut)) s"
    grep -h "^AMORCE" "$R/amorce-$n.log" 2>/dev/null | cut -c1-200 | sed 's/^/    | /'
    grep -h "tests :\|run :\|vecteurs\|arrêt\|ARRÊT\|poussée\|pip freeze\|format" "$R"/racine-"$n"/t05/journal.txt 2>/dev/null | cut -c1-200 | sed 's/^/    | /'
    # place disque (environ 770 Mo par clone) : les clones du passage partent, journaux et sorties restent
    rm -rf "$R/racine-$n/t05/controle-ia" "$R/racine-$n/amorce-depot"
}
passage 1-sain calcul/t05-pilote-jouet-v1
passage 2-artefact-branche-presente calcul/t05-pilote-jouet-v1
passage 3-relance calcul/t05-pilote-jouet-v2
git -C "$R/distant.git" branch -a | sed 's/^/branche distante : /'
# récupération du pilote sur le passage 1 (copie dont changent l'adresse du dépôt, la branche et le motif du run
# jouets, le mode attendu « jouet » et la carte absente)
sed -e "s|https://github.com/lciric/controle-ia-travail.git|$R/distant.git|" \
    -e "s|BRANCHE=calcul/t05-pilote-reel-v1|BRANCHE=calcul/t05-pilote-jouet-v1|" \
    -e "s|-t05-pilote-reel\\$|-t05-pilote-jouet\$|" -e 's|m\["config"\].get("mode") == "reel"|m["config"].get("mode") == "jouet"|' \
    -e 's|"disponible True"|"disponible False"|' "$H/recuperation_pilote_v1.sh" > "$R/recuperation-essai.sh"
echo "lignes changées dans la copie de la récupération : $(diff "$H/recuperation_pilote_v1.sh" "$R/recuperation-essai.sh" | grep -c '^>')"
env HF_TOKEN=factice-hf-0000 CONTROLE_IA_GITHUB_TOKEN=factice-gh-0000 GH_TOKEN=factice-gh-0000 VAST_API_KEY=factice-vast-0000 \
    bash "$R/recuperation-essai.sh" "$ESSAI" "$R/recuperation" > "$R/recuperation.txt" 2>&1; c=$?
echo "récupération (passage 1) : code $c ; $(tail -1 "$R/recuperation.txt")"
grep '^KO' "$R/recuperation.txt" | sed 's/^/    /'
grep -h "pip freeze\|paquet\|==" "$R"/recuperation/traces/t05-*/pip-freeze.txt 2>/dev/null | head -3 | sed 's/^/    pip freeze : /'
rm -rf "$R/recuperation" "$R/source" "$R/distant.git"
echo "FIN DE LA RÉPÉTITION"
