"""Remplit les « À REMPLIR » du brouillon 8 du préenregistrement du pilote de T0.5 et écrit la version à sceller et sa
configuration (plan de lancement du pilote, étape 1). Chaque champ est remplacé par son contexte exact, une seule fois
(jamais de remplacement global ; AR-15). Les valeurs du verdict (noyau, durée projetée, `duree_max_s`) sont
recalculées ici depuis les résultats scellés de la revalidation v2, par le code de lecture cité et la formule gelée,
et confrontées à la décision N-019 (PF-05, VR-05, PL-01) ; rien n'est recopié à la main.

Usage : python -I remplir_pilote_v1.py DEPOT COMMIT MODE DATE ENTROPIE SORTIE_PREREG SORTIE_CONFIG
        --taches CHEMIN --rapports-etat NOM=SHA[,NOM=SHA…] --rapports-relecture NOM=SHA[,…] --candidat-relu CHEMIN
MODE : reel (version à sceller : COMMIT = HEAD, arbre suivi propre, date à moins d'une heure de l'horloge) ; candidat
(texte soumis à la relecture R2 : comme reel, sans exigence d'horloge ni de candidat relu ; les rapports de la relecture,
encore à venir, sont des paires factices non vérifiées) ; jouet (répétition sur un dépôt jetable : configuration réduite,
fichier de tâches réduit, aucune exigence d'horloge).
DATE : « AAAA-MM-JJ HH:MM UTC ». ENTROPIE : fichier d'une ligne, entier dans ]0 ; 2^128[ (SeedSequence, R9).
--candidat-relu : texte relu par la relecture R2 (chemin sous brouillons/, au commit) ; mode reel : la version écrite
doit lui être égale une fois normalisée (champs du scellement masqués), sinon arrêt."""
import argparse
import datetime
import hashlib
import json
import math
import os
import re
import subprocess
import sys
from pathlib import Path

BROUILLON = "brouillons/T0.5-pilote-8B-v1-brouillon8.md"
BROUILLON_CFG = "brouillons/T0.5-pilote-config-v1-brouillon1.json"
SOURCE_TACHES = "donnees/20261007-082440-t05-extraction/taches-evaluation.json"
SHA_SOURCE = "76cdeace861d2fff45ca732c55c2d97611dcd47edc7c27d62bdad4c37755e67e"
RUN_REVAL = "20261011-225701-t05-revalidation-reel"
RESUME = f"diag/{RUN_REVAL}/resume.json"
MESURES = f"diag/{RUN_REVAL}/mesures-defaut.json"
LECTURE = f"diag/{RUN_REVAL}/lecture-defaut.json"
VERDICT = "docs/verdicts/verdict-T0.5-revalidation-v2.md"
DECISION = "docs/decisions/decision-N-019-v1.md"
PLAN = "docs/procedures/pilote-T0.5-v1/plan-lancement-pilote-v1.md"
TACHES_PILOTE = 60
EPISODES_PAR_TACHE = 3
R8_MAX_S, PLAFOND_S, JUGES_S, FACTEUR = 7800, 15000, 7200, 1.2
DOCUMENTS = [  # (chemin, abrégé du brouillon ou None)
    ("docs/brief-claude-code-programme-complet-v2.md", "9261932a"), ("docs/programme-controle-ia-v2.md", "2fd63bad"),
    ("docs/decisions/proposition-P-006-T0.5-v1.md", "6fe36296"),
    ("docs/decisions/proposition-P-007-plan-G0-v1.md", "56b9182b"),
    ("docs/decisions/proposition-P-009-T0.6-organismes-v1.md", None),
    ("docs/decisions/proposition-P-010-T0.8-moniteur-par-action-v1.md", None),
    ("docs/procedures/T0.5-selection-papiers-v1.md", "8f43dcae"),
    ("runs/20261006-134235-t05-corpus/manifeste.json", "92612ab6"),
    ("diag/20261006-134235-t05-corpus/corpus.json", "57f0aa47"),
    ("docs/procedures/T0.5-extraction-v1.md", None),
    ("diag/20261007-082440-t05-extraction/bilan-extraction.json", None),
    ("docs/sources/invites-2606.08892-v1/index.json", None),
    ("prereg/T0.4-validation-modele-reel-v3.md", "4f711cd3"),
    ("docs/verdicts/verdict-T0.4-critere-1-G0-v3.md", "63444faa"),
]


def arret(msg: str) -> None:
    sys.exit(f"ARRÊT du remplissage du pilote : {msg}")


p = argparse.ArgumentParser()
for a in ("depot", "commit", "mode", "date", "entropie", "sortie_p", "sortie_c"):
    p.add_argument(a)
p.add_argument("--taches", required=True)
p.add_argument("--rapports-etat", required=True)
p.add_argument("--rapports-relecture", required=True)
p.add_argument("--candidat-relu", default=None)
a = p.parse_args()
D = Path(a.depot)
if not re.fullmatch(r"[0-9a-f]{40}", a.commit) or a.mode not in ("reel", "candidat", "jouet"):
    arret("commit (40 hexadécimaux) ou mode (reel, candidat, jouet) invalide")
if a.mode == "reel":
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2} UTC", a.date):
        arret("date attendue au format « AAAA-MM-JJ HH:MM UTC »")
    ecart = abs((datetime.datetime.strptime(a.date, "%Y-%m-%d %H:%M UTC").replace(tzinfo=datetime.timezone.utc)
                 - datetime.datetime.now(datetime.timezone.utc)).total_seconds())
    if ecart > 3600:
        arret(f"date à {ecart:.0f} s de l'horloge (au plus 3 600 s)")
    if a.candidat_relu is None:
        arret("mode reel sans --candidat-relu")
entropie = Path(a.entropie).read_text(encoding="utf-8").strip()
if not entropie.isdigit() or not 0 < int(entropie) < 2 ** 128:
    arret(f"entropie de {a.entropie} hors de ]0 ; 2^128[")
for f in (a.sortie_p, a.sortie_c):
    if Path(f).exists():
        arret(f"{f} existe déjà (R12)")


def git(*args: str) -> bytes:
    r = subprocess.run(["git", "-C", str(D), *args], capture_output=True)
    if r.returncode != 0:
        arret(f"git {' '.join(args)} : {r.stderr.decode(errors='replace').strip()}")
    return r.stdout


def au_commit(chemin: str) -> bytes:
    return git("show", f"{a.commit}:{chemin}")


def sha_au_commit(chemin: str) -> str:
    return hashlib.sha256(au_commit(chemin)).hexdigest()


def scelle_au_commit(chemin: str) -> str:
    """Empreinte d'un fichier cité, exigée égale à son sceau compagnon au commit (R6)."""
    sha = sha_au_commit(chemin)
    sceau = au_commit(chemin + ".sha256").decode("utf-8").split()
    if not sceau or sceau[0] != sha or sceau[1:] != [Path(chemin).name]:
        arret(f"{chemin} : sceau absent ou différent au commit")
    return sha


def paires(texte: str) -> list[tuple[str, str]]:
    sortie = []
    for x in texte.split(","):
        nom, _, sha = x.strip().partition("=")
        if not nom or not re.fullmatch(r"[0-9a-f]{64}", sha):
            arret(f"paire de rapport mal formée : {x!r}")
        sortie.append((nom, sha))
    return sortie


if a.mode in ("reel", "candidat"):
    if git("rev-parse", "HEAD").decode().strip() != a.commit:
        arret("le commit cité n'est pas HEAD")
    if git("status", "--porcelain", "--untracked-files=no").strip():
        arret("arbre suivi non propre")

sys.path.insert(0, str(D / "src"))
from controle_ia.environnements.lancer_pilote_a import empreinte_config  # noqa: E402
from controle_ia.environnements.revalider_pilote_a import choisir_noyau  # noqa: E402

# --- verdict de la revalidation : résultats scellés relus, R8 appliquée au pilote réduit (N-019) ------------------
res = json.loads(au_commit(RESUME))["resultat"]
mes = json.loads(au_commit(MESURES))["resultat"]
lec = json.loads(au_commit(LECTURE))["resultat"]["lecture"]
for chemin in (RESUME, MESURES, LECTURE, VERDICT, DECISION):
    scelle_au_commit(chemin)
if res.get("noyau_retenu") is not None or res.get("noeud") is not True:
    arret("le résumé de la revalidation ne conclut pas au nœud : N-019 ne s'applique pas")
manquants = [k for k in ("R1_garde_saine", "R1_marge", "R3_seuil_fonde", "R4_rejeu", "R5_domaine_couvert",
                         "R6_chemin_defaut", "R7_memoire", "audit_conforme", "garde_zone_generee_conforme")
             if lec.get(k) is not True]
if manquants or lec.get("R2_controle_negatif") != "conforme" or lec.get("R8_duree") is not False:
    arret(f"bras « defaut » : la prémisse de N-019 (tout conforme sauf R8) ne tient pas ({manquants})")
chrono = mes["chrono"]
d_reval = mes["duree_projetee_episodes_pilote_s"]
episodes_reval = d_reval and round((chrono["generation_s"] + chrono["passe_unique_s"]) * 192 / d_reval)
if episodes_reval != 16:
    arret(f"durée projetée scellée incohérente avec la formule ({episodes_reval} épisodes au lieu de 16)")
d = (chrono["generation_s"] + chrono["passe_unique_s"]) * TACHES_PILOTE * EPISODES_PAR_TACHE / 16
if not d <= R8_MAX_S:
    arret(f"durée projetée du pilote réduit {d:.2f} s > {R8_MAX_S} s")
duree_max = min(PLAFOND_S, math.ceil((FACTEUR * d + JUGES_S) / 60) * 60)
lec_retenue = dict(lec, R8_duree=True, conforme=True, conforme_avec_marge=True)   # R8 appliquée au pilote réduit
noyau, prop = choisir_noyau({"defaut": lec_retenue, "math": json.loads(au_commit(
    f"diag/{RUN_REVAL}/lecture-math.json"))["resultat"]["lecture"]})
if noyau != "defaut":
    arret(f"choix du noyau sur le pilote réduit : {noyau!r} ({prop})")
decision = au_commit(DECISION).decode("utf-8")
if "7 584,02 s" not in decision or "**15 000 s**" not in decision or "noyau « defaut »" not in decision:
    arret("la décision N-019 ne porte pas les valeurs recalculées (7 584,02 s ; 15 000 s ; noyau « defaut »)")
if f"{d:.2f}" != "7584.02" or duree_max != 15000:
    arret(f"valeurs recalculées {d:.2f} s et {duree_max} s ≠ celles de N-019")
reserves = res.get("reserves") or []
if any("RV-5" not in r for r in reserves) or not reserves:
    arret(f"réserves du verdict inattendues : {reserves}")
# part des actions à zone générée sous 1 % du bras retenu : `lecture-defaut.json` → resultat.zone_generee (verdict,
# section 5) ; obligatoire, aucun repli silencieux (R5)
part_sous_1pc = json.loads(au_commit(LECTURE))["resultat"].get("zone_generee", {}).get("part_zone_generee_sous_1pc")
if not isinstance(part_sous_1pc, (int, float)) or not 0 <= part_sous_1pc <= 0.2:
    arret(f"part des actions à zone générée sous 1 % absente ou au-dessus de 0,2 : {part_sous_1pc}")

# --- tâches : fichier dérivé, égal aux 60 premières de la source -------------------------------------------------
sha_taches = scelle_au_commit(a.taches)
derive = json.loads(au_commit(a.taches))
if a.mode in ("reel", "candidat"):
    if scelle_au_commit(SOURCE_TACHES) != SHA_SOURCE:
        arret("source des tâches : empreinte inattendue")
    source = json.loads(au_commit(SOURCE_TACHES))["resultat"]["taches"]
    if derive.get("source", {}).get("sha256") != SHA_SOURCE or derive["taches"] != source[:TACHES_PILOTE] \
            or len(derive["taches"]) != TACHES_PILOTE:
        arret("fichier dérivé des tâches ≠ 60 premières tâches de la source")

# --- configuration ------------------------------------------------------------------------------------------------
config = json.loads(au_commit(BROUILLON_CFG).decode("utf-8"))
if config.get("mode") != "reel" or not str(config.get("duree_max_s", "")).startswith("À REMPLIR") \
        or not str(config.get("noyau_attention", "")).startswith("À REMPLIR"):
    arret("brouillon de la configuration inattendu")
config.update(noyau_attention=noyau, duree_max_s=duree_max)
if a.mode == "jouet":          # répétition sur processeur : modèle jouet, tailles réduites (chaîne seulement)
    config.update(mode="jouet", T=2, max_nouveaux=8, lot=2, couches=[0, 1, 2], max_nouveaux_juge=6, lot_juge=2,
                  lot_appariement=4)
    # le tokeniseur jouet n'a pas l'ouverture datée du gabarit réel : la garde du format (controler_format) arrêterait
    # la répétition dès le début (répétition du 2026-10-12, passage 1) ; seul le mode jouet perd ce champ
    for spec in [config["agent"], *config["juges"]]:
        spec.pop("texte_attendu_ouverture", None)
cfg_sha = empreinte_config(config)
amorce, instance = sha_au_commit("scripts/amorce_instance_t05.sh"), sha_au_commit("scripts/pilote_t05_instance.sh")
if a.mode in ("reel", "candidat"):
    # la collecte se fait dans l'arbre de travail : il doit être le commit cité, sans modification suivie
    if git("rev-parse", "HEAD").decode().strip() != a.commit or git("status", "--porcelain", "--untracked-files=no").strip():
        arret("arbre de travail ≠ commit cité (tête ou fichiers suivis modifiés) : collecte des tests non représentative")
    r = subprocess.run([sys.executable, "-m", "pytest", "--collect-only", "-q", "-p", "no:cacheprovider"], cwd=D,
                       capture_output=True, text=True, env={**os.environ, "PYTHONPATH": "src"})
    m = re.search(r"^(\d+) tests? collected", r.stdout, re.M)
    if r.returncode != 0 or not m:
        arret("collecte des tests illisible")
    tests = m.group(1)
else:
    tests = os.environ.get("TESTS_JOUET", "0")

# --- texte --------------------------------------------------------------------------------------------------------
b8 = au_commit(BROUILLON)
t = b8.decode("utf-8")


def rep(x: str, y: str) -> None:
    global t
    n = t.count(x)
    if n != 1:
        arret(f"cible trouvée {n} fois : {x[:90]!r}")
    t = t.replace(x, y)


def nombre(x: float, dec: int = 2) -> str:
    entier, _, frac = f"{x:.{dec}f}".partition(".")
    groupes = f"{int(entier):,}".replace(",", " ")
    return groupes + ("," + frac if frac and dec else "")


l3 = t.split("\n")[2]
if not l3.startswith("- Auteur : la session de mise en œuvre du programme de Lazar ; brouillon 8 du 2026-10-12"):
    arret("ligne d'auteur du brouillon 8 inattendue")
rep(l3, l3.replace("- Auteur : la session de mise en œuvre du programme de Lazar ; brouillon 8",
                   f"- Auteur : la session de mise en œuvre du programme de Lazar ; version scellée le {a.date}, "
                   f"depuis le brouillon 8 (`{BROUILLON}`, `{hashlib.sha256(b8).hexdigest()}`), seuls les marqueurs "
                   "de remplissage remplis ; brouillon 8", 1))
rep("- Date (UTC) : À REMPLIR (scellement : après l'extraction, N-014 et le verdict de la revalidation).",
    f"- Date (UTC) : {a.date.removesuffix(' UTC')} (scellement : après l'extraction, N-014, le verdict de la "
    "revalidation et N-019).")
rep("- Commit du code d'analyse : `À REMPLIR`", f"- Commit du code d'analyse : `{a.commit}`")
rep("`scripts/amorce_instance_t05.sh` (`À REMPLIR`, sha256) et `scripts/pilote_t05_instance.sh` (`À REMPLIR`, sha256)",
    f"`scripts/amorce_instance_t05.sh` (`{amorce}`, sha256) et `scripts/pilote_t05_instance.sh` (`{instance}`, sha256)")
rep("- Entropie : `À REMPLIR` (tirée au scellement", f"- Entropie : `{entropie}` (tirée au scellement")
rep("- Configuration du pilote (empreinte canonique) : `À REMPLIR`",
    f"- Configuration du pilote (empreinte canonique) : `{cfg_sha}`")
rep("- Tâches du pilote : `À REMPLIR` (empreinte", f"- Tâches du pilote : `{sha_taches}` (empreinte")
rep("- Chemin des tâches : `À REMPLIR` (fichier dérivé", f"- Chemin des tâches : `{a.taches}` (fichier dérivé")
rep("- Tests attendus : `À REMPLIR` (toute", f"- Tests attendus : `{tests}` (toute")
rep("verdict de la revalidation courte : `À REMPLIR` ; décision N-019 : `À REMPLIR`.",
    f"verdict de la revalidation courte : `{VERDICT}` (`{scelle_au_commit(VERDICT)}`) ; décision N-019 : "
    f"`{DECISION}` (`{scelle_au_commit(DECISION)}`).")
rep("  - noyau d'attention du pilote : `À REMPLIR` ; durée projetée des épisodes du pilote (180 épisodes, formule "
    "gelée `duree_projetee_pilote` aux mesures scellées du bras retenu) : `À REMPLIR` s ; `duree_max_s` (formule "
    "gelée) : `À REMPLIR` s ;",
    f"  - noyau d'attention du pilote : `{noyau}` ; durée projetée des épisodes du pilote (180 épisodes, formule "
    f"gelée `duree_projetee_pilote` aux mesures scellées du bras retenu, `{MESURES}`, "
    f"`{scelle_au_commit(MESURES)}`) : `{nombre(d)}` s ; `duree_max_s` (formule gelée) : `{nombre(duree_max, 0)}` s ;")
texte_reserves = (" ; ".join(reserves) + f" ; part des actions à zone générée sous 1 % au bras retenu : "
                  f"{nombre(part_sous_1pc, 2)} (seuil de réserve 0,2 ; `{LECTURE}`)")
rep("  - réserves du verdict, reprises ici : `À REMPLIR` ;", f"  - réserves du verdict, reprises ici : {texte_reserves} ;")
rep("  - plan de lancement du pilote : `À REMPLIR` (remplace", f"  - plan de lancement du pilote : `{PLAN}` "
    f"(`{scelle_au_commit(PLAN)}`) (remplace")
rep("- Documents qui font foi (chemin et sha256 complets au scellement) :", "- Documents qui font foi (chemin et sha256 "
    "complets) :")
for chemin, court in DOCUMENTS:
    plein = scelle_au_commit(chemin)
    if court is not None and not plein.startswith(court):
        arret(f"{chemin} : empreinte {plein[:12]} ≠ abrégé {court}")
rep("  - `docs/brief-claude-code-programme-complet-v2.md` (9261932a…) et `docs/programme-controle-ia-v2.md` (2fd63bad…) ;",
    f"  - `docs/brief-claude-code-programme-complet-v2.md` (`{scelle_au_commit(DOCUMENTS[0][0])}`) et "
    f"`docs/programme-controle-ia-v2.md` (`{scelle_au_commit(DOCUMENTS[1][0])}`) ;")
rep("(R-085 ; proposition 6fe36296…)", f"(R-085 ; proposition `{DOCUMENTS[2][0]}`, `{scelle_au_commit(DOCUMENTS[2][0])}`)")
rep("  - P-007 (56b9182b…), retenue", f"  - P-007 (`{DOCUMENTS[3][0]}`, `{scelle_au_commit(DOCUMENTS[3][0])}`), retenue")
rep("  - P-009 et P-010 (usagers", f"  - P-009 (`{DOCUMENTS[4][0]}`, `{scelle_au_commit(DOCUMENTS[4][0])}`) et P-010 "
    f"(`{DOCUMENTS[5][0]}`, `{scelle_au_commit(DOCUMENTS[5][0])}`) (usagers")
rep("  - règle de sélection (8f43dcae…), run de sélection `20261006-134235-t05-corpus` (manifeste 92612ab6…, corpus "
    "57f0aa47…) ;",
    f"  - règle de sélection (`{DOCUMENTS[6][0]}`, `{scelle_au_commit(DOCUMENTS[6][0])}`), run de sélection "
    f"`20261006-134235-t05-corpus` (manifeste `{DOCUMENTS[7][0]}`, `{scelle_au_commit(DOCUMENTS[7][0])}` ; corpus "
    f"`{DOCUMENTS[8][0]}`, `{scelle_au_commit(DOCUMENTS[8][0])}`) ;")
rep("  - procédure d'extraction v1 (`À REMPLIR`) et son bilan (`À REMPLIR`) ;",
    f"  - procédure d'extraction v1 (`{DOCUMENTS[9][0]}`, `{scelle_au_commit(DOCUMENTS[9][0])}`) et son bilan "
    f"(`{DOCUMENTS[10][0]}`, `{scelle_au_commit(DOCUMENTS[10][0])}`) ;")
rep("  - index des invites transcrites (`docs/sources/invites-2606.08892-v1/index.json`, `À REMPLIR`) ;",
    f"  - index des invites transcrites (`{DOCUMENTS[11][0]}`, `{scelle_au_commit(DOCUMENTS[11][0])}`) ;")
rep("  - T0.4 v3 : préenregistrement (4f711cd3…) et verdict (63444faa… :",
    f"  - T0.4 v3 : préenregistrement (`{DOCUMENTS[12][0]}`, `{scelle_au_commit(DOCUMENTS[12][0])}`) et verdict "
    f"(`{DOCUMENTS[13][0]}`, `{scelle_au_commit(DOCUMENTS[13][0])}` :")
rep("Durée projetée des épisodes au débit mesuré par la revalidation (bras « defaut », 180 épisodes ; N-019) : "
    "`À REMPLIR` s.",
    "Durée projetée des épisodes au débit mesuré par la revalidation (bras « defaut », 180 épisodes ; N-019) : "
    f"{nombre(d)} s.")
rep("; au commit cité, `À REMPLIR` tests),", f"; au commit cité, {tests} tests),")
rep("  - `duree_max_s` (`À REMPLIR` s, par la formule gelée", f"  - `duree_max_s` ({nombre(duree_max, 0)} s, par la "
    "formule gelée")
etat = paires(a.rapports_etat)
rep("synthèse et critique de complétude ; rapports `À REMPLIR`.",
    "synthèse et critique de complétude ; rapports " + " ; ".join(
        f"`prereg/contre-lectures/{n}` (`{s}`)" for n, s in etat) + ".")
rel = paires(a.rapports_relecture)
rep("- Relecture R2 du brouillon 8 et du différentiel du code depuis la relecture b6 (`e6ce058`) : `À REMPLIR`.",
    "- Relecture R2 du brouillon 8 et du différentiel du code depuis la relecture b6 (`e6ce058`), par des sous-agents "
    "neufs : rapports " + " ; ".join(f"`prereg/contre-lectures/{n}` (`{s}`)" for n, s in rel) + ".")
for n, s in etat + (rel if a.mode == "reel" else []):
    if a.mode in ("reel", "candidat") and scelle_au_commit(f"prereg/contre-lectures/{n}") != s:
        arret(f"rapport {n} : empreinte citée ≠ sceau au commit")
if "À REMPLIR" in t:
    arret("« À REMPLIR » restant : " + "; ".join(x[:70] for x in t.splitlines() if "À REMPLIR" in x))


import importlib.util  # noqa: E402

_spec = importlib.util.spec_from_file_location("normaliser_pilote_v1", Path(__file__).resolve().parent / "normaliser_pilote_v1.py")
_norm = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_norm)            # normalisation partagée avec les contrôles avant dépense (une seule source)
normaliser = _norm.normaliser


if a.mode == "reel":
    relu = au_commit(a.candidat_relu).decode("utf-8")
    if normaliser(relu) != normaliser(t):
        arret("version écrite ≠ candidat relu, hors des champs du scellement")
with open(a.sortie_p, "x", encoding="utf-8") as f:
    f.write(t)
with open(a.sortie_c, "x", encoding="utf-8") as f:
    f.write(json.dumps(config, ensure_ascii=False, indent=2) + "\n")
if empreinte_config(json.loads(Path(a.sortie_c).read_text(encoding="utf-8"))) != cfg_sha:
    arret("empreinte canonique du fichier de configuration écrit ≠ empreinte citée")
print(json.dumps({"prereg_sha256": hashlib.sha256(t.encode("utf-8")).hexdigest(), "config_canonique": cfg_sha,
                  "noyau": noyau, "d_s": round(d, 4), "duree_max_s": duree_max, "tests": tests, "taches": sha_taches,
                  "normalise_sha256": hashlib.sha256(normaliser(t).encode("utf-8")).hexdigest()}, ensure_ascii=False))
