#!/usr/bin/env bash
# Scellement du préenregistrement du pilote de T0.5 (plan de lancement du pilote, étape 1), sur le modèle du scellement
# v5 de la revalidation et des constats de l'état des lieux (PL-09) : HEAD = origin/main, arbre suivi propre, sorties
# absentes (R12) ; scripts égaux à leurs copies versées ; candidat relu égal à son épingle, brute et normalisée ;
# entropie tirée ici par numpy.random.SeedSequence (R9), écrite une seule fois ; texte régénéré par le générateur en mode
# reel, normalisé égal à l'épingle ; configuration et préenregistrement scellés ; verifier-arbre ; un seul commit S qui
# n'ajoute que ces quatre fichiers, poussé, puis relu sur le dépôt distant. Un échec avant le commit retire les fichiers
# créés ici (et seulement eux) : aucun reste non suivi.
# Usage : sceller_pilote_v1.sh
set -euo pipefail
H=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-pilote-b8/chaine/H
DEPOT=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-pilote-b8/chaine/clone
PY=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/scellement-revalidation/venv-gpu-neuf/bin/python
VERSEES=docs/procedures/pilote-T0.5-v1
P=prereg/T0.5-pilote-8B-v1.md; CFG=prereg/T0.5-pilote-config-v1.json
TACHES=donnees/t05-pilote-v1/taches-pilote-60-v1.json
CTL=$H/controles_avant_depense_pilote_v1.sh
epingle() { sed -n "s/^$1=\"\{0,1\}\([^\"#]*\)\"\{0,1\}.*/\1/p" "$CTL" | sed 's/[[:space:]]*$//'; }
RELU=$(epingle CANDIDAT_RELU_CHEMIN); RELU_SHA=$(epingle CANDIDAT_RELU); NORMALISE=$(epingle CANDIDAT_NORMALISE)
RAPPORTS=$(epingle RAPPORTS_ATTENDUS)
[[ "$RELU_SHA" =~ ^[0-9a-f]{64}$ && "$NORMALISE" =~ ^[0-9a-f]{64}$ && "$RELU" == brouillons/* && -n "$RAPPORTS" && "$RAPPORTS" != A_EPINGLER ]] \
    || { echo "épingles absentes des contrôles"; exit 2; }
ETAT=$(for x in $RAPPORTS; do case $x in *etat-des-lieux*) printf '%s,' "$x" ;; esac; done); ETAT=${ETAT%,}
REL=$(for x in $RAPPORTS; do case $x in *relecture-b8*) printf '%s,' "$x" ;; esac; done); REL=${REL%,}
[ -n "$ETAT" ] && [ -n "$REL" ] || { echo "rapports de l'état des lieux ou de la relecture absents des épingles"; exit 2; }
cd "$DEPOT"
git fetch -q origin main
[ "$(git rev-parse HEAD)" = "$(git rev-parse origin/main)" ] || { echo "HEAD ≠ origin/main : pousser d'abord les préalables"; exit 2; }
[ -z "$(git status --porcelain --untracked-files=no)" ] || { echo "arbre suivi non propre"; exit 2; }
for f in "$P" "$P.sha256" "$CFG" "$CFG.sha256"; do [ -e "$f" ] && { echo "$f existe déjà (R12)"; exit 2; }; done
for s in remplir_pilote_v1.py normaliser_pilote_v1.py controles_avant_depense_pilote_v1.sh lancer_pilote_v1.sh \
         sceller_pilote_v1.sh recuperation_pilote_v1.sh; do
    cmp -s "$H/$s" "$VERSEES/$s" || { echo "$s du bloc-notes ≠ copie versée"; exit 2; }
done
[ "$(sha256sum "$RELU" | cut -d' ' -f1)" = "$RELU_SHA" ] || { echo "candidat relu ≠ épingle brute"; exit 2; }
[ "$("$PY" -I "$H/normaliser_pilote_v1.py" "$RELU")" = "$NORMALISE" ] || { echo "candidat relu : normalisé ≠ épingle"; exit 2; }
COMMITTE=0
nettoyer() { if [ "$COMMITTE" = 0 ]; then for f in "$P" "$P.sha256" "$CFG" "$CFG.sha256"; do
    git ls-files --error-unmatch "$f" >/dev/null 2>&1 || rm -f "$f"; done; echo "échec avant le commit : fichiers créés retirés"; fi; }
trap nettoyer EXIT
TRAVAIL=$(mktemp -d "$H/scellement-XXXX")
"$PY" -I -c "import numpy as np; print(np.random.SeedSequence().entropy)" > "$TRAVAIL/entropie.txt"
"$PY" -I "$H/remplir_pilote_v1.py" . "$(git rev-parse HEAD)" reel "$(date -u '+%Y-%m-%d %H:%M UTC')" "$TRAVAIL/entropie.txt" \
    "$TRAVAIL/prereg.md" "$TRAVAIL/config.json" --taches "$TACHES" --rapports-etat "$ETAT" --rapports-relecture "$REL" \
    --candidat-relu "$RELU"
[ "$("$PY" -I "$H/normaliser_pilote_v1.py" "$TRAVAIL/prereg.md")" = "$NORMALISE" ] || { echo "texte régénéré ≠ candidat relu normalisé"; exit 2; }
cp "$TRAVAIL/config.json" "$CFG"; cp "$TRAVAIL/prereg.md" "$P"
PYTHONPATH=src "$PY" -m controle_ia.scellement sceller "$CFG" > /dev/null
PYTHONPATH=src "$PY" -c "from controle_ia.prereg import sceller_prereg; sceller_prereg('$P')"
PYTHONPATH=src "$PY" -m controle_ia.scellement verifier-arbre . | tail -1 | grep -q "arbre intact"
SHA=$(cut -d' ' -f1 "$P.sha256")
git add "$P" "$P.sha256" "$CFG" "$CFG.sha256"
git commit -q -F - <<EOF
T0.5 : pilote 8B, préenregistrement v1 scellé (60 tâches, N-019 ; noyau « defaut », duree_max_s 15 000 s)

Préenregistrement $SHA ; configuration $(cut -d' ' -f1 "$CFG.sha256") ; empreinte normalisée égale au candidat
relu ($NORMALISE). PREREG et BRANCHE passés à l'instance (calcul/t05-pilote-reel-v1).

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01W5L3BRJg9Vso4Gru9tWAzM
EOF
COMMITTE=1
S=$(git rev-parse HEAD)
[ "$(git diff --name-only "$S^" "$S" | sort | tr '\n' ' ')" = "$(printf '%s\n' "$CFG" "$CFG.sha256" "$P" "$P.sha256" | sort | tr '\n' ' ')" ] \
    || { echo "contenu de S inattendu"; exit 2; }
timeout 600 git push -q origin HEAD:main || { echo "poussée de S en échec : S reste local ; repousser avant tout lancement"; exit 2; }
git fetch -q origin main
[ "$(git rev-parse origin/main)" = "$S" ] || { echo "origin/main ≠ S après la poussée"; exit 2; }
echo "S $S poussé ; préenregistrement $SHA"
