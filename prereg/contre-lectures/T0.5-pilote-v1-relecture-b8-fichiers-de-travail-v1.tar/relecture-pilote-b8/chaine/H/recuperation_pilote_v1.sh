#!/usr/bin/env bash
# Contrôles de récupération du pilote de T0.5 (plan de lancement du pilote, étape 7), avant toute fusion et avant toute
# proposition de destruction de l'instance (PL-10, PL-11) ; sur le modèle de recuperation_revalidation_v2.sh, plus la
# branche des vecteurs par action (donnees/t05/<run>, un commit sans parent : empreinte égale à celle d'episodes.json).
# Clone propre du dépôt de travail ; rien n'est fusionné ni poussé ici. Aucune valeur de jeton n'est affichée.
# Usage : recuperation_pilote_v1.sh S DOSSIER_NEUF [relance]
set -uo pipefail
S=${1:?commit de scellement}; D=${2:?dossier neuf}; MODE=${3:-premier}
B=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad
PY=$B/scellement-revalidation/venv-gpu-neuf/bin/python
P=prereg/T0.5-pilote-8B-v1.md
case "$MODE" in premier) BRANCHE=calcul/t05-pilote-reel-v1 ;; relance) BRANCHE=calcul/t05-pilote-reel-v2 ;; *) echo "mode : relance, ou rien"; exit 2 ;; esac
[ -e "$D" ] && { echo "$D existe déjà (R12)"; exit 2; }
echecs=0
ok() { echo "OK  $*"; }
ko() { echo "KO  $*"; echecs=$((echecs + 1)); }
git clone -q https://github.com/lciric/controle-ia-travail.git "$D" || { echo "clonage impossible"; exit 2; }
cd "$D"
git fetch -q origin "$BRANCHE" || { echo "branche $BRANCHE introuvable"; exit 2; }
H=$(git rev-parse FETCH_HEAD); echo "tête de la branche : $H"
git checkout -q --detach "$H"
# 1. ascendance et contenu
git merge-base --is-ancestor "$S" "$H" && ok "1a S est ancêtre de la branche" || ko "1a S n'est pas ancêtre de la branche"
git diff --name-status "$S" "$H" > ../diff-status.txt
NON_AJOUTS=$(grep -vc '^A' ../diff-status.txt || true)
[ "$NON_AJOUTS" = 0 ] && ok "1b seulement des ajouts ($(wc -l < ../diff-status.txt) fichiers)" || ko "1b $NON_AJOUTS changement(s) autre(s) qu'un ajout"
HORS=$(cut -f2 ../diff-status.txt | grep -vE '^(runs/[^/]+/|diag/[^/]+/|traces/t05-[^/]+/)' || true)
[ -z "$HORS" ] && ok "1c ajouts sous runs/, diag/ et traces/t05-*/ seulement" || ko "1c chemins hors périmètre : $HORS"
RUNS=$(cut -f2 ../diff-status.txt | grep -E '^(runs|diag)/' | cut -d/ -f2 | sort -u)
NRUNS=$(printf '%s\n' "$RUNS" | grep -c . || true)
RUN=$(printf '%s\n' "$RUNS" | head -1)
if [ "$NRUNS" = 1 ] && [[ "$RUN" =~ ^[0-9]{8}-[0-9]{6}-t05-pilote-reel$ ]]; then ok "1d un seul run : $RUN"; else ko "1d runs : $RUNS"; fi
AUTEURS=$(git log --format='%an' "$S..$H" | sort -u)
[ "$AUTEURS" = "instance de calcul (T0.5)" ] && ok "1e commits de « instance de calcul (T0.5) » ($(git rev-list --count "$S..$H"))" || ko "1e auteurs : $AUTEURS"
# 2. sceaux
PYTHONPATH=src "$PY" -m controle_ia.scellement verifier-arbre . > ../verifier-arbre.txt 2>&1 && ok "2a verifier-arbre : $(tail -1 ../verifier-arbre.txt)" || ko "2a verifier-arbre : $(tail -3 ../verifier-arbre.txt)"
for f in diag/"$RUN"/*.json; do
    PYTHONPATH=src "$PY" -c "from controle_ia.manifeste import verifier_resultat; verifier_resultat('.', '$f')" 2>../vr.err \
        && ok "2b verifier_resultat $f" || ko "2b verifier_resultat $f : $(tail -1 ../vr.err)"
done
NOUVELLES=$(for d in traces/t05-*/; do git cat-file -e "$S:${d%/}" 2>/dev/null || echo "${d%/}"; done)
for d in $NOUVELLES; do
    (cd "$d" && sha256sum -c --quiet empreintes.sha256) > ../sc.txt 2>&1 && ok "2c sha256sum -c $d" || ko "2c $d : $(head -2 ../sc.txt)"
done
# 3. manifeste et citations ; 4. issue ; vecteurs
PYTHONPATH=src "$PY" - "$RUN" "$S" "$P" <<'EOF' || echecs=$((echecs + 1))
import json, re, sys
from pathlib import Path
from controle_ia.manifeste import lire_manifeste
from controle_ia.environnements.lancer_pilote_a import empreinte_config
run, s, p = sys.argv[1:4]
k = 0
def ok(m): print("OK ", m)
def ko(m):
    global k; k += 1; print("KO ", m)
texte = Path(p).read_text(encoding="utf-8")
cite = lambda motif: (re.search(motif, texte) or [None, None])[1]
cfg_c, taches_c, ent_c = cite(r"Configuration du pilote \(empreinte canonique\) : `([0-9a-f]{64})`"), \
    cite(r"Tâches du pilote : `([0-9a-f]{64})`"), cite(r"Entropie : `([0-9]+)`")
m, _ = lire_manifeste(f"runs/{run}/manifeste.json")
(ok if m["commit"] == s else ko)(f"3a commit du manifeste {m['commit'][:12]}… = S")
pr = m.get("preenregistrement") or {}
sha_p = Path(p + ".sha256").read_text().split()[0]
(ok if pr.get("chemin") == p and pr.get("sha256") == sha_p else ko)(f"3b préenregistrement {pr.get('chemin')} {str(pr.get('sha256'))[:12]}…")
(ok if empreinte_config(m["config"]) == cfg_c else ko)(f"3c configuration du manifeste = configuration citée ({str(cfg_c)[:12]}…)")
ents = {g["entropie"] for g in m["graines"].values()}
(ok if ents == {ent_c} else ko)(f"3d entropie citée ({len(m['graines'])} graines)")
(ok if m["config"].get("mode") == "reel" and m.get("decisif") is True and m.get("depot_propre") is True else ko)(
    f"3e mode {m['config'].get('mode')}, décisif {m.get('decisif')}, dépôt propre {m.get('depot_propre')}")
d = Path("diag") / run
r, a = (d / "resume.json").exists(), (d / "arret.json").exists()
(ok if r != a else ko)(f"4a issue : resume.json {r}, arret.json {a}")
corps = json.loads((d / ("resume.json" if r else "arret.json")).read_text())["resultat"]
t_sha = corps.get("taches_sha256") or corps.get("partiel", {}).get("taches_sha256")
(ok if t_sha == taches_c else ko)(f"4b tâches du run = tâches citées ({str(taches_c)[:12]}…)")
if a:
    print("    arrêt :", json.dumps({x: corps.get(x) for x in ("etape", "motif")}, ensure_ascii=False)[:600])
ep = d / "episodes.json"
if ep.exists():
    v = json.loads(ep.read_text())["resultat"]
    Path("../vecteurs-attendus.txt").write_text(f"{v['vecteurs_sha256']}\n")
    print("    vecteurs attendus :", v["vecteurs_sha256"], v["vecteurs"])
sys.exit(1 if k else 0)
EOF
if [ -f ../vecteurs-attendus.txt ]; then
    VA=$(cat ../vecteurs-attendus.txt)
    if git fetch -q origin "donnees/t05/$RUN" 2>/dev/null; then
        VB=$(git rev-parse FETCH_HEAD)
        [ -z "$(git log --format=%P -1 "$VB")" ] && ok "5a branche donnees/t05/$RUN : un commit sans parent" || ko "5a branche des vecteurs : commit avec parent"
        VS=$(git show "$VB:$RUN/vecteurs-par-action.npz" | sha256sum | cut -d' ' -f1)
        [ "$VS" = "$VA" ] && [ "$(git show "$VB:$RUN/vecteurs-par-action.npz.sha256" | cut -d' ' -f1)" = "$VA" ] \
            && ok "5b vecteurs : empreinte égale au sceau et à episodes.json ($VA)" || ko "5b vecteurs : empreinte $VS ≠ $VA"
    else ko "5a branche donnees/t05/$RUN absente : vecteurs restés sur l'instance ? instance gardée (PL-11)"; fi
else echo "--  5 pas d'episodes.json : aucun vecteur attendu"; fi
# 6. journal de l'instance versé dans les traces de ce run
J=$(printf '%s\n' $NOUVELLES | tail -1)
A=$(sed -n "s/.*Tests attendus : \`\([0-9]*\)\`.*/\1/p" "$P" | head -1)
for motif in "$A tests attendus" "poussée avant l'installation" "disponible True" "tests : $A passed"; do
    grep -qF "$motif" "$J/journal.txt" 2>/dev/null && ok "6 journal ($J) : « $motif »" || ko "6 journal ($J) : « $motif » absent"
done
grep -E "vecteurs (absents|trop gros|: empreinte non conforme|: poussée impossible)" "$J/journal.txt" 2>/dev/null | sed 's/^/KO? journal : /' || true
# 7. aucune valeur de jeton dans le différentiel ni dans les fichiers ajoutés (comptée, jamais affichée)
git diff "$S" "$H" > ../diff-complet.txt
python3 - ../diff-complet.txt ../diff-status.txt <<'EOF' || echecs=$((echecs + 1))
import os, sys
from pathlib import Path
diff = Path(sys.argv[1]).read_bytes()
fichiers = [l.split("\t", 1)[1] for l in Path(sys.argv[2]).read_text().splitlines() if "\t" in l]
k = 0
for nom in ("HF_TOKEN", "CONTROLE_IA_GITHUB_TOKEN", "GH_TOKEN", "VAST_API_KEY"):
    v = os.environ.get(nom)
    if not v or len(v) < 8:
        print(f"KO  7 {nom} absent de l'environnement de la session : recherche impossible"); k += 1; continue
    b = v.encode()
    n = diff.count(b) + sum(Path(f).read_bytes().count(b) for f in fichiers if Path(f).is_file())
    print(("OK " if n == 0 else "KO ") + f" 7 valeur de {nom} : {n} occurrence(s)")
    k += n > 0
sys.exit(1 if k else 0)
EOF
echo "RUN=$RUN"; echo "TETE=$H"
[ "$echecs" = 0 ] && echo "RÉCUPÉRATION : TOUS CONFORMES" || echo "RÉCUPÉRATION : $echecs CONTRÔLE(S) EN ÉCHEC"
