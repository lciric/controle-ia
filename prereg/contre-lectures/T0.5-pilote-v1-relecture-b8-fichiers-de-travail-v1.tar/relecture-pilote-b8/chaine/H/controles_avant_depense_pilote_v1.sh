#!/usr/bin/env bash
# Contrôles avant dépense du pilote de T0.5 (préenregistrement prereg/T0.5-pilote-8B-v1.md), v1, sur le modèle des
# contrôles v7 de la revalidation (docs/procedures/revalidation-T0.5-v2/) et des constats de l'état des lieux du pilote
# (PL-06, PF-02, PF-05, PL-07). Sur un clone neuf du dépôt de travail au commit de scellement S ; aucun calcul payant ;
# code 0 si et seulement si tout est conforme ; code 2 si les épingles manquent ou sont mal formées.
# Ce qui est contrôlé : S ajoute le sceau du préenregistrement ; commit du code cité, ancêtre de S, arbre gelé identique ;
# empreintes des deux scripts de l'instance citées ; configuration et tâches scellées, citées, égales à leur source
# (configuration du brouillon, noyau et duree_max_s mis à part ; 60 premières tâches de la source) ; valeurs du verdict
# recalculées depuis les résultats scellés de la revalidation et la formule gelée (noyau, durée projetée, duree_max_s) ;
# verdict et décision N-019 scellés et cités ; texte de S égal au candidat relu, normalisé (champs du scellement) ;
# rapports attendus présents, scellés, cités, et seuls de leur famille ; branche de résultats absente ; PREREG et
# BRANCHE cités ; problemes() vide ; sceaux ; verifier-arbre ; gardes du lanceur du pilote rejouées ; format des vrais
# tokeniseurs (8B, 3B) contrôlé comme au début du run ; suite complète des tests au commit S dans l'environnement neuf
# (dernière ligne « N passed », N = tests attendus) ; garde de calcul sur le registre de S.
# Usage : controles_avant_depense_pilote_v1.sh S DOSSIER_NEUF [relance]
# « relance » : relancement unique (plan, étape 5) : la branche …-v1 existe sans episodes.json, …-v2 est absente.
set -uo pipefail
S=$1; D=$2; MODE_LANCEMENT=${3:-premier}
DEPOT=https://github.com/lciric/controle-ia-travail.git
CANDIDAT_RELU=15a5cd3e457dd7b6db234bc08ce7378514ec217b8f8099dea426eb3743b33150                 # candidat relu (R2), brut
CANDIDAT_RELU_CHEMIN=brouillons/T0.5-pilote-8B-v1-candidat1.md
CANDIDAT_NORMALISE=fcfb10852ef5a8a288d314e38e0212a229ddee559591271165a51e55fad6b124            # candidat relu, normalisé (champs du scellement masqués)
RAPPORTS_ATTENDUS="T0.5-pilote-v1-etat-des-lieux-resultats-v1.json=8ca0f843b17ba24e78280cd1bf0ba85e2f56639e31a0630ed9779ec96d883011 T0.5-pilote-v1-etat-des-lieux-fichiers-de-travail-v1.tar=59f2d2976b2350a8389b9e5a79735c223fa4b6c2d216a4cea8c068a4713e908b T0.5-pilote-v1-relecture-b8-banc-v1.md=0b5334910dfcf1e9358f5c774eef368c6466d08855b73e8f17c61b404feee4ee"           # paires nom=empreinte (état des lieux, relecture R2)
PY=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/scellement-revalidation/venv-gpu-neuf/bin/python
H=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/pilote-v1
P=prereg/T0.5-pilote-8B-v1.md; CFG=prereg/T0.5-pilote-config-v1.json
CFG_BROUILLON=brouillons/T0.5-pilote-config-v1-brouillon1.json
TACHES=donnees/t05-pilote-v1/taches-pilote-60-v1.json
SOURCE=donnees/20261007-082440-t05-extraction/taches-evaluation.json
SOURCE_SHA=76cdeace861d2fff45ca732c55c2d97611dcd47edc7c27d62bdad4c37755e67e
VERDICT=docs/verdicts/verdict-T0.5-revalidation-v2.md; DECISION=docs/decisions/decision-N-019-v1.md
RUN_REVAL=20261011-225701-t05-revalidation-reel
case "$MODE_LANCEMENT" in premier) BRANCHE=calcul/t05-pilote-reel-v1 ;; relance) BRANCHE=calcul/t05-pilote-reel-v2 ;;
    *) echo "troisième argument : relance, ou rien"; exit 2 ;; esac
echec=0; ok() { echo "OK  $*"; }; ko() { echo "KO  $*"; echec=1; }
[[ "$S" =~ ^[0-9a-f]{40}$ ]] || { echo "S invalide"; exit 2; }
[ -e "$D" ] && { echo "$D existe déjà"; exit 2; }
[[ "$CANDIDAT_RELU" =~ ^[0-9a-f]{64}$ && "$CANDIDAT_NORMALISE" =~ ^[0-9a-f]{64}$ && "$CANDIDAT_RELU_CHEMIN" == brouillons/* ]] \
    || { echo "candidat relu non épinglé"; exit 2; }
n_paires=0
for paire in $RAPPORTS_ATTENDUS; do [[ "$paire" =~ ^[^=]+=[0-9a-f]{64}$ ]] || { echo "rapports attendus mal formés : $paire"; exit 2; }; n_paires=$((n_paires+1)); done
[ "$n_paires" -ge 1 ] || { echo "liste des rapports attendus vide"; exit 2; }
git clone -q "$DEPOT" "$D" || { echo "clonage impossible"; exit 2; }
cd "$D" && git checkout -q "$S" || { echo "commit $S introuvable"; exit 2; }
[ "$(git log --diff-filter=A -1 --format=%H -- "$P.sha256")" = "$S" ] && ok "S ajoute le sceau du préenregistrement" || ko "S n'est pas le commit qui ajoute $P.sha256"
attendus_s=$(printf '%s\n' "$CFG" "$CFG.sha256" "$P" "$P.sha256" | sort | tr '\n' ' ')
[ "$(git diff --name-only "$S^" "$S" | sort | tr '\n' ' ')" = "$attendus_s" ] && ok "S n'ajoute que le préenregistrement, la configuration et leurs sceaux" || ko "contenu de S inattendu : $(git diff --name-only "$S^" "$S" | tr '\n' ' ')"
CODE=$(sed -n "s/.*Commit du code d'analyse : \`\([0-9a-f]\{40\}\)\`.*/\1/p" "$P" | head -1)
if [[ "$CODE" =~ ^[0-9a-f]{40}$ ]] && git merge-base --is-ancestor "$CODE" "$S"; then ok "commit du code cité $CODE, ancêtre de S"
else ko "commit du code cité illisible ou non ancêtre de S"; CODE=$S; fi
for f in scripts/amorce_instance_t05.sh scripts/pilote_t05_instance.sh; do
    e=$(git show "$S:$f" | sha256sum | cut -d' ' -f1)
    grep -qF "\`$f\` (\`$e\`, sha256)" "$P" && ok "empreinte de $f citée ($e)" || ko "empreinte de $f ($e) non citée"
done
GELES=$(PYTHONPATH=src "$PY" -c "from controle_ia.harnais.validation_reelle import CHEMINS_GELES; print(' '.join(CHEMINS_GELES))" 2>/dev/null)
if [ -n "$GELES" ]; then
    # shellcheck disable=SC2086
    git diff --quiet "$CODE" "$S" -- $GELES; c=$?
    case $c in 0) ok "arbre gelé (CHEMINS_GELES) identique au commit du code" ;; 1) ko "arbre gelé modifié depuis le commit du code" ;;
               *) ko "comparaison de l'arbre gelé impossible (code $c)" ;; esac
else ko "CHEMINS_GELES illisible"; fi
for f in "$CFG" "$TACHES" "$SOURCE" "$VERDICT" "$DECISION" "diag/$RUN_REVAL/resume.json" "diag/$RUN_REVAL/mesures-defaut.json" \
         "diag/$RUN_REVAL/lecture-defaut.json" "diag/$RUN_REVAL/lecture-math.json"; do
    if git cat-file -e "$S:$f" 2>/dev/null && git cat-file -e "$S:$f.sha256" 2>/dev/null && \
       [ "$(git show "$S:$f.sha256")" = "$(git show "$S:$f" | sha256sum | cut -d' ' -f1)  $(basename "$f")" ]; then
        ok "$f et son sceau entier dans l'arbre de S"
    else ko "$f ou son sceau absent ou non conforme"; fi
done
for f in "$VERDICT" "$DECISION" "$TACHES"; do
    e=$(git show "$S:$f" | sha256sum | cut -d' ' -f1)
    grep -qF "$e" "$P" && ok "$f cité par son empreinte ($e)" || ko "$f non cité par son empreinte"
done
# texte de S = candidat relu, normalisé ; candidat versé, scellé, à l'empreinte épinglée
[ "$(git show "$S:$CANDIDAT_RELU_CHEMIN" 2>/dev/null | sha256sum | cut -d' ' -f1)" = "$CANDIDAT_RELU" ] && \
    [ "$(git show "$S:$CANDIDAT_RELU_CHEMIN.sha256" 2>/dev/null)" = "$CANDIDAT_RELU  $(basename "$CANDIDAT_RELU_CHEMIN")" ] \
    && ok "candidat relu versé, scellé, à l'empreinte épinglée" || ko "candidat relu absent, non scellé ou d'empreinte différente"
n=$("$PY" -I "$H/normaliser_pilote_v1.py" "$P")
[ "$n" = "$CANDIDAT_NORMALISE" ] && ok "préenregistrement de S = candidat relu, normalisé ($n)" || ko "préenregistrement de S ≠ candidat relu normalisé ($n)"
nc=$(git show "$S:$CANDIDAT_RELU_CHEMIN" | "$PY" -I "$H/normaliser_pilote_v1.py" -)
[ "$nc" = "$CANDIDAT_NORMALISE" ] && ok "épingle normalisée = candidat relu normalisé" || ko "épingle normalisée ≠ candidat relu normalisé ($nc)"
# rapports attendus : présents à S, scellés, cités ; seuls de leur famille
for paire in $RAPPORTS_ATTENDUS; do
    nom=${paire%%=*}; e=${paire#*=}; f="prereg/contre-lectures/$nom"
    [ "$(git show "$S:$f" 2>/dev/null | sha256sum | cut -d' ' -f1)" = "$e" ] && [ "$(git show "$S:$f.sha256" 2>/dev/null)" = "$e  $nom" ] \
        && grep -qF "\`$f\` (\`$e\`)" "$P" && ok "rapport $nom présent, scellé, cité" || ko "rapport $nom absent, non scellé, d'empreinte différente ou non cité"
done
presents=$(git ls-tree -r --name-only "$S" prereg/contre-lectures/ | grep -E '^prereg/contre-lectures/T0\.5-pilote-v1-(etat-des-lieux|relecture-b8)-[a-z0-9-]+-v1\.(md|json|tar)$' | xargs -r -n1 basename | sort | tr '\n' ' ')
attendus=$(for paire in $RAPPORTS_ATTENDUS; do echo "${paire%%=*}"; done | sort | tr '\n' ' ')
[ "$presents" = "$attendus" ] && ok "rapports du pilote présents à S = rapports attendus ($n_paires)" || ko "rapports présents « $presents » ≠ attendus « $attendus »"
# branche de résultats ; relance : -v1 présente sans episodes.json
case "$MODE_LANCEMENT" in
premier) git ls-remote --exit-code origin "refs/heads/$BRANCHE" >/dev/null 2>&1; c=$?
         [ "$c" = 2 ] && ok "branche $BRANCHE absente" || ko "branche $BRANCHE : code $c (2 attendu)" ;;
relance) git ls-remote --exit-code origin refs/heads/calcul/t05-pilote-reel-v2 >/dev/null 2>&1; c=$?
         [ "$c" = 2 ] && ok "branche de relance absente" || ko "branche de relance : code $c (2 attendu)"
         if git fetch -q origin calcul/t05-pilote-reel-v1 2>/dev/null; then
             git ls-tree -r --name-only FETCH_HEAD | grep -q '/episodes\.json$' && ko "-v1 porte un episodes.json : relancement interdit (préséance)" \
                 || ok "-v1 présente, sans episodes.json"
         else ko "-v1 absente : pas de relancement"; fi ;;
esac
grep -qF "\`PREREG=$P\`, \`BRANCHE=$BRANCHE\`" "$P" && ok "PREREG et BRANCHE ($BRANCHE) cités par la ligne « Lancement »" || ko "PREREG ou BRANCHE : la ligne « Lancement » cite autre chose"
PYTHONPATH=src "$PY" -c "from controle_ia.prereg import problemes; p = problemes('$P'); print(p); raise SystemExit(1 if p else 0)" \
    && ok "problemes() vide" || ko "problemes() non vide"
PYTHONPATH=src "$PY" -m controle_ia.scellement verifier "$P" "$CFG" "$TACHES" "$SOURCE" >/dev/null \
    && ok "sceaux du préenregistrement, de la configuration et des tâches" || ko "sceaux"
PYTHONPATH=src "$PY" -m controle_ia.scellement verifier-arbre . | tail -1 | grep -q "arbre intact" && ok "verifier-arbre : arbre intact" || ko "verifier-arbre"
# valeurs, configuration, tâches, gardes du lanceur, format des vrais tokeniseurs
PYTHONPATH=src "$PY" - "$P" "$CFG" "$CFG_BROUILLON" "$TACHES" "$SOURCE" "$SOURCE_SHA" "$RUN_REVAL" <<'EOF' && ok "valeurs du verdict, configuration, tâches et gardes du lanceur" || ko "valeurs, configuration, tâches ou gardes du lanceur"
import hashlib, json, math, sys
from pathlib import Path
from controle_ia.environnements import lancer_pilote_a as lp
from controle_ia.environnements.pilote_a import charger_taches, exiger_config
from controle_ia.environnements.revalider_pilote_a import choisir_noyau
from controle_ia.harnais.validation_reelle import exiger_code_cite, exiger_code_importe_sous
from controle_ia.manifeste import verifier_resultat
from controle_ia.scellement import verifier
p, cfg, brouillon, taches, source, source_sha, run = sys.argv[1:8]
mes = verifier_resultat(Path("."), Path(f"diag/{run}/mesures-defaut.json"))["resultat"]
res = verifier_resultat(Path("."), Path(f"diag/{run}/resume.json"))["resultat"]
lec = verifier_resultat(Path("."), Path(f"diag/{run}/lecture-defaut.json"))["resultat"]["lecture"]
lm = verifier_resultat(Path("."), Path(f"diag/{run}/lecture-math.json"))["resultat"]["lecture"]
assert res["noeud"] is True and res["noyau_retenu"] is None, "le verdict n'est pas le nœud tranché par N-019"
assert all(lec[k] is True for k in ("R1_garde_saine", "R1_marge", "R3_seuil_fonde", "R4_rejeu", "R5_domaine_couvert",
                                    "R6_chemin_defaut", "R7_memoire", "audit_conforme")) and lec["R2_controle_negatif"] == "conforme"
d = (mes["chrono"]["generation_s"] + mes["chrono"]["passe_unique_s"]) * 60 * 3 / 16
assert d <= 7800, d
duree = min(15000, math.ceil((1.2 * d + 7200) / 60) * 60)
noyau, _ = choisir_noyau({"defaut": dict(lec, R8_duree=True, conforme=True, conforme_avec_marge=True), "math": lm})
c = json.loads(Path(cfg).read_text(encoding="utf-8"))
b = json.loads(Path(brouillon).read_text(encoding="utf-8"))
assert c["noyau_attention"] == noyau == "defaut" and c["duree_max_s"] == duree == 15000, (c["noyau_attention"], c["duree_max_s"], noyau, duree)
assert {k: v for k, v in c.items() if k not in ("noyau_attention", "duree_max_s")} == \
       {k: v for k, v in b.items() if k not in ("noyau_attention", "duree_max_s")} and set(c) == set(b), "configuration ≠ brouillon"
texte = Path(p).read_text(encoding="utf-8")
assert f"noyau d'attention du pilote : `{noyau}`" in texte and "`15 000` s" in texte and "`7 584,02` s" in texte, "valeurs non citées"
assert f"{d:.2f}" == "7584.02", d
# tâches : 60 premières de la source, à l'identique
verifier(source)
assert hashlib.sha256(Path(source).read_bytes()).hexdigest() == source_sha
t = charger_taches(taches)
src = json.loads(Path(source).read_text(encoding="utf-8"))["resultat"]["taches"]
assert t == src[:60] and len(t) == 60, "tâches ≠ 60 premières de la source"
# gardes du lanceur, dans l'ordre d'executer()
exiger_config(c)
assert not [k for k in lp.CLES_LANCEMENT if k not in c] and c["mode"] == "reel" and c["noyau_attention"] in lp.NOYAUX
assert not isinstance(c["duree_max_s"], bool) and 0 < c["duree_max_s"] <= lp.DUREE_MAX_S
sha_t = verifier(taches)
lp.exiger_cibles(t)
lp.exiger_invites(c)
exiger_code_importe_sous(Path("."))
print("commit cité :", exiger_code_cite(Path("."), Path(p)), "; entropie citée :", lp.exiger_citations_pilote(Path(p), c, sha_t))
print(f"durée projetée {d:.4f} s ; duree_max_s {duree} ; noyau {noyau}")
EOF
HF_HOME="$D/../cache-hf-$$" PYTHONPATH=src "$PY" - "$CFG" <<'EOF' && ok "format des vrais tokeniseurs (agent 8B, juge 3B) et jetons de l'appariement : gardes du run conformes" || ko "format des tokeniseurs réels"
import json, sys
from pathlib import Path
from controle_ia.environnements import lancer_pilote_a as lp
c = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
from controle_ia.environnements import pilote_a as pa
fmt_agent = lp.charger_format_seul(c["agent"], "reel")
print(lp.controler_format(fmt_agent, c["agent"], "agent", c)["texte_attendu_ouverture"])
print("jetons Yes/No de l'appariement (vrai tokeniseur du 8B) :", pa.jetons_oui_non(fmt_agent.tok))
for j in c["juges"]:
    fmt = fmt_agent if j["meme_modele_que_agent"] else lp.charger_format_seul(j, "reel")
    print(j["nom"], lp.controler_format(fmt, j, "juge", c)["texte_attendu_ouverture"])
EOF
rm -rf "$D/../cache-hf-$$"
a=$(sed -n "s/.*Tests attendus : \`\([0-9]*\)\`.*/\1/p" "$P" | head -1)
PYTHONPATH=src "$PY" -m pytest -q -p no:cacheprovider > "$D/../suite-$$.txt" 2>&1; cs=$?
derniere=$(grep -v '^$' "$D/../suite-$$.txt" | tail -1); cp "$D/../suite-$$.txt" "$D/../suite-pilote-S.txt" 2>/dev/null; rm -f "$D/../suite-$$.txt"
[ "$cs" = 0 ] && [[ "$derniere" =~ ^$a\ passed(,\ [0-9]+\ warnings?)?\ in\ [0-9.]+s(\ \([0-9]+:[0-9]{2}:[0-9]{2}\))?$ ]] \
    && ok "suite complète au commit S, environnement neuf : « $derniere »" || ko "suite complète : « $derniere » (code $cs ; $a attendus)"
echo '{"tool_input":{"command":"GO_ID=GO-2026-10-04-08 vastai create instance 1 --raw"}}' | python3 .claude/hooks/garde_calcul.py \
    && ok "garde de calcul : registres/go.md de S lisible, GO-2026-10-04-08 accepté" || ko "garde de calcul sur le registre de S"
lire() { sed -n "s/.*$1 : \`\\([^\`]*\\)\`.*/\\1/p" "$P" | head -1; }
echo "lecture précoce (script de l'instance, PREREG=$P) : tests $a ; configuration $(lire "Chemin de la configuration") ; tâches $(lire "Chemin des tâches")"
[ "$(lire "Chemin de la configuration")" = "$CFG" ] && [ "$(lire "Chemin des tâches")" = "$TACHES" ] && ok "lecture précoce : chemins attendus" || ko "lecture précoce : chemins inattendus"
[ "$echec" = 0 ] && echo "CONTRÔLES AVANT DÉPENSE : TOUS CONFORMES" || echo "CONTRÔLES AVANT DÉPENSE : ÉCHEC"
[ "$echec" = 0 ]
