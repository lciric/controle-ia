#!/usr/bin/env bash
# Suite du banc du scellement : artefacts dont le commit jetable doit atteindre le dépôt nu (récupération par fetch dans
# le dépôt nu, depuis le clone de relecture). Même copie du scellement, même bloc-notes factice H.
set -uo pipefail
C=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-pilote-b8/chaine
K=$C/clone; H=$C/H; N=$C/distant.git
V=docs/procedures/pilote-T0.5-v1
P=prereg/T0.5-pilote-8B-v1.md; CFG=prereg/T0.5-pilote-config-v1.json
RF=prereg/contre-lectures/T0.5-pilote-v1-relecture-b8-banc-v1.md
J=$(git -C "$K" rev-parse banc-scellement)
[ "$(git -C "$K" remote get-url --push origin)" = "$N" ] && [ "$(git -C "$K" remote get-url origin)" = "$N" ] || { echo "origine inattendue"; exit 2; }
grep -n "controle-ia-travail\|github" "$H/sceller_pilote_v1.sh" && { echo "COPIE NON SÛRE"; exit 2; }
passage() {
    local n=$1 avant c
    avant=$(git -C "$K" rev-parse HEAD)
    (cd "$C" && bash "$H/sceller_pilote_v1.sh") > "$C/journaux/scellement-$n.log" 2>&1; c=$?
    echo "$n : code $c ; $(grep -v '^$' "$C/journaux/scellement-$n.log" | tail -2 | tr '\n' '|' | cut -c1-300)"
    echo "    HEAD $(git -C "$K" rev-parse --short HEAD) (avant $(git -C "$K" rev-parse --short "$avant")) ; distant main $(git -C "$N" rev-parse --short main) ; fichiers du scellement présents : $(cd "$K" && ls "$P" "$P.sha256" "$CFG" "$CFG.sha256" 2>/dev/null | tr '\n' ' ')"
    echo "    suivi propre : $([ -z "$(git -C "$K" status --porcelain --untracked-files=no)" ] && echo oui || echo NON)"
}
remise() {   # $1 commit : banc-scellement, clone et dépôt nu (par fetch dans le dépôt nu) remis sur ce commit
    git -C "$K" checkout -q -f banc-scellement; git -C "$K" reset -q --hard "$1"
    (cd "$K" && rm -f "$P" "$P.sha256" "$CFG" "$CFG.sha256")
    git -C "$N" fetch -q "$K" +refs/heads/banc-scellement:refs/heads/main
    git -C "$K" fetch -q origin
    [ "$(git -C "$N" rev-parse main)" = "$(git -C "$K" rev-parse HEAD)" ] || echo "    !! dépôt nu non aligné"
}
cp "$H/controles_avant_depense_pilote_v1.sh" "$C/ctl-pin-sain.sh"
verse_ctl() {   # copie versée des contrôles = celle du bloc-notes factice, re-scellée, committée
    cp "$H/controles_avant_depense_pilote_v1.sh" "$K/$V/controles_avant_depense_pilote_v1.sh"
    (cd "$K/$V" && sha256sum controles_avant_depense_pilote_v1.sh > controles_avant_depense_pilote_v1.sh.sha256)
    git -C "$K" commit -qam "essai : $1" && git -C "$K" rev-parse HEAD
}
echo "== B2bis sceau d'un fichier versé faussé : échec de verifier-arbre après la copie (piège EXIT)"
remise "$J"
printf '%s  recuperation_pilote_v1.sh\n' "$(printf '0%.0s' {1..64})" > "$K/$V/recuperation_pilote_v1.sh.sha256"
git -C "$K" commit -qam "essai : sceau faussé"; J2=$(git -C "$K" rev-parse HEAD); remise "$J2"
passage B2bis-sceau-fausse
ls -d "$H"/scellement-* | sed 's/^/    dossiers de travail du bloc-notes factice : /'
echo "== B4bis épingle normalisée fausse (bloc-notes et copie versée)"
remise "$J"
sed -i "s|^CANDIDAT_NORMALISE=fcfb1085[0-9a-f]*|CANDIDAT_NORMALISE=$(printf '1%.0s' {1..64})|" "$H/controles_avant_depense_pilote_v1.sh"
J4=$(verse_ctl "épingle normalisée fausse"); remise "$J4"
passage B4bis-epingle-normalisee-fausse
cp "$C/ctl-pin-sain.sh" "$H/controles_avant_depense_pilote_v1.sh"
echo "== B4c épingle brute du candidat fausse"
remise "$J"
sed -i "s|^CANDIDAT_RELU=15a5cd3e[0-9a-f]*|CANDIDAT_RELU=$(printf '2%.0s' {1..64})|" "$H/controles_avant_depense_pilote_v1.sh"
J5=$(verse_ctl "épingle brute fausse"); remise "$J5"
passage B4c-epingle-brute-fausse
cp "$C/ctl-pin-sain.sh" "$H/controles_avant_depense_pilote_v1.sh"
echo "== B8bis rapport de la relecture épinglé, absent du commit (générateur en échec après le piège)"
remise "$J"
git -C "$K" rm -q "$RF" "$RF.sha256" && git -C "$K" commit -qm "essai : rapport retiré"; J3=$(git -C "$K" rev-parse HEAD); remise "$J3"
passage B8bis-rapport-absent
echo "== B9 épingles des rapports sans rapport de la relecture"
remise "$J"
sed -i 's| T0\.5-pilote-v1-relecture-b8-banc-v1\.md=[0-9a-f]*"|"|' "$H/controles_avant_depense_pilote_v1.sh"
grep -c "relecture-b8" "$H/controles_avant_depense_pilote_v1.sh" | sed 's/^/    lignes « relecture-b8 » restantes dans les contrôles : /'
J6=$(verse_ctl "épingles sans relecture"); remise "$J6"
passage B9-epingles-sans-relecture
cp "$C/ctl-pin-sain.sh" "$H/controles_avant_depense_pilote_v1.sh"
echo "== B10 candidat épinglé : un autre fichier sous brouillons/ (brouillon 8 lui-même, empreintes brute et normalisée à lui)"
remise "$J"
B8SHA=$(sha256sum "$K/brouillons/T0.5-pilote-8B-v1-brouillon8.md" | cut -d' ' -f1)
B8N=$(/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/scellement-revalidation/venv-gpu-neuf/bin/python -I -B "$H/normaliser_pilote_v1.py" "$K/brouillons/T0.5-pilote-8B-v1-brouillon8.md")
sed -i -e "s|^CANDIDAT_RELU=15a5cd3e[0-9a-f]*|CANDIDAT_RELU=$B8SHA|" -e "s|^CANDIDAT_RELU_CHEMIN=.*|CANDIDAT_RELU_CHEMIN=brouillons/T0.5-pilote-8B-v1-brouillon8.md|" \
    -e "s|^CANDIDAT_NORMALISE=fcfb1085[0-9a-f]*|CANDIDAT_NORMALISE=$B8N|" "$H/controles_avant_depense_pilote_v1.sh"
J7=$(verse_ctl "candidat = brouillon 8"); remise "$J7"
passage B10-candidat-brouillon8
cp "$C/ctl-pin-sain.sh" "$H/controles_avant_depense_pilote_v1.sh"
remise "$J"
git -C "$K" status --short | head -5
echo "FIN DE LA SUITE DU BANC DU SCELLEMENT"
