#!/usr/bin/env bash
# Banc du générateur du pilote (relecture R2 b8, angle « chaîne ») : artefacts, chacun sur un commit jetable du clone de
# relecture (jamais le dépôt de travail). Copie du générateur et du normaliseur sous H0 (identiques au bloc-notes).
set -uo pipefail
C=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-pilote-b8/chaine
K=$C/clone
PYN=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/scellement-revalidation/venv-gpu-neuf/bin/python
BASE=942c65e365f809b7142b280b4adc1922ce3ab67c
Z=$(printf '0%.0s' {1..64})
ETAT="T0.5-pilote-v1-etat-des-lieux-resultats-v1.json=8ca0f843b17ba24e78280cd1bf0ba85e2f56639e31a0630ed9779ec96d883011,T0.5-pilote-v1-etat-des-lieux-fichiers-de-travail-v1.tar=59f2d2976b2350a8389b9e5a79735c223fa4b6c2d216a4cea8c068a4713e908b"
REL="T0.5-pilote-v1-relecture-b8-a-venir-v1.md=$Z"
TACHES=donnees/t05-pilote-v1/taches-pilote-60-v1.json
G=$C/gen
gen() {   # $1 nom ; $2 mode ; $3 date ; puis arguments ajoutés ; COMMIT_ARG, ENT, TACHES_ARG, ETAT_ARG, REL_ARG, SORTIE_P remplacent
    local n=$1 mode=$2 date=$3; shift 3
    mkdir -p "$G/$n"
    local sp=${SORTIE_P:-$G/$n/prereg.md}
    (cd "$K" && PYTHONDONTWRITEBYTECODE=1 "$PYN" -I -B "$C/H0/remplir_pilote_v1.py" "$K" "${COMMIT_ARG:-$(git -C "$K" rev-parse HEAD)}" "$mode" "$date" \
        "${ENT:-$G/entropie-1.txt}" "$sp" "$G/$n/config.json" --taches "${TACHES_ARG:-$TACHES}" \
        --rapports-etat "${ETAT_ARG:-$ETAT}" --rapports-relecture "${REL_ARG:-$REL}" "$@" > "$G/$n/sortie.json" 2> "$G/$n/erreurs.txt")
    local c=$?
    echo "$n : code $c ; $(grep -v '^$' "$G/$n/erreurs.txt" | tail -1 | cut -c1-260)"
    if [ -f "$G/$n/prereg.md" ] && [ "$sp" = "$G/$n/prereg.md" ]; then
        echo "    texte écrit ; normalisé $("$PYN" -I -B "$C/H0/normaliser_pilote_v1.py" "$G/$n/prereg.md")"
    fi
}
jetable() { git -C "$K" checkout -q -f -B essai "$BASE"; }
sceller_ici() { (cd "$K/$(dirname "$1")" && sha256sum "$(basename "$1")" > "$(basename "$1").sha256"); }
valider() { git -C "$K" add -f -- "$@" && git -C "$K" commit -qm "essai : $*" >/dev/null; }
retour() { git -C "$K" checkout -q -f main; git -C "$K" branch -q -D essai 2>/dev/null; [ -z "$(git -C "$K" status --porcelain --untracked-files=no)" ] || echo "    !! clone sale après le cas"; }
echo "== A1 (repris, ajout forcé) tâches modifiées (une tâche altérée), re-scellées"
jetable
"$PYN" -I - "$K/$TACHES" <<'PY'
import json, sys
p = sys.argv[1]; d = json.load(open(p, encoding="utf-8"))
d["taches"][59]["identifiant"] = d["taches"][59]["identifiant"] + "-altere"
open(p, "w", encoding="utf-8").write(json.dumps(d, ensure_ascii=False, indent=1) + "\n")
PY
sceller_ici "$TACHES"; valider "$TACHES" "$TACHES.sha256"
git -C "$K" status --porcelain --untracked-files=no | head -2
gen A1r-taches-modifiees-rescellees candidat "2026-10-12 01:29 UTC"
retour
echo "== A1b (repris) tâches modifiées, sceau laissé"
jetable
sed -i '0,/"identifiant"/s/"identifiant"/"identifiant" /' "$K/$TACHES"; valider "$TACHES"
gen A1br-taches-modifiees-sans-sceau candidat "2026-10-12 01:29 UTC"
retour
echo "== A1c (repris) tâches : 59 premières, dérivées et scellées au même chemin"
jetable
rm -f "$K/$TACHES"
(cd "$K" && "$PYN" -I -B "$C/H0/deriver_taches_pilote_v1.py" donnees/20261007-082440-t05-extraction/taches-evaluation.json \
    76cdeace861d2fff45ca732c55c2d97611dcd47edc7c27d62bdad4c37755e67e 59 "$TACHES" > /dev/null)
sceller_ici "$TACHES"; valider "$TACHES" "$TACHES.sha256"
gen A1cr-taches-59 candidat "2026-10-12 01:29 UTC"
retour
echo "== A6b (repris) mode réel, date à plus d'une heure de l'horloge"
gen A6br-reel-date-ancienne reel "2026-10-11 20:00 UTC" --candidat-relu brouillons/T0.5-pilote-8B-v1-candidat1.md
echo "== A14 mesures du bras « defaut » : génération + 1 s, re-scellées"
MES=diag/20261011-225701-t05-revalidation-reel/mesures-defaut.json
jetable
"$PYN" -I - "$K/$MES" <<'PY'
import json, sys
p = sys.argv[1]; d = json.load(open(p, encoding="utf-8"))
d["resultat"]["chrono"]["generation_s"] += 1.0
open(p, "w", encoding="utf-8").write(json.dumps(d, ensure_ascii=False, indent=1) + "\n")
PY
sceller_ici "$MES"; valider "$MES" "$MES.sha256"
gen A14-mesures-modifiees-rescellees candidat "2026-10-12 01:29 UTC"
retour
echo "== A15 résumé de la revalidation : noeud faux, re-scellé"
RES=diag/20261011-225701-t05-revalidation-reel/resume.json
jetable
"$PYN" -I - "$K/$RES" <<'PY'
import json, sys
p = sys.argv[1]; d = json.load(open(p, encoding="utf-8"))
d["resultat"]["noeud"] = False
open(p, "w", encoding="utf-8").write(json.dumps(d, ensure_ascii=False, indent=1) + "\n")
PY
sceller_ici "$RES"; valider "$RES" "$RES.sha256"
gen A15-resume-sans-noeud candidat "2026-10-12 01:29 UTC"
retour
git -C "$K" log --oneline -1
echo "FIN DU BANC B DU GÉNÉRATEUR"
