#!/usr/bin/env bash
# Suite C du banc du scellement : code modifié après la relecture. B11 : changement dans src/ (hors des empreintes citées) ;
# B12 : changement dans le script de l'instance (empreinte citée par le texte). Même copie du scellement, même dépôt nu.
set -uo pipefail
C=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-pilote-b8/chaine
K=$C/clone; H=$C/H; N=$C/distant.git
PYN=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/scellement-revalidation/venv-gpu-neuf/bin/python
P=prereg/T0.5-pilote-8B-v1.md; CFG=prereg/T0.5-pilote-config-v1.json
J=$(git -C "$K" rev-parse banc-scellement)
[ "$(git -C "$K" remote get-url --push origin)" = "$N" ] && [ "$(git -C "$K" remote get-url origin)" = "$N" ] || { echo "origine inattendue"; exit 2; }
grep -n "controle-ia-travail\|github" "$H/sceller_pilote_v1.sh" && { echo "COPIE NON SÛRE"; exit 2; }
passage() {
    local n=$1 c
    (cd "$C" && bash "$H/sceller_pilote_v1.sh") > "$C/journaux/scellement-$n.log" 2>&1; c=$?
    echo "$n : code $c ; $(grep -v '^$' "$C/journaux/scellement-$n.log" | tail -2 | tr '\n' '|' | cut -c1-260)"
    echo "    HEAD $(git -C "$K" rev-parse --short HEAD) ; distant main $(git -C "$N" rev-parse --short main) ; fichiers du scellement présents : $(cd "$K" && ls "$P" "$P.sha256" "$CFG" "$CFG.sha256" 2>/dev/null | tr '\n' ' ')"
}
remise() {
    git -C "$K" checkout -q -f banc-scellement; git -C "$K" reset -q --hard "$1"
    (cd "$K" && rm -f "$P" "$P.sha256" "$CFG" "$CFG.sha256")
    git -C "$N" fetch -q "$K" +refs/heads/banc-scellement:refs/heads/main; git -C "$K" fetch -q origin
}
echo "== B11 code de src/ modifié après la relecture (énoncé de contrôle du format), committé avant le scellement"
remise "$J"
sed -i 's/^ENONCE_DE_CONTROLE = "Which routing rule makes sparse mixtures of experts train stably?"/ENONCE_DE_CONTROLE = "Which routing rule makes sparse mixtures of experts train stably? (modifié après la relecture)"/' \
    "$K/src/controle_ia/environnements/lancer_pilote_a.py"
git -C "$K" commit -qam "essai : code modifié après la relecture" && J8=$(git -C "$K" rev-parse HEAD)
echo "    arbre gelé entre le commit du candidat relu (3ffab9f) et J8 : $(git -C "$K" diff --name-only 3ffab9ff88761e73074c820b0cb456e51de9c575 "$J8" -- src scripts tests | tr '\n' ' ')"
remise "$J8"
passage B11-code-src-modifie
if [ "$(git -C "$K" rev-parse HEAD)" != "$J8" ]; then
    echo "    commit cité par le texte scellé : $(sed -n "s/.*Commit du code d'analyse : \`\([0-9a-f]*\)\`.*/\1/p" "$K/$P" | cut -c1-12) (J8 ${J8:0:12}) ; normalisé $("$PYN" -I -B "$C/H0/normaliser_pilote_v1.py" "$K/$P")"
    echo "    ligne de l'énoncé dans le code cité : $(git -C "$K" show HEAD:src/controle_ia/environnements/lancer_pilote_a.py | grep -c 'modifié après la relecture') occurrence(s)"
fi
echo "== B12 script de l'instance modifié après la relecture (une ligne de commentaire)"
remise "$J"
printf '# modifié après la relecture\n' >> "$K/scripts/pilote_t05_instance.sh"
git -C "$K" commit -qam "essai : script de l'instance modifié" && J9=$(git -C "$K" rev-parse HEAD)
remise "$J9"
passage B12-script-instance-modifie
remise "$J"
echo "FIN DE LA SUITE C"
