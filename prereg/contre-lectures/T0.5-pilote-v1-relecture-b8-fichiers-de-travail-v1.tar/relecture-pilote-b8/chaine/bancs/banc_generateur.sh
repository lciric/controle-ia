#!/usr/bin/env bash
# Banc du générateur du pilote (relecture R2 b8, angle « chaîne ») : artefacts, chacun sur un commit jetable du clone de
# relecture (jamais le dépôt de travail). Copie du générateur et du normaliseur sous H0 (identiques au bloc-notes).
set -uo pipefail
C=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-pilote-b8/chaine
K=$C/clone
PYN=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/scellement-revalidation/venv-gpu-neuf/bin/python
BASE=942c65e365f809b7142b280b4adc1922ce3ab67c
Z=$(printf '0%.0s' {1..64})
ETAT="T0.5-pilote-v1-etat-des-lieux-resultats-v1.json=8ca0f843b17ba24e78280cd1bf0ba85e2f56639e31a0630ed9779ec96d883011,T0.5-pilote-v1-etat-des-lieux-fichiers-de-travail-v1.tar=59f2d2976b2350a8389b9e5a79735c223fa4b6c2d216a4cea8c068a4713e908b"
REL="T0.5-pilote-v1-relecture-b8-a-venir-v1.md=$Z"
TACHES=donnees/t05-pilote-v1/taches-pilote-60-v1.json
G=$C/gen
gen() {   # $1 nom ; $2 mode ; $3 date ; puis arguments ajoutés ; COMMIT_ARG, ENT, TACHES_ARG, ETAT_ARG, REL_ARG, SORTIE_P remplacent
    local n=$1 mode=$2 date=$3; shift 3
    mkdir -p "$G/$n"
    local sp=${SORTIE_P:-$G/$n/prereg.md}
    (cd "$K" && PYTHONDONTWRITEBYTECODE=1 "$PYN" -I -B "$C/H0/remplir_pilote_v1.py" "$K" "${COMMIT_ARG:-$(git -C "$K" rev-parse HEAD)}" "$mode" "$date" \
        "${ENT:-$G/entropie-1.txt}" "$sp" "$G/$n/config.json" --taches "${TACHES_ARG:-$TACHES}" \
        --rapports-etat "${ETAT_ARG:-$ETAT}" --rapports-relecture "${REL_ARG:-$REL}" "$@" > "$G/$n/sortie.json" 2> "$G/$n/erreurs.txt")
    local c=$?
    echo "$n : code $c ; $(grep -v '^$' "$G/$n/erreurs.txt" | tail -1 | cut -c1-260)"
    if [ -f "$G/$n/prereg.md" ] && [ "$sp" = "$G/$n/prereg.md" ]; then
        echo "    texte écrit ; normalisé $("$PYN" -I -B "$C/H0/normaliser_pilote_v1.py" "$G/$n/prereg.md")"
    fi
}
jetable() { git -C "$K" checkout -q -f -B essai "$BASE"; }
sceller_ici() { (cd "$K/$(dirname "$1")" && sha256sum "$(basename "$1")" > "$(basename "$1").sha256"); }
valider() { git -C "$K" add -A -- "$@" && git -C "$K" commit -qm "essai : $*" >/dev/null; }
retour() { git -C "$K" checkout -q -f main; git -C "$K" branch -q -D essai 2>/dev/null; [ -z "$(git -C "$K" status --porcelain --untracked-files=no)" ] || echo "    !! clone sale après le cas"; }

echo "== cas sain rejoué (candidat, au commit $BASE)"
gen S0-sain candidat "2026-10-12 01:29 UTC"

echo "== A1 tâches modifiées (une tâche altérée), re-scellées"
jetable
"$PYN" -I - "$K/$TACHES" <<'PY'
import json, sys
p = sys.argv[1]; d = json.load(open(p, encoding="utf-8"))
d["taches"][59]["identifiant"] = d["taches"][59]["identifiant"] + "-altere"
open(p, "w", encoding="utf-8").write(json.dumps(d, ensure_ascii=False, indent=1) + "\n")
PY
sceller_ici "$TACHES"; valider "$TACHES" "$TACHES.sha256"
gen A1-taches-modifiees-rescellees candidat "2026-10-12 01:29 UTC"
retour

echo "== A1b tâches modifiées, sceau laissé"
jetable
sed -i '0,/"identifiant"/s/"identifiant"/"identifiant" /' "$K/$TACHES"; valider "$TACHES"
gen A1b-taches-modifiees-sans-sceau candidat "2026-10-12 01:29 UTC"
retour

echo "== A1c tâches : 59 premières, dérivées et scellées au même chemin"
jetable
rm -f "$K/$TACHES"
(cd "$K" && "$PYN" -I -B "$C/H0/deriver_taches_pilote_v1.py" donnees/20261007-082440-t05-extraction/taches-evaluation.json \
    76cdeace861d2fff45ca732c55c2d97611dcd47edc7c27d62bdad4c37755e67e 59 "$TACHES" > /dev/null)
sceller_ici "$TACHES"; valider "$TACHES" "$TACHES.sha256"
gen A1c-taches-59 candidat "2026-10-12 01:29 UTC"
retour

echo "== A2 décision N-019 sans ses valeurs (7 584,02 s retiré), re-scellée"
jetable
DEC=docs/decisions/decision-N-019-v1.md
sed -i 's/7 584,02 s/7 584 s/g' "$K/$DEC"; sceller_ici "$DEC"; valider "$DEC" "$DEC.sha256"
gen A2-decision-sans-valeurs candidat "2026-10-12 01:29 UTC"
retour

echo "== A2b décision modifiée, sceau laissé"
jetable
echo "" >> "$K/$DEC"; valider "$DEC"
gen A2b-decision-sans-sceau candidat "2026-10-12 01:29 UTC"
retour

echo "== A3 brouillon 8 modifié hors des marqueurs (titre), sceau laissé"
B8=brouillons/T0.5-pilote-8B-v1-brouillon8.md
jetable
sed -i '1s/brouillon 8$/brouillon 8 (altéré)/' "$K/$B8"; valider "$B8"
gen A3-brouillon-modifie-sans-sceau candidat "2026-10-12 01:29 UTC"
retour

echo "== A3b brouillon 8 modifié hors des marqueurs, re-scellé"
jetable
sed -i '1s/brouillon 8$/brouillon 8 (altéré)/' "$K/$B8"; sceller_ici "$B8"; valider "$B8" "$B8.sha256"
gen A3b-brouillon-modifie-rescelle candidat "2026-10-12 01:29 UTC"
retour

echo "== A3c brouillon 8 : un marqueur retiré"
jetable
sed -i 's/- Entropie : `À REMPLIR` (tirée au scellement/- Entropie : `0` (tirée au scellement/' "$K/$B8"; sceller_ici "$B8"; valider "$B8" "$B8.sha256"
gen A3c-brouillon-marqueur-retire candidat "2026-10-12 01:29 UTC"
retour

echo "== A4 empreinte fausse d'un rapport de l'état des lieux"
ETAT_ARG="T0.5-pilote-v1-etat-des-lieux-resultats-v1.json=$(printf '1%.0s' {1..64}),T0.5-pilote-v1-etat-des-lieux-fichiers-de-travail-v1.tar=59f2d2976b2350a8389b9e5a79735c223fa4b6c2d216a4cea8c068a4713e908b" \
    gen A4-rapport-etat-empreinte-fausse candidat "2026-10-12 01:29 UTC"
echo "== A4b rapport de l'état des lieux absent de la liste (un seul des deux cité)"
ETAT_ARG="T0.5-pilote-v1-etat-des-lieux-resultats-v1.json=8ca0f843b17ba24e78280cd1bf0ba85e2f56639e31a0630ed9779ec96d883011" \
    gen A4b-rapport-etat-un-seul candidat "2026-10-12 01:29 UTC"

echo "== A5 arbre de travail modifié (fichier suivi, non committé)"
echo "# essai" >> "$K/README.md" 2>/dev/null || echo "# essai" >> "$K/CLAUDE.md"
gen A5-arbre-sale candidat "2026-10-12 01:29 UTC"
git -C "$K" checkout -q -- . ; [ -z "$(git -C "$K" status --porcelain --untracked-files=no)" ] && echo "    clone propre"
echo "== A5b commit cité ≠ HEAD (3ffab9f cité, HEAD 942c65e)"
COMMIT_ARG=3ffab9ff88761e73074c820b0cb456e51de9c575 gen A5b-commit-pas-head candidat "2026-10-12 01:29 UTC"

echo "== A6 mode réel, date hors format"
gen A6-reel-date-hors-format reel "2026-10-12T01:29" --candidat-relu brouillons/T0.5-pilote-8B-v1-candidat1.md
echo "== A6b mode réel, date à plus d'une heure de l'horloge"
gen A6b-reel-date-ancienne reel "2026-10-12 01:29 UTC" --candidat-relu brouillons/T0.5-pilote-8B-v1-candidat1.md
echo "== A6c mode réel sans candidat relu"
gen A6c-reel-sans-candidat reel "$(date -u '+%Y-%m-%d %H:%M UTC')"
echo "== A6d mode candidat, date hors format"
gen A6d-candidat-date-hors-format candidat "n'importe quoi"
echo "== A6e mode réel, date juste, rapports de relecture factices (absents du commit)"
gen A6e-reel-rapports-factices reel "$(date -u '+%Y-%m-%d %H:%M UTC')" --candidat-relu brouillons/T0.5-pilote-8B-v1-candidat1.md

echo "== A7 lecture-math.json modifiée, sceau laissé (non contrôlé par le générateur ?)"
jetable
LM=diag/20261011-225701-t05-revalidation-reel/lecture-math.json
"$PYN" -I - "$K/$LM" <<'PY'
import json, sys
p = sys.argv[1]; d = json.load(open(p, encoding="utf-8"))
d["resultat"]["lecture"]["conforme_avec_marge"] = True
open(p, "w", encoding="utf-8").write(json.dumps(d, ensure_ascii=False, indent=1) + "\n")
PY
valider "$LM"
gen A7-lecture-math-modifiee-sans-sceau candidat "2026-10-12 01:29 UTC"
retour

echo "== A8 brouillon de la configuration modifié (T = 11), committé (pas de sceau compagnon)"
CB=brouillons/T0.5-pilote-config-v1-brouillon1.json
jetable
sed -i 's/"T": 10,/"T": 11,/' "$K/$CB"; valider "$CB"
gen A8-config-brouillon-modifiee candidat "2026-10-12 01:29 UTC"
retour

echo "== A9 sortie déjà présente (R12)"
mkdir -p "$G/A9-sortie-presente"; echo x > "$G/A9-sortie-presente/existant.md"
SORTIE_P="$G/A9-sortie-presente/existant.md" gen A9-sortie-presente candidat "2026-10-12 01:29 UTC"
echo "== A10 entropie nulle"
echo 0 > "$G/entropie-0.txt"; ENT="$G/entropie-0.txt" gen A10-entropie-nulle candidat "2026-10-12 01:29 UTC"
echo "== A10b entropie 2^128"
echo 340282366920938463463374607431768211456 > "$G/entropie-2p128.txt"; ENT="$G/entropie-2p128.txt" gen A10b-entropie-2p128 candidat "2026-10-12 01:29 UTC"
echo "== A11 paire de rapport mal formée"
REL_ARG="T0.5-pilote-v1-relecture-b8-a-venir-v1.md=abc" gen A11-paire-mal-formee candidat "2026-10-12 01:29 UTC"
echo "== A12 chemin des tâches autre (copie conforme scellée ailleurs)"
jetable
mkdir -p "$K/donnees/autre"; cp "$K/$TACHES" "$K/donnees/autre/copie.json"; sceller_ici donnees/autre/copie.json; git -C "$K" add -f donnees/autre && git -C "$K" commit -qm "essai : copie des tâches"
TACHES_ARG=donnees/autre/copie.json gen A12-taches-autre-chemin candidat "2026-10-12 01:29 UTC"
grep -o "Chemin des tâches : \`[^\`]*\`" "$G/A12-taches-autre-chemin/prereg.md" 2>/dev/null | sed 's/^/    /'
retour
git -C "$K" log --oneline -1
echo "FIN DU BANC DU GÉNÉRATEUR"
