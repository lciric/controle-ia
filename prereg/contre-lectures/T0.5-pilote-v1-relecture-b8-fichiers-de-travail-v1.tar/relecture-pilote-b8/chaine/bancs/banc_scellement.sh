#!/usr/bin/env bash
# Banc du scellement du pilote (relecture R2 b8, angle « chaîne ») : copie de sceller_pilote_v1.sh dont seules les lignes
# H et DEPOT changent (bloc-notes factice H, clone de relecture), dépôt nu local partagé en guise de dépôt distant.
# Aucune poussée ailleurs que dans ce dépôt nu ; vérifié par grep et par « git remote -v » avant chaque passage.
set -uo pipefail
C=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-pilote-b8/chaine
K=$C/clone; H=$C/H; N=$C/distant.git
PYN=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/scellement-revalidation/venv-gpu-neuf/bin/python
BASE=942c65e365f809b7142b280b4adc1922ce3ab67c
V=docs/procedures/pilote-T0.5-v1
P=prereg/T0.5-pilote-8B-v1.md; CFG=prereg/T0.5-pilote-config-v1.json
SCRIPTS="remplir_pilote_v1.py normaliser_pilote_v1.py controles_avant_depense_pilote_v1.sh lancer_pilote_v1.sh sceller_pilote_v1.sh recuperation_pilote_v1.sh"
[ -e "$H" ] && { echo "$H existe déjà"; exit 2; }
[ -e "$N" ] && { echo "$N existe déjà"; exit 2; }
mkdir -p "$H"
# 0. rapport factice de la relecture (le seul ajout de contenu), puis épingles
git -C "$K" checkout -q -f -B banc-scellement "$BASE"
RF=prereg/contre-lectures/T0.5-pilote-v1-relecture-b8-banc-v1.md
printf '# Rapport factice du banc du scellement (relecture b8, angle chaîne)\n' > "$K/$RF"
(cd "$K/prereg/contre-lectures" && sha256sum "$(basename "$RF")" > "$(basename "$RF").sha256")
SRF=$(sha256sum "$K/$RF" | cut -d' ' -f1)
RAPP="T0.5-pilote-v1-etat-des-lieux-resultats-v1.json=8ca0f843b17ba24e78280cd1bf0ba85e2f56639e31a0630ed9779ec96d883011 T0.5-pilote-v1-etat-des-lieux-fichiers-de-travail-v1.tar=59f2d2976b2350a8389b9e5a79735c223fa4b6c2d216a4cea8c068a4713e908b T0.5-pilote-v1-relecture-b8-banc-v1.md=$SRF"
sed -e "s|^CANDIDAT_RELU=A_EPINGLER |CANDIDAT_RELU=15a5cd3e457dd7b6db234bc08ce7378514ec217b8f8099dea426eb3743b33150 |" \
    -e "s|^CANDIDAT_RELU_CHEMIN=A_EPINGLER|CANDIDAT_RELU_CHEMIN=brouillons/T0.5-pilote-8B-v1-candidat1.md|" \
    -e "s|^CANDIDAT_NORMALISE=A_EPINGLER |CANDIDAT_NORMALISE=fcfb10852ef5a8a288d314e38e0212a229ddee559591271165a51e55fad6b124 |" \
    -e "s|^RAPPORTS_ATTENDUS=\"A_EPINGLER\"|RAPPORTS_ATTENDUS=\"$RAPP\"|" "$C/H0/controles_avant_depense_pilote_v1.sh" > "$H/controles_avant_depense_pilote_v1.sh"
sed -e "s|^H=.*|H=$H|" -e "s|^DEPOT=.*|DEPOT=$K|" "$C/H0/sceller_pilote_v1.sh" > "$H/sceller_pilote_v1.sh"
for s in remplir_pilote_v1.py normaliser_pilote_v1.py lancer_pilote_v1.sh recuperation_pilote_v1.sh; do cp "$C/H0/$s" "$H/$s"; done
echo "lignes changées : contrôles $(diff "$C/H0/controles_avant_depense_pilote_v1.sh" "$H/controles_avant_depense_pilote_v1.sh" | grep -c '^>') ; scellement $(diff "$C/H0/sceller_pilote_v1.sh" "$H/sceller_pilote_v1.sh" | grep -c '^>')"
grep -n "A_EPINGLER" "$H/controles_avant_depense_pilote_v1.sh" && { echo "épingle restée"; exit 2; }
# sûreté : la copie du scellement ne nomme ni le dépôt de travail ni GitHub ; une seule poussée, vers « origin »
grep -n "controle-ia-travail\|github" "$H/sceller_pilote_v1.sh" && { echo "COPIE NON SÛRE"; exit 2; }
grep -n "push" "$H/sceller_pilote_v1.sh" | sed 's/^/    poussée de la copie : /'
# 1. préalables versés et scellés sur le commit jetable J
mkdir -p "$K/$V"
for s in $SCRIPTS; do cp "$H/$s" "$K/$V/$s"; (cd "$K/$V" && sha256sum "$s" > "$s.sha256"); done
git -C "$K" add -f "$RF" "$RF.sha256" "$V" && git -C "$K" commit -qm "essai : préalables du banc du scellement" || exit 2
J=$(git -C "$K" rev-parse HEAD); echo "J = $J"
# 2. dépôt nu local, partagé (objets du clone), main = J ; origin du clone = ce dépôt nu, en lecture et en poussée
git clone -q --bare --shared "$K" "$N" || exit 2
git -C "$N" update-ref refs/heads/main "$J"
git -C "$K" remote set-url origin "$N"; git -C "$K" remote set-url --push origin "$N"; git -C "$K" fetch -q origin
git -C "$K" remote -v | sed 's/^/    remote : /'
[ "$(git -C "$K" remote get-url --push origin)" = "$N" ] || { echo "origine de poussée inattendue"; exit 2; }
passage() {   # $1 nom ; le scellement de la copie, puis l'état laissé
    local n=$1 avant c
    avant=$(git -C "$K" rev-parse HEAD)
    (cd "$C" && bash "$H/sceller_pilote_v1.sh") > "$C/journaux/scellement-$n.log" 2>&1; c=$?
    echo "$n : code $c ; $(grep -v '^$' "$C/journaux/scellement-$n.log" | tail -2 | tr '\n' '|' | cut -c1-300)"
    echo "    HEAD $(git -C "$K" rev-parse --short HEAD) (avant $(git -C "$K" rev-parse --short "$avant")) ; distant main $(git -C "$N" rev-parse --short main) ; restes non suivis : $(cd "$K" && ls "$P" "$P.sha256" "$CFG" "$CFG.sha256" 2>/dev/null | tr '\n' ' ')"
    echo "    suivi propre : $([ -z "$(git -C "$K" status --porcelain --untracked-files=no)" ] && echo oui || echo NON)"
}
remise() {   # $1 commit : clone et dépôt nu remis sur ce commit, fichiers du scellement retirés
    git -C "$K" checkout -q -f banc-scellement; git -C "$K" reset -q --hard "$1"
    (cd "$K" && rm -f "$P" "$P.sha256" "$CFG" "$CFG.sha256")
    git -C "$N" update-ref refs/heads/main "$1"; git -C "$K" fetch -q origin
    git -C "$K" remote set-url --push origin "$N"
}
echo "== B0 cas sain"
passage B0-sain
S=$(git -C "$K" rev-parse HEAD)
if [ "$S" != "$J" ]; then
    echo "    parent de S = J : $([ "$(git -C "$K" rev-parse "$S^")" = "$J" ] && echo oui || echo NON) ; fichiers de S : $(git -C "$K" diff --name-only "$J" "$S" | tr '\n' ' ')"
    echo "    préenregistrement scellé : $(cut -c1-16 "$K/$P.sha256") ; normalisé $("$PYN" -I -B "$C/H0/normaliser_pilote_v1.py" "$K/$P")"
    echo "    configuration : $(sha256sum "$K/$CFG" | cut -c1-16) (candidat 6979a00e…) ; entropie : $(sed -n 's/^- Entropie : `\([0-9]*\)`.*/\1/p' "$K/$P" | cut -c1-6)… ($(sed -n 's/^- Entropie : `\([0-9]*\)`.*/\1/p' "$K/$P" | tr -d '\n' | wc -c) chiffres)"
    echo "    date : $(sed -n '4p' "$K/$P" | cut -c1-40) ; commit cité : $(sed -n "s/.*Commit du code d'analyse : \`\([0-9a-f]*\)\`.*/\1/p" "$K/$P" | cut -c1-12) (J ${J:0:12})"
    cp "$K/$P" "$C/gen/prereg-scelle-banc.md"; cp "$K/$CFG" "$C/gen/config-scellee-banc.json"
    ls -d "$H"/scellement-* | sed 's/^/    dossier de travail laissé : /'
fi
remise "$J"
echo "== B1 artefact : arbre sale (fichier suivi modifié)"
echo "# essai" >> "$K/README.md"
passage B1-arbre-sale
git -C "$K" checkout -q -- README.md
echo "== B2 artefact après la mise en place du piège : sceau d'un fichier versé faussé (verifier-arbre en échec)"
printf '%s  recuperation_pilote_v1.sh\n' "$(printf '0%.0s' {1..64})" > "$K/$V/recuperation_pilote_v1.sh.sha256"
git -C "$K" commit -qam "essai : sceau faussé" && J2=$(git -C "$K" rev-parse HEAD)
remise "$J2"
passage B2-sceau-fausse
remise "$J"
echo "== B3 artefact après le commit : poussée refusée (adresse de poussée inexistante)"
git -C "$K" remote set-url --push origin "$C/inexistant.git"
passage B3-poussee-refusee
echo "    commit S resté local : $(git -C "$K" log -1 --format='%h %s' | cut -c1-90)"
remise "$J"
echo "== B4 artefact : épingle normalisée fausse dans les contrôles"
cp "$H/controles_avant_depense_pilote_v1.sh" "$C/ctl-sauve.sh"
sed -i "s|^CANDIDAT_NORMALISE=fcfb1085[0-9a-f]*|CANDIDAT_NORMALISE=$(printf '1%.0s' {1..64})|" "$H/controles_avant_depense_pilote_v1.sh"
passage B4-epingle-normalisee-fausse
cp "$C/ctl-sauve.sh" "$H/controles_avant_depense_pilote_v1.sh"
echo "== B5 artefact : générateur du bloc-notes différent de sa copie versée"
echo "# modifié" >> "$H/remplir_pilote_v1.py"
passage B5-generateur-non-verse
cp "$C/H0/remplir_pilote_v1.py" "$H/remplir_pilote_v1.py"
echo "== B6 artefact : HEAD en avance sur le dépôt distant"
git -C "$K" commit -q --allow-empty -m "essai : commit local non poussé"
passage B6-head-en-avance
remise "$J"
echo "== B7 artefact : préenregistrement déjà présent (R12)"
echo x > "$K/$P"
passage B7-prereg-present
rm -f "$K/$P"
echo "== B8 artefact : rapport de la relecture épinglé absent du commit (rapport factice retiré)"
git -C "$K" rm -q "$RF" "$RF.sha256" && git -C "$K" commit -qm "essai : rapport retiré" && J3=$(git -C "$K" rev-parse HEAD)
remise "$J3"
passage B8-rapport-absent
remise "$J"
git -C "$K" status --short | head -5
echo "FIN DU BANC DU SCELLEMENT"
