"""Réplique (écrite par le relecteur, non exécutée depuis le lanceur) de la condition de révocation lue dans
lancer_pilote_v1.sh, lignes 48-56, appliquée à des lignes synthétiques du registre des décisions."""
import re, unicodedata
norm = lambda s: unicodedata.normalize("NFC", s).lower()
def revoquee(lignes):
    return any(re.search(r"révoqu|révocation", norm(x)) and "n-019" in norm(x) for x in lignes if x.startswith("| R-"))
cas = {
    "Lazar révoque N-019": "| R-150 | 2026-10-12 | Lazar révoque N-019. | message |",
    "révocation de la délégation R-140 (N-019 non nommée)": "| R-150 | 2026-10-12 | Lazar révoque la délégation R-140 et les décisions prises sous elle. | message |",
    "Lazar annule N-019": "| R-150 | 2026-10-12 | Lazar annule N-019 : option (c). | message |",
    "Lazar revient sur N-019": "| R-150 | 2026-10-12 | Lazar revient sur N-019 et retient l'option (b). | message |",
    "N‑019 (trait d'union insécable)": "| R-150 | 2026-10-12 | Lazar révoque N‑019. | message |",
    "« revoque » sans accent": "| R-150 | 2026-10-12 | Lazar revoque N-019. | message |",
    "révocation consignée dans la ligne N-019 seulement": "| N-019 | 2026-10-12 | … | tranché le 2026-10-12 sous la délégation R-140 : option (a) ; révoqué par Lazar le 2026-10-12 |",
    "faux positif : « N-019 non révoquée »": "| R-160 | 2026-10-12 | Pilote : relancement (infrastructure) ; N-019 non révoquée. | essai |",
    "« révocable » (ne doit pas déclencher)": "| R-143 | 2026-10-12 | N-019 tranché sous la délégation R-140 : option (a) ; révocable par Lazar. | essai |",
}
for nom, l in cas.items():
    print(f"{'DÉTECTÉE' if revoquee([l]) else 'non détectée'} : {nom}")
