"""Sonde du normaliseur du pilote (relecture b8, angle chaîne) : lignes touchées par chaque motif ; effets de changements
de fond hors des champs masqués ; contenu caché dans les parties masquées. Usage : python -I sonde_normaliseur.py H0 CANDIDAT"""
import hashlib, importlib.util, re, sys
from pathlib import Path
spec = importlib.util.spec_from_file_location("n", Path(sys.argv[1]) / "normaliser_pilote_v1.py")
n = importlib.util.module_from_spec(spec); spec.loader.exec_module(n)
t = Path(sys.argv[2]).read_text(encoding="utf-8")
motifs = [r"version scellée le \d{4}-\d{2}-\d{2} \d{2}:\d{2} UTC", r"- Date \(UTC\) : \d{4}-\d{2}-\d{2} \d{2}:\d{2}",
          r"(- Commit du code d'analyse : )`[0-9a-f]{40}`", r"(- Entropie : )`\d+`", r"(- Tests attendus : )`\d+`",
          r"au commit cité, \d+ tests\)", r"(Relecture R2 du brouillon 8 .*?: rapports ).*$"]
lignes = t.split("\n")
for m in motifs:
    touchees = [i + 1 for i, l in enumerate(lignes) if re.search(m, l)]
    print(f"motif {m[:48]!r} : lignes {touchees}")
# mentions des champs hors motifs (ce qui changerait au scellement sans être masqué)
for mot in ("3ffab9f", "680", "01:29", "a-venir", "0000000000"):
    print(f"occurrences de {mot!r} : lignes {[i + 1 for i, l in enumerate(lignes) if mot in l]}")
ref = n.empreinte(t)
print("normalisé du candidat :", ref)
def essai(nom, x, y, compte=1):
    k = t.count(x)
    if k < 1:
        print(f"{nom} : cible absente"); return
    u = t.replace(x, y, compte)
    print(f"{nom} : {'INCHANGÉ' if n.empreinte(u) == ref else 'change'} (cible trouvée {k} fois)")
essai("F1 durée projetée 7 584,02 → 7 584,03", "`7 584,02` s", "`7 584,03` s")
essai("F2 empreinte canonique de la configuration", "db3ad3cebc3f0832e43514749b42c01b344ab4dca2997153d851814fe251b714",
      "db3ad3cebc3f0832e43514749b42c01b344ab4dca2997153d851814fe251b715")
essai("F3 empreinte des tâches", "287e83485cba550098b80db809589398d8f2826c02dfa9cc2719a1063795d5aa",
      "287e83485cba550098b80db809589398d8f2826c02dfa9cc2719a1063795d5ab")
essai("F4 branche du lancement", "`BRANCHE=calcul/t05-pilote-reel-v1`", "`BRANCHE=calcul/t05-pilote-reel-v9`")
essai("F5 empreinte de l'amorce", "59f49aab394c4b7659b716792203663243a106355fbabf666bbb1f61ed55de73",
      "59f49aab394c4b7659b716792203663243a106355fbabf666bbb1f61ed55de74")
essai("F6 rapport de l'état des lieux", "8ca0f843b17ba24e78280cd1bf0ba85e2f56639e31a0630ed9779ec96d883011",
      "8ca0f843b17ba24e78280cd1bf0ba85e2f56639e31a0630ed9779ec96d883012")
essai("F7 fin de la ligne Date (hors date)", "(scellement : après l'extraction, N-014, le verdict de la revalidation et N-019).",
      "(scellement : après l'extraction).")
essai("F8 suite de la ligne Tests attendus", "(toute la suite de `tests/`", "(une partie de `tests/`")
essai("F9 empreinte du brouillon 8 (ligne 3)", "c99dac33c4e36e6a53d1235e6752490c5aeb876619f3eba0b70c0d6bfb845371",
      "c99dac33c4e36e6a53d1235e6752490c5aeb876619f3eba0b70c0d6bfb845372")
essai("F10 noyau", "noyau d'attention du pilote : `defaut`", "noyau d'attention du pilote : `math`")
# contenu caché dans une partie masquée
l_rel = [l for l in lignes if l.startswith("- Relecture R2 du brouillon 8")][0]
essai("M1 phrase ajoutée en fin de ligne de la relecture R2", l_rel, l_rel + " Le seuil de la garde passe à 0,3.")
essai("M2 rapports de la relecture remplacés par un texte quelconque", l_rel,
      l_rel.split(": rapports ")[0] + ": rapports aucun.")
essai("M3 date de la ligne 4 changée (masquée)", "- Date (UTC) : 2026-10-12 01:29", "- Date (UTC) : 2031-01-01 00:00")
essai("M4 dates des lignes 3 et 4 différentes l'une de l'autre", "version scellée le 2026-10-12 01:29 UTC",
      "version scellée le 1999-01-01 00:00 UTC")
essai("M5 nombre de tests de la ligne « Tests attendus » seul", "- Tests attendus : `680`", "- Tests attendus : `1`")
