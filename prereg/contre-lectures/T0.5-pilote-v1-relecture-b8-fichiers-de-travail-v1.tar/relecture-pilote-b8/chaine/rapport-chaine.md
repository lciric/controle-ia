# Relecture R2 du pilote 8B de T0.5, candidat 1 — angle « chaîne » (avec bancs)

- Relecteur : sous-agent neuf. Je n'ai écrit ni le préenregistrement, ni le générateur, ni la chaîne. Je n'ai pas lu les rapports des autres angles (`code`, `n019`, `texte`).
- Date : 2026-10-12, de 02:10 à 02:45 UTC environ.
- Dépôt de travail : `/home/user/controle-ia-travail`, tête `942c65e365f809b7142b280b4adc1922ce3ab67c`, laissée intacte : tête inchangée, arbre propre, aucune branche ajoutée.
- Objet relu : `brouillons/T0.5-pilote-8B-v1-candidat1.md` (`15a5cd3e…`) et `brouillons/T0.5-pilote-config-v1-candidat1.json` (`6979a00e…`).
- Chaîne relue : le bloc-notes `pilote-v1/`. J'ai relevé les empreintes de tous ses scripts au début de la relecture (`journaux/empreintes-bloc-notes-au-debut.txt`) et je les ai revérifiées à la fin : rien n'a changé. Le générateur relu est `remplir_pilote_v1.py` (`2f791291…`) et le normaliseur `normaliser_pilote_v1.py` (`0347237c…`). Le plan est `docs/procedures/pilote-T0.5-v1/plan-lancement-pilote-v1.md` (`4c34d49e…`), identique au bloc-notes.
- Modèle de comparaison : la chaîne v7 de la revalidation, sous `docs/procedures/revalidation-T0.5-v2/`.

Règles tenues pendant la relecture :
- aucune écriture dans le dépôt de travail ni dans `pilote-v1/` : j'ai fait tourner des copies identiques placées sous `H0/`, avec `python -I -B` ;
- aucune commande vastai ;
- aucune valeur de jeton affichée : un comptage final donne 0 occurrence des quatre jetons dans 161 fichiers ;
- `episodes-defaut.json` et `chemin-defaut.json` n'ont pas été ouverts (règle D-20) ;
- un seul clone (`git clone -q /home/user/controle-ia-travail …/chaine/clone`) et un seul dépôt nu local. Leur adresse de poussée n'a jamais visé le dépôt de travail : je l'ai neutralisée dès le clonage, puis réglée sur le dépôt nu, et j'ai vérifié la copie du scellement par grep avant de la lancer. Les deux ont été supprimés à la fin ;
- les contrôles avant dépense et le lanceur ont été relus, jamais lancés.

## Verdict

La chaîne marche sur ses cas sains. Le générateur rejoué en mode candidat à `942c65e` redonne l'empreinte normalisée `fcfb1085…` et la configuration `6979a00e…`. Le scellement, rejoué sur une copie avec un dépôt nu, produit un commit S conforme. Le piège EXIT nettoie bien. La plupart des artefacts s'arrêtent sur un motif lisible.

Aucun constat bloquant. Quatre constats majeurs sont à traiter avant le scellement :
- **CH-01** : le code scellé n'est pas lié au code relu. Le banc B11 scelle sans arrêt un changement de `src/` fait après la relecture.
- **CH-02** : le relancement promis par le plan est bloqué par la garde des instances.
- **CH-03** : aucun banc d'artefacts pour les contrôles avant dépense (écart à R5).
- **CH-04** : l'hôte est restreint par le nom de son processeur, mais la carte PCIe reste admise, alors que le débit a été mesuré sur une A100 SXM4.

## Réponses aux huit questions

### 1. Générateur : toute valeur vient-elle d'un fichier scellé au commit ?

**Presque toutes.**

Ce qui vient d'un fichier dont le sceau est contrôlé au commit (`scelle_au_commit`) :
- les résultats de la revalidation : `resume.json`, `mesures-defaut.json`, `lecture-defaut.json` ;
- le verdict, la décision N-019 et le plan ;
- les quatorze documents cités ;
- les tâches dérivées (en plus, égales aux 60 premières tâches de la source `76cdeace…`) ;
- les rapports de l'état des lieux ; ceux de la relecture en mode reel seulement.

Les empreintes des deux scripts de l'instance sont calculées au commit. Ce sont des fichiers de code, sans sceau compagnon.

Exceptions :
- **brouillon 8** : il est lu au commit, mais son sceau n'est pas contrôlé. Son empreinte complète est en revanche citée en ligne 3, hors des parties masquées.
- **`lecture-math.json`** : son sceau n'est pas contrôlé, et le résultat n'y est pas sensible (banc A7).
- **brouillon de configuration** : il n'a aucun sceau, parce que `brouillons/` est hors des dossiers scellés. Son empreinte canonique est citée dans le texte.
- **constantes de la formule** : elles sont écrites dans le code du générateur (60 tâches, 3 épisodes, 7 800 s, 15 000 s, 7 200 s, 1,2, 192, 16). Elles sont toutefois recoupées par les valeurs littérales de N-019 (« 7 584,02 s », « 15 000 s », noyau « defaut ») : toute dérive provoque un arrêt (banc A14).
- **nombres écrits à la main dans le brouillon 8** (8 089,62 s, 491,38 s…) : le générateur ne les vérifie pas. J'en ai contrôlé trois sur les fichiers scellés, tous exacts.

Résultats du banc :
- **cas sain** : code 0 ; empreinte normalisée `fcfb10852ef5a8a288d314e38e0212a229ddee559591271165a51e55fad6b124`, conforme ; configuration identique au candidat. Le seul écart au candidat 1 est la ligne 5, celle du commit (`942c65e…` au lieu de `3ffab9f…`).
- **artefacts** : 26 cas joués. Les cas demandés s'arrêtent tous sur un motif lisible : tâches modifiées, décision sans ses valeurs, marqueur du brouillon retiré, empreinte fausse d'un rapport de l'état des lieux, arbre de travail modifié, mode réel avec une date hors format. Le détail est dans la table du banc 1, plus bas.
- **trous** : sept cas passent avec le code 0 en mode candidat (A3, A3b, A4b, A6d, A7, A8, A12). Ils sont détaillés dans CH-06 et CH-07. Six seraient rattrapés plus tard, au scellement (empreinte normalisée différente) ou par les contrôles. Le septième, A7, garde une empreinte normalisée inchangée. Avec un sceau faux, il serait arrêté par `verifier-arbre` au scellement (dossier `diag/`) et par `verifier_resultat` dans les contrôles. Modifié et re-scellé, il passerait partout, mais sans effet sur le texte, puisque le choix du noyau est circulaire (CH-17).
- **brouillon modifié hors des marqueurs** : il ne provoque pas d'arrêt en mode candidat. C'est seulement le mode reel qui le refuse.

### 2. Normaliseur : masque-t-il exactement les champs fixés au scellement, et rien d'autre ?

**Oui pour la portée des motifs. Non pour ce qu'on peut cacher dans les parties masquées.**

Sept motifs, chacun ne touche qu'une ligne du candidat :

| Ligne | Ce qui est masqué |
|---|---|
| 3 | date de « version scellée le » |
| 4 | date |
| 5 | commit |
| 9 | entropie |
| 15 | nombre de tests |
| 170 | rappel du nombre de tests |
| 265 | fin de la ligne de la relecture R2 |

Dix changements de fond hors de ces champs changent l'empreinte (F1 à F10) : durée projetée, empreinte de la configuration, empreinte des tâches, branche, empreinte de l'amorce, rapport de l'état des lieux, suite de la ligne de la date, suite de la ligne des tests, empreinte du brouillon 8, noyau.

En revanche, l'empreinte ne bouge pas dans ces cas :
- une phrase de fond ajoutée en fin de ligne 265 (M1, M2) ;
- des dates quelconques, ou des dates différentes entre les lignes 3 et 4 (M3, M4) ;
- un nombre de tests de la ligne 15 différent de celui de la ligne 170 (M5).

La v7 reconstruisait exactement la partie masquée (VC-02) et contrôlait les dates (VC-10). Les contrôles du pilote ne le font plus (CH-05). Le commit et le nombre de tests étant masqués, un changement de code hors des deux scripts de l'instance passe inaperçu : c'est CH-01.

### 3. Scellement `sceller_pilote_v1.sh`

J'ai éprouvé une copie dont seules les lignes `H` et `DEPOT` changent (deux lignes au diff). La copie ne nomme ni le dépôt de travail ni GitHub (vérifié par grep). Sa seule poussée vise `origin`, réglé sur mon dépôt nu (vérifié par `git remote -v`). Il a fallu un commit jetable J portant les copies versées et scellées des six scripts, les épingles, et un rapport factice `T0.5-pilote-v1-relecture-b8-banc-v1.md` scellé.

- **Cas sain (B0)** : code 0. S est l'enfant de J et n'ajoute que les quatre fichiers attendus. Il est poussé au dépôt nu, qui a été relu. L'empreinte normalisée est `fcfb1085…`, égale à l'épingle. La configuration (`6979a00e…`) est identique au candidat. L'entropie fait 38 chiffres et le commit cité est J.
- **Arbre sale (B1)** : code 2, « arbre suivi non propre », rien n'est créé.
- **Piège EXIT, éprouvé quatre fois après sa pose** (B2bis : `verifier-arbre` en échec ; B8bis : rapport épinglé absent ; B10 : candidat épinglé égal au brouillon 8 ; B12 : script de l'instance modifié) : les quatre fichiers créés sont retirés et rien n'est poussé.
  - Défaut : pour B2bis, le seul message est « échec avant le commit : fichiers créés retirés », avec le code 1 (CH-08).
- **Poussée refusée (B3)** : code 2, « S reste local ». Les fichiers committés sont gardés.

### 4. Contrôles avant dépense

Relus, non lancés. Chaque contrôle annoncé en tête existe bien dans le corps.

Manques par rapport à la v7 :
- aucune épingle du commit du code relu (CH-01) ;
- dates des lignes 3 et 4 non contrôlées (VC-10) ;
- fin masquée de la ligne de la relecture non reconstruite (VC-02) ;
- pièces citées non vérifiées contre leurs sceaux (VT-10) : la répétition jouet et la sortie de la suite ne sont ni citées ni contrôlées (CH-12) ;
- un seul candidat épinglé, contre trois en v7 (relu, vérifié, final) ;
- aucun banc d'artefacts (CH-03).

Ajouts par rapport à la v7 :
- suite complète des tests au commit S, au lieu de la seule collecte ;
- valeurs du verdict recalculées ;
- format des vrais tokeniseurs 8B et 3B ;
- configuration égale au brouillon ;
- mode relance.

N-019 est contrôlée par le lanceur sur le registre courant, pas par les contrôles sur S. C'est acceptable, puisque le lanceur rejoue les contrôles.

### 5. Lanceur `lancer_pilote_v1.sh` (relu seulement)

| Garde | Lecture |
|---|---|
| Heure | refus entre 23:30 et 00:00 UTC, au départ et avant la création. Comparaison décimale correcte (`[ 0800 -lt 2330 ]` est vrai). |
| Place disque | au moins 3 Go, sur le bloc-notes et sur le dossier des traces. |
| N-019 | une seule ligne N-019, « tranché » et « (a) » ; aucune ligne R- ne doit contenir à la fois « révoqu » (ou « révocation ») et « n-019 ». Détection fragile (CH-10). |
| Relance | exige « relance R-NNN » et une ligne R- qui contient « relancement », « pilote » et « infrastructure ». Contrôle par mots-clés seulement. |
| Offre | filtre du plan, identique à la v7. |
| Processeur | égalité stricte avec « AMD EPYC 7513 32-Core Processor ». La carte PCIe reste pourtant admise (CH-04). |
| Prix | 1,30 USD l'heure au plus. |
| Crédit | `round(crédit, 2) ≥ round(6 × prix + 1,2, 2)`. Marge suffisante pour l'offre de la revalidation : téléchargement 0,026 USD par Go, soit 0,8 à 0,9 USD pour 31 à 35 Go ; disques arrêtés environ 0,05 USD l'heure. Le coût de téléchargement de l'offre n'entre pas dans la formule. |
| Instances tolérées | `55292763 55458787`, écrites en dur. En relance, l'instance du premier lancement n'est pas tolérée (CH-02). |
| Environnement de création | `COMMIT`, `ETUDE=pilote`, `PREREG`, `BRANCHE`, `DEPOT_URL`, et les deux jetons. `MODE` n'est pas passé et vaut `reel` par défaut. |
| Étiquette | `t05-pilote-v1`, ou `…-relance`. |
| Base de la surveillance | création − 3 900 s, d'où un plafond de 17 700 s ; elle est recopiée à la main (CH-13). |

Codes de sortie :
- 3 pour l'heure, la place, le prix ou le crédit ;
- 2 pour tout autre arrêt avant la ligne « creation », y compris les échecs imprévus, par le piège ERR ;
- 4 après cette ligne ;
- les cas sont cohérents avec le plan.

Faiblesses :
- **dossier de traces relatif** : il fait échouer les contrôles (simulation : `"$D/../suite-$$.txt"` est introuvable après `cd "$D"`) ;
- **jetons vérifiés après les contrôles** : si un jeton manque, on perd environ 20 minutes avant l'arrêt ;
- **contrôles sans délai maximal** ;
- **message trompeur** quand `vastai show instances` lui-même échoue : il annonce « instance(s) non tolérée(s) ».

Ces quatre points sont regroupés dans CH-11.

### 6. Récupération `recuperation_pilote_v1.sh`

Ce qui est bien couvert :
- ascendance, ajouts seulement, périmètre, un seul run, auteurs ;
- sceaux, `verifier_resultat`, traces ;
- manifeste : commit, préenregistrement, configuration citée, entropie citée, mode, run décisif, dépôt propre ;
- issue : un `resume.json` ou un `arret.json`, exclusivement ; tâches citées ;
- **vecteurs** : branche `donnees/t05/<run>` faite d'un commit sans parent, empreinte égale au sceau et à `episodes.json` ;
- journal ;
- absence des jetons. Un jeton absent de la session donne désormais KO : c'est plus strict que la v2.

Manques propres au pilote (CH-09) :
- **juges et appariement** : aucun fichier n'est exigé pour un run complet (`appariements.json`, `notations-{8B,3B}-{decisives,descriptives}.json`). Les comptes ne sont pas contrôlés : 180 épisodes, 240 notations par juge (180, plus les 60 épisodes e0 notés deux fois).
- **arrêt partiel** : `partiel` n'est pas affiché (épisodes écrits, appariement écrit, notations écrites).
- **contrôles retirés par rapport à la v2** : carte et mémoire, versions de torch et de transformers. Le `pip freeze` ajouté par `f8ab64a` n'est pas contrôlé.
- **branche `-v1` d'un premier lancement manqué** : ni relue ni citée en cas de relance.

### 7. Répétition jouet

Ce qu'elle éprouve :
- la dérivation de quatre tâches ;
- le générateur en mode jouet ;
- un scellement fait à la main ;
- l'amorce et le script de l'instance (`ETUDE=pilote`, `MODE=jouet`, `PREREG`, `BRANCHE`), lancés avec `env -i` et des jetons factices, avec un dépôt nu local en guise de dépôt distant ;
- la suite complète sur processeur ;
- les épisodes, l'appariement, les juges et les vecteurs du modèle jouet, ainsi que la branche des vecteurs ;
- la branche déjà présente (code 2) ;
- le relancement sur `-v2` ;
- la récupération du passage 1, sur une copie dont cinq lignes changent.

Ce qu'elle n'éprouve pas :
- **modèles et matériel réels** : modèles réels, carte, téléchargements Hugging Face ;
- **garde du format réelle** : `texte_attendu_ouverture` est retiré en mode jouet ;
- **temps et mémoire** ;
- **chemins d'arrêt** : signal TERM et plafond (codes 124 et 137), vecteurs de plus de 95 Mo, poussée refusée puis reprise ;
- **installation** : `requirements-gpu.txt` n'est pas installé, puisque l'environnement existant est réutilisé ;
- **le reste de la chaîne** : le scellement par `sceller_pilote_v1.sh`, les contrôles, le lanceur, la récupération en mode relance ;
- **poussée réelle** vers GitHub avec le jeton ;
- **valeurs de récupération forcées** : le mode `reel` et « disponible True » sont remplacés par sed.

État observé :
- **à `942c65e`** : non conforme. Les passages 1 et 3 finissent en code 1 sur la garde du format, avec le générateur d'alors. Les épisodes, les vecteurs et les juges n'ont pas été joués. La récupération donne deux KO.
- **à `f8ab64a`**, avec le générateur actuel (fin à 02:43 UTC) : conforme. Trois passages au code attendu, 682 tests, vecteurs poussés, récupération « tous conformes ». Mais c'est un autre commit que celui du candidat relu.

### 8. Plan v1 cohérent avec les scripts ? Pistes fragiles restantes

Le plan est cohérent pour les étapes 1, 2, 3, 4, 6 et 7. Écarts :
- **préalable 4** : il nomme comme copies versées la dérivation et les répétitions. Le scellement n'en exige que six, et le lanceur trois.
- **préalable 5** : il exige la répétition jouet « au commit du code cité », mais rien ne la cite ni ne la vérifie.
- **étape 5** : le relancement est bloqué (CH-02).
- **étape 3** : la carte n'est pas restreinte (CH-04).
- **bancs** : le plan n'en parle pas. La v7 en exigeait trois.
- **engagement de dépense avant la création** : il n'est pas imposé par le lanceur (c'est une étape de procédure).

Pistes fragiles restantes : CH-01, CH-02, CH-03, CH-04 ; puis CH-05, CH-09, CH-10 et CH-11.

## Constats

Les constats sont classés par gravité décroissante.

### CH-01 — majeur — le code scellé n'est pas lié au code relu

- **Où** : `sceller_pilote_v1.sh:43` ; `controles_avant_depense_pilote_v1.sh:48-61` ; `normaliser_pilote_v1.py:13,15-16`.
- **Constat** :
  - Le commit cité est HEAD au moment du scellement.
  - Le normaliseur masque le commit et le nombre de tests.
  - Ni le générateur, ni le scellement, ni les contrôles n'exigent que l'arbre gelé de S soit celui que la relecture R2 a lu : le différentiel depuis `e6ce058` jusqu'à `3ffab9f`/`942c65e`. Le contrôle « arbre gelé identique au commit du code » compare le commit cité à S, qui en est l'enfant : il est toujours vrai.
  - La v7 épinglait le code : `CODE=6ec7434` dans le scellement, `COMMIT_ATTENDU` dans le générateur, et un différentiel contrôlé depuis la v1.
- **Preuve** :
  - Banc B11 : une modification de `src/controle_ia/environnements/lancer_pilote_a.py` (`ENONCE_DE_CONTROLE`), committée avant le scellement, donne le code 0. S est scellé, cite le commit modifié, et son empreinte normalisée vaut `fcfb1085…`, égale à l'épingle (`journaux/banc-scellement-c.log`).
  - B12 : la même opération sur `scripts/pilote_t05_instance.sh` est refusée, parce que l'empreinte de ce script est citée dans le texte.
  - Contexte : `f8ab64a` (branche `travail/pilote-post-r2`) change déjà `lancer_pilote_a.py`, le script de l'instance et deux fichiers de tests.
- **Action** :
  - Épingler dans les contrôles le commit du code relu, ou le dernier commit vérifié après corrections, et exiger `git diff --quiet <épingle> S -- CHEMINS_GELES`.
  - Faire la même vérification dans le scellement, avant d'appeler le générateur.
  - Toute modification du code après la relecture demande un nouveau candidat et une vérification courte du différentiel, tous deux épinglés.

### CH-02 — majeur — relancement bloqué par la garde des instances

- **Où** : `lancer_pilote_v1.sh:31,113-126` ; plan, étape 5.
- **Constat** :
  - En relance, l'instance du premier lancement est arrêtée mais gardée (N-009).
  - Elle n'est pas dans `ARRETEES_TOLEREES`, écrite en dur. Or le lanceur doit rester égal à sa copie versée à S.
  - Résultat : « instance(s) non tolérée(s) sur le compte : pas de création », code 2.
  - Le relancement « sans nouvelle version » du plan est donc impossible tant que Lazar n'a pas détruit la première instance.
- **Preuve** :
  - Lecture du code : toute instance hors de la liste fait sortir avec le code 1 le filtre Python, puis avec le code 2 le lanceur.
  - Le banc du lanceur de la session (cas P13c) n'a joué que la liste par défaut.
- **Action** :
  - En mode relance, tolérer l'identifiant de l'instance du premier lancement, lu dans le `lancement.txt` du premier lancement ou dans la ligne R- de la cause, et relu arrêté.
  - Ajouter le cas au banc.
  - Écrire la dépendance dans le plan.

### CH-03 — majeur — aucun banc d'artefacts pour les contrôles avant dépense (R5)

- **Où** : `controles_avant_depense_pilote_v1.sh` ; plan, étapes 1 et 2.
- **Constat** :
  - La v7 avait trois bancs :
    - `essais_controles_v7.sh` : un cas sain, 31 artefacts, deux épingles mal formées ;
    - `essais_scellement_v5b.sh` : huit artefacts et un cas sain ;
    - le banc du lanceur.
  - Le pilote n'a que le banc du lanceur, qui utilise de faux contrôles, et la répétition finale, qui ne joue qu'un cas sain et n'a pas encore tourné faute d'épingles.
  - Les gardes nouvelles des contrôles ne sont éprouvées sur aucun artefact : valeurs recalculées, 60 tâches, configuration égale au brouillon, tokeniseurs, suite complète, « seuls de leur famille », relance.
- **Preuve** : `ls pilote-v1/` (seul `essais_lanceur_pilote_v1.sh` existe) ; comparaison avec `docs/procedures/revalidation-T0.5-v2/`.
- **Action** :
  - Écrire un banc des contrôles, sur une copie dont seules la ligne `DEPOT` et les épingles changent, avec au moins un artefact par garde.
  - Verser un banc du scellement : mes `bancs/banc_scellement*.sh` peuvent servir de base.

### CH-04 — majeur — carte non restreinte alors que l'hôte l'est au nom du débit mesuré

- **Où** : `lancer_pilote_v1.sh:32,101-102` ; plan, étape 3 ; candidat, ligne 170.
- **Constat** :
  - Le lanceur exige le processeur de la revalidation, au nom du débit mesuré (tirage sur processeur, en un fil) et d'AVX2.
  - Mais le filtre admet toujours `A100_PCIE`, alors que le débit a été mesuré sur une A100 SXM4 (offre 49506597).
  - La marge sur R8 n'est que de 2,8 % : 7 584,02 s pour 7 800 s.
  - Sur une carte PCIe, à bande passante et puissance moindres, la durée réelle des épisodes pourrait dépasser 7 800 s et rogner le budget des juges, plafonné à 15 000 s. On aurait alors des notations manquantes et une lecture partielle.
  - Doute : je n'ai pas mesuré l'écart entre PCIe et SXM4.
- **Preuve** : `traces/t05-revalidation-v2-20261011-2246/offre.json` (`gpu_name: A100 SXM4`, `cpu_name: AMD EPYC 7513 32-Core Processor`) ; filtre `gpu_name in [A100_SXM4,A100_PCIE]`.
- **Action** : exiger `gpu_name` égal à « A100 SXM4 », ou la machine même de la revalidation (identifiant de machine), en cohérence avec le motif écrit. Sinon, déclarer le risque dans le texte et le plan.

### CH-05 — mineur — parties masquées non reconstruites par les contrôles (régression sur VC-02 et VC-10)

- **Où** : `normaliser_pilote_v1.py:11-17` ; `controles_avant_depense_pilote_v1.sh:77-89`.
- **Constat** :
  - Le normaliseur masque toute la fin de la ligne de la relecture, les deux dates, et les deux mentions du nombre de tests.
  - Les contrôles ne reconstruisent pas la ligne de la relecture à partir des épingles.
  - Ils ne contrôlent ni l'égalité des dates des lignes 3 et 4, ni leur proximité avec l'heure du commit S, ni l'égalité des nombres de tests des lignes 15 et 170.
- **Preuve** : sonde M1 à M5, empreinte inchangée (`journaux/sonde-normaliseur.log`).
- **Action** : ajouter ces trois contrôles. La ligne de la relecture doit être reconstruite à l'identique à partir des paires `relecture-b8` épinglées.

### CH-06 — mineur — entrées lues au commit sans contrôle de sceau

- **Où** : `remplir_pilote_v1.py:157-158,187,215`.
- **Constat** :
  - **brouillon 8** : son sceau n'est pas contrôlé, et son empreinte attendue `c99dac33…` n'est pas exigée.
  - **`lecture-math.json`** : son sceau n'est pas contrôlé, et le choix du noyau ne peut rendre que « defaut », puisque la lecture du bras « defaut » est forcée conforme avec marge.
  - **brouillon de configuration** : il n'a aucun sceau.
- **Preuve** :
  - A3 et A3b (brouillon modifié, sceau laissé ou refait) : code 0, empreinte normalisée `11eea508…`.
  - A7 (`lecture-math.json` modifiée, sceau faux) : code 0, `fcfb1085…` inchangée.
  - A8 (configuration T = 11) : code 0, `1d6d0651…`.
  - En mode reel, A3 et A8 seraient rattrapés par la comparaison au candidat.
  - A7 serait rattrapé par `verifier-arbre` et par `verifier_resultat` tant que son sceau est faux. Re-scellé, il passerait partout, sans effet sur le texte (CH-17).
- **Action** : appeler `scelle_au_commit` pour le brouillon 8 et `lecture-math.json` ; exiger `c99dac33…` en constante ; donner un sceau ou une empreinte attendue au brouillon de configuration.

### CH-07 — mineur — mode candidat trop libre

- **Où** : `remplir_pilote_v1.py:73-75,176`.
- **Constat** : en mode candidat, la date n'est pas contrôlée et le chemin des tâches est libre.
- **Preuve** :
  - A6d (date « n'importe quoi ») : code 0. Le texte n'est pas normalisable (empreinte `16ac0f27…`) et ne serait refusé qu'au scellement.
  - A12 (copie conforme des tâches, scellée ailleurs) : code 0, avec « Chemin des tâches : `donnees/autre/copie.json` ».
- **Action** : exiger le format de date dans tous les modes ; fixer `--taches` à la constante en modes reel et candidat.

### CH-08 — mineur — scellement : motif illisible et dossiers de travail laissés

- **Où** : `sceller_pilote_v1.sh:41,48-50`.
- **Constat** :
  - Quand `verifier-arbre` échoue après la copie, les lignes ÉCHEC sont avalées par `| tail -1 | grep -q`. Le seul message est celui du piège, avec le code 1 ; ailleurs, les arrêts donnent le code 2.
  - Chaque tentative laisse un dossier `scellement-XXXX` dans le bloc-notes, avec l'entropie tirée, le texte et la configuration.
- **Preuve** : `journaux/scellement-B2bis-sceau-fausse.log` (deux lignes, dont aucune motif) ; trois à cinq dossiers `H/scellement-*` laissés après mes passages.
- **Action** : écrire la sortie de `verifier-arbre` dans un fichier et afficher ses lignes ÉCHEC ; harmoniser le code 2 ; retirer le dossier de travail en cas d'échec, ou le dire.

### CH-09 — mineur — récupération : manques propres au pilote

- **Où** : `recuperation_pilote_v1.sh:70-82`.
- **Constat** : voir la question 6 (juges, appariement, comptes, `partiel`, carte, versions, `pip freeze`, branche `-v1`).
- **Preuve** : lecture du code ; comparaison avec `recuperation_revalidation_v2.sh` (contrôles 3f, 4b, 4c) et avec le journal de la récupération v2 (`scratchpad/recuperation-v2-8f74ada.log`).
- **Action** :
  - Pour un run complet : KO si un fichier de résultats manque ou si un compte diffère.
  - Pour un arrêt : afficher `partiel`.
  - Ajouter la carte, la mémoire, les versions et le `pip freeze`.
  - Jouer la récupération en mode relance dans la répétition.

### CH-10 — mineur — révocation de N-019 détectée par mots-clés

- **Où** : `lancer_pilote_v1.sh:47-61`.
- **Constat** :
  - Non détectés :
    - révocation de la délégation R-140 sans nommer N-019 ;
    - « annule », « revient sur » ;
    - N‑019 écrit avec un trait d'union insécable ;
    - « revoque » sans accent ;
    - révocation écrite dans la seule ligne N-019.
  - Faux positif : « N-019 non révoquée » dans une ligne R- provoque un refus.
- **Preuve** : `journaux/sonde-revocation.log`. C'est une réplique de la condition, écrite par moi ; je n'ai pas exécuté le lanceur.
- **Action** : exiger une forme exacte pour la colonne d'état de N-019, et lire aussi R-140 ; ou faire consigner une confirmation explicite juste avant le lancement.

### CH-11 — mineur — lanceur : chemin relatif, ordre des gardes, durée des contrôles

- **Où** : `lancer_pilote_v1.sh:34,69,84,113-126` ; `controles_avant_depense_pilote_v1.sh:154,169-170`.
- **Constat** :
  - un dossier de traces relatif fait échouer les contrôles ;
  - les jetons ne sont vérifiés qu'après environ 20 minutes de contrôles ;
  - les contrôles n'ont pas de délai maximal ;
  - quand `show instances` échoue, le message est trompeur.
- **Preuve** : simulation (« No such file or directory » sur `traces/clone-controles/../suite-….txt`) ; lecture du code.
- **Action** : `T=$(realpath -m "$2")` ; vérifier les jetons avant les contrôles ; `timeout` sur les contrôles ; message distinct en cas d'échec de vastai.

### CH-12 — mineur — plan v1 et scripts non alignés, preuves des répétitions non citées

- **Où** : plan, lignes 21-24 et 43-61.
- **Constat** :
  - les copies versées exigées diffèrent selon les scripts (sept, six ou trois) ;
  - la répétition jouet « au commit du code cité » n'est ni épinglée, ni citée, ni contrôlée (la v7 contrôlait l'archive de la sienne) ;
  - les bancs sont absents du plan ;
  - CH-02 et CH-04 ne sont pas déclarés ;
  - l'engagement de dépense n'est pas imposé.
- **Preuve** : lecture croisée du plan, de `sceller_pilote_v1.sh:31-34`, de `lancer_pilote_v1.sh:63-67` et de `repetition_finale_pilote_v1.sh:18`.
- **Action** : aligner le plan et les scripts ; verser l'archive scellée de la répétition jouet faite au commit du code finalement cité, et la faire citer et contrôler.

### CH-13 — mineur — base de la surveillance : message et report à la main

- **Où** : `docs/procedures/surveiller-instance-t04-v1.sh:61` ; plan, étape 5.
- **Constat** : avec une base égale à la création moins 3 900 s, la surveillance affiche « PLAFOND : 6 heures depuis la création », alors que le plafond tombe 17 700 s après la création. La base est en outre recopiée à la main.
- **Preuve** : lecture des deux scripts.
- **Action** : l'écrire dans le plan, ou passer le plafond explicitement.

### CH-14 — information — générateur : cas sain reproduit, artefacts conformes

- **Où** : `remplir_pilote_v1.py`.
- **Constat** :
  - Le générateur actuel (`2f791291…`, modifié à 02:03, après le candidat de 01:30, en mode jouet seulement) n'est pas encore versé.
  - Il reproduit le candidat : empreinte normalisée `fcfb1085…`, configuration `6979a00e…`.
  - Sur 26 cas d'artefacts, 19 s'arrêtent sur le motif attendu et 7 passent avec le code 0 (CH-06, CH-07 ; A4b est rattrapé par les épingles).
- **Preuve** : `journaux/banc-generateur.log` et `banc-generateur-b.log`.
- **Action** : verser le générateur actuel et citer son empreinte dans la ligne de registre du scellement.

### CH-15 — information — scellement éprouvé

- **Où** : `sceller_pilote_v1.sh`.
- **Constat** : cas sain conforme. Piège EXIT efficace dans quatre cas. Poussée refusée gérée.
- **Preuve** : `journaux/banc-scellement*.log`.
- **Action** : aucune, hors CH-01 et CH-08.

### CH-16 — information — répétition jouet

- **Où** : `repetition_jouet_pilote_v1.sh`.
- **Constat** : non conforme à `942c65e` ; conforme à `f8ab64a` avec le générateur actuel.
- **Preuve** : `rep-pilote-v1-942c65e.log` ; `rep-pilote-v1-f8ab64a.log`.
- **Action** : la refaire au commit finalement cité, et la citer (CH-12).

### CH-17 — information — choix du noyau circulaire

- **Où** : `remplir_pilote_v1.py:156-160` ; contrôles, ligne 128.
- **Constat** : forcer la lecture du bras « defaut » à « conforme avec marge » fait rendre « defaut » à `choisir_noyau` quoi qu'il arrive. La vraie garde est la liste des critères R1 à R7 exigés vrais.
- **Preuve** : A7.
- **Action** : le dire, ou contrôler directement que « math » n'est pas conforme avec marge.

### CH-18 — information — délégation et crédit

- **Où** : `registres/decisions.md` (R-140) ; `registres/etat.md:60`.
- **Constat** :
  - La délégation court jusqu'au 2026-10-12 à 10:40 UTC.
  - Le crédit était lu à 7,30 USD à 01:20 UTC ; il en faut 7,68 à 1,08 USD l'heure. Le lancement viendra donc après une recharge par Lazar, sans doute après la fin de la délégation.
  - Le lanceur ne lit pas la délégation.
  - Je ne tranche pas si un lancement après 10:40 reste couvert (N-019 tranché ; GO-2026-10-04-08 valable jusqu'au 1er novembre).
- **Preuve** : registres.
- **Action** : la session confirme, ou consigne, la base de l'autorisation au moment du lancement.

## Bancs

### Banc 1 : générateur

Fichiers : `bancs/banc_generateur.sh` et `banc_generateur_b.sh` ; journaux `journaux/banc-generateur*.log`. Mode candidat, sauf mention contraire, au commit `942c65e` ou sur un commit jetable du clone.

| Cas | Code | Motif ou résultat |
|---|---|---|
| S0 sain | 0 | empreinte normalisée `fcfb1085…` |
| A1r tâches altérées, re-scellées | 1 | fichier dérivé des tâches ≠ 60 premières tâches de la source |
| A1br tâches altérées, sceau laissé | 1 | sceau absent ou différent au commit |
| A1cr 59 tâches | 1 | ≠ 60 premières tâches de la source |
| A2 décision sans 7 584,02 s | 1 | la décision N-019 ne porte pas les valeurs recalculées |
| A2b décision, sceau laissé | 1 | sceau absent ou différent au commit |
| A3, A3b brouillon modifié hors des marqueurs | 0 | `11eea508…` (CH-06) |
| A3c marqueur retiré | 1 | cible trouvée 0 fois |
| A4 empreinte fausse d'un rapport de l'état des lieux | 1 | empreinte citée ≠ sceau au commit |
| A4b un seul rapport de l'état des lieux cité | 0 | `a05bf97e…` (rattrapé par les épingles) |
| A5 arbre sale | 1 | arbre suivi non propre |
| A5b commit ≠ HEAD | 1 | le commit cité n'est pas HEAD |
| A6 réel, date hors format | 1 | date attendue au format « AAAA-MM-JJ HH:MM UTC » |
| A6br réel, date ancienne | 1 | date à 23 453 s de l'horloge |
| A6c réel sans candidat | 1 | mode reel sans --candidat-relu |
| A6d candidat, date hors format | 0 | `16ac0f27…` (CH-07) |
| A6e réel, rapports de relecture factices | 1 | git show : chemin absent au commit |
| A7 `lecture-math.json`, sceau faux | 0 | `fcfb1085…` inchangée (CH-06) |
| A8 brouillon de configuration T = 11 | 0 | `1d6d0651…` (CH-06) |
| A9 sortie présente | 1 | R12 |
| A10, A10b entropie 0 ou 2^128 | 1 | hors de ]0 ; 2^128[ |
| A11 paire mal formée | 1 | paire de rapport mal formée |
| A12 tâches ailleurs | 0 | `d9654452…` (CH-07) |
| A14 mesures + 1 s, re-scellées | 1 | 7 595,27 s ≠ N-019 |
| A15 nœud faux | 1 | ne conclut pas au nœud |

Deux premiers essais de mon banc ont échoué pour une raison propre au banc :
- A1 à A1c : l'ajout sous `donnees/`, ignoré par git, n'était pas forcé ;
- A6b : la date était à moins d'une heure de l'horloge.

Je les ai rejoués et ils sont conformes.

Re-dérivation des 60 tâches : identique octet pour octet à `287e8348…`. La copie a été supprimée ; l'empreinte est gardée dans `gen/derivation/empreinte.txt`.

### Banc 2 : scellement

Fichiers : `bancs/banc_scellement.sh`, `_b.sh` et `_c.sh` ; journaux `journaux/banc-scellement*.log` et `scellement-*.log`.

| Cas | Code | Résultat |
|---|---|---|
| B0 sain | 0 | S poussé au dépôt nu ; quatre fichiers ; normalisé = épingle |
| B1 arbre sale | 2 | arbre suivi non propre |
| B2bis sceau faussé, `verifier-arbre` après la copie | 1 | fichiers retirés, motif non affiché (CH-08) |
| B3 poussée refusée | 2 | S reste local |
| B4 épingle fausse dans le seul bloc-notes | 2 | ≠ copie versée |
| B4bis épingle normalisée fausse | 2 | normalisé ≠ épingle |
| B4c épingle brute fausse | 2 | ≠ épingle brute |
| B5 générateur non versé | 2 | ≠ copie versée |
| B6 HEAD en avance | 2 | HEAD ≠ origin/main |
| B7 préenregistrement présent | 2 | R12 |
| B8bis rapport épinglé absent | 1 | arrêt du générateur, fichiers retirés |
| B9 aucune épingle de relecture | 2 | absents des épingles |
| B10 candidat = brouillon 8 | 1 | version écrite ≠ candidat relu, fichiers retirés |
| B11 code de `src/` modifié | 0 | scellé sans arrêt (CH-01) |
| B12 script de l'instance modifié | 1 | refusé, fichiers retirés |

Mes premiers essais de B2 et B8 ont échoué pour une raison propre au banc : le dépôt nu n'avait pas d'objets partagés avec le clone. Je les ai rejoués en B2bis et B8bis.

### Sondes

- `bancs/sonde_normaliseur.py` (`journaux/sonde-normaliseur.log`) ;
- `bancs/sonde_revocation.py` (`journaux/sonde-revocation.log`).

## Fichiers de travail

Sous `relecture-pilote-b8/chaine/` :

- `H0/` : copies identiques du bloc-notes ;
- `H/` : bloc-notes factice du banc du scellement, avec ses dossiers `scellement-*` ;
- `bancs/`, `journaux/`, `gen/` ;
- `ctl-pin-sain.sh`, `ctl-sauve.sh` : contrôles épinglés pour le banc, avec un rapport factice ;
- `journaux/etat-clone-avant-suppression.txt`.

Le clone et le dépôt nu sont supprimés. La taille totale du dossier est d'environ 1,8 Mo.
