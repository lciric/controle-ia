#!/usr/bin/env bash
# Banc CH-01-1 : joue la copie du scellement du candidat 1 (lignes H et DEPOT seules changées) sur le clone jetable,
# dépôt nu local comme « origin ». Usage : jouer_cas.sh NOM COMMIT_BASE
set -uo pipefail
W=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-pilote-b8/verification/CH-01-1
nom=$1; base=$2
cd "$W/depot" || exit 9
[ "$(git remote get-url origin)" = "$W/distant.git" ] || { echo "origin inattendu : arrêt"; exit 9; }
git checkout -q -B main "$base" && git push -q -f origin main:main && git fetch -q origin || exit 9
echo "cas $nom : base $(git rev-parse HEAD) ; distant $(git -C "$W/distant.git" rev-parse main)"
debut=$(date +%s)
PYTHONDONTWRITEBYTECODE=1 bash "$W/H/sceller_pilote_v1.sh" > "$W/journaux/scellement-$nom.log" 2>&1; c=$?
S=$(git rev-parse HEAD)
echo "cas $nom : code $c en $(( $(date +%s) - debut )) s ; HEAD $S ; parent $(git rev-parse "$S^") ; distant $(git -C "$W/distant.git" rev-parse main)"
echo "  dernière ligne : $(grep -v '^$' "$W/journaux/scellement-$nom.log" | tail -1 | cut -c1-200)"
if [ "$c" = 0 ]; then
  echo "  S ajoute : $(git diff --name-only "$S^" "$S" | tr '\n' ' ')"
  echo "  commit cité : $(sed -n "s/.*Commit du code d'analyse : \`\([0-9a-f]\{40\}\)\`.*/\1/p" prereg/T0.5-pilote-8B-v1.md | head -1)"
  echo "  tests attendus : $(sed -n "s/.*Tests attendus : \`\([0-9]*\)\`.*/\1/p" prereg/T0.5-pilote-8B-v1.md | head -1)"
  echo "  normalisé : $(PYTHONDONTWRITEBYTECODE=1 /tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/scellement-revalidation/venv-gpu-neuf/bin/python -I "$W/H/normaliser_pilote_v1.py" prereg/T0.5-pilote-8B-v1.md)"
  echo "  configuration : $(sha256sum prereg/T0.5-pilote-config-v1.json | cut -d' ' -f1)"
  echo "$S" > "$W/journaux/S-$nom.txt"
fi
