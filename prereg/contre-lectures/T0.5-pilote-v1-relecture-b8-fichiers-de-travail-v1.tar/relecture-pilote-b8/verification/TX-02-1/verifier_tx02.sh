#!/usr/bin/env bash
# Vérification de TX-02 (lecture seule) : traçabilité du traitement de l'état des lieux dans le candidat 1.
set -u
D=/home/user/controle-ia-travail; C=$D/brouillons/T0.5-pilote-8B-v1-candidat1.md
cd "$D"
echo "sha candidat : $(sha256sum "$C" | cut -c1-16)"
echo "tables « Traitement de » : $(grep -c '^Traitement de' "$C") ; dont état des lieux : $(grep -c '^Traitement de l.état des lieux' "$C")"
echo "identifiants de l'état des lieux cités dans le candidat : $(grep -o -w -E '(PF|AR|RC|ML|SI|PL|VR|HR)-[0-9]{2}' "$C" | sort -u | tr '\n' ' ')"
echo "gabarit, section Contre-lecture : $(grep -o 'traitement de chaque remarque (accepté, refusé et pourquoi)' prereg/gabarit-preregistrement-v1.md)"
echo "--- prescrits par la synthèse (étape 9) et absents :"
echo "poussée initiale dans le candidat : $(grep -c 'poussée initiale' "$C") ; arrêt du script : $(grep -c 'poussée initiale de la branche $BRANCHE refusée' scripts/pilote_t05_instance.sh)"
echo "repli math (l.183) : $(grep -n 'noyau « math » au débit mesuré' "$C" | cut -d: -f1)"
echo "exclusions de l'extraction (l.48) : $(grep -n 'les exclusions de l.extraction' "$C" | cut -d: -f1) ; bilan exclus=$(python3 -c 'import json;print(json.load(open("diag/20261007-082440-t05-extraction/bilan-extraction.json"))["resultat"]["exclus"])')"
echo "--- autres :"
echo "K-1 : $(grep -c 'K-1' "$C") ; archive sans dossier (l.132) : $(grep -n 'scripts `T0.5-pilote-contre-lecture-2' "$C" | cut -d: -f1)"
echo "lignes de l'ancien ordre : Y-5 $(grep -n '« décisives, décisives, appariement, descriptives »' "$C" | cut -d: -f1) ; V-4 $(grep -n '« décisives, décisives, appariement, énoncé seul, descriptives »' "$C" | cut -d: -f1) ; test : $(grep -o 'appels == \[.*\]' tests/test_pilote_a.py | head -1)"
echo "charger_pilote sans résumé ni arrêt : $(grep -c 'ni résumé ni arrêt consigné' src/controle_ia/environnements/lire_pilote.py)"
echo "X-7 promesse « sera alignée après le run d'extraction en cours » : $(grep -c 'sera alignée après le run d.extraction en cours' "$C") ; docstring : $(grep -c 'nœud N-014 ouvert' src/controle_ia/environnements/extraire_t05.py)"
echo "--- réfutations partielles :"
echo "modèle de l'étiqueteur déclaré : $(grep -n -o 'modèle non épinglé par ce texte : limite déclarée' "$C")"
echo "gabarit du 3B (HR-07) : fichiers à la révision : $(python3 -c 'import json;d=json.load(open("traces/hf-revisions-20261006-1645/hf-Llama-3.2-3B-Instruct.json"));print([s["rfilename"] for s in d["siblings"] if "template" in s["rfilename"] or s["rfilename"].startswith("tokenizer")])')"
echo "filtre d'offre (VR-07) : $(grep -o 'gpu_name in \[A100_SXM4,A100_PCIE\] gpu_ram>=79.*cpu_ram>=128' /tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/pilote-v1/lancer_pilote_v1.sh)"
