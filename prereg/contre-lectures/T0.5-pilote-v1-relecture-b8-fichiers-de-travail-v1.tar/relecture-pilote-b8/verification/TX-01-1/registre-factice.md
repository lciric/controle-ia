| R-901 | 2026-10-12 | Relancement du pilote : cause d'infrastructure (panne réseau pendant le préchargement du 3B). | essai |
| R-902 | 2026-10-12 | Relancement du pilote : échéance interne duree_max_s atteinte pendant les épisodes (hôte lent), qualifiée d'infrastructure par la session. | essai |
| R-903 | 2026-10-12 | Relancement du pilote : tests en échec sur l'instance (test sensible au processeur, cf. R-132), tenus pour une cause d'infrastructure. | essai |
| R-904 | 2026-10-12 | Relancement du pilote : cause indéterminée, aucune cause d'infrastructure établie. | essai |
| R-905 | 2026-10-12 | Relancement du pilote : panne de mémoire pendant les épisodes. | essai |
| N-019 | 2026-10-12 | nœud factice | tranché le 2026-10-12 : option (a) |
