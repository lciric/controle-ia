# Reproduction : lecture gelée (code cité) contre la lecture de la chaîne du pilote (N-019). Lecture seule.
import json, math, sys
from pathlib import Path
D = Path(sys.argv[1])
from controle_ia.environnements import revalider_pilote_a as rv
run = D / "diag/20261011-225701-t05-revalidation-reel"
mes = json.loads((run / "mesures-defaut.json").read_text())["resultat"]
lec = json.loads((run / "lecture-defaut.json").read_text())["resultat"]["lecture"]
lm = json.loads((run / "lecture-math.json").read_text())["resultat"]["lecture"]
print("constantes gelées du code de lecture : TACHES_PILOTE =", rv.TACHES_PILOTE, "; EPISODES_PILOTE =", rv.EPISODES_PILOTE)
d_gele = rv.duree_projetee_pilote(mes["chrono"], 16)
print(f"durée projetée par le code gelé : {d_gele:.2f} s (scellée : {mes['duree_projetee_episodes_pilote_s']:.2f} s) ; ≤ 7 800 s ? {d_gele <= 7800}")
print("lecture scellée (bras defaut) : R8_duree =", lec["R8_duree"], "; conforme =", lec["conforme"], "; conforme_avec_marge =", lec["conforme_avec_marge"])
print("choisir_noyau sur la lecture scellée :", rv.choisir_noyau({"defaut": lec, "math": lm}))
d_180 = (mes["chrono"]["generation_s"] + mes["chrono"]["passe_unique_s"]) * 60 * 3 / 16
print(f"durée recalculée par la chaîne (60 × 3 au lieu de EPISODES_PILOTE) : {d_180:.2f} s")
force = dict(lec, R8_duree=True, conforme=True, conforme_avec_marge=True)
print("choisir_noyau sur la lecture forcée par remplir_pilote_v1.py et les contrôles :", rv.choisir_noyau({"defaut": force, "math": lm}))
print("duree_max_s (formule gelée, d = 180 épisodes) :", min(15000, math.ceil((1.2 * d_180 + 7200) / 60) * 60))
