# Pilote 8B de T0.5 : plan jusqu'au scellement et au lancement (synthèse du 2026-10-12, vers 00:30 UTC, HEAD 02b0947, arbre propre)

## Verdict de la synthèse
Dans la délégation R-140, le pilote ne peut être **ni scellé ni lancé**. La revalidation v2 est terminée et aboutit à un **nœud « R8 seul »**. Je l'ai vérifié dans `diag/20261011-225701-t05-revalidation-reel/resume.json` (d759b05d…, sceau conforme) :
- `noyau_retenu` vaut null, `noeud` vaut true, `proposition_au_noeud` vaut null.
- Le bras « defaut » est conforme sur tout, sauf R8 : d = (665,85 + 8,28) × 192/16 = 8 089,6 s, au-dessus des 7 800 s permises.
- Le bras « math » est tombé en panne de mémoire.

La table gelée de la v2 (l. 128) renvoie ce cas à Lazar. Retenir « defaut » ou changer la formule de durée revient à changer une lecture gelée, ce que R-140 exclut. Tout le reste se prépare dès maintenant, pour sceller puis lancer dans les heures qui suivent sa décision. La délégation finit à 10:40 UTC ; sa réponse est attendue dans la matinée.

### Arbitrages entre les lecteurs (vérifiés)
- **État de la revalidation** : le lecteur « texte » la croyait encore en cours. Elle est finie : run de 22:57:01 à 23:44:09, code 0, instance arrêtée à 23:49:30 (`registres/arrets.md`).
- **Commit à citer** : 6ec7434 ne vaut plus, car l'arbre gelé de HEAD en diffère par 5 fichiers (1f53a08). L'arbre gelé de 1f53a08 est identique à celui de HEAD (`git diff --quiet` : 0). Je recommande de garder 1f53a08 : appariement avant les notations, 3B préchargé avant les épisodes puis chargé hors ligne. Avec moins de temps pour les juges, ce changement compte encore plus.
- **Nombre de tests** : 678 collectés au HEAD, ni 670 ni 676.
- **HR-07 (gabarit du 3B)** : à la révision 0cb88a4f, le 3B n'a aucun fichier de gabarit séparé (`traces/hf-revisions-20261006-1645/hf-Llama-3.2-3B-Instruct.json`, liste des fichiers). Tout ce que lit le format est donc préchargé.
- **Appariement** : une passe unique par lot de 32 (`pilote_a.py:225-246`), environ 17 000 paires, soit environ 540 lots. Sa durée n'est pas mesurée (de 5 à 30 minutes selon les estimations).
- **Durée liée à l'hôte** : l'échantillonnage se fait ligne par ligne sur le processeur, en un seul fil (`episode.py:111-121`, `modeles.py:291`). T0.4 v3 le confirme : 108,8 jetons/s au lot de 8, 118,8 au lot de 32 (verdict v3, l. 405-406). Agrandir les lots des juges ne ferait donc rien gagner.
- **Émulation AVX2** : les 101 tests des trois fichiers touchés par 1f53a08 passent (308,87 s, `/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/pilote-etat-des-lieux/synthese/pytest-avx2-1f53a08.txt`, ff2e1b7d…).
- **Récupération v2** : le lecteur « chaîne » la disait jamais exécutée. Elle a tourné une fois pour de vrai ; je ne le sais que par le message de ba0004d, sans l'avoir vérifié moi-même.

## Étape 1 — Verdict R13 de la revalidation v2 (en cours, dans la délégation)
- Un sous-agent neuf prononce le verdict. On lui donne explicitement :
  - le préenregistrement v2 (4ff2b075…) et sa configuration (ee0945a8…) ;
  - `resume.json`, `mesures-defaut.json`, `lecture-defaut.json`, `lecture-math.json` ;
  - le manifeste (06ee7ed9…) et le code cité.
- Il recalcule `lire_bras` et `choisir_noyau`, puis **toutes** les réserves de la table, pas seulement `resume.reserves`.
- Il écrit des lignes lisibles par machine : noyau retenu (aucun), nœud (R8 seul), d du bras « defaut » (8089.6213105190545), réserves (RV-5).
- Le verdict est scellé sous `docs/verdicts/` (nom versionné).
- D-20 : personne n'ouvre `episodes-defaut.json` ni `chemin-defaut.json` hors de ce verdict. Supprimer le clone de lecture `scratchpad/pilote-etat-des-lieux/reval-v2-lecture`, qui contient des fiches.
- Si, contre toute attente, R13 retient « defaut » : pas de nœud, duree_max_s = 15 000 s par la formule gelée, et on passe à l'étape 10 sans attendre Lazar.

## Étape 2 — Un seul message à Lazar dès le verdict scellé
Nœud N-019 (numéro à confirmer), sans défaut. Le message contient le verdict, puis la décision au format de CLAUDE.md :
- **Décision** : comment faire tourner le pilote, alors que le bras « defaut » est équivalent avec marge mais dépasse R8 de 3,7 %.
- **Enjeu** : avec la formule gelée, le run dure 15 000 s et ne laisse que 6 910 s à l'appariement et aux notations. Ni l'un ni les autres n'ont jamais été mesurés. Estimation centrale, non vérifiée : environ 8 000 s pour les seules notations décisives des deux juges.
- **Options** :
  - **(a)** R8 levé, formule et instance de 5 h inchangées.
    - Avantage : aucun code.
    - Inconvénient : les notations décisives seraient probablement coupées (3B en nœud, P3 non concluant) ; seules les familles sont protégées.
  - **(b)** R8 levé, un seul run allongé : duree_max_s d'environ 25 000 à 30 000 s, avec les délais de 270 et 300 minutes, la surveillance et le devis de T0.5 recalculés.
    - Avantage : seules des constantes changent, sur des chemins de code déjà éprouvés.
    - Inconvénient : nouvelles empreintes de scripts et nouvelle répétition ; environ 11 USD de crédit ; jusqu'à 9 h d'exposition.
  - **(c)** R8 levé, deux runs : d'abord épisodes et appariement (échéance de 9 720 s), puis les juges depuis `episodes.json` scellé.
    - Avantage : chaque instance reste sous 5 h.
    - Inconvénient : code nouveau (reprise, lecture de deux runs), donc le plus de chemins jamais éprouvés.
- **Recommandation** : (b), confiance d'environ 55 %. Choisir (c) si Lazar refuse une instance de 9 h. Pistes écartées :
  - des lots de juge plus grands (aucun gain, d'après T0.4 v3) ;
  - le noyau « math » (panne de mémoire) ;
  - une mesure préalable des juges (chaîne nouvelle, crédit).
- **Dans le même message** :
  - une recharge chiffrée, sur le crédit relu sous forme filtrée par la session : règle de la forme (heures de surveillance + 1) × prix + 1,0 USD, soit environ 6,4 à 7,5 USD pour (a) et environ 11 USD pour (b) ;
  - la proposition de détruire les disques de 55292763 et de 55458787 ;
  - la décision sera consignée comme GO de type « revendication », sur le modèle de GO-2026-10-11-01, puis citée par le pilote et vérifiée par les contrôles.

## Étape 3 — Hygiène, tout de suite (routine)
- **Registres** :
  - ajouter la ligne R-142, que `depenses.md` cite mais qui manque dans `decisions.md` ;
  - corriger `etat.md`, qui donne encore 55458787 « en marche » et une ligne T0.5 périmée ;
  - écrire la passation de fin de session (R14).
- **Disque** : 6,7 Go libres, alors qu'un environnement neuf pèse environ 6 Go. Libérer au moins 10 Go dans le bloc-notes, en vérifiant par empreinte que chaque archive utile est déjà dans le dépôt (comme R-127).
- **Gel jusqu'à la création de l'instance** : ne rien verser sous `docs/sources` (l'invite H.12 de T0.8 comprise) et ne pas changer la forme de `registres/go.md`. Des tests les lisent (`test_depot_expurge.py:38` exige exactement 34 fichiers).

## Étape 4 — Relecture R2 du code du pilote (maintenant, sans attendre Lazar)
- Sous-agents neufs, deux angles, avec des sceptiques sur chaque remarque grave.
- Pièces : `git diff e6ce058 HEAD -- src/controle_ia/environnements/lancer_pilote_a.py src/controle_ia/harnais/modeles.py src/controle_ia/gardes.py src/controle_ia/environnements/pilote_a.py src/controle_ia/harnais/episode.py scripts/ requirements-gpu.txt .claude/hooks/garde_calcul.py tests/`, plus le brouillon 7.
- Questions à leur poser :
  - l'ordre inversé, contraire à CL-7, D-6 et Y-5, et ses conséquences sur les lignes de runs partiels ;
  - la garde du format, qui n'est pas rejouée sur le 3B chargé hors ligne ;
  - l'absence de point de contrôle du signal TERM et de l'échéance pendant le préchargement ;
  - la docstring du lanceur (l. 3-8), qui décrit l'ancien ordre ;
  - les arrêts du script absents de la liste d'arrêt.

## Étape 5 — Un seul lot de code, puis gel
- **Indépendant de l'option** :
  - la docstring ;
  - les gardes de carte A100 et de mémoire d'au moins 75 Gio, reprises de `revalider_pilote_a` (`exiger_carte_a100`, `exiger_memoire_carte`), avec leurs tests ;
  - les corrections issues de l'étape 4.
- **Selon l'option** :
  - (b) : DUREE_MAX_S, les délais du script et de l'amorce, le test de la borne ;
  - (c) : le mode de reprise et la lecture de deux runs ;
  - si le script change de toute façon : 3 nouvelles tentatives à attente croissante, avec délai, pour les poussées finales et les vecteurs, et `pip freeze` versé dans les traces.
- Un commit unique C, puis gel. Le gel se contrôle par `git diff --quiet C S -- CHEMINS_GELES`, en distinguant les codes 0, 1 et autre.

## Étape 6 — Preuves au commit C
- **Suite complète** : clone neuf, environnement installé seulement depuis `requirements-gpu.txt`, `env -i`, HOME nu. Exiger exactement « N passed » (678 aujourd'hui).
- **Suite entière en émulation AVX2**, méthode R-134 (`ATEN_CPU_CAPABILITY=avx2`, `ONEDNN_MAX_CPU_ISA=AVX2`, `MKL_ENABLE_INSTRUCTIONS=AVX2`), puis audit court des tests nouveaux (R-133). Sorties versées, scellées et citées.
- **Format avec les vrais tokeniseurs**, sur la session (8B 0e9e39f2…, 3B 0cb88a4f…) :
  - `charger_format_seul` puis `controler_format`, pour l'agent, le juge 8B et le juge 3B ;
  - puis rechargement hors ligne depuis ce cache ;
  - le jeton n'est jamais affiché.

## Étape 7 — Chaîne du pilote
Elle tourne depuis le bloc-notes ; ses copies sont versées et scellées sous `docs/procedures/pilote-T0.5-v1/`, hors de l'arbre gelé.

**`remplir_pilote_v1.py` (générateur)**
- Part du brouillon 8 épinglé. Chaque champ est remplacé par son préfixe de ligne, exactement une fois, jamais par remplacement global (la rangée de la l. 355 est réécrite sans marqueur).
- Lit le verdict scellé et `resume.json` (`verifier_resultat`), et exige leur égalité.
- Refuse : un nœud sans décision, un noyau hors de {defaut, math}, un d absent ou NaN, un d supérieur à 7 800 s sauf décision contraire.
- Calcule duree_max_s en arithmétique exacte : un entier multiple de 60.
- Écrit la configuration en mode exclusif et cite `lancer_pilote_a.empreinte_config`.
- Lit l'entropie, tirée une fois avant le candidat ; donne les empreintes complètes des documents qui font foi.
- Exige `problemes()` vide ; offre un mode essai et un mode réel (date à moins d'une heure de l'horloge).

**`controles_avant_depense_pilote_v1.sh S DOSSIER`**
- Reprend les contrôles utiles de la v7, sur un clone neuf de S :
  - épingles bien formées ;
  - S n'ajoute que les fichiers attendus ;
  - commit cité ancêtre de S ;
  - arbre gelé égal (`CHEMINS_GELES` importé, jamais recopié) ;
  - empreintes des deux scripts, configuration et tâches comparées à leurs sceaux ;
  - dates ;
  - branche de résultats absente ;
  - `verifier-arbre`.
- Ajoute :
  - noyau et duree_max_s recalculés depuis le verdict et la décision ;
  - gardes d'avant le manifeste rejouées avec les constantes importées (`exiger_config`, `CLES_LANCEMENT`, `NOYAUX`, borne de durée, `charger_taches`, `exiger_cibles`, `exiger_invites`, `exiger_code_cite`, `exiger_code_importe_sous`, `exiger_citations_pilote`) ;
  - lecture précoce rejouée avec les mêmes `sed` que le script de l'instance, et comparée ;
  - index des invites égal à adb4b8bc… ;
  - **suite complète au commit S**, dans un clone et un environnement neufs ;
  - garde de calcul et révocations lues en Python, jamais par `grep -q` en tube ;
  - présence de la règle de crédit dans le texte scellé.

**`lancer_pilote_v1.sh OFFRE DOSSIER`**
- Un seul appel, sans sous-agent pendant l'appel.
- Refuse toute création entre 23:30 et 00:00 UTC, au départ et juste avant la création ; vérifie la place disque.
- Rejoue les contrôles (dernière ligne exacte) ; vérifie que les scripts exécutés égalent leurs copies versées et que l'amorce de S est citée (encodage base64 vérifié).
- Relit l'offre au filtre de la procédure scellée et l'archive avec `cpu_name`, `cpu_arch` et `cpu_cores`.
- Exige un prix d'au plus 1,30 USD/h et le crédit fixé par la règle scellée ; sinon code 3, rien ne se crée.
- Tolère 55292763 et 55458787 si elles sont relues arrêtées ; rejoue la garde de calcul (GO-2026-10-04-08).
- Crée l'instance avec `ETUDE=pilote`, `PREREG`, `BRANCHE`, `DEPOT_URL` du dépôt de travail, l'étiquette `t05-pilote-v1` et `--cancel-unavail` ; la réponse est masquée.
- `lancement.txt` consigne : CREATION, la base de surveillance (CREATION + plafond − 21 600 s), l'heure du rappel et les lignes attendues à 5 minutes.
- Codes de sortie 0, 2, 3 et 4.
- Mode relance explicite (`-v2`) : seulement si `-v1` n'a pas d'`episodes.json` et si une ligne R-… consigne une cause d'infrastructure.

**`sceller_pilote_v1.sh`**
- Scelle deux fichiers, le préenregistrement et la configuration, avec leurs sceaux.
- Exige des candidats égaux à leurs épingles et régénère en mode réel.
- Vérifie que S est enfant de la base et n'ajoute que ces fichiers.
- Un piège retire les sorties non suivies si le commit n'a pas eu lieu.
- Pousse avec délai, puis relit par `ls-remote`. Si la poussée échoue : repousser, ne jamais resceller.

**`recuperation_pilote_v1.sh S DOSSIER`**
- Ascendance de S ; seulement des ajouts sous `runs/<RUN>/`, `diag/<RUN>/` et `traces/t05-*/`.
- Un seul RUN, au motif `^[0-9]{8}-[0-9]{6}-t05-pilote-reel$` ; auteur « instance de calcul (T0.5) ».
- `verifier_resultat` sur chaque JSON.
- Manifeste : commit S, préenregistrement, configuration canonique, entropie, mode reel.
- Une seule issue : `resume.json` ou `arret.json`, jamais les deux. Fichiers de chaque étape rapportés.
- Carte A100 lue dans `nvidia-smi.txt` ; nombre de tests réussis égal à N.
- Branche `donnees/t05/<RUN>` : un commit sans parent, deux fichiers, empreinte égale au sceau et à `vecteurs_sha256` d'`episodes.json`.
- Aucun jeton dans les fichiers ajoutés.
- Aucune destruction proposée avant ces vérifications.

**Surveillance**
- `docs/procedures/surveiller-instance-t04-v1.sh`, avec `PATH` vers `venv-vastai` et la base écrite par le lanceur.
- Tâche de fond relancée à l'identique ; rappel par `send_later` au plafond + 10 minutes.
- Contrôle scripté à 5 minutes. Lignes attendues :
  - `AMORCE … commit S` ;
  - « début : ETUDE=pilote MODE=reel COMMIT=S BRANCHE=… » ;
  - « préenregistrement lu : N tests… » ;
  - « branche … poussée avant l'installation » ;
  - nvidia-smi montrant une A100.
  Sinon : arrêt par l'identifiant (R10).

**Bancs (R5)**, versés et scellés :
- **Générateur** :
  - chacun de ses arrêts ;
  - repères : 5 000 → 13 200, 6 500 → 15 000, 7 800 → 15 000 ;
  - désaccord entre le résumé et le verdict ;
  - ligne en double.
- **Contrôles** :
  - cas sain et artefacts de la v7 qui s'appliquent ;
  - verdict altéré ; noyau différent du verdict ; durée différente de la formule ;
  - chemin cité faux ; fichier en trop dans S ;
  - tâche sans cibles ; invite altérée ; configuration sans sceau ;
  - GO révoqué ; suite en échec.
- **Lanceur** :
  - les 19 cas de la v7 ;
  - crédit juste sous le seuil et au seuil ;
  - deux instances tolérées ; relance ;
  - un faux vastai qui journalise les arguments, masqués.
- **Scellement** :
  - S1 à S8 ;
  - configuration ;
  - entropie absente ou altérée ;
  - verdict « nœud » sans décision.
- **Récupération** :
  - cas sain tiré de la répétition jouet ;
  - modification au lieu d'ajout ; deux RUN ; autre auteur ; sceau cassé ;
  - vecteurs absents ou d'une autre empreinte ; branche des vecteurs avec parent ;
  - jeton factice ; `resume.json` et `arret.json` ensemble.

## Étape 8 — Répétitions
**Répétition jouet au commit C**
- Conditions : `ETUDE=pilote`, `MODE=jouet`, dépôt nu local, jetons factices, `env -i`, environnement neuf (pas `VENV_EXISTANT`), au moins 5 Go libres avant chaque passage.
- Quatre passages :
  1. cas sain, jusqu'aux vecteurs poussés et vérifiés ;
  2. relance sur `…-v2` ;
  3. branche déjà présente, code 2 ;
  4. configuration citée fausse : arrêt consigné, `arret.json` poussé.
- Mesurer le temps entre la ligne AMORCE et la fin des tests.
- Limite connue depuis R-065 : le modèle jouet ne produit aucune action valide. L'appariement et les notations restent couverts seulement par les tests unitaires.

**Répétition à blanc sur le texte réel** (leçon VT-15) : en `MODE=jouet`, avec le préenregistrement et la configuration générés. Toutes les gardes d'avant le manifeste doivent passer, puis le run s'arrête, consigné, à `regler_determinisme` faute de carte.

**Répétition finale à blanc** : scellement, contrôles, puis banc du lanceur, sur un clone jetable avec les épingles réelles. D'abord avec un verdict synthétique, puis avec le vrai.

## Étape 9 — Textes
**Brouillon 8 du préenregistrement**
- Ordre des étapes de 1f53a08, avec son motif.
- Lignes de runs partiels réécrites :
  - arrêt au préchargement : `episodes.json` absent, un relancement si la cause est d'infrastructure ;
  - arrêt pendant l'appariement : format seul lisible ;
  - arrêt au chargement des juges ou pendant les notations décisives : familles lisibles.
- Liste d'arrêt complétée : préchargement ; poussée initiale refusée (code 2).
- Ligne l. 177 : repli « math » supprimé.
- Rangée l. 355 réécrite sans marqueur.
- Lignes nouvelles :
  - « Lancement » (PREREG, BRANCHE `-v1` et `-v2`) ;
  - « Index des invites » ;
  - « Réserves du verdict » (RV-5) ;
  - condition de crédit.
- « Calcul » mis à jour :
  - 670 tests réussis en 491,38 s sur 55458787 ;
  - départ du run 658 s après la création ;
  - nombre de tests au commit C ;
  - 102,8 ms par passe pour l'agent ;
  - budget de l'option retenue.
- l. 44 : « aucune exclusion ».
- Transparence :
  - R-132 à R-134, N-018, RV-5 ;
  - 1f53a08 : moment et motif ;
  - décision de Lazar ;
  - D-20 respecté.

**Configuration** : annotation de duree_max_s corrigée.

**Procédure, brouillon 5** :
- renvoie à la chaîne versée ;
- jeton sur `lciric/controle-ia-travail` ;
- un filtre unique : A100 SXM4 ou PCIe, gpu_ram ≥ 79, CUDA ≥ 13.0, offre vérifiée, centre de données, fiabilité ≥ 0,99, mémoire vive ≥ 128 Go (comme la revalidation), disque ≥ 80 Go ;
- sections « Contrôles avant dépense » et « Surveillance » faciles à repérer.

## Étape 10 — Après la décision de Lazar
1. Consigner le GO et une ligne R-… ; écrire le code de l'option (étape 5) ; refaire les preuves (étape 6) ; ajuster le brouillon 8.
2. Tirer l'entropie une seule fois (fichier en mode exclusif) ; produire le candidat en mode essai.
3. Relecture R2 du candidat : angles texte, code et chaîne, avec des sceptiques. Fichiers donnés :
   - le candidat et son différentiel avec le brouillon 7 ;
   - la configuration, le verdict, la décision ;
   - les valeurs des résultats (jamais les fiches) ;
   - le générateur, les scripts, les sorties des bancs et des répétitions ;
   - la procédure, les deux scripts de l'instance, le différentiel du code de e6ce058 à C.
   Leur demander aussi si chaque seuil de durée est compatible avec les estimations du même texte (leçon VR-14).
4. Corriger ; faire un contrôle mécanique par un sous-agent neuf ; poser les épingles.
5. Faire la répétition finale à blanc ; elle doit être conforme.
6. Sceller S ; lancer les contrôles sur S (suite complète comprise) ; relire le crédit ; consigner la dépense ; lancer par le lanceur, en un appel.
7. Contrôle à 5 minutes, surveillance, FIN, arrêt par l'identifiant (état relu « stopped »), récupération, fusion. Enfin, verdict R13 du pilote par un sous-agent neuf, scellé, puis soumis à Lazar.

## Ce qui attend le verdict ou la décision
Le noyau, duree_max_s, l'empreinte de la configuration, la ligne du verdict, les réserves, la durée estimée, la valeur de la liste d'arrêt, la règle de crédit et le devis. Selon l'option : les délais (b) ou le code de reprise (c). Puis la date du scellement. Les étapes 3 à 9 n'en dépendent pas et se font maintenant.

## Transparence
- Lecture seule : je n'ai rien écrit dans le dépôt (HEAD 02b0947, `git status` vide).
- J'ai extrait une copie de HEAD dans le bloc-notes, puis je l'ai supprimée. Seule reste la sortie de l'essai AVX2 (chemin ci-dessus).
- Le lecteur « texte » a réécrit `.git/FETCH_HEAD` par un `git fetch` ; aucune référence ni aucun fichier suivi n'a changé.
