"""Sceptique NO-01-1 : rejeu indépendant de la lecture gelée de la revalidation v2 (lire_bras, choisir_noyau,
duree_projetee_pilote) au code cité (6ec7434, exporté par git archive), depuis les résultats scellés, à 192 puis à 180
épisodes du pilote. Lecture seule du dépôt ; D-20 : seuls resume, mesures-defaut, lecture-defaut et lecture-math sont
ouverts (jamais episodes-defaut ni chemin-defaut).

Usage : python -I rejeu_no01.py DEPOT SRC_CITE"""
import hashlib
import json
import math
import sys
from pathlib import Path

DEPOT, SRC = Path(sys.argv[1]), Path(sys.argv[2])
sys.path.insert(0, str(SRC))
import controle_ia.environnements.revalider_pilote_a as rv  # noqa: E402

assert Path(rv.__file__).resolve().is_relative_to(SRC.resolve()), rv.__file__
RUN = DEPOT / "diag/20261011-225701-t05-revalidation-reel"
AUTORISES = ("resume.json", "mesures-defaut.json", "lecture-defaut.json", "lecture-math.json")


def lire_scelle(p: Path) -> dict:
    assert p.name in AUTORISES or p.parent.name == "prereg", p
    sha = hashlib.sha256(p.read_bytes()).hexdigest()
    sceau = (p.parent / (p.name + ".sha256")).read_text().split()
    assert sceau == [sha, p.name], (p, sceau, sha)
    return json.loads(p.read_text(encoding="utf-8"))


res = lire_scelle(RUN / "resume.json")["resultat"]
mes = lire_scelle(RUN / "mesures-defaut.json")["resultat"]
lecd = lire_scelle(RUN / "lecture-defaut.json")["resultat"]
lecm = lire_scelle(RUN / "lecture-math.json")["resultat"]["lecture"]
config = lire_scelle(DEPOT / "prereg/T0.5-revalidation-config-v1.json")
sortie = {}

print("code cité :", rv.__file__)
print("EPISODES_PILOTE (constante gelée) =", rv.EPISODES_PILOTE, "; TACHES_PILOTE =", rv.TACHES_PILOTE)
print("clé de configuration pour le nombre d'épisodes du pilote :",
      [k for k in config if "episode" in k.lower()], "(seulement le plafond R8 : duree_max_episodes_pilote_s =",
      config["duree_max_episodes_pilote_s"], ")")

# 1. durée projetée gelée, à 16 épisodes joués
d192 = rv.duree_projetee_pilote(mes["chrono"], 16)
print("\n[1] duree_projetee_pilote(chrono, 16) =", repr(d192), "; scellée :", repr(mes["duree_projetee_episodes_pilote_s"]),
      "; égales :", d192 == mes["duree_projetee_episodes_pilote_s"])
g, p = mes["chrono"]["generation_s"], mes["chrono"]["passe_unique_s"]
d180 = (g + p) * 180 / 16
print("    (g + p) =", g + p, "s ; × 192/16 =", (g + p) * 192 / 16, "; × 180/16 =", d180)
# la fonction gelée ne peut pas rendre 7 584,02 s pour un nombre entier d'épisodes joués
e_requis = (g + p) * rv.EPISODES_PILOTE / d180
print("    argument `episodes` qu'il faudrait passer à la fonction gelée pour obtenir", f"{d180:.2f}", "s :", e_requis,
      "(non entier : la fonction gelée ne produit pas cette valeur)")
sortie["d192"], sortie["d180"], sortie["episodes_requis"] = d192, d180, e_requis

# 2. lire_bras rejouée avec les entrées scellées, à 192 (lecture gelée)
def lire(duree):
    return rv.lire_bras(mes["mesures"], mes["controle_negatif"], lecd["repere"], mes["rejeu_identique"], config,
                        zone_generee=lecd["zone_generee"], audit=lecd["audit"], chemin=lecd["chemin"]["lecture"],
                        bras="defaut", memoire_pic_gio=mes["memoire_pic_gio"], duree_projetee_s=duree)


l192 = lire(d192)
print("\n[2] lire_bras(… duree = d192) == lecture scellée (lecture-defaut.json) :", l192 == lecd["lecture"],
      "; == resume.lectures.defaut :", l192 == res["lectures"]["defaut"])
print("    lire_bras(math, panne) == lecture-math.json :",
      rv.lire_bras({}, {}, None, None, config, panne=lecm["panne"]) == lecm)
c192 = rv.choisir_noyau({"defaut": l192, "math": lecm})
print("    choisir_noyau(192) :", c192, "; résumé scellé :", (res["noyau_retenu"], res["proposition_au_noeud"]),
      "; nœud :", res["noeud"])

# 3. même lecture, durée à 180 épisodes
l180 = lire(d180)
diff = {k: (l192[k], l180[k]) for k in l192 if l192[k] != l180[k]}
print("\n[3] lire_bras(… duree = d180) : clés qui changent :", diff)
c180 = rv.choisir_noyau({"defaut": l180, "math": lecm})
print("    choisir_noyau(180) :", c180)
sortie.update(l192=l192, l180=l180, diff=diff, c192=c192, c180=c180)

# 4. construction du générateur (l. 156) contre la lecture rejouée à 180
lec_retenue = dict(lecd["lecture"], R8_duree=True, conforme=True, conforme_avec_marge=True)
print("\n[4] dict(lec, R8_duree=True, conforme=True, conforme_avec_marge=True) == lire_bras(… d180) :",
      lec_retenue == l180)

# 5. seuil de bascule : plus grand nombre d'épisodes du pilote sous 7 800 s, en tâches de 3 épisodes
emax = config["duree_max_episodes_pilote_s"] * 16 / (g + p)
print("\n[5] épisodes du pilote au plus pour R8 :", emax, "; tâches de 3 épisodes au plus :", math.floor(emax / 3))
for t in (64, 63, 62, 61, 60):
    d = (g + p) * 3 * t / 16
    print(f"    {t} tâches ({3 * t} épisodes) : {d:.2f} s ; R8 {'tenue' if d <= 7800 else 'manquée'} ;",
          "duree_max_s =", min(15000, math.ceil((1.2 * d + 7200) / 60) * 60))
sortie["episodes_max_r8"] = emax

# 6. formule de duree_max_s à 192 et à 180
for nom, d in (("192", d192), ("180", d180)):
    print(f"[6] duree_max_s (formule gelée) à {nom} épisodes :", min(15000, math.ceil((1.2 * d + 7200) / 60) * 60),
          f"; temps laissé aux juges à 15 000 s : {15000 - d:.2f} s")

Path(sys.argv[0]).with_name("rejeu_no01-sortie.json").write_text(json.dumps(sortie, ensure_ascii=False, indent=1,
                                                                              default=str), encoding="utf-8")
