"""Affiche la structure (clés, types, nombres, booléens) des fichiers JSON autorisés, sans texte long (D-20 respectée :
seuls resume, mesures-defaut, lecture-defaut, lecture-math sont ouverts)."""
import json, sys
from pathlib import Path

AUTORISES = {"resume.json", "mesures-defaut.json", "lecture-defaut.json", "lecture-math.json"}

def montrer(x, pfx="", prof=0, maxprof=6):
    if isinstance(x, dict):
        for k, v in x.items():
            if isinstance(v, (dict, list)) and prof < maxprof:
                print(f"{pfx}{k}: {type(v).__name__}({len(v)})")
                montrer(v, pfx + "  ", prof + 1, maxprof)
            else:
                montrer_feuille(k, v, pfx)
    elif isinstance(x, list):
        for i, v in enumerate(x[:4]):
            if isinstance(v, (dict, list)):
                print(f"{pfx}[{i}]: {type(v).__name__}({len(v)})")
                montrer(v, pfx + "  ", prof + 1, maxprof)
            else:
                montrer_feuille(f"[{i}]", v, pfx)
        if len(x) > 4:
            print(f"{pfx}... ({len(x)} éléments)")

def montrer_feuille(k, v, pfx):
    if isinstance(v, str):
        print(f"{pfx}{k}: str(len={len(v)}) {v[:60]!r}")
    else:
        print(f"{pfx}{k}: {v!r}"[:200])

for chemin in sys.argv[1:]:
    p = Path(chemin)
    assert p.name in AUTORISES, p.name
    print("=====", p)
    montrer(json.loads(p.read_text(encoding="utf-8")))
