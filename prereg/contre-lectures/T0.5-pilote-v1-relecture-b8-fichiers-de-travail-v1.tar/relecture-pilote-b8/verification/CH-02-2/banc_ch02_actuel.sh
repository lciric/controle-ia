#!/usr/bin/env bash
# Banc de vérification de CH-02 (sceptique 2) : lanceur du pilote tel que relu (6928e183…), mode relance, avec
# l'instance du premier lancement arrêtée et gardée sur le compte. Dérivé du banc de la session (essais_lanceur, eef61f97…).
# Aucun appel réel : outil de location factice nommé faux_outil_location (aucun service, aucun binaire réel) ; la ligne V=
# de la copie du lanceur est redirigée vers lui ; clé d'API et GH_TOKEN retirés de l'environnement ; jetons factices.
# Variante : lanceur courant (856d516a…), correction CH-02 ; registres synthétiques à la forme exacte de N-019.
# Usage : banc_ch02_actuel.sh RACINE_NEUVE
set -uo pipefail
E=$1
W=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-pilote-b8/verification/CH-02-2
HN=$W/actuel-copie
LANCEUR=$HN/lancer_pilote_v1.sh
BN=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad
D=/home/user/controle-ia-travail
REF=942c65e
P=prereg/T0.5-pilote-8B-v1.md
VERSEES=docs/procedures/pilote-T0.5-v1
[ -e "$E" ] && { echo "$E existe déjà (R12)"; exit 2; }
mkdir -p "$E/B/pilote-v1" "$E/B/faux" "$E/home" "$E/bin-heure" "$E/bin-df"
cat > "$E/B/faux/faux_outil_location" <<'EOF'
#!/usr/bin/env bash
# outil de location factice : n'appelle aucun service
J=${FAUX_VASTAI_JOURNAL:?}
echo "appel : $1 $2" >> "$J"
case "$1 $2" in
  "search offers") printf '[{"id": 111, "gpu_name": "A100 SXM4", "dph_total": %s, "cpu_name": "%s", "cpu_arch": "amd64", "cpu_cores": 128}]\n' "${FAUX_PRIX:-1.10}" "${FAUX_CPU:-AMD EPYC 7513 32-Core Processor}" ;;
  "show user") printf '{"credit": %s}\n' "${FAUX_CREDIT:-20.0}" ;;
  "show instances") d='[{"id": 55292763, "actual_status": "exited", "cur_state": "stopped"}, {"id": 55458787, "actual_status": "exited", "cur_state": "stopped"}]'; printf '%s\n' "${FAUX_INSTANCES:-$d}" ;;
  "create instance")
    echo "CREATION FACTICE" >> "$J"
    a=("$@")
    for ((i = 0; i < ${#a[@]}; i++)); do
      [ "${a[$i]}" = "--label" ] && echo "etiquette ${a[$((i + 1))]}" >> "$J"
      if [ "${a[$i]}" = "--env" ]; then
        for kv in ${a[$((i + 1))]}; do case "$kv" in BRANCHE=*) echo "env $kv" >> "$J" ;; esac; done
      fi
    done
    printf '{"success": true, "new_contract": 99999999}\n' ;;
  *) echo "verbe inattendu" >&2; exit 9 ;;
esac
EOF
chmod +x "$E/B/faux/faux_outil_location"
cat > "$E/B/pilote-v1/controles_avant_depense_pilote_v1.sh" <<'EOF'
#!/usr/bin/env bash
mkdir -p "$2" && echo donnees > "$2/x"
echo "arguments : S=${1:0:12} mode=${3:-premier}"
echo "OK  essai"; echo "CONTRÔLES AVANT DÉPENSE : TOUS CONFORMES"
EOF
cp "$HN/normaliser_pilote_v1.py" "$E/B/pilote-v1/"
L=$E/B/pilote-v1/lancer_pilote_v1.sh
sed -e "s|^DEPOT=.*|DEPOT=$E/depot|" -e "s|^B=.*|B=$E/B|" -e 's|^V=.*|V=$B/faux/faux_outil_location|' "$LANCEUR" > "$L"
echo "lanceur source : $(sha256sum "$LANCEUR" | cut -d' ' -f1)"
echo "lignes changées dans la copie du lanceur : $(diff "$LANCEUR" "$L" | grep -c '^>')"
[ "$(sed -n 's/^B=//p' "$L")" = "$E/B" ] && [ "$(sed -n 's/^V=//p' "$L")" = '$B/faux/faux_outil_location' ] \
    && ! grep -q "venv-vastai" "$L" && ! grep -q "$BN/pilote-v1" "$L" || { echo "copie du lanceur non sûre"; exit 2; }
cat > "$E/bin-heure/date" <<EOF
#!/usr/bin/env bash
if [ "\$*" = "-u +%H%M" ]; then echo 2200; exit 0; fi
exec /usr/bin/date "\$@"
EOF
chmod +x "$E/bin-heure/date"
mkdir -p "$E/depot" && cd "$E/depot" && git init -q -b main
git config user.email essai@invalid; git config user.name essai; git config commit.gpgsign false
mkdir -p prereg scripts registres .claude/hooks "$VERSEES"
git -C "$D" show "$REF":scripts/amorce_instance_t05.sh > scripts/amorce_instance_t05.sh
git -C "$D" show "$REF":registres/go.md > registres/go.md
echo "| GO-2026-10-12-99 | 2026-10-12 | revendication | N-019, option (a) (essai) | — | — | Lazar | R-146 (essai) |" >> registres/go.md
git -C "$D" show "$REF":.claude/hooks/garde_calcul.py > .claude/hooks/garde_calcul.py
cat > registres/decisions.md <<'EOF'
# Registre des décisions (essai)

| id | date | décision | fondement |
|---|---|---|---|
| R-143 | 2026-10-12 | N-019 tranché sous la délégation R-140 : option (a) ; révocable par Lazar. | essai |
| R-146 | 2026-10-12 | GO-2026-10-12-99 de Lazar sur N-019, option (a) (essai). | essai |
| R-152 | 2026-10-12 | Relancement du pilote : cause d'infrastructure (panne réseau de l'hôte, essai, sans identifiant). | essai |
| R-151 | 2026-10-12 | Relancement du pilote : cause d'infrastructure (panne réseau de l'hôte ; instance 55700001 du premier lancement arrêtée par son identifiant, gardée, N-009 ; essai). | essai |

| id | ouvert le | objet | ce qu'il faut |
|---|---|---|---|
| N-019 | 2026-10-12 | nœud de la revalidation (essai) | tranché (a) par Lazar : GO-2026-10-12-99 (R-146) |
EOF
git add -A && git commit -qm "base"
EA=$(sha256sum scripts/amorce_instance_t05.sh | cut -d' ' -f1)
cat > "$P" <<EOF
# Préenregistrement du pilote (essai du banc CH-02)
- Scripts de l'instance, gelés par ce commit (\`ETUDE=pilote\`) : \`scripts/amorce_instance_t05.sh\` (\`$EA\`, sha256).
- Lancement : \`ETUDE=pilote\`, \`PREREG=$P\`, \`BRANCHE=calcul/t05-pilote-reel-v1\`, \`DEPOT_URL=https://github.com/lciric/controle-ia-travail.git\` ; relancement unique : \`PREREG=$P\`, \`BRANCHE=calcul/t05-pilote-reel-v2\`, même commit.
- Décision de Lazar sur N-019 : \`GO-2026-10-12-99\` (R-146) (GO de type « revendication »).
EOF
(cd prereg && sha256sum "$(basename "$P")" > "$(basename "$P").sha256")
cp "$E/B/pilote-v1/controles_avant_depense_pilote_v1.sh" "$E/B/pilote-v1/normaliser_pilote_v1.py" "$L" "$VERSEES/"
git add -A && git commit -qm "S : préenregistrement du pilote scellé (essai)"
git clone -q --bare . "$E/distant.git" && git remote add origin "$E/distant.git" && git fetch -q origin
echo "S = $(git rev-parse HEAD)"
cas() {   # $1 nom ; $2 code prédit par CH-02 ; $3 arguments du lanceur (« - » : premier lancement) ; puis l'environnement
    local nom=$1 attendu=$2 args=$3; shift 3
    rm -rf "$E/traces"; : > "$E/journal-$nom.txt"
    local a=(111 "$E/traces"); [ "$args" = "-" ] || read -r -a a <<<"$args"
    env -u VAST_API_KEY -u GH_TOKEN HOME="$E/home" PATH="$E/bin-heure:/usr/bin:/bin" PYTHONDONTWRITEBYTECODE=1 \
        HF_TOKEN=factice-hf-0000000 CONTROLE_IA_GITHUB_TOKEN=factice-gh-0000000 FAUX_VASTAI_JOURNAL="$E/journal-$nom.txt" \
        "$@" bash "$L" "${a[@]}" > "$E/sortie-$nom.txt" 2>&1
    local c=$?
    local cree; cree=$(grep -c "CREATION FACTICE" "$E/journal-$nom.txt")
    local v="conforme à la prédiction"; [ "$c" = "$attendu" ] || v="ÉCART à la prédiction (prédit $attendu)"
    echo "$nom : code $c ; créations factices $cree ; $v"
    grep -v '^$' "$E/sortie-$nom.txt" | tail -3 | sed 's/^/    | /' | cut -c1-220
    [ -f "$E/traces/lancement.txt" ] && cp "$E/traces/lancement.txt" "$E/lancement-$nom.txt"
    return 0
}
I2='{"id": 55292763, "actual_status": "exited", "cur_state": "stopped"}, {"id": 55458787, "actual_status": "exited", "cur_state": "stopped"}'
IP='{"id": 55700001, "actual_status": "exited", "cur_state": "stopped"}'
cas A0-premier-sain 0 - FAUX_X=1
cas A1-relance-premiere-arretee-gardee 0 "111 $E/traces relance R-151" "FAUX_INSTANCES=[$I2, $IP]"
cas A2-relance-premiere-seule-arretee 0 "111 $E/traces relance R-151" "FAUX_INSTANCES=[$IP]"
cas A3-relance-premiere-en-marche 2 "111 $E/traces relance R-151" 'FAUX_INSTANCES=[{"id": 55700001, "actual_status": "running", "cur_state": "running"}]'
cas A4-relance-autre-arretee-en-plus 2 "111 $E/traces relance R-151" "FAUX_INSTANCES=[$I2, $IP, {\"id\": 55700002, \"actual_status\": \"exited\", \"cur_state\": \"stopped\"}]"
cas A5-premier-avec-premiere-arretee 2 - "FAUX_INSTANCES=[$I2, $IP]"
cas A6-relance-cause-sans-identifiant 2 "111 $E/traces relance R-152" "FAUX_INSTANCES=[$I2, $IP]"
grep -l 'factice-hf\|factice-gh' "$E"/sortie-*.txt "$E"/lancement-*.txt "$E"/journal-*.txt 2>/dev/null | sed 's/^/JETON AFFICHÉ : /' || true
echo "FIN DU BANC CH-02 (lanceur courant)"
