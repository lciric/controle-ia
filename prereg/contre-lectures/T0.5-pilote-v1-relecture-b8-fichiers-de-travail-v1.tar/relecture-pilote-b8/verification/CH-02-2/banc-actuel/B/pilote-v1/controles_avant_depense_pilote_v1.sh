#!/usr/bin/env bash
mkdir -p "$2" && echo donnees > "$2/x"
echo "arguments : S=${1:0:12} mode=${3:-premier}"
echo "OK  essai"; echo "CONTRÔLES AVANT DÉPENSE : TOUS CONFORMES"
