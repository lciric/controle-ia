# Registre des décisions (essai, banc CH-02)

| id | date | décision | fondement |
|---|---|---|---|
| R-146 | 2026-10-12 | GO-2026-10-12-99 de Lazar sur N-019, option (a) (essai). | essai |

| id | ouvert le | objet | ce qu'il faut |
|---|---|---|---|
| N-019 | 2026-10-12 | nœud de la revalidation (essai) | tranché (a) par Lazar : GO-2026-10-12-99 (R-146) |
