#!/usr/bin/env bash
mkdir -p "$2" && echo donnees > "$2/x"
echo "arguments : S=${1:0:12} mode=${3:-premier}"
echo "OK  contrôles factices (banc CH-02)"; echo "CONTRÔLES AVANT DÉPENSE : TOUS CONFORMES"
