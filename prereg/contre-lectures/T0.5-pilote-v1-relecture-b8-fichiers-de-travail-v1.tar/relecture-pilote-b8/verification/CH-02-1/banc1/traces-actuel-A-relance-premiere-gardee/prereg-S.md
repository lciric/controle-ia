# Préenregistrement du pilote (essai du banc CH-02)
- Scripts de l'instance, gelés par ce commit (`ETUDE=pilote`) : `scripts/amorce_instance_t05.sh` (`59f49aab394c4b7659b716792203663243a106355fbabf666bbb1f61ed55de73`, sha256).
- Décision de Lazar sur N-019 : `GO-2026-10-12-99` (R-146) (GO de type « revendication »).
- Lancement : `ETUDE=pilote`, `PREREG=prereg/T0.5-pilote-8B-v1.md`, `BRANCHE=calcul/t05-pilote-reel-v1`, `DEPOT_URL=https://github.com/lciric/controle-ia-travail.git` ; relancement unique : `PREREG=prereg/T0.5-pilote-8B-v1.md`, `BRANCHE=calcul/t05-pilote-reel-v2`, même commit.
