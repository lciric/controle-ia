#!/usr/bin/env bash
# Banc de vérification de CH-02 (sceptique 1), lecture seule hors de ce dossier.
# Aucun appel au vrai outil de location : V pointe sur un faux outil local (loueur-factice) ; environnement vidé (env -i),
# HOME redirigé, aucune clé d'API, jetons factices ; dépôt synthétique et dépôt distant nu locaux.
# Usage : banc_ch02.sh RACINE_NEUVE
set -uo pipefail
E=$1
[ -e "$E" ] && { echo "$E existe déjà"; exit 2; }
D=/home/user/controle-ia-travail
BN=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad
SRC_H0=$BN/relecture-pilote-b8/chaine/H0/lancer_pilote_v1.sh      # version relue par l'angle « chaine » (6928e183…)
SRC_ACT=$BN/pilote-v1/lancer_pilote_v1.sh                           # version courante (856d516a…)
P=prereg/T0.5-pilote-8B-v1.md
VERSEES=docs/procedures/pilote-T0.5-v1
echo "source H0     : $(sha256sum < "$SRC_H0" | cut -c1-16)"
echo "source actuel : $(sha256sum < "$SRC_ACT" | cut -c1-16)"

construire() {   # $1 nom de la version ; $2 lanceur source
    local X=$E/$1 SRC=$2
    mkdir -p "$X/B/pilote-v1" "$X/B/outil" "$X/bin" "$X/home"
    cat > "$X/B/outil/loueur-factice" <<'EOF'
#!/usr/bin/env bash
# faux outil de location : n'appelle aucun service
J=${FAUX_JOURNAL:?}
echo "appel : $1 $2" >> "$J"
case "$1 $2" in
  "search offers") printf '[{"id": 111, "gpu_name": "A100 SXM4", "dph_total": 1.10, "cpu_name": "AMD EPYC 7513 32-Core Processor", "cpu_arch": "amd64", "cpu_cores": 128}]\n' ;;
  "show user") printf '{"credit": 20.0}\n' ;;
  "show instances") printf '%s\n' "${FAUX_INSTANCES:?}" ;;
  "create instance") echo "CREATION FACTICE" >> "$J"; printf '{"success": true, "new_contract": 99999999}\n' ;;
  *) echo "verbe inattendu" >&2; exit 9 ;;
esac
EOF
    chmod +x "$X/B/outil/loueur-factice"
    cat > "$X/bin/df" <<'EOF'
#!/usr/bin/env bash
printf 'Filesystem 1024-blocks Used Available Capacity Mounted\n/dev/x 100000000 1000 90000000 1%% /\n'
EOF
    chmod +x "$X/bin/df"
    cat > "$X/B/pilote-v1/controles_avant_depense_pilote_v1.sh" <<'EOF'
#!/usr/bin/env bash
mkdir -p "$2" && echo donnees > "$2/x"
echo "arguments : S=${1:0:12} mode=${3:-premier}"
echo "OK  contrôles factices (banc CH-02)"; echo "CONTRÔLES AVANT DÉPENSE : TOUS CONFORMES"
EOF
    cp "$BN/pilote-v1/normaliser_pilote_v1.py" "$X/B/pilote-v1/"
    local L=$X/B/pilote-v1/lancer_pilote_v1.sh
    sed -e "s|^DEPOT=.*|DEPOT=$X/depot|" -e "s|^B=.*|B=$X/B|" -e 's|^V=.*|V=$B/outil/loueur-factice|' "$SRC" > "$L"
    local n; n=$(diff "$SRC" "$L" | grep -c '^>')
    if [ "$n" != 3 ] || [ "$(sed -n 's/^V=//p' "$L")" != '$B/outil/loueur-factice' ] || grep -q "$BN/venv" "$L" \
        || grep -q "^B=$BN\$" "$L"; then echo "copie du lanceur $1 non sûre"; exit 2; fi
    echo "copie du lanceur $1 : $n lignes changées (DEPOT, B, V), aucun chemin vers le vrai outil"
    mkdir -p "$X/depot" && cd "$X/depot" && git init -q -b main
    git config user.email essai@invalid; git config user.name essai; git config commit.gpgsign false
    mkdir -p prereg scripts registres .claude/hooks "$VERSEES"
    git -C "$D" show HEAD:scripts/amorce_instance_t05.sh > scripts/amorce_instance_t05.sh
    git -C "$D" show HEAD:registres/go.md > registres/go.md
    git -C "$D" show HEAD:.claude/hooks/garde_calcul.py > .claude/hooks/garde_calcul.py
    echo "| GO-2026-10-12-99 | 2026-10-12 | revendication | N-019, option (a) (essai) | — | — | Lazar | R-146 (essai) |" >> registres/go.md
    cat > registres/decisions.md <<'EOF'
# Registre des décisions (essai, banc CH-02)

| id | date | décision | fondement |
|---|---|---|---|
| R-146 | 2026-10-12 | GO-2026-10-12-99 de Lazar sur N-019, option (a) (essai). | essai |

| id | ouvert le | objet | ce qu'il faut |
|---|---|---|---|
| N-019 | 2026-10-12 | nœud de la revalidation (essai) | tranché (a) par Lazar : GO-2026-10-12-99 (R-146) |
EOF
    git add -A && git commit -qm "base"
    local EA; EA=$(sha256sum scripts/amorce_instance_t05.sh | cut -d' ' -f1)
    cat > "$P" <<EOF
# Préenregistrement du pilote (essai du banc CH-02)
- Scripts de l'instance, gelés par ce commit (\`ETUDE=pilote\`) : \`scripts/amorce_instance_t05.sh\` (\`$EA\`, sha256).
- Décision de Lazar sur N-019 : \`GO-2026-10-12-99\` (R-146) (GO de type « revendication »).
- Lancement : \`ETUDE=pilote\`, \`PREREG=$P\`, \`BRANCHE=calcul/t05-pilote-reel-v1\`, \`DEPOT_URL=https://github.com/lciric/controle-ia-travail.git\` ; relancement unique : \`PREREG=$P\`, \`BRANCHE=calcul/t05-pilote-reel-v2\`, même commit.
EOF
    (cd prereg && sha256sum "$(basename "$P")" > "$(basename "$P").sha256")
    cp "$X/B/pilote-v1/controles_avant_depense_pilote_v1.sh" "$X/B/pilote-v1/normaliser_pilote_v1.py" "$L" "$VERSEES/"
    git add -A && git commit -qm "S : préenregistrement scellé (essai)"
    git clone -q --bare . "$X/distant.git" && git remote add origin "$X/distant.git" && git fetch -q origin
    cp registres/decisions.md "$X/decisions-base.md"
    cd "$E"
}

INST_DEUX='{"id": 55292763, "actual_status": "exited", "cur_state": "stopped"}, {"id": 55458787, "actual_status": "exited", "cur_state": "stopped"}'
cas() {   # $1 version ; $2 nom ; $3 code attendu ; $4 ligne R-151 (vide : aucune) ; $5 liste des instances ; $6 mode
    local X=$E/$1 nom=$2 attendu=$3 ligne=$4 inst=$5 mode=$6
    cp "$X/decisions-base.md" "$X/depot/registres/decisions.md"
    [ -n "$ligne" ] && printf '%s\n' "$ligne" >> "$X/depot/registres/decisions.md"
    local T=$E/traces-$1-$nom J=$E/journal-$1-$nom.txt; : > "$J"
    local args=(111 "$T"); [ "$mode" = relance ] && args+=(relance R-151)
    env -i HOME="$X/home" PATH="$X/bin:/usr/bin:/bin" LANG=C.UTF-8 HF_TOKEN=factice-hf-0000000 \
        CONTROLE_IA_GITHUB_TOKEN=factice-gh-0000000 FAUX_JOURNAL="$J" FAUX_INSTANCES="[$inst]" \
        bash "$X/B/pilote-v1/lancer_pilote_v1.sh" "${args[@]}" > "$E/sortie-$1-$nom.txt" 2>&1
    local c=$? cree; cree=$(grep -c "CREATION FACTICE" "$J")
    local v="CONFORME"; [ "$c" = "$attendu" ] || v="NON CONFORME (attendu $attendu)"
    echo "$1 / $nom (mode $mode) : code $c ; créations factices $cree ; $v"
    grep -E "instances|tolérée|relance|N-019|registre" "$E/sortie-$1-$nom.txt" | sed 's/^/    | /' | cut -c1-220
}

construire h0 "$SRC_H0"
construire actuel "$SRC_ACT"
R_SIMPLE="| R-151 | 2026-10-12 | Relancement du pilote : cause d'infrastructure (panne réseau de l'hôte) ; instance 12345678 du premier lancement arrêtée par son identifiant et gardée (N-009) (essai). | essai |"
PREMIERE_GARDEE="$INST_DEUX, {\"id\": 12345678, \"actual_status\": \"exited\", \"cur_state\": \"stopped\"}"
echo "== version relue (H0)"
cas h0 A-relance-premiere-gardee 2 "$R_SIMPLE" "$PREMIERE_GARDEE" relance
cas h0 B-relance-premiere-detruite 0 "$R_SIMPLE" "$INST_DEUX" relance
cas h0 C-premier-lancement-sain 0 "" "$INST_DEUX" premier
echo "== version courante"
cas actuel A-relance-premiere-gardee 0 "$R_SIMPLE" "$PREMIERE_GARDEE" relance
cas actuel B-relance-premiere-detruite 0 "$R_SIMPLE" "$INST_DEUX" relance
cas actuel C-premier-lancement-sain 0 "" "$INST_DEUX" premier
cas actuel D-premier-avec-instance-etrangere 2 "$R_SIMPLE" "$PREMIERE_GARDEE" premier
cas actuel E-relance-premiere-en-marche 2 "$R_SIMPLE" "$INST_DEUX, {\"id\": 12345678, \"actual_status\": \"running\", \"cur_state\": \"running\"}" relance
cas actuel F-relance-cause-sans-instance 2 "| R-151 | 2026-10-12 | Relancement du pilote : cause d'infrastructure (panne réseau de l'hôte, essai). | essai |" "$PREMIERE_GARDEE" relance
cas actuel G-relance-autre-identifiant 2 "${R_SIMPLE/12345678/12345679}" "$PREMIERE_GARDEE" relance
cas actuel H-relance-apostrophe 0 "| R-151 | 2026-10-12 | Relancement du pilote, cause d'infrastructure : l'instance 12345678 (premier lancement) est arrêtée et gardée (essai). | essai |" "$PREMIERE_GARDEE" relance
cas actuel I-relance-majuscule 2 "| R-151 | 2026-10-12 | Relancement du pilote, cause d'infrastructure. Instance 12345678 (premier lancement) arrêtée et gardée (essai). | essai |" "$PREMIERE_GARDEE" relance
NBSP=$(printf '\xc2\xa0')
cas actuel J-relance-espace-insecable 2 "| R-151 | 2026-10-12 | Relancement du pilote, cause d'infrastructure : instance${NBSP}12345678 arrêtée et gardée (essai). | essai |" "$PREMIERE_GARDEE" relance
cas actuel K-relance-deux-identifiants 2 "| R-151 | 2026-10-12 | Relancement du pilote, cause d'infrastructure : instance 12345678 arrêtée et gardée ; comme l'instance 55458787 (essai). | essai |" "$PREMIERE_GARDEE" relance
cas actuel L-relance-premiere-etat-inattendu 2 "$R_SIMPLE" "$INST_DEUX, {\"id\": 12345678, \"actual_status\": \"offline\", \"cur_state\": \"stopped\"}" relance
grep -l 'factice-hf\|factice-gh' "$E"/sortie-*.txt "$E"/journal-*.txt "$E"/traces-*/lancement.txt 2>/dev/null | sed 's/^/JETON AFFICHÉ : /'
echo "FIN DU BANC CH-02"
