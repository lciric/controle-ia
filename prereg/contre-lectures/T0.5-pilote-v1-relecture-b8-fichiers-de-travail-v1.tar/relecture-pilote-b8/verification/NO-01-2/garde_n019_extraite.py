import re, sys, unicodedata
norm = lambda s: unicodedata.normalize("NFC", s).lower()          # casse et accents composés : aucune forme n'échappe
lignes = open(sys.argv[1], encoding="utf-8").read().split("\n")
n19 = [x for x in lignes if x.startswith("| N-019 |")]
if len(n19) != 1 or "tranché" not in norm(n19[0].rsplit("|", 2)[-2]) or "(a)" not in n19[0].rsplit("|", 2)[-2]:
    sys.exit("N-019")
# révoque, révoqué(e), révocation ; « révocable » ne déclenche pas
if any(re.search(r"révoqu|révocation", norm(x)) and "n-019" in norm(x) for x in lignes if x.startswith("| R-")):
    sys.exit("N-019 révoquée")
if sys.argv[2] == "relance":
    r = [x for x in lignes if x.startswith(f"| {sys.argv[3]} |")]
    if len(r) != 1 or not all(m in r[0].lower() for m in ("relancement", "pilote", "infrastructure")):
        sys.exit("relance non consignée")
