"""Sceptique 2 de NO-01 : rejoue la lecture gelée du bras « defaut » (lire_bras, choisir_noyau, code au commit cité
6ec7434, identique à la tête) depuis les résultats scellés de la revalidation v2, à 192 puis à 180 épisodes du pilote.
N'ouvre ni episodes-defaut.json ni chemin-defaut.json (D-20). Lecture seule du dépôt : arguments = racine du dépôt."""
import json
import math
import subprocess
import sys
from pathlib import Path

D = Path(sys.argv[1])
sys.path.insert(0, str(D / "src"))
import controle_ia.environnements.revalider_pilote_a as rv  # noqa: E402

RUN = D / "diag/20261011-225701-t05-revalidation-reel"
mes = json.loads((RUN / "mesures-defaut.json").read_text())["resultat"]
lecf = json.loads((RUN / "lecture-defaut.json").read_text())["resultat"]
lecm = json.loads((RUN / "lecture-math.json").read_text())["resultat"]["lecture"]
config = json.loads((D / "prereg/T0.5-revalidation-config-v1.json").read_text())
config = config.get("config", config)
print("EPISODES_PILOTE (code cité) =", rv.EPISODES_PILOTE, "; TACHES_PILOTE =", rv.TACHES_PILOTE)
print("config : duree_max_episodes_pilote_s =", config["duree_max_episodes_pilote_s"], "; cles 'episodes' :",
      [k for k in config if "episode" in k])
chrono = mes["chrono"]
print("generation_s =", chrono["generation_s"], "; passe_unique_s =", chrono["passe_unique_s"])
print("par episode =", (chrono["generation_s"] + chrono["passe_unique_s"]) / 16)
d192 = rv.duree_projetee_pilote(chrono, 16)
print("duree_projetee_pilote(chrono, 16) [192, code gele] =", d192, "; scelle :", mes["duree_projetee_episodes_pilote_s"],
      "; egal :", d192 == mes["duree_projetee_episodes_pilote_s"])


def lire(d):
    return rv.lire_bras(mes["mesures"], mes["controle_negatif"], lecf["repere"], mes["rejeu_identique"], config,
                        zone_generee=lecf["zone_generee"], audit=lecf["audit"], chemin=lecf["chemin"]["lecture"],
                        bras="defaut", memoire_pic_gio=mes["memoire_pic_gio"], duree_projetee_s=d)


l192 = lire(d192)
print("lire_bras(192) == lecture scellee :", l192 == lecf["lecture"])
print("choisir_noyau(192) :", rv.choisir_noyau({"defaut": l192, "math": lecm}))
for n_ep in (180, 183, 186, 189, 192):
    d = (chrono["generation_s"] + chrono["passe_unique_s"]) * n_ep / 16
    l = lire(d)
    diff = sorted(k for k in l if l[k] != l192[k])
    dm = min(15000, math.ceil((1.2 * d + 7200) / 60) * 60)
    print(f"{n_ep} episodes ({n_ep // 3} taches) : d = {d:.2f} s ; R8 = {l['R8_duree']} ; cles changees vs 192 : {diff} ;"
          f" choisir_noyau : {rv.choisir_noyau({'defaut': l, 'math': lecm})} ; duree_max_s formule = {dm}"
          f" ; reste aux juges = {dm - d:.0f} s")
# nombre maximal de taches (3 episodes) tenant R8
par_tache = (chrono["generation_s"] + chrono["passe_unique_s"]) * 3 / 16
print("taches max sous 7 800 s :", math.floor(7800 / par_tache), f"({7800 / par_tache:.3f})")
