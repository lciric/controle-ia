#!/usr/bin/env bash
# rejoue le bloc « relance » extrait des contrôles, sur trois états de la branche -v1 du dépôt nu de l'essai
W=$1
. "$W/commits.txt"
G="git -C $W/distant.git"
jouer() {
  $G update-ref refs/heads/calcul/t05-pilote-reel-v1 "$2"
  for v in avant-r2 actuel; do
    res=$(for i in $(seq 1 10); do bash "$W/bloc-relance-$v.sh" "$W/local" | grep -- '-v1' ; done | sort | uniq -c | tr -s ' ' | tr '\n' ';')
    echo "$1 [$v] : $res"
  done
}
echo "branche -v2 sur le dépôt nu : $($G for-each-ref --format='%(refname)' refs/heads/calcul/ | tr '\n' ' ')"
echo "== cas 1 : -v1 porte diag/<RUN>/episodes.json (arbre réel de 942c65e + le fichier) : KO attendu"
jouer cas1-episodes-arbre-reel "$V1_EPISODES"
echo "== cas 2 : -v1 sans episodes.json (arbre réel + resume.json) : OK attendu"
jouer cas2-sain-arbre-reel "$V1_SAIN"
echo "== cas 3 : -v1 porte episodes.json, petit arbre (3 fichiers, comme un dépôt synthétique) : KO attendu"
jouer cas3-episodes-petit-arbre "$V1_PETIT"
echo "== statut du tube sur le cas 1"
$G update-ref refs/heads/calcul/t05-pilote-reel-v1 "$V1_EPISODES"
git -C "$W/local" fetch -q origin calcul/t05-pilote-reel-v1 && bash "$W/statut-tube.sh" "$W/local"
