#!/usr/bin/env bash
set -uo pipefail
git -C "$1" ls-tree -r --name-only FETCH_HEAD | grep -q '/episodes\.json$'
echo "PIPESTATUS=${PIPESTATUS[*]}"
