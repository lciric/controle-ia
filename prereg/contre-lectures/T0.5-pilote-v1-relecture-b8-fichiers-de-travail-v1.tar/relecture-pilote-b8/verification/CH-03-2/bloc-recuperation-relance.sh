#!/usr/bin/env bash
set -uo pipefail
MODE=relance; PREMIERE=calcul/t05-pilote-reel-v1; S=942c65e365f809b7142b280b4adc1922ce3ab67c
echecs=0; ok() { echo "OK  $*"; }; ko() { echo "KO  $*"; echecs=$((echecs + 1)); }
cd "$1" || exit 9
# 0. relance : branche du premier lancement lue et citée (CH-09) ; elle ne doit porter aucun episodes.json (préséance)
if [ "$MODE" = relance ]; then
    if git fetch -q origin "$PREMIERE" 2>/dev/null; then
        V1=$(git rev-parse FETCH_HEAD)
        echo "branche du premier lancement $PREMIERE : tête $V1 ; runs : $(git diff --name-only "$S" "$V1" | grep -E '^diag/' | cut -d/ -f2 | sort -u | tr '\n' ' ')"
        git ls-tree -r --name-only "$V1" | grep -q '/episodes\.json$' && ko "0 $PREMIERE porte un episodes.json : relancement contraire à la préséance" \
            || ok "0 $PREMIERE lue, sans episodes.json"
    else ko "0 $PREMIERE introuvable : relance sans premier lancement"; fi
fi
echo "echecs=$echecs"
