import json, sys
offre, brut, sortie = int(sys.argv[1]), sys.argv[2], sys.argv[3]
d = [o for o in json.load(open(brut)) if o.get("id") == offre]
if len(d) != 1:
    sys.exit(f"offre {offre} absente des offres conformes au filtre du plan")
champs = ("id", "gpu_name", "gpu_ram", "num_gpus", "cuda_max_good", "driver_version", "cpu_name", "cpu_arch",
          "cpu_cores", "cpu_cores_effective", "cpu_ram", "disk_space",
          "reliability2", "verification", "hosting_type", "rentable", "end_date", "dph_total", "storage_total_cost",
          "inet_down_cost", "inet_up_cost", "geolocation")
json.dump({k: d[0].get(k) for k in champs}, open(sortie, "w"), indent=1)
if not isinstance(d[0].get("dph_total"), (int, float)):
    sys.exit(f"offre {offre} sans prix lisible")
if d[0].get("cpu_name") != "AMD EPYC 7513 32-Core Processor":
    sys.exit(f"offre {offre} : processeur {d[0].get('cpu_name')!r} ; seul celui de la revalidation (AMD EPYC 7513, débit mesuré, AVX2) est admis")
print(d[0]["dph_total"])
