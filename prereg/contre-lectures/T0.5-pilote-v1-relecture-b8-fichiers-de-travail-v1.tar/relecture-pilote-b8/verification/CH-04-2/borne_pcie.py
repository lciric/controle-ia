"""Borne haute du ralentissement A100 PCIe 80 Go / A100 SXM4 80 Go sur les épisodes du pilote (CH-04, sceptique 2).
Hypothèse la plus défavorable : tout le trafic mémoire de la carte est exposé (aucun recouvrement par le travail de
l'hôte). Bandes passantes : spécifications publiées par NVIDIA, citées de mémoire, non vérifiées sur PDF ici."""
import json, sys
m = json.load(open(sys.argv[1]))["resultat"]
ch = m["chrono"]
pas_ms = 1000 * ch["generation_s"] / ch["passes_decodage"]
proj = m["duree_projetee_episodes_pilote_s"] * 180 / 192
print(f"pas mesuré (A100 SXM4, EPYC 7513, lot de 8) : {pas_ms:.2f} ms ; projection 180 épisodes : {proj:.2f} s")
poids = 8.03e9 * 2                         # Llama-3.1-8B en bf16, octets
kv_jeton = 32 * 8 * 128 * 2 * 2            # couches x têtes KV x dimension x (K, V) x octets = 131 072
kv = 8 * ch["longueur_remplie_max"] * kv_jeton   # lot de 8 au contexte maximal joué (borne haute)
for nom, bw in (("SXM4 80 Go", 2039e9), ("PCIe 80 Go", 1935e9)):
    print(f"{nom} : lecture poids + cache par pas = {(poids + kv) / bw * 1e3:.2f} ms")
delta_ms = (poids + kv) * (1 / 1935e9 - 1 / 2039e9) * 1e3
frac = delta_ms / pas_ms
print(f"écart par pas <= {delta_ms:.2f} ms, soit <= {100 * frac:.2f} % du pas ; sur la projection : <= {frac * proj:.0f} s")
# parts limitées par le calcul (préremplissage, passes uniques), 20 % plus lentes au pire sous 300 W
pre = ch["jetons_remplissage"] * 180 / 16 * 2 * 8.03e9 / 200e12
pu = ch["passe_unique_s"] * 180 / 16
print(f"préremplissage ~{pre:.0f} s et passes uniques {pu:.0f} s : +20 % au pire = +{0.2 * (pre + pu):.0f} s")
total = frac * proj + 0.2 * (pre + pu)
print(f"borne totale ~{total:.0f} s ({100 * total / proj:.2f} %) ; marge de R8 : {7800 - proj:.0f} s ; "
      f"marge « lot plein » (candidat 2, TX-12) : {7800 - 7752.55:.0f} s")
print(f"H200, T0.4 v3, lot de 1 : 1000/30,3 = {1000 / 30.3:.1f} ms par pas, pour {poids / 4.8e12 * 1e3:.1f} ms de lecture des poids "
      f"(4,8 To/s) : le pas est dominé par le travail de l'hôte")
