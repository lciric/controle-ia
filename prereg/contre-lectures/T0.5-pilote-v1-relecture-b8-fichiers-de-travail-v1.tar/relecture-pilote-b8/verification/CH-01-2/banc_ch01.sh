#!/usr/bin/env bash
# Banc indépendant du constat CH-01 (sceptique 2). Tout se passe dans le clone jetable $W/clone (origine retirée) ;
# rien n'est écrit dans le dépôt de travail ni dans le bloc-notes pilote-v1. Générateur, normaliseur et lignes de
# contrôle : copies de la version relue (H0-copie, empreintes égales à journaux/empreintes-bloc-notes-au-debut.txt) et
# de la version actuelle du bloc-notes (actuel-copie).
set -uo pipefail
W=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-pilote-b8/verification/CH-01-2
PYG=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/scellement-revalidation/venv-gpu-neuf/bin/python
export PYTHONDONTWRITEBYTECODE=1
C=$W/clone; cd "$C" || exit 2
RELU=brouillons/T0.5-pilote-8B-v1-candidat1.md
ETAT="T0.5-pilote-v1-etat-des-lieux-resultats-v1.json=8ca0f843b17ba24e78280cd1bf0ba85e2f56639e31a0630ed9779ec96d883011,T0.5-pilote-v1-etat-des-lieux-fichiers-de-travail-v1.tar=59f2d2976b2350a8389b9e5a79735c223fa4b6c2d216a4cea8c068a4713e908b"
REL="T0.5-pilote-v1-relecture-b8-a-venir-v1.md=0000000000000000000000000000000000000000000000000000000000000000"
GELES=". :(exclude)prereg :(exclude)brouillons :(exclude)registres :(exclude)docs :(exclude)diag :(exclude)runs :(exclude)donnees :(exclude)livrables :(exclude)papiers :(exclude)traces :(exclude)CLAUDE.md"
norm() { "$PYG" -I -B "$W/H0-copie/normaliser_pilote_v1.py" "$1"; }
N_RELU=$(git show "942c65e:$RELU" | "$PYG" -I -B "$W/H0-copie/normaliser_pilote_v1.py" -)
echo "candidat 1 : brut $(git show "942c65e:$RELU" | sha256sum | cut -c1-16)… ; normalisé (normaliseur relu) $N_RELU"

generer() {   # $1 nom du cas ; génère en mode candidat au HEAD du clone, comme le scellement (commit = HEAD)
    local R=$W/sorties/$1; rm -rf "$R"; mkdir -p "$R"; echo 1 > "$R/entropie.txt"
    "$PYG" -I -B "$W/H0-copie/remplir_pilote_v1.py" . "$(git rev-parse HEAD)" candidat "2026-10-12 01:29 UTC" "$R/entropie.txt" \
        "$R/prereg.md" "$R/config.json" --taches donnees/t05-pilote-v1/taches-pilote-60-v1.json \
        --rapports-etat "$ETAT" --rapports-relecture "$REL" > "$R/generateur.json" 2> "$R/generateur.err"
    local c=$?
    echo "[$1] HEAD $(git rev-parse --short HEAD) ; générateur code $c ; $(cut -c1-160 "$R/generateur.err" | tail -1)"
    [ "$c" = 0 ] || return 1
    local n; n=$(norm "$R/prereg.md")
    echo "[$1] tests collectés : $(sed -n 's/.*"tests": "\([0-9]*\)".*/\1/p' "$R/generateur.json") ; config brute = candidat 1 : $(cmp -s "$R/config.json" <(git show 942c65e:brouillons/T0.5-pilote-config-v1-candidat1.json) && echo oui || echo non)"
    echo "[$1] normalisé $n ; = épingle du candidat 1 : $([ "$n" = "$N_RELU" ] && echo OUI, le scellement passerait || echo NON, le scellement refuserait)"
    echo "[$1] lignes brutes différentes du candidat 1 : $(diff <(git show "942c65e:$RELU") "$R/prereg.md" | grep -c '^>')"
    diff <(git show "942c65e:$RELU") "$R/prereg.md" | grep '^[<>]' | cut -c1-170 | sed "s/^/[$1]     /"
    return 0   # pipefail : le code 1 de diff (différences trouvées) ne doit pas passer pour un échec du générateur
}

simuler_S() {  # $1 nom du cas : commit S qui n'ajoute que les quatre fichiers, comme sceller_pilote_v1.sh
    local R=$W/sorties/$1
    cp "$R/prereg.md" prereg/T0.5-pilote-8B-v1.md; cp "$R/config.json" prereg/T0.5-pilote-config-v1.json
    for f in prereg/T0.5-pilote-8B-v1.md prereg/T0.5-pilote-config-v1.json; do
        echo "$(sha256sum "$f" | cut -d' ' -f1)  $(basename "$f")" > "$f.sha256"; done
    git add prereg/T0.5-pilote-8B-v1.md prereg/T0.5-pilote-8B-v1.md.sha256 prereg/T0.5-pilote-config-v1.json prereg/T0.5-pilote-config-v1.json.sha256
    git commit -qm "essai : S simulé ($1)"; git rev-parse HEAD
}

controles_releves() {  # $1 S ; lignes 48-61 VERBATIM des contrôles relus (H0), puis lignes 56-73 VERBATIM des contrôles actuels
    local S=$1 P=prereg/T0.5-pilote-8B-v1.md PY=$PYG echec=0
    ok() { echo "    OK  $*"; }; ko() { echo "    KO  $*"; echec=1; }
    echo "  contrôles relus (H0, l. 48-61) sur S=${S:0:7} :"
    eval "$(sed -n '48,61p' "$W/H0-copie/controles_avant_depense_pilote_v1.sh")"
    if [ -n "${CODE_RELU:-}" ]; then
        echo "  contrôles actuels (l. 56-58, 63-73), CODE_RELU=${CODE_RELU:0:7} :"
        eval "$(sed -n '56,73p' "$W/actuel-copie/controles_avant_depense_pilote_v1.sh")"
    fi
}

# ------------------------------------------------------------------ cas --------------------------------------------
cas="${1:-tous}"
base() { git checkout -q --detach "$1" && git status --porcelain --untracked-files=no | head -3; }
if [ "$cas" = tous ] || [ "$cas" = R ]; then
    echo "== R : reproduction du candidat 1 au commit 3ffab9f (fidélité du banc) =="
    base 3ffab9f; generer R
fi
if [ "$cas" = tous ] || [ "$cas" = 0 ]; then
    echo "== 0 : sain, au commit 942c65e (aucun changement de code depuis le code relu) =="
    base 942c65e; generer 0 && S0=$(simuler_S 0) && { CODE_RELU=3ffab9ff88761e73074c820b0cb456e51de9c575; controles_releves "$S0"; }
fi
if [ "$cas" = tous ] || [ "$cas" = A ]; then
    echo "== A : artefact, seul src/ change après la relecture (partie src de f8ab64a, réelle) =="
    base 942c65e
    git show f8ab64a -- src/controle_ia/environnements/lancer_pilote_a.py | git apply && git commit -qam "essai : correction post-relecture, src seul"
    echo "  différentiel 3ffab9f..HEAD sur l'arbre gelé : $(git diff --name-only 3ffab9f HEAD -- $GELES | tr '\n' ' ')"
    generer A && SA=$(simuler_S A) && {
        CODE_RELU=3ffab9ff88761e73074c820b0cb456e51de9c575; controles_releves "$SA"
        echo "  cas sain du nouveau contrôle : CODE_RELU = commit vérifié (le parent de S)"
        CODE_RELU=$(git rev-parse "$SA^"); controles_releves "$SA"; }
fi
if [ "$cas" = tous ] || [ "$cas" = B ]; then
    echo "== B : artefact, f8ab64a entier (src, tests et script de l'instance) =="
    base 942c65e
    git cherry-pick -n f8ab64a >/dev/null && git commit -qm "essai : f8ab64a entier"
    generer B
fi
if [ "$cas" = tous ] || [ "$cas" = T ]; then
    echo "== T : artefact, seuls des tests ajoutés (partie tests de f8ab64a) =="
    base 942c65e
    git show f8ab64a -- tests/test_pilote_a.py tests/test_script_instance_t05.py | git apply && git commit -qam "essai : tests seuls"
    generer T
fi
if [ "$cas" = tous ] || [ "$cas" = M ]; then
    echo "== M : main actuel (a744490), générateur relu, candidat 1 épinglé =="
    base a744490; generer M
fi
if [ "$cas" = G ]; then
    echo "== G : robustesse du traitement : le code changé redéfinit aussi CHEMINS_GELES (périmètre lu dans le code de S) =="
    base 942c65e
    git show f8ab64a -- src/controle_ia/environnements/lancer_pilote_a.py | git apply
    sed -i 's/":(exclude)traces", ":(exclude)CLAUDE.md")/":(exclude)traces", ":(exclude)CLAUDE.md", ":(exclude)src")/' src/controle_ia/harnais/validation_reelle.py
    git diff --stat | tail -1; git commit -qam "essai : src changé et périmètre gelé réduit"
    generer G && SG=$(simuler_S G) && { CODE_RELU=3ffab9ff88761e73074c820b0cb456e51de9c575; controles_releves "$SG"
        echo "  même comparaison avec le périmètre de CODE_RELU (codé en dur, comme la v7) :"
        git diff --quiet "$CODE_RELU" "$SG" -- . ':(exclude)prereg' ':(exclude)brouillons' ':(exclude)registres' ':(exclude)docs' ':(exclude)diag' ':(exclude)runs' ':(exclude)donnees' ':(exclude)livrables' ':(exclude)papiers' ':(exclude)traces' ':(exclude)CLAUDE.md'; echo "    git diff --quiet : code $? (1 = changement vu)"; }
fi
