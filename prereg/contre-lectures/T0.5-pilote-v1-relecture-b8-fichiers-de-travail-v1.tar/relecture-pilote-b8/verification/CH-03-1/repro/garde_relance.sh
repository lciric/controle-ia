#!/usr/bin/env bash
# Harnais de reproduction (relecteur CH-03-1) : lignes 17, 35 et 90-100 du script relu, extraites telles quelles.
# Usage : garde_relance.sh CLONE ; MODE_LANCEMENT=relance
set -uo pipefail
MODE_LANCEMENT=relance; BRANCHE=calcul/t05-pilote-reel-v2
echec=0; ok() { echo "OK  $*"; }; ko() { echo "KO  $*"; echec=1; }
cd "$1" || exit 9
# branche de résultats ; relance : -v1 présente sans episodes.json
case "$MODE_LANCEMENT" in
premier) git ls-remote --exit-code origin "refs/heads/$BRANCHE" >/dev/null 2>&1; c=$?
         [ "$c" = 2 ] && ok "branche $BRANCHE absente" || ko "branche $BRANCHE : code $c (2 attendu)" ;;
relance) git ls-remote --exit-code origin refs/heads/calcul/t05-pilote-reel-v2 >/dev/null 2>&1; c=$?
         [ "$c" = 2 ] && ok "branche de relance absente" || ko "branche de relance : code $c (2 attendu)"
         if git fetch -q origin calcul/t05-pilote-reel-v1 2>/dev/null; then
             git ls-tree -r --name-only FETCH_HEAD | grep -q '/episodes\.json$' && ko "-v1 porte un episodes.json : relancement interdit (préséance)" \
                 || ok "-v1 présente, sans episodes.json"
         else ko "-v1 absente : pas de relancement"; fi ;;
esac
exit "$echec"
