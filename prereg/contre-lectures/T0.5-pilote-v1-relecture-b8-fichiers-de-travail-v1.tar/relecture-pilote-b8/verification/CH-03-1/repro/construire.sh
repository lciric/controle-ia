#!/usr/bin/env bash
# Construit deux dépôts nus « distants » (relecteur CH-03-1) dont la branche calcul/t05-pilote-reel-v1 porte l'arbre
# de 942c65e (noms seulement, blobs vides) plus les fichiers d'un premier run :
#   distant-artefact.git : premier run AVEC diag/<RUN>/episodes.json (relancement interdit par la préséance) ;
#   distant-sain.git     : premier run SANS episodes.json (arrêt avant la fin des épisodes ; relancement permis).
# Aucun fichier du dépôt de travail n'est lu autrement que par `git ls-tree` (lecture seule).
set -euo pipefail
W=$1; DEPOT=/home/user/controle-ia-travail
cd "$W"
git init -q construction; cd construction
git config user.email essai@invalid; git config user.name essai; git config commit.gpgsign false
EB=$(git hash-object -w --stdin </dev/null)
git -C "$DEPOT" ls-tree -r -z --name-only 942c65e > ../noms-942c65e.z
python3 -I - "$EB" ../noms-942c65e.z <<'PY' | git update-index -z --add --index-info
import sys
eb, f = sys.argv[1:3]
for n in open(f, "rb").read().split(b"\0"):
    if n:
        sys.stdout.buffer.write(b"100644 " + eb.encode() + b"\t" + n + b"\0")
PY
S0=$(git commit-tree "$(git write-tree)" -m "S simulé : arbre de 942c65e")
RUN=20261013-013000-t05-pilote-reel; TR=traces/t05-20261013-013000-AbCd
ajouter() { for p in "$@"; do printf '100644 %s\t%s\0' "$EB" "$p"; done | git update-index -z --add --index-info; }
communs="runs/$RUN/manifeste.json runs/$RUN/manifeste.json.sha256 diag/$RUN/arret.json diag/$RUN/arret.json.sha256 $TR/journal.txt $TR/empreintes.sha256 $TR/nvidia-smi.txt $TR/pip-freeze.txt"
git read-tree "$S0"; ajouter $communs
SAIN=$(git commit-tree "$(git write-tree)" -p "$S0" -m "premier run arrêté avant la fin des épisodes (sans episodes.json)")
git read-tree "$S0"; ajouter $communs "diag/$RUN/episodes.json" "diag/$RUN/episodes.json.sha256" "diag/$RUN/appariements.json" "diag/$RUN/appariements.json.sha256"
ART=$(git commit-tree "$(git write-tree)" -p "$S0" -m "premier run avec episodes.json (relancement interdit)")
for x in sain:$SAIN artefact:$ART; do
    nom=${x%%:*}; c=${x#*:}
    git init -q --bare "../distant-$nom.git"
    git push -q "../distant-$nom.git" "$S0:refs/heads/main" "$c:refs/heads/calcul/t05-pilote-reel-v1"
done
echo "S0=$S0 SAIN=$SAIN ARTEFACT=$ART"
for x in sain artefact; do
    echo "$x : $(git ls-tree -r --name-only "$( [ $x = sain ] && echo $SAIN || echo $ART )" | wc -c) octets listés ; episodes.json : $(git ls-tree -r --name-only "$( [ $x = sain ] && echo $SAIN || echo $ART )" | grep -c '/episodes\.json$' || true) ; octets après la ligne d'episodes.json : $(git ls-tree -r --name-only "$( [ $x = sain ] && echo $SAIN || echo $ART )" | sed -n '/\/episodes\.json$/,$p' | tail -n +2 | wc -c)"
done
