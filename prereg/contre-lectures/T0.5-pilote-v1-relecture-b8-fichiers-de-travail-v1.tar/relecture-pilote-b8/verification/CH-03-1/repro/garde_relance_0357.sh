#!/usr/bin/env bash
# lignes 19, 43 et 164-174 de la copie des contrôles relevée à 03:57 UTC (b4ad2a14…), telles quelles
set -uo pipefail
MODE_LANCEMENT=relance; BRANCHE=calcul/t05-pilote-reel-v2
echec=0; ok() { echo "OK  $*"; }; ko() { echo "KO  $*"; echec=1; }
cd "$1" || exit 9
# branche de résultats ; relance : -v1 présente sans episodes.json
case "$MODE_LANCEMENT" in
premier) git ls-remote --exit-code origin "refs/heads/$BRANCHE" >/dev/null 2>&1; c=$?
         [ "$c" = 2 ] && ok "branche $BRANCHE absente" || ko "branche $BRANCHE : code $c (2 attendu)" ;;
relance) git ls-remote --exit-code origin refs/heads/calcul/t05-pilote-reel-v2 >/dev/null 2>&1; c=$?
         [ "$c" = 2 ] && ok "branche de relance absente" || ko "branche de relance : code $c (2 attendu)"
         if git fetch -q origin calcul/t05-pilote-reel-v1 2>/dev/null; then
             git ls-tree -r --name-only FETCH_HEAD | grep -q '/episodes\.json$' && ko "-v1 porte un episodes.json : relancement interdit (préséance)" \
                 || ok "-v1 présente, sans episodes.json"
         else ko "-v1 absente : pas de relancement"; fi ;;
esac
exit "$echec"
