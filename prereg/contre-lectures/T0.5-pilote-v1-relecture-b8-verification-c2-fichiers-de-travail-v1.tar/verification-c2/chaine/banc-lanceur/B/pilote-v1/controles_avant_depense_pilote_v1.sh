#!/usr/bin/env bash
mkdir -p "$2" && echo donnees > "$2/x"
echo "arguments : S=${1:0:12} mode=${3:-premier}"
if [ -n "${FAUX_KO:-}" ]; then echo "OK  essai"; echo "KO  essai : faute simulée"; echo "CONTRÔLES AVANT DÉPENSE : ÉCHEC"; exit 1; fi
echo "OK  essai"; echo "CONTRÔLES AVANT DÉPENSE : TOUS CONFORMES"
