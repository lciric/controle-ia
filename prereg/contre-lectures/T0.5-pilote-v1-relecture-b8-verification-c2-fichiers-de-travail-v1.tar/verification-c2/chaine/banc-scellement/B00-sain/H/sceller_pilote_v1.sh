# copie factice de sceller_pilote_v1.sh (banc réduit du scellement)
