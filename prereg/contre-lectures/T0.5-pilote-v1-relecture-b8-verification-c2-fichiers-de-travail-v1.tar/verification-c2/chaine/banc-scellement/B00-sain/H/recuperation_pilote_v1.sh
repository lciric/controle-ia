# copie factice de recuperation_pilote_v1.sh (banc réduit du scellement)
