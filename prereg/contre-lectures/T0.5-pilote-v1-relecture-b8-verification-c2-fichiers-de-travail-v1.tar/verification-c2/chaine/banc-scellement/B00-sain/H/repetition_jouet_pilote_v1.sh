# copie factice de repetition_jouet_pilote_v1.sh (banc réduit du scellement)
