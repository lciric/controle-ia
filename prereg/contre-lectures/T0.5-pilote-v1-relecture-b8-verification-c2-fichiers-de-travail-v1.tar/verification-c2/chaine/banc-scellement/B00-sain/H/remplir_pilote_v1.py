import os, sys
from pathlib import Path
sc = os.environ.get("SCENARIO", "sain")
depot, commit, mode, date, entropie, sortie_p, sortie_c = sys.argv[1:8]
print("faux générateur :", sc, mode, date, " ".join(sys.argv[8:]))
if sc == "echec-generateur":
    sys.exit("ARRÊT du remplissage du pilote : échec simulé")
t = Path(os.environ["CANDIDAT"]).read_text(encoding="utf-8").replace("2026-10-12 03:19", date.removesuffix(" UTC"))
if sc == "normalise-faux":
    t = t.replace("sous 48 tâches complètes pour ce juge", "sous 47 tâches complètes pour ce juge", 1)
Path(sortie_p).write_text(t, encoding="utf-8")
Path(sortie_c).write_text(Path(os.environ["CONFIG"]).read_text(encoding="utf-8"), encoding="utf-8")
