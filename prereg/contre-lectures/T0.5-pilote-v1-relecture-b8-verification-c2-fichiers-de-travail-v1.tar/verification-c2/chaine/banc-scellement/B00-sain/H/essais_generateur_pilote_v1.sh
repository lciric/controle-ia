# copie factice de essais_generateur_pilote_v1.sh (banc réduit du scellement)
