# copie factice de lancer_pilote_v1.sh (banc réduit du scellement)
