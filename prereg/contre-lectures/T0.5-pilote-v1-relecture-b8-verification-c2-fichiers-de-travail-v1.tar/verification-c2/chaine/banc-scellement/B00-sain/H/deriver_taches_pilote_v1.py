# copie factice de deriver_taches_pilote_v1.py (banc réduit du scellement)
