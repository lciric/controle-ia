# copie factice de repetition_finale_pilote_v1.sh (banc réduit du scellement)
