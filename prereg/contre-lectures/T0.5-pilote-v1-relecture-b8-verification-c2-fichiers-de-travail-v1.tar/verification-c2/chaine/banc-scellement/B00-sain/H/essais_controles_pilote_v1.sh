# copie factice de essais_controles_pilote_v1.sh (banc réduit du scellement)
