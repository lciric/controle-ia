# copie factice de essais_lanceur_pilote_v1.sh (banc réduit du scellement)
