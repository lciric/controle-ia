#!/usr/bin/env bash
# Preuves statiques du relecteur (différentiel brouillon 3 -> 4) : lecture seule du dépôt, rien n'est écrit dedans.
# Usage : bash x_preuves_statiques.sh <depot>
set -u
D=$1
cd "$D" || exit 1
RV=src/controle_ia/environnements/revalider_pilote_a.py
B4=brouillons/T0.5-revalidation-equivalence-pilote-v1-brouillon4.md
SC=scripts/pilote_t05_instance.sh
echo "== HEAD : $(git rev-parse HEAD)"

echo "== X-4 : l'échéance du bras est fixée avant le chargement du modèle et borne désormais la phase « chemin »"
grep -n 'echeance = min\|modele, fmt = _charger_bas\|exiger_echeance_bras(echeance, bras)\|_phase_chemin(reference, fmt, plan, g, config, echeance)' "$RV"
grep -n '"duree_max_bras_s"\|"duree_max_s"' brouillons/T0.5-revalidation-config-v1-brouillon2.json
python3 - <<'EOF'
# estimations du brouillon 4, l. 113 (minutes) : génération 17-25 ; rejeu du lot 0 = moitié ; phase « chemin » 20-40
bas = 17 + 17 / 2 + 20
haut = 25 + 25 / 2 + 40
print(f"bras « defaut », sans chargements ni passes uniques : {bas:.1f} à {haut:.1f} min, contre 5 400 s = 90 min "
      f"(marge au haut de l'estimation : {90 - haut:.1f} min pour téléchargement et chargement des poids en demi et en "
      f"simple précision, passes uniques, repère)")
EOF

echo "== X-5 : garde W-14 levée avant l'écriture des épisodes et des mesures du bras ; aucun test en mode réel"
sed -n '513,518p' "$RV"
echo "levées de GardeArret : brouillon 3 (3ecbd25) $(git show 3ecbd25:$RV | grep -c 'raise GardeArret') ; HEAD $(grep -c 'raise GardeArret' "$RV")"
echo "tests qui passent mode=reel à executer :"; grep -n 'mode="reel"' tests/test_revalider_pilote_a.py
echo "message de la garde W-14 cherché dans les tests : $(grep -c 'absents en mode réel' tests/test_revalider_pilote_a.py) occurrence(s)"

echo "== X-6 : formule de duree_max_s du pilote"
grep -n -o 'Formule gelée de `duree_max_s` du pilote : [^.]*' "$B4"
grep -n -o 'par la formule gelée ci-dessous (W-8)' "$B4"
grep -n -o 'Formule gelée' "$B4" | head -1
grep -n -o 'La limite interne est `duree_max_s` de la configuration, plus courte (au plus 16 000 s)' brouillons/T0.5-pilote-8B-procedure-v1-brouillon2.md
python3 -c "import math; print('arrondi à la minute supérieure de 16 000 s :', math.ceil(16000/60)*60, 's ; au plafond R8 (9 000 s), reste aux juges :', 16000-9000, 's (et non 7 200)')"
sed -n '121p' "$B4" | cut -c1-200

echo "== X-7 : texte"
sed -n '139,141p' "$B4" | cut -c1-160
grep -n "hors du dépôt\|N-014 ouvert" src/controle_ia/environnements/extraire_t05.py | head -3
echo "fichiers suivis sous donnees/ : $(git ls-files -- donnees | wc -l) ; commits qui touchent donnees/ (toutes branches) : $(git log --oneline --all -- donnees | wc -l)"

echo "== X-8 : messages du contrôle de branche sur la sortie d'erreur seulement (pas dans le journal), erreur de git jetée"
sed -n '78,84p' "$SC"
grep -n "consigné au journal" brouillons/T0.5-pilote-8B-procedure-v1-brouillon2.md | cut -c1-140

echo "== X-9 : garde A100 par sous-chaîne"
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src .venv/bin/python -c "
from controle_ia.environnements import revalider_pilote_a as rv
for nom in ('NVIDIA RTX A1000 8GB Laptop GPU', 'NVIDIA A100X'):
    print(repr(nom), '->', rv.exiger_carte_a100(nom), '(passe)')
"
echo "== git status (doit être vide) :"; git status --short
