#!/usr/bin/env bash
# Essai du relecteur : les tests du script héritent de l'environnement du processus qui lance pytest. Sur l'instance,
# pytest est lancé par le script lui-même, dont l'environnement porte BRANCHE lors d'un relancement (procédure du pilote,
# brouillon 2, section 5 : « -e BRANCHE=calcul/t05-pilote-reel-v2 » ; amorce, l. 10-11).
# Usage : bash x_env_herite.sh <depot> <dossier de travail>
set -u
DEPOT=$1; W=$2
cd "$DEPOT" || exit 1
for essai in "témoin (aucune variable)|" "relancement (BRANCHE exportée)|BRANCHE=calcul/t05-pilote-reel-v2" \
             "répétition sans préenregistrement (PREREG_ABSENT exportée)|PREREG_ABSENT=1 TESTS_ATTENDUS=7 CONFIG=c.json ENTRAINEMENT=e.json EVALUATION=v.json"; do
    nom=${essai%%|*}; vars=${essai#*|}
    echo "== $nom : ${vars:-(rien)}"
    rm -rf "$W/pytest-env"
    env $vars PYTHONPATH=src PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m pytest -q -p no:cacheprovider \
        --basetemp="$W/pytest-env" tests/test_script_instance_t05.py 2>&1 \
        | grep -E "^(FAILED|ERROR)|passed|failed" | sed 's/^/   /'
done
rm -rf "$W/pytest-env"
