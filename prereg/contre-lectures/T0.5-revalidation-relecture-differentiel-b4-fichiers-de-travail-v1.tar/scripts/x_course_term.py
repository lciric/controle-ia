"""Essai du relecteur : fenêtre de course de `test_signal_term_dans_un_sous_processus`.

Le test attend que `runs/<run>/manifeste.json` existe, puis envoie TERM. Or le fichier existe dès l'ouverture par
`write_text` (manifeste.py, l. 114), avant son sceau (l. 115) et avant le `try:` d'`executer` qui écrit `arret.json`
(revalider_pilote_a.py, l. 407-424). Un TERM reçu dans cette fenêtre sort par `__main__` (code 1, « signal TERM » sur la
sortie d'erreur) sans `arret.json` : le test échoue alors à la lecture d'`arret.json`.

Ici, même montage que le test (configuration et tâches jouet, dépôt git propre), mais l'attente est active (sans pause)
pour tomber dans la fenêtre ; puis on mesure la durée de la fenêtre (écriture et sceau d'un manifeste de même taille).
Rien n'est écrit dans le dépôt relu : tout va sous le dossier de travail.

Usage : PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=<depot>/src python3 x_course_term.py <depot> <dossier de travail> [n]
"""
from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

from controle_ia.scellement import sceller

DEPOT = Path(sys.argv[1]).resolve()
W = Path(sys.argv[2]).resolve() / "travail-term"
N = int(sys.argv[3]) if len(sys.argv) > 3 else 5

CONFIG = {"N": 1, "T": 4, "episodes_par_tache": 1, "lot": 2, "max_nouveaux": 6, "temperature": 1.0,
          "couches": [0, 1, 2], "fraction_equivalence": 1.0, "statistique_equivalence": "q99",
          "tolerance_equivalence": 0.2, "positions_min_controle_negatif": 4, "actions_min_controle_negatif": 1,
          "fraction_min_controle_negatif": 0.95, "agent": {"nom": "agent-jouet"}, "mode": "jouet", "fils": 1,
          "bras": ["defaut", "math"], "nombre_taches": 4, "transcriptions_repere": 2, "actions_min_comparees": 4,
          "part_min_contexte_couvert": 0.9, "memoire_carte_min_gio": 75, "memoire_pic_max_gio": 70,
          "marge_q99": 0.15, "rho_max": 3, "duree_max_s": 600, "duree_max_bras_s": 300,
          "duree_max_episodes_pilote_s": 1e9, "chemin": {"T": 2, "tolerance": 1e-5},
          "controle_positif": {"T": 2, "decalage_positions": 1, "positions_min": 4, "actions_min": 1,
                               "fraction_min": 0.95}}


def taches(prefixe, n, longueur=lambda k: 1 + k):
    return [{"identifiant": f"{prefixe}.{k:05d}v1", "questions": f"Why do routers matter in setting {k}? " * longueur(k),
             "classification": {"theory_experiment": "mostly_experiments", "data_type": "real_only", "domains": []}}
            for k in range(n)]


def git(d, *a):
    subprocess.run(["git", "-C", str(d), *a], check=True, capture_output=True)


def montage(k: int) -> Path:
    d = W / f"depot-{k}"
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    git(d, "init", "-q", "-b", "main")
    git(d, "config", "user.email", "t@example.invalid")
    git(d, "config", "user.name", "t")
    (d / "config.json").write_text(json.dumps(CONFIG), encoding="utf-8")
    sceller(d / "config.json")
    for nom, t in (("entrainement", taches("2601", 4)), ("evaluation", taches("2602", 64, lambda k: 1))):
        f = d / f"taches-{nom}.json"
        f.write_text(json.dumps({"taches": t}), encoding="utf-8")
        sceller(f)
    git(d, "add", "-A")
    git(d, "commit", "-qm", "init")
    return d


def un_essai(k: int) -> dict:
    d = montage(k)
    run = f"20261007-0000{k:02d}-revalidation-term"
    env = dict(os.environ, PYTHONPATH=str(DEPOT / "src"), PYTHONDONTWRITEBYTECODE="1")
    p = subprocess.Popen([sys.executable, "-m", "controle_ia.environnements.revalider_pilote_a", "--config",
                          "config.json", "--entrainement", str(d / "taches-entrainement.json"), "--evaluation",
                          str(d / "taches-evaluation.json"), "--run-id", run],
                         cwd=d, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    m = d / "runs" / run / "manifeste.json"
    limite = time.monotonic() + 300
    while not m.exists() and p.poll() is None and time.monotonic() < limite:
        pass                                                   # attente active : on vise la fenêtre
    os.kill(p.pid, signal.SIGTERM)
    _, err = p.communicate(timeout=600)
    arret = d / "diag" / run / "arret.json"
    return {"essai": k, "code": p.returncode, "signal TERM sur stderr": "signal TERM" in err,
            "arret.json": arret.exists(), "sceau du manifeste": Path(str(m) + ".sha256").exists()}


def fenetre() -> float:
    """Durée (s) de l'écriture d'un manifeste de même taille et de son sceau : borne basse de la fenêtre."""
    d = W / "fenetre"
    d.mkdir(parents=True, exist_ok=True)
    texte = json.dumps({"config": CONFIG, "graines": {f"e{k}": k for k in range(60)}}, indent=2) + "\n"
    durees = []
    for k in range(200):
        f = d / f"m{k}.json"
        t0 = time.perf_counter()
        f.write_text(texte, encoding="utf-8")
        sceller(f)
        durees.append(time.perf_counter() - t0)
    shutil.rmtree(d)
    durees.sort()
    return durees[len(durees) // 2]


if __name__ == "__main__":
    W.mkdir(parents=True, exist_ok=True)
    resultats = [un_essai(k) for k in range(N)]
    for r in resultats:
        print(r)
    manque = sum(not r["arret.json"] for r in resultats)
    f = fenetre()
    print(f"attente active : {manque} essai(s) sur {N} sans arret.json (le test échouerait)")
    print(f"fenêtre minimale mesurée (écriture du manifeste + sceau, médiane) : {f * 1e3:.3f} ms ; "
          f"avec l'attente de 50 ms du test, probabilité d'y tomber ≈ {f / 0.05:.2%} par exécution (borne basse)")
    shutil.rmtree(W)
