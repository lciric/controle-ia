"""Essais du relecteur (différentiel brouillon 3 -> 4) : lecture précoce du préenregistrement par le script de
l'instance, exécuté tel quel (lecture seule depuis le dépôt) contre un dépôt local, avec un `python` et un `nvidia-smi`
factices, comme `tests/test_script_instance_t05.py`. Rien n'est écrit dans le dépôt : tout va sous le dossier de travail
passé en argument. Aucun import du dépôt (les sceaux sont écrits ici au format de `sceller` : « <hex>  <nom de base> »).

Usage : python3 x_essais_script.py <depot> <dossier de travail>
"""
from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys
from pathlib import Path

DEPOT = Path(sys.argv[1]).resolve()
TRAVAIL = Path(sys.argv[2]).resolve()
SCRIPT = DEPOT / "scripts" / "pilote_t05_instance.sh"
RUN = "20261007-000000-t05-extraction"

PYTHON_FACTICE = r"""#!/usr/bin/env bash
# python factice : consigne les arguments du lanceur (un par ligne, entre chevrons), puis échoue.
if [ "$1" = "-m" ] && [ "$2" = "pytest" ]; then
    printf '%s\n' "${FAUX_PYTEST_LIGNE:-7 passed in 1.00s}"; exit 0
fi
if [ "$1" = "-c" ]; then
    case "$2" in *"is_available() else 1"*) exit 0 ;; esac
    echo "torch factice"; exit 0
fi
for a in "$@"; do printf '<%s>\n' "$a"; done > "$ARGS_LOG"
echo "lanceur factice : arrêt" >&2
exit 1
"""


def sceller(f: Path, nom: str | None = None, contenu_de: Path | None = None, lignes_sup: str = "") -> None:
    src = contenu_de or f
    h = hashlib.sha256(src.read_bytes()).hexdigest()
    Path(str(f) + ".sha256").write_text(f"{h}  {nom or src.name}\n{lignes_sup}", encoding="utf-8")


def git(d: Path, *a: str) -> str:
    return subprocess.run(["git", "-C", str(d), *a], capture_output=True, text=True, check=True).stdout.strip()


def prereg(entr: str | None, evalu: str | None, config: str = "prereg/config.json", attendus: str = "7") -> str:
    t = f"# préenregistrement factice\n- Tests attendus : `{attendus}`\n- Chemin de la configuration : `{config}`\n"
    if entr is not None:
        t += f"- Chemin des tâches d'entraînement : `{entr}` (commentaire : `autre/chemin`)\n"
    if evalu is not None:
        t += f"- Chemin des tâches d'évaluation : `{evalu}`\n"
    return t


def bac(nom: str, dossier_run: str = RUN, nom_prereg: str = "prereg/revalidation.md", prereg_texte=None,
        modif=None) -> dict:
    racine = TRAVAIL / "travail-script" / nom
    if racine.exists():
        shutil.rmtree(racine)
    src = racine / "source"
    (src / "prereg").mkdir(parents=True)
    git(racine, "init", "-q", "-b", "main", str(src))
    git(src, "config", "user.email", "t@example.invalid")
    git(src, "config", "user.name", "t")
    (src / ".gitignore").write_text("donnees/\n.venv/\n", encoding="utf-8")       # comme le vrai dépôt
    for d in ("runs", "diag"):
        (src / d).mkdir()
        (src / d / ".gitkeep").write_text("", encoding="utf-8")
    entr = f"donnees/{dossier_run}/taches-entrainement.json"
    evalu = f"donnees/{dossier_run}/taches-evaluation.json"
    (src / "prereg" / "config.json").write_text("{}", encoding="utf-8")
    sceller(src / "prereg" / "config.json")
    for c in (entr, evalu):
        f = src / c
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text('{"taches": []}' if "entr" in c else '{"taches": [0]}', encoding="utf-8")
        sceller(f)
    (src / nom_prereg).parent.mkdir(parents=True, exist_ok=True)
    (src / nom_prereg).write_text(prereg_texte(entr, evalu) if prereg_texte else prereg(entr, evalu),
                                  encoding="utf-8")
    if modif:
        modif(src, entr, evalu)
    git(src, "add", "-A")
    git(src, "add", "-f", "donnees")                                                 # ajout forcé (N-014 (a))
    git(src, "commit", "-qm", "init")
    distant = racine / "distant.git"
    subprocess.run(["git", "clone", "-q", "--bare", str(src), str(distant)], check=True)
    venv = racine / "venv"
    (venv / "bin").mkdir(parents=True)
    (venv / "bin" / "activate").write_text(f'export PATH="{venv}/bin:$PATH"\n', encoding="utf-8")
    (venv / "bin" / "python").write_text(PYTHON_FACTICE, encoding="utf-8")
    (venv / "bin" / "python").chmod(0o755)
    return {"racine": racine, "source": src, "distant": distant, "venv": venv, "prereg": nom_prereg}


def lancer(b: dict, env_sup: dict | None = None) -> tuple[int, str, str]:
    env = {k: v for k, v in os.environ.items() if not k.startswith(("GIT_", "PYTHON"))}
    log = b["racine"] / "args-lanceur.txt"
    env.update(COMMIT=git(b["source"], "rev-parse", "HEAD"), ETUDE="revalidation", MODE="jouet",
               DEPOT_URL=str(b["distant"]), TRAVAIL=str(b["racine"] / "t"), PREREG=b["prereg"],
               VENV_EXISTANT=str(b["venv"]), HOME=str(b["racine"]), ARGS_LOG=str(log))
    env.update(env_sup or {})
    r = subprocess.run(["bash", str(SCRIPT)], env=env, capture_output=True, text=True, timeout=300)
    j = b["racine"] / "t" / "journal.txt"
    sortie = (j.read_text(encoding="utf-8") if j.exists() else "") + r.stderr
    args = log.read_text(encoding="utf-8") if log.exists() else "(lanceur non appelé)"
    return r.returncode, sortie, args


def ligne(s: str, motif: str) -> str:
    for l in s.splitlines():
        if motif in l:
            return l.split(" ", 1)[-1][:200]
    return f"(aucune ligne « {motif} »)"


def cas(nom: str, attendu: str, **k) -> None:
    env_sup = k.pop("env_sup", None)
    b = bac(nom, **k)
    code, sortie, args = lancer(b, env_sup)
    lu = "préenregistrement lu" in sortie
    installe = "torch factice" in sortie
    print(f"== {nom}\n   attendu : {attendu}\n   code {code} ; lecture précoce passée : {lu} ; installation atteinte : "
          f"{installe}")
    print(f"   journal : {ligne(sortie, 'arrêt avant') if not lu else ligne(sortie, 'préenregistrement lu')}")
    if "ARRÊT pendant run" in sortie or "(lanceur non appelé)" not in args:
        print("   arguments du lanceur : " + " ".join(args.split()))


def main() -> None:
    print(f"script : {SCRIPT} sha256 {hashlib.sha256(SCRIPT.read_bytes()).hexdigest()}")
    cas("B1-sain", "lecture passée, installation, lanceur appelé (arrêt factice ensuite)")
    cas("B2-espaces-dans-le-dossier-du-run", "cas sain : lecture passée, chemins intacts au lanceur",
        dossier_run="run avec espaces")
    cas("B3-espace-dans-le-nom-du-preenregistrement", "cas sain", nom_prereg="prereg/revalidation v1.md")
    cas("B4-chemin-a-remplir", "arrêt code 2 avant l'installation",
        prereg_texte=lambda e, v: prereg(e, "À REMPLIR"))
    cas("B5-ligne-du-chemin-absente", "arrêt code 2 (« chemin … introuvable »), garde sans test dans la suite",
        prereg_texte=lambda e, v: prereg(e, None))
    cas("B6-sceau-qui-nomme-un-autre-fichier", "artefact : le lanceur Python l'arrêtera (nom), le script le laisse-t-il ?",
        modif=lambda s, e, v: sceller(s / v, nom="taches-entrainement.json", contenu_de=s / e))
    cas("B7-sceau-a-deux-lignes", "artefact : le lanceur Python l'arrêtera (une seule ligne exigée), le script ?",
        modif=lambda s, e, v: sceller(s / v, lignes_sup=(s / (e + ".sha256")).read_text(encoding="utf-8")))
    cas("B8-configuration-sans-sceau", "artefact : le lanceur Python l'arrêtera (`verifier(a.config)`), le script ?",
        modif=lambda s, e, v: os.remove(s / "prereg" / "config.json.sha256"))

if __name__ == "__main__":
    main()
