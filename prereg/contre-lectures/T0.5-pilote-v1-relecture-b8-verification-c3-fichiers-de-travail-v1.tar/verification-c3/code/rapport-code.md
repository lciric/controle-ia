# Vérification c3 du pilote 8B de T0.5 — angle « code »

- Vérificateur : sous-agent neuf. Je n'ai écrit ni le préenregistrement, ni le code, ni la chaîne, ni les rapports de la vérification c2.
- Date : 2026-10-12, de 04:52 à 05:06 UTC environ.
- Dépôt : `/home/user/controle-ia-travail`, branche `main`, tête `7b073008585279a06251b08d6b456694320a3c58` (égale à `origin/main` local).
- Objet : le commit `c8a3325300da278e917db10a1fccba9985af532f` (`git diff a744490 7b07300 -- scripts src tests` : `scripts/pilote_t05_instance.sh`, 6 lignes ajoutées ; `tests/test_script_instance_t05.py`, 20 lignes ajoutées), et les lignes VC-01 à VC-08 de la table « Traitement de la vérification courte du candidat 2 » du candidat 3.
- Lecture seule :
  - `git rev-parse HEAD` et `git status --short --ignored` sont identiques avant et après (`etat-avant.txt` = `etat-apres.txt`, sha256 `042949d9…`).
  - Aucun fichier de l'arbre de travail (hors `.git` et `diag/`) n'est plus récent que mon repère de début (04:53:36 UTC).
  - Seul le répertoire `.git` lui-même a une date plus récente (05:01:29) : verrou de l'index pris puis rendu par mon `git status` final. Aucun fichier de `.git` n'a changé ; l'index est daté 04:46:28, avant mon repère.
  - Aucun clone, aucune commande vastai, aucune variable d'environnement affichée.
  - Règle D-20 : aucun fichier de `diag/` ouvert ; `diag/` exclu de mes recherches.
- Python : `/home/user/controle-ia/.venv/bin/python`, `PYTHONPATH=src`, `PYTHONDONTWRITEBYTECODE=1`, `pytest -q -p no:cacheprovider`. Le `--basetemp` est sous mon dossier ; il a été supprimé ensuite.
- Empreintes vérifiées (`sha256sum`) :
  - candidat 3 : `74a88671…` ;
  - configuration candidate : `6979a00e…` ;
  - brouillon 10 : `c3ee76a9…` ;
  - plan v3 : `7d9237b6…` ;
  - chaîne c3 : les 13 empreintes sont conformes (`sha256sum -c chaine-c3.sha256`).
- Script de l'instance :
  - `a744490` → `012a2116…` ;
  - `c8a3325` = `7b07300` = arbre de travail → `077424d0…`, empreinte que cite le candidat 3 (l. 6) ;
  - amorce inchangée, `59f49aab…`, citée l. 6.
- Non vérifié, hors de mon angle : l'empreinte normalisée `83056d15…`. Le classificateur du mode automatique m'a refusé l'exécution du normaliseur, et je ne l'ai pas contourné.

## Verdict

**Aucun constat bloquant, aucun majeur.**

- **Correction de VC-01 juste et complète pour la fonction.** Les cinq sorties de la plomberie sont exigées en 40 caractères hexadécimaux avant toute poussée : deux `hash-object`, deux `mktree` et `commit-tree`.
  - Une sonde injecte la panne point par point. Avec le nouveau script, dans les cinq cas : aucune tentative de poussée, aucune branche, et le journal dit « vecteurs : commit impossible (plomberie git en échec) : non poussés, restés sur l'instance ».
  - L'ancien script écrivait dans les cinq cas « vecteurs poussés : … commit , 4096 octets », sans branche.
- **Sans effet de bord.**
  - Les codes de sortie ne changent pas : 1 sur un arrêt, 0 sur un run complet.
  - Le commit des résultats et la poussée finale ne changent pas.
  - Sur un run complet, la nouvelle ligne est bien dans le journal versé.
- **R5.** Le test ajouté échoue sur l'ancien script et passe sur le nouveau :
  - ancien : `1 failed in 0.91s`, à la ligne 422, avec le faux succès reproduit ;
  - nouveau : `1 passed in 0.81s`.

  Le cas sain de la garde est couvert par `test_vecteurs_refus_passager…` (et par ma sonde).
- **Suite du fichier en place** : **`33 passed in 282.78s (0:04:42)`**, code 0.
- **Lignes VC-01 à VC-08 du candidat 3 : vraies.** Seules des nuances relèvent de l'information (UC-05).
- **Arbre gelé de `7b07300` égal à celui de `c8a3325`** (`git diff --quiet`, code 0). Il est aussi égal à ceux de `e4be3e1`, `71f5174` et `4f3f478`. Depuis `a744490`, seul `c8a3325` le touche. Rien d'autre n'a changé.
- **Constats** : un mineur et six informations.
  - UC-01 (mineur) : la ligne indicative de la récupération ne reconnaît pas le nouveau message. Le KO 5a rattrape le cas.
  - UC-02 à UC-07 : informations.

## Réponses aux questions

### 1. VC-01 : la correction est-elle juste, complète, sans effet de bord ?

Code ajouté, `scripts/pilote_t05_instance.sh:205-210` :

```bash
    if ! [[ "$b" =~ ^[0-9a-f]{40}$ && "$s" =~ ^[0-9a-f]{40}$ && "$t1" =~ ^[0-9a-f]{40}$ && "$t2" =~ ^[0-9a-f]{40}$ \
            && "$c" =~ ^[0-9a-f]{40}$ ]]; then
        journal "vecteurs : commit impossible (plomberie git en échec) : non poussés, restés sur l'instance"; return 1
    fi
```

**Juste.**
- `pousser_vecteurs` n'est appelée que sous `|| true` : l. 235, dans `consigner_arret`, et l. 350, après un run complet.
  - `set -e` est donc ignoré dans tout son corps ; le commentaire des l. 205-206 est exact.
  - Avant la correction, un `c` vide faisait de `git push origin "$c:refs/heads/donnees/t05/$run"` une suppression d'une référence absente. Le dépôt nu local l'accepte avec le code 0, d'où « vecteurs poussés … commit , … ».
  - Après la correction, la fonction rend 1 avant la boucle de poussée.
- La garde est plus stricte que la suggestion de c2, qui demandait seulement des valeurs non vides : elle exige le format exact.
  - Format attendu : 40 caractères hexadécimaux minuscules, ce que git imprime pour des objets SHA-1.
  - Dépôt : `git rev-parse --show-object-format` → `sha1`.
  - Instance : image `python:3.11-bookworm` (`lancer_pilote_v1.sh`, l. 185), clone depuis GitHub (SHA-1). Voir UC-03.
- Sous `set -u`, les cinq variables sont locales (l. 190) et affectées, vides au besoin, avant le test : aucune erreur « unbound variable ».
- `bash -n` : syntaxe correcte. `shellcheck` n'est pas installé.

**Complète pour la fonction.** Sonde `test_sonde_uc_plomberie.py` : un git factice échoue sur une sous-commande, à un rang donné, depuis des copies hors du dépôt. Sortie (`sonde-plomberie-sortie.txt`) :

| panne | ancien script (`012a2116…`) | nouveau script (`077424d0…`) |
|---|---|---|
| `hash-object`, les deux appels | « vecteurs poussés : … commit , 4096 octets », aucune branche | « vecteurs : commit impossible … », aucune poussée, aucune branche |
| `hash-object`, 2e appel (sceau) | idem, faux succès | idem, « commit impossible » |
| `mktree`, 1er appel | idem, faux succès | idem |
| `mktree`, 2e appel | idem, faux succès | idem |
| `commit-tree` | idem, faux succès | idem |

Dans les cinq cas, avec le nouveau script :
- le code de sortie est 1 (« ARRÊT pendant run ») ;
- aucune ligne « tentative » n'apparaît (aucune poussée tentée) ;
- aucune branche `donnees/t05/*` n'existe.

**Sans effet de bord.** Sonde `test_sonde_uc_run_complet.py` : chemin du run **complet** (l. 350), avec un lanceur factice qui écrit des vecteurs, un manifeste et un résumé. Sortie (`sonde-run-complet-sortie.txt`) :

| cas | code | ligne des vecteurs | branche des vecteurs | journal versé (traces « fin ») | dernière ligne |
|---|---|---|---|---|---|
| nouveau, sain | 0 | « vecteurs poussés : … commit f205e1b3…, 4096 octets » | présente | contient la ligne | « branche … poussée (résultats et traces) » |
| nouveau, `hash-object` en panne | 0 | « vecteurs : commit impossible … restés sur l'instance » | absente | contient la ligne | idem |
| ancien, `hash-object` en panne | 0 | « vecteurs poussés : … commit , 4096 octets » (faux succès) | absente | contient le faux succès | idem |

- Sur le chemin d'arrêt, le code reste 1 (test du dépôt, et sonde ci-dessus).
- Les codes de sortie, le commit des résultats (l. 345-346) et la poussée finale (l. 357-362) ne changent pas.
- Comme avant, un run complet dont les vecteurs restent sur l'instance sort en code 0. Le plan v3, étape 7, lit la branche des vecteurs (5a, 5b) et interdit toute destruction avant (PL-11).

Restes : UC-01, UC-02 et UC-03 (liés à la correction) ; UC-06 et UC-07 (antérieurs, de la même famille).

### 2. R5 : le test ajouté, rejoué sur l'ancien et le nouveau script

J'ai monté deux arbres minimaux, `r5/ancien` et `r5/nouveau`. Le test résout le script depuis son propre arbre (`RACINE = parents[1]`).
- Contenu commun, tiré de `7b07300` :
  - `pyproject.toml` ;
  - `tests/conftest.py` ;
  - `tests/test_script_instance_t05.py` (`aea1925a…`) ;
  - `src/controle_ia/{__init__,gardes,scellement}.py`, identiques à `a744490`.
- Script :
  - ancien = `git show a744490:scripts/pilote_t05_instance.sh` (`012a2116…`) ;
  - nouveau = `git show 7b07300:…` (`077424d0…`).

Commande, dans chaque arbre :

```
PYTHONPATH=src PYTHONDONTWRITEBYTECODE=1 /home/user/controle-ia/.venv/bin/python -m pytest -q -p no:cacheprovider \
  --basetemp=<mon dossier>/r5/tmp-<variante> \
  "tests/test_script_instance_t05.py::test_vecteurs_plomberie_en_echec_aucun_faux_succes"
```

**Ancien script : échec**, à la deuxième assertion (`r5-sortie-ancien.txt`). Le faux succès de VC-01 est reproduit tel quel :

```
>       assert "vecteurs : commit impossible (plomberie git en échec) : non poussés, restés sur l'instance" in j, j[-2500:]
E       AssertionError: …
E         2026-10-12T04:54:58Z ARRÊT pendant run (code 1) : résultats partiels committés (dont arret.json s'il existe)
E         2026-10-12T04:54:59Z branche calcul/t05-pilote-jouet-v1 poussée
E         2026-10-12T04:54:59Z vecteurs poussés : branche donnees/t05/20261012-045458-t05-pilote-jouet, commit , 4096 octets
tests/test_script_instance_t05.py:422: AssertionError
FAILED tests/test_script_instance_t05.py::test_vecteurs_plomberie_en_echec_aucun_faux_succes
1 failed in 0.91s
code pytest 1
```

**Nouveau script : succès** (`r5-sortie-nouveau.txt`) :

```
1 passed in 0.81s
code pytest 0
```

Cas sain de la même garde (R5) :
- `test_vecteurs_refus_passager_puis_poussee_et_cause_journalisee` passe en place sur le nouveau script : les valeurs saines franchissent la garde, la branche est poussée.
- Ma sonde du run complet sain donne « vecteurs poussés … commit f205e1b3… ».

### 3. `tests/test_script_instance_t05.py` en entier, en place

Commande, lancée depuis le dépôt de 04:56:28 à 05:01:12 UTC :

```
PYTHONPATH=src PYTHONDONTWRITEBYTECODE=1 /home/user/controle-ia/.venv/bin/python -m pytest -q -p no:cacheprovider \
  --basetemp=<mon dossier>/pytest-en-place-tmp --durations=15 tests/test_script_instance_t05.py
```

**Dernière ligne : `33 passed in 282.78s (0:04:42)`** (code 0, `pytest-en-place-sortie.txt`).

Durées :
- tests à attentes réelles : `test_poussees_apres_le_run_trois_tentatives` 90,82 s ; `test_poussee_finale_cas_sain_et_refus` 75,95 s ; `test_vecteurs_refus_permanent…` 75,61 s ; `test_vecteurs_refus_passager…` 15,56 s. Total : 257,94 s.
- `test_poussee_initiale…` : 10,71 s.
- Le nouveau test : 0,57 s.

En complément, collecte seule en place (aucun test exécuté) : **`689 tests collected`**, dont 33 dans ce fichier (`collecte-sortie.txt`). Ce compte est :
- égal à « Tests attendus : `689` » (candidat 3, l. 16) ;
- égal à « au commit cité, 689 tests » (l. 173) ;
- égal à la ligne « tests collectés : 689 » du journal de la répétition jouet à `7b07300` ;
- et vaut 688 + 1 (compte de c2 à `a744490`).

### 4. Les lignes VC-01 à VC-08 de la table du candidat 3 disent-elles vrai ?

| ligne | texte (résumé) | vérification | verdict |
|---|---|---|---|
| VC-01 (l. 454) | plomberie en échec : aucun commit, aucune poussée, journal « restés sur l'instance » ; test artefact (`hash-object`) qui échoue sur l'ancien script et passe sur le nouveau | questions 1 et 2 ; dans les cinq points de panne, la garde renvoie avant la boucle de poussée | **vrai** |
| VC-02 (l. 455) | « Voir VT-09 » : attentes réelles des tests comptées dans « Calcul », départ du run vers 900 à 950 s (l. 448) | « Calcul » (l. 173) écrit : « environ 4 minutes (tests des poussées en trois tentatives, `197e909` et `3a6d1b1`) : départ du run attendu vers 900 à 950 s après la création, sous les 1 500 s et dans les 2 700 s (vérification courte, VT-09, VC-02) ». Mesure : 257,94 s pour les quatre tests à attentes, soit environ 4,3 min. `c8a3325` n'ajoute aucune attente (0,57 s). | **vrai** |
| VC-03, VC-04, VC-06 à VC-08 (l. 456) | informations ; non adopté dans le code (sans effet sur la lecture) | `git diff a744490 7b07300 -- src` est vide : `lancer_pilote_a.py` n'a pas changé (VC-03, VC-04, VC-07, VC-08). Dans le script, seules les 6 lignes de VC-01 changent ; la ligne de synthèse de VC-06 est intacte (désormais l. 360). La raison tient : lecture sur fichiers (VC-03) ; aucune promesse du texte (VC-04) ; plan v3, étape 6, qui lit le journal (VC-06) ; sûr en mode réel (VC-07) ; docstring (VC-08). | **vrai** ; nuances UC-05 |
| VC-05 (l. 457) | récupération : `nvidia-smi.txt` et `pip-freeze.txt` cherchés dans tous les dossiers de traces nouveaux ; aucun dossier nouveau : KO « aucune trace versée » | `chaine-c3/recuperation_pilote_v1.sh` (`0c712381…`) : l. 168, KO « 6 aucune trace versée sur la branche (poussée finale en échec ?) : instance gardée, traces à reprendre » ; l. 176-178, `NS` et `PF` cherchés sur `$NOUVELLES` ; l. 180 et 185, ces chemins sont utilisés. Le différentiel avec `pilote-v1-post-r2` montre ces changements, plus ceux de VH-08 et VH-12. | **vrai** |

Gravités relues dans le fichier versé `prereg/contre-lectures/T0.5-pilote-v1-relecture-b8-verification-c2-resultats-v1.json` (`1f78fa75…`) :
- VC-01 et VC-02 : mineurs ;
- VC-03 à VC-08 : information.

La table du candidat est conforme.

### 5. Arbre gelé de `7b07300` = arbre gelé de `c8a3325` ? Rien d'autre n'a changé ? Pistes fragiles

`CHEMINS_GELES` (`validation_reelle.py:71-73`) couvre tout, sauf `prereg`, `brouillons`, `registres`, `docs`, `diag`, `runs`, `donnees`, `livrables`, `papiers`, `traces` et `CLAUDE.md`. À la racine, cela laisse : `.claude`, `.gitattributes`, `.gitignore`, `README.md`, `pyproject.toml`, `requirements-*.txt`, `scripts`, `src` et `tests`.

```
git diff --quiet c8a3325 7b07300 -- <CHEMINS_GELES>   → code 0 (égal)
git diff --quiet 4f3f478|71f5174|e4be3e1 7b07300 -- … → code 0 (égal)
git diff --quiet a744490 c8a3325 -- …                 → code 1 (attendu)
git diff --stat a744490 7b07300 -- …                  → scripts/pilote_t05_instance.sh | 6 ++++++ ; tests/test_script_instance_t05.py | 20 ++++
git log --oneline a744490..7b07300 -- …               → c8a3325 seul
git log --oneline c8a3325..7b07300 -- …               → (rien)
git diff --quiet HEAD -- … (arbre de travail)          → code 0 ; aucun fichier non suivi dans l'arbre gelé
```

**L'arbre gelé de `7b07300` est égal à celui de `c8a3325`.**
- `CODE_RELU = 7b07300…` est cohérent avec le contrôle du scellement (`sceller_pilote_v1.sh:63`, `git diff --quiet "$CODE_RELU" HEAD -- $GELES`) et avec celui des contrôles avant dépense (l. 71).
- Le candidat cite `e4be3e1` comme commit du code d'analyse, ce qui est attendu en mode candidat. Son arbre gelé est égal.

**Rien d'autre n'a changé.** Hors de l'arbre gelé, `git diff --stat a744490 7b07300` ne montre que des brouillons, des documents, `prereg/contre-lectures/` et des registres.

Pistes fragiles :
- UC-01 à UC-07 ci-dessous.
- **Tout l'arbre gelé doit rester intact jusqu'au scellement**, y compris `README.md`, `.claude/`, `.gitignore` et les `requirements`. Sinon l'égalité au code relu casse, et la répétition jouet est à refaire.
  - Corriger UC-02 ou UC-03 toucherait l'arbre gelé : à ne pas faire maintenant.
  - La correction d'UC-01 est hors de l'arbre gelé, dans la chaîne. Mais la récupération est jouée par la répétition jouet en cours et doit égaler sa copie versée à S : l'adopter, c'est rejouer la répétition.
- Restes déjà déclarés, inchangés : écriture non atomique d'un résultat (CO-15, K-1), réseau au début du run, durée des juges jamais mesurée.
- **Doute** : le comportement de GitHub devant la suppression d'une référence absente n'est toujours pas éprouvé. La question est devenue sans objet : le nouveau script ne pousse plus rien sans commit.

## Constats

| Id | Gravité | Objet |
|---|---|---|
| UC-01 | mineur | Récupération (chaîne c3), l. 174 : la ligne indicative « KO? journal » ne reconnaît pas le nouveau message « vecteurs : commit impossible … » |
| UC-02 | information | Plomberie en échec : la cause donnée par git n'est pas journalisée (elle l'est pour les poussées, CO-03) |
| UC-03 | information | Garde à 40 caractères : elle suppose des objets SHA-1 |
| UC-04 | information | Le test du dépôt n'éprouve que `hash-object` ; les quatre autres points de panne ne le sont que par ma sonde |
| UC-05 | information | Table : VC-06 (condition « si le script est rouvert » remplie, non adoptée, raison valable) ; VC-07 (« non adopté » pour une remarque sans action proposée) |
| UC-06 | information | Chemin d'arrêt : la ligne des vecteurs n'est jamais dans le journal versé (écrite après les traces ; antérieur) |
| UC-07 | information | `traces()` : un commit des traces en échec est muet, et la dernière ligne dit « (résultats et traces) » (antérieur, même famille que VC-01) |

### UC-01 — mineur — la récupération ne reconnaît pas le nouveau message

- Fichier : `chaine-c3/recuperation_pilote_v1.sh:174` (`0c712381…`). Le message vient de `scripts/pilote_t05_instance.sh:209`.
- Preuve :

  ```
  $ P='vecteurs (absents|trop gros|: empreinte non conforme|: poussée impossible)'
  « vecteurs : commit impossible (plomberie git en échec) : non poussés, … »  → grep -E "$P" : code 1 (non reconnu)
  « vecteurs : poussée impossible : restés sur l'instance »                  → code 0
  « vecteurs trop gros (96000000 octets) : non poussés, restés … »           → code 0
  ```

  Aucun autre consommateur des lignes de vecteurs dans la chaîne ni dans `scripts/` (grep).
- Portée :
  - Seul l'indice de diagnostic manque. La ligne « KO? » n'est pas comptée dans les échecs.
  - Le contrôle qui fait foi, 5a (« branche donnees/t05/$RUN absente : vecteurs restés sur l'instance ? instance gardée (PL-11) »), se déclenche, et le plan v3 (étape 7) interdit toute destruction avant la vérification des vecteurs.
  - Sur un arrêt, la ligne des vecteurs n'est de toute façon pas dans le journal versé (UC-06). L'écart ne touche donc que le run complet.
- Action proposée : ajouter `|: commit impossible` à l'alternative de la l. 174, ou chercher « restés sur l'instance ».
  - Le faire seulement si la répétition jouet doit être rejouée de toute façon : la récupération est jouée par elle, et doit égaler sa copie versée à S.
  - Sinon, déclarer que la ligne indicative est incomplète et que le KO 5a fait foi.

### UC-02 — information — cause de la panne de plomberie absente du journal

- Fichier : `scripts/pilote_t05_instance.sh:200-210`.
- Preuve : sortie d'erreur non redirigée. Dans la sonde, le journal ne porte que la ligne générique. Le « fatal: … » de git part sur la sortie d'erreur du script, donc dans le journal du conteneur : probablement `vastai logs` (doute : la capture de la sortie d'erreur par vastai n'est pas éprouvée ici). Il n'est ni dans `journal.txt` ni dans les traces.
- Portée : diagnostic seulement. L'instance est gardée (5a), et la cause probable, disque plein ou objet illisible, s'y lit.
- Action : aucune maintenant, car toucher l'arbre gelé remet en cause le code relu et la répétition. Si le code est rouvert : `2>>"$TRAVAIL/plomberie-vecteurs.err"`, puis citer sa dernière ligne dans le journal, comme pour les poussées (CO-03).

### UC-03 — information — la garde suppose des objets SHA-1 (40 caractères)

- Fichier : `scripts/pilote_t05_instance.sh:207-208`.
- Preuve :
  - `git rev-parse --show-object-format` → `sha1` ;
  - `init.defaultObjectFormat` n'est réglé ni au niveau global ni au niveau système ;
  - image de l'instance `python:3.11-bookworm` (`lancer_pilote_v1.sh:185`) ;
  - un clone prend le format du dépôt distant, et GitHub sert du SHA-1.
- Portée :
  - Sur un dépôt SHA-256 (64 caractères), la garde refuserait à tort : « commit impossible », vecteurs non poussés, KO 5a, instance gardée. Aucune perte silencieuse.
  - Sans objet pour ce pilote.
  - Les tests (`git init` du bac) deviendraient faux si un git futur passait SHA-256 par défaut. La suite s'arrêterait alors avant le run (« tests en échec »).
- Action : aucune. Si le code est rouvert : `^[0-9a-f]{40}([0-9a-f]{24})?$`, ou tester le code de retour de chaque commande.

### UC-04 — information — couverture du test : `hash-object` seul

- Fichier : `tests/test_script_instance_t05.py:407-424`.
- Preuve : le git factice ne fait échouer que `hash-object`. Ma sonde (`test_sonde_uc_plomberie.py`, `1528f6cd…`) couvre les cinq points, avec le résultat attendu pour chacun (question 1).
- Action : aucune. Si le test est rouvert, le paramétrer par `mktree` et `commit-tree`.

### UC-05 — information — nuances de la table (VC-06, VC-07)

- Fichier : candidat 3, l. 456.
- **VC-06** : c2 proposait le changement « si le script est rouvert ». `c8a3325` a rouvert le script sans l'adopter.
  - La raison « sans effet sur la lecture » est exacte : le plan v3, étape 6, lit un code 1 sur le journal, et l'absence de « poussée du run impossible » lève l'ambiguïté.
  - Changer cette ligne aurait d'ailleurs demandé de reprendre l'assertion exacte de `test_poussee_finale_cas_sain_et_refus` et le texte du plan.
- **VC-07** : c2 ne proposait aucune action (« Action : aucune »). « Non adopté » y est un abus de mots, sans conséquence.
- Action : aucune. Facultatif : « VC-07 : aucune action proposée ».

### UC-06 — information — sur un arrêt, la ligne des vecteurs n'est pas dans le journal versé (antérieur)

- Fichier : `scripts/pilote_t05_instance.sh:225-236`. L'ordre de `consigner_arret` est : commit, `traces`, `pousser`, puis `pousser_vecteurs`.
- Preuve (`test_sonde_uc_journal_verse.py`, nouveau script) :
  - arrêt avec `hash-object` en panne : le journal local porte « vecteurs : commit impossible … », le journal versé (`traces/t05-…/journal.txt`) aucune ligne de vecteurs ;
  - arrêt sain : le journal local porte « vecteurs poussés : … commit 9b8ca553… », le journal versé aucune ligne de vecteurs ; la branche des vecteurs est présente.
- Portée : comportement antérieur à `c8a3325` et inchangé.
  - La session connaît l'issue des vecteurs par la branche (5a, 5b).
  - Elle la voit aussi par `vastai logs`, puisque l'amorce affiche les 20 dernières lignes du journal.
- Action : aucune.

### UC-07 — information — `traces()` : un commit en échec est muet (antérieur)

- Fichier : `scripts/pilote_t05_instance.sh:184`, puis 357-358.
- Preuve (même sonde ; git factice dont seul le commit « traces de l'instance » échoue, run complet) :
  - code 0 ;
  - dernière ligne « branche calcul/t05-pilote-jouet-v1 poussée (résultats et traces) » ;
  - aucun dossier `traces/` sur la branche ;
  - aucune ligne du journal ne signale l'échec.
- Portée :
  - C'est la même famille que VC-01 : un faux « (résultats et traces) » au journal.
  - La récupération le rattrape par le KO de la ligne 168 (« 6 aucune trace versée sur la branche … instance gardée »).
  - Le cas est très improbable : `git add` et `git commit` locaux d'un petit dossier, juste après le commit des résultats.
- Action : aucune maintenant, car l'arbre gelé est en jeu. Si le script est rouvert : journaliser l'échec du commit des traces, et dire « traces non versées » dans la dernière ligne.

## Fichiers de travail

Tous sous `/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/verification-c3/code/` :

| fichier | contenu | sha256 |
|---|---|---|
| `r5/ancien/`, `r5/nouveau/` | arbres minimaux du rejeu R5 (script `012a2116…`, ou script `077424d0…`) | — |
| `r5-sortie-ancien.txt` | sortie du test ajouté, ancien script (1 failed) | `e1e3042a…` |
| `r5-sortie-nouveau.txt` | sortie du test ajouté, nouveau script (1 passed) | `fb3ff298…` |
| `pytest-en-place-sortie.txt` | fichier entier, en place (33 passed) | `33dd3d7d…` |
| `collecte-sortie.txt` | collecte seule en place (689) | `52a9af6f…` |
| `test_sonde_uc_plomberie.py` | sonde : cinq points de panne, ancien et nouveau script | `1528f6cd…` |
| `sonde-plomberie-sortie.txt` | sa sortie | `d580a767…` |
| `test_sonde_uc_run_complet.py` | sonde : run complet avec vecteurs, cas sain et panne | `b4a6da27…` |
| `sonde-run-complet-sortie.txt` | sa sortie | `8e18ea98…` |
| `test_sonde_uc_journal_verse.py` | sonde : journal versé sur un arrêt (UC-06), commit des traces en échec (UC-07) | `c8ae6026…` |
| `sonde-journal-verse-sortie.txt` | sa sortie | `a6be6d00…` |
| `etat-avant.txt`, `etat-apres.txt` | état du dépôt | `042949d9…`, identiques |

Dossiers temporaires supprimés : bases de pytest (en place, collecte, sondes, rejeu R5).
