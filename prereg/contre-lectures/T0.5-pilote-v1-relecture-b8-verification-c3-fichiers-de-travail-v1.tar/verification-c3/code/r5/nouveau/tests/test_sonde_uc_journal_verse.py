"""Sonde de la vérification c3, angle « code » (UC-06, UC-07) sur le nouveau script, depuis une copie hors du dépôt.
UC-06 : chemin d'arrêt avec vecteurs (plomberie en panne, puis cas sain) : la ligne des vecteurs est-elle dans le
journal versé sur la branche ? UC-07 : commit des traces en échec (run complet) : que disent le journal et la branche ?"""
import os
import shutil

from test_script_instance_t05 import PILOTE, _distant, _git, _journal, _lancer, _lanceur_factice, bac  # noqa: F401
from test_sonde_uc_run_complet import LANCEUR_COMPLET_AVEC_VECTEURS

BR = "calcul/t05-pilote-jouet-v1"


def _faux_git(bac, condition: str) -> str:
    faux = bac["racine"] / "faux-git"
    faux.mkdir()
    (faux / "git").write_text("#!/usr/bin/env bash\n"
                              f'if {condition}; then echo "fatal: panne simulée" >&2; exit 128; fi\n'
                              f'exec "{shutil.which("git")}" "$@"\n', encoding="utf-8")
    (faux / "git").chmod(0o755)
    return str(faux)


def _journaux_verses(distant) -> list[str]:
    return [f for f in _git(distant, "ls-tree", "-r", "--name-only", BR).split("\n")
            if f.startswith("traces/") and f.endswith("/journal.txt")]


def _ecrire(texte):
    with open(os.environ["SONDE_SORTIE"], "a", encoding="utf-8") as f:
        f.write(texte + "\n")


def test_arret_ligne_des_vecteurs_hors_du_journal_verse(bac):
    for cas, chemin in (("panne hash-object", True), ("cas sain", False)):
        sous = bac["racine"] / cas.replace(" ", "-")
        b = dict(bac)
        _lanceur_factice(b, pilote=True) if cas == "panne hash-object" else None
        distant = _distant(b)
        ch = _faux_git(b, '[ "$1" = "hash-object" ]') if chemin else None
        travail = "t-" + cas.replace(" ", "-")
        code, _ = _lancer(b, distant, travail=travail, env_sup=PILOTE, chemin=ch)
        j = _journal(b, travail)
        vect = [l[21:] for l in j.splitlines() if l[21:].startswith("vecteurs")]
        jv = _journaux_verses(distant)
        verse = _git(distant, "show", f"{BR}:{jv[-1]}") if jv else ""
        vect_verse = [l[21:] for l in verse.splitlines() if l[21:].startswith("vecteurs")]
        _ecrire(f"[UC-06] arrêt, {cas} : code {code} ; journal local {vect} ; journal versé ({jv[-1] if jv else '-'}) : "
                f"lignes des vecteurs {vect_verse} ; branches de vecteurs « {_git(distant, 'branch', '--list', 'donnees/t05/*')} »")
        assert code == 1 and len(vect) == 1 and vect_verse == []
        if ch:
            shutil.rmtree(bac["racine"] / "faux-git")


def test_commit_des_traces_en_echec_run_complet(bac):
    _lanceur_factice(bac, pilote=True)
    (bac["venv"] / "bin" / "python").write_text(LANCEUR_COMPLET_AVEC_VECTEURS, encoding="utf-8")
    distant = _distant(bac)
    ch = _faux_git(bac, '[ "$1" = "commit" ] && [[ "$*" == *"traces de l\'instance"* ]]')
    code, _ = _lancer(bac, distant, env_sup=PILOTE, chemin=ch)
    j = _journal(bac)
    derniere = j.rstrip().splitlines()[-1][21:]
    jv = _journaux_verses(distant)
    _ecrire(f"[UC-07] run complet, commit des traces en échec : code {code} ; dernière ligne « {derniere} » ; "
            f"dossiers de traces sur la branche : {jv} ; « traces » au journal : "
            f"{[l[21:] for l in j.splitlines() if 'trace' in l[21:]]}")
    assert code == 0 and derniere.endswith("poussée (résultats et traces)") and jv == []
