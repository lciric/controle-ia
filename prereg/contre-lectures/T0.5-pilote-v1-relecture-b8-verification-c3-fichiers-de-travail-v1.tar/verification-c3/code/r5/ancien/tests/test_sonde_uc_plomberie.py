"""Sonde de la vérification c3, angle « code » (UC) : la garde de VC-01 couvre-t-elle chaque point de panne de la
plomberie de pousser_vecteurs (hash-object des deux fichiers, mktree des deux arbres, commit-tree), et pas seulement
hash-object ? Rejouée sur l'ancien script (a744490) et le nouveau (7b07300), depuis des copies hors du dépôt.
Variable SONDE_VARIANTE : « ancien » (constat seul) ou « nouveau » (assertions)."""
import os
import shutil
from pathlib import Path

import pytest

from test_script_instance_t05 import PILOTE, _distant, _git, _journal, _lancer, _lanceur_factice, bac  # noqa: F401

CAS = [("hash-object", "tous"), ("hash-object", "2"), ("mktree", "1"), ("mktree", "2"), ("commit-tree", "1")]


@pytest.mark.parametrize("cible, rang", CAS)
def test_panne_de_plomberie(bac, cible, rang):
    _lanceur_factice(bac, pilote=True)
    distant = _distant(bac)
    faux = bac["racine"] / "faux-git"
    faux.mkdir()
    compteur = faux / "compteur"
    reel = shutil.which("git")
    (faux / "git").write_text(
        "#!/usr/bin/env bash\n"
        f'if [ "$1" = "{cible}" ]; then\n'
        f'  n=$(cat "{compteur}" 2>/dev/null || echo 0); n=$((n + 1)); echo "$n" > "{compteur}"\n'
        f'  if [ "{rang}" = tous ] || [ "{rang}" = "$n" ]; then echo "fatal: panne simulée ({cible}, appel $n)" >&2; exit 128; fi\n'
        "fi\n"
        f'exec "{reel}" "$@"\n', encoding="utf-8")
    (faux / "git").chmod(0o755)
    code, sortie = _lancer(bac, distant, env_sup=PILOTE, chemin=str(faux))
    j = _journal(bac)
    lignes = [l for l in j.splitlines() if "vecteurs" in l]
    branches = _git(distant, "branch", "--list", "donnees/t05/*")
    appels = compteur.read_text().strip() if compteur.exists() else "0"
    variante = os.environ.get("SONDE_VARIANTE", "?")
    with open(os.environ["SONDE_SORTIE"], "a", encoding="utf-8") as f:
        f.write(f"[{variante}] panne {cible} rang {rang} (appels {appels}) : code {code} ; "
                f"journal {[l[21:] for l in lignes]} ; branches distantes « {branches} »\n")
    if variante == "nouveau":
        assert code == 1 and "ARRÊT pendant run" in j
        assert "vecteurs : commit impossible (plomberie git en échec) : non poussés, restés sur l'instance" in j
        assert "vecteurs poussés" not in j and "tentative" not in j and branches == ""
