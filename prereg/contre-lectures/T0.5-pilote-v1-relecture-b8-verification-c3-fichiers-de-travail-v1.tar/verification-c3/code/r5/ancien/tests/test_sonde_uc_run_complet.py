"""Sonde de la vérification c3, angle « code » (UC) : chemin du run COMPLET (ligne 350 du script, après la poussée des
résultats) avec des vecteurs écrits. Cas sain (vrai git) et artefact (hash-object en panne) : code de sortie, poussée
finale, traces versées, ligne des vecteurs. Variable SONDE_VARIANTE : « ancien » (constat) ou « nouveau » (assertions)."""
import os
import shutil

import pytest

from test_script_instance_t05 import PILOTE, _distant, _git, _journal, _lancer, _lanceur_factice, bac  # noqa: F401

LANCEUR_COMPLET_AVEC_VECTEURS = """#!/usr/bin/env bash
if [ "$1" = "-m" ] && [ "$2" = "pytest" ]; then printf '%s\\n' "7 passed in 1.00s"; exit 0; fi
if [ "$1" = "-m" ] && [ "$2" = "pip" ]; then echo "paquet-factice==1.0"; exit 0; fi
if [ "$1" = "-c" ]; then
    case "$2" in *"is_available() else 1"*) exit 0 ;; esac
    echo "torch factice"; exit 0
fi
run=""; prec=""
for a in "$@"; do [ "$prec" = "--run-id" ] && run="$a"; prec="$a"; done
mkdir -p "donnees/$run" "diag/$run" "runs/$run"
head -c 4096 /dev/urandom > "donnees/$run/vecteurs-par-action.npz"
(cd "donnees/$run" && sha256sum vecteurs-par-action.npz > vecteurs-par-action.npz.sha256)
echo '{"factice": true}' > "runs/$run/manifeste.json"; echo '{"factice": true}' > "diag/$run/resume.json"
echo '{"run": "factice"}'; exit 0
"""


@pytest.mark.parametrize("panne", [False, True])
def test_run_complet_vecteurs(bac, panne):
    _lanceur_factice(bac, pilote=True)
    (bac["venv"] / "bin" / "python").write_text(LANCEUR_COMPLET_AVEC_VECTEURS, encoding="utf-8")
    distant = _distant(bac)
    chemin = None
    if panne:
        faux = bac["racine"] / "faux-git"
        faux.mkdir()
        (faux / "git").write_text("#!/usr/bin/env bash\n"
                                  'if [ "$1" = "hash-object" ]; then echo "fatal: panne simulée" >&2; exit 128; fi\n'
                                  f'exec "{shutil.which("git")}" "$@"\n', encoding="utf-8")
        (faux / "git").chmod(0o755)
        chemin = str(faux)
    code, _ = _lancer(bac, distant, env_sup=PILOTE, chemin=chemin)
    j = _journal(bac)
    lignes = [l[21:] for l in j.splitlines() if "vecteurs" in l]
    branches = _git(distant, "branch", "--list", "donnees/t05/*")
    traces = [f for f in _git(distant, "ls-tree", "-r", "--name-only", "calcul/t05-pilote-jouet-v1").split("\n")
              if f.startswith("traces/") and f.endswith("/journal.txt")]
    journal_verse = _git(distant, "show", f"calcul/t05-pilote-jouet-v1:{traces[-1]}") if traces else ""
    ligne_versee = [l[21:] for l in journal_verse.splitlines() if l[21:].startswith("vecteurs")]
    derniere = j.rstrip().splitlines()[-1][21:]
    variante = os.environ.get("SONDE_VARIANTE", "?")
    with open(os.environ["SONDE_SORTIE"], "a", encoding="utf-8") as f:
        f.write(f"[{variante}] run complet, panne={panne} : code {code} ; vecteurs {lignes} ; branches « {branches} » ; "
                f"ligne des vecteurs dans le journal versé {ligne_versee} ; dernière ligne « {derniere} »\n")
    if variante == "nouveau":
        assert code == 0 and derniere == "branche calcul/t05-pilote-jouet-v1 poussée (résultats et traces)"
        assert "run terminé" in j
        if panne:
            assert lignes == ["vecteurs : commit impossible (plomberie git en échec) : non poussés, restés sur l'instance"]
            assert branches == "" and ligne_versee == lignes
        else:
            assert len(lignes) == 1 and lignes[0].startswith("vecteurs poussés : branche donnees/t05/")
            assert "donnees/t05/" in branches and ligne_versee == lignes
