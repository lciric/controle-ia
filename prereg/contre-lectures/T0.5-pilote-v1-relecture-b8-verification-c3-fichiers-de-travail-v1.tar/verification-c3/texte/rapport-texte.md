# Vérification courte du candidat 3 du pilote 8B de T0.5 — angle « texte »

- **Vérificateur** : sous-agent neuf. Je n'ai écrit ni les brouillons 9 et 10, ni le générateur, ni la chaîne, ni le code, ni les rapports de la vérification c2 ou de la relecture R2.
- **Date** : 2026-10-12, d'environ 04:50 à 05:20 UTC.
- **Objet** (sceaux conformes, empreintes recalculées) :
  - `brouillons/T0.5-pilote-8B-v1-candidat3.md` : `74a88671…52d1`, 550 lignes ; normalisé recalculé avec `chaine-c3/normaliser_pilote_v1.py` : `83056d15157ef9043daab5275e7d4665aa7e087bbb3b5a1556e7d9830cf9ed63`, conforme ;
  - `brouillons/T0.5-pilote-config-v1-candidat3.json` : `6979a00e…`, égale au candidat 2 ; empreinte canonique recalculée `db3ad3ce…b714` ; elle ne diffère du brouillon 1 de la configuration que par `noyau_attention` (« defaut ») et `duree_max_s` (15000) ;
  - brouillon 10 `c3ee76a9…`, brouillon 9 `a5b472e5…`, candidat 2 `622383f5…` ; plan v3 `7d9237b6…` ; proposition N-019 v2 `1de5a363…` ; chaîne figée `chaine-c3/` : treize empreintes conformes à `chaine-c3.sha256`.
- **Numéros de ligne** : ceux du candidat 3, identiques à ceux du brouillon 10 (même nombre de lignes, même découpage).
- **Règles tenues** : lecture seule dans le dépôt, `chaine-c3/` et `pilote-v1-post-r2/` (arbre suivi propre, chaîne figée intacte, aucun `__pycache__` créé : Python lancé avec `-B` ou `PYTHONDONTWRITEBYTECODE=1`) ; aucun clone ; aucune commande vastai (la garde de calcul n'a été sollicitée que par sa fonction de lecture du registre, sans commande) ; aucun jeton affiché ; D-20 : ni `episodes-defaut.json` ni `chemin-defaut.json` ouverts, aucune recherche récursive ; de `mesures-defaut.json`, seuls des nombres ; pas de suite des tests (un `pytest --collect-only` : 689 tests collectés).
- **Le dépôt a bougé pendant la vérification** (session principale) : `cdf0d4f` (05:0x UTC, GO-2026-10-12-01 de Lazar sur N-019, option (a)) puis `d4475b6` (05:10 UTC, R-147, colonne d'état de N-019 « tranché (a) par Lazar : GO-2026-10-12-01 (R-147) », `registres/etat.md` réécrit). La tâche disait « Lazar n'a pas encore répondu » : ce n'est plus le cas. Mes constats portent sur le candidat 3 (`7b07300`) ; les registres sont lus à `d4475b6` quand je le dis.

## Verdict

**Du point de vue du texte : scellable en l'état. Bilan : 0 bloquant, 0 majeur, 12 mineurs, 7 informations.**

- La table « Traitement de la vérification courte du candidat 2 » dit vrai pour l'essentiel. Elle a 39 lignes pour 54 constats :
  - 31 disent vrai, dont plusieurs restent sous condition d'épreuves à jouer ;
  - 6 disent vrai en partie : VT-11, VN-03, VN-08, VN-15/16/18 (pour VN-18), VH-07, VH-11/13/14 (pour VH-11) ;
  - 2 décrivent un engagement ou un message à venir : VT-12, VN-09/17.

  Les comptes de l'en-tête sont exacts : 54 constats, 8 majeurs, 29 mineurs, 17 informations ; six sceptiques, aucun réfuté.
- Préséance et causes : la liste est fermée (« tout autre cas : cause indéterminée ») ; aucun arrêt réel ne reste sans classement. Cinq points de conduite restent à préciser (UT-01 à UT-05) ; aucun ne touche l'application des critères de lecture par le juge R13, qui lit des résultats scellés.
- N-019 : présentée partout comme décision de Lazar citée en tête ; option (a) posée comme condition (l. 7) ; valeurs recalculées exactes. Le GO de Lazar est arrivé pendant la vérification ; les gardes de la chaîne (blocs extraits des contrôles et du lanceur) passent sur les registres courants avec une copie du texte qui porte ce GO. R-147 ajoute deux faits que le texte, écrit avant, ne reflète pas (UT-12).
- R1 complet ; les changements du brouillon 10 sont tous motivés ; rien de gelé n'est changé sans être déclaré, mais le résumé de la Transparence est incomplet (UT-06).
- **Attention au choix d'un brouillon 11** : le GO-2026-10-12-01 (ligne envoyée par Lazar) dit « préenregistrement … scellé depuis le brouillon 10 et le candidat vérifié ». Toute retouche du texte sortirait de sa lettre. Je recommande de traiter les mineurs hors du texte (ligne R-… de scellement qui fixe les conventions de UT-01 à UT-05, UT-08 et UT-12 ; registres ; plan ou note ; message), et de ne faire un brouillon 11 que si la session juge UT-01 ou UT-02 majeurs, en le consignant alors au regard du GO.

## Réponses aux questions

### 1. La table « Traitement de la vérification courte du candidat 2 » dit-elle vrai ?

Sources relues : les quatre rapports c2 (`verification-c2/{texte,code,chaine,n019}/rapport-*.md`) ; les verdicts des sceptiques (journal `wf_3be6f986-f59`, lignes 11 à 20 ; et `prereg/contre-lectures/T0.5-pilote-v1-relecture-b8-verification-c2-resultats-v1.json`, `1f78fa75…`, 54 constats recomptés : 0 bloquant, 8 majeurs, 29 mineurs, 17 informations).

| remarque (ligne) | dit-elle vrai ? | vérifié dans |
|---|---|---|
| VT-01 (l. 440) | **oui** ; restes du sceptique non repris (UT-13) ; « plan v2 » au lieu de v3 (UT-07) | texte l. 8, 192-193, 196, 199, 204 ; plan v3 l. 103-106 (4 bis) et 113-125 (étape 5, « après la poussée initiale », « dépôt distant injoignable » retiré) ; chaîne : contrôles l. 224-227 (« -v1 absente : pas de relancement »), récupération l. 49, banc des contrôles R4 ; aucun script changé pour VT-01 |
| VT-02 (l. 441) | **oui** pour le texte (l. 196) ; la récupération « depuis l'instance gardée » n'a ni procédure ni règle de lecture (UT-02) ; « écrit » n'est presque jamais établissable pendant le run (UT-01) | l. 196 ; plan v3 l. 120-121 et 126-128 |
| VT-03 (l. 442) | **oui** : « tout autre cas », carte, erreur de carte, TERM, surveillance classés ; clause du devis et du crédit (l. 204) ; ligne R-… (l. 198) ; le lanceur contrôle les trois mots et une seule instance (`lancer_pilote_v1.sh` l. 59-67) ; réserves UT-03 à UT-05 | l. 198-204 ; plan v3 l. 113-121 ; banc du lanceur c3b : P13, P13b, P13c, P13d conformes |
| VT-04 (l. 443) | **oui** | l. 24 (4ff2b075…, ee0945a8…, empreintes recalculées) ; générateur l. 393-394 ; contrôles l. 38, 75-85 ; lignes RC-04/RC-08 l. 353 |
| VT-05 (l. 444) | **oui** : les 124 constats de l'état des lieux sont cités (plages comprises) ; critique tracée (manques 0 à 19, corrections 0 à 16) ; « manque 19 : signalé à Lazar » : sous condition (message non envoyé) | l. 370-375 ; calcul de couverture (`edl/`) |
| VT-06 (l. 445) | **oui** | RC-07 l. 355 ; X-7 l. 534 ; SI-11 l. 366 ; SI-12 l. 367 ; recharge l. 345 (« plan v2, étape 3 », identique à l'étape 3 du v3) |
| VT-07 (l. 446) | **oui** | Transparence l. 262 ; R-146 ; `d20-relecture-b8.txt` et `d20-verification-c2.txt` : « fenêtres communes : 0 » |
| VT-08 (l. 447) | **oui** | l. 280 ; générateur l. 388 ; contrôles `PYREC` l. 131-134 ; normaliseur l. 19 ; scellement l. 31-36 (familles) |
| VT-09 (l. 448) | **oui** | l. 173 (« vers 900 à 950 s après la création ») |
| VT-10 (l. 449) | **oui** | l. 7 ; l. 3 (« décision N-019 de la session … (retirée depuis, R-145 ; N-019 revient à Lazar) ») |
| VT-11 (l. 450) | **en partie** : v1 intacte (`c5d46e60…`) ; la v2 dit la carte et l'hôte ; mais elle dit aussi « prêt (préenregistrement vérifié, chaîne et bancs) », prématuré (UT-14) ; « dits à Lazar » : sous condition (le brouillon de message v2 le contient, non envoyé) | proposition v2 l. 37, 45-47 ; `message-lazar-2026-10-12-brouillon-v2.md` l. 22 |
| VT-12 (l. 451) | **sous condition** (engagement) | voir UT-16 |
| VT-13 (l. 452) | **oui** pour l'essentiel ; la ligne d'auteur ne dit pas les chemins et empreintes insérés là où le brouillon n'en avait pas (UT-15) | l. 3, l. 266 ; générateur l. 308-394 |
| VT-14 (l. 453) | **oui** | l. 173 (« faites pour 64 tâches … », « 40 à 55 Gio ») |
| VC-01 (l. 454) | **oui** (lecture) : garde des cinq objets, journal « restés sur l'instance », test artefact ; « échoue sur l'ancien script » non rejoué ici | `git show c8a3325` : script l. 205-210, `test_vecteurs_plomberie_en_echec_aucun_faux_succes` ; 689 tests collectés |
| VC-02 (l. 455) | **oui** (voir VT-09) | l. 173 |
| VC-03, 04, 06-08 (l. 456) | **oui** : aucun changement de code pour eux (`git diff 2fe1046 e4be3e1` : seulement le script de l'instance, +6, et un test, +20) | — |
| VC-05 (l. 457) | **oui** | récupération l. 168-178 |
| VN-01 (l. 458) | **oui** | proposition v2 l. 33-43 ; ligne N-019 alignée (`71f5174`) |
| VN-02 (l. 459) | **oui** dans la v2 (l. 29-31, 37, 52-54) ; « dits à Lazar » : sous condition (message) | — |
| VN-03 (l. 460) | **en partie** à `7b07300` : l. 3, 26, 60 réécrites ; le résidu de la l. 16 signalé par le sceptique (« brouillon 8 ; … lancement à la recharge du crédit ») restait ; il est corrigé à `d4475b6` pendant la vérification (UT-19) | `registres/etat.md` à `7b07300` puis à `d4475b6` |
| VN-04 à 07, 10, 11, 14 (l. 461) | **oui** | proposition v2 l. 37-48, 52 |
| VN-08 (l. 462) | **en partie** : rapports c2 versés et scellés (`e4be3e1`) ; mais « cités par empreinte (R-146) » est faux pour eux (UT-10) | `grep` : 0 occurrence de `1f78fa75` ou `verification-c2` dans les registres et la proposition v2 |
| VN-09, VN-17 (l. 463) | **sous condition** (message) ; la v2 répète l'affirmation « prêt » de VN-09 (UT-14) | brouillon de message v2 l. 1 (« [État au moment de l'envoi : ÉTAT_FINAL.] ») |
| VN-12 (l. 464) | **oui** (v2 l. 13-14 ; R-146) ; message : sous condition | — |
| VN-13 (l. 465) | **oui** (v2 l. 3-5) ; message : sous condition | — |
| VN-15, 16, 18 (l. 466) | **sous condition** : banc du générateur joué à `7b07300` (21 générations, toutes conformes, G10 réel sain et G15b/G15c compris), à rejouer au commit des préalables ; **VN-18 non traité** : l'incohérence est toujours au texte (UT-09) | `banc-generateur-pilote-c3.log` |
| VH-01 (l. 467) | **oui** pour le code (scellement l. 37-41, 53-55, 63-66 : épingles, suivi à HEAD, code relu, journal) ; banc S13-S19 écrit, non joué : sous condition ; consignation au registre : à venir | `chaine-c3/sceller_pilote_v1.sh`, `essais_scellement_pilote_v1.sh` |
| VH-02 (l. 468) | **oui** pour le code (répétition l. 33-38 ; contrôles l. 145-205 : cinq scripts exactement, 64 hexadécimaux, pas de double, cause dans le KO) ; artefacts A31-A34 écrits, non joués ; répétition rejouée depuis une copie figée : en cours | journal `rep-pilote-v1-7b07300.log` : cinq lignes « script répété », empreintes égales à `chaine-c3` |
| VH-03 (l. 469) | **oui** | texte l. 199 ; plan v3 l. 122-125 |
| VH-07 (l. 470) | **en partie, sous condition** : banc du scellement écrit, pas encore versé (le dossier versé ne contient que les trois plans) ; cas de relance R1-R4 écrits ; deux artefacts de récupération dans la répétition (en cours) ; résidu « partiel » déclaré (plan v3 l. 154-155) | — |
| VH-04 (l. 471) | **oui** | scellement l. 15 |
| VH-05 (l. 472) | **oui** | générateur l. 270-271, contrôles l. 100, lanceur l. 108 ; bancs : G15b/G15c (conformes), P17h/P17i (conformes), A05b/A05c (écrits) |
| VH-06 (l. 473) | **oui** écrit (copie à une ligne exactement, l. 98 ; durée bornée, l. 72-77) ; sous condition | banc des contrôles |
| VH-08 (l. 474) | **oui** | récupération l. 15, 208 |
| VH-09 (l. 475) | **oui** | scellement l. 34-36 ; banc S16 |
| VH-10 (l. 476) | **oui** | contrôles l. 20 ; récupération l. 14 |
| VH-12 (l. 477) | **oui** | récupération l. 22, 34-38 ; répétition l. 82 (`COPIE_EXIGEE=non`) |
| VH-11, 13, 14 (l. 478) | **en partie** : VH-13 et VH-14 justes (aucun `-I -B` dans la chaîne) ; pour VH-11, « aucune action » est inexact dans l'autre sens : l'action a été faite (plan v3, cité par le générateur, `PLAN` l. 52) (UT-17) | — |

### 2. Préséance et causes d'arrêt

**Sans ambiguïté ? En grande partie.** La préséance (l. 196) et les causes (l. 198-204) se lisent ainsi :
1. `episodes.json` poussé (sur `-v1`) : jamais de relancement, lecture telle quelle ;
2. écrit mais non poussé : récupération depuis l'instance gardée, sinon nœud ;
3. ni écrit ni poussé, arrêt **après** « branche … poussée avant l'installation », cause d'infrastructure, dans le devis et le crédit : un relancement (`-v2`) ;
4. tout le reste (arrêt avant cette ligne, cause déterministe ou indéterminée, hors devis) : nœud.

**Liste fermée ? Oui** (l. 202 : « tout autre cas ») ; elle n'est pas une partition : la poussée initiale refusée pour un refus de droit est dans deux classes (UT-05), sans effet sur l'issue (nœud dans les deux cas).

**Cohérence avec le plan v3 :**
- étape 4 (création, mode relance, instance tolérée) : cohérente ;
- 4 bis : cohérente avec le premier tiret (l. 199) ; mais la ligne attendue « début : … BRANCHE=calcul/t05-pilote-reel-v1 » est écrite en dur, alors qu'un relancement porte `-v2` (UT-11) ;
- étape 5 : alignée (cause « après la poussée initiale », liste identique, « dépôt distant injoignable » retiré, devis et crédit, ligne R-…, « ni écrit ni poussé ») ;
- étape 6 : cohérente (code 2 = avant l'installation = nœud ; code 1 lu sur le journal ; poussée finale en échec = instance gardée) ;
- étape 7 : cohérente (relance : `-v1` lue sans `episodes.json`).

**Cohérence avec la chaîne :**
- lanceur, ligne R-… : trois mots (« relancement », « pilote », « infrastructure », toute casse) et une seule instance distincte (l. 59-67). Le texte exige en plus la cause tirée de la liste, l'étape et le motif : exigence de procédure, non contrôlée (déclarée par VT-03) ;
- contrôles et récupération en relance : `-v1` présente sans `episodes.json`, `-v2` absente (contrôles l. 217-228 ; récupération l. 40-50) : c'est la forme mécanique de « poussé » et de « après la poussée initiale ». « Écrit mais non poussé » n'a pas de garde mécanique : il repose sur la ligne R-… (cause, étape, motif).

**Un arrêt réel resterait-il sans classement ? Non**, grâce à « tout autre cas ». Mais cinq cas sont classés par une lecture que le texte ne dit pas :
- perte de l'instance pendant le run : le journal relayé par la surveillance n'a aucune ligne entre « run : … » et la fin (le lanceur n'écrit rien à l'écriture d'`episodes.json`, sa sortie d'erreur va dans `run.err`). Les pièces nommées n'établissent donc jamais l'absence d'`episodes.json` : par la lettre, la cause est indéterminée (nœud), alors que « instance perdue » est rangée parmi les causes d'infrastructure. Le texte ne dit pas si le temps écoulé compte comme pièce (UT-01) ;
- résultats écrits mais non poussés : aucune procédure ni règle de lecture ; la session ne peut ni copier ni exécuter sur une instance (R-060) ; une instance arrêtée par la surveillance ne laisse ni `arret.json` ni `resume.json`, et la l. 191 rend alors ces résultats non lisibles, même récupérés (UT-02) ;
- seuil de 1 500 s : la l. 200 le compte depuis la ligne « AMORCE », le « Calcul » (Z-5) depuis la création (UT-03) ;
- arrêt du run relancé, et crédit insuffisant au moment du relancement (attente de recharge, comme au plan, ou nœud ?) (UT-04) ;
- « tests en échec » reste déterministe même si l'échec vient du réseau : c'est prudent (manque 8 de la critique), sans constat.

### 3. N-019

- **Présentation** : partout décision de Lazar citée en tête (l. 7, 20, 257, 266, 343, 413-414, 434, 449) ; la décision v1 de la session est dite retirée (l. 3, 20, 257, 343, 413). Une seule attribution fausse : l. 374, « N-019 décidée par Lazar (R-145) » (UT-08).
- **Condition** : l. 7, « GO … qui retient l'option (a) de la proposition N-019 ; ce préenregistrement ne vaut que sous cette option ; toute autre → nouvelle version ».
- **Valeurs** (recalculées depuis `mesures-defaut.json`, `bdc78cb2…`, avec le code cité) : d à 192 = 8 089,6213 s (égal au scellé) ; d à 180 = 7 584,02 s ; marge 215,98 s (2,77 %) ; par lots 7 752,55 s (marge 47,45 s) ; `duree_max_s` = min(15 000 ; 16 320) = 15 000 s ; temps brut après les épisodes 7 415,98 s ; 48/60 = 80 %. Toutes cohérentes dans le texte, avec la proposition v2 et avec la configuration.
- **Le GO est arrivé pendant la vérification** : GO-2026-10-12-01 (`registres/go.md` l. 24 : type « revendication », périmètre « N-019, option (a) … », accordé par Lazar, 8 colonnes) ; R-147 (`registres/decisions.md` l. 284) ; colonne d'état de N-019 (l. 328) exactement « tranché (a) par Lazar : GO-2026-10-12-01 (R-147) ». Rejoués sur une copie du texte qui porte ce GO (dans mon dossier) : bloc `PYGO` des contrôles « GO GO-2026-10-12-01 (R-147) conforme », code 0 ; bloc `GO19` du lanceur, code 0 ; lecture du registre par la garde de calcul : 16 GO lus, sans erreur.
- **Deux faits nouveaux de R-147, absents du texte** (UT-12) : « le retrait de R-145 est levé » (Lazar confirme la décision de la session), alors que le texte dit la décision v1 « retirée » ; et une délégation élargie, qui change le sens de « nœud » pour les nœuds « de même nature que N-019 », alors que le texte, écrit avant, dit « nœud » et parfois « proposition à Lazar ». Le périmètre du GO cite « le brouillon 10 et le candidat vérifié » : c'est le candidat 3 tel qu'il est.

### 4. R1 et changements du brouillon 10

**R1 est complet** : hypothèse (l. 32-52), prédictions chiffrées avec leur sens et leurs clauses (l. 54-72), métrique (l. 74-113), seuils (l. 115-138), plan d'analyse (l. 140-174), critères de lecture gelés (l. 176-224), liste d'arrêt (l. 226-249). `problemes()` est vide sur le candidat 3. L'annexe est égale à `CONSIGNE_ETIQUETAGE` et `INVITE_ETIQUETEUR` de `lire_pilote.py` à `e4be3e1` (comparaison exacte).

**Changements du brouillon 10 hors des tables** (différentiel ligne à ligne, `diff-b9-b10*.txt`) :

| ligne | changement | motif |
|---|---|---|
| 1 | titre « brouillon 10 » | forme |
| 3 | résumé du brouillon 10 ; brouillon 8 : « décision N-019 de la session (retirée depuis, R-145…) », invite de l'étiqueteur ; brouillons 7 à 9 gardés ; liste des traitements | VT-10, VT-13 (TX-09) |
| 7 | GO « qui retient l'option (a) … ne vaut que sous cette option ; toute autre → nouvelle version » | VT-10 |
| 8 | relancement : « cause d'infrastructure après la poussée initiale, `episodes.json` ni écrit ni poussé ; Préséance » | VT-01, VT-02 |
| 24 | préenregistrement scellé de la revalidation et sa configuration cités | VT-04 |
| 173 | attentes des tests (900 à 950 s) ; d prudente (manque 6) ; estimations faites pour 64 tâches ; mémoire 40 à 55 Gio | VT-09, VC-02, VT-05, VT-14 |
| 193 (table) | ligne « run relancé » | VT-01, VT-02 |
| 196 | préséance « écrit et poussé », récupération ou nœud, « écrit » établi sur les pièces, relancement seulement après la poussée initiale | VT-01, VT-02 |
| 198-204 | causes : ligne R-… précisée ; classe « arrêt avant la poussée initiale » ; infrastructure bornée à l'après-poussée, carte, TERM et surveillance classés ; « tout autre cas » ; clause du devis et du crédit | VT-01, VT-03 |
| 262 | incident D-20 d'un sceptique | VT-07 |
| 266 | résumés des brouillons 9 et 10 | VT-13 |
| 280 | ligne des rapports élargie aux vérifications courtes | VT-08 |
| 435-478 | table de traitement de la vérification c2 | — |

Aucun seuil, aucune prédiction, aucune constante de lecture, aucune clé de configuration ne change. Les éléments gelés changés sont la préséance, les causes, la ligne « run relancé » et la ligne « Lancement ». Tous sont déclarés dans la ligne d'auteur et la table VT. **Mais le résumé de la Transparence (l. 266) n'en dit qu'une partie** (UT-06).

Différentiel candidat 2 → candidat 3, normalisé : les lignes changées sont celles du brouillon 10, plus trois valeurs du générateur seulement : l. 6 (script de l'instance `077424d0…`, VC-01), l. 20 (proposition v2), l. 23 (plan v3). Rien d'inattendu.

Empreintes : sur les 49 empreintes de 64 caractères du candidat, 41 désignent bien le fichier cité juste avant, 5 sont celles des brouillons relus 1, 3, 4, 5 et 6, deux sont attendues sans chemin (configuration canonique, tâches), et une est la paire factice des rapports. `lecture-defaut.json` est cité sans empreinte (l. 22 et 346) ; elle figure dans le verdict cité (UT-15).

### 5. Sondage des tables (état des lieux et relecture R2)

| ligne | dit-elle vrai ? | motif |
|---|---|---|
| PF-01 (l. 370) | oui | lanceur l. 152-154 (crédit lu après l'offre, juste avant la création) ; banc P08, P08b ; étape 3 identique en v2 et v3 |
| HR-02 (l. 371) | oui | relecture R2 et vérification c2 (code `942c65e..3a6d1b1`) ; CH-01 dans les contrôles et le scellement |
| AR-20 (l. 372) | oui (v3 aussi) | plan v3 étapes 1, 4 et 7 |
| informations (l. 373) | oui pour la gravité (13 constats « information » recomptés) ; « sans action » inexact pour HR-14, PF-07 et VR-15, dont l'action a été faite (UT-17) | JSON de l'état des lieux |
| critique, manques 0 à 19 (l. 374) | oui, sauf « 2 : … N-019 décidée par Lazar (R-145) » (UT-08) et « 19 : signalé à Lazar » (sous condition) ; « 16 » : 11,5 cibles attribué aux fiches alors que la critique le tire du bilan (surdéclaration, UT-15) | critique, JSON |
| critique, corrections au plan 0 à 16 (l. 375) | oui ; non dit : la correction 3 demandait aussi la mémoire vive ramenée à 64 Go, non reprise (plan v3 : ≥ 128 Go) (UT-17) | plan v3 l. 85-87 |
| VR-03, VR-12, VR-14, CO-13 (l. 344) | en partie : VR-12 (devis chiffré) et VR-14 (« l'échec vient de la planification », à dire dans le nœud) ne sont repris nulle part (UT-17) | proposition v2 |
| VR-07, PL-22, PF-08 (l. 347) | oui | lanceur l. 34, 140-145 ; récupération 6b |
| RC-04, RC-08 (l. 353) | oui | l. 24 |
| RC-07 (l. 355) et X-7 (l. 534) | oui | `extraire_t05.py` sous `src/`, arbre gelé |
| SI-11 (l. 366), SI-12 (l. 367) | oui | raisons exactes (code gelé ; TERM jamais reçu en vrai) |
| AR-15 (l. 351) | oui | `rep()` exige une seule occurrence (générateur l. 294-299) ; « À REMPLIR » restant refusé (l. 398-399) |
| TX-01 (l. 381) | oui ; « alignés sur le plan v2 (étape 4 bis) » : le v3 l'est en entier, le v2 non (UT-07) | plan v2 l. 100 (« dépôt distant injoignable » encore cause de relancement) |
| TX-02 (l. 382) | oui | 124/124 |
| CO-09, CO-10 (l. 407) | oui | l. 173 |
| NO-01, NO-02 (l. 413) | oui | proposition v1 puis v2 |
| CH-03 (l. 424) | oui pour le code (liste de l'arbre lue sur un fichier : contrôles l. 224-226, récupération l. 45-47) ; bancs des contrôles et du scellement : sous condition | — |
| CH-12 (l. 432) | **périmé** : « plan de lancement v2 … douze scripts » ; la chaîne et le plan v3 en ont treize (UT-07) | plan v3 l. 29-33 ; scellement l. 47-50 ; répétition finale l. 23-24 |

### 6. Ce qui manquerait à un futur juge R13

Pour appliquer les critères gelés à des résultats scellés, rien d'essentiel : table de lecture, runs partiels, juge complet défini par son fichier, P2 et P3, plan B, familles, audit et combinaisons sont sans ambiguïté. Il lui manquerait, pour juger qu'il lit le bon run :
1. la règle de lecture de résultats récupérés sur une instance gardée, et qui les vérifie (UT-02) ;
2. le statut d'un relancement décidé après une perte d'instance pendant le run (UT-01) ; l'origine du seuil de 1 500 s (UT-03) ; le sort d'un arrêt du run relancé (UT-04) ;
3. le régime des issues « nœud » après R-147, et la lecture de « décision v1 retirée » face à « retrait levé » (UT-12) ;
4. des renvois à jour : plan v3 et non v2, treize scripts, la bonne ligne R-… pour la décision de Lazar (UT-07, UT-08) ;
5. le traitement de la présente vérification : sans brouillon 11, aucune table du texte scellé ne le portera ; seule la ligne masquée citera nos rapports (UT-18) ;
6. pour l'étiquetage (déjà signalé en c2, non changé) : la forme exacte de la ligne de registre qui consigne le modèle des étiqueteurs par lot.

## Constats

### UT-01 — mineur (doute : majeur) — « Écrit » ne s'établit presque jamais pendant le run : une perte d'instance en plein run tombe en « indéterminée »

- **Où** : candidat l. 196 et l. 200 ; `scripts/pilote_t05_instance.sh` (`077424d0…`) l. 57, 328-331, 347 ; `src/controle_ia/environnements/lancer_pilote_a.py` l. 333-359.
- **Preuve** :
  - l. 196 : « « Écrit » s'établit sur les pièces : résultats poussés, ou journal de l'instance relevé par la surveillance ; si elles n'établissent pas l'absence d'`episodes.json`, la cause est indéterminée » ; l. 200 range « instance perdue » parmi les causes d'infrastructure.
  - Le script écrit « run : $RUN » (l. 328), lance le lanceur avec `>run.json 2>>run.err` (l. 330-331), puis plus rien jusqu'à « run terminé » (l. 347) ou l'arrêt consigné. Le lanceur n'imprime rien quand il écrit `episodes.json` (l. 359 : seul `etat["episodes_ecrits"]` change). `vastai logs` ne voit donc aucune trace d'avancement pendant le run.
  - Une instance perdue, ou arrêtée sans consignation, pendant le run ne pousse rien. Les pièces nommées n'établissent pas l'absence d'`episodes.json`, d'où « cause indéterminée », donc nœud, sauf à admettre le temps écoulé (horodatage de « run : … », heure de la perte, durée projetée de 7 584 s) comme pièce, ce que le texte ne dit pas.
- **Effet** : la session peut hésiter entre relancer (« instance perdue ») et nœud dans le cas d'incident le plus probable sur Vast.ai ; un juge pourrait ensuite contester la légitimité d'un run relancé.
- **Action** : sans toucher au code gelé, fixer la convention (ligne R-… de scellement, ou brouillon 11) : « une perte de l'instance après la ligne « run : … » donne un nœud » (prudent), ou « le temps écoulé depuis « run : … », inférieur à X s, établit l'absence d'`episodes.json` ».

### UT-02 — mineur (doute : majeur) — Résultats « écrits mais non poussés » : ni procédure de récupération, ni règle de lecture

- **Où** : l. 196 ; l. 191 ; l. 239 ; plan v3 l. 126-140 ; `registres/etat.md` (N-012 : R-060).
- **Preuve** :
  - l. 196 : « écrit mais non poussé (instance perdue ou arrêtée après les épisodes, poussée refusée), ses résultats se récupèrent depuis l'instance gardée (N-009), sinon nœud ».
  - Le plan v3 ne décrit aucune récupération depuis une instance : l'étape 7 lit la branche, et exige des commits de l'auteur « instance de calcul (T0.5) » (`recuperation_pilote_v1.sh` l. 62-63).
  - La session ne peut ni copier ni exécuter sur une instance (R-060, rappelé dans `etat.md` : « la clé ne permet ni copie ni exécution ») : seul un geste de Lazar le permettrait.
  - La l. 191 rend « non lisible » un run sans `arret.json` ni `resume.json`. C'est le cas d'une instance arrêtée par la surveillance après les épisodes, même si ses fichiers sont récupérés. La l. 196, elle, laisse entendre qu'ils seraient lus.
- **Action** : écrire, dans la ligne R-… de scellement ou dans une note citée par le plan, qui récupère (Lazar), comment les fichiers sont vérifiés (sceaux `.sha256` du lanceur, manifeste, empreintes au journal) et comment ils se lisent : tels quels s'ils portent `arret.json` ou `resume.json` scellés, sinon ligne de la l. 191 (nœud). À défaut, écrire simplement : écrit mais non poussé = nœud, résultats gardés.

### UT-03 — mineur — Seuil de 1 500 s : deux origines différentes

- **Où** : l. 200 ; l. 173 (Z-5) ; plan v3 l. 116.
- **Preuve** : l. 200 : « si la mise en place (de la ligne « AMORCE » au début du run) a dépassé 1 500 s ». l. 173 : « le délai externe de 270 minutes ne vient avant l'arrêt par la surveillance que si le run démarre dans les 1 500 s après la création ». La surveillance compte depuis la création (17 700 s) ; le délai externe, depuis le début du run (16 200 s) ; c'est bien la création qui fonde le seuil. La ligne « AMORCE » arrive environ 45 s après la création (revalidation v2), davantage si l'image tarde.
- **Action** : aligner la l. 200 sur la création (heure de `lancement.txt`) et le début du run (horodatage de « run : … »), ou dire que l'écart est accepté.

### UT-04 — mineur — Relancement : deux cas sans règle écrite

- **Où** : l. 192, l. 199, l. 204 ; plan v3 l. 89-92.
- **Preuve** :
  - Un arrêt du run relancé (`-v2`) n'est classé nulle part. « Relancement unique » laisse entendre un nœud, mais la l. 192, appliquée telle quelle au run relancé, dit « un relancement ». Le premier tiret des causes (l. 199) ne parle que de `-v1`.
  - l. 204 : relancement « seulement s'il tient dans le reste du devis … et du crédit » ; mais la liste des nœuds ne nomme que « un relancement hors du devis ». Le plan, étape 3, prévoit pour un crédit insuffisant le code 3 et une recharge demandée à Lazar, pas un nœud.
- **Action** : « un arrêt du run relancé, quelle qu'en soit la cause, donne un nœud ; aucune branche `-v3` » ; « crédit insuffisant au relancement : attente de la recharge (plan, étape 3), sans nœud » (ou l'inverse, mais écrit).

### UT-05 — mineur — Classes non exclusives : la poussée initiale refusée pour un refus de droit est dans deux classes

- **Où** : l. 199 et l. 201.
- **Preuve** : l. 199 : « arrêt avant la poussée initiale (… poussée initiale refusée quelle qu'en soit la cause …) : nœud » ; l. 201, cause déterministe : « poussée initiale refusée quand git donne un refus de droit (le jeton ; un relancement n'y changerait rien) ». Les deux donnent un nœud, mais la ligne R-… doit citer « la cause tirée de la liste » (l. 198), et deux classes conviennent.
- **Action** : retirer l'élément de la l. 201, ou l'annoter « (classé arrêt avant la poussée initiale) ».

### UT-06 — mineur — La Transparence ne déclare qu'une partie des changements gelés du brouillon 10

- **Où** : l. 266.
- **Preuve** : « le brouillon 10 classe en nœud les arrêts d'avant la poussée initiale et ferme la liste des causes (VT-01, VT-03) ». Ne sont pas dits : la préséance « écrit et poussé », avec récupération ou nœud, et « écrit » établi sur les pièces (VT-02) ; la condition de devis et de crédit du relancement (VT-03, reprise de la procédure b4). Ces changements ne sont déclarés que dans la ligne d'auteur (l. 3) et la table (l. 441-442). C'est le même défaut que VT-13 (a) de la vérification c2.
- **Action** : compléter la phrase à la prochaine version ; sans brouillon 11, le déclarer dans la ligne R-… de scellement.

### UT-07 — mineur — Renvois périmés au plan v2 et aux « douze scripts »

- **Où** : l. 370 (« plan v2, étape 3 »), l. 372 (« plan v2 (étapes 1, 4 et 7) »), l. 381 et l. 440 (« aligné(s) sur le plan v2 (étape 4 bis) »), l. 432 (CH-12 : « Plan de lancement v2 aligné sur les scripts (douze scripts …) »).
- **Preuve** :
  - Le texte ne cite par chemin et empreinte que le plan v3 (l. 23). Le plan v2 n'est pas aligné sur le texte : à son étape 5 (l. 100), il range encore « dépôt distant injoignable » parmi les causes de relancement.
  - La chaîne compte treize scripts : plan v3 l. 29-33, `CHAINE` du scellement l. 47-50, répétition finale l. 23-24.
- **Action** : écrire « plan v3 » (étapes 4 bis et 5 pour l. 381 et 440) et « treize scripts depuis VH-07 » ; sans brouillon 11, le déclarer (ligne R-…).

### UT-08 — mineur — l. 374 : « N-019 décidée par Lazar (R-145) »

- **Où** : l. 374 (critique, manque 2).
- **Preuve** : R-145 (`registres/decisions.md` l. 282) rend N-019 à Lazar et retire R-143 ; la décision de Lazar est GO-2026-10-12-01 (R-147, l. 284), citée en tête au scellement.
- **Action** : « N-019 rendue à Lazar (R-145), décidée par son GO cité en tête ».

### UT-09 — mineur — VN-18 non traité : les fourchettes de l'appariement et des juges ne s'accordent pas

- **Où** : l. 173 ; l. 152 ; proposition v2 l. 30 ; ligne VN-15, 16, 18 (l. 466 : « aucune autre action »).
- **Preuve** : « appariement de 5 à 27 minutes ; notations décisives des deux juges de 4 600 à 13 500 s (de 5 400 à 15 100 s avec l'appariement) ». Or 4 600 + 300 = 4 900 s, et non 5 400 : la borne basse prend l'appariement de VR-03 (800 s), la borne haute 1 620 s. Le sceptique de VN-02 recommandait d'« accorder la fourchette d'appariement (VN-18) ».
- **Action** : « de 4 900 à 15 100 s avec l'appariement » (ou citer la source de chaque borne) ; sinon, dire dans la table que VN-18 n'est pas adopté, avec sa raison.

### UT-10 — mineur — VN-08 : les rapports de la vérification c2 ne sont cités par empreinte nulle part

- **Où** : l. 462 ; R-146 (`registres/decisions.md` l. 283) ; R-147 (l. 284) ; proposition v2 l. 18-19.
- **Preuve** : R-146 cite les rapports de la relecture R2 (`5d604efd…`, `25a27dd6…`), pas ceux de la vérification c2, versés après (`e4be3e1` : `…-verification-c2-resultats-v1.json` `1f78fa75…`, `…-fichiers-de-travail-v1.tar` `d18df563…`). `grep` : 0 occurrence dans les registres et dans la proposition v2, qui promet pourtant « empreintes dans la ligne R-… qui consigne cette version ».
- **Action** : une ligne R-… qui cite les rapports c2, puis c3, par empreinte, avant le message ; ou corriger la ligne VN-08.

### UT-11 — mineur — Plan v3, étape 4 bis : la ligne attendue nomme `-v1` en dur

- **Où** : plan v3 l. 103-106 ; étape 5, l. 121-122 ; candidat l. 8 et l. 23 (le plan est cité pour les étapes 4 à 6).
- **Preuve** : 4 bis attend « début : ETUDE=pilote MODE=reel COMMIT=<S> BRANCHE=calcul/t05-pilote-reel-v1 », « Sinon : arrêt par identifiant (R10), nœud ». Le script écrit `BRANCHE=$BRANCHE` (l. 60), soit `…-v2` en relance. Lue à la lettre, l'étape 4 bis arrêterait le run relancé et ferait un nœud.
- **Action** : note de plan (ou plan v4, R12) : « BRANCHE=<branche du lancement : -v1, ou -v2 en relance> ». Sans effet sur le texte.

### UT-12 — mineur — R-147, posée pendant la vérification, change deux choses que le texte ne dit pas

- **Où** : candidat l. 3, 20, 257, 343, 413, 449 (« décision v1 … retirée ») ; issues « nœud » (l. 46, 130, 132, 181-192, 199, 204, 246, 248…) ; `registres/decisions.md` l. 284 (R-147) ; `registres/go.md` l. 24.
- **Preuve** :
  - R-147 : « N-019 tranché (a) par Lazar ; le retrait de R-145 est levé » ; `etat.md` (`d4475b6`) : « Il confirme la décision de la session (R-143), que R-145 avait retirée faute de délégation ».
  - R-147 : « la session tranche seule, à l'avenir, les nœuds de même nature que N-019 (choix d'option, écart nommé à une lecture gelée), consignés et déclarés dans le texte concerné ».
  - Le texte, écrit avant, dit la décision v1 « retirée ». Il emploie « nœud » au sens de la hiérarchie antérieure (arrêt, attendre le GO), parfois explicitement « proposition à Lazar » (l. 46, 185). Un texte scellé ne peut plus « déclarer » de nouvelles décisions.
  - Le GO cite « préenregistrement … scellé depuis le brouillon 10 et le candidat vérifié » : un brouillon 11 sortirait de sa lettre.
- **Action** : dans la ligne R-… de scellement, ou dans une note citée : (i) « décision v1 : retirée par R-145, retrait levé par R-147 ; le texte vaut sous GO-2026-10-12-01 » ; (ii) dire quel régime vaut pour les issues « nœud » de ce pilote (je recommande : elles restent des décisions de Lazar, sauf les cas que R-147 couvre expressément, consignés par une ligne R-… avant toute action). Ne pas rouvrir le texte pour cela.

### UT-13 — information — Restes du sceptique de VT-01 ni repris ni déclarés

- **Où** : l. 440 ; l. 228 ; plan v3 ; banc des contrôles, cas R1.
- **Preuve** : le sceptique demandait (i) d'écrire au plan que la session ne crée jamais `-v1` elle-même : les contrôles et la récupération acceptent une `-v1` poussée par la session, et le cas sain R1 du banc la simule ainsi ; (ii) de corriger « plan de lancement du pilote, étape 2 » (l. 228) en « étape 4 bis ». Ni l'un ni l'autre n'est fait ; la ligne VT-01 ne les nomme pas, alors que VH-01 et VH-02 citent leurs restes. Le texte ferme déjà la voie (l. 196 et 199 classent sur la ligne du journal, non sur l'existence de `-v1`).
- **Action** : une phrase au plan (note) ; mentionner les restes dans la ligne R-….

### UT-14 — information — La proposition v2 répète « prêt (préenregistrement vérifié, chaîne et bancs) »

- **Où** : proposition v2 l. 37 ; ligne VN-09, VN-17 (l. 463) ; brouillon de message v2 l. 1.
- **Preuve** : à 05:15 UTC, la vérification c3 est en cours, les épingles valent « A_EPINGLER », les bancs des contrôles et du scellement ne peuvent pas tourner, et la répétition jouet est en cours. La v2 est scellée (R12) : seul le message peut corriger.
- **Action** : remplir « ÉTAT_FINAL » du message avec l'état réel ; le dire en une ligne.

### UT-15 — information — Ligne d'auteur et citations : trois détails

- **Où** : l. 3 ; l. 22 et l. 346 ; l. 260.
- **Preuve** :
  - (a) Le générateur ajoute des chemins et des empreintes là où le brouillon n'en avait pas : P-009 et P-010, la décision v1, `mesures-defaut.json`, les chemins de P-006, P-007, de la règle de sélection, du manifeste, du corpus et des pièces de T0.4. La ligne d'auteur dit seulement « empreintes abrégées complétées ». Toutes ces citations sont justes (41 empreintes recalculées).
  - (b) `lecture-defaut.json` est cité sans empreinte ; son empreinte `3c8e76ba…` figure dans le verdict cité (l. 189 du verdict). R6 est donc tenue par transitivité.
  - (c) « 11,5 cibles par tâche » est rangé parmi les nombres lus dans les fiches, alors que la critique le tire du bilan. C'est une surdéclaration, sans effet.
- **Action** : aucune avant le scellement ; à reprendre si un brouillon 11 se fait.

### UT-16 — information — Lignes « sous condition » : épreuves et message encore à jouer

- **Où** : l. 414 (NO-03), 424 (CH-03), 427 (CH-06, CH-07), 429 (CH-09), 432 (CH-12), 451 (VT-12), 459 (VN-02), 463-466, 467-470, 473.
- **Preuve** :
  - joués, conformes : banc du lanceur c3b (50 cas, dont P13b-d et P17h-i) ; banc du générateur à `7b07300` (21 générations ; normalisé du cas sain `83056d15…`) ;
  - non jouables avant les épingles : bancs des contrôles et du scellement, répétition finale ;
  - en cours : répétition jouet à `7b07300`, depuis une copie figée (journal : cinq lignes « script répété » égales à `chaine-c3`) ;
  - non envoyé : message à Lazar.
- **Action** : relire ces lignes cas par cas au commit des préalables (VT-12), avant le scellement.

### UT-17 — information — Traitements partiels non dits

- **Où** : l. 344 (VR-12, VR-14), 373, 375 (correction 3), 478 (VH-11).
- **Preuve** :
  - VR-12 (devis chiffré) et VR-14 (« l'échec vient de la planification ») ne sont repris nulle part ;
  - la correction 3 demandait aussi la mémoire vive minimale à 64 Go (plan v3 : ≥ 128 Go) ;
  - « Informations, sans action » couvre des informations dont l'action a été faite (HR-14, PF-07, VR-15) ;
  - VH-11 : « aucune action » alors que le plan v3 l'a traité ;
  - le reste 5 du sceptique de VN-01 (montants en dollars de la v2, 6,7 et 9,3 USD, non vérifiés) n'est pas noté.
- **Action** : aucune avant le scellement ; le dire dans la ligne R-… si l'on veut une trace exacte.

### UT-18 — information — Sans brouillon 11, le traitement de la vérification c3 n'aura pas de table

- **Où** : l. 280 (ligne masquée) ; normaliseur l. 19.
- **Preuve** : au scellement, seule la ligne des rapports change ; elle cite des rapports de la famille `relecture-b8`. Les constats de cette vérification qu'on traite hors du texte n'auront donc pas de ligne de traitement lisible par le juge R13.
- **Action** : verser, dans la même famille (`T0.5-pilote-v1-relecture-b8-verification-c3-…`), un fichier de traitement scellé avec les rapports. Il sera cité par la ligne masquée. Sinon, une ligne R-….

### UT-19 — information — Résidu de VN-03 corrigé pendant la vérification

- **Où** : `registres/etat.md` l. 16.
- **Preuve** : à `7b07300`, « brouillon 8 ; reste : candidat rempli, relecture R2, répétitions, scellement, lancement à la recharge du crédit » ; à `d4475b6`, « brouillon 10 et candidat 3 (`7b07300`), plan de lancement v3 ; reste : vérification courte du candidat 3, épingles, … scellement sous GO-2026-10-12-01, puis lancement à la recharge du crédit ».
- **Action** : aucune.

## Fichiers de travail

Sous `/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/verification-c3/texte/` :
- `diff-b9-b10.txt`, `diff-b9-b10-mots.txt`, `diff-b9-b10-compact.txt`, `diff-c2-c3.txt`, `diff-b10-c3.txt` : différentiels ;
- `edl/edl.txt` : les 124 constats de l'état des lieux, les manques et les corrections de la critique ;
- `go/` : copie du candidat 3 portant GO-2026-10-12-01 (R-147), blocs des contrôles (`PYGO`) et du lanceur (`GO19`) extraits tels quels et rejoués sur les registres de `d4475b6` (codes 0) ;
- ce rapport.

Le dépôt, `chaine-c3/` et `pilote-v1-post-r2/` n'ont pas été modifiés ; aucun clone.
