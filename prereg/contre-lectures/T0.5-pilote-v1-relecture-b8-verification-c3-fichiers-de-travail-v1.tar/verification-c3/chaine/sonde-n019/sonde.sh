#!/usr/bin/env bash
# Sonde des trois blocs N-019 (figés) et de la garde de calcul sur les registres de HEAD et des variantes synthétiques.
set -uo pipefail
B=$(cd "$(dirname "$0")" && pwd); PY=/home/user/controle-ia/.venv/bin/python
DEPOT=/home/user/controle-ia-travail; GO=GO-2026-10-12-01; REG=R-147
T=$B/cas; rm -rf "$T"; mkdir -p "$T"
git -C "$DEPOT" show HEAD:registres/go.md > "$T/go-base.md"; git -C "$DEPOT" show HEAD:registres/decisions.md > "$T/dec-base.md"
printf -- "- Décision de Lazar sur N-019 : \`%s\` (%s) (GO de type « revendication »)\n" "$GO" "$REG" > "$T/texte.md"
cas() {   # $1 nom ; $2 ligne ajoutée à go.md (vide : aucune)
    local n=$1 l=$2 d="$T/$1"; mkdir -p "$d/registres"
    cp "$T/dec-base.md" "$d/registres/decisions.md"; cp "$T/go-base.md" "$d/registres/go.md"
    [ -n "$l" ] && printf '%s\n' "$l" >> "$d/registres/go.md"
    "$PY" -I -B "$B/bloc-controles.py" "$T/texte.md" "$d/registres/go.md" "$d/registres/decisions.md" > "$d/c.txt" 2>&1; local c=$?
    "$PY" -I -B "$B/bloc-lanceur-go19.py" "$T/texte.md" "$d/registres/go.md" "$d/registres/decisions.md" > "$d/l.txt" 2>&1; local l19=$?
    "$PY" -I -B "$B/bloc-lanceur-premiere.py" "$d/registres/decisions.md" premier "" > "$d/p.txt" 2>&1; local p=$?
    "$PY" -I -B "$B/generateur_enveloppe.py" "$d" "$GO" "$REG" > "$d/g.txt" 2>&1; local g=$?
    "$PY" -I -B "$B/garde_enveloppe.py" "$B/../sonde-registre/garde_calcul_copie.py" "$d/registres/go.md" > "$d/k.txt" 2>&1; local k=$?
    v() { [ "$1" = 0 ] && echo accepte || echo REFUSE; }
    printf '%-38s générateur %-7s contrôles %-7s lanceur(GO19) %-7s lanceur(N-019) %-7s garde %-7s\n' "$n" "$(v $g)" "$(v $c)" "$(v $l19)" "$(v $p)" "$(v $k)"
    for f in g c l k; do [ -s "$d/$f.txt" ] && tail -1 "$d/$f.txt" | cut -c1-150 | sed "s/^/      $f: /"; done
}
cas B00-registres-HEAD ""
cas B01-revocation-perimetre "| GO-2026-10-12-98 | 2026-10-12 | révocation | révoque $GO (sonde) | — | — | Lazar | sonde |"
cas B02-revocation-reference "| GO-2026-10-12-98 | 2026-10-12 | révocation | sonde | — | — | Lazar | $GO |"
cas B03-type-sans-espaces "| GO-2026-10-12-98 | 2026-10-12 |révocation| révoque $GO | — | — | Lazar | sonde |"
cas B04-type-majuscule "| GO-2026-10-12-98 | 2026-10-12 | Révocation | révoque $GO | — | — | Lazar | sonde |"
cas B05-mal-formee-3-cellules "| GO-2026-10-12-98 | 2026-10-12 | révocation de $GO (sonde) |"
cas B06-mal-formee-sans-revocation "| GO-2026-10-12-98 | 2026-10-12 | revendication | sonde | x | — | — | Lazar | sonde |"
cas B07-revendication-qui-cite "| GO-2026-10-12-97 | 2026-10-12 | revendication | aucune révocation de $GO | — | — | Lazar | sonde |"
cas B08-sans-espace-initial-n019 "|GO-2026-10-12-98|2026-10-12|révocation|révoque $GO|—|—|Lazar|sonde|"
cas B09-sans-espace-initial-calcul "|GO-2026-10-12-98|2026-10-12|révocation|révoque GO-2026-10-04-08|—|—|Lazar|sonde|"
cas B10-type-sans-accent "| GO-2026-10-12-98 | 2026-10-12 | revocation | révoque $GO | — | — | Lazar | sonde |"
cas B11-revocation-calcul "| GO-2026-10-12-97 | 2026-10-12 | révocation | révoque GO-2026-10-04-08 | — | — | Lazar | sonde |"
cas B12-identifiant-mal-forme "| GO-2026-10-12-9 | 2026-10-12 | révocation | révoque $GO | — | — | Lazar | sonde |"
