import re, sys
texte, go_md, dec_md = (open(f, encoding="utf-8").read() for f in sys.argv[1:4])
m = re.findall(r"^- Décision de Lazar sur N-019 : `(GO-\d{4}-\d{2}-\d{2}-\d{2})` \((R-\d{3,4})\)", texte, re.M)
if len(m) != 1:
    sys.exit("GO de Lazar sur N-019 introuvable dans le préenregistrement de S")
go = m[0][0]
lignes = go_md.split("\n")
c = [[x.strip() for x in l.strip().strip("|").split("|")] for l in lignes if l.startswith(f"| {go} |")]
if len(c) != 1 or len(c[0]) != 8 or c[0][2] != "revendication" or c[0][6] != "Lazar" or "N-019" not in c[0][3] \
        or "(a)" not in c[0][3]:
    sys.exit(f"{go} : absent du registre courant, ou d'un autre type, ou non accordé par Lazar, ou sans N-019 et l'option (a)")
for g in (go, "GO-2026-10-04-08"):
    if [l for l in lignes if l.startswith("| GO-") and (lambda c: (len(c) == 8 and c[2].lower() == "révocation" and (g in c[3] or g in c[7])) or (len(c) != 8 and "révocation" in l.lower() and g in l))([x.strip() for x in l.strip().strip("|").split("|")])]:
        sys.exit(f"{g} révoqué dans le registre courant")
reg = m[0][1]
dec = dec_md.split("\n")
n19 = [l for l in dec if l.startswith("| N-019 |")]
etat = n19[0].rsplit("|", 2)[-2].strip() if len(n19) == 1 else ""
if not re.fullmatch(rf"tranché \(a\) par Lazar : {re.escape(go)} \({re.escape(reg)}\)", etat):
    sys.exit(f"N-019 : la colonne d'état courante n'est pas « tranché (a) par Lazar : {go} ({reg}) »")
r = [l for l in dec if l.startswith(f"| {reg} |")]
if len(r) != 1 or go not in r[0]:
    sys.exit(f"{reg} : absent du registre courant, en double, ou sans {go}")
print(go)
