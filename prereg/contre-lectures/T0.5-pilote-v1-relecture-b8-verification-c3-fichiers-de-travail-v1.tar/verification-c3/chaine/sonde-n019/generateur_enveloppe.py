"""Enveloppe du bloc N-019 du générateur (lignes 263-283 de remplir_pilote_v1.py figé, extraites telles quelles)."""
import re, sys
from pathlib import Path
from types import SimpleNamespace
d, go, reg = sys.argv[1], sys.argv[2], sys.argv[3]
a = SimpleNamespace(go=go, registre=reg)
def au_commit(chemin): return (Path(d) / chemin).read_bytes()
def arret(msg): sys.exit(f"ARRÊT du remplissage du pilote : {msg}")
exec(Path(__file__).with_name("bloc-generateur-corps.py").read_text(encoding="utf-8"))
print("générateur : accepté")
