lignes_go = au_commit("registres/go.md").decode("utf-8").split("\n")
cellules = [[c.strip() for c in x.strip().strip("|").split("|")] for x in lignes_go if x.startswith(f"| {a.go} |")]
if len(cellules) != 1 or len(cellules[0]) != 8:
    arret(f"{a.go} : absent de registres/go.md, en double ou mal formé")
ident, accorde, typ, perimetre, plafond, echeance, par, ref = cellules[0]
if typ != "revendication" or par != "Lazar" or "N-019" not in perimetre or "(a)" not in perimetre:
    arret(f"{a.go} : type {typ!r}, accordé par {par!r}, ou périmètre sans N-019 et l'option (a)")
g = a.go          # révocation lue par cellules (vérification courte, VH-05)
revocations = [l for l in lignes_go if l.startswith("| GO-") and (lambda c: (len(c) == 8 and c[2].lower() == "révocation" and (g in c[3] or g in c[7])) or (len(c) != 8 and "révocation" in l.lower() and g in l))([x.strip() for x in l.strip().strip("|").split("|")])]
if revocations:
    arret(f"{a.go} révoqué dans registres/go.md")
lignes_dec = au_commit("registres/decisions.md").decode("utf-8").split("\n")
n19 = [x for x in lignes_dec if x.startswith("| N-019 |")]
etat19 = n19[0].rsplit("|", 2)[-2].strip() if len(n19) == 1 else ""
# forme exacte de la colonne d'état (relecture R2, CH-10) ; une révocation est une ligne « révocation » de go.md
if not re.fullmatch(rf"tranché \(a\) par Lazar : {re.escape(a.go)} \({re.escape(a.registre)}\)", etat19):
    arret(f"N-019 : colonne d'état ≠ « tranché (a) par Lazar : {a.go} ({a.registre}) »")
reg = [x for x in lignes_dec if x.startswith(f"| {a.registre} |")]
if len(reg) != 1 or a.go not in reg[0]:
    arret(f"{a.registre} : ligne absente, en double ou sans {a.go}")
go, registre = a.go, a.registre
