"""Garde de calcul (copie) : lecture du registre et révocation du GO de calcul, comme decider() ; aucune commande."""
import sys, importlib.util
from pathlib import Path
spec = importlib.util.spec_from_file_location("gc", sys.argv[1]); gc = importlib.util.module_from_spec(spec); spec.loader.exec_module(gc)
reg = gc.lire_go(Path(sys.argv[2]))            # bloquer() : sortie 2 si registre mal formé
i = "GO-2026-10-04-08"
rev = sorted(k for k, r in reg.items() if r["type"] == "révocation" and (i in r["perimetre"] or i in r["ref"]))
if rev: print("garde : GO de calcul révoqué par", rev, file=sys.stderr); sys.exit(2)
print("garde : registre lu, GO de calcul non révoqué")
