import sys, re, importlib.util
from pathlib import Path
spec = importlib.util.spec_from_file_location("gc", sys.argv[1]); gc = importlib.util.module_from_spec(spec); spec.loader.exec_module(gc)
go_md = Path(sys.argv[2]); dec_md = Path(sys.argv[3])
lignes = go_md.read_text(encoding="utf-8").split("\n")
print("lignes '| GO-' :", sum(l.startswith("| GO-") for l in lignes))
mal = [(i+1, len([x.strip() for x in l.strip().strip("|").split("|")])) for i, l in enumerate(lignes) if l.startswith("| GO-") and len([x.strip() for x in l.strip().strip("|").split("|")]) != 8]
print("lignes à ≠ 8 cellules :", mal)
reg = gc.lire_go(go_md)
print("garde : registre lu,", len(reg), "GO ;", sorted(reg)[-3:])
for g in ("GO-2026-10-12-01", "GO-2026-10-04-08"):
    rev = [l for l in lignes if l.startswith("| GO-") and (lambda c: (len(c) == 8 and c[2].lower() == "révocation" and (g in c[3] or g in c[7])) or (len(c) != 8 and "révocation" in l.lower() and g in l))([x.strip() for x in l.strip().strip("|").split("|")])]
    print(g, "révocations (règle des trois blocs) :", len(rev), "; garde :", sorted(k for k, r in reg.items() if r["type"] == "révocation" and (g in r["perimetre"] or g in r["ref"])))
c = [[x.strip() for x in l.strip().strip("|").split("|")] for l in lignes if l.startswith("| GO-2026-10-12-01 |")]
print("GO-2026-10-12-01 :", len(c), len(c[0]) if c else None, c[0][2] if c else None, c[0][6] if c else None, ("N-019" in c[0][3] and "(a)" in c[0][3]) if c else None, c[0][7] if c else None)
dec = dec_md.read_text(encoding="utf-8").split("\n")
n19 = [l for l in dec if l.startswith("| N-019 |")]
print("N-019 lignes :", len(n19), "; colonne d'état :", n19[0].rsplit("|", 2)[-2].strip()[:160] if n19 else None)
print("R-147 :", len([l for l in dec if l.startswith("| R-147 |")]))
print("garde, GO-2026-10-04-08 :", reg["GO-2026-10-04-08"]["accorde"], "->", reg["GO-2026-10-04-08"]["echeance"], reg["GO-2026-10-04-08"]["type"])
