"""Bouchon du générateur, banc synthétique du scellement (vérification c3, angle chaîne) : mêmes arguments et mêmes
messages d'arrêt que le vrai pour le GO, la colonne d'état de N-019 et les rapports au commit ; recopie le candidat relu."""
import argparse, json, re, subprocess, sys
def arret(m): sys.exit(f"ARRÊT du remplissage du pilote : {m}")
p = argparse.ArgumentParser()
for x in ("depot", "commit", "mode", "date", "entropie", "sortie_p", "sortie_c"): p.add_argument(x)
for x in ("--taches", "--rapports-etat", "--rapports-relecture", "--candidat-relu", "--go", "--registre"): p.add_argument(x)
a = p.parse_args()
def git(*args):
    r = subprocess.run(["git", "-C", a.depot, *args], capture_output=True)
    if r.returncode: arret(f"git {' '.join(args)} : {r.stderr.decode(errors='replace').strip()}")
    return r.stdout
au_commit = lambda c: git("show", f"{a.commit}:{c}")
if git("rev-parse", "HEAD").decode().strip() != a.commit: arret("le commit cité n'est pas HEAD")
lignes_go = au_commit("registres/go.md").decode().split("\n")
cel = [[c.strip() for c in x.strip().strip("|").split("|")] for x in lignes_go if x.startswith(f"| {a.go} |")]
if len(cel) != 1 or len(cel[0]) != 8: arret(f"{a.go} : absent de registres/go.md, en double ou mal formé")
dec = au_commit("registres/decisions.md").decode().split("\n")
n19 = [x for x in dec if x.startswith("| N-019 |")]
etat = n19[0].rsplit("|", 2)[-2].strip() if len(n19) == 1 else ""
if not re.fullmatch(rf"tranché \(a\) par Lazar : {re.escape(a.go)} \({re.escape(a.registre)}\)", etat):
    arret(f"N-019 : colonne d'état ≠ « tranché (a) par Lazar : {a.go} ({a.registre}) »")
for x in (a.rapports_etat + "," + a.rapports_relecture).split(","):
    au_commit("prereg/contre-lectures/" + x.partition("=")[0])
t = au_commit(a.candidat_relu).decode()
open(a.sortie_p, "x", encoding="utf-8").write(t); open(a.sortie_c, "x").write('{"bouchon": true}\n')
print('{"bouchon": true}')
