# Registre des GO (synthétique)

| id | accordé le | type | périmètre | plafond | échéance | accordé par | référence |
|---|---|---|---|---|---|---|---|
| GO-2026-10-04-08 | 2026-10-04 | calcul | essai | 150 USD | 2026-11-01 | Lazar | essai |
