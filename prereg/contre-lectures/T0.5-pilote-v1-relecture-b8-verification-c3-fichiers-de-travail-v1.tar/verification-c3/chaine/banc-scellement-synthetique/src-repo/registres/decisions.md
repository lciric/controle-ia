# Registre des décisions (synthétique)

| id | ouvert le | objet | ce qu'il faut |
|---|---|---|---|
| N-019 | 2026-10-12 | nœud (essai) | en attente |
