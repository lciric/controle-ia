# dépôt synthétique du banc du scellement (vérification c3)
