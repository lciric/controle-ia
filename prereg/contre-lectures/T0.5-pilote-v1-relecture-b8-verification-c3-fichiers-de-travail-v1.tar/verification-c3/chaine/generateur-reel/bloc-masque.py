import datetime, re, sys
texte, s_ct, paires = sys.argv[1], int(sys.argv[2]), sys.argv[3].split()
t = open(texte, encoding="utf-8").read()
cite = lambda famille: " ; ".join(f"`prereg/contre-lectures/{n}` (`{e}`)" for n, e in (x.split("=") for x in paires) if famille in n)
attendu_rel = ("- Relecture R2 du brouillon 8 et du différentiel du code depuis la relecture b6 (`e6ce058`), puis "
               "vérifications courtes des candidats suivants et du différentiel du code depuis le candidat 1 (`942c65e`), "
               "par des sous-agents neufs : rapports " + cite("relecture-b8") + ".")
assert attendu_rel in t.split("\n"), "ligne de la relecture R2"
assert ("synthèse et critique de complétude ; rapports " + cite("etat-des-lieux") + ".") in t, "ligne de l'état des lieux"
d1 = re.findall(r"version scellée le (\d{4}-\d{2}-\d{2} \d{2}:\d{2}) UTC", t)
d2 = re.findall(r"^- Date \(UTC\) : (\d{4}-\d{2}-\d{2} \d{2}:\d{2}) \(", t, re.M)
assert len(d1) == 1 and d1 == d2, f"dates {d1} {d2}"
quand = datetime.datetime.strptime(d1[0], "%Y-%m-%d %H:%M").replace(tzinfo=datetime.timezone.utc).timestamp()
assert abs(quand - s_ct) <= 7200, f"date {d1[0]} à {abs(quand - s_ct):.0f} s du commit S"
n1 = re.findall(r"^- Tests attendus : `(\d+)`", t, re.M); n2 = re.findall(r"au commit cité, (\d+) tests\)", t)
assert len(n1) == 1 and n1 == n2, f"tests {n1} {n2}"
