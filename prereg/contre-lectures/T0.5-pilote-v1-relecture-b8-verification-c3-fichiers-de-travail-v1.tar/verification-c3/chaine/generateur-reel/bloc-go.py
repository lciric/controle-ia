import re, sys
texte, go_md, dec_md = (open(f, encoding="utf-8").read() for f in sys.argv[1:4])
m = re.search(r"^- Décision de Lazar sur N-019 : `(GO-\d{4}-\d{2}-\d{2}-\d{2})` \((R-\d{3,4})\)", texte, re.M)
assert m and len(re.findall(r"^- Décision de Lazar sur N-019 :", texte, re.M)) == 1, "ligne « Décision de Lazar sur N-019 »"
go, reg = m.groups()
lignes = go_md.split("\n")
c = [[x.strip() for x in l.strip().strip("|").split("|")] for l in lignes if l.startswith(f"| {go} |")]
assert len(c) == 1 and len(c[0]) == 8, f"{go} absent, en double ou mal formé"
assert c[0][2] == "revendication" and c[0][6] == "Lazar" and "N-019" in c[0][3] and "(a)" in c[0][3], f"{go} : {c[0][2]}, {c[0][6]}"
for g in (go, "GO-2026-10-04-08"):
    assert not [l for l in lignes if l.startswith("| GO-") and (lambda c: (len(c) == 8 and c[2].lower() == "révocation" and (g in c[3] or g in c[7])) or (len(c) != 8 and "révocation" in l.lower() and g in l))([x.strip() for x in l.strip().strip("|").split("|")])], f"{g} révoqué"
dec = dec_md.split("\n")
n19 = [l for l in dec if l.startswith("| N-019 |")]
assert len(n19) == 1, "N-019 absent ou en double"
etat = n19[0].rsplit("|", 2)[-2].strip()
# forme exacte de la colonne d'état (relecture R2, CH-10) ; une révocation est une ligne « révocation » de go.md
assert re.fullmatch(rf"tranché \(a\) par Lazar : {re.escape(go)} \({re.escape(reg)}\)", etat), \
    f"N-019 : colonne d'état ≠ « tranché (a) par Lazar : {go} ({reg}) »"
r = [l for l in dec if l.startswith(f"| {reg} |")]
assert len(r) == 1 and go in r[0], f"{reg} absent, en double ou sans {go}"
print(f"GO {go} ({reg}) conforme")
