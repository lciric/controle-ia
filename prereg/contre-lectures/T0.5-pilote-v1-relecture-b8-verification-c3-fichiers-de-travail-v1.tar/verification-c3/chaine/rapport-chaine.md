# Vérification courte du candidat 3 du pilote 8B de T0.5 — angle « chaîne » (c3)

- Vérificateur : sous-agent neuf. Je n'ai écrit ni le préenregistrement, ni le générateur, ni la chaîne, ni les rapports de c2. J'ai lu le rapport c2 « chaîne » comme liste de constats à vérifier, et les verdicts des sceptiques de VH-01 et VH-02 (journal du workflow `wf_3be6f986-f59`, lignes 19 et 20).
- Date : 2026-10-12, de 04:58 à 05:45 UTC environ.
- Dépôt de travail : `/home/user/controle-ia-travail`, en lecture seule. **La tête a bougé pendant la vérification** : `cdf0d4f` au début (GO-2026-10-12-01 de Lazar inscrit dans `registres/go.md`), puis `d4475b6` (N-019 tranché, R-147). L'arbre gelé est identique entre `e4be3e1`, `7b07300` et `d4475b6` (`git diff --quiet … -- CHEMINS_GELES` : code 0).
- Objet : candidat 3 (`74a88671…`, sceau conforme, normalisé recalculé `83056d15…`) et sa configuration (`6979a00e…`, égale octet pour octet à celle du candidat 2).
- Chaîne figée : `chaine-c3/` (treize scripts, empreintes conformes à `chaine-c3.sha256`, figée à 04:49:37). Le bloc-notes `pilote-v1/` lui est égal (13 sur 13). Chaîne lue par c2 : `pilote-v1-post-r2/`.

Règles tenues :
- aucune écriture dans le dépôt de travail, `chaine-c3/` ni `pilote-v1-post-r2/` (vérifié à la fin : 13 empreintes conformes, aucun fichier plus récent dans `pilote-v1-post-r2/`) ;
- aucune commande vastai. La garde de calcul n'a été jouée que sur une entrée JSON synthétique, comme le font les contrôles (l. 319), ou par import d'une copie ;
- aucune valeur de jeton affichée ;
- D-20 : `episodes-defaut.json` et `chemin-defaut.json` non ouverts, aucun grep dans `diag/`. Seuls ont été produits des noms (`git ls-tree … | grep '/episodes\.json$'` : 0 chemin), des tailles (`du`), et `verifier-arbre`, qui hache sans rien afficher ;
- un seul clone (local, adresse de poussée neutralisée), supprimé à la fin (état consigné dans `etat-clone-avant-suppression.txt`) ;
- pas de suite complète des tests (seule la collecte du générateur a tourné) ;
- Python lancé avec `-B` ou `PYTHONDONTWRITEBYTECODE=1`.

## Verdict

Les constats VH de c2 et les restes des sceptiques sont traités dans la chaîne figée, et ces traitements tiennent à l'épreuve. Points éprouvés :
- le scellement relit épingles, code relu, suivi à HEAD et journal, tous avant l'entropie ;
- un arrêt d'avant le piège sort en code 2 (éprouvé : 2, contre 128 pour la version lue par c2) ;
- la révocation est lue par cellules, à l'identique dans les trois blocs (sonde de 13 cas) ;
- le journal de la répétition jouet au commit `7b07300` (fini à 05:31) satisfait exactement les attentes figées des contrôles ;
- à la tête actuelle, avec le vrai GO-2026-10-12-01 et R-147, le générateur figé reproduit le candidat 3 (normalisé `83056d15…`, configuration `6979a00e…`), et les blocs « parties masquées » et « GO » des contrôles l'acceptent.

**Un constat majeur, UH-01.** Le banc du scellement figé ne peut pas passer : sa fonction `remise` déplace la branche du dépôt nu vers un commit que ce dépôt n'a pas. Joué sur un dépôt synthétique, il rend 8 cas sur 20 « NON CONFORME ». Une correction d'une ligne donne 20 sur 20. Elle ne touche ni le candidat ni la répétition jouet. Aucun constat bloquant.

Le reste est mineur (UH-02 à UH-10, UH-14) ou pour information (UH-11 à UH-13). Les mineurs portent sur :
- la construction de cas de bancs (UH-02, UH-03) ;
- un verdict au seul code (UH-04) ;
- une forme de ligne de révocation (UH-05) ;
- des contrôles qui ne sont pas rejoués au scellement (UH-06) ;
- l'absence d'artefact pour VH-04 (UH-07) ;
- les journaux des bancs (UH-08) ;
- l'ordre des préalables (UH-09) ;
- des gardes de la récupération sans artefact (UH-10) ;
- le nettoyage du scellement (UH-14).

## Réponses

### 1. VH-01 à VH-14 et restes des sceptiques

Les numéros de ligne renvoient aux fichiers de `chaine-c3/`, sauf mention.

| VH | Corrigé ? | Comment (lignes) | Trou restant |
|---|---|---|---|
| 01 (maj.) | Oui | `sceller` : l. 37-41 (refus de « A_EPINGLER » ; `CODE_RELU`, `REPETITION_JOUET` et leur chemin exigés bien formés), l. 51-55 (26 copies versées et journal suivis : `ls-files` plus arbre suivi propre, l. 45 ⇒ disque = HEAD), l. 60-63 (arbre gelé de HEAD = code relu), l. 64-66 (journal : empreinte, sceau, ligne « commit du code répété »). Plan v3, étape 1 (l. 68-71). Bancs S13 à S19. | Le banc ne passe pas (UH-01). S18 peut dégénérer en S15 (UH-02). Aucune ligne R-… ne consigne encore le traitement de c2 (UH-13). |
| — reste 1 du sceptique (journal lu à HEAD, copies de la chaîne aussi) | Oui | l. 51-55 et l. 45 | — |
| — reste 2 (artefacts : non suivi, autre commit, hors du dossier) | Oui, écrit | S17 (l. 133-135), S18 (l. 137-140), S19 (l. 143-144) | Jamais joués sur la chaîne réelle ; ils le seraient sans succès tant qu'UH-01 n'est pas corrigé. |
| — reste 3 (verser, écrire au plan, consigner) | En partie | Plan v3, étape 1 | Versement au commit des préalables, à venir ; consignation absente (UH-13). |
| — reste 4 (« A_EPINGLER » hors des lignes d'épingles) | Oui | `grep` : seulement les l. 22-27 des contrôles | — |
| 02 (maj.) | Oui | `repetition_jouet` : l. 34-38 (cinq copies faites au début, empreintes au journal), l. 40, 47 et 83 (scripts joués depuis ces copies). Contrôles, l. 145-206 : bloc PYREP, puis comparaison aux copies versées à S, puis empreinte du journal. | — |
| — restes du sceptique : artefacts A31 et A32 | Oui, plus A33 et A34 | `essais_controles`, l. 140-146 | Épingles de A33 et A34 calculées sur un mauvais journal (UH-03). |
| — 64 hexadécimaux, une ligne par script, cinq exactement | Oui | contrôles, l. 174-182 | — |
| — cause du refus dans la ligne KO | Oui | contrôles, l. 186-205 | — |
| — répétition lancée depuis une copie figée | Oui | `ps` : `bash …/rep-figee-7b07300/repetition_jouet_pilote_v1.sh` (chemin absolu, `7d83285b…`) | La chaîne a été figée à 04:49:37, après le départ de la répétition (04:47:19). Seuls trois bancs ont changé dans l'intervalle (04:48:40), sans effet sur la répétition (UH-09). |
| — journaux c2 et c2b non réutilisés | Oui | nouvelle répétition au commit `7b07300` | — |
| 03 (maj.) | Oui (texte et plan) | Candidat 3, l. 196 et 199 : nœud. Plan v3, l. 122-125 : destruction de la première instance, puis lancement en mode premier. Chaîne inchangée et cohérente : lanceur, l. 31-33 (deux instances tolérées en mode premier) ; contrôles en relance, l. 224-227 (-v1 absente : KO) ; banc des contrôles, R4. | Décision et destruction reviennent à Lazar (geste irréversible, R-147). |
| 04 | Oui | `sceller`, l. 15 (`trap 'exit 2' ERR`). Éprouvé : `git fetch` en échec avant le piège donne le code 2 (version c2 : 128 ; `essai-vh04/codes.log`). | Pas d'artefact au banc (UH-07). |
| 05 | Oui | Même lambda (même empreinte de texte, `f3921062…`) dans : `remplir`, l. 271 ; contrôles, l. 100 ; lanceur, l. 108. Bancs : G15b et G15c, A05b et A05c, P17h et P17i. | Sélection des lignes par `startswith("| GO-")` (UH-05) ; verdict de P17h au seul code (UH-04). |
| 06 | Oui | Lignes KO avec message d'assertion (l. 89, 126, 240 des contrôles : `tail -1`) ; `copie_ctl` exige une seule ligne changée (l. 98-103) ; banc borné à 6 600 s (l. 72, 77) ; motifs précis (A01 à A15). | A28 garde `\|` sans groupe (sans effet, déjà relevé par c2) ; A16 et A17 gardent le motif générique « répétition jouet ». |
| 07 (maj.) | En partie | Banc du scellement écrit (20 cas) ; relance au banc des contrôles (R1 à R4) ; deux artefacts de la récupération dans la répétition (vus au journal) ; « partiel » déclaré en résidu (plan, l. 154-155). | Banc du scellement cassé (UH-01). La récupération n'a d'artefact ni pour la garde « copie versée », ni pour 4d à 4f, 6b et 6c (UH-10). |
| 08 | Oui | `recuperation`, l. 15 et 24-25 (`$D.travail`), l. 153 et 157 (fichier des vecteurs attendus dans ce dossier), l. 208 (code 1). Répétition, l. 93 ; contrôles, l. 155-156 (« code 1 » attendu). | — |
| 09 | Oui | `sceller`, l. 34-36 | Motif plus lâche que la regex des contrôles (l. 213), et pas de comparaison « présents = épinglés » au scellement (UH-06). |
| 10 | Oui | contrôles, l. 20 ; récupération, l. 14 | — |
| 11 (info.) | De fait | Plan v3, cité par le générateur (l. 52) et par le candidat 3 (l. 23) | La table du candidat dit « aucune action » (forme, UH-13). Bancs et répétition finale à rejouer au commit des préalables. |
| 12 | Oui | récupération, l. 13, 22 et 35-38 ; répétition, l. 82 (`COPIE_EXIGEE=non`) | Pas d'artefact (UH-10). |
| 13 (info.) | — | — | — |
| 14 (info.) | Sans objet | Aucun Python n'est lancé depuis `docs/` du dépôt de travail. La seule exécution depuis `$V` est celle du banc des contrôles (l. 66), dans un clone jetable où `__pycache__/` est ignoré et jamais versé. `verifier-arbre` du dépôt : « arbre intact » (1,6 s). | — |

### 2. Révocation lue par cellules : même règle partout ? Garde de calcul ? Cas nouveaux isolés ?

**Oui, la règle est identique.** Le texte de la condition est le même, à l'octet près, dans les trois blocs :

```
l.startswith("| GO-") and (lambda c: (len(c) == 8 and c[2].lower() == "révocation" and (g in c[3] or g in c[7]))
    or (len(c) != 8 and "révocation" in l.lower() and g in l))([x.strip() for x in l.strip().strip("|").split("|")])
```

La sonde `sonde-n019/sonde.sh` extrait les blocs tels quels : générateur l. 263-283, contrôles PYGO, lanceur GO19 et N-019. Elle les joue sur les registres de HEAD et sur 12 variantes (`sonde-n019.log`, `8c553eae…`). Résultat : même verdict dans les trois blocs, sauf l'écart voulu (le générateur ne contrôle pas le GO de calcul, cas B11). En détail :
- B00 : les registres de HEAD (GO-2026-10-12-01, R-147) sont acceptés partout, garde comprise.
- B01 à B04 : révocation dans le périmètre, dans la référence, type sans espaces, type « Révocation » : les trois blocs refusent. Les cas R3 et R4 de c2 sont donc corrigés.
- B05 et B12 : ligne mal formée qui cite « révocation » et le GO : refusée.
- B07 : ligne « revendication » qui mentionne une révocation : acceptée.

**La garde de calcul refuse aussi une ligne mal formée, et plus largement.** `lire_go` (l. 49-72) bloque toute la commande de lancement dès qu'une ligne `^\|\s*GO-…\s*\|` présente l'un de ces défauts :
- un nombre de cellules différent de 8 (B05, et aussi B06, une ligne mal formée sans révocation, que les trois blocs acceptent) ;
- des dates illisibles ;
- un identifiant en double.

La première exécution du banc du lanceur (`banc-lanceur-pilote-c3.log`, P17i : « registre GO mal formé ligne 25 : dates illisibles ») le montre. La garde est rejouée sur le registre de S par les contrôles (l. 319) et sur le registre courant par le lanceur (l. 175-176).

Écarts avec la garde :
- elle ne contrôle la révocation que du GO cité par la commande, c'est-à-dire du GO de calcul ;
- elle reconnaît `|GO-…` sans espace (B08, B09), ce que les trois blocs ignorent. Une révocation du GO de N-019 écrite sous cette forme n'est donc vue par personne (UH-05) ;
- elle compare le type en respectant la casse (B04), ce qui rend les blocs plus stricts qu'elle, sans inconvénient.

**Cas nouveaux des bancs :**
- G15b : isolé. Le générateur n'a pas d'autre garde sur cette ligne, et l'ancienne règle (`"| révocation |" in l`) l'aurait acceptée : le cas est discriminant.
- G15c : cas sain, code 0.
- A05b : motif discriminant (« GO-2026-10-12-99 révoqué » ne sort que du bloc N-019), mais la garde de calcul échoue aussi (deux KO).
- A05c : cas sain, « TOUS CONFORMES » attendu.
- P17h : le verdict ne lit que le code 2 (`essais_lanceur`, l. 117). La garde de l'étape 6 rendrait aussi le code 2 : le verdict automatique ne distingue donc pas la garde visée. Le journal c3b montre le bon message (« GO-2026-10-12-99 révoqué dans le registre courant ») ; voir UH-04.
- P17i : création attendue et obtenue (c3b). Sa première version avait été refusée par la garde, puis corrigée.

### 3. Scellement et banc du scellement

**Ordre des gardes, toutes avant l'entropie (l. 80) :**

| Étape | Lignes |
|---|---|
| usage | l. 16-17 |
| épingles du candidat et des rapports | l. 26-30 |
| familles présentes | l. 31-33 |
| paires hors famille | l. 34-36 |
| « A_EPINGLER » | l. 38 |
| code relu et journal épinglés | l. 39-41 |
| fetch, HEAD = origin/main, arbre suivi propre, R12 | l. 42-46 |
| suivi à HEAD | l. 51-55 |
| chaîne (`cmp`) | l. 56-58 |
| candidat relu brut | l. 59 |
| arbre gelé | l. 60-63 |
| journal | l. 64-66 |
| normalisé | l. 67 |
| piège `fin` | l. 78 |

Les gardes du générateur (GO, N-019, rapports) viennent après l'entropie, mais l'entropie est tirée dans `TRAVAIL`, que `fin` retire.

**Code 2 et nettoyage :**
- le piège ERR (l. 15) donne le code 2, éprouvé ;
- `fin` (l. 69-77) retire les fichiers créés non suivis et le dossier de travail. Banc synthétique : « échec avant le commit : fichiers créés retirés », aucun dossier `scellement-*` laissé ;
- trou rare : si `git commit` échoue après `git add` (l. 92-93), les fichiers indexés ne sont pas retirés, alors que le message dit le contraire (UH-14).

**Banc S00 à S19, à la lecture.** Chaque artefact vise sa garde, sans qu'une garde antérieure ne l'arrête :
- S04, S14 et S18 changent l'épingle dans le bloc-notes et dans la copie versée (`epingle_versee`, l. 87-91, commit poussé), sans quoi l'arrêt viendrait de « bloc-notes ≠ copie versée » ;
- S13, S16 et S19 ne touchent que le bloc-notes : leurs gardes (l. 38, 34-36, 40) précèdent le `cmp` ;
- pour S17, le montage est vérifié (l. 134) ; après `reset --hard`, le journal reste sur le disque, non suivi (éprouvé).

**Mais le banc figé échoue.** `remise` (l. 63) fait `git -C "$E/distant.git" update-ref refs/heads/main "$Jx"` vers un commit créé dans le clone après la copie nue. Git refuse : « nonexistent object ». origin/main reste à J, et le scellement s'arrête sur « HEAD ≠ origin/main ».

Preuve. Le banc figé (copie identique, `2697a9ec…`) a été joué sur un dépôt synthétique : vrais modules de scellement, vrais contrôles épinglés par `poser_epingles.py`, vrai candidat 3, générateur remplacé par un bouchon aux mêmes messages. Résultat : 8 « NON CONFORME » sur 20 (S02, S04, S08, S09, S14, S15, S17, S18 ; `banc-scellement-synthetique.log`, `65f38ea6…`). Avec la seule l. 63 remplacée par `git push -q -f "$E/distant.git" "${1:-$J}:refs/heads/main"; git fetch -q origin`, on obtient 20 « CONFORME » sur 20, chaque cas arrêté par le message de sa garde (`…-corrige.log`, `9cce4377…`) ; voir UH-01.

**Faux « CONFORME » possibles :**
- S18 : si la `sed` de l'épingle ne mord pas, le commit du journal passe quand même, et S18 rejoue S15, avec le même message l. 66 (UH-02) ;
- S08 : le motif « ARRÊT du remplissage » est générique. Il reste discriminant seulement parce que S00 passe dans le même montage ;
- S06 : passe même avec le défaut d'UH-01, puisque sa garde est justement celle que le défaut déclenche.

### 4. Contrôles avant dépense et banc des contrôles

**Bloc de la répétition (l. 145-206) :**
- six lignes exigées exactes ;
- quatre passages, chacun une seule fois ;
- deux « TOUS CONFORMES » ;
- les deux KO, chacun dans les cinq lignes qui suivent son étiquette ;
- lignes « script répété » : 64 hexadécimaux, pas de doublon, les cinq noms exactement (l. 174-182) ;
- comparaison aux copies versées à S (l. 190-195), puis empreinte et sceau du journal (l. 198-201) ;
- cause écrite dans la ligne KO (l. 187-205).

Rejoué tel quel sur le vrai journal : conforme (question 5).

**Banc des contrôles :**
- A31 : isolé (seul KO « répétition jouet », copie versée rescellée).
- A32 : isolé, épingle juste (calculée après A31, qui ne touche pas le journal).
- A33 et A34 : épingles calculées sur le journal laissé dans l'arbre de travail par le cas précédent (A32, puis A33), et non sur celui de C1 (l. 143 et 145). La copie jouée porte donc une seconde faute. Le verdict tient seulement parce que le bloc PYREP refuse avant la comparaison d'empreinte (démonstration dans UH-03).
- A05b : deux KO (bloc N-019 et garde de calcul), motif discriminant. A05c : sain.
- A23 : isolé ; un seul KO, « proposition-N-019-v2.md non cité par son empreinte », le fichier rescellé passant les autres contrôles.

**Durée du banc.** Il compte 42 cas `jouer` (A00 à A34 avec A05b, A05c et A20b ; R1 à R4 ; A30) et Z1, qui s'arrête avant tout clonage. Par cas, il faut compter :
- un clonage local mesuré à 16,5 s (780 Mo) ;
- `verifier-arbre`, mesuré à 1,6 s ;
- les blocs Python, quelques secondes.

Soit environ 25 à 40 s par cas, et 20 à 30 minutes au total, très loin des 6 600 s. Le banc v7 de la revalidation faisait environ 20 s par cas. La borne est cohérente : le texte est daté avant `DEBUT_BANC`, et le commit S suit le contrôle de quelques secondes, donc l'écart reste d'au plus 6 700 s environ, sous 7 200 s. Le banc n'a jamais tourné (il exige les épingles).

### 5. Répétition jouet : attentes et journal

À la lecture, les attentes correspondent à ce qu'écrivent les deux scripts :
- `echo "commit du code répété : …"` (l. 33) ;
- `passage $n : code $code ; durée…` (l. 65) ;
- `récupération ($1) : code $c ; <dernière ligne>` (l. 90), la récupération sortant en code 1 en cas d'échec (l. 208) ;
- lignes KO indentées de quatre espaces (l. 91) ; le KO Python s'écrit « KO  » avec deux espaces (`print("KO ", m)`, l. 85-86 de la récupération) ;
- `FIN DE LA RÉPÉTITION` (l. 112).

**Journal fini (05:31), confronté ligne à ligne** (`sonde-journal/confrontation.log`). Copie : `journal-repetition-7b07300-copie.log`, 63 lignes, `531f2d79…`, identique à l'original.
- Bloc PYREP extrait tel quel des contrôles figés, avec `CODE_RELU = 7b073008…` : code 0.
- Les cinq empreintes « script répété » égalent la chaîne figée (deriver `9c7eac29`, remplir `f54382d7`, normaliser `9e15211f`, récupération `0c712381`, répétition `7d83285b`).
- Chaque ligne exigée est présente une fois ; chaque début de passage une fois ; deux « TOUS CONFORMES ».
- Exactement deux KO :
  - l. 54 : « KO  0 calcul/t05-pilote-jouet-a-v1 porte un episodes.json… », deuxième ligne après son étiquette (l. 52) ;
  - l. 59 : « KO  4c fichiers d'un run complet (6) : manquent notations-3B-descriptives.json », première ligne après son étiquette (l. 58).
- Autres valeurs : tests collectés 689 (comme le candidat) ; passages en codes 0, 2, 1 et 0 ; la relance lit b-v1, « runs : » vide.
- La dernière ligne, « code 0 », est ajoutée par l'appel ; elle est sans effet sur les contrôles.
- `CODE_RELU` doit être épinglé à `7b073008585279a06251b08d6b456694320a3c58`, non à `e4be3e1` (même arbre gelé, mais la ligne du journal est comparée à l'identique ; UH-12).

### 6. Plan v3 face aux scripts et au brouillon 10

**Cohérent sur les points demandés :**
- **Relancement** (étape 5) : mêmes causes que le candidat (l. 198-204). Ligne R-… : trois mots et une seule instance, contrôlés par le lanceur (l. 59-67).
- **Arrêts d'avant la poussée initiale** : nœud (candidat, l. 196 et 199 ; plan, l. 122-125). La destruction de la première instance avant un lancement « premier » est cohérente avec la tolérance du lanceur (l. 33) et avec R4.
- **Préséance** (« écrit et poussé ») : la chaîne ne lit que « absent de -v1 » (contrôles, l. 224-227 ; récupération, l. 40-50). « Écrit mais non poussé » relève de la procédure.
- **Étape 1** : décrit fidèlement le scellement, y compris « tout arrêt sort en code 2 », désormais vrai.
- **Étape 4** : fidèle au lanceur.

**À la tête actuelle**, le générateur figé en mode reel, avec le vrai GO-2026-10-12-01 et R-147 et les rapports existants, rend :
- `normalise_sha256 = 83056d15…` ;
- une configuration `6979a00e…` ;
- les écarts bruts au candidat 3 limités à la date, au commit, à la ligne du GO et à la ligne des rapports.

Les blocs « parties masquées » et « GO » des contrôles et la garde de calcul l'acceptent (`generateur-reel/`).

**Pistes fragiles :**
- UH-01 : le banc du scellement ne peut passer.
- UH-06 : ce que les contrôles exigent de S sans que le scellement le relise. Il n'est couvert que par la répétition finale à C ; tout commit après C (journaux des bancs, registres, rapports tardifs) sort de cette couverture.
- UH-08 : journaux des bancs sans empreinte du banc ; banc du générateur c3 joué pendant la réécriture de son script.
- UH-09 : l'ordre « dans cet ordre » des préalables n'est pas exécutable à la lettre.
- Le plan est cité non masqué par le texte. Toute correction du plan impose donc un candidat 4 : il vaut mieux corriger les scripts et consigner le reste.

### 7. Journaux des bancs

**Lanceur (`banc-lanceur-pilote-c3b.log`)** : 50 cas, 50 « CONFORME ».
- Départ à 04:48:47, après la dernière réécriture du banc (04:48:40).
- Chaque arrêt porte le message de sa garde.
- Le premier essai (`…-c3.log`) avait P17i « NON CONFORME » (garde de calcul : dates illisibles dans la ligne du banc) ; corrigé.
- Attente mal posée : verdict au seul code (UH-04).

**Générateur (`banc-generateur-pilote-c3.log`)** : 21 générations, 21 « CONFORME ».
- G00 : normalisé `83056d15…` (le candidat 3), configuration canonique `db3ad3ce…`.
- G10 : normalisé du texte reel égal à celui du candidat.
- Mais le banc a tourné de 04:47:40 à 04:50:32, alors que son script a été réécrit à 04:48:40 (date de la copie figée). Ce journal ne se rattache donc pas à une version unique du banc : à rejouer (UH-08).

## Constats

Classés par gravité décroissante.

### UH-01 — majeur — le banc du scellement ne peut pas passer : `remise` déplace la branche du dépôt nu vers un commit qu'il n'a pas

- **Où** : `essais_scellement_pilote_v1.sh:63`, appelée par S02 (l. 78), S08 (l. 108), S09 (l. 112), S15 (l. 126), S17 (l. 133) et `epingle_versee` (l. 90 : S04, S14, S18).
- **Constat** :
  - `git -C "$E/distant.git" update-ref refs/heads/main "$Jx"` échoue, parce que `$Jx` est un commit créé dans le clone après la copie nue (l. 41) : « nonexistent object » ;
  - `origin/main` reste à J, et le scellement s'arrête alors sur « HEAD ≠ origin/main » ;
  - huit cas sur vingt sortent « NON CONFORME » ;
  - le banc n'a jamais tourné (il exige les épingles) : les gardes nouvelles du scellement (VH-01, VH-09) n'ont donc encore aucun artefact joué (R5).
- **Preuve** :
  - Banc figé (copie identique, `2697a9ec…`) sur un dépôt synthétique : vrais `scellement.py`, `prereg.py`, contrôles épinglés par `poser_epingles.py`, candidat 3 ; générateur remplacé par un bouchon aux mêmes messages (`outils/remplir_bouchon.py`).
  - Sortie : `fatal: update_ref failed for ref 'refs/heads/main': … nonexistent object …`, puis par exemple « S02-sceau-fausse-verifier-arbre : code 2 ; NON CONFORME (motif « ÉCHEC » absent) | HEAD ≠ origin/main ».
  - Bilan : 8 « NON CONFORME » (`banc-scellement-synthetique.log`, `65f38ea6…`).
  - Même banc, l. 63 seule remplacée : 20 sur 20 « CONFORME », chacun avec le message de sa garde (`banc-scellement-synthetique-corrige.log`, `9cce4377…`).
- **Action** :
  - l. 63 : `git push -q -f "$E/distant.git" "${1:-$J}:refs/heads/main"; git fetch -q origin`. Le chemin est explicite, l'adresse de poussée d'origin pouvant être faussée par S03 ;
  - nouvelles empreintes de la chaîne. Ni le candidat ni la répétition jouet ne sont touchés : ce banc n'est pas parmi les cinq scripts répétés ;
  - puis jouer le banc au commit des préalables et verser son journal.

### UH-02 — mineur — banc du scellement : S18 peut dégénérer en S15 ; motifs qui ne distinguent pas les deux moitiés de la garde du journal

- **Où** : `essais_scellement`, l. 87-91 (`epingle_versee`), l. 137-140 (S18), l. 109 (S08) ; `sceller`, l. 64-66.
- **Constat** :
  - `epingle_versee` ne vérifie pas qu'une ligne a changé. Pour S04 et S14, une `sed` sans effet bloque le commit (« montage impossible »). Pour S18, le commit du journal modifié passe quand même : S18 rejouerait alors S15 (empreinte), avec le même message, et resterait « CONFORME » ;
  - S08 vise « ARRÊT du remplissage », c'est-à-dire n'importe quel arrêt du générateur.
- **Preuve** : lecture ; `poser_epingles.py` écrit aujourd'hui l'épingle sans guillemets, donc la `sed` mord (banc synthétique : S18 conforme).
- **Action** :
  - dans `epingle_versee`, exiger `diff | grep -c '^>'` = 1 sur la copie des contrôles, comme `copie_ctl` ;
  - scinder le message des l. 64-66 (« empreinte » et « commit ») et viser chacun ;
  - pour S08, viser le nom du rapport retiré (`$RF`).

### UH-03 — mineur — banc des contrôles : épingles de A33 et A34 calculées sur le journal du cas précédent

- **Où** : `essais_controles`, l. 143 et 145 (`"$LOGJ"` de l'arbre de travail, laissé par `jouer` sur `art-A32`, puis sur `art-A33`).
- **Constat** :
  - la copie jouée porte une épingle qui n'égale pas le journal versé à S : deux fautes au lieu d'une, contrairement au commentaire des l. 138-139 (« seule la garde visée refuse ») ;
  - le verdict tient parce que le bloc PYREP refuse avant la comparaison d'empreinte (l. 174-182 avant l. 198-201) ;
  - A32 est juste : calculé après A31, qui ne touche pas le journal.
- **Preuve** : démonstration sur un journal synthétique.
  - A33 : épingle `a1cf04f2…`, journal versé `ca1d6bec…`.
  - A34 : épingle `06168847…`, journal `2508e4d1…`.
- **Action** : calculer chaque épingle depuis `git show "$C1:$LOGJ"`, ou ramener l'arbre à `C1` avant chaque `copie_ctl`.

### UH-04 — mineur — banc du lanceur : verdict au seul code ; P17h ne distingue pas sa garde de la garde de calcul

- **Où** : `essais_lanceur`, l. 117 ; cas P17h (l. 185-186), et aussi P17b ; lanceur, l. 175-176.
- **Constat** :
  - une ligne mal formée est aussi refusée par la garde de calcul à l'étape 6 (`lire_go`, sonde B05), en code 2 (piège ERR, « arrêt avant la création ») ;
  - si la règle de prudence du bloc GO19 disparaissait, P17h resterait « CONFORME » ;
  - de même, A05b (contrôles) déclenche deux KO, mais son motif reste discriminant.
- **Preuve** : `banc-lanceur-pilote-c3b.log` ; P17h montre « GO-2026-10-12-99 révoqué dans le registre courant », ce qui ne se vérifie qu'à la lecture.
- **Action** : ajouter à `cas()` un motif attendu dans la sortie (grep), au moins pour P12* et P17*.

### UH-05 — mineur — révocation : lignes choisies par `startswith("| GO-")`, et non comme la garde de calcul

- **Où** : `remplir`, l. 271 ; contrôles, l. 100 ; lanceur, l. 108 ; garde, l. 41 (`LIGNE_GO = ^\|\s*(GO-…)\s*\|`).
- **Constat** :
  - une révocation du GO de N-019 écrite `|GO-…|…|révocation|…` (sans espace après la barre) est ignorée par les trois blocs ;
  - la garde la lit, mais ne contrôle que le GO de calcul ;
  - personne ne la refuse.
- **Preuve** : sonde B08 (tout accepté). Pour comparaison, sonde B09 (même forme, GO de calcul) : la garde refuse.
- **Action** : choisir les lignes par `re.match(r"^\|\s*GO-\d{4}-\d{2}-\d{2}-\d{2}\s*\|", l)` dans les trois blocs, ou écrire la forme exigée (« | GO-… | ») dans le plan et la consigner.

### UH-06 — mineur — le scellement ne relit pas trois exigences des contrôles qui ne dépendent que de l'arbre

- **Où** : `sceller`, l. 34-67 ; contrôles, l. 213-215 (rapports présents = attendus, motif `[a-z0-9-]+-v1\.(md|json|tar)`), l. 319 (garde de calcul sur le registre de S), l. 117-119 (sceau du candidat relu ; `brouillons/` hors de `verifier-arbre`).
- **Constat** :
  - entre la répétition finale (au commit C) et le scellement (HEAD = C plus d'autres commits), plusieurs écarts passeraient le scellement puis seraient refusés par les contrôles, sans recours (R12, version 2) :
    - un rapport de la famille versé sans être épinglé ;
    - un nom hors du motif des contrôles, que le motif du scellement (l. 35) laisse passer ;
    - une ligne du registre des GO mal formée (sonde B06 : générateur accepté, garde refusée) ;
    - un sceau du candidat altéré ;
  - VH-09 visait cette classe d'écart.
- **Preuve** : lecture et sonde.
- **Action** : avant l'entropie, ajouter au scellement :
  - la même comparaison `presents`/`attendus` que les contrôles ;
  - la garde de calcul sur `registres/go.md` de HEAD (même entrée JSON que les contrôles, l. 319) ;
  - le sceau du candidat relu.
  
  Sinon, n'ajouter après C que les journaux des bancs.

### UH-07 — mineur — aucun artefact au banc pour VH-04 (arrêt sous `set -e` avant le piège)

- **Où** : `essais_scellement` (aucun cas de dépôt injoignable) ; `sceller`, l. 15.
- **Constat** : le comportement est juste (code 2), mais il n'est éprouvé par aucun banc versé (R5). Le piège n'écrit aucune ligne propre ; seul le message de git apparaît.
- **Preuve** : `essai-vh04/codes.log` : version figée, code 2 ; version c2, code 128 (`git fetch` vers un dépôt absent).
- **Action** :
  - ajouter S20 : `git remote set-url origin "$E/inexistant.git"`, code 2 attendu ;
  - écrire `trap 'echo "arrêt du scellement (ligne $LINENO)"; exit 2' ERR`, comme le lanceur.

### UH-08 — mineur — journaux des bancs sans empreinte du banc ; banc du générateur c3 joué pendant la réécriture de son script

- **Où** : en-têtes des bancs (lanceur : aucune empreinte ; générateur : celle du générateur seulement ; contrôles et scellement : `C` seulement). `banc-generateur-pilote-c3/` : `entropie.txt` à 04:47:40, dernier cas à 04:50:29 ; `essais_generateur_pilote_v1.sh` de la chaîne figée daté de 04:48:40.
- **Constat** :
  - bash lit son script au fil de l'exécution ; le journal c3 du générateur ne se rattache donc pas à une version unique du banc ;
  - en général, rien ne lie un journal de banc versé à la copie du banc versée à S.
- **Preuve** : `ls --time-style=full-iso` des dossiers et de `chaine-c3/`.
- **Action** :
  - rejouer les quatre bancs au commit des préalables, chacun depuis une copie figée (chemin absolu) ;
  - écrire en tête de chaque journal l'empreinte du banc et celles des scripts éprouvés ;
  - verser ces journaux (plan, préalable 4) et les relire contre les copies versées.

### UH-09 — mineur — plan v3 : ordre des préalables non exécutable à la lettre ; « chaîne figée avant la répétition » inexact de deux minutes

- **Où** : plan v3, l. 37 (« dans cet ordre »), l. 46-50 (épingle `REPETITION_JOUET` en 3), l. 51-52 (journal versé en 4), l. 53-60 (répétition en 5, « La chaîne est figée avant cette répétition »).
- **Constat** :
  - l'épingle du journal ne peut précéder la répétition qui le produit ;
  - le script de versement (`verser_chaine_pilote_v1.sh`, hors chaîne) exige d'ailleurs les épingles posées avant de verser ;
  - la répétition est partie à 04:47:19 ; la chaîne a été figée à 04:49:37, et trois bancs ont été réécrits à 04:48:40. C'est sans effet sur la preuve : les cinq scripts répétés égalent la chaîne figée.
- **Preuve** : `ps` (départ de la répétition), dates des fichiers de `chaine-c3/`, `chaine-c3.sha256`.
- **Action** : ne pas faire de plan v4, qui imposerait un candidat 4 (plan cité non masqué). Consigner l'ordre réel dans R-… et dans la passation : répétition, puis épingles, puis versement, puis commit C, puis bancs et répétition finale, puis journaux, puis C'.

### UH-10 — mineur — récupération : gardes sans artefact (R5)

- **Où** : récupération, l. 35-38 (copie versée), l. 123-147 (4d, 4e, 4f), l. 179-184 (6b), l. 185-188 (6c) ; répétition, l. 82 (`COPIE_EXIGEE=non`, `CARTE_EXIGEE=non`).
- **Constat** :
  - seuls « 0 » (préséance) et « 4c » ont un artefact joué (journal, l. 54 et 59) ;
  - « copie versée » et « carte » ne sont jamais jouées ;
  - les comptes (4d à 4f) et 6c ne le sont que sur des cas sains ;
  - seul l'état « partiel » est déclaré en résidu.
- **Preuve** : lecture et journal.
- **Action** : déclarer ces résidus (passation, R-…), ou ajouter un petit banc de la récupération sur des branches synthétiques, sans toucher aux cinq scripts répétés : la répétition n'aurait pas à être rejouée.

### UH-14 — mineur — scellement : un commit en échec après `git add` laisse les fichiers indexés

- **Où** : `sceller`, l. 72 et 92-93.
- **Constat** : `fin()` saute les fichiers que `ls-files` voit (indexés) et affiche pourtant « fichiers créés retirés ». Le scellement suivant s'arrête alors sur « arbre suivi non propre ». C'est rare.
- **Preuve** : lecture.
- **Action** : `git reset -q -- "$P" "$P.sha256" "$CFG" "$CFG.sha256"` dans `fin()`, avant le retrait.

### UH-12 — information — répétition jouet au commit `7b07300` : conforme aux attentes figées ; `CODE_RELU` à épingler

- **Où** : `rep-pilote-v1-7b07300.log` (`531f2d79…`) ; contrôles, l. 152.
- **Constat** :
  - conforme ligne à ligne (question 5) ;
  - `CODE_RELU` doit valoir `7b073008585279a06251b08d6b456694320a3c58` et `REPETITION_JOUET` l'empreinte du journal versé tel quel (`531f2d79…` s'il l'est sans changement).
- **Preuve** : `sonde-journal/confrontation.log`.
- **Action** : épingler ces valeurs ; verser le journal tel quel.

### UH-13 — information — traitement et versement

- **Où** : candidat 3, l. 470 et 478 ; `registres/decisions.md` (aucune ligne R-… sur le traitement de c2) ; `pilote-v1-post-r2/verser_chaine_pilote_v1.sh`, l. 20-21.
- **Constat** :
  - VH-11 est dit « aucune action », alors que le plan v3 en est la suite ;
  - VH-07 dit « banc du scellement versé », alors qu'il ne l'est pas encore (il le sera à C) ;
  - le versement exige les empreintes de la chaîne « relue ». Après la pose des épingles (et la correction d'UH-01), la liste différera de `chaine-c3.sha256` par les contrôles (six lignes d'épingles) et par le banc du scellement (une ligne).
- **Action** :
  - consigner le traitement de c2 et de c3 (R-…) ;
  - joindre à la passation le différentiel entre `chaine-c3/` et la chaîne versée : lignes d'épingles et ligne d'UH-01 seulement.

### UH-11 — information — registres changés pendant la vérification ; tête actuelle scellable

- **Où** : commits `cdf0d4f` et `d4475b6`.
- **Constat** :
  - le GO de Lazar (GO-2026-10-12-01, type « revendication », 8 cellules, référence R-147), la colonne d'état exacte de N-019 et la ligne R-147 (qui cite le GO) passent les trois blocs et la garde (sonde B00) ;
  - le générateur figé en mode reel à `d4475b6` reproduit le candidat 3 (normalisé `83056d15…`, configuration `6979a00e…`, tests 689) ;
  - les blocs « parties masquées » et « GO » des contrôles et la garde de calcul l'acceptent ;
  - R-147 élargit la délégation, mais laisse à Lazar les gestes irréversibles : la destruction d'une première instance (VH-03, plan, l. 122-125) lui revient toujours.
- **Preuve** : `sonde-n019/sonde-n019.log`, `generateur-reel/sortie.json` (`4dbf604c…`).
- **Action** : aucune.

## Fichiers de travail

Sous `verification-c3/chaine/` :
- `sonde-n019/` : blocs extraits, enveloppes, `sonde.sh`, `sonde-n019.log` ;
- `sonde-registre/` : copie de la garde, registres de HEAD ;
- `sonde-journal/` : bloc PYREP extrait, `confronter.sh`, copie du journal, `confrontation.log` ;
- `banc-scellement-synthetique/` : dépôt synthétique `src-repo`, `outils/` (copie du banc figé, correction d'UH-01, bouchon du générateur), journaux `…synthetique.log` et `…-corrige.log`, dossiers `E/` et `E2/` ;
- `essai-vh04/` : copies du scellement (c3 et c2) et `codes.log` ;
- `generateur-reel/` : copie du générateur et du normaliseur, sortie en mode reel à `d4475b6`, blocs des contrôles rejoués. Fichier de travail, à ne pas employer ;
- `etat-clone-avant-suppression.txt`.

Le clone est supprimé.
