#!/usr/bin/env bash
# Confronte le journal de la répétition jouet aux attentes des contrôles avant dépense figés (bloc PYREP extrait tel quel)
# et aux copies de la chaîne figée (empreintes des cinq scripts répétés). Lecture seule.
set -uo pipefail
J=$1; CODE=$2; C3=$3; B=$(cd "$(dirname "$0")" && pwd); PY=/home/user/controle-ia/.venv/bin/python
"$PY" -I -B "$B/bloc-repetition.py" "$CODE" "$J" > "$B/sortie-bloc.txt" 2>&1; c=$?
echo "bloc PYREP des contrôles (figé) sur le journal : code $c ; $(tail -1 "$B/sortie-bloc.txt")"
grep -E '^[a-z_]+_pilote_v1\.(py|sh) [0-9a-f]{64}$' "$B/sortie-bloc.txt" | while read -r s e; do
    f=$(sha256sum "$C3/$s" | cut -d' ' -f1); [ "$f" = "$e" ] && echo "  $s : journal = chaîne figée ($e)" || echo "  $s : journal $e ≠ chaîne figée $f"
done
echo "lignes exigées, une par une :"
for l in "commit du code répété : $CODE" "FIN DE LA RÉPÉTITION" \
         "récupération (passage-1-premier) : code 0 ; RÉCUPÉRATION : TOUS CONFORMES" \
         "récupération (passage-4-relance) : code 0 ; RÉCUPÉRATION : TOUS CONFORMES" \
         "récupération (artefact-premier-avec-episodes) : code 1 ; RÉCUPÉRATION : 1 CONTRÔLE(S) EN ÉCHEC" \
         "récupération (artefact-notations-manquantes) : code 1 ; RÉCUPÉRATION : 1 CONTRÔLE(S) EN ÉCHEC"; do
    n=$(grep -cxF -- "$l" "$J"); echo "  [$n] $l"
done
for p in "passage 1-sain : code 0 " "passage 2-artefact-branche-presente : code 2 " "passage 3-premier-manque : code 1 " "passage 4-relance : code 0 "; do
    echo "  [$(grep -c "^$p" "$J")] début « $p»"
done
echo "  [$(grep -c 'RÉCUPÉRATION : TOUS CONFORMES' "$J")] lignes « TOUS CONFORMES » (2 attendues)"
echo "lignes KO du journal :"; grep -n '^    KO' "$J" | cut -c1-160
