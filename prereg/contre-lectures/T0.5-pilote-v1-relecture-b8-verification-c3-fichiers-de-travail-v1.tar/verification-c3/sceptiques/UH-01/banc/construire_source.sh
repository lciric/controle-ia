#!/usr/bin/env bash
# Dépôt source synthétique pour jouer le banc du scellement figé (sceptique UH-01). Lecture seule du dépôt réel
# (git show au commit 7b07300) et de la chaîne figée ; écrit seulement sous $1 (neuf).
set -euo pipefail
S=$1
[ -e "$S" ] && { echo "$S existe déjà"; exit 2; }
REEL=/home/user/controle-ia-travail
CH=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/chaine-c3
ICI=$(cd "$(dirname "$0")" && pwd)
V=docs/procedures/pilote-T0.5-v1
mkdir -p "$S" && cd "$S" && git init -q -b main . && git config user.email essai@invalid && git config user.name essai \
    && git config commit.gpgsign false
printf '__pycache__/\n' > .gitignore
echo "# dépôt synthétique" > README.md
mkdir -p src/controle_ia/harnais src/controle_ia/environnements registres donnees/t05-pilote-v1 brouillons prereg/contre-lectures "$V"
for f in __init__.py gardes.py scellement.py prereg.py; do git -C "$REEL" show "7b07300:src/controle_ia/$f" > "src/controle_ia/$f"; done
: > src/controle_ia/harnais/__init__.py
cat > src/controle_ia/harnais/validation_reelle.py <<'PY'
CHEMINS_GELES = (".", ":(exclude)prereg", ":(exclude)brouillons", ":(exclude)registres", ":(exclude)docs",
                 ":(exclude)diag", ":(exclude)runs", ":(exclude)donnees", ":(exclude)livrables", ":(exclude)papiers",
                 ":(exclude)traces", ":(exclude)CLAUDE.md")
PY
echo "VERSION = 0" > src/controle_ia/environnements/lancer_pilote_a.py
printf '| Id | Date | Décision | État |\n|---|---|---|---|\n| N-019 | 2026-10-12 | pilote réduit (essai) | en attente du GO de Lazar |\n' > registres/decisions.md
printf '| GO | accordé | type | périmètre | plafond | échéance | par | référence |\n|---|---|---|---|---|---|---|---|\n' > registres/go.md
echo '{"taches": []}' > donnees/t05-pilote-v1/taches-pilote-60-v1.json
git add -A && git commit -qm "A0 : code initial"
echo "VERSION = 1" > src/controle_ia/environnements/lancer_pilote_a.py
git commit -qam "A1 : code relu" && A1=$(git rev-parse HEAD)
cp "$REEL/brouillons/T0.5-pilote-8B-v1-candidat3.md" brouillons/
RELU=brouillons/T0.5-pilote-8B-v1-candidat3.md
for n in T0.5-pilote-v1-etat-des-lieux-essai-v1.md T0.5-pilote-v1-relecture-b8-essai-v1.md; do
    echo "rapport factice $n" > "prereg/contre-lectures/$n"; (cd prereg/contre-lectures && sha256sum "$n" > "$n.sha256")
done
printf 'commit du code répété : %s\nscript répété : factice\n' "$A1" > "$V/repetition-jouet-pilote-v1.log"
(cd "$V" && sha256sum repetition-jouet-pilote-v1.log > repetition-jouet-pilote-v1.log.sha256)
for s in deriver_taches_pilote_v1.py normaliser_pilote_v1.py controles_avant_depense_pilote_v1.sh lancer_pilote_v1.sh \
         sceller_pilote_v1.sh recuperation_pilote_v1.sh repetition_jouet_pilote_v1.sh repetition_finale_pilote_v1.sh \
         essais_lanceur_pilote_v1.sh essais_controles_pilote_v1.sh essais_generateur_pilote_v1.sh essais_scellement_pilote_v1.sh; do
    cp "$CH/$s" "$V/$s"
done
cp "$ICI/bouchon_remplir.py" "$V/remplir_pilote_v1.py"
sha() { sha256sum "$1" | cut -d' ' -f1; }
R1=$(sha prereg/contre-lectures/T0.5-pilote-v1-etat-des-lieux-essai-v1.md); R2=$(sha prereg/contre-lectures/T0.5-pilote-v1-relecture-b8-essai-v1.md)
NORM=$(/home/user/controle-ia/.venv/bin/python -I "$CH/normaliser_pilote_v1.py" "$RELU")
sed -i -e "s|^CANDIDAT_RELU=A_EPINGLER|CANDIDAT_RELU=$(sha "$RELU")|" \
       -e "s|^CANDIDAT_RELU_CHEMIN=A_EPINGLER|CANDIDAT_RELU_CHEMIN=$RELU|" \
       -e "s|^CANDIDAT_NORMALISE=A_EPINGLER|CANDIDAT_NORMALISE=$NORM|" \
       -e "s|^RAPPORTS_ATTENDUS=\"A_EPINGLER\"|RAPPORTS_ATTENDUS=\"T0.5-pilote-v1-etat-des-lieux-essai-v1.md=$R1 T0.5-pilote-v1-relecture-b8-essai-v1.md=$R2\"|" \
       -e "s|^CODE_RELU=A_EPINGLER|CODE_RELU=$A1|" \
       -e "s|^REPETITION_JOUET=A_EPINGLER|REPETITION_JOUET=$(sha "$V/repetition-jouet-pilote-v1.log")|" \
       "$V/controles_avant_depense_pilote_v1.sh"
! grep -q A_EPINGLER "$V/controles_avant_depense_pilote_v1.sh" || { echo "épingle restée"; exit 2; }
(cd "$V" && for s in *.sh *.py; do sha256sum "$s" > "$s.sha256"; done)
git add -A && git commit -qm "C : préalables synthétiques (épingles posées)"
echo "A1 $A1"
echo "C $(git rev-parse HEAD)"
PYTHONPATH=src /home/user/controle-ia/.venv/bin/python -m controle_ia.scellement verifier-arbre . | tail -1
