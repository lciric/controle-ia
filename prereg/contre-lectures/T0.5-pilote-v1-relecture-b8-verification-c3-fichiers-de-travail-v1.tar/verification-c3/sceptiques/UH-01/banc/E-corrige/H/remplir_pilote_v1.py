"""Bouchon du générateur (essai du sceptique UH-01) : mêmes arguments et mêmes messages d'arrêt que
remplir_pilote_v1.py pour les gardes que le banc du scellement vise (GO, colonne N-019, rapports épinglés) ;
en cas sain, recopie le candidat relu (normalisé égal) et écrit une configuration factice."""
import argparse
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path


def arret(msg):
    sys.exit(f"ARRÊT du remplissage du pilote : {msg}")


p = argparse.ArgumentParser()
for x in ("depot", "commit", "mode", "date", "entropie", "sortie_p", "sortie_c"):
    p.add_argument(x)
p.add_argument("--taches", required=True)
p.add_argument("--rapports-etat", required=True)
p.add_argument("--rapports-relecture", required=True)
p.add_argument("--candidat-relu", default=None)
p.add_argument("--go", default=None)
p.add_argument("--registre", default=None)
a = p.parse_args()
D = Path(a.depot)


def git(*args):
    r = subprocess.run(["git", "-C", str(D), *args], capture_output=True)
    if r.returncode != 0:
        arret(f"git {' '.join(args)} : {r.stderr.decode(errors='replace').strip()}")
    return r.stdout


def au_commit(c):
    return git("show", f"{a.commit}:{c}")


for f in (a.sortie_p, a.sortie_c):
    if Path(f).exists():
        arret(f"{f} existe déjà (R12)")
if git("rev-parse", "HEAD").decode().strip() != a.commit:
    arret("le commit cité n'est pas HEAD")
for texte in (a.rapports_etat, a.rapports_relecture):
    for x in texte.split(","):
        nom, _, sha = x.strip().partition("=")
        if not nom or not re.fullmatch(r"[0-9a-f]{64}", sha):
            arret(f"paire de rapport mal formée : {x!r}")
        if hashlib.sha256(au_commit(f"prereg/contre-lectures/{nom}")).hexdigest() != sha:
            arret(f"{nom} : empreinte ≠ épingle")
lignes_go = au_commit("registres/go.md").decode("utf-8").split("\n")
cel = [[c.strip() for c in x.strip().strip("|").split("|")] for x in lignes_go if x.startswith(f"| {a.go} |")]
if len(cel) != 1 or len(cel[0]) != 8:
    arret(f"{a.go} : absent de registres/go.md, en double ou mal formé")
lignes_dec = au_commit("registres/decisions.md").decode("utf-8").split("\n")
n19 = [x for x in lignes_dec if x.startswith("| N-019 |")]
etat19 = n19[0].rsplit("|", 2)[-2].strip() if len(n19) == 1 else ""
if not re.fullmatch(rf"tranché \(a\) par Lazar : {re.escape(a.go)} \({re.escape(a.registre)}\)", etat19):
    arret(f"N-019 : colonne d'état ≠ « tranché (a) par Lazar : {a.go} ({a.registre}) »")
Path(a.sortie_p).write_text(Path(a.candidat_relu).read_text(encoding="utf-8"), encoding="utf-8")
Path(a.sortie_c).write_text(json.dumps({"bouchon": True, "commit": a.commit}) + "\n", encoding="utf-8")
