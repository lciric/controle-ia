import json, sys
tol = set(sys.argv[1].split())
autres, vues = [], []
for i in json.load(sys.stdin):
    ident, etat, cur = str(i.get("id")), i.get("actual_status"), i.get("cur_state")
    if ident in tol and etat in ("exited", "stopped") and cur == "stopped":
        vues.append(f"{ident} ({etat}, {cur})")
    else:
        autres.append(f"{ident} ({etat}, {cur})")
print("instances arrêtées tolérées :", ", ".join(vues) or "aucune")
if autres:
    print("autres instances sur le compte :", ", ".join(autres)); sys.exit(1)
