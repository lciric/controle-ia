"""Mesure des écarts de production du jouet (PETITE) pour quelques entropies : écart max, q99 max, jetons non nuls
dans la zone générée par couche, audit de symétrie. Lecture seule du code (copie au commit 6ec7434)."""
import json, subprocess, sys, tempfile
from pathlib import Path
racine_code = Path(sys.argv[1])
sys.path[:0] = [str(racine_code / "src"), str(racine_code / "tests")]
import torch
from controle_ia.harnais import validation_reelle as V
from test_validation_reelle import PETITE
print("capacité ATen :", torch.backends.cpu.get_cpu_capability())
for entropie in [int(x) for x in sys.argv[2:]]:
    d = Path(tempfile.mkdtemp(dir=sys.argv[1] + "/.."))
    for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"],
              ["config", "commit.gpgsign", "false"]):
        subprocess.run(["git", "-C", str(d), *a], check=True)
    (d / "README").write_text("x\n"); subprocess.run(["git", "-C", str(d), "add", "-A"], check=True)
    subprocess.run(["git", "-C", str(d), "commit", "-qm", "init"], check=True)
    s = V.executer(d, "20261004-160000-repetition-jouet", entropie=entropie, config=PETITE, verifier_import=False)
    r = json.loads((d / s["resume"]).read_text())["resultat"]
    for ph in ("logique", "chemin", "production"):
        eq = r[ph]["equivalence"]
        print(f"entropie {entropie} {ph:10s} ecart_max={eq['ecart_max']!r} q99_max={eq['ecart_q99_max']!r} "
              f"zeros_generee={ {c: z['generee'] for c, z in eq['zeros'].items()} }")
    print(f"entropie {entropie} audit : {s['lecture']['audit_symetrie']}")
