#!/usr/bin/env bash
# Banc du vérificateur (angle chaîne) : artefacts qui devraient échouer aux contrôles v5 et que je soupçonne de passer.
# Tout se passe sous verification-v2-essais/ ; rien n'est écrit dans le dépôt de travail ni dans revalidation-v2/.
set -uo pipefail
B=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad
E=$B/verification-v2-essais
H=$B/revalidation-v2
PY=$B/scellement-revalidation/venv-gpu-neuf/bin/python
RELU=$H/candidat-2/T0.5-revalidation-equivalence-pilote-v2.md
VERIFIE=$H/candidat-3/T0.5-revalidation-equivalence-pilote-v2.md
P=prereg/T0.5-revalidation-equivalence-pilote-v2.md
CL=prereg/contre-lectures; GO=GO-2026-10-11-07
VERIF=T0.5-revalidation-v2-verification-corrections-v1.md
RAPPORTS="T0.5-revalidation-v2-relecture-texte-v1.md T0.5-revalidation-v2-relecture-code-v1.md T0.5-revalidation-v2-relecture-chaine-v1.md T0.5-revalidation-v2-relecture-contre-verifications-v1.md T0.5-revalidation-v2-relecture-resultats-v1.json T0.5-revalidation-v2-relecture-fichiers-de-travail-v1.tar $VERIF"
cd "$E/source" || exit 2
python3 - <<EOF || exit 2
from pathlib import Path
d = Path("registres/decisions.md"); t = d.read_text(encoding="utf-8")
l = [x for x in t.split("\n") if x.startswith("| N-018 |")][0]
t = t.replace(l, l.rsplit("| en attente |", 1)[0] + "| tranché : option (a), $GO (essai du vérificateur) |")
d.write_text(t, encoding="utf-8")
g = Path("registres/go.md"); g.write_text(g.read_text(encoding="utf-8").rstrip("\n") + "\n| $GO | 2026-10-11 | revendication | N-018, option (a) (essai du vérificateur) | — | 2026-10-11 | Lazar | essai |\n", encoding="utf-8")
Path("$CL/$VERIF").write_text("# rapport de vérification fictif (essai du vérificateur)\n", encoding="utf-8")
EOF
PYTHONPATH=src "$PY" -m controle_ia.scellement sceller "$CL/$VERIF" > /dev/null || exit 2
git add -A registres "$CL/$VERIF" "$CL/$VERIF.sha256" && git commit -qm "essai : préalables" || exit 2
C1=$(git rev-parse HEAD); echo "C1=$C1"
generer() {   # $1 sortie ; $2.. options supplémentaires (remplacent le GO ou le registre)
    local s=$1; shift
    local args=(); for n in $RAPPORTS; do args+=(--rapport "$CL/$n"); done
    "$PY" -I "$H/remplir_revalidation_v2_r2.py" . 6ec7434119781a3abebac789174101b9ed6ae087 reel "$(date -u '+%Y-%m-%d %H:%M UTC')" \
        "$s" --candidat-relu "$RELU" --candidat-verifie "$VERIFIE" --go "${GOX:-$GO}" --registre "${REGX:-R-135}" "${args[@]}"
}
generer "$E/v2-saine.md" || exit 2
git clone -q --bare . "$E/distant.git" || exit 2
NV=657df75a8ca5f2a741b68ae3a87fd2323e13c6de0b905b978b5c758b87be0df8
sed -e "s|^DEPOT=.*|DEPOT=$E/distant.git|" -e "s|^CANDIDAT_VERIFIE=.*|CANDIDAT_VERIFIE=$(sha256sum "$VERIFIE" | cut -d' ' -f1)|" \
    -e "s|^CANDIDAT_NORMALISE=.*|CANDIDAT_NORMALISE=$NV|" -e "s|^RAPPORTS_ATTENDUS=.*|RAPPORTS_ATTENDUS=\"$RAPPORTS\"|" \
    "$H/controles_avant_depense_v5.sh" > "$E/controles-essai.sh"
diff "$H/controles_avant_depense_v5.sh" "$E/controles-essai.sh" | grep -c '^>' | sed 's/^/lignes changées : /'
sceller_v2() { PYTHONPATH=src "$PY" -c "from controle_ia.prereg import sceller_prereg; sceller_prereg('$P')" >/dev/null; }
resceller() { local f; for f in "$@"; do (cd "$(dirname "$f")" && sha256sum "$(basename "$f")" > "$(basename "$f").sha256"); done; }
# $1 nom ; $2 modification avant la génération (commit à part) ; $3 modification de la v2 après la génération ; $4 après la poussée
jouer() {
    local nom=$1 avant=$2 v2=$3 apres=${4:-}
    git checkout -q -B "x-$nom" "$C1" || { echo "$nom : montage"; return; }
    if [ "$avant" != ":" ]; then
        eval "$avant"; git add -A . >/dev/null 2>&1; git commit -qm "essai : $nom (avant)" || { echo "$nom : commit avant"; return; }
        rm -f "$E/v2-$nom.md"; generer "$E/v2-$nom.md" >/dev/null || { echo "$nom : génération refusée"; return; }
        cp "$E/v2-$nom.md" "$P"
    else
        cp "$E/v2-saine.md" "$P"
    fi
    eval "$v2"
    sceller_v2 || { echo "$nom : sceller_prereg refuse"; return; }
    git add -A . >/dev/null 2>&1; git commit -qm "essai : $nom" || { echo "$nom : commit"; return; }
    local s; s=$(git rev-parse HEAD)
    git push -q "$E/distant.git" "x-$nom" >/dev/null 2>&1
    eval "$apres"
    bash "$E/controles-essai.sh" "$s" "$E/clone-$nom" > "$E/sortie-$nom.txt" 2>&1; local c=$?
    rm -rf "$E/clone-$nom"
    echo "$nom : code $c ; $(grep -c '^KO' "$E/sortie-$nom.txt") KO ; $(tail -1 "$E/sortie-$nom.txt")"
    grep '^KO' "$E/sortie-$nom.txt" | sed 's/^/    /' | cut -c1-200
}
for x in ${ESSAIS:-X0}; do
case $x in
X0) jouer X0-sain ":" ":" ;;
X1) jouer X1-rapport-remplace-avant-scellement \
      "sed -i '0,/^### L-01/s/^### L-01.*/### L-01 (mineure) — réécrit après coup/' $CL/T0.5-revalidation-v2-relecture-chaine-v1.md && resceller $CL/T0.5-revalidation-v2-relecture-chaine-v1.md" ":" ;;
X2) jouer X2-pieces-trompeuses ":" \
      "sed -i -E 's/ ; corrections de la relecture : R-135 ;/ ; NOTE : seuil d’équivalence relevé et lecture R3 abandonnée pour cette version ; Commit du code d’analyse : \`3b8c049bec316272b4f65a0e51ef54a2c1e83217\` ; Tests attendus : \`669\` ; corrections de la relecture : R-135 ;/' $P" ;;
X3) jouer X3-go-revocation-par-session \
      "printf '| GO-2026-10-11-08 | 2026-10-11 | révocation | révoque $GO (N-018) | — | 2026-10-11 | session | essai |\n' >> registres/go.md" \
      "sed -i -E 's/décision de Lazar : $GO \(R-135\)\.$/décision de Lazar : GO-2026-10-11-08 (R-135)./' $P" ;;
X4) jouer X4-registre-inexistant ":" "sed -i -E 's/décision de Lazar : $GO \(R-135\)\.$/décision de Lazar : $GO (R-999)./' $P" ;;
X5) jouer X5-n018-refuse "sed -i -E 's/^(\| N-018 \|.*)\| tranché : [^|]*\|$/\1| refusé : option (b) retenue, relancer la v1 |/' registres/decisions.md" ":" ;;
X6) jouer X6-dates-absurdes ":" "sed -i -E '3s/2026-10-1[0-9] [0-9]{2}:[0-9]{2}/2019-01-01 00:00/; 8s/2026-10-1[0-9] [0-9]{2}:[0-9]{2}/2031-12-31 23:59/' $P" ;;
X7) jouer X7-pieces-doublees ":" "sed -i -E 's/candidat relu \`/candidat relu \`0000000000000000000000000000000000000000000000000000000000000000\` ; candidat relu \`/' $P" ;;
esac
done
echo "FIN DU BANC"
