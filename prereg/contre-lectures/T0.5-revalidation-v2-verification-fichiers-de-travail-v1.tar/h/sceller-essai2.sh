#!/usr/bin/env bash
# Scellement de la version 2 du préenregistrement de la revalidation (T0.5), après le GO de Lazar sur N-018 (plan de
# lancement v5, étape 1). Prérequis, déjà committés et poussés : la ligne du GO dans registres/go.md, N-018 tranché et
# la ligne R-… qui consigne le GO dans registres/decisions.md, R-135, les rapports de relecture et de vérification
# scellés. Le texte est régénéré par remplir_revalidation_v2_r2.py en mode reel à l'heure du scellement ; son empreinte
# normalisée doit égaler celle du candidat vérifié, épinglée dans controles_avant_depense_v5.sh. Un seul commit S
# (préenregistrement et sceau), poussé vers le dépôt de travail. Aucune instance n'est créée ici.
# Usage : sceller_revalidation_v3.sh GO_ID REGISTRE_DU_GO
set -euo pipefail
GO=${1:?GO de Lazar sur N-018}; REG=${2:?ligne R-… qui consigne le GO}
H=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/verification-v2-essais/h
DEPOT=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/verification-v2-essais/scel2
PY=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/scellement-revalidation/venv-gpu-neuf/bin/python
CODE=6ec7434119781a3abebac789174101b9ed6ae087
P=prereg/T0.5-revalidation-equivalence-pilote-v2.md
RELU=$H/candidat-2/T0.5-revalidation-equivalence-pilote-v2.md
VERIFIE=$(sed -n 's/^CANDIDAT_VERIFIE_FICHIER=//p' "$H/epingles.txt")
NORMALISE=$(sed -n 's/^CANDIDAT_NORMALISE=\([0-9a-f]\{64\}\).*/\1/p' "$H/controles_avant_depense_v5.sh")
RAPPORTS=$(sed -n 's/^RAPPORTS_ATTENDUS="\(.*\)".*/\1/p' "$H/controles_avant_depense_v5.sh")
[[ "$NORMALISE" =~ ^[0-9a-f]{64}$ ]] || { echo "empreinte normalisée non épinglée dans les contrôles v5"; exit 2; }
[ "$(sha256sum "$VERIFIE" | cut -d' ' -f1)" = "$(sed -n 's/^CANDIDAT_VERIFIE=\([0-9a-f]\{64\}\).*/\1/p' "$H/controles_avant_depense_v5.sh")" ] \
    || { echo "candidat vérifié ≠ empreinte brute épinglée"; exit 2; }
cd "$DEPOT"
git fetch -q origin main
[ "$(git rev-parse HEAD)" = "$(git rev-parse origin/main)" ] || { echo "HEAD ≠ origin/main : pousser d'abord les préalables"; exit 2; }
[ -z "$(git status --porcelain --untracked-files=no)" ] || { echo "arbre suivi non propre"; exit 2; }
[ -e "$P" ] && { echo "$P existe déjà (R12)"; exit 2; }
args=(); for n in $RAPPORTS; do args+=(--rapport "prereg/contre-lectures/$n"); done
SORTIE=$(mktemp -d "$H/scellement-XXXX")/T0.5-revalidation-equivalence-pilote-v2.md
DATE=$(date -u '+%Y-%m-%d %H:%M UTC')
"$PY" -I "$H/remplir_revalidation_v2_r2.py" . "$CODE" reel "$DATE" "$SORTIE" --candidat-relu "$RELU" \
    --candidat-verifie "$VERIFIE" --go "$GO" --registre "$REG" "${args[@]}"
n=$(sed -E '3s/[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}/AAAA-MM-JJ HH:MM/; 8s/[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}/AAAA-MM-JJ HH:MM/' "$SORTIE" \
    | sed -E 's/^(- Version 2 \(N-018\) : .*) Pièces : .*$/\1 Pièces : (remplies au scellement)./' | sha256sum | cut -d' ' -f1)
[ "$n" = "$NORMALISE" ] || { echo "v2 régénérée ≠ candidat vérifié ($n ≠ $NORMALISE)"; exit 2; }
cp "$SORTIE" "$P"
PYTHONPATH=src "$PY" -c "from controle_ia.prereg import sceller_prereg; sceller_prereg('$P')"
PYTHONPATH=src "$PY" -m controle_ia.scellement verifier-arbre . | tail -1
SHA=$(cut -d' ' -f1 "$P.sha256")
git add "$P" "$P.sha256"
git commit -q -F - <<EOF
T0.5 : revalidation courte de l'équivalence, préenregistrement v2 scellé (N-018, $GO)

Préenregistrement $SHA ; commit du code cité $CODE (seul le test M-1 change depuis la v1 dans l'arbre gelé) ;
670 tests attendus ; PREREG et BRANCHE passés à l'instance (calcul/t05-revalidation-reel-v2). Empreinte normalisée
égale au candidat vérifié ($NORMALISE).

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01W5L3BRJg9Vso4Gru9tWAzM
EOF
git rev-parse HEAD
timeout 600 git push -q origin HEAD:main
git ls-remote origin refs/heads/main
