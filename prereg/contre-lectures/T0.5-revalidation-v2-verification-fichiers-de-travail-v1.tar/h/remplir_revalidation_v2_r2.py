"""Écrit la version 2 du préenregistrement de la revalidation (T0.5) depuis la v1 scellée — révision 2 du générateur,
après la relecture R2 du candidat 2 (rapports `prereg/contre-lectures/T0.5-revalidation-v2-relecture-*-v1.*`, R-135).

Ne change de la v1 que : le titre ; l'en-tête (motif, ce qui change) ; l'auteur et la date ; le commit du code cité ;
l'origine de l'entropie (« au scellement de la v1 ») ; la ligne « Lancement » (PREREG, BRANCHE) ; la durée de la suite
au commit cité (« Calcul ») ; une ligne de transparence ; une entrée d'historique, placée en dernier dans la section
« Contre-lecture » (T-6), dont la fin « Pièces : … » est la seule partie variable entre le candidat relu et la version
scellée (normalisée par les contrôles avant dépense, avec la première date des lignes 3 et 8).

Arrêts (R5) : v1 intacte (sceau) ; arbre suivi propre ; 3b8c049 ancêtre du commit cité, lui-même ancêtre de HEAD ;
dans l'arbre gelé (`CHEMINS_GELES`), seul `tests/test_validation_reelle.py` change entre 3b8c049 et le commit cité, et
rien entre le commit cité et HEAD ; empreintes des deux scripts de l'instance égales à celles de la v1 ; sortie de la
suite versée, suivie à HEAD, lisible, au nombre de tests de la v1 (et recompté à HEAD en mode reel) ; en mode reel :
date à moins d'une heure de l'horloge, candidats relu et vérifié fournis, rapports sous `prereg/contre-lectures/`,
au nom attendu, suivis à HEAD avec un sceau conforme, GO cité présent dans `registres/go.md` et nœud N-018 qui n'est
plus « en attente » ; sortie en mode exclusif (R12) ; ni forme longue ni forme courte de l'ancien commit hors des
lignes permises.

Usage : python -I remplir_revalidation_v2_r2.py DEPOT COMMIT MODE DATE_UTC SORTIE
        [--candidat-relu F --candidat-verifie F --go GO-… --registre R-… --rapport F …]
MODE : reel (version à sceller) ou essai (candidat à relire : la fin « Pièces » vaut « (remplies au scellement) »)."""
import argparse
import hashlib
import re
import subprocess
import sys
from pathlib import Path


def arret(msg: str) -> None:
    sys.exit(f"ARRÊT du remplissage de la v2 : {msg}")


ap = argparse.ArgumentParser()
for nom in ("depot", "commit", "mode", "date", "sortie"):
    ap.add_argument(nom)
ap.add_argument("--candidat-relu"); ap.add_argument("--candidat-verifie")
ap.add_argument("--go"); ap.add_argument("--registre"); ap.add_argument("--rapport", action="append", default=[])
a = ap.parse_args()
D = Path(a.depot)
V1 = "prereg/T0.5-revalidation-equivalence-pilote-v1.md"
V2 = "prereg/T0.5-revalidation-equivalence-pilote-v2.md"
BRANCHE = "calcul/t05-revalidation-reel-v2"
ANCIEN = "3b8c049bec316272b4f65a0e51ef54a2c1e83217"
TEST_CORRIGE = "tests/test_validation_reelle.py"
SUITE = "docs/procedures/revalidation-T0.5-v2/suite-6ec7434-environnement-neuf-v1.txt"
ENVIRONNEMENT = "docs/procedures/revalidation-T0.5-v2/environnement-suite-6ec7434-v1.txt"
PROCESSEUR = "traces/t05-instance-55292763-processeur-20261011/processeur.json"
TESTS_INSTANCE = "traces/t05-20261010-223801-JOkW/tests.txt"
JOURNAL_INSTANCE = "traces/t05-instance-55292763-20261010-224000/journal-instance.txt"
MOTIF_RAPPORT = re.compile(r"prereg/contre-lectures/T0\.5-revalidation-v2-(relecture|verification)-[a-z-]+-v1\.(md|json|tar)")
if not re.fullmatch(r"[0-9a-f]{40}", a.commit) or a.mode not in ("reel", "essai"):
    arret("commit (40 hexadécimaux) ou mode (reel, essai) invalide")
if Path(a.sortie).exists():
    arret(f"{a.sortie} existe déjà (R12)")
if not re.fullmatch(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2} UTC", a.date):
    arret("date attendue au format « AAAA-MM-JJ HH:MM UTC »")
if a.mode == "reel":
    import datetime
    ecart = abs((datetime.datetime.strptime(a.date, "%Y-%m-%d %H:%M UTC").replace(tzinfo=datetime.timezone.utc)
                 - datetime.datetime.now(datetime.timezone.utc)).total_seconds())
    if ecart > 3600:
        arret(f"date à {ecart:.0f} s de l'horloge (au plus 3 600 s)")
    if not (a.candidat_relu and a.candidat_verifie and a.go and a.registre and a.rapport):
        arret("mode reel : candidats relu et vérifié, GO, registre et rapports obligatoires")


def git(*args: str) -> bytes:
    r = subprocess.run(["git", "-C", str(D), *args], capture_output=True)
    if r.returncode != 0:
        arret(f"git {' '.join(args)} : {r.stderr.decode(errors='replace').strip()}")
    return r.stdout


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


sys.path.insert(0, str(D / "src"))
from controle_ia.harnais.validation_reelle import CHEMINS_GELES  # noqa: E402

if git("status", "--porcelain", "--untracked-files=no").strip():
    arret("arbre suivi non propre")
for anc, desc in ((ANCIEN, a.commit), (a.commit, "HEAD")):
    if subprocess.run(["git", "-C", str(D), "merge-base", "--is-ancestor", anc, desc]).returncode != 0:
        arret(f"{anc[:12]} n'est pas ancêtre de {desc[:12]}")
change = git("diff", "--name-only", ANCIEN, a.commit, "--", *CHEMINS_GELES).decode().split()
if change != [TEST_CORRIGE]:
    arret(f"arbre gelé entre {ANCIEN[:7]} et {a.commit[:7]} : {change} au lieu de [{TEST_CORRIGE}]")
if git("diff", "--name-only", a.commit, "HEAD", "--", *CHEMINS_GELES).strip():
    arret(f"arbre gelé différent entre le commit cité {a.commit[:12]} et HEAD")
octets_v1 = git("show", f"HEAD:{V1}")
sha_v1 = sha(octets_v1)
if git("show", f"HEAD:{V1}.sha256").decode().split()[0] != sha_v1:
    arret("la v1 ne correspond pas à son sceau")
t = octets_v1.decode("utf-8")
for script in ("scripts/amorce_instance_t05.sh", "scripts/pilote_t05_instance.sh"):
    if f"`{script}` (`{sha(git('show', f'{a.commit}:{script}'))}`, sha256)" not in t:
        arret(f"{script} : empreinte au commit cité différente de celle de la v1")


def au_head(p: str) -> bytes:
    return git("show", f"HEAD:{p}")


lignes = [x for x in au_head(SUITE).decode("utf-8").strip().splitlines() if x and not x.startswith("code ")]
if not lignes:
    arret(f"{SUITE} sans ligne lisible")
m = re.fullmatch(r"(\d+) passed in (\d+)\.(\d{2})s( \(\d+:\d{2}:\d{2}\))?", lignes[-1])
if not m:
    arret(f"dernière ligne de la suite illisible : {lignes[-1]!r}")
tests, duree = m.group(1), f"{m.group(2)},{m.group(3)}"
if f"  - Tests attendus : `{tests}` (toute" not in t:
    arret(f"nombre de tests {tests} différent de celui de la v1")
if a.mode == "reel":
    r = subprocess.run([sys.executable, "-m", "pytest", "--collect-only", "-q", "-p", "no:cacheprovider"], cwd=D,
                       capture_output=True, text=True, env={**__import__("os").environ, "PYTHONPATH": "src"})
    mc = re.search(r"^(\d+) tests? collected", r.stdout, re.M)
    if r.returncode != 0 or not mc or mc.group(1) != tests:
        arret(f"tests collectés à HEAD : {mc.group(1) if mc else 'illisible'} ≠ {tests}")
s_suite, s_env, s_proc = sha(au_head(SUITE)), sha(au_head(ENVIRONNEMENT)), sha(au_head(PROCESSEUR))
s_tests_inst, s_journal = sha(au_head(TESTS_INSTANCE)), sha(au_head(JOURNAL_INSTANCE))
c7 = a.commit[:7]


def rep(x: str, y: str) -> None:
    global t
    n = t.count(x)
    if n != 1:
        arret(f"cible trouvée {n} fois : {x[:80]!r}")
    t = t.replace(x, y)


rep("# Préenregistrement — T0.5 — revalidation courte de l'équivalence sur le domaine du pilote — v1",
    "# Préenregistrement — T0.5 — revalidation courte de l'équivalence sur le domaine du pilote — v2")
entete_v1 = t.split("\n")[2]
if not entete_v1.startswith("Version scellée le 2026-10-10 19:41 UTC"):
    arret("en-tête de la v1 inattendu")
rep(entete_v1,
    f"Version 2, scellée le {a.date}, depuis la v1 scellée le 2026-10-10 19:41 UTC (`{V1}`, `{sha_v1}` ; gardée telle "
    "quelle). La v1 n'a joué aucun épisode : sur l'instance 55292763, la suite des tests a échoué avant le run (« 1 failed, "
    "669 passed » ; `tests/test_validation_reelle.py::test_p4_contraire_se_lit_au_vu_du_repere`, un test qui supposait non "
    "nul le 99e centile des écarts de production du modèle jouet en bfloat16, la grandeur que lit la garde ; il est nul sur "
    "ce processeur, un AMD EPYC 7513 de classe vectorielle AVX2 pour torch, sans AVX-512 "
    f"(`{PROCESSEUR}`, `{s_proc}`), alors que le maximum reste non nul, environ 1e-3 en émulation ; R-132, R-134). Elle n'est "
    "pas relancée telle quelle : la cause est déterministe, et l'option (b) de N-018, relancer la v1 sur un processeur de "
    "classe AVX-512, choisirait le matériel pour passer une garde. D'où cette version (N-018). Ce qui change : le commit "
    f"du code cité (le test corrigé, commit `{c7}` ; le code de la revalidation, les scripts de l'instance, la "
    "configuration, l'entropie et le nombre de tests sont inchangés) et la durée de la suite à ce commit (« Calcul ») ; le "
    f"chemin de ce préenregistrement et la branche de résultats, passés au script de l'instance (`PREREG={V2}`, "
    f"`BRANCHE={BRANCHE}` : la v1 occupe les défauts) ; le titre, cet en-tête, l'auteur et la date, une ligne de "
    "transparence et une entrée d'historique. Aucun seuil, aucune lecture, aucune graine ne change.\n\n"
    "En-tête de la v1, pour mémoire : « " + entete_v1 + " »")
rep("- Auteur : la session de mise en œuvre du programme de Lazar ; rédaction le 2026-10-07.",
    "- Auteur : la session de mise en œuvre du programme de Lazar ; rédaction le 2026-10-07 ; version 2 rédigée le 2026-10-10.")
rep("- Date (UTC) : 2026-10-10 19:41 (scellement :",
    f"- Date (UTC) : {a.date.removesuffix(' UTC')} (version 2 ; v1 le 2026-10-10 19:41 ; scellement de la v1 :")
rep(f"- Commit du code d'analyse : `{ANCIEN}`",
    f"- Commit du code d'analyse : `{a.commit}` (v1 : `{ANCIEN}` ; seul change, entre les deux, dans l'arbre gelé "
    f"(`CHEMINS_GELES`) : `{TEST_CORRIGE}`)")
rep("(tirée au scellement par `numpy.random.SeedSequence`, écrite une seule fois).",
    "(tirée au scellement de la v1 par `numpy.random.SeedSequence`, écrite une seule fois ; la même pour la v2).")
rep("--run-id <run> --prereg prereg/T0.5-revalidation-equivalence-pilote-v1.md`.",
    f"--run-id <run> --prereg {V2}` ; ce chemin et la branche de résultats `{BRANCHE}` sont passés au script par "
    "l'environnement de l'instance (`PREREG`, `BRANCHE`), la v1 et sa branche occupant les défauts ; l'amorce les "
    "transmet telles quelles sans les lire (répétition jouet v3 de la chaîne, passage 1).")
rep("(au commit cité : 670 tests, 475,09 s dans un environnement neuf installé seulement depuis `requirements-gpu.txt`, "
    "sur la session, le 2026-10-10 : répétition jouet de l'amorce, archive "
    "`prereg/contre-lectures/T0.5-revalidation-repetition-jouet-v5.tar`, fichier `racine-1-sain/t05/tests.txt` ; "
    "vérification du remplissage, D-3 et N-9).",
    f"(au commit cité : {tests} tests, {duree} s dans un environnement neuf installé seulement depuis "
    f"`requirements-gpu.txt`, sur la session, le 2026-10-10 : `{SUITE}` (`{s_suite}`), environnement `{ENVIRONNEMENT}` "
    f"(`{s_env}`) ; au commit de la v1 : 670 tests, 475,09 s sur la session, répétition jouet de l'amorce, archive "
    "`prereg/contre-lectures/T0.5-revalidation-repetition-jouet-v5.tar`, fichier `racine-1-sain/t05/tests.txt`, "
    "vérification du remplissage, D-3 et N-9 ; sur l'instance 55292763, au commit de la v1 : 1 échec et 669 réussis en "
    f"501,51 s, `{TESTS_INSTANCE}` (`{s_tests_inst}`), soit 10 min 25 s de la ligne « AMORCE » à la fin des tests, "
    f"`{JOURNAL_INSTANCE}` (`{s_journal}`)).")
rep("- Connu avant le scellement : les résultats de T0.4 v1 à v3 (cités).",
    "- Connu avant le scellement de la v2 : la tentative de la v1, arrêtée aux tests, avant tout manifeste et tout "
    "épisode (R-132) ; aucun résultat de run n'existe. Audit des tests sensibles au matériel par un sous-agent neuf "
    "(`prereg/contre-lectures/T0.5-revalidation-audit-tests-materiel-v1.md`, "
    "`dd1becf7be90650b79419b3d336ad2406a7ae4d704d643f7be26885bb7efff6c` ; R-133) : aucun autre test à risque élevé ni "
    "moyen ; risques faibles notés, non corrigés avant la relance (trois tests qui exigent un écart de production non nul "
    "au 99e centile, passés sur les deux classes de processeur, AVX2 et AVX-512 ; tolérances de 1e-30 et 1e-12 ; passage "
    "de minuit pendant `test_garde_calcul`, que le lanceur évite) ; un hôte sans AVX2 ferait échouer trois tests, donc "
    "arrêter avant le run (risque résiduel déclaré, R-135).\n"
    "- Connu avant le scellement : les résultats de T0.4 v1 à v3 (cités).")
derniere = [x for x in t.split("\n") if x.startswith("- Contrôle mécanique des corrections du brouillon 6")]
if len(derniere) != 1:
    arret("dernière entrée de l'historique de la v1 introuvable")
if a.mode == "reel":
    pieces = []
    for f, role in ((a.candidat_relu, "candidat relu"), (a.candidat_verifie, "candidat vérifié après corrections")):
        brut = Path(f).read_bytes()
        pieces.append(f"{role} `{sha(brut)}`")
    for f in a.rapport:
        if not MOTIF_RAPPORT.fullmatch(f):
            arret(f"rapport {f} hors de prereg/contre-lectures/ ou au nom inattendu")
        b = au_head(f)
        if au_head(f + ".sha256").decode("utf-8").strip() != f"{sha(b)}  {Path(f).name}":
            arret(f"sceau de {f} absent ou non conforme")
        pieces.append(f"`{Path(f).name}` (`{sha(b)}`)")
    go = au_head("registres/go.md").decode("utf-8")
    if not re.search(rf"^\| {re.escape(a.go)} \|.*N-018", go, re.M):
        arret(f"{a.go} absent de registres/go.md ou sans N-018")
    n018 = [x for x in au_head("registres/decisions.md").decode("utf-8").splitlines() if x.startswith("| N-018 |")]
    if len(n018) != 1 or n018[0].rstrip().endswith("| en attente |"):
        arret("N-018 introuvable ou encore en attente dans registres/decisions.md")
    fin = ("Pièces : " + " ; ".join(pieces) + f" ; corrections de la relecture : R-135 ; décision de Lazar : {a.go} "
           f"({a.registre}).")
else:
    fin = "Pièces : (remplies au scellement)."
entree = ("- Version 2 (N-018) : différentiel v1 → v2 (texte ; code dans l'arbre gelé, `git diff " + ANCIEN[:7] + " " + c7
          + " -- <CHEMINS_GELES>` : un seul fichier de test) relu avant le scellement par des sous-agents neufs, en trois "
          "angles (texte, code et cause, chaîne de lancement), avec contre-vérification adverse des remarques graves ; "
          "corrections faites ensuite, puis vérifiées par un sous-agent neuf. " + fin)
rep(derniere[0], derniere[0] + "\n" + entree)
permises = ("- Commit du code d'analyse", "En-tête de la v1", "- Version 2 (N-018)")
reste = [x for x in t.splitlines() if (ANCIEN in x or ANCIEN[:7] in x) and not x.startswith(permises)]
if reste:
    arret("ancien commit restant hors des lignes permises : " + " | ".join(x[:80] for x in reste))
with open(a.sortie, "x", encoding="utf-8") as f:
    f.write(t)
print(f"v2 écrite : {a.sortie} ; sha256 {sha(t.encode())} ; tests {tests} ; durée {duree} s")
