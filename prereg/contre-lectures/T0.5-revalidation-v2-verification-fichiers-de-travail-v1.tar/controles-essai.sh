#!/usr/bin/env bash
# Contrôles avant dépense de la revalidation (T0.5), v5 : version 2 du préenregistrement (N-018), après la relecture R2
# du candidat 2 (R-135 ; L-02, L-03, L-09, L-10, T-2, T-3, T-9). Sur un clone neuf du dépôt de travail au commit de
# scellement S ; aucun calcul payant ; code 0 si et seulement si tout est conforme.
# Le candidat vérifié est épinglé par deux empreintes écrites ici (brute et normalisée). Normalisation : première date
# « AAAA-MM-JJ HH:MM » des lignes 3 et 8, et fin « Pièces : … » de l'unique entrée « - Version 2 (N-018) : », qui doit
# suivre immédiatement la dernière entrée de l'historique de la v1. La fin « Pièces » est ensuite vérifiée pièce par
# pièce : empreintes des candidats relu et vérifié, rapports attendus (liste fixe) présents à S avec leur sceau et
# leur empreinte, GO de Lazar sur N-018 consigné, N-018 tranché, R-135 présent.
# Aucune valeur n'est lue dans l'environnement : les essais (banc des artefacts) jouent une copie dont seules les lignes
# DEPOT et les trois épingles changent.
# Usage : controles_avant_depense_v5.sh S DOSSIER_NEUF
set -uo pipefail
S=$1; D=$2
DEPOT=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/verification-v2-essais/distant.git
CANDIDAT_RELU=af09c78b13f4b4dc18c005b216ccc738bc39fd02828242cc8c1f61e64eb38fb8        # candidat 2, relu (R2)
CANDIDAT_VERIFIE=f5adb5718304d701e7065c3e80b6212f6c543f7be1a1b0ab15665c4052b1823e
CANDIDAT_NORMALISE=657df75a8ca5f2a741b68ae3a87fd2323e13c6de0b905b978b5c758b87be0df8
RAPPORTS_ATTENDUS="T0.5-revalidation-v2-relecture-texte-v1.md T0.5-revalidation-v2-relecture-code-v1.md T0.5-revalidation-v2-relecture-chaine-v1.md T0.5-revalidation-v2-relecture-contre-verifications-v1.md T0.5-revalidation-v2-relecture-resultats-v1.json T0.5-revalidation-v2-relecture-fichiers-de-travail-v1.tar T0.5-revalidation-v2-verification-corrections-v1.md"
ARCHIVE_V5=903164d44083c21690fc1757fa227ca58bc95ca3cac4b879e2caf624ec5c3178
SUITE=docs/procedures/revalidation-T0.5-v2/suite-6ec7434-environnement-neuf-v1.txt
SUITE_SHA=90d3984fb99ea575d2bf32c3af2d8ac86592cb72da82c6a1bc2f5d7fa70cdac2
PY=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/scellement-revalidation/venv-gpu-neuf/bin/python
P=prereg/T0.5-revalidation-equivalence-pilote-v2.md; CFG=prereg/T0.5-revalidation-config-v1.json
P1=prereg/T0.5-revalidation-equivalence-pilote-v1.md; ANCIEN=3b8c049bec316272b4f65a0e51ef54a2c1e83217
BRANCHE=calcul/t05-revalidation-reel-v2
RUN=donnees/20261007-082440-t05-extraction
echec=0; ok() { echo "OK  $*"; }; ko() { echo "KO  $*"; echec=1; }
[[ "$S" =~ ^[0-9a-f]{40}$ ]] || { echo "S invalide"; exit 2; }
[ -e "$D" ] && { echo "$D existe déjà"; exit 2; }
for v in "$CANDIDAT_VERIFIE" "$CANDIDAT_NORMALISE"; do [[ "$v" =~ ^[0-9a-f]{64}$ ]] || { echo "empreinte du candidat vérifié non épinglée"; exit 2; }; done
[ "$RAPPORTS_ATTENDUS" != A_EPINGLER ] || { echo "liste des rapports attendus non épinglée"; exit 2; }
git clone -q "$DEPOT" "$D" || { echo "clonage impossible"; exit 2; }
cd "$D" && git checkout -q "$S" || { echo "commit $S introuvable"; exit 2; }
[ "$(git log --diff-filter=A -1 --format=%H -- "$P.sha256")" = "$S" ] && ok "S ajoute le sceau du préenregistrement v2" || ko "S n'est pas le commit qui ajoute $P.sha256"
# commit du code : lu dans le préenregistrement de S, ancêtre de S
CODE=$(sed -n "s/.*Commit du code d'analyse : \`\([0-9a-f]\{40\}\)\`.*/\1/p" "$P" | head -1)
if [[ "$CODE" =~ ^[0-9a-f]{40}$ ]] && git merge-base --is-ancestor "$CODE" "$S"; then ok "commit du code cité $CODE, ancêtre de S"
else ko "commit du code cité illisible ou non ancêtre de S"; CODE=$S; fi
for f in scripts/amorce_instance_t05.sh scripts/pilote_t05_instance.sh; do
    e=$(git show "$S:$f" | sha256sum | cut -d' ' -f1)
    grep -qF "\`$f\` (\`$e\`, sha256)" "$P" && ok "empreinte de $f citée ($e)" || ko "empreinte de $f ($e) non citée"
done
GELES=(. ':(exclude)prereg' ':(exclude)brouillons' ':(exclude)registres' ':(exclude)docs' ':(exclude)diag' ':(exclude)runs'
       ':(exclude)donnees' ':(exclude)livrables' ':(exclude)papiers' ':(exclude)traces' ':(exclude)CLAUDE.md')
git diff --quiet "$CODE" "$S" -- "${GELES[@]}"; c=$?
case $c in 0) ok "arbre gelé identique au commit du code" ;; 1) ko "arbre gelé modifié depuis le commit du code" ;;
           *) ko "comparaison de l'arbre gelé impossible (code $c)" ;; esac
git merge-base --is-ancestor "$ANCIEN" "$CODE" && [ "$(git diff --name-only "$ANCIEN" "$CODE" -- "${GELES[@]}")" = "tests/test_validation_reelle.py" ] \
    && ok "code : seul tests/test_validation_reelle.py change depuis le commit de la v1" || ko "code : différentiel depuis la v1 inattendu"
for f in "$CFG" "$RUN/taches-entrainement.json" "$RUN/taches-evaluation.json"; do
    if git cat-file -e "$S:$f" && git cat-file -e "$S:$f.sha256" && \
       [ "$(git show "$S:$f.sha256")" = "$(git show "$S:$f" | sha256sum | cut -d' ' -f1)  $(basename "$f")" ]; then
        ok "$f et son sceau entier dans l'arbre de S"
    else ko "$f ou son sceau absent ou non conforme"; fi
done
# rapports de vérification de la v1, toujours cités par l'historique (trois)
n=0
while read -r nom sha; do
    n=$((n+1)); f="prereg/contre-lectures/$nom"
    if git cat-file -e "$S:$f" && [ "$(git show "$S:$f" | sha256sum | cut -d' ' -f1)" = "$sha" ]; then ok "rapport cité $nom présent, empreinte conforme"
    else ko "rapport cité $nom absent de S ou d'empreinte différente"; fi
done < <(grep -o '`T0\.5-revalidation-verification-remplissage-[0-9]-v1\.md` (`[0-9a-f]\{64\}`)' "$P" | sed 's/`\([^`]*\)` (`\([0-9a-f]*\)`)/\1 \2/')
[ "$n" = 3 ] && ok "trois rapports de vérification de la v1 cités" || ko "$n rapport(s) de vérification de la v1 cité(s) au lieu de 3"
# v1 intacte et citée par son empreinte
e1=$(git show "$S:$P1" | sha256sum | cut -d' ' -f1)
[ "$(git show "$S:$P1.sha256" | cut -d' ' -f1)" = "$e1" ] && grep -qF "(\`$P1\`, \`$e1\`" "$P" \
    && ok "v1 intacte, citée par son empreinte ($e1)" || ko "v1 : sceau ou citation"
# entrée « - Version 2 (N-018) : » : une seule, juste après la dernière entrée de l'historique de la v1
nv=$(grep -c '^- Version 2 (N-018)' "$P")
lc=$(grep -n '^- Contrôle mécanique des corrections du brouillon 6' "$P" | cut -d: -f1)
lv=$(grep -n '^- Version 2 (N-018) : ' "$P" | cut -d: -f1)
[ "$nv" = 1 ] && [ -n "$lc" ] && [ "$lv" = "$((lc + 1))" ] && ok "entrée Version 2 unique, à sa place (ligne $lv)" || ko "entrée Version 2 : $nv ligne(s), place $lv (attendue $((lc + 1)))"
# préenregistrement de S = candidat vérifié, normalisé (dates des lignes 3 et 8 ; fin « Pièces » de l'entrée)
n=$(sed -E '3s/[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}/AAAA-MM-JJ HH:MM/; 8s/[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}/AAAA-MM-JJ HH:MM/' "$P" \
    | sed -E 's/^(- Version 2 \(N-018\) : .*) Pièces : .*$/\1 Pièces : (remplies au scellement)./' | sha256sum | cut -d' ' -f1)
[ "$n" = "$CANDIDAT_NORMALISE" ] && ok "préenregistrement de S = candidat vérifié, normalisé ($n)" || ko "préenregistrement de S ≠ candidat vérifié ($n)"
# fin « Pièces » : chaque pièce vérifiée
PIECES=$(sed -n 's/^- Version 2 (N-018) : .* Pièces : \(.*\)$/\1/p' "$P")
grep -qF "candidat relu \`$CANDIDAT_RELU\`" <<<"$PIECES" && ok "pièces : candidat relu ($CANDIDAT_RELU)" || ko "pièces : candidat relu absent"
grep -qF "candidat vérifié après corrections \`$CANDIDAT_VERIFIE\`" <<<"$PIECES" && ok "pièces : candidat vérifié ($CANDIDAT_VERIFIE)" || ko "pièces : candidat vérifié absent"
cites=$(grep -o '`T0\.5-revalidation-v2-[a-z-]*-v1\.[a-z]*` (`[0-9a-f]\{64\}`)' <<<"$PIECES" | sed 's/`\([^`]*\)` (`\([0-9a-f]*\)`)/\1/' | sort | tr '\n' ' ')
attendus=$(tr ' ' '\n' <<<"$RAPPORTS_ATTENDUS" | grep . | sort | tr '\n' ' ')
[ "$cites" = "$attendus" ] && ok "pièces : rapports cités = rapports attendus" || ko "pièces : rapports cités « $cites » ≠ attendus « $attendus »"
while read -r nom sha; do
    [ -n "$nom" ] || continue
    f="prereg/contre-lectures/$nom"
    if git cat-file -e "$S:$f" && [ "$(git show "$S:$f" | sha256sum | cut -d' ' -f1)" = "$sha" ] \
       && [ "$(git show "$S:$f.sha256" 2>/dev/null)" = "$sha  $nom" ]; then ok "pièce $nom présente, scellée, empreinte conforme"
    else ko "pièce $nom absente, non scellée ou d'empreinte différente"; fi
done < <(grep -o '`T0\.5-revalidation-v2-[a-z-]*-v1\.[a-z]*` (`[0-9a-f]\{64\}`)' <<<"$PIECES" | sed 's/`\([^`]*\)` (`\([0-9a-f]*\)`)/\1 \2/')
GO=$(sed -n 's/.*décision de Lazar : \(GO-[0-9-]*\) (R-[0-9]*)\.$/\1/p' <<<"$PIECES")
if [[ "$GO" =~ ^GO-[0-9]{4}-[0-9]{2}-[0-9]{2}-[0-9]{2}$ ]] && grep -qE "^\| $GO \|.*N-018" registres/go.md; then ok "GO de Lazar sur N-018 consigné ($GO)"
else ko "GO sur N-018 absent des pièces ou de registres/go.md"; fi
l18=$(grep '^| N-018 |' registres/decisions.md)
[ "$(grep -c '^| N-018 |' registres/decisions.md)" = 1 ] && ! grep -q '| en attente |[[:space:]]*$' <<<"$l18" && ok "N-018 tranché dans registres/decisions.md" || ko "N-018 absent ou encore en attente"
grep -q '^| R-135 |' registres/decisions.md && ok "R-135 (corrections de la relecture) consigné" || ko "R-135 absent"
# sortie de la suite au commit cité : versée, scellée, à l'empreinte attendue, citée
[ "$(git show "$S:$SUITE" 2>/dev/null | sha256sum | cut -d' ' -f1)" = "$SUITE_SHA" ] && [ "$(git show "$S:$SUITE.sha256")" = "$SUITE_SHA  $(basename "$SUITE")" ] \
    && grep -qF "\`$SUITE\` (\`$SUITE_SHA\`)" "$P" && ok "sortie de la suite versée, scellée, citée" || ko "sortie de la suite : empreinte, sceau ou citation"
# archives des répétitions jouet de la v1 : présentes, scellées ; v5 à l'empreinte attendue, citée
for v in v4 v5; do
    f=prereg/contre-lectures/T0.5-revalidation-repetition-jouet-$v.tar
    if git cat-file -e "$S:$f" && [ "$(git show "$S:$f.sha256")" = "$(git show "$S:$f" | sha256sum | cut -d' ' -f1)  $(basename "$f")" ]; then
        ok "archive $v présente et scellée"
    else ko "archive $v absente ou sceau non conforme"; fi
done
[ "$(git show "$S:prereg/contre-lectures/T0.5-revalidation-repetition-jouet-v5.tar" 2>/dev/null | sha256sum | cut -d' ' -f1)" = "$ARCHIVE_V5" ] \
    && grep -qF "archive \`prereg/contre-lectures/T0.5-revalidation-repetition-jouet-v5.tar\`" "$P" \
    && ok "archive v5 à l'empreinte attendue, citée" || ko "archive v5 : empreinte ou citation"
git ls-remote --exit-code origin "refs/heads/$BRANCHE" >/dev/null 2>&1; c=$?
[ "$c" = 2 ] && ok "branche $BRANCHE absente" || ko "branche de résultats $BRANCHE : code $c (2 attendu)"
grep -qF "\`PREREG=$P\`, \`BRANCHE=$BRANCHE\`" "$P" && ok "PREREG et BRANCHE cités par la v2 (ligne 3) = constantes" || ko "PREREG ou BRANCHE : la v2 cite autre chose"
PYTHONPATH=src "$PY" -c "from controle_ia.prereg import problemes; p = problemes('$P'); print(p); raise SystemExit(1 if p else 0)" \
    && ok "problemes() vide" || ko "problemes() non vide"
PYTHONPATH=src "$PY" -m controle_ia.scellement verifier "$P" "$P1" "$CFG" "$RUN/taches-entrainement.json" "$RUN/taches-evaluation.json" >/dev/null \
    && ok "sceaux de la v2, de la v1, de la configuration et des tâches" || ko "sceaux"
PYTHONPATH=src "$PY" -m controle_ia.scellement verifier-arbre . | tail -1 | grep -q "arbre intact" && ok "verifier-arbre : arbre intact" || ko "verifier-arbre"
PYTHONPATH=src "$PY" - "$P" "$CFG" "$RUN" <<'EOF' && ok "gardes du lanceur rejouées (configuration, citations, code cité, code importé)" || ko "gardes du lanceur"
import json, sys
from pathlib import Path
from controle_ia.environnements import revalider_pilote_a as rv
from controle_ia.harnais.validation_reelle import exiger_code_cite, exiger_code_importe_sous
from controle_ia.scellement import verifier
p, cfg, run = sys.argv[1:4]
verifier(cfg)
c = json.loads(Path(cfg).read_text(encoding="utf-8"))
rv.exiger_config_revalidation(c)
if c["mode"] != "reel":
    raise SystemExit("configuration hors mode reel")
e = rv.exiger_citations(Path(p), c, rv._sha_fichier(f"{run}/taches-entrainement.json"), rv._sha_fichier(f"{run}/taches-evaluation.json"))
print("commit cité :", exiger_code_cite(Path("."), Path(p)), "; entropie citée :", e)
exiger_code_importe_sous(Path("."))
EOF
PYTHONPATH=src "$PY" -m pytest --collect-only -q -p no:cacheprovider > "$D/../collecte-$$.txt" 2>&1; cc=$?
n=$(sed -n 's/^\([0-9]*\) tests\{0,1\} collected in .*/\1/p' "$D/../collecte-$$.txt"); rm -f "$D/../collecte-$$.txt"
a=$(sed -n "s/.*Tests attendus : \`\([0-9]*\)\`.*/\1/p" "$P" | head -1)
[ "$cc" = 0 ] && [ -n "$n" ] && [ "$n" = "$a" ] && ok "tests collectés au commit S : $n = tests attendus (collecte en code 0)" || ko "tests collectés au commit S : $n ≠ $a, ou collecte en code $cc"
echo '{"tool_input":{"command":"GO_ID=GO-2026-10-04-08 vastai create instance 1 --raw"}}' | python3 .claude/hooks/garde_calcul.py \
    && ok "garde de calcul : registres/go.md de S lisible, GO-2026-10-04-08 accepté" || ko "garde de calcul sur le registre de S"
lire() { sed -n "s/.*$1 : \`\\([^\`]*\\)\`.*/\\1/p" "$P" | head -1; }
echo "lecture précoce (script de l'instance, PREREG=$P) : tests $a ; configuration $(lire "Chemin de la configuration") ; entraînement $(lire "Chemin des tâches d'entraînement") ; évaluation $(lire "Chemin des tâches d'évaluation")"
[ "$echec" = 0 ] && echo "CONTRÔLES AVANT DÉPENSE : TOUS CONFORMES" || echo "CONTRÔLES AVANT DÉPENSE : ÉCHEC"
exit $echec
