#!/usr/bin/env bash
# Essai W-1 : les fichiers de tâches cités par le brouillon 3 (donnees/<run>/taches-*.json) peuvent-ils être dans l'arbre
# du commit que l'instance extrait ? Rien n'est ouvert sous donnees/ : seuls des noms (chemin fictif, index git) sont lus.
# Usage : bash w_donnees.sh <racine du dépôt>
cd "$1" || exit 1
echo "HEAD $(git rev-parse HEAD)"
echo "1. brouillon 3, chemins cités :"; grep -n "Chemin des tâches" brouillons/T0.5-revalidation-equivalence-pilote-v1-brouillon3.md | cut -c1-140
echo "2. .gitignore :"; grep -n "donnees" .gitignore
echo "3. git check-ignore sur un chemin fictif de la forme citée :"
git check-ignore -v --no-index "donnees/20261007-082440-t05-extraction/taches-entrainement.json"; echo "   code $? (0 = ignoré)"
echo "4. fichiers suivis sous donnees/ à HEAD : $(git ls-files | grep -c '^donnees/')"
echo "5. fichiers sous donnees/ dans l'historique de toutes les branches locales : $(git log --all --name-only --format= -- 'donnees/*' | grep -c .)"
echo "6. l'extraction écrit les tâches assemblées sous donnees/ :"; grep -n '"taches-evaluation"\|"taches-entrainement"\|^compteurs. `donnees' src/controle_ia/environnements/extraire_t05.py | cut -c1-150
echo "7. le script de l'instance : clone, extraction du commit, puis plus aucune récupération ; chemins passés au lanceur :"
grep -n 'clone -q\|checkout -q "\$COMMIT"\|fetch\|lire_chemin "Chemin des tâches\|--entrainement' scripts/pilote_t05_instance.sh | cut -c1-150
echo "8. ordre dans le script : pip (l. 172), carte (l. 176), tests (l. 189) avant la lecture des chemins (l. 221-222) ; le lanceur vérifie les fichiers :"
grep -n "verifier(chemin_entrainement)\|verifier(chemin_evaluation)" src/controle_ia/environnements/revalider_pilote_a.py
