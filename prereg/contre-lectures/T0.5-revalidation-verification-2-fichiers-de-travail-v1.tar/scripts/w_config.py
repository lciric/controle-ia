"""La configuration brouillon 2 passe-t-elle la garde du lanceur, et chaque valeur de la table du brouillon 3 (l. 111)
est-elle celle du fichier ? Différentiel avec le brouillon 1. Lecture seule."""
import json, sys, hashlib
sys.path.insert(0, "src")
from controle_ia.environnements import revalider_pilote_a as rv
from controle_ia.manifeste import config_canonique
c2 = json.load(open("brouillons/T0.5-revalidation-config-v1-brouillon2.json"))
c1 = json.load(open("brouillons/T0.5-revalidation-config-v1-brouillon1.json"))
rv.exiger_config_revalidation(c2); print("garde du lanceur : passe")
table = {"N": 1, "T": 10, "episodes_par_tache": 1, "lot": 8, "max_nouveaux": 400, "temperature": 1.0, "couches": [7, 15, 23],
         "fraction_equivalence": 1.0, "statistique_equivalence": "q99", "tolerance_equivalence": 0.2,
         "positions_min_controle_negatif": 4, "actions_min_controle_negatif": 10, "fraction_min_controle_negatif": 0.95,
         "mode": "reel", "fils": 1, "bras": ["defaut", "math"], "nombre_taches": 16, "transcriptions_repere": 2,
         "actions_min_comparees": 40, "part_min_contexte_couvert": 0.9, "memoire_carte_min_gio": 75,
         "memoire_pic_max_gio": 70, "marge_q99": 0.15, "rho_max": 3, "duree_max_s": 12600, "duree_max_bras_s": 5400,
         "duree_max_episodes_pilote_s": 9000, "chemin": {"T": 5, "tolerance": 0.003},
         "controle_positif": {"T": 5, "decalage_positions": 1, "positions_min": 4, "actions_min": 10, "fraction_min": 0.95}}
ecarts = {k: (v, c2.get(k)) for k, v in table.items() if c2.get(k) != v}
print("écarts table/fichier :", ecarts or "aucun")
print("clés du fichier absentes de la table :", sorted(set(c2) - set(table)))
print("agent :", c2["agent"]["modele"], c2["agent"]["revision"], c2["agent"]["variables_gabarit"])
print("clés retirées depuis le brouillon 1 :", sorted(set(c1) - set(c2)), "; ajoutées :", sorted(set(c2) - set(c1)))
print("valeurs changées :", {k: (c1[k], c2[k]) for k in set(c1) & set(c2) if c1[k] != c2[k]})
print("empreinte canonique (brouillon 2, pour mémoire) :", hashlib.sha256(config_canonique(c2)).hexdigest())
