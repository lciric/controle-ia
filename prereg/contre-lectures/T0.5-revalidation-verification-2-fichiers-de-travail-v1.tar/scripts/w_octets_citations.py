"""Essai W-octets : les lignes du brouillon 3 que lisent les motifs du lanceur (Python) et du script (sed) ont-elles
les octets attendus ? Remplit les À REMPLIR par des valeurs fictives dans une COPIE en mémoire, puis applique les
motifs exacts du code. Lecture seule du dépôt."""
import re, sys, subprocess, tempfile, os
sys.path.insert(0, "src")
from controle_ia.environnements import revalider_pilote_a as rv
from controle_ia.harnais.validation_reelle import ENTROPIE_CITEE

src = open("brouillons/T0.5-revalidation-equivalence-pilote-v1-brouillon3.md", encoding="utf-8").read()
for i, l in enumerate(src.splitlines(), 1):
    if any(k in l for k in ("Tests attendus", "Tâches d'", "Chemin d", "Configuration de la revalidation", "Entropie :", "Index des invites")):
        bizarres = sorted({hex(ord(c)) for c in l if ord(c) in (0xa0, 0x202f, 0x2019, 0x2009)})
        print(f"l.{i}: caractères spéciaux {bizarres or 'aucun'} : {l[:90]}")
# remplissage fictif (copie en mémoire)
h = lambda c: c * 64
rempli = (src.replace("- Entropie : `À REMPLIR`", "- Entropie : `123456789`")
             .replace("(empreinte canonique) : `À REMPLIR`", f"(empreinte canonique) : `{h('a')}`")
             .replace("- Tâches d'entraînement : `À REMPLIR`", f"- Tâches d'entraînement : `{h('b')}`")
             .replace("- Tâches d'évaluation : `À REMPLIR`", f"- Tâches d'évaluation : `{h('c')}`")
             .replace("- Chemin des tâches d'entraînement : `À REMPLIR`", "- Chemin des tâches d'entraînement : `donnees/x/taches-entrainement.json`")
             .replace("- Chemin des tâches d'évaluation : `À REMPLIR`", "- Chemin des tâches d'évaluation : `donnees/x/taches-evaluation.json`")
             .replace("Tests attendus : `À REMPLIR`", "Tests attendus : `602`"))
for nom, motif in [("config", rv.CONFIG_CITEE), ("entrainement", rv.TACHES_CITEES), ("evaluation", rv.EVALUATION_CITEE),
                   ("index", rv.INDEX_CITE), ("entropie", ENTROPIE_CITEE)]:
    m = motif.search(rempli)
    print(f"motif {nom}: {'trouvé ' + m.group(1)[:16] if m else 'ABSENT'} ; dans le brouillon tel quel : {'trouvé' if motif.search(src) else 'absent'}")
with tempfile.TemporaryDirectory(dir=os.environ["W"]) as d:
    for etat, texte in (("tel quel", src), ("rempli", rempli)):
        p = os.path.join(d, "prereg.md"); open(p, "w", encoding="utf-8").write(texte)
        # sed exacts du script pilote_t05_instance.sh (l. 186 et 205)
        att = subprocess.run(["bash", "-c", "set -o pipefail; sed -n \"s/.*Tests attendus : \\`\\([0-9]*\\)\\`.*/\\1/p\" \"$1\" | head -1", "_", p], capture_output=True, text=True).stdout.strip()
        lire = lambda cle: subprocess.run(["bash", "-c", "sed -n \"s/.*$1 : \\`\\\\([^\\`]*\\\\)\\`.*/\\\\1/p\" \"$2\" | head -1", "_", cle, p], capture_output=True, text=True).stdout.strip()
        print(f"[{etat}] ATTENDUS={att!r} ; config={lire('Chemin de la configuration')!r} ; entr={lire(chr(67)+'hemin des tâches d'+chr(39)+'entraînement')!r} ; eval={lire('Chemin des tâches d'+chr(39)+'évaluation')!r}")
