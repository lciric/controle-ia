"""Essai : signal TERM envoyé, par son identifiant de processus (R10), au lanceur de la revalidation en mode jouet ;
attendu : arret.json (motif « signal TERM »), code de sortie 1. Tout est écrit sous le dossier passé en argument."""
import json, os, signal, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, "src")
from controle_ia.scellement import sceller

BASE = Path(sys.argv[1]); SRC = Path("src").resolve(); BASE.mkdir(parents=True, exist_ok=True)
d = BASE / "depot"; d.mkdir()
g = lambda *a: subprocess.run(["git", "-C", str(d), *a], check=True, capture_output=True)
g("init", "-q", "-b", "main"); g("config", "user.email", "v@example.invalid"); g("config", "user.name", "v")
config = {"N": 1, "T": 4, "episodes_par_tache": 1, "lot": 2, "max_nouveaux": 6, "temperature": 1.0, "couches": [0, 1, 2],
          "fraction_equivalence": 1.0, "statistique_equivalence": "q99", "tolerance_equivalence": 0.2,
          "positions_min_controle_negatif": 4, "actions_min_controle_negatif": 1, "fraction_min_controle_negatif": 0.95,
          "agent": {"nom": "agent-jouet"}, "mode": "jouet", "fils": 1, "bras": ["defaut", "math"], "nombre_taches": 4,
          "transcriptions_repere": 2, "actions_min_comparees": 4, "part_min_contexte_couvert": 0.9,
          "memoire_carte_min_gio": 75, "memoire_pic_max_gio": 70, "marge_q99": 0.15, "rho_max": 3, "duree_max_s": 600,
          "duree_max_bras_s": 300, "duree_max_episodes_pilote_s": 1e9, "chemin": {"T": 2, "tolerance": 1e-5},
          "controle_positif": {"T": 2, "decalage_positions": 1, "positions_min": 4, "actions_min": 1, "fraction_min": 0.95}}
(d / "config.json").write_text(json.dumps(config)); sceller(d / "config.json")
t = lambda p, n, f: [{"identifiant": f"{p}.{k:05d}v1", "questions": "Why? " * f(k), "classification": None} for k in range(n)]
for nom, ts in (("entrainement", t("2601", 4, lambda k: 1 + k)), ("evaluation", t("2602", 64, lambda k: 1))):
    (d / f"{nom}.json").write_text(json.dumps({"taches": ts})); sceller(d / f"{nom}.json")
g("add", "-A"); g("commit", "-q", "-m", "init")
run = "20261007-000020-verif-term"
env = dict(os.environ, PYTHONPATH=str(SRC), PYTHONDONTWRITEBYTECODE="1")
p = subprocess.Popen([sys.executable, "-m", "controle_ia.environnements.revalider_pilote_a", "--config", "config.json",
                      "--entrainement", "entrainement.json", "--evaluation", "evaluation.json", "--run-id", run],
                     cwd=d, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
time.sleep(float(sys.argv[2]) if len(sys.argv) > 2 else 8)
os.kill(p.pid, signal.SIGTERM)                 # par identifiant de processus (R10)
out, err = p.communicate(timeout=600)
arret = d / "diag" / run / "arret.json"
print(f"code de sortie {p.returncode} ; stderr : {err.strip().splitlines()[-1] if err.strip() else ''}")
if arret.is_file():
    a = json.loads(arret.read_text())["resultat"]
    print(f"arret.json : étape={a['etape']!r} ; motif={a['motif'][:80]!r} ; bras lus={a['bras_lus']}")
    print("fichiers :", sorted(x.name for x in (d / "diag" / run).iterdir() if not x.name.endswith(".sha256")))
else:
    print("arret.json absent ; stdout :", out[-300:])
