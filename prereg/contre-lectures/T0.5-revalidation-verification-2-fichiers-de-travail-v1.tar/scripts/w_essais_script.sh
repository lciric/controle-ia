#!/usr/bin/env bash
# Essais du vérificateur sur les gardes ajoutées à scripts/pilote_t05_instance.sh (RV-14). Les lignes éprouvées sont
# extraites telles quelles du script du dépôt (aucune recopie à la main) ; tout s'exécute sous le dossier passé en $1.
# Usage : bash w_essais_script.sh <dossier de travail> <racine du dépôt>
set -uo pipefail
T="$1"; DEPOT="$2"; S="$DEPOT/scripts/pilote_t05_instance.sh"
mkdir -p "$T"; cd "$T" || exit 1
echo "script : $(sha256sum "$S" | cut -c1-64)"

# 1. dernière ligne de pytest : la condition exacte de la ligne 197
COND=$(sed -n '197p' "$S" | sed -E 's/^if (.*); then$/\1/')
echo "condition l.197 : $COND"
essai_ligne() {   # $1 attendus, $2 dernière ligne ; rend « arrêt » si la condition d'arrêt est vraie
    local ATTENDUS="$1" DERNIERE="$2"
    if eval "$COND"; then echo "arrêt"; else echo "passe"; fi
}
for l in "62 passed in 349.95s (0:05:49)" "62 passed in 0.95s" "62 passed, 3 warnings in 346.12s (0:05:46)" \
         "62 passed, 1 warning in 346.12s (1:05:46)"; do
    printf '  sain     %-50s → %s\n' "« $l »" "$(essai_ligne 62 "$l")"
done
for l in "61 passed in 1.00s" "162 passed in 1.00s" "620 passed in 1.00s" "62 passed, 1 skipped in 1.00s" \
         "62 passed, 1 xfailed in 1.00s" "62 passed, 1 xpassed in 1.00s" "62 passed, 1 deselected in 1.00s" \
         "1 failed, 61 passed in 1.00s" "62 passed, 1 error in 1.00s" "" "no tests ran in 0.01s" \
         $'\e[32m62 passed\e[0m in 1.00s'; do
    printf '  artefact %-50q → %s\n' "$l" "$(essai_ligne 62 "$l")"
done

# 2. nombre de tests lu dans le préenregistrement (ligne 186) ; préenregistrement absent sous set -e (ligne 186 avant 215)
L186=$(sed -n '186p' "$S")
printf -- '- Tests attendus : `602` (toute la suite)\n' > prereg-rempli.md
printf -- '- Tests attendus : `À REMPLIR` (toute la suite)\n' > prereg-vide.md
for p in prereg-rempli.md prereg-vide.md; do
    PREREG="$p"; eval "$L186"; echo "  ligne 186 sur $p → ATTENDUS='$ATTENDUS'"
done
( set -euo pipefail; PREREG=absent.md; trap 'echo "  préenregistrement absent : sortie du script, code $? (piège EXIT : consigner_arret « tests (sortie imprévue) »)"' EXIT; eval "$L186"; echo "  (non atteint)" ) 2>/dev/null

# 3. branche déjà présente (ligne 74) : dépôts git locaux, sans réseau
L74=$(sed -n '74p' "$S" | sed -E 's/^if (.*); then$/\1/')
echo "condition l.74 : $L74"
rm -rf distant.git clone; git init -q --bare distant.git
git clone -q distant.git clone 2>/dev/null; ( cd clone && git -c user.email=v@x -c user.name=v commit -q --allow-empty -m init && git push -q origin HEAD:main && git push -q origin HEAD:calcul/t05-revalidation-v1 )
cd clone
for BRANCHE in calcul/t05-revalidation-v1 calcul/t05-revalidation-v2 t05-revalidation-v1; do
    if eval "$L74"; then r="arrêt (branche présente)"; else r="passe"; fi; echo "  BRANCHE=$BRANCHE → $r"
done
git remote set-url origin "$T/distant-introuvable.git"
BRANCHE=calcul/t05-revalidation-v1
git ls-remote --exit-code --heads origin "$BRANCHE" >/dev/null 2>&1; code=$?
if eval "$L74"; then r="arrêt"; else r="passe"; fi
echo "  dépôt distant injoignable (code de git ls-remote : $code) → $r : la vérification est sautée en silence"
cd "$T"

# 4. carte (ligne 176) : processeur seul ici (artefact) ; cas sain simulé par un module torch factice
L176=$(sed -n '176p' "$S" | sed -E 's/^if (.*); then$/\1/')
PY="$DEPOT/.venv/bin/python"
python() { "$PY" "$@"; }
MODE=reel; if eval "$L176"; then echo "  carte : machine sans carte → arrêt avant les tests"; else echo "  carte : machine sans carte → passe (anomalie)"; fi
mkdir -p faux/torch; printf 'class cuda:\n    @staticmethod\n    def is_available():\n        return True\n' > faux/torch/__init__.py
python() { PYTHONPATH="$T/faux" "$PY" "$@"; }
if eval "$L176"; then echo "  carte : torch voit une carte (simulé) → arrêt (anomalie)"; else echo "  carte : torch voit une carte (simulé) → passe"; fi
MODE=jouet; python() { "$PY" "$@"; }; if eval "$L176"; then echo "  carte : mode jouet → arrêt (anomalie)"; else echo "  carte : mode jouet → contrôle sauté (attendu)"; fi
