"""Essais du vérificateur sur le code de la revalidation (modèle jouet, processeur). Lecture seule du dépôt : le dépôt
jetable, les tâches et les résultats sont écrits sous le dossier passé en argument.

E-a : panne de mémoire pendant la phase « repère et chemin » du bras « defaut » : le texte (table, « panne de mémoire
      signalée dans un bras ») attend « defaut » non conforme et « math » lu ; que fait le code ?
E-b : échéance passée à la phase « chemin » : celle du bras (duree_max_bras_s) ou celle du run ?
E-c : bras aux écarts tous nuls : « réserve » (table) ou non conforme (P9 dans la conformité) ?
E-d : durée projetée absente (chrono sans « generation_s ») : R8 lu conforme ?
"""
import json, subprocess, sys, time
from pathlib import Path

import torch

sys.path.insert(0, "src")
from controle_ia.environnements import revalider_pilote_a as rv
from controle_ia.harnais.modeles import regler_determinisme
from controle_ia.scellement import sceller

regler_determinisme(1)
BASE = Path(sys.argv[1]); BASE.mkdir(parents=True, exist_ok=True)
CONFIG = {"N": 1, "T": 2, "episodes_par_tache": 1, "lot": 2, "max_nouveaux": 6, "temperature": 1.0,
          "couches": [0, 1, 2], "fraction_equivalence": 1.0, "statistique_equivalence": "q99",
          "tolerance_equivalence": 0.2, "positions_min_controle_negatif": 4, "actions_min_controle_negatif": 1,
          "fraction_min_controle_negatif": 0.95, "agent": {"nom": "agent-jouet"}, "mode": "jouet", "fils": 1,
          "bras": ["defaut", "math"], "nombre_taches": 4, "transcriptions_repere": 2, "actions_min_comparees": 4,
          "part_min_contexte_couvert": 0.9, "memoire_carte_min_gio": 75, "memoire_pic_max_gio": 70,
          "marge_q99": 0.15, "rho_max": 3, "duree_max_s": 600, "duree_max_bras_s": 300,
          "duree_max_episodes_pilote_s": 1e9, "chemin": {"T": 2, "tolerance": 1e-5},
          "controle_positif": {"T": 2, "decalage_positions": 1, "positions_min": 4, "actions_min": 1,
                               "fraction_min": 0.95}}   # = configuration des tests du dépôt


def git(r, *a):
    subprocess.run(["git", "-C", str(r), *a], check=True, capture_output=True)


def depot(nom):
    d = BASE / nom
    d.mkdir()
    git(d, "init", "-q", "-b", "main"); git(d, "config", "user.email", "v@example.invalid"); git(d, "config", "user.name", "v")
    (d / "README").write_text("x\n"); git(d, "add", "-A"); git(d, "commit", "-q", "-m", "init")
    return d


def taches(prefixe, n, longueur=lambda k: 1 + k):
    return [{"identifiant": f"{prefixe}.{k:05d}v1", "questions": f"Why do routers matter in setting {k}? " * longueur(k),
             "classification": {"theory_experiment": "mostly_experiments", "data_type": "real_only", "domains": []}}
            for k in range(n)]


def fichiers(d):
    chemins = []
    for nom, t in (("entrainement", taches("2601", 4)), ("evaluation", taches("2602", 64, lambda k: 1))):
        f = d / f"taches-{nom}.json"; f.write_text(json.dumps({"taches": t}), encoding="utf-8"); sceller(f); chemins.append(str(f))
    git(d, "add", "-A"); git(d, "commit", "-q", "-m", "taches")
    return chemins


# --- E-b : échéance reçue par la phase « chemin »
d = depot("e-b"); e, v = fichiers(d)
vrai_chemin, vu = rv._phase_chemin, {}
def espion(reference, fmt, plan, g, config, echeance):
    vu["echeance_chemin_restante_s"] = round(echeance - time.perf_counter(), 1)
    return vrai_chemin(reference, fmt, plan, g, config, echeance)
rv._phase_chemin = espion
cfg_b = dict(CONFIG, duree_max_bras_s=120, duree_max_s=600)
rv.executer(cfg_b, d, "20261007-000010-verif-echeance", None, e, v, entropie_essai=11)
rv._phase_chemin = vrai_chemin
print(f"E-b : duree_max_bras_s = 120 s, duree_max_s = 600 s ; échéance restante passée à la phase « chemin » : "
      f"{vu['echeance_chemin_restante_s']} s (> 120 s : échéance du run, pas celle du bras)")

# --- E-a : panne de mémoire dans la phase « repère et chemin » du bras « defaut »
d = depot("e-a"); e, v = fichiers(d)
def panne_chemin(*a, **k):
    raise torch.cuda.OutOfMemoryError("mémoire simulée pendant la phase chemin")
rv._phase_chemin = panne_chemin
run = "20261007-000011-verif-panne-chemin"
try:
    r = rv.executer(CONFIG, d, run, None, e, v, entropie_essai=11)
    print("E-a : run complet ; lectures :", {b: x.get("conforme") for b, x in r["lectures"].items()})
except Exception as exc:
    sortie = sorted(p.name for p in (d / "diag" / run).iterdir())
    arret = json.loads((d / "diag" / run / "arret.json").read_text())["resultat"]
    print(f"E-a : run ARRÊTÉ ({type(exc).__name__}) ; fichiers : {sortie}")
    print(f"      arret.json : étape={arret['etape']!r}, bras lus={arret['bras_lus']}, noyau={arret['noyau_retenu_sur_les_bras_lus']}")
    print("      le bras « math » n'est pas joué ; la table du brouillon 3 (l. 125) attend « defaut » non conforme et la règle appliquée à « math »")
rv._phase_chemin = vrai_chemin

# --- E-c : écarts tous nuls
def fiche_nulle(generes=20, contexte=200):
    cle = "0,9"
    return {"equivalence": {
        "ecarts_q99": {cle: {7: 0.0}}, "ecarts": {cle: {7: 0.0}},
        "positions_capturees": {cle: contexte + generes}, "longueurs_contexte": {cle: contexte},
        "lignes": {cle: {"remplissage": 3}}, "sondes": {cle: {"tableaux_distincts": True, "ulp_vu": True}},
        "profils": {cle: {7: {"generee": {"jetons": generes, "q99": 0.0, "max": 0.0, "nuls": generes}}}},
        "controle_negatif_zone_generee": {cle: {7: {"positions": generes - 1, "au_dessus": generes - 1, "max": 0.8, "q99": 0.5}}}},
        "actions": [{"debut": contexte}]}
fiches = [fiche_nulle() for _ in range(12)]
cfg = dict(CONFIG, actions_min_comparees=10, actions_min_controle_negatif=10)
mes = rv.domaine_et_garde(fiches); aud = rv.audit_symetrie(fiches, {"7": {"q99": 0.03}})
lec = rv.lire_bras(mes, {"lecture": "conforme"}, {"7": {"q99": 0.03}}, True, cfg, audit=aud, bras="math",
                   memoire_pic_gio=10.0, duree_projetee_s=10.0)
print(f"E-c : écarts tous nuls → audit_R4_ecarts_tous_nuls={lec['audit_R4_ecarts_tous_nuls']}, P9={aud['P9_zone_generee_non_nulle']}, "
      f"conforme={lec['conforme']} (la table l. 129 dit « réserve » ; P9 rend le bras non conforme)")

# --- E-d : durée projetée absente
print(f"E-d : duree_projetee_pilote({{}}, 16) = {rv.duree_projetee_pilote({}, 16)} ; "
      f"R8 lu avec None : {rv.lire_bras(mes, {'lecture': 'conforme'}, {'7': {'q99': 0.03}}, True, cfg, audit=aud, duree_projetee_s=None)['R8_duree']} ; "
      f"R7 lu avec None : {rv.lire_bras(mes, {'lecture': 'conforme'}, {'7': {'q99': 0.03}}, True, cfg, audit=aud, memoire_pic_gio=None)['R7_memoire']}")
