#!/usr/bin/env bash
# Z (question B) : la commande de contrôle des sceaux du script (l. 130-133), rejouée telle quelle sur une copie des
# trois modules (__init__, gardes, scellement) ; on regarde le fichier sceaux.txt et sa dernière ligne, celle que le
# script verse au journal. Cas : 1) premier fichier altéré ; 2) troisième fichier altéré (après deux « OK ») ;
# 3) troisième fichier altéré, avec PYTHONUNBUFFERED=1 (témoin de la cause). Imports : python3 -S (sans site-packages)
# et -X importtime, pour montrer que seule la bibliothèque standard est chargée.
set -u
# l'image python:3.11-bookworm ne pose pas PYTHONUNBUFFERED ; la session, si : on la retire (témoin au cas 3)
unset PYTHONUNBUFFERED
D=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-revalidation-b5
B="$D/bac-sceaux"
rm -rf "$B"; mkdir -p "$B/src/controle_ia" "$B/prereg" "$B/donnees/r"
for m in __init__.py gardes.py scellement.py; do cp /home/user/controle-ia/src/controle_ia/$m "$B/src/controle_ia/"; done
cd "$B"
echo '{}' > prereg/config.json; echo '{"taches": []}' > donnees/r/taches-entrainement.json
echo '{"taches": [0]}' > donnees/r/taches-evaluation.json
for f in prereg/config.json donnees/r/taches-entrainement.json donnees/r/taches-evaluation.json; do
  (cd "$(dirname "$f")" && sha256sum "$(basename "$f")" > "$(basename "$f").sha256")
done
verif() { PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src python3 -m controle_ia.scellement verifier prereg/config.json \
            donnees/r/taches-entrainement.json donnees/r/taches-evaluation.json >"$B/sceaux.txt" 2>&1; }
echo "python3 = $(command -v python3) ; $(python3 --version)"
echo "== 0) cas sain"; verif; echo "code $?"; cat "$B/sceaux.txt"
echo "== 1) premier fichier (configuration) altéré"
cp prereg/config.json /tmp/x 2>/dev/null; echo '{"a": 1}' > prereg/config.json
verif; echo "code $?"; echo "-- sceaux.txt :"; cat "$B/sceaux.txt"; echo "-- tail -n 1 (versé au journal) : $(tail -n 1 "$B/sceaux.txt")"
echo '{}' > prereg/config.json
echo "== 2) troisième fichier (tâches d'évaluation) altéré, après deux fichiers conformes"
echo '{"taches": [1]}' > donnees/r/taches-evaluation.json
verif; echo "code $?"; echo "-- sceaux.txt :"; cat "$B/sceaux.txt"; echo "-- tail -n 1 (versé au journal) : $(tail -n 1 "$B/sceaux.txt")"
echo "== 3) même cas, PYTHONUNBUFFERED=1 (témoin)"
PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src python3 -m controle_ia.scellement verifier prereg/config.json \
    donnees/r/taches-entrainement.json donnees/r/taches-evaluation.json >"$B/sceaux.txt" 2>&1
echo "code $?"; echo "-- tail -n 1 : $(tail -n 1 "$B/sceaux.txt")"
echo '{"taches": [0]}' > donnees/r/taches-evaluation.json
echo "== 4) imports sans site-packages (python3 -S) et modules chargés hors bibliothèque standard"
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src python3 -S -X importtime -m controle_ia.scellement verifier prereg/config.json \
    donnees/r/taches-entrainement.json donnees/r/taches-evaluation.json 2>"$B/imports.txt"; echo "code $?"
python3 - "$B/imports.txt" <<'PY'
import sys
noms = [l.split("|")[-1].strip() for l in open(sys.argv[1]) if l.startswith("import time:") and "|" in l]
noms = [n for n in noms if n and n != "package"]
racines = sorted({n.strip().split(".")[0] for n in noms})
hors = [r for r in racines if r not in sys.stdlib_module_names and r not in ("controle_ia",)]
print("modules racines importés :", len(racines), "; hors bibliothèque standard (sauf controle_ia) :", hors)
print("modules controle_ia :", sorted({n.strip() for n in noms if n.strip().startswith("controle_ia")}))
PY
rm -rf "$B"
