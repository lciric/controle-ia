"""Z (question D) : arithmétique des limites de temps du brouillon 5 et de la configuration, brouillon 3 ; garde de
configuration de la revalidation appliquée au brouillon 3 ; garde de durée du lanceur du pilote (bornes).
Lancer : PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/home/user/controle-ia/src /home/user/controle-ia/.venv/bin/python <ce fichier>"""
import json, math
from pathlib import Path

DEPOT = Path("/home/user/controle-ia")
c = json.loads((DEPOT / "brouillons/T0.5-revalidation-config-v1-brouillon3.json").read_text(encoding="utf-8"))
print("configuration b3 :", {k: c[k] for k in ("duree_max_s", "duree_max_bras_s", "duree_max_episodes_pilote_s")})
assert c["duree_max_bras_s"] * 2 == c["duree_max_s"] == 12_600 and c["duree_max_bras_s"] == 105 * 60
print("surveillance : 5 h − 5 min =", 5 * 3600 - 300, "; 6 h − 3 900 s =", 6 * 3600 - 3900)
print("plafond = 17 700 − 2 700 =", 17_700 - 2_700, "; R8 = 15 000 − 7 200 =", 15_000 - 7_200,
      "; délai externe 270 min =", 270 * 60, "; plafond de l'amorce 300 min =", 300 * 60)


def formule(d):
    return min(15_000, math.ceil((1.2 * d + 7_200) / 60) * 60)


vals = {d: formule(d) for d in range(0, 7_801)}
print("formule(7 800) =", formule(7_800), "; formule(6 500) =", formule(6_500), "; formule(6 501) =", formule(6_501),
      "; formule(0) =", formule(0))
assert all(v % 60 == 0 and 0 < v <= 15_000 for v in vals.values())
seuil = min(d for d, v in vals.items() if v == 15_000)
print("le plafond joue dès d =", seuil, "s ; au-delà, la part des juges vaut 15 000 − d :",
      {d: 15_000 - d for d in (6_500, 7_000, 7_800)})
print("ancienne formule (brouillon 4) au plafond R8 de 9 000 s : min(16 000 ; 1,2 × 9 000 + 7 200) =",
      min(16_000, 1.2 * 9_000 + 7_200))
# arrondi flottant : 1,2 × d n'est pas exact en binaire ; vérifier qu'aucun d entier ne passe à la minute suivante à tort
faux = [d for d in range(0, 7_801) if math.ceil((1.2 * d + 7_200) / 60) != -((-(12 * d + 72_000)) // 600)]
print("écarts entre l'arrondi flottant et l'arrondi exact (entiers) :", faux[:10], "…" if len(faux) > 10 else "",
      "nombre :", len(faux))
from controle_ia.environnements import revalider_pilote_a as rv  # noqa: E402
from controle_ia.environnements import lancer_pilote_a as lp  # noqa: E402
rv.exiger_config_revalidation(c)
print("exiger_config_revalidation(brouillon 3) : accepté")
print("lanceur du pilote : DUREE_MAX_S =", lp.DUREE_MAX_S, "; DUREE_EXTERNE_S =", lp.DUREE_EXTERNE_S)
