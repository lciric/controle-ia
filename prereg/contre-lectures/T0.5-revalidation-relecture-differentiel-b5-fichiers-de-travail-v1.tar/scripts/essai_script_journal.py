"""Z (questions B et E) : le script de l'instance (`scripts/pilote_t05_instance.sh`, HEAD), exécuté tel quel contre un
dépôt jetable, comme le fait `tests/test_script_instance_t05.py` (même montage, même environnement minimal ENV_DE_BASE,
python et nvidia-smi factices). On lit `journal.txt` seul (pas la sortie d'erreur) pour :
  S1  cas sain : préenregistrement lu, sceaux conformes ;
  S2  tâches d'évaluation altérées (troisième fichier vérifié) : la ligne versée au journal nomme-t-elle la cause ?
  S3  configuration altérée (premier fichier vérifié) : témoin ;
  S4  vérification de branche impossible, avec une erreur de git réaliste sur deux lignes (cause au journal ?) ;
  S5  branche présente : message au journal ?
  S6  `python3` absent du PATH avant l'installation : arrêt en code 2, consigné ?
Lancer : PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/home/user/controle-ia/src /home/user/controle-ia/.venv/bin/python <ce fichier>
"""
import os, shutil, subprocess, sys, tempfile
from pathlib import Path

DEPOT = Path("/home/user/controle-ia")
SCRIPT = DEPOT / "scripts" / "pilote_t05_instance.sh"
sys.path.insert(0, str(DEPOT / "src"))
from controle_ia.scellement import sceller  # noqa: E402

ICI = Path("/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-revalidation-b5")
ENV_DE_BASE = ("PATH", "LANG", "LC_ALL", "LC_CTYPE", "TMPDIR")
PREREG = "prereg/revalidation.md"
ENT = "donnees/20261007-000000-t05-extraction/taches-entrainement.json"
EVA = "donnees/20261007-000000-t05-extraction/taches-evaluation.json"
CONFIG = "prereg/config.json"
PYTHON_FACTICE = """#!/usr/bin/env bash
if [ "$1" = "-m" ] && [ "$2" = "pytest" ]; then printf '%s\\n' "7 passed in 1.00s"; exit 0; fi
if [ "$1" = "-c" ]; then case "$2" in *"is_available() else 1"*) exit 0 ;; esac; echo "torch factice"; exit 0; fi
echo "lanceur factice : arrêt" >&2; exit 1
"""


def git(d, *a):
    return subprocess.run(["git", "-C", str(d), *a], capture_output=True, text=True, check=True).stdout.strip()


def bac(racine: Path):
    src = racine / "source"
    (src / "prereg").mkdir(parents=True)
    git(racine, "init", "-q", "-b", "main", str(src))
    git(src, "config", "user.email", "t@example.invalid"); git(src, "config", "user.name", "t")
    for d in ("runs", "diag"):
        (src / d).mkdir(); (src / d / ".gitkeep").write_text("")
    (src / PREREG).write_text(f"- Tests attendus : `7`\n- Chemin de la configuration : `{CONFIG}`\n"
                              f"- Chemin des tâches d'entraînement : `{ENT}`\n"
                              f"- Chemin des tâches d'évaluation : `{EVA}`\n", encoding="utf-8")
    (src / CONFIG).write_text("{}"); sceller(src / CONFIG)
    (src / "src" / "controle_ia").mkdir(parents=True)
    for nom in ("__init__.py", "gardes.py", "scellement.py"):
        shutil.copy(DEPOT / "src" / "controle_ia" / nom, src / "src" / "controle_ia" / nom)
    for c in (ENT, EVA):
        f = src / c; f.parent.mkdir(parents=True, exist_ok=True); f.write_text('{"taches": []}'); sceller(f)
    git(src, "add", "-A"); git(src, "commit", "-qm", "init")
    venv = racine / "venv"; (venv / "bin").mkdir(parents=True)
    (venv / "bin" / "activate").write_text(f'export PATH="{venv}/bin:$PATH"\n')
    for nom, texte in (("python", PYTHON_FACTICE), ("nvidia-smi", "#!/usr/bin/env bash\necho 'A100'\n")):
        (venv / "bin" / nom).write_text(texte); (venv / "bin" / nom).chmod(0o755)
    return src, venv


def lancer(racine, src, venv, travail, chemin=None, env_sup=None):
    distant = racine / f"distant-{travail}.git"
    subprocess.run(["git", "clone", "-q", "--bare", str(src), str(distant)], check=True)
    env = {k: os.environ[k] for k in ENV_DE_BASE if k in os.environ}
    env.update(COMMIT=git(src, "rev-parse", "HEAD"), ETUDE="revalidation", MODE="jouet", DEPOT_URL=str(distant),
               TRAVAIL=str(racine / travail), PREREG=PREREG, VENV_EXISTANT=str(venv), HOME=str(racine))
    if chemin is not None:
        env["PATH"] = chemin
    env.update(env_sup or {})
    r = subprocess.run(["bash", str(SCRIPT)], env=env, capture_output=True, text=True, timeout=300)
    j = racine / travail / "journal.txt"
    return r.returncode, (j.read_text(encoding="utf-8") if j.exists() else "(pas de journal)"), r.stderr


def montrer(nom, code, journal, err):
    print(f"== {nom} : code {code}")
    for l in journal.splitlines()[1:]:
        print("   journal |", l[21:])
    if err.strip():
        print("   stderr  |", err.strip().splitlines()[-1][:300])


racine = Path(tempfile.mkdtemp(prefix="essai-script-", dir=ICI))
try:
    src, venv = bac(racine)
    print("PYTHONUNBUFFERED dans l'environnement du script :", "PYTHONUNBUFFERED" in ENV_DE_BASE)
    montrer("S1 cas sain", *lancer(racine, src, venv, "s1"))
    (src / EVA).write_text('{"taches": [1]}'); git(src, "commit", "-qam", "eva")
    montrer("S2 tâches d'évaluation altérées (3e fichier)", *lancer(racine, src, venv, "s2"))
    (src / EVA).write_text('{"taches": []}'); (src / CONFIG).write_text('{"a": 1}'); git(src, "commit", "-qam", "cfg")
    montrer("S3 configuration altérée (1er fichier)", *lancer(racine, src, venv, "s3"))
    (src / CONFIG).write_text("{}"); git(src, "commit", "-qam", "retour")
    faux = racine / "faux-git"; faux.mkdir()
    (faux / "git").write_text("#!/usr/bin/env bash\nif [ \"$1\" = ls-remote ]; then\n"
                              "  echo \"remote: Invalid username or token.\" >&2\n"
                              "  echo \"fatal: Authentication failed for 'https://github.com/x/y.git/'\" >&2; exit 128\nfi\n"
                              f"exec {shutil.which('git')} \"$@\"\n")
    (faux / "git").chmod(0o755)
    montrer("S4 branche : vérification impossible (git, code 128, deux lignes)",
            *lancer(racine, src, venv, "s4", chemin=f"{faux}:{os.environ['PATH']}"))
    distant = racine / "distant-s5.git"
    subprocess.run(["git", "clone", "-q", "--bare", str(src), str(distant)], check=True)
    subprocess.run(["git", "-C", str(distant), "branch", "calcul/t05-revalidation-jouet-v1", "main"], check=True)
    env = {k: os.environ[k] for k in ENV_DE_BASE if k in os.environ}
    env.update(COMMIT=git(src, "rev-parse", "HEAD"), ETUDE="revalidation", MODE="jouet", DEPOT_URL=str(distant),
               TRAVAIL=str(racine / "s5"), PREREG=PREREG, VENV_EXISTANT=str(venv), HOME=str(racine))
    r = subprocess.run(["bash", str(SCRIPT)], env=env, capture_output=True, text=True, timeout=300)
    montrer("S5 branche présente", r.returncode, (racine / "s5" / "journal.txt").read_text(encoding="utf-8"), r.stderr)
    # S6 : PATH sans python3 (seulement git, coreutils, sed... par liens dans un dossier jetable)
    bins = racine / "bins"; bins.mkdir()
    for outil in ("git", "bash", "env", "date", "tee", "mkdir", "sed", "head", "tail", "tr", "dirname", "basename",
                  "sha256sum", "cat", "printf"):
        p = shutil.which(outil)
        if p:
            (bins / outil).symlink_to(p)
    montrer("S6 python3 absent avant l'installation", *lancer(racine, src, venv, "s6", chemin=str(bins)))
finally:
    shutil.rmtree(racine)
