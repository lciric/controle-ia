#!/usr/bin/env bash
# Relecture du différentiel, brouillon 5 : les deux lancements de tests demandés (question E), en séquence.
# 1) les deux fichiers ; 2) le fichier du script seul, avec BRANCHE et PREREG_ABSENT exportées.
set -u
D=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-revalidation-b5
cd /home/user/controle-ia
export PYTHONDONTWRITEBYTECODE=1
date -u +%FT%TZ > "$D/sorties/pytest-1.txt"
PYTHONPATH=src .venv/bin/python -m pytest -q -p no:cacheprovider --basetemp="$D/pytest-tmp" \
    tests/test_revalider_pilote_a.py tests/test_script_instance_t05.py >> "$D/sorties/pytest-1.txt" 2>&1
echo "code $?" >> "$D/sorties/pytest-1.txt"
date -u +%FT%TZ > "$D/sorties/pytest-2-env.txt"
BRANCHE=calcul/t05-pilote-reel-v2 PREREG_ABSENT=1 PYTHONPATH=src .venv/bin/python -m pytest -q -p no:cacheprovider \
    --basetemp="$D/pytest-tmp-env" tests/test_script_instance_t05.py >> "$D/sorties/pytest-2-env.txt" 2>&1
echo "code $?" >> "$D/sorties/pytest-2-env.txt"
date -u +%FT%TZ >> "$D/sorties/pytest-2-env.txt"
