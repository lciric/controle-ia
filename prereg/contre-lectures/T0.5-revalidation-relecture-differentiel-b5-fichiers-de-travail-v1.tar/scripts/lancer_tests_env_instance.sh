#!/usr/bin/env bash
# Contrôle mécanique élargi (X-1, Y-1) : tests du script lancés avec toutes les variables que l'amorce, l'essai local
# ou les essais du script peuvent poser sur l'instance, exportées avec des valeurs hostiles.
set -u
D=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-revalidation-b5
cd /home/user/controle-ia
export PYTHONDONTWRITEBYTECODE=1 COMMIT=deadbeef ETUDE=pilote MODE=reel TRAVAIL=/inexistant DEPOT_URL=https://example.invalid/x.git \
  GH_TOKEN=x HF_TOKEN=x BRANCHE=calcul/t05-revalidation-reel-v2 PREREG=prereg/autre.md VENV_EXISTANT=/inexistant \
  PREREG_ABSENT=1 TESTS_ATTENDUS=3 CONFIG=x TACHES=x ENTRAINEMENT=x EVALUATION=x FAUX_PYTEST_LIGNE="1 passed in 1s" \
  FAUX_PYTEST_CODE=1 FAUX_CARTE_CODE=1 RACINE_AMORCE=/inexistant
PYTHONPATH=src .venv/bin/python -m pytest -q -p no:cacheprovider --basetemp="$D/pytest-tmp-env2" tests/test_script_instance_t05.py 2>&1 | tail -3
