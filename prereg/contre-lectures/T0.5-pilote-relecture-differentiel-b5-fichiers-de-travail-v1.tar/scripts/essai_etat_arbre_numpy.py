"""Essai de relecture (Y), question B : état de l'arbre et version de numpy à chaque étape de lecture, sur des dépôts
jetables construits par les aides des tests (`tests/test_lire_pilote.py`, lues sans modification ; aucun cache écrit :
lancer avec PYTHONDONTWRITEBYTECODE=1). La garde d'import est neutralisée comme dans les tests (le code vient du vrai
dépôt). Usage : PYTHONPATH=src:tests python -I? non : python essai_etat_arbre_numpy.py <dossier>"""
import json, subprocess, sys
from pathlib import Path

DOSSIER = Path(sys.argv[1]).resolve()
sys.path[:0] = ["/home/user/controle-ia/src", "/home/user/controle-ia/tests"]
import test_lire_pilote as T                                   # aides : construire, _etiqueter_selon_8b
from conftest import committer
from controle_ia.environnements import lire_pilote as lp
from controle_ia.gardes import GardeArret
from controle_ia import manifeste as M

lp.exiger_code_importe_sous = lambda racine: None


def git(d, *a):
    return subprocess.run(["git", "-C", str(d), *a], capture_output=True, text=True, check=True).stdout


def depot_neuf(nom):
    d = DOSSIER / nom
    d.mkdir(parents=True)
    git(d, "init", "-q", "-b", "main"); git(d, "config", "user.email", "t@x.invalid"); git(d, "config", "user.name", "t")
    (d / "README").write_text("x\n"); git(d, "add", "-A"); git(d, "commit", "-qm", "init")
    t = DOSSIER / (nom + "-travail"); t.mkdir()
    return d, t


def etat(d, nom):
    r = json.loads((d / "diag" / T.ANALYSE / f"{nom}.json").read_text(encoding="utf-8"))["resultat"]
    return {k: r[k] for k in ("commit_courant", "arbre_propre", "statut_arbre")}


print("S1 — cas sain, sorties de chaque étape NON committées avant la suivante")
d, t = depot_neuf("s1")
x = T.construire(d, n=6)
lp.preparer_etiquetage(d, T.RUN, T.ANALYSE, x["prereg"], x["taches"], t)
T._etiqueter_selon_8b(d, x, t, inverser=0.1)
lp.lire_etiquetage(d, T.RUN, T.ANALYSE, x["taches"], t)
print("  etiquettes.json :", json.dumps(etat(d, "etiquettes"), ensure_ascii=False))
lp.analyser(d, T.RUN, T.ANALYSE, x["taches"])
print("  lecture.json    :", json.dumps(etat(d, "lecture"), ensure_ascii=False))

print("S2 — module de lecture modifié et commité pour une autre tâche, puis ramené à l'état cité sans commit")
d, t = depot_neuf("s2")
x = T.construire(d, n=6)
lp.preparer_etiquetage(d, T.RUN, T.ANALYSE, x["prereg"], x["taches"], t)
committer(d)
cite = json.loads((d / "runs" / T.ANALYSE / "manifeste.json").read_text())["config"]["commit_lecture_cite"]
g = d / "src/controle_ia/gardes.py"
g.write_text(g.read_text(encoding="utf-8") + "\n# modification pour une autre tâche\n", encoding="utf-8")
committer(d)
T._etiqueter_selon_8b(d, x, t, inverser=0.1)
try:
    lp.lire_etiquetage(d, T.RUN, T.ANALYSE, x["taches"], t); print("  (a) passe : INATTENDU")
except GardeArret as e:
    print("  (a) arrêt :", e)
git(d, "checkout", cite, "--", "src/controle_ia/gardes.py")          # contournement : état cité, sans commit
lp.lire_etiquetage(d, T.RUN, T.ANALYSE, x["taches"], t)
print("  (b) passe ; etiquettes.json :", json.dumps(etat(d, "etiquettes"), ensure_ascii=False))

print("S3 — manifeste d'analyse sans la clé numpy (artefact)")
d, t = depot_neuf("s3")
x = T.construire(d, n=6)
vraie = M.versions
M.versions = lambda: {k: v for k, v in vraie().items() if k != "numpy"}
try:
    lp.preparer_etiquetage(d, T.RUN, T.ANALYSE, x["prereg"], x["taches"], t)
finally:
    M.versions = vraie
committer(d)
T._etiqueter_selon_8b(d, x, t, inverser=0.1)
try:
    lp.lire_etiquetage(d, T.RUN, T.ANALYSE, x["taches"], t); print("  passe : INATTENDU")
except GardeArret as e:
    print("  arrêt :", e)
print("  versions().get('numpy') courant :", lp.versions().get("numpy"))

print("S4 — préparation sur un arbre non propre (fichier non suivi)")
d, t = depot_neuf("s4")
x = T.construire(d, n=6)
(d / "hors-suivi.txt").write_text("x", encoding="utf-8")
try:
    lp.preparer_etiquetage(d, T.RUN, T.ANALYSE, x["prereg"], x["taches"], t); print("  passe")
except GardeArret as e:
    print("  arrêt :", str(e).splitlines()[0])
