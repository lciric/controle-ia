"""Essai de relecture (Y), F-4 : ce que tolère `format_strict` en tête d'action (code au commit HEAD)."""
import sys
sys.path.insert(0, "/home/user/controle-ia/src")
from controle_ia.environnements.lire_pilote import format_strict
corps = "ACTION: ADD\nTITLE: t\nPROPOSAL: p\nCONTROLS: c\nCOST: 10\nPREDICTION: x"
for nom, texte in [("sain", corps), ("lignes vides en tête", "\n\n" + corps),
                   ("ligne d'espaces en tête (ligne blanche)", "   \n" + corps),
                   ("ligne de tabulation en tête", "\t\n" + corps), ("CR LF en tête", "\r\n" + corps),
                   ("espace avant ACTION", " " + corps), ("tabulation avant ACTION", "\t" + corps),
                   ("espace avant TITLE", corps.replace("\nTITLE", "\n TITLE"))]:
    print(f"{nom:45s} {format_strict(texte)}")
