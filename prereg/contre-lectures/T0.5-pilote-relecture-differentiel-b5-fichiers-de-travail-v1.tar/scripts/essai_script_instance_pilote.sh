#!/usr/bin/env bash
# Essai de relecture (Y) : le script de l'instance (au commit HEAD du dépôt) joué en ETUDE=pilote, sur un dépôt jetable
# local, avec un python et un nvidia-smi factices (aucune installation, aucune carte), et un préenregistrement dont les
# lignes lues sont celles du brouillon 5 (l. 9, 12, 13), remplies. Usage : bash essai_script_instance_pilote.sh <dossier>
set -u
DEPOT_REEL=/home/user/controle-ia
B5="$DEPOT_REEL/brouillons/T0.5-pilote-8B-v1-brouillon5.md"
SCRIPT="$DEPOT_REEL/scripts/pilote_t05_instance.sh"
W="$1"; rm -rf "$W"; mkdir -p "$W"; cd "$W" || exit 1
TACHES=donnees/20261007-082440-t05-extraction/taches-evaluation.json
# --- dépôt source -----------------------------------------------------------------------------------------------
git init -q -b main src && cd src && git config user.email t@x.invalid && git config user.name t
mkdir -p prereg runs diag "$(dirname $TACHES)"; : > runs/.gitkeep; : > diag/.gitkeep
printf 'donnees/\n' > .gitignore
{ echo "# préenregistrement factice (lignes du brouillon 5, remplies)"
  sed -n '9p' "$B5"
  sed -n '12p' "$B5" | sed "s|\`À REMPLIR\`|\`$TACHES\`|"
  sed -n '13p' "$B5" | sed 's|`À REMPLIR`|`7`|'
} > prereg/T0.5-pilote-8B-v1.md
echo '{}' > prereg/T0.5-pilote-config-v1.json
echo '{"taches": []}' > $TACHES
(cd "$(dirname $TACHES)" && sha256sum taches-evaluation.json > taches-evaluation.json.sha256)
git add -A && git add -f $TACHES $TACHES.sha256 && git commit -qm init
COMMIT=$(git rev-parse HEAD); cd ..
echo "== lignes lues (préenregistrement factice)"; cat src/prereg/T0.5-pilote-8B-v1.md
# --- environnement factice -------------------------------------------------------------------------------------
mkdir -p venv/bin
printf 'export PATH="%s/venv/bin:$PATH"\n' "$W" > venv/bin/activate
cat > venv/bin/python <<'PY'
#!/usr/bin/env bash
if [ "$1" = "-m" ] && [ "$2" = "pytest" ]; then printf '%s\n' "${FAUX_PYTEST_LIGNE:-7 passed in 1.00s}"; exit 0; fi
if [ "$1" = "-c" ]; then case "$2" in *"is_available() else 1"*) exit 0 ;; esac; echo "torch factice"; exit 0; fi
echo "lanceur factice : arguments $*" >&2; exit 1
PY
printf '#!/usr/bin/env bash\necho "A100 factice"\n' > venv/bin/nvidia-smi
chmod +x venv/bin/python venv/bin/nvidia-smi
lancer() {   # $1 = dossier de travail ; reste = variables
    local t=$1; shift
    env -i PATH="$W/venv/bin:/usr/bin:/bin" HOME="$W" COMMIT="$COMMIT" ETUDE=pilote DEPOT_URL="$W/distant.git" \
        TRAVAIL="$W/$t" VENV_EXISTANT="$W/venv" "$@" bash "$SCRIPT" > "$W/$t.sortie" 2>&1
    echo "code $?"
}
git clone -q --bare src distant.git
echo; echo "== 1. mode jouet, branche par défaut"
lancer t1 MODE=jouet; grep -E "début|préenregistrement lu|tests :|run :|ARRÊT|poussée" "$W/t1.sortie"
echo "branches du dépôt distant :"; git -C distant.git branch --list | sed 's/^/  /'
echo; echo "== 2. mode réel (factice), branche par défaut"
lancer t2 MODE=reel HF_TOKEN=x; grep -E "début|préenregistrement lu|tests :|run :|ARRÊT|poussée" "$W/t2.sortie"
echo "branches du dépôt distant :"; git -C distant.git branch --list | sed 's/^/  /'
echo; echo "== 3. relancement à l'identique sans BRANCHE (branche réelle déjà présente)"
lancer t3 MODE=reel HF_TOKEN=x; tail -2 "$W/t3.sortie"
echo; echo "== 4. relancement avec BRANCHE=calcul/t05-pilote-reel-v2"
lancer t4 MODE=reel HF_TOKEN=x BRANCHE=calcul/t05-pilote-reel-v2; grep -E "début|préenregistrement lu" "$W/t4.sortie"
echo; echo "== 5. tâches non ajoutées de force (ignorées par donnees/) : arrêt avant l'installation"
git clone -q src src2 && cd src2 && git config user.email t@x.invalid && git config user.name t && \
  git rm -q --cached $TACHES $TACHES.sha256 && git commit -qm "sans ajout forcé" && C2=$(git rev-parse HEAD) && cd ..
git -C distant.git fetch -q "$W/src2" main:refs/heads/main2
COMMIT=$C2 lancer t5 MODE=jouet BRANCHE=calcul/t05-pilote-jouet-v9 COMMIT=$C2; tail -1 "$W/t5.sortie"
