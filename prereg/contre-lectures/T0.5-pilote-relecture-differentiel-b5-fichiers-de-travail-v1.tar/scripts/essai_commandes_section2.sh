#!/usr/bin/env bash
# Essai de relecture (Y) : les deux commandes ajoutées à la section 2 de la procédure (brouillon 2), l. 47-48.
# git ls-files lit l'index de l'extraction courante, pas l'arbre de $COMMIT ; git ls-remote --exit-code rend 2, 0 ou 128.
set -u
W="$1"; rm -rf "$W"; mkdir -p "$W"; cd "$W" || exit 1
T=donnees/run/taches-evaluation.json
git init -q -b main d && cd d && git config user.email t@x.invalid && git config user.name t
printf 'donnees/\n' > .gitignore; mkdir -p donnees/run prereg
echo a > prereg/p.md; git add -A; git commit -qm "scellement (COMMIT), sans les tâches"; COMMIT=$(git rev-parse HEAD)
echo '{}' > $T; sha256sum $T > /dev/null; (cd donnees/run && sha256sum taches-evaluation.json > taches-evaluation.json.sha256)
git add -f $T $T.sha256; git commit -qm "tâches ajoutées de force APRÈS le commit de scellement"
echo "(a) git ls-files --error-unmatch, extraction courante = HEAD (tâches suivies depuis un commit postérieur à COMMIT) :"
git ls-files --error-unmatch $T $T.sha256 >/dev/null 2>&1; echo "    code $? (0 = « suivis » ; pourtant absents de l'arbre de COMMIT)"
echo "    contrôle dans l'arbre de COMMIT : git cat-file -e \"\$COMMIT:$T\""
git cat-file -e "$COMMIT:$T" 2>/dev/null; echo "    code $? (≠ 0 : absent de l'arbre du commit de scellement)"
echo "    git ls-tree \"\$COMMIT\" -- $T (piège : code 0 même si absent) :"; git ls-tree "$COMMIT" -- $T; echo "    code $?"
echo "(b) fichier ignoré, présent sur disque, non ajouté de force :"
echo x > donnees/run/autre.json; git ls-files --error-unmatch donnees/run/autre.json >/dev/null 2>&1; echo "    code $?"
cd ..; git clone -q --bare d distant.git; git -C d remote add origin "$W/distant.git"
echo "(c) git ls-remote --exit-code origin refs/heads/calcul/t05-pilote-reel-v1 :"
git -C d ls-remote --exit-code origin refs/heads/calcul/t05-pilote-reel-v1 >/dev/null 2>&1; echo "    branche absente : code $?"
git -C distant.git branch calcul/t05-pilote-reel-v1 main
git -C d ls-remote --exit-code origin refs/heads/calcul/t05-pilote-reel-v1 >/dev/null 2>&1; echo "    branche présente : code $?"
git -C distant.git branch x/calcul/t05-pilote-reel-v9 main
git -C d ls-remote --exit-code origin calcul/t05-pilote-reel-v9 >/dev/null 2>&1; echo "    motif court, branche x/calcul/t05-pilote-reel-v9 seulement : code $? (le motif court attrape la fin du nom)"
git -C d ls-remote --exit-code origin refs/heads/calcul/t05-pilote-reel-v9 >/dev/null 2>&1; echo "    nom complet, même cas : code $?"
git -C d remote set-url origin "$W/inexistant.git"
git -C d ls-remote --exit-code origin refs/heads/calcul/t05-pilote-reel-v1 >/dev/null 2>&1; echo "    dépôt injoignable : code $?"
