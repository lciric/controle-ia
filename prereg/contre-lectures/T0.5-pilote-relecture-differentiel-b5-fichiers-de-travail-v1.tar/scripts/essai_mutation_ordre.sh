#!/usr/bin/env bash
# Essai de relecture (Y) : le test de l'ordre des étapes (test_lanceur_ordre_des_etapes_arret_pendant_d) passe-t-il
# encore si le lanceur fait l'appariement AVANT les notations décisives ? Copie du code et des tests dans le dossier
# de l'essai (le dépôt n'est pas touché) ; mutation textuelle de la copie seulement.
set -u
DEPOT=/home/user/controle-ia
W="$1"; rm -rf "$W"; mkdir -p "$W/tests"; cd "$W" || exit 1
mkdir -p "$W/docs/sources"; cp -r "$DEPOT/docs/sources/invites-2606.08892-v1" "$W/docs/sources/"; cp -r "$DEPOT/src" "$W/src"; find "$W/src" -name __pycache__ -prune -exec rm -rf {} +
cp "$DEPOT/tests/test_pilote_a.py" "$DEPOT/tests/conftest.py" "$W/tests/"
python3 - "$W/src/controle_ia/environnements/lancer_pilote_a.py" <<'PY'
import sys, pathlib
p = pathlib.Path(sys.argv[1]); t = p.read_text(encoding="utf-8")
assert t.count('    noter("decisives")\n') == 1 and t.count('    noter("descriptives")\n') == 1
t = t.replace('    noter("decisives")\n', '', 1)
t = t.replace('    noter("descriptives")\n', '    noter("decisives")\n    noter("descriptives")\n', 1)
p.write_text(t, encoding="utf-8")
print("mutation : appariement avant les notations décisives")
PY
grep -n 'noter("' src/controle_ia/environnements/lancer_pilote_a.py | grep -v "def noter"
cd "$W/tests" && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$W/src" "$DEPOT/.venv/bin/python" -m pytest -q -p no:cacheprovider \
   --basetemp="$W/pytest-tmp" --rootdir="$W/tests" "test_pilote_a.py::test_lanceur_ordre_des_etapes_arret_pendant_d" 2>&1 | tail -3
echo "--- témoin : la même copie, sans mutation"
cp "$DEPOT/src/controle_ia/environnements/lancer_pilote_a.py" "$W/src/controle_ia/environnements/lancer_pilote_a.py"
cd "$W/tests" && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$W/src" "$DEPOT/.venv/bin/python" -m pytest -q -p no:cacheprovider \
   --basetemp="$W/pytest-tmp-temoin" --rootdir="$W/tests" "test_pilote_a.py::test_lanceur_ordre_des_etapes_arret_pendant_d" 2>&1 | tail -1
