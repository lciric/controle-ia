#!/usr/bin/env bash
# Essai de relecture (Y) : au relancement prescrit par la procédure (« -e BRANCHE=calcul/t05-pilote-reel-v2 »), BRANCHE
# est dans l'environnement du conteneur, donc de l'amorce, du script de l'instance et de pytest. Les tests du script
# (`tests/test_script_instance_t05.py`) passent-ils encore ? (dépôt lu seulement ; sorties dans le dossier de l'essai)
W="$1"; mkdir -p "$W"; cd /home/user/controle-ia || exit 1
for b in "" "calcul/t05-pilote-reel-v2"; do
    echo "== BRANCHE=${b:-<absente>}"
    if [ -n "$b" ]; then export BRANCHE="$b"; fi
    PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src .venv/bin/python -m pytest -q -p no:cacheprovider --color=no \
        --basetemp="$W/pytest-tmp-${b//\//-}" tests/test_script_instance_t05.py 2>&1 | grep -E "^(FAILED|ERROR)|passed|failed" | tail -5
done
