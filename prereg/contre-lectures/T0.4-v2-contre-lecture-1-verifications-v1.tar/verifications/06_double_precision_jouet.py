"""Expériences sur modèle jouet (processeur, double précision), au code du commit cité (clone), non décisives.

(a) écart génération / passe unique en double précision, par zone et par couche (configuration de répétition) ;
(b) effet du défaut D1 (décalage +1 des positions décodées), par couche ;
(c) idem sur un jouet plus large (8 couches, largeur 256) ;
(d) simulation d'une réduction de la normalisation RMS dont l'ordre dépend de la forme du lot (cas probable sur carte :
    décodage à 8 lignes contre passe unique à L lignes) : au décodage seulement, la variance en simple précision est
    sommée dans un autre ordre ; on mesure l'écart génération / passe unique en double précision, sans défaut ;
(e) la réduction en simple précision `pow(2).mean(-1)` est-elle invariante à la taille du lot sur processeur ?
"""
import json, sys
import numpy as np
import torch
sys.path.insert(0, "src")
from controle_ia.harnais import validation_reelle as V
from controle_ia.manifeste import graines as G
from controle_ia.harnais.activations import couches_par_defaut
import transformers.models.llama.modeling_llama as LL

torch.set_num_threads(1)
torch.use_deterministic_algorithms(True)

def jouer(config, decalage=0, entropie=12345):
    gr = G(V.taches(config), entropie)
    c = config["logique"]
    modele, tok = V.charger(config, None, c["dtype"], gr)
    fmt, _ = V.format_du_modele(modele, tok, config)
    couches = couches_par_defaut(modele.config.num_hidden_layers)
    phase = "controle-positif" if decalage else "logique"
    cc = dict(c, T=config["controle_positif"]["T"]) if decalage else c
    sorties, _ = V.jouer_phase(modele, fmt, cc, gr, phase, couches, decalage_positions=decalage)
    par = {}
    for ep, _, r in sorties:
        for cle, prof in r["profils"].items():
            for couche, p in prof.items():
                d = par.setdefault(str(couche), {"contexte": [], "generee": [], "nuls_gen": 0, "pos_gen": 0})
                if p["contexte"]["jetons"]:
                    d["contexte"].append(p["contexte"]["max"])
                if p["generee"]["jetons"]:
                    d["generee"].append(p["generee"]["max"]); d["nuls_gen"] += p["generee"]["nuls"]; d["pos_gen"] += p["generee"]["jetons"]
    return {c_: {"max_contexte": max(v["contexte"]), "max_generee": max(v["generee"]) if v["generee"] else None,
                 "min_des_max_generee": min(v["generee"]) if v["generee"] else None,
                 "actions": len(v["generee"]), "nuls_generee": f'{v["nuls_gen"]}/{v["pos_gen"]}'} for c_, v in par.items()}

sortie = {}
base = V.CONFIG_REPETITION
sortie["a_logique_double_repetition"] = jouer(base)
sortie["b_D1_double_repetition"] = jouer(base, decalage=1)
large = dict(base, modele_jouet={"couches": 8, "largeur": 256, "tetes": 8, "tetes_cle_valeur": 4, "intermediaire": 512})
sortie["c_logique_double_large"] = jouer(large)
sortie["c_D1_double_large"] = jouer(large, decalage=1)

# (d) réduction de la variance (simple précision) dont l'ordre change au décodage (une position par ligne)
vrai = LL.LlamaRMSNorm.forward
def rms_variant(self, hidden_states):
    input_dtype = hidden_states.dtype
    hs = hidden_states.to(torch.float32)
    if hs.shape[-2] == 1:                       # passe de décodage : autre ordre de sommation, toujours en simple précision
        D = hs.shape[-1]
        carres = hs.pow(2)
        variance = (carres.reshape(*carres.shape[:-1], 8, D // 8).sum(-1).flip(-1).cumsum(-1)[..., -1:] / D)
    else:
        variance = hs.pow(2).mean(-1, keepdim=True)
    hs = hs * torch.rsqrt(variance + self.variance_epsilon)
    return self.weight * hs.to(input_dtype)
LL.LlamaRMSNorm.forward = rms_variant
try:
    sortie["d_logique_double_large_rms_variant"] = jouer(large)
    sortie["d_logique_double_repetition_rms_variant"] = jouer(base)
finally:
    LL.LlamaRMSNorm.forward = vrai

# (e) invariance de la réduction simple précision à la taille du lot, sur processeur
g = torch.Generator().manual_seed(0)
x = torch.randn(1, 2000, 4096, generator=g, dtype=torch.float64) * 3
x32 = x.to(torch.float32)
plein = x32.pow(2).mean(-1, keepdim=True)
par8 = torch.cat([x32[:, i:i + 8].pow(2).mean(-1, keepdim=True) for i in range(0, 2000, 8)], dim=1)
un = torch.cat([x32[:, i:i + 1].pow(2).mean(-1, keepdim=True) for i in range(2000)], dim=1)
lot8 = x32[0, :8].reshape(8, 1, 4096).pow(2).mean(-1, keepdim=True).reshape(1, 8, 1)
sortie["e_invariance_processeur"] = {"plein_vs_par8_identiques": bool(torch.equal(plein, par8)),
                                      "plein_vs_un_par_un_identiques": bool(torch.equal(plein, un)),
                                      "lot_8x1_vs_plein_identiques": bool(torch.equal(lot8, plein[:, :8]))}
print(json.dumps(sortie, indent=1))
