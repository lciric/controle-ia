"""Recalcule les chiffres du modèle jouet cités par le brouillon v2 (répétitions au code 6556b4e et 47d3c61)."""
import hashlib, json, sys
from pathlib import Path

R = Path(sys.argv[1])
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def charger(p):
    d = json.loads(Path(p).read_text()); return d.get("resultat", d)

for run in ["20261005-121017-repetition-jouet", "20261005-121053-repetition-jouet",
            "20261005-122652-repetition-jouet", "20261005-122708-repetition-jouet"]:
    f = R / "diag" / run / "resume.json"
    r = charger(f)
    comp = (R / "diag" / run / "resume.json.sha256").read_text().split()[0]
    m = json.loads((R / "runs" / run / "manifeste.json").read_text())
    print(f"== {run} : resume sha256 {sha(f)} (compagnon {'égal' if comp == sha(f) else 'DIFFÉRENT'}) ; commit du manifeste {m.get('commit', '?')[:12]}")
    lo, pc, prod = r["logique"]["equivalence"], r["controle_positif"]["bilan"], r["production"]["equivalence"]
    print(f"   logique : ecart_max {lo['ecart_max']:.3e} ; max_contexte {lo['max_contexte']:.3e} ; max_zone_generee {lo['max_zone_generee']:.3e}")
    cn = lo["controle_negatif"]; print(f"   logique CN : {cn['passent']}/{cn['comparables']} ; min {cn['min_des_maxima']:.4f} ; courtes {cn['courtes']}")
    print(f"   controle positif : comparables {pc['comparables']} vus {pc['vus']} courtes {pc['courtes']} min_des_maxima {pc['min_des_maxima']:.4e} fraction {pc['fraction']}")
    # par couche : minimum et maximum, sur les actions, du maximum de la zone générée (D1)
    par_couche = {}
    for e in r["controle_positif"]["episodes"]:
        for cle, prof in e["profils"].items():
            for c, p in prof.items():
                par_couche.setdefault(c, []).append(p["generee"].get("max"))
    print("   D1 par couche (min, max des maxima de zone générée) :", {c: (f"{min(v):.2e}", f"{max(v):.2e}") for c, v in par_couche.items()})
    cnp = prod["controle_negatif"]
    print(f"   production : ecart_max {prod['ecart_max']:.3e} ; CN {cnp['passent']}/{cnp['comparables']} min {cnp['min_des_maxima']:.4f}")
    rp = r["production"]["repere_precision"]
    print("   repère de précision max par couche :", {c: f"{v['max']:.3e}" for c, v in rp.items()}, "max global", f"{max(v['max'] for v in rp.values()):.3e}")
    print("   lecture :", r.get("lecture"))
    print("   chargement :", r.get("chargement"), "; noyaux permis logique :", r["logique"].get("noyaux_permis"))
    print("   réglages relus :", r["reglages"].get("relus"))
    print("   longueur_remplie_max logique / cp / prod :", r["logique"]["debit"].get("longueur_remplie_max"),
          r["controle_positif"]["debit"].get("longueur_remplie_max"), r["production"]["debit"].get("longueur_remplie_max"))
for run_b, run_a in [("20261005-121053-repetition-jouet", "20261005-121017-repetition-jouet"),
                     ("20261005-122708-repetition-jouet", "20261005-122652-repetition-jouet")]:
    f = R / "diag" / run_b / f"comparaison-{run_a}.json"
    c = charger(f)
    print(f"== comparaison {run_b} vs {run_a} : sha256 {sha(f)} ; identique {c['identique']} ; differences {c['differences']}")
