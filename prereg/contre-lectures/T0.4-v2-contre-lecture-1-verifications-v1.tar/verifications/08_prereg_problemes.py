"""problemes() du validateur (code cité) sur le brouillon tel quel, puis sur une copie où l'entrée de contre-lecture est remplie
(deux empreintes factices) ; et les gardes de citation (commit, révision, entropie) du lanceur sur le brouillon."""
import re, sys, tempfile
from pathlib import Path
sys.path.insert(0, "depot/src")
from controle_ia.prereg import problemes, sections
from controle_ia.harnais import validation_reelle as V
b = Path("depot/brouillons/T0.4-validation-modele-reel-v2-brouillon1.md")
print("brouillon tel quel :", problemes(b))
t = b.read_text(encoding="utf-8")
print("sections :", list(sections(t)))
rempli = t.replace("- **Contre-lecture 1** (sous-agent neuf) : À REMPLIR.",
                   "- **Contre-lecture 1** (sous-agent neuf) : brouillon " + "a" * 64 + " ; rapport " + "b" * 64 + ".")
with tempfile.TemporaryDirectory() as d:
    p = Path(d) / "x.md"; p.write_text(rempli, encoding="utf-8")
    print("entrée remplie :", problemes(p))
print("commit cité :", V.COMMIT_CITE.search(t).group(1))
print("révision citée :", V.REVISION_CITEE.search(t).group(1))
print("entropie citée :", V.ENTROPIE_CITEE.search(t).group(1), "< 2**128 :", int(V.ENTROPIE_CITEE.search(t).group(1)) < 2**128)
print("occurrences : commit", len(V.COMMIT_CITE.findall(t)), "révision", len(V.REVISION_CITEE.findall(t)), "entropie", len(V.ENTROPIE_CITEE.findall(t)))
