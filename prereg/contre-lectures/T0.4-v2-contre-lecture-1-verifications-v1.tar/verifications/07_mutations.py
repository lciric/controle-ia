"""Mutations ciblées du code au commit 47d3c61, chacune dans une copie minimale (src, tests, pyproject.toml) du clone ;
on lance tests/test_validation_reelle.py et tests/test_harnais_lots.py et l'on note si un test échoue (mutation vue).
Le clone de travail n'est jamais modifié."""
import concurrent.futures as cf, json, os, re, shutil, subprocess, sys, time
from pathlib import Path

B = Path(sys.argv[1])            # dossier cl-v2-1
SRC = B / "depot"
OUT = B / "mutations"
V = "src/controle_ia/harnais/validation_reelle.py"
E = "src/controle_ia/harnais/episode.py"
A = "src/controle_ia/harnais/activations.py"
M = "src/controle_ia/harnais/modeles.py"

GARDES = ('        phase = "logique"\n        appliquer_gardes(sorties, resume["logique"]["equivalence"], "logique", cn)\n'
          '        phase = "controle_positif"\n        exiger_controle_positif(resume["controle_positif"]["bilan"], cp, "contrôle positif")\n')
MUTATIONS = {
 "M01-garde-CP-retiree": [(V, '        exiger_controle_positif(resume["controle_positif"]["bilan"], cp, "contrôle positif")\n', '        pass  # mutation\n')],
 "M02-ordre-des-gardes-inverse": [(V, GARDES, '        phase = "controle_positif"\n        exiger_controle_positif(resume["controle_positif"]["bilan"], cp, "contrôle positif")\n'
                                    '        phase = "logique"\n        appliquer_gardes(sorties, resume["logique"]["equivalence"], "logique", cn)\n')],
 "M03-CP-joue-apres-les-gardes-de-logique": [
     (V, GARDES, '        phase = "controle_positif"\n        exiger_controle_positif(resume["controle_positif"]["bilan"], cp, "contrôle positif")\n'),
     (V, '        # contrôle positif (version 2) : défaut D1 injecté, même modèle, même noyau ; joué avant les gardes de logique,\n',
         '        appliquer_gardes(sorties, resume["logique"]["equivalence"], "logique", cn)\n        # (mutation)\n')],
 "M04-captures-en-simple-precision": [(A, 'return torch.float64 if dtype == torch.float64 else torch.float32', 'return torch.float32')],
 "M05-ecart-calcule-en-simple-precision": [(A, 'g64, p64 = g.astype(np.float64), p.astype(np.float64)', 'g64, p64 = g.astype(np.float32), p.astype(np.float32)')],
 "M06-reel-sans-conversion-double": [(M, 'modele = modele.to(torch.float64).to(appareil)', 'modele = modele.to(torch.float32).to(appareil)')],
 "M06b-jouet-logique-en-simple": [(V, "return m.to(getattr(torch, dtype)).eval(), tok", 'return m.to(torch.float32 if dtype == "float64" else getattr(torch, dtype)).eval(), tok')],
 "M07-NaN-compte-comme-vu": [(V, 'm = min(float("-inf") if z["max"] != z["max"] else z["max"] for z in zones)', 'm = min(float("inf") if z["max"] != z["max"] else z["max"] for z in zones)')],
 "M08-longueur-remplie-max-retiree": [(E, '                chrono["longueur_remplie_max"] = max(chrono.get("longueur_remplie_max", 0), plan["longueur_remplie"])\n', '')],
 "M09-D1-non-injecte": [(E, 'suivante = positions[:, -1:] + 1 + int(decalage_positions)', 'suivante = positions[:, -1:] + 1')],
 "M10-vu-a-une-couche-au-lieu-de-chaque": [(V, 'm = min(float("-inf") if z["max"] != z["max"] else z["max"] for z in zones)', 'm = max(float("-inf") if z["max"] != z["max"] else z["max"] for z in zones)')],
 "M11-comparaison-ignore-le-CP": [(V, '        differences.append({"phase": "controle_positif", "motif": "contrôle positif différent"})\n', '        pass  # mutation\n')],
 "M12-lecture-P2b-stricte": [(V, 'lecture["controle_positif"] = "conforme" if pc["bilan"]["fraction"] >= cpc["fraction_min"] else "contraire"', 'lecture["controle_positif"] = "conforme" if pc["bilan"]["fraction"] > cpc["fraction_min"] else "contraire"')],
 "M13-CP-joue-avec-le-T-de-la-logique": [(V, 'sorties_pc, plan_pc = jouer_phase(modele, fmt, c_pc, graines, "controle-positif"', 'sorties_pc, plan_pc = jouer_phase(modele, fmt, c, graines, "controle-positif"')],
 "M14-CP-avec-les-graines-de-la-logique": [(V, 'jouer_phase(modele, fmt, c_pc, graines, "controle-positif"', 'jouer_phase(modele, fmt, c_pc, graines, "logique"')],
 "M15-garde-CP-fraction-stricte": [(V, 'if not bilan["fraction"] >= cp["fraction_min"]:', 'if not bilan["fraction"] > cp["fraction_min"]:')],
 "M16-comparable-au-sens-large": [(V, 'if any(z["jetons"] < cp["positions_min"] for z in zones):', 'if any(z["jetons"] <= cp["positions_min"] for z in zones):')],
 "M17-garde-CP-actions-min-large": [(V, 'if bilan["comparables"] < cp["actions_min"]:\n        return', 'if bilan["comparables"] <= cp["actions_min"]:\n        return')],
 "M18-reglages-non-relus": [(M, '    reglages["relus"] = etats_effectifs()\n', '')],
 "M19-noyaux-permis-retires": [(V, '"noyau_attention": c["noyau_attention"], "noyaux_permis": permis,', '"noyau_attention": c["noyau_attention"],')],
 "M20-sonde-ulp-en-simple": [(A, 'p[n, 0] = np.nextafter(p[n, 0], p.dtype.type(np.inf), dtype=p.dtype)', 'p[n, 0] = np.nextafter(np.float32(p[n, 0]), np.float32(np.inf), dtype=np.float32)')],
 "M21-garde-carte-75-Gio": [(V, '"memoire_carte_min_gio": 130,', '"memoire_carte_min_gio": 75,')],
 "M22-memoire-vive-64-Go": [(V, '"memoire_vive_min_go": 96,', '"memoire_vive_min_go": 64,')],
 "M23-CP-lit-le-contexte": [(V, 'zones = [p["generee"] for p in r["profils"][cle].values()]', 'zones = [p["contexte"] for p in r["profils"][cle].values()]')],
}

def lancer(nom):
    d = OUT / nom
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    for x in ("src", "tests", "pyproject.toml"):
        (shutil.copytree if (SRC / x).is_dir() else shutil.copy2)(SRC / x, d / x)
    for fichier, ancien, nouveau in MUTATIONS[nom]:
        t = (d / fichier).read_text(encoding="utf-8")
        n = t.count(ancien)
        if n != 1:
            return nom, {"erreur": f"{fichier}: motif trouvé {n} fois"}
        (d / fichier).write_text(t.replace(ancien, nouveau), encoding="utf-8")
    env = dict(os.environ, PYTHONPATH="src", PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="1")
    t0 = time.time()
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "-rf",
                        "tests/test_validation_reelle.py", "tests/test_harnais_lots.py"],
                       cwd=d, env=env, capture_output=True, text=True, timeout=1500)
    (d / "pytest.txt").write_text(r.stdout + "\n--- stderr\n" + r.stderr, encoding="utf-8")
    lignes = r.stdout.strip().splitlines()
    echecs = sorted({l.split(" ")[1].split("::")[-1] for l in lignes if l.startswith("FAILED ")})
    return nom, {"code": r.returncode, "bilan": lignes[-1] if lignes else "", "tests_en_echec": echecs,
                 "vue": r.returncode != 0, "duree_s": round(time.time() - t0)}

if __name__ == "__main__":
    noms = sys.argv[2:] or list(MUTATIONS)
    res = {}
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        for nom, r in ex.map(lancer, noms):
            res[nom] = r
            print(nom, json.dumps(r, ensure_ascii=False), flush=True)
    (OUT / "resultats.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
