"""Chiffres de la v1 cités par la Transparence du brouillon v2, recalculés depuis diag/20261005-102042-validation-reelle/arret.json."""
import json, statistics
a = json.load(open("diag/20261005-102042-validation-reelle/arret.json"))["resultat"]
p = a["partiel"]; lo = p["logique"]["equivalence"]
print("phase", a["phase"], "| motif", a["motif"][:120])
print("ecart_max", lo["ecart_max"], "max_contexte", lo["max_contexte"], "max_zone_generee", lo["max_zone_generee"])
cn = lo["controle_negatif"]; print("P3", cn["passent"], "/", cn["comparables"], "min", cn["min_des_maxima"])
par = {}
med = {}
for e in p["logique"]["episodes"]:
    for cle, prof in e["equivalence"]["profils"].items():
        for c, z in prof.items():
            par.setdefault(c, []).append(z["max"])
            med.setdefault(c, []).append(z["contexte"].get("q50"))
print("max par couche", {c: f"{max(v):.3e}" for c, v in par.items()})
print("médiane des médianes (contexte) par couche", {c: f"{statistics.median(x for x in v if x is not None):.2e}" for c, v in med.items()})
print("tests", p.get("tests_instance"), "| lecture partielle", p["lecture_partielle"])
print("mémoire max logique (Go)", p["logique"]["memoire_max_go"], "| carte", p["reglages"].get("memoire_carte_gio"), "| mémoire vive", p.get("memoire_vive_go"))
