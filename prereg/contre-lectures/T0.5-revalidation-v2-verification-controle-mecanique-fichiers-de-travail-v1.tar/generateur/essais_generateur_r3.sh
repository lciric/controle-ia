#!/usr/bin/env bash
# Contrôle mécanique (CM) : arrêts du générateur r3 en mode reel (VT-02, VT-10, VT-11, VC-03, VC-04), sur un clone
# jetable du dépôt de travail à HEAD ; préalables simulés comme au banc v6 (GO fictif, N-018 tranché, R-136 et R-137
# fictifs, deux rapports fictifs). Aucune écriture sous le dépôt de travail ni sous revalidation-v2.
set -uo pipefail
E=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/controle-mecanique-essais/generateur
H=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/revalidation-v2
PY=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/scellement-revalidation/venv-gpu-neuf/bin/python
SRC=/home/user/controle-ia-travail
CL=prereg/contre-lectures; GO=GO-2026-10-11-99; REG=R-137
CAND=brouillons/T0.5-revalidation-equivalence-pilote-v2-candidat4.md
RELU=brouillons/T0.5-revalidation-equivalence-pilote-v2-candidat2.md
FICTIFS="T0.5-revalidation-v2-verification-banc-controles-v1.tar T0.5-revalidation-v2-verification-controle-mecanique-v1.md"
NOMS="T0.5-revalidation-v2-relecture-texte-v1.md T0.5-revalidation-v2-relecture-code-v1.md T0.5-revalidation-v2-relecture-chaine-v1.md T0.5-revalidation-v2-relecture-contre-verifications-v1.md T0.5-revalidation-v2-relecture-resultats-v1.json T0.5-revalidation-v2-relecture-fichiers-de-travail-v1.tar T0.5-revalidation-v2-verification-texte-v1.md T0.5-revalidation-v2-verification-chaine-v1.md T0.5-revalidation-v2-verification-contre-verifications-v1.md T0.5-revalidation-v2-verification-resultats-v1.json T0.5-revalidation-v2-verification-fichiers-de-travail-v1.tar $FICTIFS"
[ -e "$E/source" ] && { echo "déjà monté"; exit 2; }
mkdir -p "$E" && cd "$E" && git clone -q --no-local "$SRC" source && cd source || exit 2
git config user.email essai@invalid; git config user.name essai; git config commit.gpgsign false
python3 - <<EOF || exit 2
from pathlib import Path
d = Path("registres/decisions.md"); t = d.read_text(encoding="utf-8")
l = [x for x in t.split("\n") if x.startswith("| N-018 |")][0]
t = t.replace(l, l.rsplit("| en attente |", 1)[0] + "| tranché : option (a), $GO (essai) |")
t = t.rstrip("\n") + ("\n| R-136 | 2026-10-11 | essai : vérification des corrections | R2 |"
                      "\n| $REG | 2026-10-11 | essai : $GO consigné | — |\n")
d.write_text(t, encoding="utf-8")
g = Path("registres/go.md")
g.write_text(g.read_text(encoding="utf-8").rstrip("\n") + "\n| $GO | 2026-10-11 | revendication | N-018, option (a) (essai) | — | — | Lazar | $REG (essai) |\n", encoding="utf-8")
for n in "$FICTIFS".split():
    Path("$CL/" + n).write_text("rapport fictif (essai) " + n + "\n", encoding="utf-8")
EOF
for n in $FICTIFS; do PYTHONPATH=src "$PY" -m controle_ia.scellement sceller "$CL/$n" > /dev/null || exit 2; done
git add -A registres $CL && git commit -qm "essai : préalables simulés" || exit 2
C1=$(git rev-parse HEAD)
PAIRES=""; for n in $NOMS; do PAIRES="$PAIRES $n=$(sha256sum "$CL/$n" | cut -d' ' -f1)"; done; PAIRES=${PAIRES# }
NV=4e217cca897d8d737d654d4a4f5481bf3df205201358d8d7af00a800220d2062; SV=$(sha256sum "$CAND" | cut -d' ' -f1)
sed -e "s|^CANDIDAT_VERIFIE=.*|CANDIDAT_VERIFIE=$SV|" -e "s|^CANDIDAT_VERIFIE_CHEMIN=.*|CANDIDAT_VERIFIE_CHEMIN=$CAND|" \
    -e "s|^CANDIDAT_NORMALISE=.*|CANDIDAT_NORMALISE=$NV|" -e "s|^RAPPORTS_ATTENDUS=.*|RAPPORTS_ATTENDUS=\"$PAIRES\"|" \
    "$H/controles_avant_depense_v6.sh" > "$E/ctl.sh"
sed -e "s|^CANDIDAT_NORMALISE=.*|CANDIDAT_NORMALISE=$(printf '0%.0s' {1..64})|" "$E/ctl.sh" > "$E/ctl-normalise-faux.sh"
n=0
cas() {   # $1 nom ; $2 code attendu (0 ou 1) ; $3 modification avant le commit ; $4.. arguments du générateur à substituer
    local nom=$1 attendu=$2 avant=$3; shift 3
    local commit=6ec7434119781a3abebac789174101b9ed6ae087 ctl=$E/ctl.sh relu=$RELU go=$GO reg=$REG
    local kv; for kv in "$@"; do eval "local $kv"; done
    git checkout -q -f -B "cas-$nom" "$C1"; eval "$avant"
    git add -A . >/dev/null 2>&1; git commit -qm "essai : $nom" >/dev/null 2>&1
    rm -f "$E/v2-$nom.md"
    "$PY" -I "$H/remplir_revalidation_v2_r3.py" . "$commit" reel "$(date -u '+%Y-%m-%d %H:%M UTC')" "$E/v2-$nom.md" \
        --controles "$ctl" --candidat-relu "$relu" --candidat-verifie "$CAND" --go "$go" --registre "$reg" > "$E/sortie-$nom.txt" 2>&1
    local c=$?; [ "$c" = 0 ] || c=1
    local v="conforme"; [ "$c" = "$attendu" ] || v="NON CONFORME (attendu $attendu)"
    echo "$nom : code $c ; $v ; $(tail -1 "$E/sortie-$nom.txt" | cut -c1-170)"
}
cas G0-sain 0 ":"
cas G1-registre-mal-forme 1 ":" reg=R137
cas G2-registre-inexistant 1 ":" reg=R-999
cas G3-registre-sans-go 1 ":" reg=R-135
cas G4-candidat-relu-faux 1 ":" relu=$CAND
cas G5-go-mal-forme 1 ":" go=GO-2026-10-11-9
cas G6-go-revoque 1 "echo '| GO-2026-10-11-98 | 2026-10-11 | révocation | révoque $GO (N-018) | — | — | Lazar | essai |' >> registres/go.md"
cas G7-go-par-session 1 "sed -i -E 's/^(\| $GO \|.*)\| Lazar \|/\1| session |/' registres/go.md"
cas G8-n018-refuse 1 "sed -i -E 's/^(\| N-018 \|.*)\| tranché : [^|]*\|$/\1| refusé : option (b) retenue ($GO) |/' registres/decisions.md"
cas G9-normalise-faux 1 ":" ctl=$E/ctl-normalise-faux.sh
cas G10-commit-autre 1 ":" commit=$(git rev-parse HEAD)
cas G11-processeur-altere 1 "echo ' ' >> traces/t05-instance-55292763-processeur-20261011/processeur.json"
cas G12-r136-absent 1 "sed -i '/^| R-136 |/d' registres/decisions.md"
echo FIN
