#!/usr/bin/env bash
set -euo pipefail
trap 'echo "arrêt avant la création (ligne $LINENO)"; exit 2' ERR
trap 'echo "trap EXIT"' EXIT
: "${JETON_FICTIF_ABSENT:?JETON_FICTIF_ABSENT absent}"
echo "non atteint"
