#!/usr/bin/env bash
# Contrôle mécanique (CM) : cas du banc léger du lanceur v6. Chaque cas : HOME redirigé, clé d'API retirée, jetons
# factices, faux outil de location ; on relève le code, les appels journalisés et la présence du clone des contrôles.
set -uo pipefail
E=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/controle-mecanique-essais/lanceur
L=$E/B/revalidation-v2/lancer_revalidation_v6.sh
[ "$(sed -n 's/^B=//p' "$L")" = "$E/B" ] || { echo "copie du lanceur non sûre"; exit 2; }
cas() {   # $1 nom ; $2 code attendu ; puis affectations d'environnement propres au cas
    local nom=$1 attendu=$2; shift 2
    rm -rf "$E/traces" "$E/compteur-heure"; : > "$E/journal-$nom.txt"
    env -u VAST_API_KEY HOME="$E/home" PATH="$E/bin-heure:$E/bin-df:/usr/bin:/bin" \
        HF_TOKEN=factice-hf-0000000 CONTROLE_IA_GITHUB_TOKEN=factice-gh-0000000 FAUX_VASTAI_JOURNAL="$E/journal-$nom.txt" \
        "$@" bash "$L" 111 "$E/traces" > "$E/sortie-$nom.txt" 2>&1
    local c=$?
    local cree; cree=$(grep -c "CREATION FACTICE" "$E/journal-$nom.txt")
    local clone="absent"; [ -e "$E/traces/clone-controles" ] && clone="PRÉSENT"
    local v="conforme"; [ "$c" = "$attendu" ] || v="NON CONFORME (attendu $attendu)"
    echo "$nom : code $c ; créations factices $cree ; clone des contrôles $clone ; $v"
    grep -v '^$' "$E/sortie-$nom.txt" | tail -3 | sed 's/^/    | /' | cut -c1-180
}
cas M0-sain 0 FAUX_X=1
cas M1-creee-mais-code-1 4 FAUX_CODE_CREATION=1
cas M2-reponse-illisible 4 FAUX_CREATION=illisible
cas M3-echec-creation 4 'FAUX_CREATION={"success": false, "msg": "non"}'
cas M4-heure-2345-avant-creation 3 FAUX_HEURE2=2345
cas M5-place-traces 3 FAUX_DF_TRACES=1
cas M6-controles-ko 2 FAUX_KO=1
cas M7-offre-sans-prix 2 FAUX_PRIX=null
cas M8-jeton-absent 2 HF_TOKEN=
# GO révoqué dans le registre courant (copie de travail du dépôt synthétique, non committée)
cp "$E/depot/registres/go.md" "$E/go-sauve.md"
echo '| GO-2026-10-11-98 | 2026-10-11 | révocation | révoque GO-2026-10-11-99 (N-018) | — | — | Lazar | essai |' >> "$E/depot/registres/go.md"
cas M9-go-revoque-courant 2 FAUX_X=1
cp "$E/go-sauve.md" "$E/depot/registres/go.md"
# contrôles exécutés différents de leur copie versée à S
cp "$E/B/revalidation-v2/controles_avant_depense_v6.sh" "$E/ctl-sauve.sh"
echo "# modifié" >> "$E/B/revalidation-v2/controles_avant_depense_v6.sh"
cas M10-controles-non-verses 2 FAUX_X=1
cp "$E/ctl-sauve.sh" "$E/B/revalidation-v2/controles_avant_depense_v6.sh"
cas M11-sain-rejoue 0 FAUX_X=1
echo "FIN"
