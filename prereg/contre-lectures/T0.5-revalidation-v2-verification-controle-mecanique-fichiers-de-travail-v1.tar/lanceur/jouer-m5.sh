#!/usr/bin/env bash
set -uo pipefail
E=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/controle-mecanique-essais/lanceur
L=$E/B/revalidation-v2/lancer_revalidation_v6.sh
[ "$(sed -n 's/^B=//p' "$L")" = "$E/B" ] || exit 2
rm -rf "$E/traces" "$E/compteur-heure"; : > "$E/journal-M5b.txt"
env -u VAST_API_KEY HOME="$E/home" PATH="$E/bin-heure:$E/bin-df:/usr/bin:/bin" HF_TOKEN=factice-hf-0000000 CONTROLE_IA_GITHUB_TOKEN=factice-gh-0000000 FAUX_VASTAI_JOURNAL="$E/journal-M5b.txt" FAUX_DF_TRACES=1 bash "$L" 111 "$E/traces" > "$E/sortie-M5b.txt" 2>&1
echo "M5b-place-traces : code $? ; créations factices $(grep -c 'CREATION FACTICE' "$E/journal-M5b.txt") ; appels $(wc -l < "$E/journal-M5b.txt")"; tail -2 "$E/sortie-M5b.txt"
