#!/usr/bin/env bash
# Contrôle mécanique (CM) : montage d'un banc léger du lanceur v6. Dépôt synthétique minimal, faux outil de location
# (copie de celui de la vérification, qui n'appelle aucun service), faux contrôles égaux à leur copie versée.
# HOME redirigé et clé d'API retirée de l'environnement à l'exécution : aucun appel réel n'est possible.
set -euo pipefail
E=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/controle-mecanique-essais/lanceur
BN=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad
D=/home/user/controle-ia-travail
P=prereg/T0.5-revalidation-equivalence-pilote-v2.md
[ -e "$E/depot" ] && { echo "déjà monté"; exit 2; }
mkdir -p "$E/B/revalidation-v2" "$E/B/venv-vastai/bin" "$E/home" "$E/bin-heure" "$E/bin-df"
cp "$BN/verification-v2-essais/lanceur/venv-vastai/bin/vastai" "$E/B/venv-vastai/bin/vastai"
chmod +x "$E/B/venv-vastai/bin/vastai"
cat > "$E/B/revalidation-v2/controles_avant_depense_v6.sh" <<'EOF'
#!/usr/bin/env bash
# faux contrôles (CM) : crée le dossier du clone, échoue si FAUX_KO est posé
mkdir -p "$2" && echo donnees > "$2/x"
if [ -n "${FAUX_KO:-}" ]; then echo "OK  essai"; echo "KO  essai : faute simulée"; echo "CONTRÔLES AVANT DÉPENSE : ÉCHEC"; exit 1; fi
echo "OK  essai"; echo "CONTRÔLES AVANT DÉPENSE : TOUS CONFORMES"
EOF
sed -e "s|^DEPOT=.*|DEPOT=$E/depot|" -e "s|^B=.*|B=$E/B|" "$BN/revalidation-v2/lancer_revalidation_v6.sh" > "$E/B/revalidation-v2/lancer_revalidation_v6.sh"
echo "lignes changées dans la copie du lanceur : $(diff "$BN/revalidation-v2/lancer_revalidation_v6.sh" "$E/B/revalidation-v2/lancer_revalidation_v6.sh" | grep -c '^>')"
[ "$(sed -n 's/^B=//p' "$E/B/revalidation-v2/lancer_revalidation_v6.sh")" = "$E/B" ] || { echo "B mal remplacé"; exit 2; }
# faux date : 2200 au premier appel « -u +%H%M », puis la valeur de FAUX_HEURE2 (défaut 2200)
cat > "$E/bin-heure/date" <<EOF
#!/usr/bin/env bash
if [ "\$*" = "-u +%H%M" ]; then
  n=\$(cat "$E/compteur-heure" 2>/dev/null || echo 0); n=\$((n+1)); echo \$n > "$E/compteur-heure"
  if [ "\$n" -ge 2 ]; then echo "\${FAUX_HEURE2:-2200}"; else echo 2200; fi; exit 0
fi
exec /usr/bin/date "\$@"
EOF
chmod +x "$E/bin-heure/date"
# faux df : 2,9 Go libres sur le dossier des traces seulement (FAUX_DF_TRACES posé)
cat > "$E/bin-df/df" <<EOF
#!/usr/bin/env bash
if [ -n "\${FAUX_DF_TRACES:-}" ] && [ "\${@: -1}" = "$E/traces" ]; then
  printf 'Filesystem 1024-blocks Used Available Capacity Mounted\n/dev/x 100 90 2900000 97%% /\n'; exit 0
fi
exec /usr/bin/df "\$@"
EOF
chmod +x "$E/bin-df/df"
# dépôt synthétique : v2 saine du banc v6, amorce, registre des GO, garde de calcul, copies versées
mkdir -p "$E/depot" && cd "$E/depot" && git init -q -b main
git config user.email essai@invalid; git config user.name essai; git config commit.gpgsign false
mkdir -p prereg scripts registres .claude/hooks docs/procedures/revalidation-T0.5-v2
git -C "$D" show HEAD:scripts/amorce_instance_t05.sh > scripts/amorce_instance_t05.sh
git -C "$D" show HEAD:registres/go.md > registres/go.md
git -C "$D" show HEAD:.claude/hooks/garde_calcul.py > .claude/hooks/garde_calcul.py
git add -A && git commit -qm "base"
cp "$BN/banc-controles-v6/v2-saine.md" "$P"
(cd prereg && sha256sum "$(basename "$P")" > "$(basename "$P").sha256")
cp "$E/B/revalidation-v2/controles_avant_depense_v6.sh" "$E/B/revalidation-v2/lancer_revalidation_v6.sh" docs/procedures/revalidation-T0.5-v2/
git add -A && git commit -qm "S : v2 scellée (essai)"
git clone -q --bare . "$E/distant.git" && git remote add origin "$E/distant.git" && git fetch -q origin
echo "S = $(git rev-parse HEAD)"
