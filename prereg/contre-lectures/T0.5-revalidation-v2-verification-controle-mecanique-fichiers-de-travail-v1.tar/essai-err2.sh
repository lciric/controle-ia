#!/usr/bin/env bash
set -euo pipefail
trap 'echo "arrêt avant la création (ligne $LINENO)"; exit 2' ERR
DPH=$(python3 - <<'PY'
import sys
sys.exit("offre 1 sans prix lisible")
PY
)
echo "non atteint"
