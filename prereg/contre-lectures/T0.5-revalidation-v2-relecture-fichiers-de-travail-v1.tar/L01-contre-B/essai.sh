#!/usr/bin/env bash
# Rejoue les lignes 63-64 du lanceur v4 sur une réponse simulée (aucun appel à vastai).
set -euo pipefail
faux() { printf '%s' "$1"; }
for cas in '[]' '[{"id":1,"actual_status":"exited","cur_state":"stopped","intended_status":"stopped"}]'; do
  N=$(faux "$cas" | python3 -c 'import json, sys; print(len(json.load(sys.stdin)))')
  ( [ "$N" = 0 ] || { echo "$N instance(s) déjà sur le compte : pas de création"; exit 2; }; echo "création possible" ) ; echo "code $?"
done
