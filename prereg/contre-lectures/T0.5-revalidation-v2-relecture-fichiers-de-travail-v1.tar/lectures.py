import re, sys, json
from pathlib import Path
sys.path.insert(0, "/home/user/controle-ia-travail/src")
from controle_ia.harnais.validation_reelle import COMMIT_CITE, ENTROPIE_CITEE, REVISION_CITEE
from controle_ia.environnements.revalider_pilote_a import CONFIG_CITEE, TACHES_CITEES, EVALUATION_CITEE, INDEX_CITE
for f in sys.argv[1:]:
    t = Path(f).read_text(encoding="utf-8")
    print("==", f)
    for nom, rx in [("commit", COMMIT_CITE), ("entropie", ENTROPIE_CITEE), ("revision", REVISION_CITEE),
                    ("config", CONFIG_CITEE), ("taches", TACHES_CITEES), ("evaluation", EVALUATION_CITEE), ("index", INDEX_CITE)]:
        ms = rx.findall(t)
        print(f"  {nom}: first={ms[0] if ms else None} n={len(ms)} distinct={len(set(ms))}")
