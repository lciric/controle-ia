"""Émulation indépendante (relecteur C) : à la phase de tolérance 1e-9 (production de P4), écarts mesurés mis à zéro ;
But : l'ancien P4 échoue comme sur l'instance ; le nouveau passe ; (l'appel par mot-clé est éprouvé à part, par mutation de jouer_phase : IndexError)."""
import pytest
from controle_ia.gardes import GardeArret
from controle_ia.harnais import validation_reelle as V
import vr_ancien, vr_nouveau


def _zero(monkeypatch):
    reel = V.jouer_episodes
    def jouer(*a, **k):
        sorties = reel(*a, **k)
        if a[11] == 1e-9:
            for _, _, r in sorties:
                for champ in ("ecarts", "ecarts_q99"):
                    r[champ] = {cle: {c: 0.0 for c in pc} for cle, pc in r[champ].items()}
        return sorties
    monkeypatch.setattr(V, "jouer_episodes", jouer)


def test_ancien_echoue(depot, monkeypatch):
    _zero(monkeypatch)
    with pytest.raises(pytest.fail.Exception, match="DID NOT RAISE"):
        vr_ancien.test_p4_contraire_se_lit_au_vu_du_repere(depot)


def test_nouveau_passe(depot, monkeypatch):
    _zero(monkeypatch)
    vr_nouveau.test_p4_contraire_se_lit_au_vu_du_repere(depot, monkeypatch)
