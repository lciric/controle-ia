#!/usr/bin/env bash
# Fabrique les commits S d'artefact dans le clone jetable (essai L-03, angle B). Aucune poussée hors du dépôt nu local.
set -euo pipefail
E=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad/relecture-v2-essais/L03-contre-B-consequence
B=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad
PY=$B/scellement-revalidation/venv-gpu-neuf/bin/python
P2=prereg/T0.5-revalidation-equivalence-pilote-v2.md; P1=prereg/T0.5-revalidation-equivalence-pilote-v1.md
R=prereg/contre-lectures/T0.5-revalidation-v2-relecture-differentiel-v1.md
CODE=6ec7434119781a3abebac789174101b9ed6ae087; BASE=56e7af8
cd $E/source
gen() { $PY -I $B/revalidation-v2/remplir_revalidation_v2.py . "$1" essai "2026-10-11 00:30 UTC" $B/revalidation-v2/suite-correctif-tests.txt $P2 "${@:2}" >/dev/null; }
scel() { PYTHONPATH=src $PY -c "from controle_ia.prereg import sceller_prereg; sceller_prereg('$P2')"; git add -A prereg; git commit -qm "essai : $1"; echo "$1 $(git rev-parse HEAD)" >> $E/artefacts.txt; }
: > $E/artefacts.txt
# A1 v1 altérée, resscellée
git checkout -q -B a1 $BASE; gen $CODE $R; echo "ajout" >> $P1; sha256sum $P1 | sed 's#prereg/##' > $P1.sha256; scel A1-v1-alteree-rescellee
# A2 v1 altérée sans nouveau sceau
git checkout -q -B a2 $BASE; gen $CODE $R; echo "ajout" >> $P1; git add $P1; scel A2-v1-alteree-sans-sceau
# A3 relecture altérée après citation, resscellée
git checkout -q -B a3 $BASE; gen $CODE $R; echo "ajout" >> $R; sha256sum $R | sed 's#prereg/contre-lectures/##' > $R.sha256; scel A3-relecture-alteree
# A4 relecture absente
git checkout -q -B a4 $BASE; gen $CODE $R; git rm -q $R $R.sha256; scel A4-relecture-absente
# A5 aucune relecture citée
git checkout -q -B a5 $BASE; gen $CODE; scel A5-relecture-non-citee
# A8 fichier de code ajouté entre la v1 et le commit cité
git checkout -q -B a8 $BASE; echo '"""essai"""' > src/controle_ia/ajout_essai.py; git add src/controle_ia/ajout_essai.py; git commit -qm "essai : code ajouté"; C8=$(git rev-parse HEAD); gen $C8 $R; scel A8-code-ajoute
# A9 ligne Version 2 réécrite (contenu non relu), citation conservée
git checkout -q -B a9 $BASE; gen $CODE $R; sed -i 's/^- Version 2 (N-018) : différentiel v1 → v2 (texte et code : `git diff 3b8c049 6ec7434`, un seul fichier de test) relu avant le scellement par un sous-agent neuf/- Version 2 (N-018) : différentiel NON relu (texte libre ajouté au scellement)/' $P2; grep -c "NON relu" $P2; scel A9-ligne-version2-reecrite
# A10 ligne supplémentaire préfixée « - Version 2 (N-018) » insérée ailleurs (après la ligne du commit du code)
git checkout -q -B a10 $BASE; gen $CODE $R; sed -i '/^- Commit du code d.analyse/a - Version 2 (N-018) : ligne insérée hors historique (essai), contenu arbitraire.' $P2; grep -n "ligne insérée" $P2 | cut -c1-60; scel A10-ligne-prefixee-inseree
git checkout -q main
git push -q $E/distant.git a1 a2 a3 a4 a5 a8 a9 a10
cat $E/artefacts.txt
