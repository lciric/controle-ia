"""Contre-vérification de C-1 (angle A) : écarts de production du jouet, configuration PETITE, lus action par action
et couche par couche, tels que la garde de production les lit (ecarts_q99) et tels que le maximum les donne (ecarts).
Lecture seule du code (copie de l'arbre au commit 6ec7434). Aucun jeton ni secret."""
import subprocess
import sys
import tempfile
from pathlib import Path

racine_code = Path(sys.argv[1])
sys.path[:0] = [str(racine_code / "src"), str(racine_code / "tests")]
import torch  # noqa: E402
from controle_ia.harnais import validation_reelle as V  # noqa: E402
from test_validation_reelle import PETITE  # noqa: E402

print("capacite ATen :", torch.backends.cpu.get_cpu_capability(), "| torch", torch.__version__)
reel = V.jouer_episodes
captures = []


def jouer(*a, **k):
    sorties = reel(*a, **k)
    if a[11] == PETITE["production"]["tolerance"]:
        captures.append(sorties)
    return sorties


V.jouer_episodes = jouer
for entropie in [int(x) for x in sys.argv[2:]]:
    captures.clear()
    d = Path(tempfile.mkdtemp(dir=str(racine_code.parent)))
    for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"],
              ["config", "commit.gpgsign", "false"]):
        subprocess.run(["git", "-C", str(d), *a], check=True)
    (d / "README").write_text("x\n")
    subprocess.run(["git", "-C", str(d), "add", "-A"], check=True)
    subprocess.run(["git", "-C", str(d), "commit", "-qm", "init"], check=True)
    s = V.executer(d, "20261004-160000-repetition-jouet", entropie=entropie, config=PETITE, verifier_import=False)
    print(f"entropie {entropie} : appels de production captures = {len(captures)} ; lecture production = "
          f"{s['lecture']['production_equivalence']} ; audit = {s['lecture']['audit_symetrie']}")
    for i, sorties in enumerate(captures):
        mx, q = [], []
        for ep, _, r in sorties:
            for cle in r["ecarts"]:
                mx += list(r["ecarts"][cle].values())
                q += list(r["ecarts_q99"][cle].values())
        nn = sum(x > 0 for x in mx)
        print(f"  appel {i} : actions*couches = {len(mx)} ; max des maxima = {max(mx)!r} ; "
              f"max des q99 = {max(q)!r} ; maxima non nuls = {nn} ; q99 > 1e-9 : {sum(x > 1e-9 for x in q)}")
