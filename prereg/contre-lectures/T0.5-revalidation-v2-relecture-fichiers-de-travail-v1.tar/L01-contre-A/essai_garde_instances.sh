#!/usr/bin/env bash
# Essai : la garde des lignes 63-64 de lancer_revalidation_v4.sh, avec un faux vastai qui rend une instance arrêtée
# (même forme que le relevé filtré du 2026-10-06, traces/vastai-releve-20261006-1330/instances.json). Aucun appel réel.
set -euo pipefail
D=$(dirname "$0")
V="$D/faux_vastai.sh"
cat > "$V" <<'EOF'
#!/usr/bin/env bash
echo '[{"id": 55292763, "actual_status": "exited", "intended_status": "stopped", "cur_state": "stopped"}]'
EOF
chmod +x "$V"
N=$("$V" show instances --raw | python3 -c 'import json, sys; print(len(json.load(sys.stdin)))')
[ "$N" = 0 ] || { echo "$N instance(s) déjà sur le compte : pas de création"; exit 2; }
echo "création"
