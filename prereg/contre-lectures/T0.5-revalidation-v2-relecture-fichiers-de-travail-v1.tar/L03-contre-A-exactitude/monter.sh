#!/usr/bin/env bash
# Monte un dépôt de travail jetable et des commits de scellement simulés (cas sain et artefacts) pour éprouver
# controles_avant_depense_v4.sh (copie à adresse de dépôt paramétrable). Aucun accès réseau, aucun jeton.
set -euo pipefail
E=$(cd "$(dirname "$0")" && pwd)
SP=/tmp/claude-0/-home-user/5a6b9d1d-b17d-59a1-a770-8737a831fe0a/scratchpad
PY=$SP/scellement-revalidation/venv-gpu-neuf/bin/python
CAND=$SP/revalidation-v2/candidat-2/T0.5-revalidation-equivalence-pilote-v2.md
P=prereg/T0.5-revalidation-equivalence-pilote-v2.md; P1=prereg/T0.5-revalidation-equivalence-pilote-v1.md
R=prereg/contre-lectures/T0.5-revalidation-v2-relecture-differentiel-v1.md
cd "$E"; rm -rf travail; git clone -q --no-local /home/user/controle-ia-travail travail; cd travail
git config user.email essai@invalid; git config user.name essai
BASE=$(git rev-parse HEAD); echo "base $BASE" > "$E/commits.txt"
# variante : $1 nom ; $2 fonction de modification (appelée avant scellement) ; $3 fonction après scellement (facultative)
variante() {
  local nom=$1 avant=$2 apres=${3:-}
  git checkout -q -B "v-$nom" "$BASE"
  $avant
  PYTHONPATH=src "$PY" -c "from controle_ia.prereg import sceller_prereg; sceller_prereg('$P')" >/dev/null
  [ -n "$apres" ] && $apres
  git add -A prereg && git commit -qm "essai : scellement simulé ($nom)"
  echo "$nom $(git rev-parse HEAD)" >> "$E/commits.txt"
}
relecture() { printf 'Rapport simulé de la relecture de la v2 (essai L03).\n' > "$R"; echo "$(sha256sum "$R" | cut -d' ' -f1)  $(basename "$R")" > "$R.sha256"; }
citer() { local sha; sha=$(sha256sum "$R" | cut -d' ' -f1)
  cp "$CAND" "$P"
  sed -i "171s#(rapport à citer au scellement)#(\`T0.5-revalidation-v2-relecture-differentiel-v1.md\` (\`$sha\`))#" "$P"; }
sain() { relecture; citer; }
v1_alteree() { sain; printf '\n' >> "$P1"; }                        # v1 modifiée, sceau inchangé
v1_rescellee() { sain; printf "\n" >> "$P1"; echo "$(sha256sum "$P1" | cut -d" " -f1)  $(basename "$P1")" > "$P1.sha256"; }
releture_absente() { relecture; citer; rm -f "$R" "$R.sha256"; }
relecture_alteree() { relecture; citer; printf 'ajout\n' >> "$R"; }
relecture_non_citee() { relecture; cp "$CAND" "$P"; }
ligne_changee() { sain; sed -i '20s/$/ (ajout)/' "$P"; }
version2_changee() { sain; sed -i '171s/relu avant le scellement par un sous-agent neuf/non relu/' "$P"; }
variante sain sain
variante v1-alteree v1_alteree
variante v1-rescellee v1_rescellee
variante relecture-absente releture_absente
variante relecture-alteree relecture_alteree
variante relecture-non-citee relecture_non_citee
variante ligne-changee ligne_changee
variante version2-changee version2_changee
# code ajouté entre la v1 et le commit du code cité : commit C' sur la base, cité dans la v2
git checkout -q -B code-ajoute "$BASE"
printf '# ajout d essai\n' >> scripts/pilote_t05_instance.sh; git commit -qam "essai : code ajouté"; CP=$(git rev-parse HEAD)
code_ajoute() { sain; sed -i "9s/6ec7434119781a3abebac789174101b9ed6ae087/$CP/" "$P"
  e=$(git show "HEAD:scripts/pilote_t05_instance.sh" | sha256sum | cut -d' ' -f1)
  sed -i "s#\`scripts/pilote_t05_instance.sh\` (\`[0-9a-f]\{64\}\`, sha256)#\`scripts/pilote_t05_instance.sh\` (\`$e\`, sha256)#" "$P"; }
BASE_SAUVE=$BASE; BASE=$CP; variante code-ajoute code_ajoute; BASE=$BASE_SAUVE
git checkout -q main
# dépôts nus : un par configuration de branches
rm -rf "$E/distant.git" "$E/distant-branche.git"
git clone -q --bare . "$E/distant.git"
git -C "$E/distant.git" fetch -q "$E/travail" 'refs/heads/v-*:refs/heads/v-*' 'refs/heads/code-ajoute:refs/heads/code-ajoute'
git clone -q --bare "$E/distant.git" "$E/distant-branche.git"
git -C "$E/distant-branche.git" branch calcul/t05-revalidation-reel-v2 "$(git rev-parse v-sain)"
git -C "$E/distant.git" branch -a | head -20
