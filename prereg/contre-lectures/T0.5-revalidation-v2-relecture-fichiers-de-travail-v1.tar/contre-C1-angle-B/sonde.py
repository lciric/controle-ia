"""Contre-vérification de C-1 : production du jouet (PETITE), entropie donnée ; max, q99 max, non nuls par couche."""
import json, subprocess, sys, tempfile
from pathlib import Path
racine = Path(sys.argv[1]); sys.path[:0] = [str(racine / "src"), str(racine / "tests")]
import torch
from controle_ia.harnais import validation_reelle as V
from test_validation_reelle import PETITE
print("capacite", torch.backends.cpu.get_cpu_capability(), torch.__version__)
for ent in [int(x) for x in sys.argv[2:]]:
    d = Path(tempfile.mkdtemp(dir=str(racine.parent)))
    for a in (["init", "-q", "-b", "main"], ["config", "user.email", "t@x.invalid"], ["config", "user.name", "t"],
              ["config", "commit.gpgsign", "false"]):
        subprocess.run(["git", "-C", str(d), *a], check=True)
    (d / "R").write_text("x\n"); subprocess.run(["git", "-C", str(d), "add", "-A"], check=True)
    subprocess.run(["git", "-C", str(d), "commit", "-qm", "i"], check=True)
    s = V.executer(d, "20261004-160000-repetition-jouet", entropie=ent, config=PETITE, verifier_import=False)
    r = json.loads((d / s["resume"]).read_text())["resultat"]
    eq = r["production"]["equivalence"]
    nn = {c: z["generee"][1] - z["generee"][0] for c, z in eq["zeros"].items()}
    print(json.dumps({"ent": ent, "max": eq["ecart_max"], "q99max": eq["ecart_q99_max"], "non_nuls_generee": nn,
                      "tol": eq["tolerance"], "audit": s["lecture"]["audit_symetrie"]}))
